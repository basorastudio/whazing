// --- START OF FILE ScheduleController.ts ---

import type { Request, Response } from 'express';
// Assuming Yup might be needed for validation later, though not used in original store
// import * as Yup from 'yup';

import ListScheduleService from '../services/ScheduleServices/ListScheduleService'; // Assuming path
import ListScheduleServiceNew from '../services/ScheduleServices/ListScheduleServiceNew'; // Assuming path
import DeleteScheduleService from '../services/ScheduleServices/DeleteScheduleService';   // Assuming path
import createScheduleService from '../services/ScheduleServices/createScheduleService'; // Assuming path
import AppError from '../errors/AppError'; // Assuming path

interface ListQuery {
    startDate?: string;
    endDate?: string;
    startDateCreatedAt?: string;
    endDateCreatedAt?: string;
    pageNumber?: string;
    status?: string; // Added status based on index function usage
    selectedUser?: any; // Define better type if possible (e.g., { id: number | string })
    contactId?: number | string; // Added based on index function usage
}

interface StoreBody {
    body: string;
    startDate: string; // Date string
    endDate?: string; // Optional end date string
    contactId: number | string; // Contact to send to
    userId?: number | string; // User initiating (usually from req.user)
    tenantId?: number | string; // Tenant (usually from req.user)
    status?: string; // Optional status
    mediaPath?: string; // Optional path to media file
    mediaName?: string; // Optional name of media file
    repetir?: string; // 'true' or 'false' string based on original logic
    repeticao?: string; // Number as string based on original logic
}

export const listSchedule = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId } = req.user;
    const {
        startDate,
        endDate,
        startDateCreatedAt,
        endDateCreatedAt,
        pageNumber
    } = req.query as ListQuery;

    const { messages, count, hasMore } = await ListScheduleService({
        startDate,
        endDate,
        startDateCreatedAt,
        endDateCreatedAt,
        pageNumber,
        tenantId
    });

    return res.json({ messages, count, hasMore });
};

export const index = async (req: Request, res: Response): Promise<Response> => {
    const {
        startDate,
        endDate,
        startDateCreatedAt,
        endDateCreatedAt,
        pageNumber,
        status,
        selectedUser, // May contain { id: ... }
        contactId
    } = req.query as ListQuery;
    const { tenantId, profile, id: loggedInUserId } = req.user;

    let userIdFilter = ''; // Initialize as empty string

    // Determine the user ID to filter by based on profile
    if (profile !== 'admin' && profile !== 'supervisor') {
        userIdFilter = String(loggedInUserId); // Non-admins/supervisors see their own
    } else if (selectedUser !== undefined) {
        // If admin/supervisor selected a user, use that user's ID
        // Assuming selectedUser might be an object like { id: ... } or just the ID string
        userIdFilter = typeof selectedUser === 'object' && selectedUser !== null && selectedUser.id
                       ? String(selectedUser.id)
                       : String(selectedUser); // Adjust based on actual structure
    }
    // If admin/supervisor and no user selected, userIdFilter remains empty (fetch all for tenant)

    const { schedules, count, hasMore } = await ListScheduleServiceNew({
        startDate,
        endDate,
        startDateCreatedAt,
        endDateCreatedAt,
        pageNumber,
        userId: userIdFilter, // Pass the determined user ID filter
        status,
        tenantId,
        contactId // Pass contactId for filtering
    });

    return res.json({ schedules, count, hasMore });
};


export const remove = async (req: Request, res: Response): Promise<Response> => {
    const { id } = req.params;
    const { tenantId } = req.user;

    await DeleteScheduleService({ id, tenantId });
    return res.status(200).send(); // 200 OK with empty body is common for delete
};


export const store = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { tenantId } = req.user;
        const media = req.file; // Get uploaded file info from multer
        const scheduleData = req.body as StoreBody; // Cast body to interface

        // Prepare data for the service, ensuring types are correct
        const dataForService = {
            ...scheduleData,
            tenantId: Number(tenantId),
            userId: Number(req.user.id),
            // Use the filename from multer if a file was uploaded
            mediaPath: media ? media.filename : undefined,
            // Use the originalname if you want to store that too
            mediaName: media ? media.originalname : undefined,
            // Convert string 'true'/'false' to boolean
            repetir: scheduleData.repetir === 'true',
            // Convert repetition count string to number
            repeticao: scheduleData.repeticao ? parseInt(scheduleData.repeticao, 10) : undefined
        };

        // Add validation using Yup if needed here

        const schedule = await createScheduleService(dataForService);

        return res.status(201).json({ // 201 Created
            message: 'Agendamento criado com sucesso!', // Traducido
            data: schedule
        });

    } catch (error: any) {
        console.error('Erro ao criar agendamento:', error); // Traducido
        // Throw a standard AppError for consistent handling
        throw new AppError('Erro ao criar o agendamento'); // Traducido
    }
};

// --- END OF FILE ScheduleController.ts ---