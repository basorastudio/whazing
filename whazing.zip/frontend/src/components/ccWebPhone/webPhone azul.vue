<template>
  <div
    v-show="isOpen"
    class="absolute-top-left flex flex-center z-top"
    :key="keyWebPhone"
  >
    <q-page-sticky position="top-right" :offset="fabPos">
      <div class="relative-position" v-touch-pan.prevent.mouse="moveCall">
        <div style="position: absolute; top: 5px; right: 5px">
          <q-btn round flat color="neutral" icon="close" @click="handleClose" />
        </div>
        <!-- <q-btn @click="playRinging()"></q-btn> -->
        <div class="cwebphone">
          <div class="webphone">
            <div class="header">
              <h1 class="q-my-none">Webphone</h1>
              <!-- <div v-if="callError" class="text-caption text-negative">
                {{ callError }}
              </div> -->
              <!-- <div>{{ callInfo }}</div> -->
            </div>
            <div>
              {{
                callInfo.status !== "accept"
                  ? `Status: ${callStatus}`
                  : formattedDuration
              }}
            </div>
            <Thumbnail
              v-if="username && callInfo.status !== 'offer'"
              :src="getProfilePicture"
              :username="username"
              size="40px"
              status="online"
              variant="circle"
            />
            <div
              class="webphone-container webphone-border q-pa-xs"
              v-if="callInfo.status === 'offer'"
            >
              <div v-if="callInfo.id" class="text-black">
                {{ callInfo.phone }}
              </div>
              <div v-if="callInfo.tag" class="text-black">
                {{ callInfo.tag.substring(0, 20) }}
              </div>
              <div class="row justify-center">
                <q-btn
                  class="q-mr-sm glossy"
                  round
                  @click="doAcceptCall"
                  color="warning"
                  :disable="isCallEndDisabled"
                  icon="ring_volume"
                  :class="
                    [
                      'offer',
                      'call-start',
                      'relaylatency',
                      'preaccept',
                    ].includes(callInfo.status)
                      ? 'cblink-web'
                      : 'cweb-opacity'
                  "
                >
                  <q-tooltip>Aceitar chamada</q-tooltip>
                </q-btn>
                <q-btn
                  class="glossy"
                  round
                  :disable="isCallEndDisabled"
                  @click="doRejectCall"
                  color="negative"
                  icon="thumb_down_alt"
                >
                  <q-tooltip>Rejeitar chamada</q-tooltip>
                </q-btn>
              </div>
            </div>

            <div v-else>
              <div class="displayWeb q-my-sm">
                <div class="input-container">
                  <input
                    ref="refPhoneNumber"
                    type="text"
                    v-model="phoneNumber"
                    placeholder="Digite o número"
                  />
                  <q-icon
                    v-if="!!phoneNumber"
                    name="clear"
                    class="clear-icon"
                    @click="phoneNumber = ''"
                  />
                </div>
              </div>
              <div class="row justify-center q-gutter-md q-mb-md">
                <q-btn
                  class="glossy"
                  :class="
                    [
                      'offer',
                      'call-start',
                      'relaylatency',
                      'preaccept',
                    ].includes(callInfo.status)
                      ? 'cblink-web'
                      : 'cweb-opacity'
                  "
                  round
                  :disable="!phoneNumber || callInfo.status == 'accept'"
                  @click="call"
                  color="primary"
                  icon="call"
                >
                  <q-tooltip>Chamar</q-tooltip>
                </q-btn>
                <q-btn
                  class="glossy"
                  round
                  :disable="isCallEndDisabled"
                  @click="hangUp"
                  color="indigo"
                  icon="call_end"
                >
                  <q-tooltip>Desligar</q-tooltip>
                </q-btn>
                <!-- :disable="!phoneNumber" -->
                <q-btn
                  class="glossy"
                  :disable="callInfo.status !== 'accept'"
                  round
                  @click="isMuted ? unMute() : mute()"
                  color="positive"
                  :icon="isMuted ? 'volume_off' : 'volume_up'"
                >
                  <q-tooltip>{{ isMuted ? "Mudo" : "Som Normal" }}</q-tooltip>
                </q-btn>
              </div>
              <div class="keypad">
                <button
                  v-for="(item, index) in keypadLayout"
                  :key="index"
                  @click="pressKey(item.key)"
                  :disabled="cWhatsapps.length == 0"
                  :class="{ 'backspace-key': item.key === '←' }"
                >
                  <div class="keypad-button-content">
                    <span class="keypad-number">{{ item.key }}</span>
                    <span class="keypad-letters">{{ item.letters }}</span>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </q-page-sticky>
  </div>
</template>

<script>
import Thumbnail from './Thumbnail.vue' // Adjust path as necessary
import { mapGetters, mapMutations } from 'vuex' // If you're using Vuex
import SoundDTMF1 from 'src/assets/sounds/dtmf-1.mp3'
import SoundDTMF2 from 'src/assets/sounds/dtmf-2.mp3'
import SoundDTMF3 from 'src/assets/sounds/dtmf-3.mp3'
import SoundDTMF4 from 'src/assets/sounds/dtmf-4.mp3'
import SoundDTMF5 from 'src/assets/sounds/dtmf-5.mp3'
import SoundDTMF6 from 'src/assets/sounds/dtmf-6.mp3'
import SoundDTMF7 from 'src/assets/sounds/dtmf-7.mp3'
import SoundDTMF8 from 'src/assets/sounds/dtmf-8.mp3'
import SoundDTMF9 from 'src/assets/sounds/dtmf-9.mp3'
import SoundDTMF0 from 'src/assets/sounds/dtmf-0.mp3'
import SoundDTMFHash from 'src/assets/sounds/dtmf-hash.mp3'
import SoundDTMFStar from 'src/assets/sounds/dtmf-star.mp3'
import SoundCalling from 'src/assets/sounds/calling.mp3'
import SoundRinging from 'src/assets/sounds/ring.mp3'

const keypadLayout = [
  { key: '1', letters: '' },
  { key: '2', letters: 'ABC' },
  { key: '3', letters: 'DEF' },
  { key: '4', letters: 'GHI' },
  { key: '5', letters: 'JKL' },
  { key: '6', letters: 'MNO' },
  { key: '7', letters: 'PQRS' },
  { key: '8', letters: 'TUV' },
  { key: '9', letters: 'WXYZ' },
  { key: '*', letters: '' },
  { key: '0', letters: '+' },
  { key: '#', letters: '' },
  { key: '←', letters: '' } // Added backspace key
]
export default {
  name: 'cWebPhone',
  components: { Thumbnail },
  props: {
    openWebPhone: { type: Boolean, required: true },
    pWebPhoneNumber: { type: String, default: () => '' },
    pticketId: { type: [Number, String], required: false },
    pcontactId: { type: [Number, String], required: false },
    pcontactName: { type: String, required: false, default: () => '' },
    pprofile_picture: { type: String, required: false, default: () => '' }
  },
  data() {
    return {
      keypadLayout,
      keyWebPhone: 0,
      callingSound: null,
      ringSound: null,
      phoneNumber: this.pWebPhoneNumber,
      isOpen: this.openWebPhone,
      elapsedTime: 0,
      timer: null,
      isMuted: false,
      draggingFab: false,
      fabPos: [18, 180],
      keyPressData: { key: null, count: 0, lastPressTime: 0 }
    }
  },
  computed: {
    ...mapGetters({
      uiFlags: 'webphone/getUIFlags',
      callInfo: 'webphone/getCallInfo',
      inboxes: 'whatsapps',
      wavoip: 'webphone/getWavoip'
    }),
    cWhatsapps() {
      return this.inboxes || []
    },
    username() {
      return (
        this.callInfo.tag ||
        this.callInfo.contact_name ||
        this.callInfo.phone ||
        ''
      )
    },
    getProfilePicture() {
      return (
        this.callInfo.profile_picture ||
        this.pprofile_picture ||
        'user-profile-avatar.png'
      )
    },
    callStatus() {
      switch (this.callInfo.status) {
        case 'outcoming_calling':
          return 'Ligando...'
        case 'offer':
          return 'Chamando...'
        case 'call-start':
          return 'Ligando...'
        case 'terminate':
          return 'Chamada finalizada'
        default:
          return 'Não identificado'
      }
    },
    isCallEndDisabled() {
      return [
        'terminate',
        'reject',
        'accept_elsewhere',
        'reject_elsewhere'
      ].includes(this.callInfo.status)
    },
    formattedDuration() {
      const totalSeconds = this.elapsedTime
      const hours = Math.floor(totalSeconds / 3600)
      const minutes = Math.floor((totalSeconds % 3600) / 60)
      const seconds = totalSeconds % 60
      return [
        hours > 0 ? String(hours).padStart(2, '0') : '00',
        String(minutes).padStart(2, '0'),
        String(seconds).padStart(2, '0')
      ].join(':')
    }
  },
  watch: {
    // uiFlags(newUiIFlags) {
    //   // console.log("newUiIFlags", newUiIFlags);
    //   this.isOpen = newUiIFlags.isOpen;
    // },
    uiFlags: {
      handler: function (newUiIFlags) {
        console.log('newUiIFlags', newUiIFlags)
        this.isOpen = newUiIFlags.isOpen
      },
      deep: true
    },
    callInfo(newCallInfo, oldCallInfo) {
      this.phoneNumber = newCallInfo.phone
      const status = newCallInfo.status
      const oldStatus = oldCallInfo.status

      localStorage.setItem('wavo_call_info', JSON.stringify(newCallInfo))
      if (status === oldStatus) {
        return
      }
      console.log('status', status)
      if (status === 'accept') {
        this.startTimer()
      } else if (status === 'terminate') {
        this.stopTimer()
      }
      if (status === 'outcoming_calling') {
        this.playCalling()
      } else {
        this.stopCalling()
      }
      if (status === 'offer') {
        this.handlerPlayAudio()
        // this.playRinging();
      } else {
        this.stopRinging()
      }
    },
    inboxes(newInboxes) {
      newInboxes.forEach((inbox) => {
        if (inbox.wavoip) {
          this.startWavoip(inbox.name, inbox.wavoip)
        }
      })
    },
    pWebPhoneNumber(newValue) {
      this.phoneNumber = newValue
    },
    openWebPhone(newValue) {
      this.isOpen = newValue
    },
    $route: {
      handler(newPath, oldPath) {
        console.log(`Route changed from ${oldPath} to ${newPath}`)
        setTimeout(() => {
          // Reset states or handle the route change
          let pos
          const strPos = localStorage.getItem('webphone_position')
          if (strPos) {
            try {
              pos = JSON.parse(strPos)
            } catch (e) {
              pos = [18, 180]
            }
          } else pos = [18, 180]
          this.fabPos = pos
        }, 2000)
      },
      immediate: true
    }
  },
  methods: {
    ...mapMutations('webphone', ['SET_WEBPHONE_CALL']),
    handlerPlayAudio() {
      const options = {
        body: 'Você tem uma chamada',
        icon: this.callInfo.picture_profile
      }
      const notification = new Notification(
        `Mensagem de ${this.callInfo.tag || this.callInfo.phone}`,
        options
      )

      notification.onclick = (e) => {
        this.isOpen = true
        console.log('play ringing')
        this.playRinging()
      }
    },

    doAcceptCall() {
      this.$store.dispatch('webphone/acceptCall')
    },
    doRejectCall() {
      this.stopRinging()
      this.$store.dispatch('webphone/rejectCall')
    },
    startTimer() {
      if (this.timer) {
        clearInterval(this.timer)
      }
      const startDate = this.$store.state.webphone.call.active_start_date
      this.timer = setInterval(() => {
        const now = new Date()
        this.elapsedTime = Math.floor((now - startDate) / 1000)
      }, 1000)
    },
    stopTimer() {
      clearInterval(this.timer)
      this.timer = null
      this.elapsedTime = 0
    },
    pressKey(key) {
      const currentTime = Date.now()
      const clickInterval = 500 // Time window for multiple clicks (in milliseconds)
      if (key === '←') {
        this.phoneNumber = this.phoneNumber.slice(0, -1)
        // refthis.phoneNumber.focus();
        return
      }
      // Determine if the current key press should overwrite or concatenate
      const isSameKey = this.keyPressData.key === key
      const timeDifference = currentTime - this.keyPressData.lastPressTime

      if (isSameKey && timeDifference < clickInterval) {
        this.keyPressData.count += 1
      } else {
        this.keyPressData.key = key
        this.keyPressData.count = 1
      }

      // Update the last press time at the end
      this.keyPressData.lastPressTime = currentTime

      const item = keypadLayout.find((i) => i.key === key)
      if (item) {
        let charToAdd = item.key
        if (item.letters) {
          // Always start with the numeric key on the first click
          if (this.keyPressData.count === 1) {
            charToAdd = item.key
          } else {
            const index = (this.keyPressData.count - 1) % item.letters.length
            charToAdd = item.letters.charAt(index)
          }
        }

        // If the time difference is less than the click interval, overwrite the last character
        if (isSameKey && timeDifference < clickInterval) {
          this.phoneNumber = this.phoneNumber.slice(0, -1) + charToAdd
        } else {
          // Otherwise, concatenate to the existing input
          if (this.phoneNumber) {
            this.phoneNumber += charToAdd
          } else {
            this.phoneNumber = charToAdd
          }
        }
        this.playDTMFSounds(charToAdd)
      }
    },
    playDTMFSounds(key) {
      const playSound = this.soundMap[key]
      if (playSound) {
        playSound.play()
      } else {
        console.warn(`No sound mapped for key: ${key}`)
      }
    },

    playCalling() {
      this.callingSound = new Audio(SoundCalling)
      this.callingSound.loop = true
      this.callingSound.play()
    },
    stopCalling() {
      if (this.callingSound) {
        this.callingSound.pause()
        this.callingSound.currentTime = 0
      }
    },
    playRinging() {
      this.ringSound = new Audio(SoundRinging)
      this.ringSound.loop = true
      this.ringSound.play()
    },
    stopRinging() {
      if (this.ringSound) {
        this.ringSound.pause()
        this.ringSound.currentTime = 0
      }
    },

    async hangUp() {
      // console.log(`Chamada para ${this.phoneNumber} terminada.`);
      console.log('statttttt', this.callInfo.status)
      if (this.callInfo.status === 'offer') {
        this.$store.dispatch('webphone/rejectCall')
      } else this.$store.dispatch('webphone/endCall')
    },
    moveCall(ev) {
      this.draggingFab = ev.isFirst !== true && ev.isFinal !== true

      this.fabPos = [this.fabPos[0] - ev.delta.x, this.fabPos[1] + ev.delta.y]
      localStorage.setItem('webphone_position', JSON.stringify(this.fabPos))
    },
    startWavoip(inboxName, token) {
      this.$store.dispatch('webphone/startWavoip', {
        token,
        inboxName
      })
    },
    handleClose() {
      this.$emit('update:modelValue', false)
      this.isOpen = false
      this.$store.dispatch('webphone/updateWebphoneVisible', { isOpen: false })
    },
    async call() {
      console.log(`Chamando ${this.phoneNumber}`)
      try {
        await this.$store.dispatch('webphone/outcomingCall', {
          contact_id: this.pcontactId || '',
          contact_name: this.pcontactName || '',
          profile_picture: this.pprofile_picture || '',
          phone: this.phoneNumber,
          ticket_id: this.pticketId
        })
      } catch (error) {
        if (error.message === 'Numero não existe') {
          // notificarErro("Numero não existe");
        } else if (
          error.message === 'Linha ocupada, tente mais tarde ou faça um upgrade'
        ) {
          // notificarErro("Linha ocupada, tente mais tarde ou faça um upgrade");
          this.$q.notify({
            type: 'warn',
            message: 'Linha ocupada, tente mais tarde ou faça um upgrade',
            actions: [{ icon: 'close', round: true, color: 'white' }]
          })
        } else if (error.message === 'Limite de ligações atingido') {
          // notificarErro("Limite de ligações atingido");
        } else {
          // notificarErro("Erro efetuando chamada");
        }
      }
    },

    async mute() {
      try {
        await this.$store.dispatch('webphone/mute', {
          token: this.callInfo.id
        })
      } catch (error) {
        console.error('[*] - Error to mute', error)
      }
    },

    async unMute() {
      try {
        await this.$store.dispatch('webphone/unMute', {
          token: this.callInfo.id
        })
      } catch (error) {
        console.error('[*] - Error to mute', error)
      }
    },
    useSound(sound) {
      const audio = new Audio(sound)
      audio.loop = false
      return audio
    }
  },
  created() {},
  mounted() {
    let pos
    const strPos = localStorage.getItem('webphone_position')
    if (strPos) {
      try {
        pos = JSON.parse(strPos)
      } catch (e) {
        pos = [18, 180]
      }
    } else pos = [18, 180]
    this.fabPos = pos

    window.onbeforeunload = (event) => {
      event.preventDefault()
      event.stopImmediatePropagation()
      event.returnValue = true
      localStorage.setItem('wavo_call_info', JSON.stringify(this.callInfo))
    }

    console.log('webphone mounted')
    const locWavo = localStorage.getItem('wavo_call_info')
    const wavoInfo = JSON.parse(
      !locWavo || locWavo == 'undefined' ? '{}' : locWavo
    )
    if (wavoInfo?.id) {
      // wavoStore.call = { ...wavoStore.call, ...wavoInfo };
      this.SET_WEBPHONE_CALL(wavoInfo)

      if (['offer', 'accept'].includes(wavoInfo.call?.status)) {
        this.isOpen = false
        this.$store.dispatch('webphone/updateWebphoneVisible', {
          isOpen: true
        })
      }
    }

    this.soundMap = {
      1: this.useSound(SoundDTMF1),
      2: this.useSound(SoundDTMF2),
      3: this.useSound(SoundDTMF3),
      4: this.useSound(SoundDTMF4),
      5: this.useSound(SoundDTMF5),
      6: this.useSound(SoundDTMF6),
      7: this.useSound(SoundDTMF7),
      8: this.useSound(SoundDTMF8),
      9: this.useSound(SoundDTMF9),
      0: this.useSound(SoundDTMF0),
      '#': this.useSound(SoundDTMFHash),
      '*': this.useSound(SoundDTMFStar)
    }
  },
  beforeDestroy() {
    console.log('webphone unmounted')
    window.onbeforeunload = null
    // Cleanup logic if needed
  }
}
</script>
<style lang="scss" scoped>
.cwebphone {
  text-align: center;
  font-family: Avenir, Helvetica, Arial, sans-serif;
  color: #2c3e50;
}

.webphone {
  width: 350px;
  margin: 0 auto;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 10px;
  background-color: #c5d3d6;
  background-image: linear-gradient(0deg, #c5d3d6 0%, #2ceaea 100%);
}
.header {
  margin-bottom: 10px;
}

.input-container {
  position: relative;
}

.displayWeb input {
  width: 100%;
  padding: 10px;
  font-size: 18px;
  text-align: center;
  border: 1px solid #ddd;
  border-radius: 4px;
  // margin-bottom: 10px;
}
.clear-icon {
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
  cursor: pointer;
}

.keypad {
  display: flex;
  flex-wrap: wrap;
  gap: 10px; /* Adjust as needed for spacing between buttons */
}

.keypad button {
  flex: 1 1 25%; /* Adjust size of buttons as needed */
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
  font-size: 16px;
}

// .keypad {
//   display: grid;
//   grid-template-columns: repeat(3, 1fr);
//   gap: 10px;
// }
// .keypad button {
//   padding: 6px;
//   font-size: 18px;
//   cursor: pointer;
//   border: 1px solid #ddd;
//   border-radius: 4px;
//   background-color: #fff;
// }

.keypad button {
  align-items: center;
  background-color: initial;
  background-image: linear-gradient(#464d55, #25292e);
  border-radius: 8px;
  border-width: 0;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1), 0 3px 6px rgba(0, 0, 0, 0.05);
  box-sizing: border-box;
  color: #fff;
  cursor: pointer;
  display: inline-flex;
  flex-direction: column;
  font-size: 18px;
  height: 52px;
  justify-content: center;
  line-height: 1;
  margin: 0;
  outline: none;
  overflow: hidden;
  padding: 0 32px;
  text-align: center;
  text-decoration: none;
  transform: translate3d(0, 0, 0);
  transition: all 150ms;
  vertical-align: baseline;
  white-space: nowrap;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.keypad button.backspace-key {
  background: #e57373; // A distinct color for the backspace key
  color: #fff;
  font-size: 1.5rem;
}

.backspace-key {
  flex: 1 1 100%; /* Makes the backspace button span the full width */
  text-align: center; /* Center text inside the button */
}

.keypad button:hover {
  box-shadow: rgba(0, 1, 0, 0.2) 0 2px 8px;
  opacity: 0.85;
}

.keypad-button-content {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.keypad-number {
  font-size: 2rem;
  font-weight: bold;
}

.keypad-letters {
  font-size: 0.8rem;
  color: #666;
}

.keypad button:active {
  outline: 0;
}

.keypad button:focus {
  box-shadow: rgba(0, 0, 0, 0.5) 0 0 0 3px;
}

@media (max-width: 420px) {
  .keypad button {
    height: 48px;
  }
}
</style>

<style lang="sass" scoped>
.cblink-web
  animation: blink 3s linear infinite

.cweb-opacity
  opacity: 1

@keyframes blink
 0%
  opacity: 0
  background: red
 50%
  opacity: .5
  background: blue
 100%
  opacity: 1
  background: green
</style>
