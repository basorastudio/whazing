import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'allcontacts' column to the 'Users' table
    // Likely a flag indicating if the user can see all contacts vs. only their own.
    await queryInterface.addColumn(
      'Users',       // Table name
      'allcontacts', // New column name
      {
        type: DataTypes.BOOLEAN,
        allowNull: false,    // Cannot be null
        defaultValue: false, // Default to not seeing all contacts
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'allcontacts' column from the 'Users' table
    await queryInterface.removeColumn(
      'Users',       // Table name
      'allcontacts'  // Column name to remove
    );
  }
};

export = migration;