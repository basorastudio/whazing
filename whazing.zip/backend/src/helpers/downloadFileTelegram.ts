import axios, { AxiosRequestConfig } from "axios";
import { createWriteStream, WriteStream } from "fs";
import { Worker, isMainThread, parentPort, workerData } from "worker_threads";

interface WorkerInputData {
  url: string;
  pathFile: string;
}

interface ProgressData {
  type: "progress";
  downloadedBytes: number;
  totalSize: number;
}

interface CompleteData {
  type: "complete";
}

interface ErrorData {
  type: "error";
  error: string;
}

type WorkerMessage = ProgressData | CompleteData | ErrorData;

// --- Worker Function ---
const workerFunction = async (data: WorkerInputData): Promise<void> => {
  try {
    const axiosConfig: AxiosRequestConfig = {
      url: data.url,
      method: "GET",
      responseType: "stream",
      maxContentLength: Infinity, // Allow large files
      maxBodyLength: Infinity // Allow large files
    };

    const response = await axios(axiosConfig);
    const fileStream: WriteStream = createWriteStream(data.pathFile);
    let downloadedBytes = 0;
    const totalSize = parseInt(response.headers["content-length"] || "0", 10);

    return new Promise((resolve, reject) => {
      const stream = response.data;

      stream.on("data", (chunk: Buffer) => {
        downloadedBytes += chunk.length;
        if (parentPort) {
          const progressPayload: ProgressData = {
            type: "progress",
            downloadedBytes: downloadedBytes,
            totalSize: totalSize
          };
          parentPort.postMessage(progressPayload);
        }
      });

      stream.pipe(fileStream);

      fileStream.on("finish", () => {
        if (parentPort) {
          const completePayload: CompleteData = { type: "complete" };
          parentPort.postMessage(completePayload);
        }
        resolve();
      });

      fileStream.on("error", (err: Error) => {
        console.error("Error en Stream de archivo:", err);
        if (parentPort) {
          const errorPayload: ErrorData = {
            type: "error",
            error: err.message || "Stream error desconocido"
          };
          parentPort.postMessage(errorPayload);
        }
        reject(err); // Reject the promise on file stream error
      });

      stream.on("error", (err: Error) => {
        console.error("Error en Stream de respuesta:", err);
        if (parentPort) {
          const errorPayload: ErrorData = {
            type: "error",
            error: err.message || "Stream error desconocido"
          };
          parentPort.postMessage(errorPayload);
        }
        fileStream.close(); // Asegura cerrar el stream de archivo si hay error en el stream de respuesta
        reject(err); // Reject the promise on response stream error
      });
    });
  } catch (error: any) {
    console.error("ERROR DESCARGANDO:", error);
    if (parentPort) {
      const errorPayload: ErrorData = {
        type: "error",
        error: error?.message || "Error desconocido durante la descarga"
      };
      parentPort.postMessage(errorPayload);
    }
    throw error; // Re-throw error to be caught by the main thread's catch block if running directly
  }
};

// --- Main Thread Logic ---
if (!isMainThread && parentPort) {
  // Estamos en el worker thread
  (async () => {
    try {
      await workerFunction(workerData as WorkerInputData);
      // La finalización se indica mediante el mensaje 'complete'
    } catch (error: any) {
      // El error ya se envía a través de postMessage en workerFunction
      console.error("Worker thread error:", error?.message);
    }
  })();
}

// --- Exported Function (to be called from main thread) ---
type ProgressCallback = (percentage: number) => void;

export const downloadFileTelegram = async (
  url: string,
  pathFile: string,
  onProgress?: ProgressCallback
): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (!url || typeof url !== "string") {
      return reject(new Error("URL inválida proporcionada"));
    }
    if (!pathFile || typeof pathFile !== "string") {
      return reject(new Error("Ruta de archivo inválida proporcionada"));
    }

    const worker = new Worker(__filename, {
      workerData: { url, pathFile }
    });

    worker.on("message", (message: WorkerMessage) => {
      switch (message.type) {
        case "progress":
          if (onProgress && message.totalSize > 0) {
            const percentage =
              (message.downloadedBytes / message.totalSize) * 100;
            onProgress(percentage);
          }
          break;
        case "complete":
          resolve();
          break;
        case "error":
          reject(new Error(message.error || "Error desconocido del worker"));
          break;
      }
    });

    worker.on("error", err => {
      reject(new Error(`Error del Worker: ${err.message}`));
    });

    worker.on("exit", code => {
      if (code !== 0) {
        reject(new Error(`Worker detenido con código de salida ${code}`));
      }
      // La resolución ya ocurre con el mensaje 'complete'
    });
  });
};

// Maintain original export if needed
export const downloadFile = downloadFileTelegram;
