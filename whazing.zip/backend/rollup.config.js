const { rollup } = require('rollup');

const inputOptions = {
  input: 'dist/server.js', // Path to your project's entry file
};

const outputOptions = {
  file: 'dist/bundle.js', // Output bundled file
  format: 'cjs', // CommonJS format for Node.js
  sourcemap: true // Enable source maps for better debugging
};

async function build() {
  // Bundle files using Rollup without encryption
  const bundle = await rollup(inputOptions);
  await bundle.write(outputOptions);
}

build();

