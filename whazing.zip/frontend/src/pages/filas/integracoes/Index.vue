<template>
  <div v-if="!canAccessPage">
    <q-banner dense inline-actions class="bg-red text-white">
      <template v-slot:avatar>
        <q-icon name="warning" />
      </template>
      {{ $t('integracao.msgSemAcesso') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               v-if="whatsappNumber"
               icon="mdi-whatsapp"
               :label="$t('integracao.chamarSuporte')"
               @click="abrirWhatsApp2"
        />
      </template>
    </q-banner>
  </div>
  <div v-else-if="userProfile === 'admin'">
    <q-banner v-if="!premium" dense inline-actions class="bg-amber-8 text-white q-mb-md">
      <template v-slot:avatar>
        <q-icon name="star" />
      </template>
      {{ $t('general.msgRecursoPremium') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               icon="mdi-whatsapp"
               :label="$t('general.linkobterpremium')"
               @click="abrirWhatsApp3"
        />
      </template>
    </q-banner>

    <q-card-section v-if="!premium">
      <div class="row items-center justify-around q-col-gutter-md">
        <!-- Texto -->
        <div class="col-xs-12 col-sm-6 text-left">
          <div class="text-h6">
            {{ $t('dashboard.supportPlatform') }}
          </div>
          <div class="text-body q-mt-sm">
            {{ $t('dashboard.donationMessage') }}
          </div>
        </div>
        <!-- Imagem -->
        <div class="col-xs-12 col-sm-4 text-center">
          <img src="https://raw.githubusercontent.com/cleitonme/Whazing-SaaS/main/donate.jpg"
               alt="QR Code para doação via Pix"
               class="donation-image">
        </div>
      </div>
      <!-- Ícones de redes sociais -->
      <div class="row justify-center q-mt-md">
        <div class="social-icons">
          <q-btn round color="green" icon="mdi-whatsapp" size="md" class="q-mx-xs"
                 type="a" href="https://grupo.whazing.com.br/" target="_blank">
            <q-tooltip>Nosso Grupo de WhatsApp</q-tooltip>
          </q-btn>
          <q-btn round color="primary" icon="mdi-web" size="md" class="q-mx-xs"
                 type="a" href="https://www.whazing.com.br" target="_blank">
            <q-tooltip>Nosso Site</q-tooltip>
          </q-btn>
        </div>
      </div>
    </q-card-section>
    <q-table flat
      bordered
      square
      hide-bottom
             class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
             :class="{'full-height': $q.screen.lt.sm}"
      :data="integracoes"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :rows-per-page-options="[0]">
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-hub-outline q-pr-sm" />
            {{ $t('integracao.titulo') }}
          </h2>
          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline"
            :label="$t('integracao.adicionar')"
          @click="integracaoEdicao = {}; modalIntegracao = true" />
          <q-btn flat
                 class="generate-button btn-rounded-50"
                 :class="{'generate-button-dark' : $q.dark.isActive}"
                 v-if="whatsappNumber"
                 icon="mdi-whatsapp"
                 :label="$t('integracao.chamarSuporte')"
                 @click="abrirWhatsApp"
          />
        </div>

      </template>
      <template v-slot:body-cell-color="props">
        <q-td class="text-center">
          <div
            class="q-pa-sm rounded-borders"
            :style="`background: ${props.row.color}`"
          >
            {{ props.row.color }}
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'" />
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn flat
            round
                 class="color-light1"
                 :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-edit-outline"
            @click="editarIntegracao(props.row)" />
          <q-btn flat
            round
                 class="color-light1"
                 :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-trash-outline"
            @click="deletarIntegracao(props.row)" />
        </q-td>
      </template>
    </q-table>
    <ModalIntegracao :modalIntegracao.sync="modalIntegracao"
      :integracaoEdicao.sync="integracaoEdicao"
      @modal-integracao:criada="integracaoCriada"
      @modal-integracao:editada="integracaoEditada" />
  </div>
</template>

<script>
import { DeletarIntegracao, ListarIntegracoes } from 'src/service/integracoes'
import { ListarConfiguracaoPublica, Listarp } from 'src/service/configuracoesgeneral'
import { MostrarPlano } from 'src/service/empresas'
import ModalIntegracao from './ModalIntegracao'
export default {
  name: 'Integrações',
  components: {
    ModalIntegracao
  },
  data () {
    return {
      userProfile: 'user',
      integracaoEdicao: {},
      modalIntegracao: false,
      canAccessPage: false,
      integracoes: [],
      loading: false,
      premium: true,
      whatsappNumber: null,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'name', label: this.$t('integracao.nome'), field: 'name', align: 'left' },
        { name: 'type', label: this.$t('integracao.campoTipo'), field: 'type', align: 'left' },
        { name: 'acoes', label: this.$t('integracao.acoes'), field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.integrations !== false
      } catch (error) {
        console.error('Erro ao carregar o plano:', error)
      }
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configurações:', error)
      }
    },
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const message = encodeURIComponent(this.$t('integracao.whatsapp1'))
        const url = `https://wa.me/${this.whatsappNumber}?text=${message}`
        window.open(url, '_blank')
      }
    },
    abrirWhatsApp2() {
      if (this.whatsappNumber) {
        const message = encodeURIComponent(this.$t('integracao.whatsapp2'))
        const url = `https://wa.me/${this.whatsappNumber}?text=${message}`
        window.open(url, '_blank')
      }
    },
    abrirWhatsApp3() {
      const message = encodeURIComponent(this.$t('general.obterpremium'))
      const url = `https://wa.me/554899416725?text=${message}`
      window.open(url, '_blank')
    },
    async listarIntegracoes () {
      const { data } = await ListarIntegracoes()
      this.integracoes = data
    },
    integracaoCriada (integracao) {
      const newIntegracaos = [...this.integracoes]
      newIntegracaos.push(integracao)
      this.integracoes = [...newIntegracaos]
    },
    integracaoEditada (integracao) {
      const newIntegracaos = [...this.integracoes]
      const idx = newIntegracaos.findIndex(f => f.id === integracao.id)
      if (idx > -1) {
        newIntegracaos[idx] = integracao
      }
      this.integracoes = [...newIntegracaos]
    },
    editarIntegracao (integracao) {
      this.integracaoEdicao = { ...integracao }
      this.modalIntegracao = true
    },
    deletarIntegracao(integracao) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('integracao.confirmDeleteMsg', { name: integracao.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarIntegracao(integracao)
          .then(res => {
            let newIntegracaos = [...this.integracoes]
            newIntegracaos = newIntegracaos.filter(f => f.id !== integracao.id)

            this.integracoes = [...newIntegracaos]
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: this.$t('integracao.integracaoDeletada', { name: integracao.name }),
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .catch((error) => {
            console.error('Error deleting integration:', error) // Log the error for debugging
            this.$q.notify({
              type: 'negative',
              progress: true,
              position: 'top',
              message: this.$t('integracao.erroDelete'),
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }],
              group: false
            })
          })
          .finally(() => {
            this.loading = false
          })
      })
    }

  },
  mounted () {
    this.fetchConfigurations()
    this.listarPlano()
    this.listarIntegracoes()
    this.userProfile = localStorage.getItem('profile')
    this.loadVersionp()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 50px)
  .q-table__top
    padding: 8px
</style>
