import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna tokenVersion a la tabla Users
    return queryInterface.addColumn('Users', 'tokenVersion', { // Nombre de columna preservado
      type: DataTypes.INTEGER,
      allowNull: false, // Asume que no puede ser nulo
      defaultValue: 0 // Valor inicial para la versión del token
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna tokenVersion
    return queryInterface.removeColumn('Users', 'tokenVersion');
  }
};