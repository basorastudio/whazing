<template>
<div v-if="easyFlowVisible"
     class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
     :class="{
    'full-height': $q.screen.lt.sm
  }">
    <q-toolbar class="text-grey-8 ">
      <q-toolbar-title>
        <div class="text-h6">{{ data.name }}</div>
      </q-toolbar-title>

      <q-btn round
        class="color-light1"
        :class="$q.dark.isActive ? 'color-dark1' : ''"
        :icon="rightPanelVisible ? 'mdi-chevron-right' : 'mdi-chevron-left'"
        flat
        @click="rightPanelVisible = !rightPanelVisible"
      ></q-btn>

      <q-btn round
             class="color-light1"
             :class="$q.dark.isActive ? 'color-dark1' : ''"
             icon="mdi-magnify-plus-outline"
             flat
             @click="zoomAdd"
      ></q-btn>

      <q-btn round
             class="color-light1"
             :class="$q.dark.isActive ? 'color-dark1' : ''"
             icon="mdi-magnify-minus-outline"
             flat
             @click="zoomSub"
      ></q-btn>

      <q-btn round
        flat
        icon="mdi-delete"
        @click="deleteElement"
             class="color-light1"
             :class="$q.dark.isActive ? 'color-dark1' : ''"
        :disabled="!this.activeElement.type || ['start', 'exception'].includes(this.activeElement.type)"></q-btn>
      <q-separator inset
        spaced
        vertical />
       <q-btn
        round
        flat
        class="color-light1"
        :class="$q.dark.isActive ? 'color-dark1' : ''"
        icon="mdi-download"
        @click="downloadData"
      ></q-btn>
      <q-btn
        round
        flat
        class="color-light1"
        :class="$q.dark.isActive ? 'color-dark1' : ''"
        icon="mdi-help"
        @click="openHelp"
      ></q-btn>
      <q-btn round
             class="color-light1"
             :class="$q.dark.isActive ? 'color-dark1' : ''"
        flat
             icon="eva-undo-outline"
             @click="() => $router.push({ name: 'chatbot' })" />
    </q-toolbar>
    <q-separator color="text-grey-3" />
    <div class="q-mt-sm"
      style="display: flex; height: calc(100% - 60px);">
      <div id="efContainer"
           ref="efContainer"
           class="container"
           :style="{ width: rightPanelVisible ? 'calc(100% - 400px)' : '100%' }"
           v-flowDrag>
        <div class="flow-content" ref="flowContent">
        <template v-for="node in data.nodeList">
          <flow-node :id="node.id"
            :key="node.id"
            :node="node"
            :activeElement="activeElement"
            @changeNodeSite="changeNodeSite"
            @nodeRightMenu="nodeRightMenu"
            @clickNode="clickNode"
                     @configureNode="handleConfigureNode">
          </flow-node>
        </template>
        <!-- Forçar área de construção -->
        <div style="position:absolute;top: 2000px;left: 2000px;">&nbsp;</div>
      </div>
      </div>
      <!-- Configuração node -->
      <transition name="slide-right">
        <div v-if="rightPanelVisible"
             style="width: 400px; border-left: 1px solid #dce3e8;">
        <flow-node-form ref="nodeForm"
          @setLineLabel="setLineLabel"
          @repaintEverything="repaintEverything"
          :filas="cDataFlow.filas"
          :usuarios="cDataFlow.usuarios"
          :nodesList="data"
          @addNode="addNode"
          @deleteLine="deleteLine"
          @addNewLineCondition="addNewLineCondition"
          @saveFlow="saveFlow"
          @closeForm="togglePanel">
        </flow-node-form>
      </div>
      </transition>

    </div>
    <!-- Visualização Resultado -->
    <flow-info v-if="flowInfoVisible"
      ref="flowInfo"
      :data="data"></flow-info>
    <flow-help v-if="flowHelpVisible"
      ref="flowHelp"></flow-help>
  </div>

</template>

<script>
import draggable from 'vuedraggable'
// import jsPlumb from './jsplumb.js'

import './jsplumb'
import { easyFlowMixin } from './mixins'
import flowNode from './node'
import nodeMenu from './node_menu'
import FlowInfo from './info'
import FlowHelp from './help'
import FlowNodeForm from './node_form'
import { merge, cloneDeep } from 'lodash'
import './index.css'
import { uid } from 'quasar'

import { UpdateChatFlow } from '../../service/chatFlow'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  data () {
    return {
      isFullScreen: false,
      jsPlumb: null,
      easyFlowVisible: true,
      flowInfoVisible: false,
      loadEasyFlowFinish: false,
      flowHelpVisible: false,
      rightPanelVisible: false,
      data: {},
      activeElement: {
        type: undefined,
        nodeId: undefined,
        sourceId: undefined,
        targetId: undefined
      },
      zoom: 0.5
    }
  },
  props: {
    filas: {
      type: Array,
      default: () => []
    },
    usuarios: {
      type: Array,
      default: () => []
    }
  },
  mixins: [easyFlowMixin],
  components: {
    // eslint-disable-next-line vue/no-unused-components
    draggable, flowNode, nodeMenu, FlowInfo, FlowNodeForm, FlowHelp
  },
  directives: {
    flowDrag: {
      bind (el, binding, vnode, oldNode) {
        if (!binding) {
          return
        }
        el.onmousedown = (e) => {
          if (e.button == 2) {
            return
          }
          let disX = e.clientX
          let disY = e.clientY
          el.style.cursor = 'move'

          document.onmousemove = function (e) {
            e.preventDefault()
            const left = e.clientX - disX
            disX = e.clientX
            el.scrollLeft += -left

            const top = e.clientY - disY
            disY = e.clientY
            el.scrollTop += -top
          }

          document.onmouseup = function (e) {
            el.style.cursor = 'auto'
            document.onmousemove = null
            document.onmouseup = null
          }
        }
      }
    }
  },
  computed: {
    cDataFlow () {
      return this.$store.state.chatFlow
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    getUUID () {
      return uid()
    },
    addNewLineCondition (from, to, oldTo) {
      if (!this.jsPlumpConsist({ sourceId: from, targetId: to })) {
        return
      }
      const connParam = {
        source: from,
        target: to,
        paintStyle: {
          strokeWidth: 3,
          stroke: getComputedStyle(document.documentElement).getPropertyValue('--q-cor1')
        }
      }
      this.jsPlumb.connect(connParam, this.jsplumbConnectOptions)
      if (oldTo) {
        const conn = this.jsPlumb.getConnections({
          source: from,
          target: oldTo
        })[0]
        this.jsPlumb.deleteConnection(conn)
      }
      this.clickNode(from)
    },
    handleConfigureNode(nodeId) {
      // Primeiro, garante que o painel lateral esteja aberto
      this.rightPanelVisible = true

      // Aguarda o painel abrir e a transição completar
      setTimeout(() => {
        // Depois simula o click no node para carregar as configurações
        this.clickNode(nodeId)

        // Inicializa o formulário do node
        this.$nextTick(() => {
          if (this.$refs.nodeForm) {
            this.$refs.nodeForm.nodeInit(this.data, nodeId)
          }
        })
      }, 300) // Tempo suficiente para a animação do painel completar
    },
    saveFlow () {
      const data = {
        ...this.cDataFlow.flow,
        flow: this.data
      }
      UpdateChatFlow(data)
        .then(res => {
          this.$notificarSucesso(this.$t('ccFlowBuilder.fluxosalvo'))
        })
        .catch(error => {
          console.error(error)
          this.$notificarErro(error)
        })
    },
    jsPlumpConsist (evt) {
      const from = evt.sourceId
      const to = evt.targetId
      if (from === to) {
        this.$q.notify({
          type: 'negative',
          progress: true,
          position: 'top',
          timeout: 2500,
          message: this.$t('ccFlowBuilder.erroconectarsimesmo'),
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        return false
      }
      this.$notificarSucesso(this.$t('ccFlowBuilder.conexaorealizada'))
      return true
    },
    jsPlumbInit () {
      this.jsPlumb.ready(() => {
        this.jsPlumb.importDefaults(this.jsplumbSetting)
        this.jsPlumb.setSuspendDrawing(false, true)
        this.loadEasyFlow()
        this.jsPlumb.bind('click', (conn, originalEvent) => {
          this.activeElement.sourceId = conn.sourceId
          this.activeElement.targetId = conn.targetId
          this.$refs.nodeForm.lineInit({
            from: conn.sourceId,
            to: conn.targetId,
            label: conn.getLabel()
          })
        })
        this.jsPlumb.bind('connection', (evt) => {
          if (!this.jsPlumpConsist(evt)) {
            return
          }
          const from = evt.source.id
          const to = evt.target.id
          if (this.loadEasyFlowFinish) {
            this.data.lineList.push({ from: from, to: to, label: 'Valor' })
            const label = null
            this.$refs.nodeForm.lineInit({
              from,
              to,
              label
            })
            this.setLineLabel(from, to, label)
          }
        })

        this.jsPlumb.bind('connectionDetached', (evt) => {
          this.deleteLine(evt.sourceId, evt.targetId)
        })

        this.jsPlumb.bind('connectionMoved', (evt) => {
          this.changeLine(evt.originalSourceId, evt.originalTargetId)
        })

        this.jsPlumb.bind('contextmenu', (evt) => {
          console.log('contextmenu', evt)
        })

        this.jsPlumb.bind('beforeDrop', (evt) => {
          return this.jsPlumpConsist(evt)
        })

        this.jsPlumb.bind('beforeDetach', (evt) => {
          console.log('beforeDetach', evt)
        })
        this.jsPlumb.setContainer(this.$refs.flowContent)
      })
    },

    loadEasyFlow () {
      for (var i = 0; i < this.data.nodeList.length; i++) {
        const node = this.data.nodeList[i]
        this.jsPlumb.makeSource(node.id, merge(this.jsplumbSourceOptions, {}))
        this.jsPlumb.makeTarget(node.id, this.jsplumbTargetOptions)
        if (!node.viewOnly) {
          this.jsPlumb.draggable(node.id, {
            containment: 'parent',
            stop: function (el) {
              console.log('arraste para o final: ', el)
            }
          })
        }
      }
      for (let i = 0; i < this.data.lineList.length; i++) {
        const line = this.data.lineList[i]
        var connParam = {
          source: line.from,
          target: line.to,
          label: line.label ? line.label : '',
          connector: line.connector ? line.connector : '',
          anchors: line.anchors ? line.anchors : undefined,
          paintStyle: {
            strokeWidth: 3,
            stroke: getComputedStyle(document.documentElement).getPropertyValue('--q-cor1')
          }
        }
        this.jsPlumb.connect(connParam, this.jsplumbConnectOptions)
      }
      this.$nextTick(function () {
        this.loadEasyFlowFinish = true
      })
    },

    setLineLabel (from, to, label) {
      var conn = this.jsPlumb.getConnections({
        source: from,
        target: to
      })[0]
      if (!label || label === '') {
        conn.removeClass('flowLabel')
        conn.addClass('emptyFlowLabel')
      } else {
        conn.addClass('flowLabel')
      }
      conn.setLabel({
        label: label
      })

      conn.setPaintStyle({
        strokeWidth: 3,
        stroke: getComputedStyle(document.documentElement).getPropertyValue('--q-cor1')
      })

      this.data.lineList.forEach(function (line) {
        if (line.from == from && line.to == to) {
          line.label = label
        }
      })
    },
    togglePanel() {
      this.rightPanelVisible = !this.rightPanelVisible
      this.$nextTick(() => {
        this.repaintEverything()
      })
    },
    deleteElement () {
      if (this.activeElement.id === 'nodeC') return
      if (this.activeElement.type === 'node') {
        this.deleteNode(this.activeElement)
      } else if (this.activeElement.type === 'line') {
        this.$q.dialog({
          title: this.$t('general.Attention'),
          message: this.$t('ccFlowBuilder.deletarlinha'),
          cancel: {
            label: this.$t('general.no'),
            color: 'primary',
            push: true
          },
          ok: {
            label: this.$t('general.yes'),
            color: 'negative',
            push: true
          },
          persistent: true
        }).onOk(async () => {
          var conn = this.jsPlumb.getConnections({
            source: this.activeElement.sourceId,
            target: this.activeElement.targetId
          })[0]
          this.jsPlumb.deleteConnection(conn)
        })
      }
    },
    handleWheel(event) {
      if (event.ctrlKey) {
        // Previne o comportamento padrão do navegador de zoom
        event.preventDefault()

        // Ajusta a sensibilidade do zoom
        const zoomSensitivity = 0.001
        const zoomDelta = -event.deltaY * zoomSensitivity

        // Calcula o novo zoom
        let newZoom = this.zoom + zoomDelta

        // Limita o zoom entre 0.2 e 1.5
        newZoom = Math.min(Math.max(newZoom, 0.2), 1.5)

        // Atualiza o zoom apenas se mudou
        if (newZoom !== this.zoom) {
          this.zoom = newZoom
          const content = this.$refs.flowContent

          // Aplica a transformação
          content.style.transform = `scale(${this.zoom})`

          // Atualiza o jsPlumb
          this.jsPlumb.setZoom(this.zoom)
          this.jsPlumb.repaintEverything()
        }
      }
    },
    deleteLine (from, to) {
      // Se temos um ID de origem e destino
      if (from && to) {
        try {
          // Obter todas as conexões entre origem e destino
          const connections = this.jsPlumb.getConnections({
            source: from,
            target: to
          })

          // Verificar se há conexões
          if (connections && connections.length > 0) {
            // Remover cada conexão individualmente
            connections.forEach(conn => {
              try {
                // Suspender desenho antes de deletar
                this.jsPlumb.setSuspendDrawing(true)
                this.jsPlumb.deleteConnection(conn, { fireEvent: false })
              } catch (err) {
                console.error('Erro ao deletar conexão individual:', err)
              }
            })

            // Reativar desenho
            this.jsPlumb.setSuspendDrawing(false, true)

            // Atualiza o array de dados
            this.data.lineList = this.data.lineList.filter(function (line) {
              return !(line.from === from && line.to === to)
            })
          }

          // Repintar tudo após um breve delay para garantir atualizações
          this.$nextTick(() => {
            setTimeout(() => {
              this.jsPlumb.repaintEverything()
            }, 50)
          })
        } catch (error) {
          console.error('Erro ao deletar linha:', error)
          // Tentar forçar uma repintura mesmo em caso de erro
          this.jsPlumb.repaintEverything()
        }
      }
    },
    changeLine (oldFrom, oldTo) {
      this.deleteLine(oldFrom, oldTo)
    },
    changeNodeSite (data) {
      for (var i = 0; i < this.data.nodeList.length; i++) {
        const node = this.data.nodeList[i]
        if (node.id === data.id) {
          node.left = data.left
          node.top = data.top
        }
      }
    },
    addNode (evt, nodeMenu, mousePosition) {
      const efContainer = this.$refs.efContainer
      const containerRect = efContainer.getBoundingClientRect()

      // Configurações de tamanho do nó e espaçamento
      const nodeWidth = 170 // Largura aproximada do nó
      const nodeHeight = 32 // Altura aproximada do nó
      const minSpacing = 20 // Espaçamento mínimo entre nós

      // Função para verificar se há sobreposição
      const hasOverlap = (x, y, existingNodes) => {
        return existingNodes.some(node => {
          const nodeLeft = parseInt(node.left)
          const nodeTop = parseInt(node.top)

          return !(x + nodeWidth + minSpacing < nodeLeft ||
            x > nodeLeft + nodeWidth + minSpacing ||
            y + nodeHeight + minSpacing < nodeTop ||
            y > nodeTop + nodeHeight + minSpacing)
        })
      }

      // Função para encontrar posição livre em espiral
      const findFreePosition = () => {
        const centerX = efContainer.scrollLeft + (containerRect.width / 2)
        const centerY = efContainer.scrollTop + (containerRect.height / 2)

        let angle = 0
        let radius = 0
        const radiusIncrement = 50 // Distância entre as "voltas" da espiral
        const angleIncrement = 0.5 // Incremento do ângulo em radianos

        while (radius < Math.max(containerRect.width, containerRect.height)) {
          // Calcula nova posição na espiral
          const x = centerX + radius * Math.cos(angle)
          const y = centerY + radius * Math.sin(angle)

          // Ajusta pela escala do zoom
          const scaledX = x / this.zoom
          const scaledY = y / this.zoom

          // Verifica se a posição está livre
          if (!hasOverlap(scaledX, scaledY, this.data.nodeList)) {
            return { left: scaledX, top: scaledY }
          }

          // Incrementa a espiral
          angle += angleIncrement
          radius += radiusIncrement * angleIncrement / (2 * Math.PI)
        }

        // Fallback: retorna posição com offset aleatório se não encontrar posição livre
        return {
          left: centerX / this.zoom + Math.random() * 100,
          top: centerY / this.zoom + Math.random() * 100
        }
      }

      // Encontra posição livre
      const position = findFreePosition()

      // Cria o novo nó
      const nodeId = this.getUUID()
      const nodeName = this.getUniqueNodeName(nodeMenu.name)

      const node = {
        id: nodeId,
        name: nodeName,
        type: nodeMenu.type,
        left: `${position.left}px`,
        top: `${position.top}px`,
        ico: nodeMenu.ico,
        state: 'success',
        actions: nodeMenu?.actions,
        conditions: nodeMenu?.conditions,
        interactions: nodeMenu?.interactions
      }

      // Adiciona o nó
      this.data.nodeList.push(node)

      // Configuração do jsPlumb
      this.$nextTick(() => {
        this.jsPlumb.makeSource(nodeId, this.jsplumbSourceOptions)
        this.jsPlumb.makeTarget(nodeId, this.jsplumbTargetOptions)
        this.jsPlumb.draggable(nodeId, {
          containment: 'parent',
          stop: (el) => {
            console.log('Arraste finalizado:', el)
          }
        })

        // Scroll suave até o novo nó
        this.scrollToNode(position.left, position.top)
      })
    },
    scrollToNode(left, top) {
      const efContainer = this.$refs.efContainer

      efContainer.scrollTo({
        left: left * this.zoom - efContainer.clientWidth / 2,
        top: top * this.zoom - efContainer.clientHeight / 2,
        behavior: 'smooth'
      })
    },
    snapToGrid(value, gridSize = 20) {
      return Math.round(value / gridSize) * gridSize
    },
    getUniqueNodeName(baseName) {
      let nodeName = baseName
      let index = 1

      while (this.data.nodeList.some(node => node.name === nodeName)) {
        nodeName = `${baseName}${index}`
        index++
      }

      return nodeName
    },
    forceInitialZoom() {
      const content = this.$refs.flowContent
      this.zoom = 1.0

      content.style.transform = `scale(${this.zoom})`

      setTimeout(() => {
        this.jsPlumb.setZoom(this.zoom)
        this.jsPlumb.repaintEverything()
      }, 100)
    },
    deleteNode (node) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('ccFlowBuilder.deletaretapa', { name: node.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(async () => {
        this.data.nodeList = this.data.nodeList.filter(n => n.id !== node.id)
        this.$nextTick(function () {
          this.jsPlumb.removeAllEndpoints(node.id)
        })
      })

      return true
    },

    clickNode (nodeId) {
      const node = this.data.nodeList.find(n => n.id === nodeId)
      this.activeElement = node
      this.$refs.nodeForm.nodeInit(this.data, nodeId)
    },

    hasLine (from, to) {
      for (var i = 0; i < this.data.lineList.length; i++) {
        var line = this.data.lineList[i]
        if (line.from === from && line.to === to) {
          return true
        }
      }
      return false
    },
    hashOppositeLine (from, to) {
      return this.hasLine(to, from)
    },
    nodeRightMenu (nodeId, evt) {
      this.menu.show = true
      this.menu.curNodeId = nodeId
      this.menu.left = evt.x + 'px'
      this.menu.top = evt.y + 'px'
    },
    repaintEverything () {
      this.jsPlumb.repaint()
    },
    dataInfo () {
      this.flowInfoVisible = true
      this.$nextTick(function () {
        this.$refs.flowInfo.init()
      })
    },
    dataReload (data) {
      this.easyFlowVisible = false
      this.data.nodeList = []
      this.data.lineList = []
      this.$nextTick(() => {
        data = cloneDeep(data)
        this.easyFlowVisible = true
        this.data = data
        this.$nextTick(() => {
          // eslint-disable-next-line no-undef
          this.jsPlumb = jsPlumb.getInstance()
          this.$nextTick(() => {
            this.jsPlumbInit()
            this.forceInitialZoom()
          })
        })
      })
    },
    zoomAdd() {
      if (this.zoom >= 1.5) return

      this.zoom = this.zoom + 0.1
      const content = this.$refs.flowContent

      // Aplica transform apenas ao conteúdo
      content.style.transform = `scale(${this.zoom})`

      // Atualiza o jsPlumb
      this.jsPlumb.setZoom(this.zoom)
      this.jsPlumb.repaintEverything()
    },

    zoomSub() {
      if (this.zoom <= 0.2) return

      this.zoom = this.zoom - 0.1
      const content = this.$refs.flowContent

      // Aplica transform apenas ao conteúdo
      content.style.transform = `scale(${this.zoom})`

      // Atualiza o jsPlumb
      this.jsPlumb.setZoom(this.zoom)
      this.jsPlumb.repaintEverything()
    },
    downloadData () {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('ccFlowBuilder.confirmadownload'),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(async () => {
        var datastr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(this.data, null, '\t'))
        var downloadAnchorNode = document.createElement('a')
        downloadAnchorNode.setAttribute('href', datastr)
        downloadAnchorNode.setAttribute('download', 'data.json')
        downloadAnchorNode.click()
        downloadAnchorNode.remove()
        this.$notificarSucesso(this.$t('ccFlowBuilder.download'))
      })
    },
    openHelp () {
      this.flowHelpVisible = true
      this.$nextTick(function () {
        this.$refs.flowHelp.init()
      })
    }
  },
  mounted () {
    this.loadColors()
    // eslint-disable-next-line no-undef
    this.jsPlumb = jsPlumb.getInstance()
    window.addEventListener('wheel', this.handleWheel, { passive: false })
    this.$nextTick(() => {
      this.dataReload(this.cDataFlow.flow.flow)
    })
  },
  beforeDestroy() {
    window.removeEventListener('wheel', this.handleWheel)
  }
}
</script>
<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

.container
  transform-origin: 0 0
  position: relative
  width: 100%
  height: 100%
  overflow: auto

  &::-webkit-scrollbar
    width: 8px
    height: 8px

  &::-webkit-scrollbar-track
    background: transparent

  &::-webkit-scrollbar-thumb
    background: rgba(0, 0, 0, 0.2)
    border-radius: 4px

  // Previne o zoom do navegador
  touch-action: none

.toggle-panel-btn
  position: absolute
  right: 410px
  top: 50%
  transform: translateY(-50%)
  z-index: 1000

.slide-right-enter-active,
.slide-right-leave-active
  transition: all 0.3s ease

.slide-right-enter,
.slide-right-leave-to
  transform: translateX(400px)
  opacity: 0

</style>
