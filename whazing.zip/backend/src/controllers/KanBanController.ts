// --- START OF FILE KanBanController.ts ---

import type { Request, Response } from "express";
import * as Yup from "yup";

import AppError from "../errors/AppError";
import CreateKanbanService from "../services/KanbanServices/CreateKanbanService";
import ListKanbanService from "../services/KanbanServices/ListKanbanService";
import DeleteKanbanService from "../services/KanbanServices/DeleteKanbanService";
import UpdateKanbanService from "../services/KanbanServices/UpdateKanbanService";
import UpdateKanbanIdService from "../services/KanbanServices/UpdateKanbanIdService";
import UpdateKanbanIdService2 from "../services/KanbanServices/UpdateKanbanIdService2";
import { logger } from "../utils/logger";
import ContactsKanbanService from "../services/StatisticsServices/ContactsKanbanService"; // Corrected path assuming stats
import ListSettingsService from "../services/SettingServices/ListSettingsService";
import UpdateKanbanUserService from "../services/KanbanServices/UpdateKanbanUserService";
import ShowKanbanService from "../services/KanbanServices/ShowKanbanService";
import ShowKanbanServiceGlobal from "../services/KanbanServices/ShowKanbanServiceGlobal";

interface StoreBody {
  name: string;
  // Add other properties if needed
}

interface UpdateBody {
  name: string;
  isActive: boolean;
  // Add other properties if needed
}

interface UpdateKanbanIdBody {
  kanbanId: number | string;
}

interface UpdateUserBody {
  kanbanOrder: any[]; // Should be more specific, like number[] or { id: number; order: number }[]
}

interface IndexQuery {
  isActive?: string | boolean;
  userIdAdmin?: string;
  showAll?: string | boolean;
}

interface ShowParams {
  userId?: string; // Assuming userId might be passed in params for show
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const settings = await ListSettingsService(tenantId);
  const kanbanUserEnabled =
    settings?.find(s => s.key === "kanbanUser")?.value === "enabled"
      ? "S"
      : "N";
  const kanbanGlobalEnabled =
    settings?.find(s => s.key === "kanbanGlobal")?.value === "enabled"
      ? "S"
      : "N";

  // Permission check based on settings
  if (kanbanUserEnabled === "N") {
    if (req.user.profile !== "admin" && req.user.profile !== "supervisor") {
      throw new AppError("ERR_NO_PERMISSION", 403);
    }
  }
  if (kanbanGlobalEnabled === "S") {
    if (req.user.profile !== "admin" && req.user.profile !== "supervisor") {
      throw new AppError("ERR_NO_PERMISSION", 403);
    }
  }

  const kanbanData = { ...req.body } as StoreBody;
  kanbanData.userId = req.user.id; // Add userId from authenticated user
  kanbanData.tenantId = tenantId; // Add tenantId

  const schema = Yup.object().shape({
    name: Yup.string().required(),
    userId: Yup.number().required(),
    tenantId: Yup.number().required()
  });

  try {
    await schema.validate(kanbanData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  try {
    const kanban = await CreateKanbanService(kanbanData);
    return res.status(201).json(kanban);
  } catch (error: any) {
    logger.error(error);
    return res.status(500).send(error.message); // Use send for plain text error
  }
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const { isActive, userIdAdmin, showAll } = req.query as IndexQuery;
  let { id: userId } = req.user; // Default to logged-in user

  // Allow admin/supervisor to view for other users if userIdAdmin is provided
  if (req.user.profile === "admin" || req.user.profile === "supervisor") {
    if (typeof userIdAdmin === "string" && userIdAdmin.trim() !== "") {
      userId = Number(userIdAdmin); // Use the provided admin ID
    }
  }

  try {
    const kanbans = await ListKanbanService({
      tenantId,
      userId,
      showAll:
        typeof showAll === "string" ? showAll === "true" : Boolean(showAll), // Convert to boolean
      isActive: isActive ? String(isActive).toLowerCase() === "true" : false // Convert isActive to boolean
    });
    return res.status(200).json(kanbans);
  } catch (error: any) {
    logger.error(error);
    return res.status(500).send(error.message);
  }
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const settings = await ListSettingsService(tenantId);
  const kanbanUserEnabled =
    settings?.find(s => s.key === "kanbanUser")?.value === "enabled"
      ? "S"
      : "N";
  const kanbanGlobalEnabled =
    settings?.find(s => s.key === "kanbanGlobal")?.value === "enabled"
      ? "S"
      : "N";

  // Permission Check
  if (kanbanUserEnabled === "N") {
    if (req.user.profile !== "admin" && req.user.profile !== "supervisor") {
      throw new AppError("ERR_NO_PERMISSION", 403);
    }
  }
  if (kanbanGlobalEnabled === "S") {
    if (req.user.profile !== "admin" && req.user.profile !== "supervisor") {
      throw new AppError("ERR_NO_PERMISSION", 403);
    }
  }

  const kanbanData = { ...req.body } as UpdateBody;
  kanbanData.userId = req.user.id; // Ensure userId is set
  kanbanData.tenantId = tenantId; // Ensure tenantId is set

  const schema = Yup.object().shape({
    name: Yup.string().required(),
    isActive: Yup.boolean().required(),
    userId: Yup.number().required()
    // tenantId is implicitly handled
  });

  try {
    await schema.validate(kanbanData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  try {
    const { kanbanId } = req.params;
    const updatedKanban = await UpdateKanbanService({
      kanbanData: kanbanData,
      kanbanId: Number(kanbanId)
    });
    return res.status(200).json(updatedKanban);
  } catch (error: any) {
    logger.error(error);
    return res.status(500).send(error.message);
  }
};

export const list = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, profile } = req.user;
  let { id: userId } = req.user;
  const { userIdAdmin } = req.query as IndexQuery; // Reuse IndexQuery

  // Allow admin/supervisor to override userId
  if (profile === "admin" || profile === "supervisor") {
    if (typeof userIdAdmin === "string" && userIdAdmin.trim() !== "") {
      userId = Number(userIdAdmin);
    }
  }

  try {
    const contactsKanban = await ContactsKanbanService({
      tenantId,
      userId, // Use potentially overridden userId
      profile // Pass profile for potential use in service
    });
    return res.status(200).json(contactsKanban);
  } catch (error: any) {
    logger.error(error);
    // Check if it's a known AppError or a generic server error
    if (error instanceof AppError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: "Internal server error" }); // Default error
  }
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const settings = await ListSettingsService(tenantId);
  const kanbanUserEnabled =
    settings?.find(s => s.key === "kanbanUser")?.value === "enabled"
      ? "S"
      : "N";
  const kanbanGlobalEnabled =
    settings?.find(s => s.key === "kanbanGlobal")?.value === "enabled"
      ? "S"
      : "N";

  // Permission Check
  if (kanbanUserEnabled === "N") {
    if (req.user.profile !== "admin" && req.user.profile !== "supervisor") {
      throw new AppError("ERR_NO_PERMISSION", 403);
    }
  }
  if (kanbanGlobalEnabled === "S") {
    if (req.user.profile !== "admin" && req.user.profile !== "supervisor") {
      throw new AppError("ERR_NO_PERMISSION", 403);
    }
  }

  const { kanbanId } = req.params;

  try {
    await DeleteKanbanService({ id: Number(kanbanId), tenantId });
    return res.status(200).json({ message: "Kanban eliminado" }); // Traducido
  } catch (error: any) {
    logger.error(error);
    return res.status(500).send(error.message);
  }
};

export const updateKanbanId = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const { id: contactId } = req.params; // Assuming 'id' in route is contactId
  const { kanbanId } = req.body as UpdateKanbanIdBody;

  const schema = Yup.object().shape({
    kanbanId: Yup.number().required()
  });

  try {
    await schema.validate({ kanbanId }); // Validate only the relevant part
  } catch (err: any) {
    throw new AppError(err.message);
  }

  try {
    const updatedContact = await UpdateKanbanIdService({
      contactId: Number(contactId),
      kanbanId: Number(kanbanId),
      tenantId: Number(tenantId) // Ensure tenantId is passed as number
    });
    return res.status(200).json(updatedContact);
  } catch (error: any) {
    logger.error(error);
    return res.status(500).send(error.message);
  }
};

export const updateKanbanId2 = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId } = req.user;
  const { id: contactId } = req.params; // Assuming 'id' in route is contactId
  const { kanbanId } = req.body as UpdateKanbanIdBody;

  const schema = Yup.object().shape({
    kanbanId: Yup.number().required()
  });

  try {
    await schema.validate({ kanbanId });
  } catch (err: any) {
    throw new AppError(err.message);
  }

  try {
    const updatedContact = await UpdateKanbanIdService2({
      contactId: Number(contactId),
      kanbanId: Number(kanbanId),
      tenantId: Number(tenantId),
      userId: Number(userId) // Pass the logged-in user's ID
    });
    return res.status(200).json(updatedContact);
  } catch (error: any) {
    logger.error(error);
    return res.status(500).send(error.message);
  }
};

export const updateuser = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { kanbanOrder } = req.body as UpdateUserBody;
    const userId = Number(req.user.id);
    const tenantId = Number(req.user.tenantId);

    if (!Array.isArray(kanbanOrder)) {
      // Providing a more specific error message
      return res.status(400).json({ error: "kanbanOrder debe ser un array" }); // Traducido
    }

    const result = await UpdateKanbanUserService({
      userId,
      tenantId,
      kanbanOrder
    });

    return res.status(200).json(result);
  } catch (error: any) {
    // Differentiate between AppError and other errors
    if (error instanceof AppError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    // Generic error for unexpected issues
    logger.error(error); // Log the actual error for debugging
    return res.status(500).json({ error: "Internal server error" });
  }
};

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { userId: paramUserId } = req.params as ShowParams; // Get userId from route params if available
  const { tenantId, id: loggedInUserId } = req.user; // Get logged-in user's ID and tenantId

  const settings = await ListSettingsService(tenantId);
  const kanbanGlobalEnabled =
    settings?.find(s => s.key === "kanbanGlobal")?.value === "enabled"
      ? "S"
      : "N";

  let kanbanData;

  // Determine which service to call based on global setting
  if (kanbanGlobalEnabled === "S") {
    kanbanData = await ShowKanbanServiceGlobal(tenantId);
  } else {
    // Use the userId from params if provided, otherwise use the logged-in user's ID
    const targetUserId = paramUserId ? Number(paramUserId) : loggedInUserId;
    kanbanData = await ShowKanbanService(targetUserId, tenantId);
  }

  return res.status(200).json(kanbanData);
};

// --- END OF FILE KanBanController.ts ---
