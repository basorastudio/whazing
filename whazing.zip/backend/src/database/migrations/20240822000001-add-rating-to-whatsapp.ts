import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Check if the 'rating' column already exists before adding
    const tableInfo = await queryInterface.describeTable('Whatsapps');
    if (!tableInfo || !tableInfo['rating']) {
      // Add the 'rating' column to the 'Whatsapps' table
      // Likely a flag to enable/disable the rating feature for this WhatsApp connection.
      await queryInterface.addColumn(
        'Whatsapps', // Table name
        'rating',    // New column name
        {
          type: DataTypes.BOOLEAN,
          defaultValue: false, // Default to false
          allowNull: true,    // Allow null
        }
      );
    }
    // If the column exists, do nothing (idempotency)
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'rating' column from the 'Whatsapps' table
    // Consider checking if it exists before removing, though removeColumn usually handles this.
    await queryInterface.removeColumn(
      'Whatsapps', // Table name
      'rating'     // Column name to remove
    );
  }
};

export = migration;