// --- START OF FILE 20231018160343-create_table_read_group_message.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'ReadMessageGroups'; // 'ReadMessag' + 'eGroups' -> Pluralized standard name
        const tableDefinition = {
            id: {
                type: DataTypes.INTEGER, // Original INTEGER
                primaryKey: true,
                autoIncrement: true, // 'autoIncrem' + 'ent'
                allowNull: false
            },
            internalMessageId: { // Original column name
                type: DataTypes.BIGINT, // Original BIGINT
                references: {
                    model: 'InternalMessages', // 'InternalMe' + 'ssage' -> Pluralized
                    key: 'id'
                },
                onUpdate: 'CASCADE', // Original 'CASCADE'
                onDelete: 'SET NULL' // Original 'SET NULL'
                 // allowNull defaults to true, matching onDelete SET NULL
            },
            userGroupId: { // Original column name
                type: DataTypes.INTEGER, // Original INTEGER
                references: {
                    model: 'UsersGroups', // 'UsersGroup' + 's' -> Pluralized standard name
                    key: 'id'
                },
                onUpdate: 'CASCADE', // Original 'CASCADE'
                onDelete: 'CASCADE', // Original 'CASCADE'
                allowNull: false // Changed ![] to false
            },
            createdAt: {
                type: DataTypes.DATE,
                allowNull: false
            },
            updatedAt: {
                type: DataTypes.DATE,
                allowNull: false
            }
        };
        await queryInterface.createTable(tableName, tableDefinition);

        // Optional: Add unique constraint on (internalMessageId, userGroupId)
        await queryInterface.addConstraint(tableName, {
           fields: ['internalMessageId', 'userGroupId'],
           type: 'unique',
           name: 'unique_read_message_user_group_constraint' // Explicit constraint name
        });
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'ReadMessageGroups'; // 'ReadMessag' + 'eGroups' -> Pluralized standard name
         // Remove constraint first
         try {
           await queryInterface.removeConstraint(tableName, 'unique_read_message_user_group_constraint');
        } catch (error) {
           console.log("Constraint 'unique_read_message_user_group_constraint' not found or already removed.");
        }
        await queryInterface.dropTable(tableName);
    }
};

export default migration;
// --- END OF FILE 20231018160343-create_table_read_group_message.ts ---