import request from 'src/service/request'

// Suscripciones de Empresas
export function crearSuscripcion (data) {
  return request({
    url: '/admin/subscriptions/',
    method: 'post',
    data
  })
}

export function listarSuscripciones () {
  return request({
    url: '/admin/subscriptions/',
    method: 'get'
  })
}

export function editarSuscripcion (data) {
  return request({
    url: `/admin/subscriptions/${data.id}/`,
    method: 'put',
    data
  })
}

export function eliminarSuscripcion (data) {
  return request({
    url: `/admin/subscriptions/${data.id}/`,
    method: 'delete',
    data
  })
}

// Cuentas de Usuarios
export function crearUsuario (data) {
  return request({
    url: '/admin/users/',
    method: 'post',
    data
  })
}

export function listarUsuarios () {
  return request({
    url: '/admin/users/',
    method: 'get'
  })
}

export function editarUsuario (data) {
  return request({
    url: `/admin/users/${data.id}/`,
    method: 'put',
    data
  })
}

export function eliminarUsuario (data) {
  return request({
    url: `/admin/users/${data.id}/`,
    method: 'delete',
    data
  })
}

// Planes
export function crearPlan (data) {
  return request({
    url: '/admin/plans/',
    method: 'post',
    data
  })
}

export function listarPlanes () {
  return request({
    url: '/admin/plans/',
    method: 'get'
  })
}

export function editarPlan (data) {
  return request({
    url: `/admin/plans/${data.id}/`,
    method: 'put',
    data
  })
}

export function eliminarPlan (data) {
  return request({
    url: `/admin/plans/${data.id}/`,
    method: 'delete',
    data
  })
}

// Token de Autenticación
export function generarTokenAdmin () {
  return request({
    url: '/admin/auth/token/',
    method: 'post'
  })
}

export function renovarTokenAdmin (data) {
  return request({
    url: '/admin/auth/renew-token/',
    method: 'post',
    data
  })
}