import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Change the 'body' column in 'Messages' to allow NULL values
    await queryInterface.changeColumn(
      "Messages", // Table name
      "body", // Column name to change
      {
        type: DataTypes.TEXT, // Keep type as TEXT
        allowNull: true // Allow null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Revert the 'body' column in 'Messages' to NOT allow NULL values
    // Warning: This might fail if NULLs exist. Handle existing NULLs first in production.
    await queryInterface.changeColumn(
      "Messages", // Table name
      "body", // Column name to change
      {
        type: DataTypes.TEXT, // Keep type as TEXT
        allowNull: false // Disallow null
      }
    );
  }
};

export = migration;
