// --- START OF FILE 20231009221940-add_columns_cnpj_to_tenant.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Tenants";
    const columnName = "cnpj"; // Original column name

    const tableDescription = await queryInterface.describeTable(tableName); // describeTa' + 'ble'

    if (!tableDescription || !tableDescription[columnName]) {
      const attributes = {
        type: DataTypes.STRING,
        allowNull: false // Changed ![] to false
        // Assuming CNPJ should be unique, add unique: true if needed
        // unique: true
      };
      await queryInterface.addColumn(tableName, columnName, attributes);
    } else {
      console.log(
        `La columna ${columnName} ya existe en la tabla ${tableName}. Saltando adición.`
      );
    }
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Tenants";
    const columnName = "cnpj";

    const tableDescription = await queryInterface.describeTable(tableName);

    if (tableDescription && tableDescription[columnName]) {
      await queryInterface.removeColumn(tableName, columnName);
    } else {
      console.log(
        `La columna ${columnName} no existe en la tabla ${tableName}. Saltando eliminación.`
      );
    }
  }
};

export default migration;

// --- END OF FILE 20231009221940-add_columns_cnpj_to_tenant.ts ---
