import path from "path";
import multer, { StorageEngine } from "multer";
import { Request } from "express"; // No usado directamente, pero Multer lo puede necesitar internamente

/**
 * Configuración para subir archivos privados usando Multer.
 * Los archivos se guardan en una carpeta 'private' (fuera del acceso público web).
 * El nombre del archivo se genera usando un timestamp y la extensión original.
 */

// Resuelve la ruta a la carpeta privada relativa al directorio actual
const privateFolder = path.resolve(__dirname, "..", "..", "private");

interface PrivateUploadConfig {
  directory: string;
  storage: StorageEngine;
}

const privateFilesConfig: PrivateUploadConfig = {
  directory: privateFolder,
  storage: multer.diskStorage({
    destination: privateFolder,
    filename(
      req: Request,
      file: Express.Multer.File,
      callback: (error: Error | null, filename: string) => void
    ) {
      // Obtiene la extensión del archivo original
      const fileExtension = path.extname(file.originalname);

      // Genera un timestamp numérico (milisegundos desde la época)
      const timestamp = new Date().getTime();

      // Crea el nombre final del archivo: timestamp + extensión
      const finalFilename = `${timestamp}${fileExtension}`;

      return callback(null, finalFilename);
    }
  })
  // Podrías añadir fileFilter aquí si necesitas restringir tipos de archivo o tamaños
};

export default privateFilesConfig;
