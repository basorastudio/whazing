import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add webhook related columns to 'Whatsapps' table
    const columnsToAdd = [
      {
        name: "webhookmensagemsaida",
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false
      },
      {
        name: "urlwebhook",
        type: DataTypes.TEXT,
        defaultValue: null,
        allowNull: true
      },
      {
        name: "webhookmensagemsentrada",
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false
      },
      {
        name: "webhooknovoticket",
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false
      }
    ];

    for (const col of columnsToAdd) {
      await queryInterface.addColumn("Whatsapps", col.name, {
        type: col.type,
        defaultValue: col.defaultValue,
        allowNull: col.allowNull
      });
    }
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added webhook columns
    await queryInterface.removeColumn("Whatsapps", "webhooknovoticket");
    await queryInterface.removeColumn("Whatsapps", "webhookmensagemsentrada");
    await queryInterface.removeColumn("Whatsapps", "urlwebhook");
    await queryInterface.removeColumn("Whatsapps", "webhookmensagemsaida");
  }
};

export = migration;
