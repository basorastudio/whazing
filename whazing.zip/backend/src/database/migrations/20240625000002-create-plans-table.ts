// --- START OF FILE 20240625000002-create-plans-table.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Plans";
    const tableDefinition = {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
      },
      maxUsers: {
        type: DataTypes.INTEGER,
        defaultValue: 0
      },
      maxConnections: {
        // Assuming 'maxConnect' + 'ions' -> 'maxConnections'
        type: DataTypes.INTEGER,
        defaultValue: 0
      },
      createdAt: {
        // Sequelize automatically adds this if timestamps: true, but defining explicitly
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        // Sequelize automatically adds this if timestamps: true, but defining explicitly
        type: DataTypes.DATE,
        allowNull: false
      },
      value: {
        // Assuming original intent of 'value' column was for price/cost
        type: DataTypes.FLOAT, // Changed from BOOLEAN based on context 'value'
        allowNull: false, // Changed !![] to true, assuming value is required
        defaultValue: 0.0 // Assuming default value 0
      },
      isPublic: {
        type: DataTypes.BOOLEAN,
        defaultValue: true, // Changed !![] to true
        allowNull: false
      }
    };
    await queryInterface.createTable(tableName, tableDefinition);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Plans";
    await queryInterface.dropTable(tableName);
  }
};

export default migration;

// --- END OF FILE 20240625000002-create-plans-table.ts ---
