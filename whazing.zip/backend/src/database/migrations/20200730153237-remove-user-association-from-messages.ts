import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna userId de la tabla Messages
    return queryInterface.removeColumn('Messages', 'userId');
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Vuelve a añadir la columna userId (reversión de la migración)
    return queryInterface.addColumn('Messages', 'userId', {
      type: DataTypes.INTEGER,
      references: {
        model: 'Users',
        key: 'id'
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL', // O la política original si era diferente
      allowNull: true // Asumiendo que podía ser nulo
    });
  }
};