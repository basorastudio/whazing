// --- START OF FILE 20230425153434-create-contacts_number_tenantId.ts ---

import { QueryInterface, Sequelize, QueryTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const indexName = "Contacts_number_tenantId";
    const tableName = "Contacts";
    const indexFields = ["number", "tenantId"];

    // Using Sequelize helper (preferred)
    await queryInterface.addIndex(tableName, indexFields, {
      name: indexName,
      unique: true,
      // PostgreSQL specific constraint for unique nullable columns
      where: {
        tenantId: { [Sequelize.Op.ne]: null } // Ensure tenantId is not null for uniqueness check
      }
      // Note: 'where' clause might not be supported/needed in all dialects
    });

    /* // Raw query approach (Alternative, might need dialect adjustments)
        const dialect = queryInterface.sequelize.getDialect();
        const createIndexQuery = dialect === 'postgres'
            ? `CREATE UNIQUE INDEX "${indexName}" ON "Contacts" (number, "tenantId") WHERE "tenantId" IS NOT NULL`
            : `CREATE UNIQUE INDEX "${indexName}" ON "Contacts" (number, "tenantId")`; // Adjust for other dialects if needed

        try {
            await queryInterface.sequelize.query(createIndexQuery, { type: QueryTypes.RAW });
        } catch (error) {
            console.error(`Error creating index ${indexName}:`, error);
            // Optional: Check for specific errors like 'index already exists' and handle gracefully
        } */
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const indexName = "Contacts_number_tenantId";
    const tableName = "Contacts";

    // Using Sequelize helper (preferred)
    await queryInterface.removeIndex(tableName, indexName);

    /* // Raw query approach (Alternative)
        const dropIndexQuery = `DROP INDEX "${indexName}"`;
        try {
            await queryInterface.sequelize.query(dropIndexQuery, { type: QueryTypes.RAW });
        } catch (error) {
            console.error(`Error dropping index ${indexName}:`, error);
            // Optional: Check for specific errors like 'index does not exist' and handle gracefully
        } */
  }
};

export default migration;

// --- END OF FILE 20230425153434-create-contacts_number_tenantId.ts ---
