import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import Ticket from "./Ticket";
import User from "./User";
import Queue from "./Queue";

@Table
class LogTicket extends Model<LogTicket> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column(DataType.TEXT) // Use TEXT for potentially long logs
  type: string;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @ForeignKey(() => Ticket)
  @Column
  ticketId: number;

  @BelongsTo(() => Ticket)
  ticket: Ticket;

  @ForeignKey(() => User)
  @AllowNull(true)
  @Default(null)
  @Column
  userId: number | null;

  @BelongsTo(() => User)
  user: User | null;

  @ForeignKey(() => Queue)
  @Column
  queueId: number;

  @BelongsTo(() => Queue)
  queue: Queue;
}

export default LogTicket;
