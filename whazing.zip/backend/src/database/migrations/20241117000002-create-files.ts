import { QueryInterface, DataTypes, Sequelize } from 'sequelize'; // Added Sequelize
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'Files' table (presumably for storing uploaded media/documents)
    await queryInterface.createTable(
      'Files', // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
          allowNull: false,
        },
        url: { // URL if stored externally (e.g., S3)
          type: DataTypes.STRING,
          allowNull: false,
        },
        mediaType: { // MIME type (e.g., 'image/jpeg', 'application/pdf')
          type: DataTypes.STRING,
          allowNull: false,
        },
        mediaUrl: { // Potentially redundant with 'url', or maybe internal path? Kept from original.
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null,
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: { model: 'Tenants', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE', // If tenant is deleted, delete associated files
          allowNull: false, // File must belong to a tenant (changed from original true based on onDelete: CASCADE)
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'),
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'),
        },
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'Files' table
    await queryInterface.dropTable('Files');
  }
};

export = migration;