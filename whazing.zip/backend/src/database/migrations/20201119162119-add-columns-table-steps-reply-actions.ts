import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'queue' a la tabla 'StepsReplyActions'
    return queryInterface.addColumn('StepsReplyActions', 'queue', {
      type: DataTypes.INTEGER
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'queue' de la tabla 'StepsReplyActions'
    return queryInterface.removeColumn('StepsReplyActions', 'queue');
  }
};