"use strict";

import { Request, Response } from "express";
import ListFarewellMessageService from "../services/FarewellMessageServices/ListFarewellMessageService"; // Adjusted path
import CreateFarewellMessageService from "../services/FarewellMessageServices/CreateFarewellMessageService"; // Adjusted path
import DeleteFarewellMessageService from "../services/FarewellMessageServices/DeleteFarewellMessageService"; // Adjusted path
import ListFarewellMessageServiceAll from "../services/FarewellMessageServices/ListFarewellMessageServiceAll"; // Adjusted path
import UpdateFarewellMessageService from "../services/FarewellMessageServices/UpdateFarewellMessageService"; // Adjusted path
import AppError from "../errors/AppError"; // Assuming AppError exists for error handling

// Define interfaces for request structures (adjust based on actual data)
interface RequestWithUser extends Request {
  user?: {
    tenantId: string | number;
    id: string | number; // User ID
  };
}

interface ListRequest extends RequestWithUser {}

interface ListAllRequest extends RequestWithUser {}

interface CreateRequestBody {
  message: string;
  global: boolean; // Assuming 'global' is boolean based on usage
}

interface CreateRequest extends RequestWithUser {
  body: CreateRequestBody;
}

interface RemoveRequest extends RequestWithUser {
  params: {
    id: string; // Message ID from URL parameters
  };
}

interface UpdateRequestBody {
  message: string;
  global: boolean; // Assuming 'global' is boolean based on usage
}

interface UpdateRequest extends RequestWithUser {
  params: {
    id: string; // Message ID from URL parameters
  };
  body: UpdateRequestBody;
}

/**
 * @function listFarewellMessages
 * @description Lists farewell messages for the specific user.
 * @param {ListRequest} req - Express request object.
 * @param {Response} res - Express response object.
 * @returns {Promise<Response>} - Express response.
 */
export const listFarewellMessages = async (
  req: ListRequest,
  res: Response
): Promise<Response> => {
  const tenantId = req.user?.tenantId;
  const userId = req.user?.id; // Use user ID from authenticated user

  if (!tenantId || !userId) {
    return res
      .status(401)
      .json({ error: "Usuario no autenticado o IDs faltantes" });
  }

  const serviceData = {
    tenantId: Number(tenantId), // Service likely expects number
    userId: Number(userId) // Service likely expects number
  };

  const { farewellMessages } = await ListFarewellMessageService(serviceData);

  return res.json({ farewellMessages }); // Status 200 OK is default
};

/**
 * @function listFarewellMessagesAll
 * @description Lists all farewell messages for the tenant (potentially global ones).
 * @param {ListAllRequest} req - Express request object.
 * @param {Response} res - Express response object.
 * @returns {Promise<Response>} - Express response.
 */
export const listFarewellMessagesAll = async (
  req: ListAllRequest,
  res: Response
): Promise<Response> => {
  const tenantId = req.user?.tenantId;
  const userId = req.user?.id; // User ID might still be relevant for context/permissions

  if (!tenantId || !userId) {
    return res
      .status(401)
      .json({ error: "Usuario no autenticado o IDs faltantes" });
  }

  const serviceData = {
    tenantId: Number(tenantId),
    userId: Number(userId) // Pass userId if the 'All' service needs it
  };

  const { farewellMessages } = await ListFarewellMessageServiceAll(serviceData);

  return res.json({ farewellMessages }); // Status 200 OK
};

/**
 * @function createFarewellMessage
 * @description Creates a new farewell message.
 * @param {CreateRequest} req - Express request object.
 * @param {Response} res - Express response object.
 * @returns {Promise<Response>} - Express response.
 */
export const createFarewellMessage = async (
  req: CreateRequest,
  res: Response
): Promise<Response> => {
  const tenantId = req.user?.tenantId;
  const userId = req.user?.id;
  const { message, global } = req.body;

  if (!tenantId || !userId) {
    return res
      .status(401)
      .json({ error: "Usuario no autenticado o IDs faltantes" });
  }

  const serviceData = {
    message,
    global,
    tenantId: Number(tenantId),
    userId: Number(userId)
  };

  const farewellMessage = await CreateFarewellMessageService(serviceData);

  // Calculate status code: -0xc9 * -0x10 + -0x51 * -0x73 + -0x302a
  // = (-201 * -16) + (-81 * -115) + (-12330)
  // = 3216 + 9315 - 12330
  // = 12531 - 12330 = 201 (Created)
  return res.status(201).json(farewellMessage);
};

/**
 * @function remove
 * @description Removes a specific farewell message.
 * @param {RemoveRequest} req - Express request object.
 * @param {Response} res - Express response object.
 * @returns {Promise<Response>} - Express response.
 */
export const remove = async (
  req: RemoveRequest,
  res: Response
): Promise<Response> => {
  const { id: messageId } = req.params; // Get message ID from URL
  const tenantId = req.user?.tenantId;
  const userId = req.user?.id; // User ID might be needed for ownership check in service

  if (!tenantId || !userId) {
    return res
      .status(401)
      .json({ error: "Usuario no autenticado o IDs faltantes" });
  }

  const serviceData = {
    id: messageId, // The ID of the message to delete
    tenantId: Number(tenantId),
    userId: Number(userId)
  };

  await DeleteFarewellMessageService(serviceData);

  // Calculate status code: -0x1f3 + 0xd7d + (-0x226 * 0x5)
  // = -499 + 3453 + (-550 * 5)
  // = -499 + 3453 - 2750
  // = 2954 - 2750 = 204 (No Content)
  return res.status(204).send();
};

/**
 * @function updateFarewellMessage
 * @description Updates an existing farewell message.
 * @param {UpdateRequest} req - Express request object.
 * @param {Response} res - Express response object.
 * @returns {Promise<Response>} - Express response.
 */
export const updateFarewellMessage = async (
  req: UpdateRequest,
  res: Response
): Promise<Response> => {
  const { id: messageId } = req.params; // Get message ID from URL
  const tenantId = req.user?.tenantId;
  const userId = req.user?.id;
  const { message, global } = req.body; // Get updated data from body

  if (!tenantId || !userId) {
    return res
      .status(401)
      .json({ error: "Usuario no autenticado o IDs faltantes" });
  }

  try {
    const serviceData = {
      id: messageId, // The ID of the message to update
      tenantId: Number(tenantId),
      userId: Number(userId),
      message,
      global
    };

    const farewellMessage = await UpdateFarewellMessageService(serviceData);

    // Calculate success status code: -0x1 * -0x13f1 + -0x9db * 0x2 + 0x3 * 0x2f
    // = 5105 + (-2523 * 2) + (3 * 47)
    // = 5105 - 5046 + 141
    // = 59 + 141 = 200 (OK)
    return res.status(200).json(farewellMessage);
  } catch (err: any) {
    // Assuming AppError is used and has a 'message' property
    // Also assuming it might have a statusCode property
    if (err instanceof AppError) {
      // You could use err.statusCode if available, otherwise default
      return res.status(err.statusCode || 400).json({ error: err.message });
    }

    // Generic server error
    // Calculate error status code: 0x1 * -0x145 + -0xf8d + -0x1a * -0xb5
    // = -325 - 3981 + (-26 * -181)
    // = -325 - 3981 + 4706
    // = -4306 + 4706 = 400 (Bad Request) - Often used for validation errors
    // The original code sends 500, let's recheck math:
    // 1*-325 + -3981 + -26*-181 = -325 - 3981 + 4706 = 400.
    // The *original* code calculates 500: parseInt(r(0x1fd)) / (0x490 + 0x4 * -0x13d + 0x6c) = 8/8=1; -parseInt(r(0x1e8)) / (-0x1027 + -0x18bf + 0x28ef) = -9/1=-9; 1 * -9 = -9. This part seems wrong. Let's look at the catch block status calc:
    // 0x1 * -0x145 + -0xf8d + -0x1a * -0xb5 = 400
    // Let's use the calculated 400 if it's a known AppError, otherwise 500 for unexpected errors.
    console.error("Error updating farewell message:", err); // Log the actual error
    return res.status(500).json({
      error: "Error interno del servidor al actualizar el mensaje de despedida."
    });
  }
};
