import { Request, Response } from 'express';
import TicketsQueuesService from '../services/StatisticsServices/TicketsQueuesService';
import ContactsReportService from '../services/StatisticsServices/ContactsReportService';
import TicketsReportService from '../services/StatisticsServices/TicketsReportService';

interface QueryParams {
    status?: string;
    queuesIds?: string | string[]; // Podría ser una cadena JSON o un array real
    searchParam?: string;
    searchParamMessage?: string;
    pageNumber?: string;
    showAll?: string; // Debería ser booleano idealmente, pero viene como string
    withUnreadMessages?: string; // Debería ser booleano
    tagsIds?: string | string[];
    useradmId?: string;
    whatsappIds?: string | string[]; // Podría ser una cadena JSON o un array real
    isNotAssignedUser?: string; // Debería ser booleano
    includeNotQueueDefined?: string; // Debería ser booleano
    startDate?: string;
    endDate?: string;
    tags?: string | string[]; // Similar a tagsIds
    campaign?: string;
    kanbans?: string; // Podría ser un array
    wallets?: string; // Podría ser un array
    isNotAssigned?: string; // Similar a isNotAssignedUser
}

interface UserRequest extends Request {
    user?: {
        id: string | number;
        tenantId: string | number;
        profile: string;
    };
    query: QueryParams;
}

// Helper para formatear fecha (YYYY-MM-DD)
const formatDate = (dateInput: string | Date): string => {
    const date = new Date(dateInput);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

export const DashTicketsQueues = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId } = req.user!;
    const { queuesIds } = req.query; // status no se usa aquí

    const params = {
        queuesIds: queuesIds, // Mantener como viene de la query por ahora
        tenantId
    };

    const tickets = await TicketsQueuesService(params);

    return res.status(200).json(tickets);
};

export const ContactsReport = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId, profile, id: userId } = req.user!;
    const query = req.query;

    const startDateParam = query.startDate;
    const endDateParam = query.endDate;

    let startDate: string | null = null;
    let endDate: string | null = null;

    if (startDateParam) {
        startDate = formatDate(startDateParam);
    }
    if (endDateParam) {
        endDate = formatDate(endDateParam);
    }

    // Convertir IDs de string a number si existen y son arrays
    const tagsIds = query.tags ? (Array.isArray(query.tags) ? query.tags.map(Number) : JSON.parse(query.tags).map(Number)) : undefined;
    const ddds = query.ddds ? (Array.isArray(query.ddds) ? query.ddds.map(Number) : JSON.parse(query.ddds).map(Number)) : undefined;
    const wallets = query.wallets ? (Array.isArray(query.wallets) ? query.wallets.map(Number) : JSON.parse(query.wallets).map(Number)) : undefined;

    const campaign = query.campaign ? query.campaign : undefined;
    const showAll = query.showAll === 'true';

    const params = {
        startDate,
        endDate,
        ddds,
        campaign,
        wallets,
        tenantId,
        profile,
        userId: +userId, // Asegurar que userId es número
        showAll,
        tagsIds
    };

    const contactsReport = await ContactsReportService(params);

    return res.status(200).json(contactsReport);
};


export const TicketsReport = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId, profile, id: userId } = req.user!;
    const {
        searchParam,
        searchParamMessage,
        pageNumber = '1', // Valor por defecto
        status,
        showAll,
        withUnreadMessages,
        queuesIds: queuesIdsParam,
        tagsIds: tagsIdsParam,
        useradmId,
        whatsappIds: whatsappIdsParam,
        isNotAssignedUser,
        includeNotQueueDefined,
        startDate,
        endDate
    } = req.query;

    // Convertir parámetros booleanos de string a boolean
    const showAllBool = showAll === 'true';
    const withUnreadBool = withUnreadMessages === 'true';
    const isNotAssignedUserBool = isNotAssignedUser === 'true';
    const includeNotQueueDefinedBool = includeNotQueueDefined === 'true';

    // Convertir IDs de string JSON/array a array de números
    const parseIds = (param: string | string[] | undefined): number[] | undefined => {
        if (!param) return undefined;
        try {
            const parsed = typeof param === 'string' ? JSON.parse(param) : param;
            return Array.isArray(parsed) ? parsed.map(Number).filter(id => !isNaN(id)) : undefined;
        } catch (error) {
            console.error("Error parsing IDs:", param, error);
            return undefined;
        }
    };

    const queuesIds = parseIds(queuesIdsParam);
    const tagsIds = parseIds(tagsIdsParam);
    const whatsappIds = parseIds(whatsappIdsParam);

    const params = {
        searchParam,
        searchParamMessage,
        pageNumber: pageNumber, // Mantener como string según el servicio original
        status: status ? JSON.parse(status) : undefined, // Asume que status es un JSON array
        showAll: showAllBool,
        userId: String(userId), // El servicio espera userId como string
        withUnreadMessages: withUnreadBool,
        queuesIds,
        tagsIds,
        useradmId,
        whatsappIds,
        isNotAssignedUser: isNotAssignedUserBool,
        includeNotQueueDefined: includeNotQueueDefinedBool,
        tenantId,
        profile,
        startDate,
        endDate
    };

    const { tickets, count, hasMore } = await TicketsReportService(params);

    return res.status(200).json({ tickets, count, hasMore });
};