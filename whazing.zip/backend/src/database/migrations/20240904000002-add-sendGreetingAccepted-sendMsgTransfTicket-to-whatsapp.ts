import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add multiple columns related to sending specific messages
    await Promise.all([
      // Add 'sendGreetingAccepted' boolean column
      queryInterface.addColumn(
        'Whatsapps',            // Table name
        'sendGreetingAccepted', // New column name
        {
          type: DataTypes.BOOLEAN,
          defaultValue: false,
          // allowNull defaults to true
        }
      ),
      // Add 'sendGreetingAcceptedMSG' text column
      queryInterface.addColumn(
        'Whatsapps',                 // Table name
        'sendGreetingAcceptedMSG',   // New column name
        {
          type: DataTypes.TEXT,
          // allowNull defaults to true
        }
      ),
      // Add 'sendMsgTransfTicket' boolean column
      queryInterface.addColumn(
        'Whatsapps',             // Table name
        'sendMsgTransfTicket',   // New column name
        {
          type: DataTypes.BOOLEAN,
          defaultValue: false,
          // allowNull defaults to true
        }
      ),
      // Add 'sendMsgTransfTicketMSG' text column
      queryInterface.addColumn(
        'Whatsapps',                  // Table name
        'sendMsgTransfTicketMSG',     // New column name
        {
          type: DataTypes.TEXT,
          // allowNull defaults to true
        }
      ),
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added columns
    await Promise.all([
      queryInterface.removeColumn('Whatsapps', 'sendGreetingAccepted'),
      queryInterface.removeColumn('Whatsapps', 'sendGreetingAcceptedMSG'),
      queryInterface.removeColumn('Whatsapps', 'sendMsgTransfTicket'),
      queryInterface.removeColumn('Whatsapps', 'sendMsgTransfTicketMSG'),
    ]);
  }
};

export = migration;