<template>
  <q-dialog :value="abrirModalQR" @hide="fecharModalQrModal" persistent>
    <q-card class="whatsapp-card container-rounded-10">
      <!-- Encabezado -->
      <q-card-section class="q-pb-sm">
        <div class="row items-center justify-between">
          <div class="text-h6 font-family-main whatsapp-title">Inicia sesión en WhatsApp Web</div>
          <q-btn round flat color="negative" icon="eva-close" @click="fecharModalQrModal" />
        </div>
      </q-card-section>

      <!-- Descripción -->
      <q-card-section class="q-pt-none q-pb-sm">
        <p class="whatsapp-description">Envía mensajes privados a tus amigos y familiares a través de WhatsApp en tu navegador.</p>
      </q-card-section>

      <div class="whatsapp-content row">
        <!-- Instrucciones -->
        <q-card-section class="instructions-section col-12 col-sm-6">
          <ol class="whatsapp-instructions">
            <li>Abre WhatsApp en tu teléfono.</li>
            <li>Toca Menú <span class="menu-icon">⋮</span> en Android o Ajustes <span class="settings-icon">⚙️</span> en iPhone.</li>
            <li>Toca Dispositivos vinculados y luego Vincular un dispositivo.</li>
            <li>Apunta tu teléfono hacia esta pantalla para escanear el código QR.</li>
          </ol>
          
          <div class="help-link">
            <a href="#" @click.prevent>¿Necesitas ayuda para empezar?</a>
          </div>
          
          <div class="login-phone-link">
            <a href="#" @click.prevent>Iniciar sesión con número de teléfono</a>
          </div>
        </q-card-section>

        <!-- Sección QR Code -->
        <q-card-section class="qr-section col-12 col-sm-6 q-py-sm text-center">
          <div class="qr-container" :style="$q.dark.isActive ? 'background: white !important' : ''">
            <QrcodeVue v-if="cQrcode" :value="cQrcode" :size="250" level="H" />
            <div class="qr-checkmark" v-if="cQrcode">
              <q-icon name="check_circle" color="green" size="sm" />
              <span class="checkmark-text">Mantén tu teléfono conectado</span>
            </div>
          </div>

          <!-- Código de emparejamiento -->
          <div v-if="cParingCode" class="pairing-code q-py-sm" :style="$q.dark.isActive ? 'background: #000 !important' : ''">
            <div class="text-caption q-mb-xs">Código de emparejamiento:</div>
            <div class="text-weight-bold">{{ formatPairingCode(cParingCode) }}</div>
          </div>
          <div v-else class="text-caption waiting-text">
            ESPERANDO LA LECTURA DEL CÓDIGO QR...
          </div>
        </q-card-section>
      </div>

      <!-- Pie de página -->
      <q-card-section class="q-pt-none">
        <div class="text-caption q-mb-sm">Si tiene problemas para conectar, solicite un nuevo Código QR</div>
        <div class="row justify-center">
          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
            label="Nuevo QR Code"
            @click="solicitarQrCode"
            icon="mdi-qrcode" />
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
</template>

<script>

import QrcodeVue from 'qrcode.vue'

export default {
  name: 'ModalQrCode',
  components: {
    QrcodeVue
  },
  props: {
    abrirModalQR: {
      type: Boolean,
      default: false
    },
    channel: {
      type: Object,
      default: () => ({
        id: null,
        qrcode: ''
      })
    }
  },
  watch: {
    channel: {
      handler (v) {
        if (this.channel.status === 'CONNECTED') {
          this.fecharModalQrModal()
        }
      },
      deep: true
    }
  },
  computed: {
    cQrcode () {
      return this.channel.qrcode
    },
    cParingCode () {
      return this.channel.pairingCode
    }
  },
  methods: {
    formatPairingCode(code) {
      // Añade espacios cada 4 caracteres para mejor legibilidad
      return code?.match(/.{1,4}/g)?.join('-') || code
    },
    solicitarQrCode () {
      this.$emit('gerar-novo-qrcode', this.channel)
      this.fecharModalQrModal()
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    },
    fecharModalQrModal () {
      this.$emit('update:abrirModalQR', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.whatsapp-card {
  max-width: 800px;
  width: 90vw;
  border-radius: 10px;
}

.whatsapp-title {
  color: #128C7E;
  font-weight: 600;
  font-size: 1.5rem;
}

.whatsapp-description {
  color: #4a4a4a;
  font-size: 0.9rem;
  margin-bottom: 1rem;
}

.whatsapp-content {
  display: flex;
  flex-wrap: wrap;
}

.instructions-section {
  text-align: left;
  padding-right: 1rem;
}

.whatsapp-instructions {
  padding-left: 1.5rem;
  margin-top: 0;
  
  li {
    margin-bottom: 0.8rem;
    color: #4a4a4a;
    font-size: 0.9rem;
  }
}

.menu-icon, .settings-icon {
  display: inline-block;
  font-weight: bold;
}

.help-link, .login-phone-link {
  margin-top: 1.5rem;
  
  a {
    color: #128C7E;
    text-decoration: none;
    font-size: 0.9rem;
    display: inline-flex;
    align-items: center;
    
    &:hover {
      text-decoration: underline;
    }
  }
}

.login-phone-link {
  margin-top: 1rem;
}

.qr-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.qr-container {
  padding: 1rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  display: inline-block;
  background: white;
  position: relative;
}

.qr-checkmark {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 0.5rem;
  color: #25D366;
  
  .checkmark-text {
    margin-left: 0.3rem;
    font-size: 0.8rem;
    color: #4a4a4a;
  }
}

.pairing-code {
  background: #f5f5f5;
  border-radius: 4px;
  padding: 0.5rem;
  margin: 0.5rem 1rem;
  font-size: 1.2rem;
}

.text-caption {
  font-size: 0.875rem;
}

.waiting-text {
  color: #128C7E;
  font-weight: 500;
  margin-top: 0.5rem;
}

.generate-button {
  background-color: #25D366;
  color: white;
  border-radius: 24px;
  padding: 0.5rem 1.5rem;
  
  &:hover {
    background-color: #128C7E;
  }
}

.generate-button-dark {
  background-color: #128C7E;
}

@media (max-width: 600px) {
  .whatsapp-content {
    flex-direction: column-reverse;
  }
  
  .instructions-section, .qr-section {
    width: 100%;
    padding: 0 1rem;
  }
  
  .qr-container {
    margin-bottom: 1.5rem;
  }
}
</style>
