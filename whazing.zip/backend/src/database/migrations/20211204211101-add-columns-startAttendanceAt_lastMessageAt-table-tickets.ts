import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add timestamp columns to 'Tickets' table
    await Promise.all([
      queryInterface.addColumn('Tickets', 'startedAttendanceAt', {
        type: DataTypes.BIGINT, // Using BIGINT for timestamp (milliseconds?)
        allowNull: true,
        defaultValue: null,
      }),
      queryInterface.addColumn('Tickets', 'lastMessageAt', {
        type: DataTypes.BIGINT, // Using BIGINT for timestamp
        allowNull: true,
        defaultValue: null,
      }),
      queryInterface.addColumn('Tickets', 'closedAt', { // Also adding closedAt based on original variable names
        type: DataTypes.BIGINT, // Using BIGINT for timestamp
        allowNull: true,
        defaultValue: null,
      }),
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added timestamp columns
    await Promise.all([
      queryInterface.removeColumn('Tickets', 'closedAt'),
      queryInterface.removeColumn('Tickets', 'lastMessageAt'),
      queryInterface.removeColumn('Tickets', 'startedAttendanceAt'),
    ]);
  }
};

export = migration;