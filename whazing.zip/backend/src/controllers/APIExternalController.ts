import { Request, Response } from 'express';
import * as Yup from 'yup';
import { Op } from 'sequelize'; // Assuming sequelize is used for Op.or
import AppError from '../errors/AppError';
import ApiConfig from '../models/ApiConfig'; // Assuming ApiConfig is a Sequelize model
import Queue from '../libs/Queue';
import Tag from '../models/Tag'; // Assuming Tag is a Sequelize model
import Ticket from '../models/Ticket'; // Assuming Ticket is a Sequelize model
import Contact from '../models/Contact'; // Assuming Contact is a Sequelize model
import User from '../models/User'; // Assuming User is a Sequelize model
import QueueModel from '../models/Queue'; // Renamed to avoid conflict with lib
import ShowTicketService from '../services/TicketServices/ShowTicketService';
import UpdateContactTagsService from '../services/ContactServices/UpdateContactTagsService';
import UpdateTicketService from '../services/TicketServices/UpdateTicketService';
import CreateTicketService from '../services/TicketServices/CreateTicketService';
import { StartWhatsAppSession } from '../services/WbotServices/StartWhatsAppSession';
import * as qrcode from 'qrcode';
import { getIO } from '../libs/socket';
import GetProfilePicUrl from '../services/WbotServices/GetProfilePicUrl';
import Whatsapp from '../models/Whatsapp'; // Assuming Whatsapp is a Sequelize model
import CreateContactService from '../services/ContactServices/CreateContactService';
import ShowContactService from '../services/ContactServices/ShowContactService';
import { getWbot } from '../libs/wbot';
import ContactsReportService from '../services/StatisticsServices/ContactsReportService';
import Kanban from '../models/Kanban'; // Assuming Kanban is a Sequelize model
import UpdateKanbanIdService from '../services/KanbanServices/UpdateKanbanIdService';

// Helper Functions (Types added, logic preserved)

interface ApiConfigValidationResult extends ApiConfig { // Assuming ApiConfig model structure
  id: number;
  tenantId: number;
  sessionId: string; // Assuming sessionId is string in ApiConfig
  // other properties...
}

const validateAPIAndSession = async (apiId: string | number, tenantId: number | string, sessionId: string | number): Promise<ApiConfigValidationResult> => {
  const api = await ApiConfig.findOne({
    where: { id: apiId, tenantId }
  });

  if (!api || api.sessionId !== sessionId.toString()) { // Ensure sessionId comparison is correct type
    throw new AppError('ERR_SESSION_NOT_AUTH', 401);
  }
  // Cast to expected type if validation passes
  return api as ApiConfigValidationResult;
};

interface ContactResult extends Contact { // Assuming Contact model structure
  id: number;
  number: string;
  tenantId: number;
  // other properties...
}

const findContactByNumber = async (number: string, tenantId: number | string): Promise<ContactResult> => {
  const contact = await Contact.findOne({
    where: {
      number: number.toString(), // Ensure number is string for query
      tenantId
    }
  });

  if (!contact) {
    throw new AppError('CONTACT_NOT_FOUND', 404);
  }
  return contact as ContactResult;
};

const validateWithYup = async (schema: Yup.ObjectSchema<any>, data: any): Promise<void> => {
  try {
    await schema.validate(data);
  } catch (err: any) {
    throw new AppError(err.message);
  }
};

// Controller Methods

export const sendMessageAPI = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user; // Assuming these are on req.user
  const { apiId } = req.params;
  const { profile } = req.user; // Assuming profile is on req.user
  const messageData = { ...req.body };

  await validateAPIAndSession(apiId, tenantId, sessionId);

  const dataToSend = {
    ...messageData,
    apiId,
    sessionId,
    tenantId,
    profile // Passed to queue job
  };

  const schema = Yup.object().shape({
    apiId: Yup.string().required(),
    sessionId: Yup.string().required(),
    body: Yup.string().required(),
    number: Yup.string().required(),
    mediaUrl: Yup.string().url().nullable(),
    tenantId: Yup.number().required() // Assuming tenantId is number here
  });

  await validateWithYup(schema, dataToSend);

  Queue.add('SendMessageAPI', dataToSend);

  return res.status(202).json({ message: 'Message added to queue' }); // 202 Accepted
};

export const showTicket = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user;
  const { apiId } = req.params;

  await validateAPIAndSession(apiId, tenantId, sessionId);

  const contact = await findContactByNumber(req.body.number, tenantId);

  const ticket = await Ticket.findOne({
    where: {
      contactId: contact.id,
      status: 'open',
      tenantId
    }
  });

  if (!ticket) {
    return res.status(404).json({ error: 'Ticket não encontrado' });
  }

  const ticketDetails = await ShowTicketService({ id: ticket.id.toString(), tenantId }); // Ensure ID is string
  return res.status(200).json(ticketDetails);
};

export const showTicketChatbot = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId, sessionId } = req.user;
    const { apiId } = req.params;

    await validateAPIAndSession(apiId, tenantId, sessionId);

    const contact = await findContactByNumber(req.body.number, tenantId);

    const tickets = await Ticket.findAll({
        where: {
            contactId: contact.id,
            tenantId: tenantId
        }
    });

    if (!tickets.length) {
        return res.status(404).json({ message: 'Ticket não encontrado' });
    }

    for (const ticket of tickets) {
        const ticketDetails = await ShowTicketService({ id: ticket.id.toString(), tenantId });
        if (ticketDetails.channel === null) { // Check if channel is null, indicating it might be the chatbot one
             return res.status(200).json(ticketDetails);
        }
    }

    // If no ticket with channel=null is found after checking all tickets
    return res.status(404).json({ message: 'Ticket Aberto não encontrado' });
};


export const showAllTicket = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user;
  const { apiId } = req.params;

  await validateAPIAndSession(apiId, tenantId, sessionId);

  const contact = await findContactByNumber(req.body.number, tenantId);

  const tickets = await Ticket.findAll({
    where: {
      contactId: contact.id,
      tenantId
    }
  });

  if (!tickets.length) {
    return res.status(404).json({ error: 'Ticket não encontrado' });
  }

  const ticketDetailsPromises = tickets.map(ticket =>
    ShowTicketService({ id: ticket.id.toString(), tenantId })
  );
  const allTicketDetails = await Promise.all(ticketDetailsPromises);

  return res.status(200).json(allTicketDetails);
};

export const updateTag = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user;
  const { apiId } = req.params;
  const { ticketId, contactId, number, tag: tagId } = req.body;

  await validateAPIAndSession(apiId, tenantId, sessionId);

  if ((!ticketId && !contactId) && !number) {
    return res.status(400).json({ error: 'É necessário fornecer ticketId, contactId ou number' });
  }
  if (!tagId) {
    return res.status(400).json({ error: 'ID da tag não fornecido' });
  }

  let effectiveContactId: number | null = null;

  if (ticketId) {
    const ticket = await Ticket.findOne({ where: { id: ticketId, tenantId } });
    if (ticket) {
      effectiveContactId = ticket.contactId;
    }
  } else if (contactId) {
    const contact = await Contact.findOne({ where: { id: contactId, tenantId } });
    if (contact) {
      effectiveContactId = contact.id;
    }
  } else if (number) {
    const contact = await Contact.findOne({
      where: { number: number.toString(), tenantId }
    });
    if (contact) {
      effectiveContactId = contact.id;
    }
  }

  if (!effectiveContactId) {
    return res.status(404).json({ error: 'Contato não encontrado' });
  }

  const tag = await Tag.findOne({ where: { id: tagId, tenantId } });

  if (!tag) {
    return res.status(404).json({ error: 'Tag não encontrada' });
  }

  await UpdateContactTagsService({
    tags: [tag.id], // Service likely expects array of IDs
    contactId: effectiveContactId,
    tenantId
  });

  // Re-fetch the contact to return updated info
  const updatedContact = await Contact.findOne({
      where: { id: effectiveContactId, tenantId },
      include: [Tag] // Include tags to show the update
  });

  return res.status(200).json(updatedContact);
};

export const updateQueue = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user;
  const { apiId } = req.params;
  const { ticketId } = req.body;
  const ticketData = { ...req.body };
  ticketData.tenantId = tenantId;

  const apiConfig = await validateAPIAndSession(apiId, tenantId, sessionId);

  const updateData = {
    ticketData: ticketData,
    ticketId: ticketId,
    userIdRequest: apiConfig.userId // Assuming userId from apiConfig is the requester
  };

  const { ticket } = await UpdateTicketService(updateData);
  return res.status(200).json(ticket);
};

export const sendMessageParamsAPI = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user;
  const { apiId } = req.params;
  const { body, number, externalKey } = req.query as { body: string; number: string; externalKey?: string };

  let formattedNumber: string;
  if (typeof number === 'string') {
     // Basic normalization: remove non-digits
     formattedNumber = number.replace(/\D/g, '');
     // Potentially add more specific country code logic if needed
  } else {
    formattedNumber = ''; // Or handle error
  }

  await validateAPIAndSession(apiId, tenantId, sessionId);

  const dataToSend = {
    body,
    number: formattedNumber,
    externalKey,
    apiId,
    sessionId,
    tenantId
  };

  const schema = Yup.object().shape({
    apiId: Yup.string().required(),
    sessionId: Yup.string().required(),
    body: Yup.string().required(),
    number: Yup.string().required(), // Validate the potentially formatted number
    tenantId: Yup.number().required()
    // externalKey is optional, no need to require
  });

  await validateWithYup(schema, dataToSend);

  Queue.add('SendMessageAPI', dataToSend);

  return res.status(202).json({ message: 'Message added to queue' });
};

export const updateTicketInfo = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user;
  const { apiId } = req.params;
  const { ticketId } = req.body;
  const ticketData = { ...req.body };
  ticketData.tenantId = tenantId;

  const apiConfig = await validateAPIAndSession(apiId, tenantId, sessionId);

  const updateData = {
    ticketData: ticketData,
    ticketId: ticketId,
    userIdRequest: apiConfig.userId
  };

  const { ticket } = await UpdateTicketService(updateData);
  return res.status(200).json(ticket);
};

export const sendMessageAPIOficial = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user;
  const { apiId } = req.params;
  const messageData = { ...req.body };

  // Note: Official API might not use sessionId validation in the same way
  // Adjust validateAPIAndSession if needed or remove if not applicable

  const dataToSend = {
    ...messageData,
    apiId,
    sessionId, // Include if needed by the queue job
    tenantId
  };

  const schema = Yup.object().shape({
    // Adjust schema based on the actual required fields for the official API message
    apiId: Yup.string(), // Might not be needed if endpoint is specific
    sessionId: Yup.string(), // Might not be needed
    number: Yup.string().required(),
    tenantId: Yup.number().required(),
    // Add other required fields for the official API payload (e.g., template name, parameters)
  });

  await validateWithYup(schema, dataToSend);

  // Queue job name might differ for official API
  Queue.add('SendMessageAPIOficial', dataToSend);

  return res.status(202).json({ message: 'Message added to queue' });
};

export const createContact = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user; // sessionId might not be needed here
  const contactData = req.body;
  delete contactData.profilePicUrl; // Don't allow setting this directly

  if (contactData.number) {
    // Normalize number
    contactData.number = contactData.number.replace(/\D/g, '');
  }

  const schema = Yup.object().shape({
    name: Yup.string().required(),
    number: Yup.string().required().matches(/^\d+$/, 'Invalid number format. Only numbers allowed.'),
    // Add other contact fields validation if necessary
  });

  try {
    await schema.validate(contactData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  // Check if contact already exists for this tenant
  const existingContact = await Contact.findOne({
    where: { number: contactData.number, tenantId }
  });

  if (existingContact) {
    // Contact already exists, return it or an error? Returning existing for now.
    return res.status(200).json(existingContact); // Or 409 Conflict: return res.status(409).json({ error: 'Contato já existe' });
  }

  // Find a default WhatsApp connection for the tenant to validate number
  const defaultWhatsapp = await Whatsapp.findOne({
    where: { tenantId, type: 'whatsapp', status: 'CONNECTED' } // Assuming 'whatsapp' type and connected status
  });

  let profilePicUrl: string | null = null;
  if (defaultWhatsapp) {
    try {
      const wbot = getWbot(defaultWhatsapp.id);
      // Validate number format for WhatsApp (e.g., number@s.whatsapp.net)
      const numberCheck = `${contactData.number}@s.whatsapp.net`;
      // The onWhatsApp check might throw if the number doesn't exist
      const [result] = await wbot.onWhatsApp(numberCheck);

      if (!result || !result.exists) {
        // Attempt alternative format for BR numbers (simple example)
         if (contactData.number.length === 13 && contactData.number.startsWith('55') || contactData.number.length === 12 && /^[2-9]/.test(contactData.number.substring(2))) {
            const brSpecificLength = contactData.number.length === 13 ? 9 : 8; // 9 for mobile with 9, 8 otherwise
            const numberWithoutDDD = contactData.number.substring(contactData.number.length - brSpecificLength);
            const ddd = contactData.number.substring(2, 4); // Assuming DDD is 2 digits after 55
            const numberWithNine = '55' + ddd + '9' + numberWithoutDDD; // Try adding 9
            const brNumberCheck = `${numberWithNine}@s.whatsapp.net`;
             const [brResult] = await wbot.onWhatsApp(brNumberCheck);
             if (brResult && brResult.exists) {
                 contactData.number = numberWithNine; // Update number if valid with '9'
             } else {
                 throw new AppError('Número não encontrado no WhatsApp', 400);
             }
         } else {
            throw new AppError('Número não encontrado no WhatsApp', 400);
         }
      }
       // Re-fetch JID after potential BR number correction
       const finalJidNumber = `${contactData.number}@s.whatsapp.net`;
       const [finalResult] = await wbot.onWhatsApp(finalJidNumber);
       if(finalResult?.jid) {
           contactData.number = finalResult.jid.split('@')[0]; // Use validated number from JID
       }


      // Get profile picture after validation
      profilePicUrl = await GetProfilePicUrl(contactData.number, defaultWhatsapp.id);

    } catch (error: any) {
      console.error("Erro ao validar número no WhatsApp:", error);
      // Decide if validation failure should prevent contact creation
      // For now, let's allow creation but log the error
      // throw new AppError('Erro ao validar número no WhatsApp', 500);
    }
  }

  const finalContactData = {
    ...contactData,
    profilePicUrl,
    tenantId
  };

  const newContact = await CreateContactService(finalContactData);
  return res.status(201).json(newContact); // 201 Created
};

export const createTicketAPI = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user; // Assuming user context provides these
  const { number, status, queueId, userId } = req.body;

  if (!number || !status || !queueId) {
    return res.status(400).json({ error: 'Dados incompletos. Os campos number, status e queueId são obrigatórios.' });
  }

  if (status === 'open' && !userId) {
     return res.status(400).json({ error: 'O campo userId é obrigatório quando o status é \'open\'.' });
  }

  const formattedNumber = number.toString().replace(/\D/g, '');

  // Find the WhatsApp session associated with the API sessionId (if needed for context)
  // This depends on how API sessions map to WhatsApp connections
  const whatsapp = await Whatsapp.findOne({
    where: { id: sessionId, tenantId } // Assuming API sessionId matches WhatsApp ID
  });

  if (!whatsapp) {
    return res.status(404).json({ error: 'Sessão WhatsApp não encontrada para iniciar ticket.' });
  }

  const channel = whatsapp.type; // 'whatsapp', 'telegram', etc.

  // Find or create contact
  let contact = await Contact.findOne({ where: { number: formattedNumber, tenantId } });
  if (!contact) {
    // If contact doesn't exist, create it (minimal data)
    try {
        contact = await CreateContactService({
            name: formattedNumber, // Use number as name initially
            number: formattedNumber,
            tenantId
        });
    } catch (err) {
        console.error("Erro ao criar contato:", err);
        return res.status(500).json({ error: 'Erro ao criar contato.' });
    }
  }

  // Check for existing open or pending tickets for this contact on the same channel/session
   const existingTicket = await Ticket.findOne({
       where: {
           contactId: contact.id,
           tenantId,
           channel, // Ensure it's for the same channel
           whatsappId: sessionId, // Check if it's for the same WhatsApp session
           status: {
               [Op.or]: ['open', 'pending']
           }
       }
   });


  if (existingTicket) {
      // Handle existing ticket: return error, update, or just return existing?
      if (existingTicket.userId && existingTicket.userId !== userId) {
            const assignedUser = await User.findByPk(existingTicket.userId);
            return res.status(409).json({ error: `Ticket já atribuído para outro usuário: ${assignedUser?.name || 'Desconhecido'}` }); // 409 Conflict
      }
       if (existingTicket.queueId && existingTicket.queueId !== queueId) {
             const assignedQueue = await QueueModel.findByPk(existingTicket.queueId);
             return res.status(409).json({ error: `Ticket já atribuído à fila: ${assignedQueue?.name || 'Desconhecida'}` }); // 409 Conflict
       }
      // If user/queue match or are null, return existing ticket info
       const ticketInfo = {
            id: existingTicket.id,
            userId: existingTicket.userId,
            status: existingTicket.status
        };
        return res.status(200).json({ message: 'Ticket já existe', ticket: ticketInfo });
  }


  // Create new ticket
  try {
    const newTicketData = {
      contactId: contact.id,
      status,
      userId, // Will be null if status is not 'open'
      tenantId,
      channel,
      whatsappId: sessionId, // Associate with the specific WhatsApp session
      queueId
    };
    const newTicket = await CreateTicketService(newTicketData);

    // Emit socket event if needed
    const io = getIO();
    io.to(`${tenantId}:${newTicket.status}`).emit(`${tenantId}-ticket`, {
      action: 'create',
      ticket: newTicket
    });

    return res.status(201).json({ success: true, ticket: newTicket }); // 201 Created
  } catch (err: any) {
    console.error("Erro ao criar ticket:", err);
    return res.status(500).json({ success: false, error: 'Erro ao criar ticket', details: err.message });
  }
};

export const statusChannel = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId, sessionId } = req.user;

    try {
        const whatsapp = await Whatsapp.findOne({
            where: { id: sessionId, tenantId }
        });

        if (!whatsapp) {
             return res.status(404).json({ error: 'Canal de comunicação não encontrado.' });
        }

        // Return relevant status information
        const statusInfo = {
            id: whatsapp.id,
            name: whatsapp.name,
            status: whatsapp.status,
            qrcode: whatsapp.qrcode, // Include qrcode if available
            type: whatsapp.type,
            number: whatsapp.number
        };

        return res.status(200).json(statusInfo);
    } catch (error: any) {
        console.error("Erro ao consultar status do canal:", error);
        return res.status(500).json({ success: false, error: 'Erro ao consultar status do canal', details: error.message });
    }
};

export const requestQrCode = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, sessionId } = req.user;
  const { apiId } = req.params; // apiId might not be needed if sessionId is the primary key
  const { number } = req.body; // Optional: number to associate with the WhatsApp session

  // Validate API session (optional, depends on flow)
  // await validateAPIAndSession(apiId, tenantId, sessionId);

  const whatsapp = await Whatsapp.findOne({
    where: { id: sessionId, tenantId }
  });

  if (!whatsapp) {
    return res.status(404).json({ success: false, error: 'Canal de comunicação não encontrado.' });
  }

   // Prevent QR code generation if already connected
   if (whatsapp.status === 'CONNECTED') {
       return res.status(400).json({ success: false, error: 'Canal já está conectado.' });
   }

  // Associate number if provided
  if (number) {
    const formattedNumber = number.toString().replace(/\D/g, '');
    whatsapp.number = formattedNumber;
    await whatsapp.save();
  }

  // If QR code already exists and status is QRCODE or PAIRING, return existing QR
    if ((whatsapp.status === 'qrcode' || whatsapp.status === 'PAIRING') && whatsapp.qrcode) {
        try {
            const qrCodeBase64 = await qrcode.toDataURL(whatsapp.qrcode);
            const qrInfo = {
                success: true,
                qrcode: whatsapp.qrcode, // Text QR
                qrcodePng: `data:image/png;base64,${Buffer.from(qrCodeBase64.split(',')[1], 'base64').toString('base64')}`, // Base64 Image QR
                pairingCode: whatsapp.pairingCode || null
            };
             return res.status(200).json(qrInfo);
        } catch (qrError) {
             console.error("Erro ao converter QR code existente:", qrError);
             // Proceed to generate a new one if conversion fails
        }
    }


  // Clear previous QR/Pairing code before starting new session
  whatsapp.qrcode = '';
  whatsapp.pairingCode = '';
  await whatsapp.save();

  try {
    // Start session and wait for QR code event or timeout
    const startSessionPromise = StartWhatsAppSession(whatsapp);

    // Timeout mechanism
    const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => {
            reject(new Error('Timeout ao iniciar sessão do WhatsApp'));
        }, 60000); // 60 seconds timeout
    });


    await Promise.race([startSessionPromise, timeoutPromise]);


    // Re-fetch WhatsApp instance to get the updated QR code/pairing code
    const updatedWhatsapp = await Whatsapp.findByPk(whatsapp.id);

    if (updatedWhatsapp && (updatedWhatsapp.qrcode || updatedWhatsapp.pairingCode)) {
      try {
        let qrCodeBase64 = '';
        if (updatedWhatsapp.qrcode) {
            qrCodeBase64 = await qrcode.toDataURL(updatedWhatsapp.qrcode);
        }
        const qrInfo = {
            success: true,
            qrcode: updatedWhatsapp.qrcode || '',
            qrcodePng: qrCodeBase64 ? `data:image/png;base64,${Buffer.from(qrCodeBase64.split(',')[1], 'base64').toString('base64')}` : '',
            pairingCode: updatedWhatsapp.pairingCode || null
        };
        return res.status(200).json(qrInfo);
      } catch (qrError) {
        console.error("Erro ao converter QR code gerado:", qrError);
         // Return success but without the PNG if conversion fails
         const qrInfo = {
            success: true,
            qrcode: updatedWhatsapp.qrcode || '',
            qrcodePng: '',
            pairingCode: updatedWhatsapp.pairingCode || null
         };
         return res.status(200).json(qrInfo);
      }
    }
    // If no QR code or pairing code after session start attempt
    return res.status(500).json({ success: false, error: 'Erro ou timeout ao solicitar QR code.' });

  } catch (error: any) {
     // Check if QR code or pairing code became available despite the error (e.g., timeout occurred but QR arrived late)
    const finalWhatsapp = await Whatsapp.findByPk(whatsapp.id);
     if (finalWhatsapp && (finalWhatsapp.qrcode || finalWhatsapp.pairingCode)) {
         try {
             let qrCodeBase64 = '';
             if (finalWhatsapp.qrcode) {
                 qrCodeBase64 = await qrcode.toDataURL(finalWhatsapp.qrcode);
             }
             const qrInfo = {
                 success: true, // Indicate success as QR is available
                 qrcode: finalWhatsapp.qrcode || '',
                 qrcodePng: qrCodeBase64 ? `data:image/png;base64,${Buffer.from(qrCodeBase64.split(',')[1], 'base64').toString('base64')}` : '',
                 pairingCode: finalWhatsapp.pairingCode || null,
                 warning: error.message // Include original error as warning
             };
             return res.status(200).json(qrInfo);
         } catch (qrError) {
             console.error("Erro ao converter QR code (em catch):", qrError);
             // Fall through to general error if conversion fails here too
         }
     }

    console.error("Erro ao solicitar QR Code:", error);
    return res.status(500).json({ success: false, error: 'Erro ao solicitar QR Code', details: error.message });
  }
};

export const getContactsByTag = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId, sessionId } = req.user;
    const { apiId, tagId } = req.params; // tagId from params

    try {
        await validateAPIAndSession(apiId, tenantId, sessionId);

        if (!tagId) {
            return res.status(400).json({ success: false, error: 'ID da tag não fornecido' });
        }

        const tag = await Tag.findOne({ where: { id: tagId, tenantId } });
        if (!tag) {
            return res.status(404).json({ success: false, error: 'Tag não encontrada' });
        }

        // Assuming ContactsReportService can filter by tagId
        const { contacts } = await ContactsReportService({
            startDate: null, // Or appropriate date range if needed
            endDate: null,
            tenantId,
            tags: [parseInt(tagId, 10)], // Ensure tagId is number array
            userIds: [], // Filter by all users or specific ones if needed
            reportType: 'sByTag' // Indicate report type
        });

        return res.status(200).json({ success: true, contacts: contacts || [] });

    } catch (error: any) {
        console.error("Erro ao buscar contatos por tag:", error);
        return res.status(500).json({ success: false, error: 'Erro ao buscar contatos por tag', details: error.message });
    }
};

export const getContactsByKanban = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId, sessionId } = req.user;
    const { apiId, kanbanId } = req.params; // kanbanId from params

    try {
        await validateAPIAndSession(apiId, tenantId, sessionId);

        if (!kanbanId) {
            return res.status(400).json({ success: false, error: 'ID do kanban não fornecido' });
        }

        // No need to validate Kanban existence here, service handles it
        const { contacts } = await ContactsReportService({
            startDate: null,
            endDate: null,
            tenantId,
            kanbans: [parseInt(kanbanId, 10)], // Ensure kanbanId is number array
            userIds: [],
            reportType: 'sByKanban' // Indicate report type
        });

        return res.status(200).json({ success: true, contacts: contacts || [] });

    } catch (error: any) {
        console.error("Erro ao buscar contatos por kanban:", error);
        return res.status(500).json({ success: false, error: 'Erro ao buscar contatos por kanban', details: error.message });
    }
};

export const getContactsByWallets = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId, sessionId } = req.user;
    const { apiId, walletId } = req.params; // walletId from params

    try {
        await validateAPIAndSession(apiId, tenantId, sessionId);

        if (!walletId) {
            return res.status(400).json({ success: false, error: 'ID da carteira (wallet) não fornecido' });
        }

        // No need to validate Wallet existence here, service handles it
        const { contacts } = await ContactsReportService({
            startDate: null,
            endDate: null,
            tenantId,
            wallets: [parseInt(walletId, 10)], // Ensure walletId is number array
            userIds: [],
            reportType: 'sByWallets' // Indicate report type
        });

        return res.status(200).json({ success: true, contacts: contacts || [] });

    } catch (error: any) {
        console.error("Erro ao buscar contatos por carteira:", error);
        return res.status(500).json({ success: false, error: 'Erro ao buscar contatos por carteira', details: error.message });
    }
};

export const updateKanban = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId, sessionId } = req.user;
    const { apiId } = req.params;
    const { ticketId, contactId, number, crm: kanbanId } = req.body; // Renamed crm to kanbanId for clarity

    await validateAPIAndSession(apiId, tenantId, sessionId);

    if ((!ticketId && !contactId) && !number) {
        return res.status(400).json({ error: 'É necessário fornecer ticketId, contactId ou number' });
    }
    if (!kanbanId) {
        return res.status(400).json({ error: 'ID do Kanban (crm) não fornecido' });
    }

    let effectiveContactId: number | null = null;

    // Find contact ID
    if (ticketId) {
        const ticket = await Ticket.findOne({ where: { id: ticketId, tenantId } });
        if (ticket) effectiveContactId = ticket.contactId;
    } else if (contactId) {
        const contact = await Contact.findOne({ where: { id: contactId, tenantId } });
        if (contact) effectiveContactId = contact.id;
    } else if (number) {
        const contact = await Contact.findOne({ where: { number: number.toString(), tenantId } });
        if (contact) effectiveContactId = contact.id;
    }

    if (!effectiveContactId) {
        return res.status(404).json({ error: 'Contato não encontrado' });
    }

    // Validate Kanban lane existence
    const kanbanLane = await Kanban.findOne({ where: { id: kanbanId, tenantId } });
    if (!kanbanLane) {
        return res.status(404).json({ error: 'Lane Kanban não encontrada' });
    }

    // Update Kanban ID for the contact
    await UpdateKanbanIdService({
        contactId: effectiveContactId,
        kanbanId: kanbanLane.id,
        tenantId
    });

    // Re-fetch contact to show updated info
    const updatedContact = await Contact.findOne({
        where: { id: effectiveContactId, tenantId },
         include: [Kanban] // Assuming relation is set up
    });

    return res.status(200).json(updatedContact);
};

export const getContactInfo = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId, sessionId } = req.user;
    const { apiId } = req.params;
    const { number, contactId } = req.body;

    await validateAPIAndSession(apiId, tenantId, sessionId);

    if (!number && !contactId) {
        return res.status(400).json({ success: false, error: 'É necessário fornecer number ou contactId' });
    }

    let effectiveContactId: number | null = null;

    if (contactId) {
        const contact = await Contact.findOne({ where: { id: contactId, tenantId } });
        if (contact) effectiveContactId = contact.id;
    } else if (number) {
        const contact = await Contact.findOne({ where: { number: number.toString(), tenantId } });
        if (contact) effectiveContactId = contact.id;
    }

    if (!effectiveContactId) {
        return res.status(404).json({ success: false, error: 'Contato não encontrado' });
    }

    try {
        const contactDetails = await ShowContactService({ id: effectiveContactId.toString(), tenantId });
        return res.status(200).json({ success: true, contact: contactDetails });
    } catch (error: any) {
        console.error("Erro ao buscar informações do contato:", error);
         // Handle case where ShowContactService throws its own not found error
         if (error instanceof AppError && error.statusCode === 404) {
            return res.status(404).json({ success: false, error: 'Contato não encontrado' });
         }
        return res.status(500).json({ success: false, error: 'Erro ao buscar informações do contato', details: error.message });
    }
};

export const validateWhatsAppContact = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId, sessionId } = req.user;
    const { apiId } = req.params;
    const { number } = req.body;

    if (!number) {
        return res.status(400).json({ success: false, error: 'Número não fornecido' });
    }

    await validateAPIAndSession(apiId, tenantId, sessionId); // Validate API session

    const formattedNumber = number.toString().replace(/\D/g, '');

    // Find the associated WhatsApp connection
     const whatsapp = await Whatsapp.findOne({
         where: { id: sessionId, tenantId, type: 'whatsapp' } // Ensure it's a WhatsApp type connection
     });

     if (!whatsapp) {
         throw new AppError('Sessão WhatsApp não encontrada ou inválida.', 404);
     }
      if (whatsapp.status !== 'CONNECTED') {
          throw new AppError('Sessão WhatsApp não está conectada.', 400);
      }


    try {
        const wbot = getWbot(whatsapp.id);
        const numberCheck = `${formattedNumber}@s.whatsapp.net`;
        const [result] = await wbot.onWhatsApp(numberCheck);

        if (!result || !result.exists) {
             return res.status(404).json({ success: false, error: 'Número não encontrado no WhatsApp' });
        }

        const validatedNumber = result.jid.split('@')[0]; // Get number from JID
        const profilePic = await GetProfilePicUrl(validatedNumber, whatsapp.id);

        return res.status(200).json({
            success: true,
            number: validatedNumber,
            profilePicUrl: profilePic
        });

    } catch (error: any) {
        console.error("Erro ao validar contato WhatsApp:", error);
        return res.status(500).json({ success: false, error: error.message || 'Erro ao validar contato WhatsApp' });
    }
};