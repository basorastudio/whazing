import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add 'disableBot' and 'disableCampaign' flags to 'Contacts'
    await Promise.all([
      queryInterface.addColumn(
        "Contacts", // Table name
        "disableBot", // New column name
        {
          type: DataTypes.BOOLEAN,
          defaultValue: false
          // allowNull defaults to true
        }
      ),
      queryInterface.addColumn(
        "Contacts", // Table name
        "disableCampaign", // New column name
        {
          type: DataTypes.BOOLEAN,
          defaultValue: false
          // allowNull defaults to true
        }
      )
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added columns
    await Promise.all([
      queryInterface.removeColumn("Contacts", "disableBot"),
      queryInterface.removeColumn("Contacts", "disableCampaign")
    ]);
  }
};

export = migration;
