<template>
  <div>
    <q-table
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      title="Programaciones"
      :data="agendamentos"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="eva-clock-outline q-pr-sm"/>
            Programaciones
          </h2>
          <div class="contact-header full-width">
            <div class="col-xs-6 col-md-3">
            <q-btn
              class="generate-button btn-rounded-50"
              :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="eva-plus-outline"
              label="Programar Mensaje"
              @click="modalAgendamento = true"
            />
            </div>
            <div class="col-xs-6 col-md-3">
              <q-select
                v-model="params.status"
                :options="statusOptions"
                label="Filtrar por Estado"
                @input="filtrarAgendamentos"
                class="contact-search"
                style="width: 300px"
                filled
                debounce="500"
              />
              <q-select
                v-if="userProfile === 'admin'"
                v-model="params.selectedUser"
                :options="usuarios"
                option-value="id"
                option-label="name"
                label="Filtrar por Usuario"
                @input="filtrarAgendamentos"
                class="contact-search"
                style="width: 300px"
                filled
                debounce="500"
                clearable
              >
              </q-select>
            </div>
            <div class="d-flex justify-content-between">
            Fecha de envío:
            <DatePick dense rounded outlined label="Fecha Inicial de Envío"
                      class="row col"
                      v-model="params.startDate"
                      @input="onDateChange"
            />
            <DatePick dense rounded outlined label="Fecha Final de Envío"
                      class="row col"
                      v-model="params.endDate"
                      @input="onDateChange"
            />
            </div>
            <div class="d-flex justify-content-between">
            Fecha que fue programado:
            <DatePick dense rounded outlined label="Fecha Inicial de Programación"
                      class="row col"
                      v-model="params.startDateCreatedAt"
                      @input="onDateChange"
            />
            <DatePick dense rounded outlined label="Fecha Final de Programación"
                      class="row col"
                      v-model="params.endDateCreatedAt"
                      @input="onDateChange"
            />
            </div>
          </div>
        </div>
      </template>
      <template v-slot:body-cell-body="props">
        <q-td :props="props" style="white-space: pre-wrap; word-wrap: break-word;">
          {{ props.row.body.length > 100 ? props.row.body.slice(0, 100) + '...' : props.row.body }}
          <q-btn
            v-if="props.row.body.length > 100"
            flat
            dense
            label="Ver más"
            class="text-primary q-ml-sm"
            @click="abrirModalTextoCompleto(props.row.body)"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-status="props">
        <q-td :props="props">
          <div class="status-indicator">
            <q-icon
              v-if="props.row.status === 'PENDENTE'"
              name="hourglass_top"
              class="status-icon yellow"
            />
            <q-icon
              v-else-if="props.row.status === 'ENVIADA'"
              name="check_circle"
              class="status-icon green"
            />
            <q-icon
              v-else-if="props.row.status === 'ERRO'"
              name="error"
              class="status-icon red"
            />
            <span>{{ props.row.status }}</span>
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-mediaUrl="props">
        <q-td :props="props">
          <span v-if="props.row.mediaUrl">
            <a :href="props.row.mediaUrl" target="_blank" style="text-decoration: underline; cursor: pointer;">
              Abrir Archivo
            </a>
          </span>
          <span v-else>
            Sin Archivo
          </span>
        </q-td>
      </template>

      <template v-slot:body-cell-createdAt="props">
        <q-td :props="props">
          {{ formatDate(props.row.createdAt) }}
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            v-if="props.row.status !== 'ENVIADA'"
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? 'color-dark1' : ''"
            icon="eva-trash-outline"
            @click="deletarMensagem(props.row)"
          />
        </q-td>
      </template>
      <template v-slot:pagination="{ pagination }">
        {{ agendamentos.length }}/{{ pagination.rowsNumber }}
      </template>
    </q-table>

    <q-dialog v-model="modalTextoCompleto">
      <q-card>
        <q-card-section>
          <div class="text-h6">Texto Completo</div>
        </q-card-section>
        <q-card-section style="white-space: pre-wrap; word-wrap: break-word;">
          <p>{{ textoCompleto }}</p>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="Cerrar" color="primary" @click="modalTextoCompleto = false" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <ModalAgendamento
      :modalAgendamento.sync="modalAgendamento"
    @agendamento:criado="agendamentoCriado"
    />

  </div>
</template>

<script>
import { ListarAgendamentoNovo, DeletarAgendamento } from 'src/service/agendamentos'
import { ListarUsuarios } from 'src/service/user'
import { ListarCores } from 'src/service/configuracoesgeneral'
import ModalAgendamento from './ModalAgendamento'

export default {
  name: 'Agendamentos',
  components: { ModalAgendamento },
  data() {
    return {
      userProfile: 'user',
      contatosCache: {},
      usuarios: [],
      agendamentos: [],
      modalAgendamento: false,
      modalTextoCompleto: false,
      textoCompleto: '',
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        startDate: null,
        endDate: null,
        startDateCreatedAt: null,
        endDateCreatedAt: null,
        status: 'PENDENTE',
        hasMore: true,
        selectedUser: null
      },
      statusOptions: [
        { label: 'Pendiente', value: 'PENDENTE' },
        { label: 'Enviada', value: 'ENVIADA' },
        { label: 'Error', value: 'ERRO' }
      ],
      loading: false,
      columns: [
        { name: 'contactName', label: 'Contacto', field: 'contactName', align: 'center' },
        { name: 'body', label: 'Mensaje', field: 'body', align: 'center' },
        { name: 'status', label: 'Estado', field: 'status', align: 'center' },
        { name: 'mediaUrl', label: 'Archivo', field: 'mediaUrl', align: 'left' },
        { name: 'scheduleDate', label: 'Fecha Envío', field: 'scheduleDate', align: 'left', format: (val) => this.formatDate(val) },
        { name: 'userName', label: 'Usuario Programó', field: 'userName', align: 'center' },
        { name: 'createdAt', label: 'Fecha fue programado', field: 'createdAt', align: 'center', format: (val) => this.formatDate(val) },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    },
    deletarMensagem(mensagem) {
      this.$q
        .dialog({
          title: '¡Atención! ¿Realmente desea eliminar este mensaje?',
          message: 'No se puede revertir.',
          cancel: {
            label: 'No',
            color: 'primary',
            push: true
          },
          ok: {
            label: 'Sí',
            color: 'negative',
            push: true
          },
          persistent: true
        })
        .onOk(() => {
          this.loading = true
          DeletarAgendamento(mensagem)
            .then((res) => {
              this.loading = false
              // Remove o agendamento deletado do array agendamentos
              const index = this.agendamentos.findIndex(agendamento => agendamento.id === mensagem.id)
              if (index !== -1) {
                this.agendamentos.splice(index, 1)
              }
              this.pagination.rowsNumber -= 1
              this.$q.notify({
                type: 'positive',
                message: 'Mensaje eliminado con éxito'
              })
            })
            .catch((error) => {
              this.loading = false
              console.error(error)
              this.$q.notify({
                type: 'negative',
                message: 'No fue posible eliminar el mensaje',
                detail: error.message
              })
            })
        })
        .onCancel(() => {
        })
    },
    async listarUsuarios() {
      const data = await ListarUsuarios()
      this.usuarios = data.data.users
    },
    async listarAgendamentos() {
      this.loading = true
      try {
        const startDate = this.params.startDate
          ? new Date(this.params.startDate).toISOString()
          : null

        const endDate = this.params.endDate
          ? (() => {
            const date = new Date(this.params.endDate)
            date.setDate(date.getDate() + 1)
            return date.toISOString()
          })()
          : null

        const startDateCreatedAt = this.params.startDateCreatedAt
          ? new Date(this.params.startDateCreatedAt).toISOString()
          : null

        const endDateCreatedAt = this.params.endDateCreatedAt
          ? (() => {
            const date = new Date(this.params.endDateCreatedAt)
            date.setDate(date.getDate() + 1)
            return date.toISOString()
          })()
          : null

        const response = await ListarAgendamentoNovo({
          startDate,
          endDate,
          startDateCreatedAt,
          endDateCreatedAt,
          status: this.params.status,
          selectedUser: this.params.selectedUser,
          pageNumber: this.params.pageNumber
        })

        if (response.data && Array.isArray(response.data.schedules)) {
          this.agendamentos = [
            ...this.agendamentos,
            ...response.data.schedules.map((schedule) => ({
              id: schedule.id,
              body: schedule.body,
              status: schedule.status,
              mediaUrl: schedule.mediaPath ? `${process.env.URL_API}/public/${schedule.mediaPath}/${schedule.mediaName}` : null,
              ticketId: schedule.ticketId,
              scheduleDate: schedule.sendAt,
              userName: schedule.user ? schedule.user.name : 'Usuario desconocido',
              contactName: schedule.contact ? schedule.contact.name : 'Contacto desconocido',
              createdAt: schedule.createdAt
            }))
          ]
          this.pagination.rowsNumber = response.data.count || 0
          this.pagination.hasMore = response.data.hasMore
        } else {
          console.error('Resposta da API não está no formato esperado:', response.data)
        }
      } catch (error) {
        console.error('Erro ao listar agendamentos:', error)
      } finally {
        this.loading = false
      }
    },
    abrirModalTextoCompleto(note) {
      this.textoCompleto = note
      this.modalTextoCompleto = true
    },
    formatDate(dateString) {
      const date = new Date(dateString)

      // Configura o formatador de data para o fuso horário desejado (exemplo: 'America/Santo_Domingo')
      const options = {
        timeZone: 'America/Santo_Domingo', // Ajuste para o fuso horário desejado
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false // Usa o formato de 24 horas
      }

      const formatter = new Intl.DateTimeFormat('es', options)
      return formatter.format(date).replace(',', '')
    },
    async filtrarAgendamentos() {
      this.params.pageNumber = 1
      this.params.hasMore = true
      this.agendamentos = []

      this.params.status = this.params.status && this.params.status.value ? this.params.status.value : null

      await this.listarAgendamentos()
    },
    onDateChange() {
      if (this.params.startDate && this.params.endDate) {
        this.filtrarAgendamentos()
      }
      if (this.params.startDateCreatedAt && this.params.endDateCreatedAt) {
        this.filtrarAgendamentos()
      }
    },
    onScroll({ to, ref, ...all }) {
      if (!this.loading && this.params.hasMore && to >= (this.agendamentos.length - 10)) {
        this.loading = true
        this.params.pageNumber++
        this.listarAgendamentos()
      }
    }
  },
  async mounted() {
    this.loadColors()
    await this.listarAgendamentos()
    await this.listarUsuarios()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.my-sticky-dynamic
  /* height or max-height is important */
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th /* bg color is important for th; just specify one */
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1
  /* this will be the loading indicator */
  thead tr:last-child th
    /* height of all previous header rows */
    top: 63px
  thead tr:first-child th
    top: 0

.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

#tabela-contatos-atendimento
  thead
    th
      height: 55px

.blur-effect
  filter: blur(0px)

.status-indicator
  display: flex
  align-items: center
  gap: 8px

.status-icon
  border-radius: 50%
  padding: 4px
  color: white

.status-icon.yellow
  background-color: #fbc02d

.status-icon.green
  background-color: #4caf50

.status-icon.red
  background-color: #f44336
</style>
