import { Request, Response } from "express";
import moment from "moment";
import { head } from "lodash"; // Assuming head is used for file checking
import axios from "axios";
import * as Yup from "yup";

import { getIO } from "../libs/socket";
import AdminListChatFlowService from "../services/AdminServices/AdminListChatFlowService";
import AdminListSettingsService from "../services/AdminServices/AdminListSettingsService";
import AdminListTenantsService from "../services/AdminServices/AdminListTenantsService";
import AdminListUsersService from "../services/AdminServices/AdminListUsersService";
import AdminListChannelsService from "../services/AdminServices/AdminListChannelsService";
import AdminUpdateUserService from "../services/AdminServices/AdminUpdateUserService";
import UpdateSettingService from "../services/SettingServices/UpdateSettingService";
import AppError from "../errors/AppError";
import CreateWhatsAppService from "../services/WhatsappService/CreateWhatsAppService";
import CreateUserService from "../services/UserServices/CreateUserService";
import { CreateTenantService } from "../services/AdminServices/AdminCreateTenantService";
import AdminStatusTenantService from "../services/AdminServices/AdminStatusTenant";
import AdminUpdateTenantService from "../services/AdminServices/AdminUpdateTenantService";
import AdminListUsersByTenantService from "../services/AdminServices/AdminListUsersByTenantService";
import CheckSettingsHelper from "../helpers/CheckSettings"; // Assuming helper path
import CheckSettingsGeneral from "../helpers/CheckSettingsGeneral"; // Assuming helper path
import ListTotalUsersService from "../services/UserServices/ListTotalUsersService";
import AdminDeleteTenantService from "../services/AdminServices/AdminDeleteTenantService";
import AdminAddmonthTenantService from "../services/AdminServices/AdminAddmonthTenantService";
import FindAllInvoiceServiceOpen from "../services/InvoicesServices/FindAllInvoiceServiceopen";
import UpdateInvoiceService from "../services/InvoicesServices/UpdateInvoiceService";
import AdminDeleteInvoiceService from "../services/AdminServices/AdminDeleteInvoiceService";
import { checkVersionService } from "../services/AdminServices/checkVersionService";
import Tenant from "../models/Tenant";
import User from "../models/User";
import Contact from "../models/Contact";
import Ticket from "../models/Ticket";
import { createRefreshToken } from "../helpers/RefreshToken"; // Assuming helper path

// Define interfaces for request bodies and responses where applicable

interface SignupRequestBody {
  phone: string;
  email: string;
  name: string; // Assuming this is tenantName
  password?: string; // Might not be needed if set later
  planId?: number | string; // Or interface Plan
  // Add other fields if needed
}

interface StoreRequestBody extends SignupRequestBody {
  tenantName: string;
  status: string; // 'active', 'inactive' etc.
  name: string; // User name
  dueDate: string; // Date string
  planId: { value: number | string }; // Assuming planId comes in this structure
  recurrence?: string;
}

interface UpdateUserRequestBody {
  password?: string;
  // other user fields...
}

interface UpdateTenantRequestBody {
  name?: string;
  planId?: { value: number | string };
  phone?: string;
  email?: string;
  dueDate?: string;
  recurrence?: string;
}

interface StoreChannelBody {
  name: string;
  tenantId: number | string;
  tokenTelegram?: string;
  instagramUser?: string;
  instagramKey?: string;
  type: string; // 'whatsapp', 'telegram', 'instagram' etc.
  wabaBSP?: string; // Specific to WABA
  tokenAPI?: string; // Specific to API type
}

interface UpdateSettingsBody {
  key: string;
  value: string;
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const {
    tenantName,
    // status, // Status seems to be set internally to 'active' initially
    password,
    name, // User name
    phone,
    email,
    dueDate,
    planId,
    recurrence = "MENSAL" // Default recurrence
  }: StoreRequestBody = req.body;

  const userTenantId = Number(req.user.tenantId); // Assuming tenantId is on req.user

  // Basic validation: Check if user with the same email already exists
  const emailExists = await User.findOne({ where: { email } });
  if (emailExists) {
    return res.status(400).json({
      error: "O email informado já está cadastrado em outro usuário."
    });
  }

  // Basic validation: Check if tenant with the same phone already exists (if phone should be unique per tenant)
  /* // Uncomment if phone needs to be unique per tenant
     const phoneExists = await Tenant.findOne({ where: { phone } });
     if (phoneExists) {
         return res.status(400).json({ error: 'O telefone informado já está cadastrado em outro tenant.' });
     }
     */

  const tenantData = {
    name: tenantName,
    status: "active", // Default status on creation
    ownerId: userTenantId, // ID of the admin user creating the tenant
    planId: planId.value, // Extract value
    phone,
    email, // Tenant email might be the same as owner or different
    dueDate,
    recurrence
  };

  const newTenant = await CreateTenantService(tenantData);

  const userData = {
    email,
    password,
    name, // User name
    tenantId: newTenant.id, // Assign the new tenant's ID
    profile: "admin", // First user is admin of the new tenant
    configs: {}, // Initialize empty configs
    // Default queue settings (adjust as needed)
    queueIds: [], // Initially no queues assigned
    whatsappId: null, // No default connection initially
    userStatus: "enabled", // Default status
    allTicket: true,
    isActive: true,
    startWork: "",
    endWork: "",
    spy: false,
    isTricked: false,
    super: false
  };

  const newUser = await CreateUserService(userData);

  return res.status(201).json({ tenant: newTenant, user: newUser }); // 201 Created
};

export const indexUsers = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { searchParam, pageNumber } = req.query as {
    searchParam?: string;
    pageNumber?: string;
  };

  const params = {
    searchParam: searchParam || "",
    pageNumber: pageNumber || "1"
  };

  const { users, count, hasMore } = await AdminListUsersService(params);

  return res.status(200).json({ users, count, hasMore });
};

export const indexUsersTotal = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const totalUsers = await ListTotalUsersService();
  return res.status(200).json({ totalUsers });
};

export const getUsersByTenant = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.params;
  const users = await AdminListUsersByTenantService(parseInt(tenantId, 10)); // Ensure tenantId is number
  return res.status(200).json({ users });
};

export const updateUser = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { password }: UpdateUserRequestBody = req.body;
  const { userId } = req.params;

  // Only allow password update for now, based on original logic focus
  if (!password) {
    return res.status(400).json({ error: "Password is required" });
    // throw new AppError("Password is required."); // Or throw error
  }

  const userData = {
    userId: parseInt(userId, 10), // Ensure ID is number
    password
    // Add other fields here if needed, e.g., name, email, profile
    // Be cautious about allowing profile changes via admin API without checks
  };

  const updatedUser = await AdminUpdateUserService(userData);

  const io = getIO();
  if (updatedUser) {
    // Emit event to the specific user's tenant socket room
    io.to(updatedUser.tenantId.toString()).emit(
      `tenant-${updatedUser.tenantId}-user`,
      {
        action: "update",
        user: updatedUser
      }
    );
    // Also emit to the global admin room if needed
    io.to("admin").emit(`tenant-${updatedUser.tenantId}-user`, {
      action: "update",
      user: updatedUser
    });
  }

  return res.status(200).json(updatedUser);
};

export const indexTenants = async (
  req: Request,
  res: Response
): Promise<Response> => {
  // Assuming tenantId '0' or similar means list all for super admin
  const requestingTenantId =
    req.user?.tenantId === 0 ? undefined : req.user.tenantId;
  const tenants = await AdminListTenantsService(requestingTenantId);
  return res.status(200).json(tenants);
};

export const indexChatFlow = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.params; // Assuming tenantId comes from route params
  const listData = { tenantId: parseInt(tenantId, 10) };
  const chatFlows = await AdminListChatFlowService(listData);
  return res.status(200).json(chatFlows);
};

export const indexSettings = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.params; // Assuming specific tenant or '0' for general
  const settings = await AdminListSettingsService(parseInt(tenantId, 10));
  return res.status(200).json(settings);
};

export const updateSettings = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.params; // Can be '0' for general settings or specific tenant ID
  const { value, key }: UpdateSettingsBody = req.body;

  const settingData = {
    key,
    value,
    tenantId: parseInt(tenantId, 10)
  };

  const updatedSetting = await UpdateSettingService(settingData);

  const io = getIO();
  // Emit to specific tenant or global admin room
  const targetRoom = tenantId === "0" ? "admin" : tenantId.toString();
  io.to(targetRoom).emit(`tenant-${tenantId}-settings`, {
    // Standardize event name
    action: "update",
    setting: updatedSetting
  });

  return res.status(200).json(updatedSetting);
};

export const indexChannels = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.query as { tenantId?: string }; // tenantId from query param

  const listData = {
    tenantId: tenantId ? parseInt(tenantId, 10) : undefined // Pass undefined if no specific tenant is requested
  };
  const channels = await AdminListChannelsService(listData);
  return res.status(200).json(channels);
};

export const storeChannel = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const {
    name,
    tenantId,
    tokenTelegram,
    instagramUser,
    instagramKey,
    type,
    wabaBSP,
    tokenAPI
  }: StoreChannelBody = req.body;

  // Add validation if needed (e.g., ensure tenant exists)

  const whatsappData = {
    name,
    status: "DISCONNECTED", // Initial status
    tenantId: parseInt(tenantId as string, 10),
    tokenTelegram,
    instagramUser,
    instagramKey,
    type,
    wabaBSP,
    tokenAPI,
    isDefault: false // Default to false unless specified otherwise
    // Add other necessary fields for CreateWhatsAppService
  };

  const newWhatsapp = await CreateWhatsAppService(whatsappData);
  return res.status(201).json(newWhatsapp); // 201 Created
};

export const updateStatusEmpresa = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.params;
  const { status } = req.body as { status: "active" | "inactive" }; // Define allowed statuses

  const tenantIdNum = parseInt(tenantId, 10);

  if (tenantIdNum === 1) {
    // Prevent changing status of tenant 1 (super admin?)
    throw new AppError("Ação não permitida", 403);
  }

  if (!["active", "inactive"].includes(status)) {
    throw new AppError("Invalid status value.", 400);
  }

  const tenantData = {
    id: tenantIdNum,
    status
  };

  const updatedTenant = await AdminStatusTenantService(tenantData);
  return res.status(200).json(updatedTenant);
};

export const adminUpdateTenant = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.params;
  const {
    name,
    planId,
    phone,
    email,
    dueDate,
    recurrence
  }: UpdateTenantRequestBody = req.body;

  const tenantIdNum = parseInt(tenantId, 10);

  if (tenantIdNum === 1) {
    // Prevent updating tenant 1?
    throw new AppError("Ação não permitida", 403);
  }

  const tenantData = {
    id: tenantIdNum,
    name,
    planId: planId?.value, // Extract value
    phone,
    email,
    dueDate,
    recurrence
  };

  // Remove undefined fields so they don't overwrite existing data unintentionally
  Object.keys(tenantData).forEach(
    key =>
      (tenantData as any)[key] === undefined && delete (tenantData as any)[key]
  );

  const updatedTenant = await AdminUpdateTenantService(tenantData);
  return res.status(200).json(updatedTenant);
};

export const signup = async (
  req: Request,
  res: Response
): Promise<Response> => {
  // --- Configuration Checks ---
  const apiTokenConfigKey = "apitoken"; // Example key name
  const apiMessageConfigKey = "apimessage"; // Example key name
  const signupEnabledKey = "allowSignup";
  const signupWelcomeMessageKey = "boasvindas";
  const apiEndpointKey = "apiendpoint";
  const apiKeyKey = "apikey"; // Key for the external API

  const apiTokenExpected = createRefreshToken(apiTokenConfigKey); // Generate expected token
  const apiMessageExpected = createRefreshToken(apiMessageConfigKey); // Generate expected token

  const apiTokenSetting = await CheckSettingsHelper(apiTokenExpected); // Check if expected token is set
  const apiMessageSetting = await CheckSettingsHelper(apiMessageExpected); // Check if expected token is set

  if (
    apiTokenSetting !== apiTokenExpected ||
    apiMessageSetting !== apiMessageExpected
  ) {
    // Check if total users limit is reached (only if tokens don't match)
    const totalUsers = await ListTotalUsersService();
    if (totalUsers >= 1) {
      // Allow only 1 user if signup keys are wrong/missing?
      throw new AppError("Signup disabled.", 403); // Or a more specific error
    }
  }

  const allowSignup = await CheckSettingsGeneral(signupEnabledKey);
  if (allowSignup !== "enabled") {
    return res.status(403).json({ error: "Signup disabled" });
  }

  // --- Tenant/User Existence Checks ---
  const { phone: reqPhone, email: reqEmail }: SignupRequestBody = req.body;

  const phoneExists = await Tenant.findOne({ where: { phone: reqPhone } });
  if (phoneExists) {
    return res.status(400).json({
      error: "O telefone informado já está cadastrado em outro tenant."
    });
  }

  const emailExists = await User.findOne({ where: { email: reqEmail } });
  if (emailExists) {
    return res.status(400).json({
      error: "O email informado já está cadastrado em outro usuário."
    });
  }

  // --- External API Notification (Optional) ---
  const sendNotification = await CheckSettingsGeneral("apienviarwhats"); // Check if notification should be sent
  if (sendNotification === "enabled") {
    try {
      const formatPhoneNumber = (rawNumber: string): string => {
        const digits = rawNumber.replace(/\D/g, "");
        // Basic BR format assumption - refine if needed
        if (digits.length >= 10) {
          return "55" + digits; // Add BR country code
        }
        return digits; // Return as is if not easily identifiable
      };

      const targetNumber = formatPhoneNumber(reqPhone);
      const welcomeMessageTemplate =
        (await CheckSettingsGeneral(signupWelcomeMessageKey)) || "Bem-vindo!"; // Default welcome message
      const apiEndpoint = await CheckSettingsGeneral(apiEndpointKey);
      const apiKey = await CheckSettingsGeneral(apiKeyKey);

      // Replace placeholders in the welcome message
      const messageBody = welcomeMessageTemplate
        .replace(/{{nomeempresa}}/g, req.body.name || "Nova Empresa") // Use provided name or default
        .replace(/{{nomeresponsavel}}/g, req.body.name || "Responsável") // Use provided name or default
        .replace(/{{email}}/g, reqEmail)
        .replace(/{{senha}}/g, req.body.password || "******"); // Mask password

      if (apiEndpoint && apiKey) {
        const payload = {
          number: targetNumber,
          body: messageBody,
          externalKey: "SIGNUP_WELCOME" // Example key
        };
        const headers = {
          Authorization: `Bearer ${apiKey}`, // Assuming Bearer token auth
          "Content-Type": "application/json"
        };

        await axios.post(apiEndpoint, payload, { headers });
        console.log(`Mensagem de boas-vindas enviada para ${targetNumber}`);
      } else {
        console.warn(
          "API endpoint ou API key não configurados para envio de mensagem de boas-vindas."
        );
      }
    } catch (error) {
      console.error(
        "Erro ao enviar mensagem de boas-vindas via API externa:",
        error
      );
      // Decide if signup should fail if notification fails. Currently just logs error.
      // return res.status(500).json({ error: "Erro ao enviar notificação de boas-vindas." });
    }
  }

  // --- Proceed with Tenant/User Creation ---
  const daysToExpireStr = (await CheckSettingsGeneral("expiracao")) || "7"; // Default 7 days
  const daysToExpire = parseInt(daysToExpireStr, 10);

  // Set dueDate based on current date + configured expiration days
  req.body.dueDate = moment()
    .add(daysToExpire, "day")
    .format("YYYY-MM-DD HH:mm:ss");
  req.body.recurrence = "MENSAL"; // Default recurrence
  req.body.planId = req.body.planId || { value: 1 }; // Default plan ID if not provided

  // Call the existing store function (now renamed storeInternal for clarity)
  return storeInternal(req, res);
};

// Renamed original store function to avoid conflict with signup export
const storeInternal = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const {
    tenantName,
    status = "active", // Default status
    password,
    name, // User name
    planId, // Already comes as { value: ... } from signup or directly
    phone,
    email,
    dueDate, // Set by signup
    recurrence // Set by signup
  }: StoreRequestBody = req.body;

  const userTenantId = 1; // Assume creator is always tenant 1 for signup? Or req.user.tenantId if admin signup

  const tenantData = {
    name: tenantName || `Tenant ${email}`, // Default name if needed
    status,
    ownerId: userTenantId,
    planId: planId.value,
    phone,
    email,
    dueDate,
    recurrence
  };

  const newTenant = await CreateTenantService(tenantData);

  const userData = {
    email,
    password,
    name,
    tenantId: newTenant.id,
    profile: "admin",
    configs: {},
    queueIds: [],
    whatsappId: null,
    userStatus: "enabled",
    allTicket: true,
    isActive: true,
    startWork: "",
    endWork: "",
    spy: false,
    isTricked: false,
    super: false
  };

  const newUser = await CreateUserService(userData);

  return res.status(201).json({ tenant: newTenant, user: newUser });
};

// Exporting storeInternal as store2 to match original export name
export { storeInternal as store2 };

export const deleteTenant = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.params;
  const deleteData = { tenantId: parseInt(tenantId, 10) };
  await AdminDeleteTenantService(deleteData);
  return res.status(204).send(); // 204 No Content
};

export const addMonthTenant = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { tenantId } = req.params;
    const tenantData = { tenantId: parseInt(tenantId, 10) };
    const updatedTenant = await AdminAddmonthTenantService(tenantData);
    return res.status(200).json(updatedTenant);
  } catch (error: any) {
    console.error("Erro ao adicionar mês ao tenant:", error);
    // Assuming AdminAddmonthTenantService might throw AppError
    if (error instanceof AppError) {
      return res.status(error.statusCode).json({ error: error.message });
    }
    return res.status(500).json({ error: "Erro ao adicionar mês ao tenant." });
  }
};

export const mediaUpload = async (
  req: Request,
  res: Response
): Promise<Response> => {
  // Admin check (assuming req.user exists and has profile)
  if (req.user?.profile !== "admin") {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }
  // Super admin check (tenantId 1)
  if (req.user?.tenantId !== 1) {
    throw new AppError("ERR_NO_PERMISSION", 403);
  }

  const file = head(req.files as Express.Multer.File[]); // Use lodash head

  if (!file) {
    // Original code sends 204, but 400 seems more appropriate
    return res.status(400).json({ error: "No file uploaded." });
    // throw new AppError("No file uploaded.", 400);
  }

  // Instead of just returning 204, return the filename or path
  // This assumes the file is saved somewhere accessible by the frontend
  // Adjust the path/URL based on where files are stored (e.g., '/public/company/')
  const filePath = `/public/${file.filename}`; // Example path

  return res.status(200).json({ url: filePath }); // Return URL/path of the uploaded file
};

export const listinvoice = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.params; // Assuming tenantId from params
  const invoices = await FindAllInvoiceServiceOpen(parseInt(tenantId, 10));
  return res.status(200).json(invoices);
};

export const updateinvoice = async (
  req: Request,
  res: Response
): Promise<Response> => {
  // Basic validation example - refine as needed
  const schema = Yup.object().shape({
    id: Yup.number().required()
    // Add other fields that can be updated if necessary
  });

  const invoiceData = req.body;

  try {
    await schema.validate(invoiceData);
  } catch (err: any) {
    throw new AppError(err.message, 400);
  }

  const { id } = invoiceData;
  const status = "paid"; // Force status to 'paid'

  const updateData = {
    id,
    status
    // Add other fields from invoiceData if they are allowed in UpdateInvoiceService
  };

  const updatedInvoice = await UpdateInvoiceService(updateData);
  return res.status(200).json(updatedInvoice);
};

export const deleteinvoice = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { invoiceId } = req.params;
  const deleteData = { invoiceId: parseInt(invoiceId, 10) };
  await AdminDeleteInvoiceService(deleteData);
  return res.status(204).send(); // 204 No Content
};

export const ListCountContacts = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const count = await Contact.count();
    return res.status(200).json({ count });
  } catch (error) {
    console.error("Erro ao contar os contatos.", error);
    return res.status(500).json({ error: "Erro ao contar os contatos." });
  }
};

export const ListCountTickets = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const count = await Ticket.count();
    return res.status(200).json({ count });
  } catch (error) {
    console.error("Erro ao contar os tickets.", error);
    return res.status(500).json({ error: "Erro ao contar os tickets." });
  }
};

export const checkVersion = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const versionInfo = await checkVersionService();
    return res.status(200).json(versionInfo);
  } catch (error: any) {
    // Return a generic error message
    return res
      .status(500)
      .json({ message: "Error checking the version.", error: error.message });
  }
};
