import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt
} from "sequelize-typescript";
import Tenant from "./Tenant"; // Assuming relation to Tenant

@Table
class Setting extends Model<Setting> {
  @PrimaryKey
  @Column
  key: string; // Key is the primary key

  @PrimaryKey // TenantId is also part of the primary key (composite key)
  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @Column
  value: string;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @BelongsTo(() => Tenant)
  tenant: Tenant;
}

export default Setting;
