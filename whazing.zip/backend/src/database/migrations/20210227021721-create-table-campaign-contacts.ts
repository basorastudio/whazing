import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Crea la tabla 'CampaignContacts' para asociar contactos a campañas
    return Promise.all([ // Usar Promise.all aunque solo sea una operación
      queryInterface.createTable('CampaignContacts', {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
          allowNull: false
        },
        messageRandom: { // ¿Mensaje aleatorio o personalizado para este contacto en la campaña?
          type: DataTypes.STRING,
          allowNull: false
        },
        body: { // Cuerpo del mensaje específico para este contacto
          type: DataTypes.TEXT,
          allowNull: true,
          defaultValue: null
        },
        mediaName: { // Nombre del medio específico para este contacto
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        messageId: { // ID del mensaje enviado a este contacto
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        jobId: { // ID del trabajo/proceso que envió el mensaje
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        ack: { // Estado de confirmación del mensaje
          type: DataTypes.INTEGER,
          allowNull: false,
          defaultValue: 0
        },
        timestamp: { // Marca de tiempo del envío/evento
          type: DataTypes.INTEGER, // Podría ser mejor DATE o BIGINT
          allowNull: true,
          defaultValue: null
        },
        contactId: {
          type: DataTypes.INTEGER,
          references: { model: 'Contacts', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE' // Si se elimina el contacto, se elimina la asociación
        },
        campaignId: {
          type: DataTypes.INTEGER,
          references: { model: 'Campaigns', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE', // Si se elimina la campaña, se elimina la asociación
          allowNull: false,
          defaultValue: 0 // Usar 0 como default para FK puede ser problemático
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        }
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la tabla 'CampaignContacts'
    return Promise.all([ // Usar Promise.all aunque solo sea una operación
      queryInterface.dropTable('CampaignContacts')
    ]);
  }
};