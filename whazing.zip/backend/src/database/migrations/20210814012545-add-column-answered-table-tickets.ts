import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'answered' (BOOLEAN) a la tabla 'Tickets'
    return Promise.all([
      queryInterface.addColumn('Tickets', 'answered', {
        type: DataTypes.BOOLEAN,
        defaultValue: true // Valor predeterminado es true
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'answered' de la tabla 'Tickets'
    return Promise.all([
      queryInterface.removeColumn('Tickets', 'answered')
    ]);
  }
};