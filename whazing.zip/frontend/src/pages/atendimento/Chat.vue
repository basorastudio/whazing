<template>
  <div class="bg-white no-scroll hide-scrollbar overflow-hidden" :style="style">
    <InforCabecalhoChat @updateTicket:resolver="atualizarStatusTicket('closed')"
      @updateTicket:retornar="atualizarStatusTicket('pending')"
      @updateTicket:reabrir="atualizarStatusTicket('open')"
      @abrir:modalAgendamentoMensagem="onClickOpenAgendamentoMensagem()"
    />

      <transition appear enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
        <infinite-loading v-if="cMessages.length" @infinite="onLoadMore" direction="top" :identificador="ticketFocado.id" spinner="spiral">
          <div slot="no-results">
            <div v-if="!cMessages.length">{{ $t('InforCabecalhoChat.messages.noResults') }}</div>
          </div>
          <div slot="no-more">{{ $t('InforCabecalhoChat.messages.noMoreMessages') }}</div>
        </infinite-loading>
      </transition>

<MensagemChat
  :replyingMessage.sync="replyingMessage"
  :mensagens="cMessages"
  v-if="cMessages.length && ticketFocado.id &&
        (ticketFocado.disableRespondHub ||
         !(ticketFocado.status === 'pending' && userProfile !== 'admin' && !userSpyTicket))"
  @mensagem-chat:encaminhar-mensagem="abrirModalEncaminharMensagem"
  :ativarMultiEncaminhamento.sync="ativarMultiEncaminhamento"
  :mensagensParaEncaminhar.sync="mensagensParaEncaminhar" />

      <div id="inicioListaMensagensChat"></div>

    <div
      class="absolute-center items-center"
      :class="{
        'row col text-center q-col-gutter-lg': !$q.screen.xs,
        'full-width text-center': $q.screen.xs,
      }"
      v-if="!ticketFocado.id"
    >
    <div
  style="margin-left: 30vw; display: flex; justify-content: center; align-items: center;">
  <img :src="generateMediaUrl()" style="width: 400px; height: 160px;">
</div>
<h1 class="color-light2 row col justify-center"
  :class="{
      'full-width': $q.screen.xs
    }">
</h1>
    </div>
    <div v-if="cMessages.length" class="relative-position">
      <transition appear enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
        <div v-if="scrollIcon">
          <q-btn class="vac-icon-scroll" color="white" text-color="green" icon="mdi-arrow-down" round push ripple dense @click="scrollToBottom" />
        </div>
      </transition>

      <div v-if="ticketFocado.status === 'pending' && ticketFocado.disableRespondHub" class="bg-transparent fast-messages-list flex flex-center">
        <div>
        <q-banner class="bg-amber-1 text-grey-9">
          <template v-slot:avatar>
            <q-icon name="info" color="warning" />
          </template>
          {{ $t('InforCabecalhoChat.info.commentDisabled') }}
        </q-banner>
        </div>
      </div>
    </div>

    <q-footer class="bg-white">
      <q-separator class="bg-grey-4" />
      <q-list v-if="replyingMessage"
        :style="`border-top: 1px solid #; max-height: 140px; width: 100%;`"
        style=" max-height: 100px;"
        class="q-pa-none q-py-md text-black row items-center col justify-center full-width"
        :class="{
            'bg-grey-1': !$q.dark.isActive,
            'bg-grey-10': $q.dark.isActive
          }">
        <q-item class="q-card--bordered q-pb-sm btn-rounded"
          :style="`
            width: 460px;
            min-width: 460px;
            max-width: 460px;
            max-height: 110px;
          `"
          :class="{
              'bg-blue-1': !replyingMessage.fromMe && !$q.dark.isActive,
              'bg-blue-2 text-black': !replyingMessage.fromMe && $q.dark.isActive,
              'bg-grey-2 text-black': replyingMessage.fromMe
            }">
          <q-item-section>
            <q-item-label v-if="!replyingMessage.fromMe"
              :class="{ 'text-black': $q.dark.isActive }"
              caption>
              {{ replyingMessage.contact && replyingMessage.contact.name }}
            </q-item-label>
            <q-item-label lines="4"
              v-html="formatarMensagemWhatsapp(replyingMessage.body)">
            </q-item-label>
          </q-item-section>
          <q-btn @click="replyingMessage = null"
            dense
            flat
            round
            icon="close"
            class="float-right absolute-top-right z-max"
            :disabled="loading || ticketFocado.status !== 'open'" />
        </q-item>
      </q-list>

      <q-banner class="text-grey-8"
                v-if="mensagensParaEncaminhar.length > 0">
    <span class="text-bold text-h5"> {{ mensagensParaEncaminhar.length }} </span> {{ $t('InforCabecalhoChat.info.messagesSelected') }}
    <q-separator class="bg-grey-4" />
        <q-select class="q-px-md"
                  ref="selectAutoCompleteContato"
                  autofocus
                  outlined
                  rounded
                  hide-dropdown-icon
                  :loading="loading"
                  v-model="contatosSelecionados"
                  :options="contatos"
                  input-debounce="700"
                  @filter="localizarContato"
                  use-input
                  multiple
                  fill-input
                  clearable
                  option-label="name"
                  option-value="id"
                  :label="$t('InforCabecalhoChat.contacts.search')"
                  :hint="$t('InforCabecalhoChat.contacts.searchHint') + ` (${contatosSelecionados.length}/5)`"
                  style="min-height: 56px">

          <template v-slot:selected-item="scope">
            <q-chip
              removable
              dense
              size="sm"
              @remove="scope.removeAtIndex(scope.index)"
              :tabindex="scope.tabindex"
              color="primary"
              text-color="white"
              class="q-ma-xs"
              style="height: 24px;"
            >
              <q-avatar size="16px">
                <img v-if="scope.opt.profilePicUrl" :src="scope.opt.profilePicUrl" />
                <q-icon v-else name="mdi-account" size="16px" />
              </q-avatar>
              <span class="ellipsis" style="max-width: 120px;">{{ scope.opt.name }}</span>
            </q-chip>
          </template>

          <template v-slot:option="scope">
            <q-item v-bind="scope.itemProps"
                    v-on="scope.itemEvents"
                    v-if="scope.opt.name"
                    dense>
              <q-item-section avatar>
                <q-avatar size="28px">
                  <img v-if="scope.opt.profilePicUrl" :src="scope.opt.profilePicUrl" />
                  <q-icon
                    v-else
                    name="mdi-account"
                    size="1.2em"
                    color="grey-5"
                  />
                </q-avatar>
              </q-item-section>
              <q-item-section>
                <q-item-label> {{ scope.opt.name }}</q-item-label>
                <q-item-label caption v-if="!HideNumber || (userProfile === 'admin' || userProfile === 'supervisor')">{{ scope.opt.number }}</q-item-label>
              </q-item-section>
            </q-item>
          </template>
        </q-select>
    <template v-slot:action>
      <q-btn class="bg-padrao q-px-sm" flat color="negative" :label="$t('InforCabecalhoChat.actions.cancel')" @click="cancelarMultiEncaminhamento" />
      <q-btn class="bg-padrao q-px-sm" flat color="positive" :label="$t('InforCabecalhoChat.actions.send')"
             icon="mdi-send"
             :disable="contatosSelecionados.length === 0 || contatosSelecionados.length > 5"
             @click="confirmarEncaminhamentoMensagem(mensagensParaEncaminhar)" />
    </template>
      </q-banner>

      <InputMensagem v-if="!mensagensParaEncaminhar.length"
        :mensagensRapidas="mensagensRapidas"
        :replyingMessage.sync="replyingMessage" />
      <q-resize-observer @resize="onResizeInputMensagem" />
    </q-footer>

    <q-dialog v-model="modalEncaminhamentoMensagem"
              persistent
              @hide="mensagemEncaminhamento = {}">
      <q-card :style="$q.screen.width < 770 ?
    `min-width: 98vw; max-width: 98vw; max-height: 100vh` :
    'min-width: 50vw; max-width: 50vw; max-height: 100vh'">
        <q-card-section class="q-py-sm">
          <div class="text-h6">
            {{ $t('InforCabecalhoChat.info.forwardingMessage') }}
            <q-btn flat class="bg-padrao btn-rounded float-right" color="negative" icon="close" v-close-popup />
          </div>
        </q-card-section>
        <q-separator inset />
        <q-card-section class="q-py-md" style="max-height: 300px; overflow-y: auto;">
          <MensagemChat :isShowOptions="false"
                        :replyingMessage.sync="replyingMessage"
                        :mensagens="[mensagemEncaminhamento]" />
        </q-card-section>
        <q-card-section class="q-py-xs">
          <q-select class="q-px-md"
                    ref="selectAutoCompleteContato"
                    autofocus
                    outlined
                    rounded
                    hide-dropdown-icon
                    :loading="loading"
                    v-model="contatosSelecionados"
                    :options="contatos"
                    input-debounce="700"
                    @filter="localizarContato"
                    use-input
                    multiple
                    fill-input
                    clearable
                    option-label="name"
                    option-value="id"
                    :label="$t('InforCabecalhoChat.contacts.search')"
                    :hint="$t('InforCabecalhoChat.contacts.searchHint') + ` (${contatosSelecionados.length}/5)`"
                    style="min-height: 56px">

            <template v-slot:selected-item="scope">
              <q-chip
                removable
                dense
                size="sm"
                @remove="scope.removeAtIndex(scope.index)"
                :tabindex="scope.tabindex"
                color="primary"
                text-color="white"
                class="q-ma-xs"
                style="height: 24px;"
              >
                <q-avatar size="16px">
                  <img v-if="scope.opt.profilePicUrl" :src="scope.opt.profilePicUrl" />
                  <q-icon v-else name="mdi-account" size="16px" />
                </q-avatar>
                <span class="ellipsis" style="max-width: 120px;">{{ scope.opt.name }}</span>
              </q-chip>
            </template>

            <template v-slot:option="scope">
              <q-item v-bind="scope.itemProps"
                      v-on="scope.itemEvents"
                      v-if="scope.opt.name"
                      dense>
                <q-item-section avatar>
                  <q-avatar size="28px">
                    <img v-if="scope.opt.profilePicUrl" :src="scope.opt.profilePicUrl" />
                    <q-icon
                      v-else
                      name="mdi-account"
                      size="1.2em"
                      color="grey-5"
                    />
                  </q-avatar>
                </q-item-section>
                <q-item-section>
                  <q-item-label> {{ scope.opt.name }}</q-item-label>
                  <q-item-label caption v-if="!HideNumber || (userProfile === 'admin' || userProfile === 'supervisor')">{{ scope.opt.number }}</q-item-label>
                </q-item-section>
              </q-item>
            </template>
          </q-select>

        </q-card-section>
        <q-card-actions align="right" class="q-py-sm q-px-md">
          <q-btn class="bg-padrao q-px-sm" flat color="positive" :label="$t('InforCabecalhoChat.actions.send')"
                 icon="mdi-send"
                 :disable="contatosSelecionados.length === 0 || contatosSelecionados.length > 5"
                 @click="confirmarEncaminhamentoMensagem([mensagemEncaminhamento])" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <ModalAgendamento
      :modalAgendamento="modalAgendamentoMensagem"
      :ticketFocado="ticketFocado"
      @update:modalAgendamento="modalAgendamentoMensagem = $event"
    />

  </div>
</template>
<script>
import mixinCommon from './mixinCommon'
import InforCabecalhoChat from './InforCabecalhoChat'
// import parser from 'vdata-parser'
import MensagemChat from './MensagemChat'
import InputMensagem from './InputMensagem'
import mixinAtualizarStatusTicket from './mixinAtualizarStatusTicket'
import mixinSockets from './mixinSockets'
import InfiniteLoading from 'vue-infinite-loading'
import { ListarContatos } from 'src/service/contatos'
import { EncaminharMensagem } from 'src/service/tickets'
import whatsBackground from 'src/assets/wa-background.png'
import whatsBackgroundDark from 'src/assets/wa-background-dark.jpg'
import ModalAgendamento from './ModalAgendamento'

export default {
  name: 'Chat',
  mixins: [mixinCommon, mixinAtualizarStatusTicket, mixinSockets],
  props: {
    mensagensRapidas: Array
  },
  components: {
    InforCabecalhoChat,
    MensagemChat,
    InputMensagem,
    InfiniteLoading,
    ModalAgendamento
  },
  data () {
    return {
      userProfile: 'user',
      scrollIcon: false,
      loading: false,
      exibirContato: false,
      modalAgendamentoMensagem: false,
      heigthInputMensagem: 0,
      params: {
        ticketId: null,
        pageNumber: 1
      },
      agendamentoMensagem: {
        scheduleDate: ''
      },
      replyingMessage: null,
      modalEncaminhamentoMensagem: false,
      mensagemEncaminhamento: {},
      HideNumber: null,
      userSpyTicket: null,
      mensagensParaEncaminhar: [],
      ativarMultiEncaminhamento: false,
      contatoSelecionado: {
        id: '',
        name: ''
      },
      contatos: [],
      contatosSelecionados: []
    }
  },
  computed: {
    cMessages () {
      // eslint-disable-next-line vue/no-side-effects-in-computed-properties
      // this.replyingMessage = null
      return this.mensagensTicket
    },
    style () {
      return {
        backgroundImage: this.$q.dark.isActive ? `url(${whatsBackgroundDark}) !important` : `url(${whatsBackground}) !important`,
        backgroundPosition: 'center !important',
        minHeight: '79vh'
      }
    },
    cStyleScroll () {
      const loading = 0 // this.loading ? 72 : 0
      const add = this.heigthInputMensagem + loading
      return `min-height: calc(100vh - ${62 + add + 7}px); height: calc(100vh - ${62 + add + 7}px); width: 100%`
    }
  },
  methods: {
    async listarConfiguracoes() {
      const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))
      const userSpyTicketConfig = configuracoes?.find(c => c.key === 'spyticket')
      if (userSpyTicketConfig) {
        this.userSpyTicket = userSpyTicketConfig.value === 'enabled'
      }
      const HideNumberConfig = configuracoes?.find(c => c.key === 'HideNumber')
      if (HideNumberConfig) {
        this.HideNumber = HideNumberConfig.value === 'enabled'
      }
    },
    generateMediaUrl() {
      return `${process.env.URL_API}/public/logos/atendimento.png`
    },
    onClickOpenAgendamentoMensagem() {
      this.modalAgendamentoMensagem = true
    },
    async onResizeInputMensagem (size) {
      this.heigthInputMensagem = size.height
    },
    async onLoadMore (infiniteState) {
      if (this.loading) return

      if (!this.hasMore || !this.ticketFocado?.id) {
        return infiniteState.complete()
      }

      try {
        this.loading = true
        this.params.ticketId = this.ticketFocado.id
        this.params.pageNumber += 1
        await this.$store.dispatch('LocalizarMensagensTicket', this.params)
        this.loading = false
        infiniteState.loaded()
      } catch (error) {
        infiniteState.complete()
      }
      this.loading = false
    },
    scrollArea (e) {
      this.hideOptions = true
      setTimeout(() => {
        if (!e) return
        this.scrollIcon = (e.verticalSize - (e.verticalPosition + e.verticalContainerSize)) > 2000 // e.verticalPercentage < 0.8
      }, 200)
    },
    scrollToBottom() {
      const element = document.getElementById('inicioListaMensagensChat')
      if (element) {
        element.scrollIntoView()
      }
    },
    abrirModalEncaminharMensagem (msg) {
      this.mensagemEncaminhamento = msg
      this.modalEncaminhamentoMensagem = true
    },
    async localizarContato (search, update, abort) {
      if (search.length < 2) {
        if (this.contatos.length) update(() => { this.contatos = [...this.contatos] })
        abort()
        return
      }
      this.loading = true
      const { data } = await ListarContatos({
        searchParam: search
      })

      update(() => {
        if (data.contacts.length) {
          this.contatos = data.contacts
        } else {
          this.contatos = [{}]
          // this.$refs.selectAutoCompleteContato.toggleOption({}, true)
        }
      })
      this.loading = false
    },
    cancelarMultiEncaminhamento () {
      this.mensagensParaEncaminhar = []
      this.ativarMultiEncaminhamento = false
      this.contatosSelecionados = []
    },
    confirmarEncaminhamentoMensagem (data) {
      if (this.contatosSelecionados.length === 0) {
        this.$notificarErro(this.$t('InforCabecalhoChat.notifications.error.selectContact'))
        return
      }

      if (this.contatosSelecionados.length > 5) {
        this.$notificarErro(this.$t('InforCabecalhoChat.notifications.error.maxContactsExceeded'))
        return
      }

      if (this.ticketFocado && this.ticketFocado.channel === 'hub_whatsapp') {
        this.$q.dialog({
          title: this.$t('InforCabecalhoChat.notifications.titleatencao'),
          message: this.$t('InforCabecalhoChat.notifications.avisooficial'),
          color: 'warning',
          icon: 'warning',
          persistent: true,
          ok: {
            label: this.$t('InforCabecalhoChat.notifications.entendi'),
            color: 'primary'
          }
        }).onOk(() => {
          this.processarEncaminhamento(data)
        })
      } else {
        this.processarEncaminhamento(data)
      }
    },

    processarEncaminhamento(data) {
      const promises = this.contatosSelecionados.map(contato =>
        EncaminharMensagem(data, contato)
      )

      Promise.all(promises)
        .then(results => {
          const nomes = this.contatosSelecionados.map(c => c.name).join(', ')
          this.$notificarSucesso(this.$t('InforCabecalhoChat.notifications.messageForwarded', {
            name: nomes,
            number: this.contatosSelecionados.length > 1
              ? this.$t('InforCabecalhoChat.notifications.multipleContacts')
              : this.contatosSelecionados[0].number
          }))
          this.mensagensParaEncaminhar = []
          this.ativarMultiEncaminhamento = false
          this.modalEncaminhamentoMensagem = false
          this.contatosSelecionados = []
        })
        .catch(e => {
          this.$notificarErro(this.$t('InforCabecalhoChat.notifications.error.forward'), e)
        })
    }
  },
  created () {
    this.$root.$on('scrollToBottomMessageChat', this.scrollToBottom)
    this.socketTicket()
  },
  mounted () {
    this.listarConfiguracoes()
    this.socketMessagesList()
    this.userProfile = localStorage.getItem('profile')
  },
  destroyed () {
    this.$root.$off('scrollToBottomMessageChat', this.scrollToBottom)
  }
}
</script>

<style lang="scss">
audio {
  height: 40px;
  width: 264px;
}

.mostar-btn-opcoes-chat {
  display: none;
  transition: width 2s transform 2s;
}

.q-message-text:hover .mostar-btn-opcoes-chat {
  display: block;
  float: right;
  position: absolute;
  z-index: 999;
}

.hr-text {
  line-height: 1em;
  position: relative;
  outline: 0;
  border: 0;
  color: black;
  text-align: center;
  height: 1.5em;
  opacity: 0.8;

  &:before {
    content: "";
    // use the linear-gradient for the fading effect
    // use a solid background color for a solid bar
    //background: linear-gradient(to right, transparent, #818078, transparent);
    position: absolute;
    left: 0;
    top: 50%;
    width: 100%;
    height: 1px;
  }

  &:after {
    content: attr(data-content);
    position: relative;
    display: inline-block;
    color: grey;
    font-size: 16px;
    font-weight: 600;
    padding: 0 0.5em;
    line-height: 1.5em;
    background-color: white;
    border-radius: 5px;
  }
}

.textContentItem {
  overflow-wrap: break-word;
  // padding: 3px 80px 6px 6px;
}

.textContentItemDeleted {
  font-style: italic;
  color: rgba(0, 0, 0, 0.36);
  overflow-wrap: break-word;
  // padding: 3px 80px 6px 6px;
}

.replyginContactMsgSideColor {
  flex: none;
  width: 4px;
  background-color: #35cd96;
}

.replyginSelfMsgSideColor {
  flex: none;
  width: 4px;
  background-color: #6bcbef;
}

.replyginMsgBody {
  padding: 10;
  height: auto;
  display: block;
  white-space: pre-wrap;
  overflow: hidden;
}

.messageContactName {
  display: flex;
  color: #6bcbef;
  font-weight: 500;
}

.vac-icon-scroll {
  position: absolute;
  bottom: 30px;
  right: 20px;
  box-shadow: 0 1px 1px -1px rgba(0, 0, 0, 0.2), 0 1px 1px 0 rgba(0, 0, 0, 0.14), 0 1px 2px 0 rgba(0, 0, 0, 0.12);
  display: flex;
  cursor: pointer;
  z-index: 9999;
}

// /* CSS Logilcs */
// #message-box {
//   &:empty ~ #submit-button {
//     display: none;
//   } /*when textbox empty show microhpone*/
//   &:not(:empty) ~ #voice-button {
//     display: none;
//   } /*when textbox with texy show submit button*/
// }

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}

.fade-enter,
.fade-leave-to

/* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

/* Aplicar apenas em elementos que realmente precisam de rolagem */
.scroll-custom {
  /* Garante que a barra de rolagem só aparece quando necessário */
  overflow: auto;

  /* Estilo para a barra de rolagem */
  &::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  &::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 4px;

    &:hover {
      background: #666;
    }
  }

  &::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
  }

  /* Para Firefox */
  scrollbar-width: thin;
  scrollbar-color: #888 #f1f1f1;
}
</style>
