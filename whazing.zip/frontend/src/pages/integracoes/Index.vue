<template>
  <q-page padding>
    <div class="row q-col-gutter-md">
      <!-- Facebook Integration Card -->
      <div class="col-12 col-md-4">
        <q-card>
          <q-card-section class="bg-primary text-white">
            <div class="text-h6">Facebook</div>
          </q-card-section>
          <q-card-section>
            <div class="text-body1 q-mb-md">Integración con Facebook</div>
            <q-input v-model="facebook.pageId" label="ID de Página" outlined dense class="q-mb-sm" />
            <q-input v-model="facebook.accessToken" label="Token de Acceso" outlined dense type="password" />
          </q-card-section>
          <q-card-actions align="right">
            <q-btn color="primary" label="Guardar" @click="saveFacebookConfig" />
          </q-card-actions>
        </q-card>
      </div>

      <!-- Instagram Integration Card -->
      <div class="col-12 col-md-4">
        <q-card>
          <q-card-section class="bg-pink-6 text-white">
            <div class="text-h6">Instagram</div>
          </q-card-section>
          <q-card-section>
            <div class="text-body1 q-mb-md">Integración con Instagram</div>
            <q-input v-model="instagram.username" label="Usuario" outlined dense class="q-mb-sm" />
            <q-input v-model="instagram.accessToken" label="Token de Acceso" outlined dense type="password" />
          </q-card-section>
          <q-card-actions align="right">
            <q-btn color="pink-6" label="Guardar" @click="saveInstagramConfig" />
          </q-card-actions>
        </q-card>
      </div>

      <!-- Messenger Integration Card -->
      <div class="col-12 col-md-4">
        <q-card>
          <q-card-section class="bg-blue-6 text-white">
            <div class="text-h6">Messenger</div>
          </q-card-section>
          <q-card-section>
            <div class="text-body1 q-mb-md">Integración con Messenger</div>
            <q-input v-model="messenger.pageId" label="ID de Página" outlined dense class="q-mb-sm" />
            <q-input v-model="messenger.accessToken" label="Token de Acceso" outlined dense type="password" />
          </q-card-section>
          <q-card-actions align="right">
            <q-btn color="blue-6" label="Guardar" @click="saveMessengerConfig" />
          </q-card-actions>
        </q-card>
      </div>
    </div>
  </q-page>
</template>

<script>
import { defineComponent } from 'vue'
import { saveFacebookConfig, saveInstagramConfig, saveMessengerConfig, getIntegrationsConfig } from '../../service/integracoes'

export default defineComponent({
  name: 'IntegracionesPage',
  data () {
    return {
      facebook: {
        pageId: '',
        accessToken: ''
      },
      instagram: {
        username: '',
        accessToken: ''
      },
      messenger: {
        pageId: '',
        accessToken: ''
      }
    }
  },
  methods: {
    async saveFacebookConfig () {
      try {
        await saveFacebookConfig(this.facebook)
        this.$q.notify({
          type: 'positive',
          message: 'Configuración de Facebook guardada exitosamente'
        })
      } catch (error) {
        console.error('Error al guardar la configuración de Facebook:', error)
        this.$q.notify({
          type: 'negative',
          message: 'Error al guardar la configuración de Facebook: ' + error.message
        })
      }
    },
    async saveInstagramConfig () {
      try {
        await saveInstagramConfig(this.instagram)
        this.$q.notify({
          type: 'positive',
          message: 'Configuración de Instagram guardada exitosamente'
        })
      } catch (error) {
        console.error('Error al guardar la configuración de Instagram:', error)
        this.$q.notify({
          type: 'negative',
          message: 'Error al guardar la configuración de Instagram: ' + error.message
        })
      }
    },
    async saveMessengerConfig () {
      try {
        await saveMessengerConfig(this.messenger)
        this.$q.notify({
          type: 'positive',
          message: 'Configuración de Messenger guardada exitosamente'
        })
      } catch (error) {
        console.error('Error al guardar la configuración de Messenger:', error)
        this.$q.notify({
          type: 'negative',
          message: 'Error al guardar la configuración de Messenger: ' + error.message
        })
      }
    },
    
    async loadIntegrationsConfig () {
      try {
        const { data } = await getIntegrationsConfig()
        if (data) {
          this.facebook = data.facebook || this.facebook
          this.instagram = data.instagram || this.instagram
          this.messenger = data.messenger || this.messenger
        }
      } catch (error) {
        console.error('Error al cargar las configuraciones:', error)
        this.$q.notify({
          type: 'negative',
          message: 'Error al cargar las configuraciones de integración'
        })
      }
    }
  }
})
</script>