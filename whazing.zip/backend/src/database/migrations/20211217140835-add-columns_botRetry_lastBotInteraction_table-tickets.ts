import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      // Añade la columna 'botRetries' (INTEGER) a 'Tickets'
      queryInterface.addColumn('Tickets', 'botRetries', {
        type: DataTypes.INTEGER,
        allowNull: false, // No permite nulos
        defaultValue: 0 // Valor predeterminado 0
      }),
      // Añade la columna 'lastInteractionBot' (DATE) a 'Tickets'
      queryInterface.addColumn('Tickets', 'lastInteractionBot', {
        type: DataTypes.DATE,
        allowNull: true, // Permite nulos
        defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina las columnas añadidas
    return Promise.all([
      queryInterface.removeColumn('Tickets', 'botRetries'),
      queryInterface.removeColumn('Tickets', 'lastInteractionBot')
    ]);
  }
};