import { Telegraf, Context } from 'telegraf';
import { Update } from 'telegraf/typings/core/types/typegram'; // Import Update type if needed
import { getIO } from './socket'; // Adjust path as needed
import { logger } from '../utils/logger'; // Adjust path as needed
import process from 'process'; // For listening to termination signals

interface WhatsappSession {
  id: number | string;
  name?: string;
  tenantId: number | string;
  tokenTelegram?: string;
  status?: string; // Status like 'CONNECTED', 'DISCONNECTED'
  update: (data: Partial<WhatsappSession>) => Promise<any>; // Mock or actual update method
  // Add other relevant properties from your Whatsapp model
}

interface TelegramSession {
    id: number | string; // Corresponds to WhatsappSession ID
    bot: Telegraf<Context<Update>>; // The Telegraf instance
}

const TelegramSessions: TelegramSession[] = [];

/**
 * Initializes a Telegraf (Telegram) bot instance for a given WhatsApp/Telegram session.
 * @param whatsapp - The WhatsApp/Telegram session object containing the bot token and ID.
 * @returns Promise resolving with the initialized Telegraf bot instance.
 * @throws {Error} If the Telegram token is missing.
 */
export const initTbot = async (whatsapp: WhatsappSession): Promise<Telegraf<Context<Update>>> => {
    return new Promise(async (resolve, reject) => { // Make the executor async
        try {
            const io = getIO(); // Get Socket.IO instance
            const sessionName = whatsapp.name || `Tenant_${whatsapp.tenantId}_Bot_${whatsapp.id}`; // Use name or generate one
            const { tenantId } = whatsapp;
            const botToken = whatsapp.tokenTelegram;

            if (!botToken) {
                logger.error(`Missing Telegram token for session ID ${whatsapp.id}. Cannot initialize bot.`);
                return reject(new Error('Missing Telegram token')); // Reject the promise
            }

            // Create new Telegraf instance
            const bot = new Telegraf(botToken);
            bot.id = whatsapp.id; // Assign whatsapp ID for tracking

            // Check if a session for this ID already exists
            const existingSessionIndex = TelegramSessions.findIndex(s => s.id === whatsapp.id);

            if (existingSessionIndex === -1) {
                TelegramSessions.push({ id: whatsapp.id, bot }); // Add new session
                 logger.info(`New Telegram bot session added for ID: ${whatsapp.id}`);
            } else {
                // Stop the existing bot before replacing it
                 try {
                    await TelegramSessions[existingSessionIndex].bot.stop('Existing session replaced');
                     logger.info(`Stopped existing Telegram bot for session ID: ${whatsapp.id}`);
                 } catch (stopError) {
                      logger.warn(`Error stopping existing Telegram bot for session ID ${whatsapp.id}:`, stopError);
                 }
                TelegramSessions[existingSessionIndex].bot = bot; // Update existing session
                logger.info(`Telegram bot session updated for ID: ${whatsapp.id}`);
            }

            // --- Telegraf Bot Setup ---
            // Add middleware, command handlers, etc. here
            // Example: bot.start((ctx) => ctx.reply('Welcome'));
            // Example: bot.help((ctx) => ctx.reply('Send me a sticker'));
            // Example: bot.on('sticker', (ctx) => ctx.reply('👍'));
            // Example: bot.hears('hi', (ctx) => ctx.reply('Hey there'));

            // Middleware to log updates
            bot.use((ctx, next) => {
                 logger.debug(`Received update from Telegram bot ${bot.id}:`, ctx.update);
                 return next(); // Continue processing
             });


            // Launch the bot
            await bot.launch(); // Use launch for polling or webhook

            // Update WhatsApp status in DB (assuming 'CONNECTED' means bot is running)
             await whatsapp.update({ status: 'CONNECTED', qrcode: '', session: '' });

            // Emit socket event to notify frontend
            const Bpayload = { action: 'update', session: whatsapp };
            io.to(`${tenantId}:whatsappSession`).emit(`tenant-${tenantId}-whatsappSession`, Bpayload);

            logger.info(`Telegram bot launched successfully: ${sessionName} (ID: ${whatsapp.id})`);

            // --- Graceful Shutdown Handling ---
            const stopBot = (signal: string) => {
                logger.info(`Stopping Telegram bot ${bot.id} due to ${signal}...`);
                bot.stop(signal);
            };
            process.once('SIGINT', () => stopBot('SIGINT')); // Handle Ctrl+C
            process.once('SIGTERM', () => stopBot('SIGTERM')); // Handle termination signal

            resolve(bot); // Resolve the promise with the initialized bot

        } catch (error) {
            // Update WhatsApp status to 'DISCONNECTED' on failure
            try {
                 await whatsapp.update({ status: 'DISCONNECTED', qrcode: '', session: '' });
                 const io = getIO();
                 const Bpayload = { action: 'update', session: whatsapp };
                 io.to(`${whatsapp.tenantId}:whatsappSession`).emit(`tenant-${whatsapp.tenantId}-whatsappSession`, Bpayload);
            } catch (updateError) {
                 logger.error(`Failed to update WhatsApp status after Telegram bot init error for ID ${whatsapp.id}:`, updateError);
            }

            logger.error(`Error starting Telegram bot | Error: ${error}`);
            reject(new Error('Error starting Telegram bot')); // Reject the promise
        }
    });
};

/**
 * Retrieves an initialized Telegraf bot instance for a given ID.
 * @param id - The ID of the WhatsApp/Telegram session.
 * @param isInternal - Flag to suppress logging for internal checks (default: true).
 * @returns The Telegraf bot instance or undefined if not found.
 */
export const getTbot = (id: number | string, isInternal = true): Telegraf<Context<Update>> | undefined => {
    if (!isInternal) {
        logger.info(`getTbot requested for ID: ${id}`);
    }
    const sessionIndex = TelegramSessions.findIndex(s => s.id === id);
    if (sessionIndex !== -1) {
        return TelegramSessions[sessionIndex].bot;
    }
    return undefined;
};

/**
 * Stops and removes a Telegraf bot session.
 * @param id - The ID of the session to remove.
 */
export const removeTbot = (id: number | string): void => {
    try {
        const sessionIndex = TelegramSessions.findIndex(s => s.id === id);
        if (sessionIndex !== -1) {
            const session = TelegramSessions[sessionIndex];
             logger.info(`Attempting to stop Telegram bot session ID: ${id}`);
             session.bot.stop('Bot removal requested'); // Stop the bot gracefully
            TelegramSessions.splice(sessionIndex, 1); // Remove from the sessions array
            logger.info(`Telegram bot session removed for ID: ${id}`);
        } else {
            logger.warn(`Attempted to remove non-existent Telegram bot session: ${id}`);
        }
    } catch (error) {
        logger.error(`Error removing Telegram bot session ${id}: ${error}`);
    }
};