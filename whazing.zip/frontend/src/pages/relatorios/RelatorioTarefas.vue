<template>
  <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-card bordered>
      <q-card-section>
        <div class=text-h6 q-px-sm  :class="$q.dark.isActive ? ('text-color-dark') : ''">
          Informe de Tareas </div>
      </q-card-section>
      <q-card-section class="q-pt-none">
        <fieldset>
          <legend class="q-px-sm">Filtros (Fecha de creación de la tarea)</legend>
          <div class="row q-gutter-md items-end">
            <div class="col-grow">
              <label>Inicio</label>
              <DatePick
                dense
                v-model="pesquisa.startDate"
              />
            </div>
            <div class="col-grow">
              <label>Final</label>
              <DatePick
                dense
                v-model="pesquisa.endDate"
              />
            </div>
            <div class="col-xs-12 col-sm-7 grow text-center">
              <q-select
                square
                outlined
                v-model="pesquisa.status"
                multiple
                :options="statusOptions"
                use-chips
                option-value="value"
                option-label="label"
                emit-value
                map-options
                dropdown-icon="add"
                label="Estado"
              >
                <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                  <q-item
                    v-bind="itemProps"
                    v-on="itemEvents"
                  >
                    <q-item-section>
                      <q-item-label v-html="opt.label"></q-item-label>
                    </q-item-section>
                    <q-item-section side>
                      <q-checkbox
                        :value="selected"
                        @input="toggleOption(opt)"
                      />
                    </q-item-section>
                  </q-item>
                </template>
                <template v-slot:selected-item="{opt}">
                  <q-badge
                    dense
                    square
                    color="grey-3"
                    text-color="primary"
                    class="q-ma-xs text-body1"
                    :label="opt.label"
                  >
                  </q-badge>
                </template>
              </q-select>
            </div>
            <div class="col-grow text-center">
              <q-btn
                class="q-mr-sm"
                color="info"
                label="Generar"
                icon="refresh"
                @click="gerarRelatorio"
              />
              <q-btn
                class="q-mr-sm"
                color="black"
                icon="print"
                label="Imprimir"
                @click="printReport('tRelatorioTarefas')"
              />
              <q-btn
                color="green"
                label="Excel"
                @click="exportTable('tRelatorioTarefas')"
              />
            </div>
          </div>
        </fieldset>
      </q-card-section>
    </q-card>

    <div class="row">
      <div class="col-xs-12 q-mt-sm">
        <div
          class="tableLarge q-ma-sm q-markup-table q-table__container q-table__card q-table--cell-separator q-table--flat q-table--bordered q-table--no-wrap"
          id="tRelatorioTarefas"
        >
          <table
            id="tableRelatorioTarefas"
            class="q-pb-md q-table q-tabs--dense "
          >
            <thead>
              <tr>
                <td
                  v-for="col in columns"
                  :key="col.name"
                >
                  {{ col.label }}
                </td>
              </tr>
            </thead>
            <tbody>
              <template v-if="tarefas.length > 0">
                <tr
                  v-for="row in tarefas"
                  :key="row.id"
                >
                  <td
                    v-for="col in columns"
                    :key="col.name +'-'+ row.id"
                    :class="col.class"
                    :style="col.style"
                  >
                    {{ col.format !== void 0 ? col.format(row[col.field], row) : row[col.field] }}
                  </td>
                </tr>
              </template>
              <template v-else>
                <tr>
                  <td :colspan="columns.length" class="text-center">No hay tareas para mostrar con los filtros seleccionados</td>
                </tr>
              </template>

              <template v-if="tarefas.length > 0">
                <div>
                  <div class="q-mt-md q-pa-md text-right text-weight-bold">
                    Total de tareas: {{ tarefas.length }}
                  </div>
                </div>
              </template>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <ccPrintModelLandscape
      id="slotTableRelatorioTarefas"
      :imprimirRelatorio="imprimir"
      title="Informe de Tareas"
      :styleP="`
      table { width: 100%; font-size: 10px; border-spacing: 1; border-collapse: collapse;  }
      #tableReport tr td { border:1px solid #DDD; padding-left: 10px; padding-right: 10px;  }
      #tableReport thead tr:nth-child(1) td { text-align: center; padding: 5px; font-weight: bold; color: #000; background: lightgrey; opacity: 1; }
      #lineGroup { background: #f8f8f8; line-height: 30px; }
      #quebraAgrupamentoRelatorio { border-bottom: 1px solid black !important; }
      #st_nome, #st_tipo_atendimento, #st_status_faturamento, #st_convenio, #st_nome_profissional, #st_status, #st_nome_unidade, #st_nome_profissional { width: 200px; word-wrap: normal !important; white-space: normal !important; }
      #dt_atendimento_unidade { width: 100px; text-align: center }
      `"
    >
      <template v-slot:body>
        <table class="q-pb-md q-table q-tabs--dense ">
          <thead>
            <tr>
              <td
                v-for="col in columns"
                :key="col.name"
              >
                {{ col.label }}
              </td>
            </tr>
          </thead>
          <tbody>
            <template v-if="tarefas.length > 0">
              <tr
                v-for="row in tarefas"
                :key="row.id"
              >
                <td
                  v-for="col in columns"
                  :key="col.name +'-'+ row.id"
                  :class="col.class"
                  :style="col.style"
                >
                  {{ col.format !== void 0 ? col.format(row[col.field], row) : row[col.field] }}
                </td>
              </tr>
            </template>
            <template v-else>
              <tr>
                <td :colspan="columns.length" class="text-center">No hay tareas para mostrar con los filtros seleccionados</td>
              </tr>
            </template>
          </tbody>
        </table>
      </template>
    </ccPrintModelLandscape>

  </div>
</template>

<script>
import { format, parseISO, sub } from 'date-fns'
import ccPrintModelLandscape from './ccPrintModelLandscape'
import XLSX from 'xlsx'
import { ListarTarefas, ConsultarResumoTarefas } from 'src/service/tarefas'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  name: 'RelatorioTarefas',
  components: { ccPrintModelLandscape },
  data () {
    return {
      userProfile: 'user',
      data: null,
      tarefas: [],
      statusOptions: [
        { label: 'Pendiente', value: 'pending' },
        { label: 'En progreso', value: 'in_progress' },
        { label: 'Completada', value: 'completed' },
        { label: 'Cancelada', value: 'cancelled' }
      ],
      columns: [
        { name: 'title', label: 'Título', field: 'title', align: 'left', style: 'width: 300px' },
        { name: 'description', label: 'Descripción', field: 'description', align: 'left', style: 'width: 400px' },
        { 
          name: 'status', 
          label: 'Estado', 
          field: 'status', 
          align: 'center', 
          style: 'width: 150px; text-align: center;',
          format: (value) => {
            const statusMap = {
              pending: 'Pendiente',
              in_progress: 'En progreso',
              completed: 'Completada',
              cancelled: 'Cancelada'
            }
            return statusMap[value] || value
          }
        },
        { 
          name: 'priority', 
          label: 'Prioridad', 
          field: 'priority', 
          align: 'center', 
          style: 'width: 150px; text-align: center;',
          format: (value) => {
            const priorityMap = {
              low: 'Baja',
              medium: 'Media',
              high: 'Alta'
            }
            return priorityMap[value] || value
          }
        },
        { 
          name: 'dueDate', 
          label: 'Fecha de vencimiento', 
          field: 'dueDate', 
          align: 'center', 
          style: 'width: 200px; text-align: center;',
          format: (value) => {
            if (!value) return 'No definida'
            return format(parseISO(value), 'dd/MM/yyyy')
          }
        },
        { 
          name: 'assignedTo', 
          label: 'Asignado a', 
          field: 'assignedTo', 
          align: 'left', 
          style: 'width: 200px',
          format: (value) => value || 'No asignado'
        },
        { 
          name: 'createdAt', 
          label: 'Fecha de creación', 
          field: 'createdAt', 
          align: 'center', 
          style: 'width: 200px; text-align: center;',
          format: (value) => {
            if (!value) return ''
            return format(parseISO(value), 'dd/MM/yyyy HH:mm')
          }
        },
        { 
          name: 'updatedAt', 
          label: 'Última actualización', 
          field: 'updatedAt', 
          align: 'center', 
          style: 'width: 200px; text-align: center;',
          format: (value) => {
            if (!value) return ''
            return format(parseISO(value), 'dd/MM/yyyy HH:mm')
          }
        }
      ],
      pesquisa: {
        startDate: format(sub(new Date(), { days: 30 }), 'yyyy-MM-dd'),
        endDate: format(new Date(), 'yyyy-MM-dd'),
        status: []
      },
      imprimir: false
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores retornados por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    printReport (idElemento) {
      this.imprimir = !this.imprimir
    },
    exportTable () {
      const json = XLSX.utils.table_to_sheet(
        document.getElementById('tableRelatorioTarefas'),
        { raw: true }
      )
      for (const col in json) {
        if (col[0] == 'J') {
          json[col].t = 'n'
          json[col].v = json[col].v.replace(/\./g, '').replace(',', '.')
        }
      }
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, json, 'Informe de Tareas')
      XLSX.writeFile(wb, 'informe-tareas.xlsx')
    },
    async gerarRelatorio () {
      try {
        const params = { ...this.pesquisa }
        const { data } = await ListarTarefas(params)
        this.tarefas = data.tasks || []
      } catch (error) {
        console.error(error)
        this.$notificarErro('Problema al generar el informe de tareas', error)
      }
    }
  },
  async mounted () {
    this.loadColors()
    this.userProfile = localStorage.getItem('profile')
    // No generamos el informe automáticamente para evitar carga innecesaria
    // this.gerarRelatorio()
  }
}
</script>

<style scoped>
.text-right {
  text-align: right;
}

thead tr:nth-child(1) td {
  color: #000;
  background: lightgrey;
  position: sticky;
  opacity: 1;
  top: 0;
  z-index: 1000;
}

.tableSmall {
  max-height: calc(100vh - 130px);
  height: calc(100vh - 130px);
}

.tableLarge {
  max-height: calc(100vh - 220px);
  height: calc(100vh - 220px);
}
</style>