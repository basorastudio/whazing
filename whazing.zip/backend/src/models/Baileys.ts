import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default
} from "sequelize-typescript";
import Whatsapp from "./Whatsapp"; // Assuming it relates to Whatsapp

// @Table decorator was missing in the original deobfuscated code, adding it.
@Table
class Baileys extends Model<Baileys> {
  @PrimaryKey
  @Column // Assuming ID is not auto-incrementing here based on usage
  id: number; // Or string, depending on actual usage

  @Default(null)
  @Column(DataType.TEXT) // Assuming TEXT for potentially large JSON/string data
  chats: string; // Or use DataType.JSONB if it's always JSON

  @Default(null)
  @Column(DataType.TEXT) // Assuming TEXT
  contacts: string; // Or use DataType.JSONB if it's always JSON

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @ForeignKey(() => Whatsapp)
  @Column
  whatsappId: number;

  // BelongsTo relation to Whatsapp is missing but implied by FK. Add if needed:
  // @BelongsTo(() => Whatsapp)
  // whatsapp: Whatsapp;
}

export default Baileys;
