import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'statusImportMessages' column to the 'Whatsapps' table
    // Stores the status of the message import process.
    await queryInterface.addColumn(
      'Whatsapps',              // Table name
      'statusImportMessages',   // New column name
      {
        type: DataTypes.STRING,
        allowNull: true, // Allow null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'statusImportMessages' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps',              // Table name
      'statusImportMessages'    // Column name to remove
    );
  }
};

export = migration;