import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add multiple AI-related columns to 'QueueIntegrations'
    await queryInterface.addColumn("QueueIntegrations", "aiModel", {
      type: DataTypes.STRING,
      allowNull: true
    });
    await queryInterface.addColumn("QueueIntegrations", "apiKey", {
      type: DataTypes.STRING,
      allowNull: true
    });
    await queryInterface.addColumn("QueueIntegrations", "maxMessages", {
      type: DataTypes.INTEGER,
      defaultValue: 10
    });
    await queryInterface.addColumn("QueueIntegrations", "maxTokens", {
      type: DataTypes.INTEGER,
      defaultValue: 100
    });
    await queryInterface.addColumn("QueueIntegrations", "prompt", {
      // Assuming prompt column based on context, wasn't explicitly in the switch map derived from obfuscation, might need review based on app logic
      type: DataTypes.TEXT, // Use TEXT for potentially long prompts
      allowNull: true
    });
    await queryInterface.addColumn("QueueIntegrations", "temperature", {
      type: DataTypes.FLOAT,
      defaultValue: 1
    });
    await queryInterface.addColumn("QueueIntegrations", "voice", {
      type: DataTypes.STRING,
      allowNull: true
    });
    await queryInterface.addColumn("QueueIntegrations", "voiceKey", {
      type: DataTypes.STRING,
      allowNull: true
    });
    await queryInterface.addColumn("QueueIntegrations", "voiceRegion", {
      type: DataTypes.STRING,
      allowNull: true
    });
    // Note: queueId was also in the original obfuscated logic but seems redundant if this table is QueueIntegrations already linked to Queues. Kept out unless required.
    // await queryInterface.addColumn('QueueIntegrations', 'queueId', {
    //   type: DataTypes.INTEGER,
    //   allowNull: true,
    //   references: { model: 'Queues', key: 'id' },
    // });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added AI-related columns
    await queryInterface.removeColumn("QueueIntegrations", "aiModel");
    await queryInterface.removeColumn("QueueIntegrations", "apiKey");
    await queryInterface.removeColumn("QueueIntegrations", "maxMessages");
    await queryInterface.removeColumn("QueueIntegrations", "maxTokens");
    await queryInterface.removeColumn("QueueIntegrations", "prompt"); // Assuming prompt column was added
    await queryInterface.removeColumn("QueueIntegrations", "temperature");
    await queryInterface.removeColumn("QueueIntegrations", "voice");
    await queryInterface.removeColumn("QueueIntegrations", "voiceKey");
    await queryInterface.removeColumn("QueueIntegrations", "voiceRegion");
    // await queryInterface.removeColumn('QueueIntegrations', 'queueId'); // If queueId was added
  }
};

export = migration;
