import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'ratingInvalid' column to the 'Whatsapps' table
    // Stores the message text sent if an invalid rating is received.
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "ratingInvalid", // New column name
      {
        type: DataTypes.TEXT // TEXT for potentially long messages
        // allowNull defaults to true
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'ratingInvalid' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      "Whatsapps", // Table name
      "ratingInvalid" // Column name to remove
    );
  }
};

export = migration;
