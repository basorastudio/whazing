import { MessengerClient } from "messaging-api-messenger";
import process from "process";
import AppError from "../errors/AppError"; // Adjust path as needed
import { logger } from "../utils/logger"; // Adjust path as needed

interface Session {
  id: number | string; // Or just number/string depending on usage
  // Add other properties if the session object holds more than just the client
  client: MessengerClient;
}

const sessionsMessenger: Session[] = [];

/**
 * Initializes a Messenger bot client for a given WhatsApp session/connection.
 * @param whatsapp - The WhatsApp connection object containing credentials.
 * @returns Promise resolving with the initialized MessengerClient.
 */
export const initMessengerBot = async (whatsapp: {
  id: number | string;
  tokenAPI?: string;
  facebookAppId?: string;
}): Promise<MessengerClient> => {
  try {
    const accessToken = whatsapp.tokenAPI; // Assuming tokenAPI maps to accessToken
    const appId = process.env.FACEBOOK_APP_ID || whatsapp.facebookAppId; // Use env var first, then whatsapp record

    if (!accessToken) {
      throw new Error("Not token configured"); // Specific error message
    }
    if (!appId) {
      throw new Error("Not App Id configured"); // Specific error message for App ID
    }

    const client = new MessengerClient({
      accessToken: accessToken,
      appId: appId // Pass App ID if required by the library version
      // appSecret: process.env.FACEBOOK_APP_SECRET, // Include if needed
    });

    client.id = whatsapp.id; // Attach whatsapp ID to the client instance for tracking

    // Check if session already exists
    const sessionIndex = sessionsMessenger.findIndex(s => s.id === whatsapp.id);

    if (sessionIndex === -1) {
      sessionsMessenger.push({ id: whatsapp.id, client }); // Add new session
    } else {
      sessionsMessenger[sessionIndex].client = client; // Update existing session client
      logger.info(`MessengerBot session updated for ID: ${whatsapp.id}`);
    }

    logger.info(`MessengerBot initialized successfully for ID: ${whatsapp.id}`);
    return client;
  } catch (error: any) {
    logger.error(`initMessengerBot error | Error: ${error}`);
    // Throw a specific AppError for better handling upstream
    throw new AppError(
      `Error initializing Messenger Bot: ${error.message || error}`,
      500
    );
  }
};

/**
 * Retrieves an initialized Messenger bot client for a given ID.
 * @param id - The ID of the WhatsApp/Messenger session.
 * @returns The MessengerClient instance or undefined if not found.
 */
export const getMessengerBot = (
  id: number | string
): MessengerClient | undefined => {
  const sessionIndex = sessionsMessenger.findIndex(s => s.id == id); // Use loose equality for potential type mismatch
  if (sessionIndex !== -1) {
    return sessionsMessenger[sessionIndex].client;
  }
  return undefined;
};
