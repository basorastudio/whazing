<template>
  <div class="q-pa-sm"
  :class="{'bg-grey-9' : $q.dark.isActive}">
 <vencimento />
    <q-card class="dashboard-header ">
      <q-card-section class="row justify-between items-center">
        <div class="dashboard-title col-xs-12 col-md-3 text-h4 text-bold text-md-left"
             :class="{'color-dark3' : $q.dark.isActive}">
          Painel de Controle
        </div>
        <div class="dashboard-header-inputs col-xs-12 col-md-9 justify-end flex q-gutter-sm text-center text-md-right q-my-md rdsPainelDate">
          <div class="q-mb-sm">
            <q-datetime-picker
              style="width: 200px"
              class="color-light1"
              :class="$q.dark.isActive ? 'color-dark1' : ''"
              dense
              hide-bottom-space
              outlined
              stack-label
              bottom-slots
              label="Data/Hora Agendamento"
              mode="date"
              color="primary"
              format24h
              v-model="params.startDate"
            />
          </div>
          <div class="q-mb-sm">
            <q-datetime-picker
              style="width: 200px"
              dense
              hide-bottom-space
              outlined
              stack-label
              bottom-slots
              label="Data/Hora Agendamento"
              mode="date"
              color="primary"
              format24h
              v-model="params.endDate"
            />
          </div>
          <q-btn
            class="generate-button q-mb-sm btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
            flat
            icon="refresh"
            label="Gerar"
            @click="getDashData"
          />
          <q-toggle
            v-if="grupoAtivo === 'disabled'"
            v-model="toggleValue"
            checked-icon="check"
            unchecked-icon="clear"
            @input="handleGroups"
            :color="toggleValue ? 'green' : 'negative'"
            size="md"
            >
            <q-tooltip anchor="bottom middle" self="top middle">
              <span>Filtrar Grupos</span>
            </q-tooltip>
          </q-toggle>

        </div>

      </q-card-section>
    </q-card>

    <div class="row justify-center" v-if="!premium">
      <!-- Seção de solicitação de doação -->
      <div class="q-mt-lg q-pa-md text-center">
        <q-card class="donation-card" flat bordered :class="{'bg-dark color-dark3' : $q.dark.isActive}">
          <q-card-section class="row items-center justify-around" >
            <!-- Texto -->
            <div class="text-left" style="max-width: 50%;">
              <div class="text-h6">
                Apoie nossa Plataforma
              </div>
              <div class="text-body q-mt-sm">
                Mantenha a versão gratuita disponível para todos com uma doação via Pix. Escaneie o QR Code ao lado.
              </div>
            </div>
            <!-- Imagem -->
            <img src="https://raw.githubusercontent.com/cleitonme/Whazing-SaaS/main/donate.jpg"
                 alt="QR Code para doação via Pix"
                 class="donation-image">
          </q-card-section>
        </q-card>
      </div>
    </div>

    <div class="row justify-center" v-if="userProfile === 'admin'">
      <q-btn @click="fecharTicketsEmMassa"
             flat
             icon="mdi-close"
             label="Fechamento tickets em Massa"
             class="generate-button btn-rounded-50"
             :class="{'generate-button-dark' : $q.dark.isActive}">

        <q-tooltip content-class="text-bold">
          Fechamento tickets em Massa
        </q-tooltip>
      </q-btn>

      <q-btn @click="apagarTicketsMassa"
             flat
             icon="mdi-close"
             label="Apagar tickets em Massa"
             class="generate-button btn-rounded-50"
             :class="{'generate-button-dark' : $q.dark.isActive}">

        <q-tooltip content-class="text-bold">
          Apagar tickets em Massa
        </q-tooltip>
      </q-btn>

    </div>
    <q-card class="q-my-md" style="box-shadow: none !important; background-color: transparent" v-if="toggleValue === false">
      <q-card class="dashboard-container-cards">
      <q-card-section class="dashboard-cards q-pa-md q-mb-sm">
        <div class="row justify-center ">
          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Total Atendimentos</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ ticketsAndTimes.qtd_total_atendimentos }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-account-multiple" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              class="my-card full-height"
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Ativo</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ ticketsAndTimes.qtd_demanda_ativa }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-account-check" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              class="my-card full-height"
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Receptivo</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number text-h4 text-bold text-center my-card-content">
                      {{ ticketsAndTimes.qtd_demanda_receptiva }}

                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-phone-incoming" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              class="my-card full-height"
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Novos Contatos</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number text-h4 text-bold text-center my-card-content">
                      {{ ticketsAndTimes.new_contacts }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-account-plus" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">
            <q-card flat bordered class="my-card full-height"
            :class="{'bg-dark color-dark3' : $q.dark.isActive}">
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Tempo Médio de Atendimento</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number text-h5 text-bold text-center my-card-content">
                      {{ cTmaFormat }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-clock-outline" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">

            <q-card flat bordered class="my-card full-height"
            :class="{'bg-dark color-dark3' : $q.dark.isActive}">
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Tempo Médio 1º Resposta</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number text-h5 text-bold text-center">
                  {{ cTmeFormat }}
                  </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-timer-sand" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
        </div>
      </q-card-section>
    </q-card>
    </q-card>
    <div class="row">
      <div
        class="col-xs-12"
        :class="userProfile === 'user' ? 'col-sm-6' : 'col-sm-3'">
        <q-card>
          <q-card-section class="q-pa-md">
            <ApexChart
              ref="ChartTicketsChannels"
              type="pie"
              height="300"
              width="100%"
              :options="ticketsChannelsOptions"
              :series="ticketsChannelsOptions.series"
            />
          </q-card-section>
        </q-card>
      </div>
      <div
        class="col-xs-12"
        :class="userProfile === 'user' ? 'col-sm-6' : 'col-sm-3'">
        <q-card>
          <q-card-section class="q-pa-md">
            <ApexChart
              ref="ChartTicketsQueue"
              type="pie"
              height="300"
              width="100%"
              :options="ticketsQueueOptions"
              :series="ticketsQueueOptions.series"
            />
          </q-card-section>
        </q-card>
      </div>
      <div class="col-xs-12 col-sm-3" v-if="userProfile === 'admin' || userProfile === 'supervisor'">
        <q-card>
          <q-card-section class="q-pa-md">
            <ApexChart
              ref="ChartTicketsUser"
              type="pie"
              height="300"
              width="100%"
              :options="ticketsUserOptions"
              :series="ticketsUserOptions.series"
            />
          </q-card-section>
        </q-card>
      </div>
      <div class="col-xs-12 col-sm-3" v-if="userProfile === 'admin' || userProfile === 'supervisor'">
        <q-card>
          <q-card-section class="q-pa-md">
            <ApexChart
              ref="ChartTicketsStatus"
              type="pie"
              height="300"
              width="100%"
              :options="ticketsStatusOptions"
              :series="ticketsStatusOptions.series"
            />
          </q-card-section>
        </q-card>
      </div>

    </div>
    <q-card class="q-my-md">
      <q-card-section>
        <ApexChart
          ref="ChartTicketsEvolutionChannels"
          type="bar"
          height="300"
          width="100%"
          :options="ticketsEvolutionChannelsOptions"
          :series="ticketsEvolutionChannelsOptions.series"
        />
      </q-card-section>
    </q-card>
    <q-card class="q-my-md">
      <q-card-section class="q-pa-md">
        <ApexChart
          ref="ChartTicketsEvolutionByPeriod"
          type="line"
          height="300"
          :options="ticketsEvolutionByPeriodOptions"
          :series="ticketsEvolutionByPeriodOptions.series"
        />
      </q-card-section>
    </q-card>
    <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-card class="q-my-md">
      <q-card-section>
        <ApexChart
          ref="ChartTicketsEvolutionByHour"
          type="line"
        height="300"
        :options="ticketsEvolutionByHourOptions"
        :series="ticketsEvolutionByHourOptions.series"
        />
      </q-card-section>
    </q-card>

      <q-card>
        <q-card-section class="q-pa-md">
          <ApexChart
            ref="ChartTicketsActiveUsers"
            type="bar"
            height="300"
            width="100%"
            :options="ticketsActiveUsersOptions"
            :series="ticketsActiveUsersOptions.series"
          />
        </q-card-section>
      </q-card>
    </div>
    <q-card class="q-my-md q-pa-sm" v-if="toggleValue === false">
    <q-card-section class="q-pa-md">
      <q-table
        title="Desempenho da Equipe"
        :data="ticketsPerUsersDetail"
        :columns="TicketsPerUsersDetailColumn"
        row-key="email"
        :pagination.sync="paginationTableUser"
        :rows-per-page-options="[0]"
        bordered
        flat
        hide-bottom
      >
        <template v-slot:body-cell-name="props">
          <q-td :props="props">
            <div class="row items-center">
              <!-- Bolinha indicando o status -->
              <div
                class="q-mr-sm"
                :style="{
          width: '10px',
          height: '10px',
          borderRadius: '50%',
          backgroundColor: props.row.isOnline ? 'green' : 'red',
        }"
              ></div>
              <!-- Informações do usuário -->
              <div>
                <div class="text-bold">{{ props.row.name || 'Sem usuário atribuído' }}</div>
                <div class="text-caption">{{ props.row.email }}</div>
              </div>
            </div>
          </q-td>
        </template>

<template v-slot:body-cell-avaliacao="props">
  <q-td :props="props">
    <q-rating
      v-model="props.row.avaliacao"
      size="1.5em"
      color="yellow"
      readonly
    />
  </q-td>
</template>
      </q-table>
      "Os tickets listados como 'Sem usuário atribuído' são aqueles que não tiveram um atendente designado, Usuarios que não tiverem nenhum atendimento no periodo não aparece na lista."
    </q-card-section>
  </q-card>

    <q-dialog v-model="modaFecharMassa"
              @hide="modaFecharMassa = false"
              persistent>
      <q-card class="container-rounded-10 modal-container q-pa-lg">

        <q-card-section class="row items-center justify-between q-mt-md q-px-none">
          <div class="text-h6 text-center font-family-main col">
            Fechar Tickets em Massa
          </div>
          <q-btn flat color="negative" v-close-popup icon="eva-close" />
        </q-card-section>

        <div class="container-border container-rounded-10">

          <q-card-section class="row flex-gap-1 q-col-gutter-sm">
            <div class="text-h6 font-family-main">
              Atenção, essa é uma ação em massa e não poderá ser revertida.
            </div>
            <div class="flex-gap-1 full-width row q-col-gutter-sm">
              <div class="full-width">
                <q-datetime-picker dense rounded outlined format24h mode="datetime" label="Data e hora Inicial criação ticket"
                                   class="row col"
                                   v-model="fecharTickets.dateStart" />
              </div>
              <div class="full-width">
                <q-datetime-picker dense rounded outlined format24h mode="datetime" label="Data e hora Final criação ticket"
                                   class="row col"
                                   v-model="fecharTickets.dateEnd" />
              </div>
              <div class="full-width">
                <q-select
                  rounded
                  outlined
                  dense
                  v-model="fecharTickets.status"
                  :options="optionsTickets"
                  option-value="value"
                  option-label="label"
                  emit-value
                  map-options
                  label="Status"
                />
              </div>
              <div class="full-width">
                <q-select
                  rounded
                  outlined
                  dense
                  label="Canal"
                  v-model="fecharTickets.whatsappId"
                  :options="listaWhats"
                  map-options
                  emit-value
                  option-value="id"
                  option-label="name"
                  clearable
                >
              </div>
              <div class="full-width">
                <q-checkbox
                  v-model="fecharTickets.isGroup"
                  label="Grupo"
                />
              </div>
            </div>
          </q-card-section>
        </div>

        <q-card-actions align="right">
          <q-btn
            label="Cancelar"
            class="q-px-md q-mr-sm btn-rounded-50"
            color="negative"
            v-close-popup
          />
          <q-btn
            label="Executar"
            class="q-ml-lg q-px-md btn-rounded-50"
            color="primary"
            icon="eva-save-outline"
            @click="handleFecharMassa"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <q-dialog v-model="modarApagarMassa"
              @hide="modarApagarMassa = false"
              persistent>
      <q-card class="container-rounded-10 modal-container q-pa-lg">

        <q-card-section class="row items-center justify-between q-mt-md q-px-none">
          <div class="text-h6 text-center font-family-main col">
            Apagar Tickets em Massa
          </div>
          <q-btn flat color="negative" v-close-popup icon="eva-close" />
        </q-card-section>

        <div class="container-border container-rounded-10">

          <q-card-section class="row flex-gap-1 q-col-gutter-sm">
            <div class="text-h6 font-family-main">
              Atenção, essa é uma ação em massa e não poderá ser revertida.
            </div>
            <div class="flex-gap-1 full-width row q-col-gutter-sm">
              <div class="full-width">
                <q-datetime-picker dense rounded outlined format24h mode="datetime" label="Data e hora Inicial criação ticket"
                                   class="row col"
                                   v-model="apagarTickets.dateStart" />
              </div>
              <div class="full-width">
                <q-datetime-picker dense rounded outlined format24h mode="datetime" label="Data e hora Final criação ticket"
                                   class="row col"
                                   v-model="apagarTickets.dateEnd" />
              </div>
              <div class="full-width">
                <q-select
                  rounded
                  outlined
                  dense
                  v-model="apagarTickets.status"
                  :options="optionsTicketsApagar"
                  option-value="value"
                  option-label="label"
                  emit-value
                  map-options
                  label="Status"
                />
              </div>
              <div class="full-width">
                <q-select
                  rounded
                  outlined
                  dense
                  label="Canal"
                  v-model="apagarTickets.whatsappId"
                  :options="listaWhats"
                  map-options
                  emit-value
                  option-value="id"
                  option-label="name"
                  clearable
                >
              </div>
              <div class="full-width">
                <q-checkbox
                  v-model="apagarTickets.isGroup"
                  label="Grupo"
                />
              </div>
            </div>
          </q-card-section>
        </div>

        <q-card-actions align="right">
          <q-btn
            label="Cancelar"
            class="q-px-md q-mr-sm btn-rounded-50"
            color="negative"
            v-close-popup
          />
          <q-btn
            label="Executar"
            class="q-ml-lg q-px-md btn-rounded-50"
            color="primary"
            icon="eva-save-outline"
            @click="handleApagarMassa"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
import { groupBy } from 'lodash'
import { ListarFilas } from 'src/service/filas'
import { ListarUsuarios } from 'src/service/user'
import {
  GetDashTicketsAndTimes,
  GetDashTicketsChannels,
  GetDashTicketsEvolutionChannels,
  GetDashTicketsQueue,
  GetDashTicketsEvolutionByPeriod,
  GetDashTicketsPerUsersDetail,
  GetDashTicketsEvolutionByHour,
  GetDashTicketsUser,
  GetDashTicketsActiveUsers,
  GetDashTicketsStatus
} from 'src/service/estatisticas'
import { ListarConfiguracoes } from 'src/service/configuracoes'
import { subDays, format, formatDuration, differenceInDays, sub } from 'date-fns'
import ApexChart from 'vue-apexcharts'
import { QIcon } from 'quasar'
import vencimento from '../../components/vencimentodash.vue'
import { ApagaremMassaTickets, FecharemMassaTickets } from 'src/service/tickets'
import { ListarWhatsapps } from 'src/service/sessoesWhatsapp'
import { ListarCores, Listarp } from 'src/service/configuracoesgeneral'

export default {
  name: 'IndexDashboard',
  components: { ApexChart, QIcon, vencimento },
  data () {
    return {
      listaWhats: [],
      fecharTickets: {
        dateStart: format(sub(new Date(), { days: 30 }), 'yyyy-MM-dd'),
        dateEnd: format(new Date(), 'yyyy-MM-dd'),
        optionsTickets: [
          { value: 'open', label: 'Aberto' },
          { value: 'pending', label: 'Pendente' }
        ],
        listaWhats: [],
        isGroup: false
      },
      modaFecharMassa: false,
      modarApagarMassa: false,
      premium: true,
      optionsTickets: [
        { value: 'open', label: 'Aberto' },
        { value: 'pending', label: 'Pendente' }
      ],
      optionsTicketsApagar: [
        { value: 'open', label: 'Aberto' },
        { value: 'pending', label: 'Pendente' },
        { value: 'closed', label: 'Fechado' }
      ],
      apagarTickets: {
        dateStart: format(sub(new Date(), { days: 30 }), 'yyyy-MM-dd'),
        dateEnd: format(new Date(), 'yyyy-MM-dd'),
        optionsTickets: [
          { value: 'open', label: 'Aberto' },
          { value: 'pending', label: 'Pendente' },
          { value: 'closed', label: 'Fechado' }
        ],
        listaWhats: [],
        isGroup: false
      },
      userProfile: 'user',
      confiWidth: {
        horizontal: false,
        width: this.$q.screen.width
      },
      toggleValue: false,
      grupoAtivo: 'disabled',
      params: {
        startDate: format(subDays(new Date(), 6), 'yyyy-MM-dd'),
        endDate: format(new Date(), 'yyyy-MM-dd'),
        queuesIds: [],
        userIds: [],
        isGroup: false
      },
      paginationTableUser: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      filas: [],
      usuarios: [],
      ticketsChannels: [],
      ticketsChannelsOptions: {
        // colors: ['#00E396', '#ff2a00','#FEB019'],
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 1000
        },
        fill: {
          type: 'gradient',
          gradient: {
            shade: 'dark',
            type: 'vertical',
            shadeIntensity: 0.05,
            inverseColors: false,
            opacityFrom: 1,
            opacityTo: 0.9,
            stops: [0, 100]
          }
        },
        chart: {
          toolbar: {
            show: true
          }
        },
        legend: {
          position: 'bottom'
        },
        title: {
          text: 'Atendimento por canal'
        },
        noData: {
          text: 'Sem dados aqui!',
          align: 'center',
          verticalAlign: 'middle',
          offsetX: 0,
          offsetY: 0,
          style: {
            color: undefined,
            fontSize: '14px',
            fontFamily: undefined
          }
        },
        series: [],
        labels: [],
        theme: {
          mode: 'light',
          palette: 'palette1'
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -10
            }
          }
        },
        dataLabels: {
          enabled: true,
          textAnchor: 'middle',
          style: {
            fontSize: '16px',
            offsetY: '150',
            fontFamily: 'Helvetica, Arial, sans-serif'
          },
          offsetX: 0
        }
      },
      ticketsStatus: [],
      ticketsStatusOptions: {
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 1000
        },
        fill: {
          type: 'gradient',
          gradient: {
            shade: 'dark',
            type: 'vertical',
            shadeIntensity: 0.05,
            inverseColors: false,
            opacityFrom: 1,
            opacityTo: 0.9,
            stops: [0, 100]
          }
        },
        chart: {
          toolbar: {
            show: true
          }
        },
        legend: {
          position: 'bottom'
        },
        title: {
          text: 'Status dos Tickets(Ao Vivo)'
        },
        noData: {
          text: 'Sem dados aqui!',
          align: 'center',
          verticalAlign: 'middle',
          offsetX: 0,
          offsetY: 0,
          style: {
            color: undefined,
            fontSize: '14px',
            fontFamily: undefined
          }
        },
        series: [],
        labels: [],
        theme: {
          mode: 'light',
          palette: 'palette1'
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -10
            }
          }
        },
        dataLabels: {
          enabled: true,
          textAnchor: 'middle',
          style: {
            fontSize: '16px',
            offsetY: '150',
            fontFamily: 'Helvetica, Arial, sans-serif'
          },
          offsetX: 0
        }
      },
      ticketsActiveUsers: [],
      ticketsActiveUsersOptions: {
        chart: {
          type: 'bar',
          toolbar: { show: true }
        },
        title: { text: 'Atendimentos Ativos por Usuário (AO VIVO)' },
        xaxis: {
          categories: [],
          title: { text: 'Usuários' }
        },
        yaxis: {
          title: { text: 'Atendimentos' }
        },
        series: []
      },
      ticketsQueue: [],
      ticketsQueueOptions: {
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 1000
        },
        fill: {
          type: 'gradient',
          gradient: {
            shade: 'dark',
            type: 'vertical',
            shadeIntensity: 0.05,
            inverseColors: false,
            opacityFrom: 1,
            opacityTo: 0.9,
            stops: [0, 100]
          }
        },
        chart: {
          toolbar: {
            show: true
          }
        },
        legend: {
          position: 'bottom'
        },
        title: {
          text: 'Atendimento por fila'
        },
        noData: {
          text: 'Sem dados aqui!',
          align: 'center',
          verticalAlign: 'middle',
          offsetX: 0,
          offsetY: 0,
          style: {
            color: undefined,
            fontSize: '14px',
            fontFamily: undefined
          }
        },
        series: [],
        labels: [],
        theme: {
          mode: 'light',
          palette: 'palette1'
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -10
            }
          }
        },
        dataLabels: {
          enabled: true,
          textAnchor: 'middle',
          style: {
            fontSize: '16px',
            offsetY: '150',
            fontFamily: 'Helvetica, Arial, sans-serif'
          },
          offsetX: 0
        }
      },
      ticketsEvolutionChannels: [],
      ticketsEvolutionChannelsOptions: {
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 1000
        },
        chart: {
          type: 'bar',
          stacked: true,
          stackType: '100%',
          toolbar: {
            tools: {
              download: true,
              selection: false,
              zoom: false,
              zoomin: false,
              zoomout: false,
              pan: false,
              reset: false | '<img src="/static/icons/reset.png" width="20">'
            }

          }
        },
        theme: {
          mode: 'light',
          palette: 'palette1'
        },
        grid: {
          show: true,
          strokeDashArray: 0
        },
        fill: {
          type: 'gradient',
          gradient: {
            shade: 'dark',
            type: 'vertical',
            shadeIntensity: 0.05,
            inverseColors: false,
            opacityFrom: 1,
            opacityTo: 0.9,
            stops: [0, 100]
          }
        },
        dataLabels: {
          enabled: true
        },
        title: {
          text: 'Evolução por canal',
          align: 'left'
        },
        stroke: {
          width: 0
        },
        xaxis: {
          type: 'category',
          categories: [],
          tickPlacement: 'on'
        },
        yaxis: {
          title: {
            text: 'Atendimentos',
            style: {
              color: '#FFF'
            }
          }
        },
        tooltip: {
          y: {
            formatter: function (val) {
              return Number(val).toFixed(0)
            }
          }
        }
      },
      ticketsUser: [],
      ticketsUserOptions: {
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 1000
        },
        fill: {
          type: 'gradient',
          gradient: {
            shade: 'dark',
            type: 'vertical',
            shadeIntensity: 0.05,
            inverseColors: false,
            opacityFrom: 1,
            opacityTo: 0.9,
            stops: [0, 100]
          }
        },
        chart: {
          toolbar: {
            show: true
          }
        },
        legend: {
          position: 'bottom'
        },
        title: {
          text: 'Atendimento por usuário'
        },
        noData: {
          text: 'Sem dados aqui!',
          align: 'center',
          verticalAlign: 'middle',
          offsetX: 0,
          offsetY: 0,
          style: {
            color: undefined,
            fontSize: '14px',
            fontFamily: undefined
          }
        },
        series: [],
        labels: [],
        theme: {
          mode: 'light',
          palette: 'palette1'
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -10
            }
          }
        },
        dataLabels: {
          enabled: true,
          textAnchor: 'middle',
          style: {
            fontSize: '16px',
            offsetY: '150',
            fontFamily: 'Helvetica, Arial, sans-serif'
          },
          offsetX: 0
        }
      },
      ticketsEvolutionByHour: [],
      ticketsEvolutionByHourOptions: {
        chart: {
          type: 'line',
          toolbar: {
            tools: {
              download: true,
              selection: false,
              zoom: false,
              zoomin: false,
              zoomout: false,
              pan: false,
              reset: false
            }
          }
        },
        grid: {
          show: true
        },
        dataLabels: {
          enabled: true
        },
        stroke: {
          curve: 'smooth'
        },
        xaxis: {
          categories: [],
          title: {
            text: 'Horário'
          }
        },
        yaxis: {
          title: {
            text: 'Tickets'
          }
        },
        title: {
          text: 'Novos tickets por hora',
          align: 'left'
        },
        tooltip: {
          shared: false,
          y: {
            formatter: (val) => val.toFixed(0)
          }
        },
        series: []
      },
      ticketsEvolutionByPeriod: [],
      ticketsEvolutionByPeriodOptions: {
        // colors: ['#008FFB', '#00E396', '#FEB019'],
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 1000
        },
        theme: {
          mode: 'light',
          palette: 'palette1'
        },
        chart: {
          toolbar: {
            tools: {
              download: true,
              selection: false,
              zoom: false,
              zoomin: false,
              zoomout: false,
              pan: false,
              reset: false | '<img src="/static/icons/reset.png" width="20">'
            }

          }
        },
        grid: {
          show: true,
          strokeDashArray: 0,
          xaxis: {
            lines: {
              show: true
            }
          }
        },
        stroke: {
          width: [4, 4, 4]
        },
        fill: {
          type: 'gradient',
          gradient: {
            shade: 'dark',
            type: 'vertical',
            shadeIntensity: 0.05,
            inverseColors: false,
            opacityFrom: 1,
            opacityTo: 0.9,
            stops: [0, 100]
          }
        },
        title: {
          text: 'Evolução atendimentos',
          align: 'left'
        },
        dataLabels: {
          enabled: true,
          enabledOnSeries: [1]
        },
        xaxis: {
          categories: []
        },
        yaxis: {
          title: {
            text: 'Atendimentos'
          }
        },
        tooltip: {
          shared: false,
          x: {
            show: false
          },
          y: {
            formatter: function (val) {
              return Number(val).toFixed(0)
            }
          }
        },
        legend: {
          show: false
        }
      },
      ticketsAndTimes: {
        qtd_total_atendimentos: null,
        qtd_demanda_ativa: null,
        qtd_demanda_receptiva: null,
        tma: null,
        tme: null
      },

      ticketsPerUsersDetail: [],
      TicketsPerUsersDetailColumn: [
        {
          name: 'name',
          label: 'Usuário',
          field: 'name',
          align: 'left',
          style: 'width: 300px;',
          format: (v, r) => {
            return v ? `${r.name} | ${r.email}` : 'Não informado'
          }
        },
        {
          name: 'qtd_pendentes',
          label: 'Pendentes',
          field: 'qtd_pendentes'
        },
        {
          name: 'qtd_em_atendimento',
          label: 'Atendendo',
          field: 'qtd_em_atendimento'
        },
        {
          name: 'qtd_resolvidos',
          label: 'Finalizados',
          field: 'qtd_resolvidos'
        },
        {
          name: 'qtd_por_usuario',
          label: 'Total',
          field: 'qtd_por_usuario'
        },
        {
          name: 'tme',
          label: 'T.M.E',
          field: 'tme',
          align: 'center',
          headerStyle: 'text-align: center !important',
          format: v => {
            return formatDuration(v) || ''
          }
        },
        {
          name: 'tma',
          label: 'T.M.A',
          field: 'tma',
          align: 'center',
          headerStyle: 'text-align: center !important',
          format: v => {
            return formatDuration(v) || ''
          }
        },
        {
          name: 'avaliacao',
          label: 'Avaliação',
          field: 'avaliacao',
          align: 'center',
          headerStyle: 'text-align: center !important'
        }
      ]
    }
  },
  watch: {
    '$q.dark.isActive' () {
      // necessário para carregar os gráficos com a alterçaão do mode (dark/light)
      this.$router.go()
    },
    '$q.screen.width' () {
      // necessário para carregar os gráficos com a alterçaão do mode (dark/light)
      this.setConfigWidth()
    }
  },
  computed: {
    cTmaFormat () {
      const tma = this.ticketsAndTimes.tma || {}
      return formatDuration(tma) || ''
    },
    cTmeFormat () {
      const tme = this.ticketsAndTimes.tme || {}
      return formatDuration(tme) || ''
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)

        this.setupColor()
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    },
    setupColor() {
      const mode = this.$q.dark.isActive ? 'dark' : 'light'
      const primaryColor = getComputedStyle(document.documentElement)
        .getPropertyValue('--q-cor1')
        .trim()
      const convertedColor = primaryColor.length === 9 ? primaryColor.slice(0, 7) : primaryColor
      const theme = {
        mode,
        palette: 'palette1',
        monochrome: {
          enabled: true,
          color: convertedColor,
          shadeTo: mode,
          shadeIntensity: 0.95
        }

      }
      this.ticketsQueueOptions = { ...this.ticketsQueueOptions, theme }
      this.ticketsUserOptions = { ...this.ticketsUserOptions, theme }
      this.ticketsChannelsOptions = { ...this.ticketsChannelsOptions, theme }
      this.ticketsEvolutionChannelsOptions = { ...this.ticketsEvolutionChannelsOptions, theme }
      this.ticketsEvolutionByPeriodOptions = { ...this.ticketsEvolutionByPeriodOptions, theme }
      this.ticketsEvolutionByHourOptions = { ...this.ticketsEvolutionByHourOptions, theme }
      this.ticketsActiveUsersOptions = { ...this.ticketsActiveUsersOptions, theme }
      this.ticketsStatusOptions = { ...this.ticketsStatusOptions, theme }
    },
    async listaWhatsapp() {
      const { data } = await ListarWhatsapps()
      this.listaWhats = data.filter(f => f.isActive)
    },
    async handleApagarMassa() {
      try {
        const data = {
          status: this.apagarTickets.status,
          startDate: this.apagarTickets.dateStart,
          endDate: this.apagarTickets.dateEnd,
          whatsappId: this.apagarTickets.whatsappId,
          isGroup: this.apagarTickets.isGroup
        }

        const response = await ApagaremMassaTickets(data)

        if (response.status === 200) {
          this.$q.notify({
            type: 'positive',
            message: 'Tickets apagados com sucesso!'
          })
          setTimeout(() => {
            window.location.reload()
          }, 1000)
        } else {
          this.$q.notify({
            type: 'negative',
            message: 'Ocorreu um erro ao apagar os tickets.'
          })
          setTimeout(() => {
            window.location.reload()
          }, 1000)
        }

        this.modaFecharMassa = false
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: 'Ocorreu um erro ao apagar os tickets.'
        })
        setTimeout(() => {
          window.location.reload()
        }, 1000)
      }
    },
    async handleFecharMassa() {
      try {
        const data = {
          status: this.fecharTickets.status,
          startDate: this.fecharTickets.dateStart,
          endDate: this.fecharTickets.dateEnd,
          whatsappId: this.fecharTickets.whatsappId,
          isGroup: this.fecharTickets.isGroup
        }

        const response = await FecharemMassaTickets(data)

        if (response.status === 200) {
          this.$q.notify({
            type: 'positive',
            message: 'Tickets fechados com sucesso!'
          })
          setTimeout(() => {
            window.location.reload()
          }, 1000)
        } else {
          this.$q.notify({
            type: 'negative',
            message: 'Ocorreu um erro ao fechar os tickets.'
          })
          setTimeout(() => {
            window.location.reload()
          }, 1000)
        }

        this.modaFecharMassa = false
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: 'Ocorreu um erro ao fechar os tickets.'
        })
        setTimeout(() => {
          window.location.reload()
        }, 1000)
      }
    },
    async fecharTicketsEmMassa () {
      this.modaFecharMassa = true
    },
    async apagarTicketsMassa () {
      this.modarApagarMassa = true
    },
    async listarFilas () {
      const { data } = await ListarFilas()
      this.filas = data
    },
    async listarUsuarios () {
      const { data } = await ListarUsuarios()
      this.usuarios = data
    },
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoes()
      localStorage.setItem('configuracoes', JSON.stringify(data))
      const ignoreGroupMsg = data.find(config => config.key === 'ignoreGroupMsg')
      this.grupoAtivo = ignoreGroupMsg.value
    },
    handleGroups() {
      if (this.toggleValue) {
        this.params.isGroup = true
        this.$q.notify({
          type: 'positive',
          message: 'Filtrar estatísticas para grupos!',
          progress: true,
          actions: [{ icon: 'close', round: true, color: 'white' }]
        })
      } else {
        this.params.isGroup = false
        this.$q.notify({
          type: 'positive',
          message: 'Filtrar estatísticas para conversas privadas!',
          progress: true,
          actions: [{ icon: 'close', round: true, color: 'white' }]
        })
      }
    },
    setConfigWidth () {
      const diffDays = differenceInDays(new Date(this.params.endDate), new Date(this.params.startDate))
      if (diffDays > 30) {
        this.configWidth = { horizontal: true, width: 2200 }
      } else {
        const actualWidth = this.$q.screen.width
        this.configWidth = { horizontal: true, width: actualWidth - (actualWidth < 768 ? 40 : 100) }
      }
    },
    getDashTicketsAndTimes () {
      GetDashTicketsAndTimes(this.params).then(res => {
        this.ticketsAndTimes = res.data[0]
      })
        .catch(err => {
          console.error(err)
        })
    },
    getDashTicketsQueue () {
      GetDashTicketsQueue(this.params).then(res => {
        this.ticketsQueue = res.data
        const series = []
        const labels = []
        this.ticketsQueue.forEach(e => {
          series.push(+e.qtd)
          labels.push(e.label)
        })
        this.ticketsQueueOptions.series = series
        this.ticketsQueueOptions.labels = labels
        this.$refs.ChartTicketsQueue.updateOptions(this.ticketsQueueOptions)
        this.$refs.ChartTicketsQueue.updateSeries(series, true)
      })
        .catch(err => {
          console.error(err)
        })
    },
    getDashTicketsChannels () {
      const statusMapping = {
        whatsapp: 'WhatsApp',
        telegram: 'Telegram',
        hub_facebook: 'Facebook',
        hub_instagram: 'Instagram',
        hub_webchat: 'WebChat',
        instagram: 'Instagram'
      }
      GetDashTicketsChannels(this.params).then(res => {
        this.ticketsChannels = res.data
        const series = []
        const labels = []
        this.ticketsChannels.forEach(e => {
          series.push(+e.qtd)
          labels.push(statusMapping[e.label])
        })
        this.ticketsChannelsOptions.series = series
        this.ticketsChannelsOptions.labels = labels
        this.$refs.ChartTicketsChannels.updateOptions(this.ticketsChannelsOptions)
        this.$refs.ChartTicketsChannels.updateSeries(series, true)
      })
        .catch(err => {
          console.error(err)
        })
    },
    getDashTicketsEvolutionChannels () {
      GetDashTicketsEvolutionChannels(this.params)
        .then(res => {
          this.ticketsEvolutionChannels = res.data
          const dataLabel = groupBy({ ...this.ticketsEvolutionChannels }, 'dt_referencia')
          const labels = Object.keys(dataLabel)
          // .map(l => {
          //   return format(new Date(l), 'dd/MM')
          // })
          this.ticketsEvolutionChannelsOptions.labels = labels
          this.ticketsEvolutionChannelsOptions.xaxis.categories = labels
          const series = []
          const dados = groupBy({ ...this.ticketsEvolutionChannels }, 'label')
          for (const item in dados) {
            series.push({
              name: item,
              // type: 'line',
              data: dados[item].map(d => {
                // if (labels.includes(format(new Date(d.dt_ref), 'dd/MM'))) {
                return d.qtd
              })
            })
          }
          this.ticketsEvolutionChannelsOptions.series = series
          this.$refs.ChartTicketsEvolutionChannels.updateOptions(this.ticketsEvolutionChannelsOptions)
          this.$refs.ChartTicketsEvolutionChannels.updateSeries(series, true)
        })
        .catch(error => {
          console.error(error)
        })
    },
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    getDashTicketsStatus() {
      if (this.userProfile === 'user') {
        return
      }
      GetDashTicketsStatus(this.params)
        .then(res => {
          const series = []
          const labels = []

          res.data.forEach(e => {
            series.push(+e.qtd)
            labels.push(e.label === 'open' ? 'Abertos' : 'Pendentes')
          })

          this.ticketsStatusOptions.series = series
          this.ticketsStatusOptions.labels = labels

          this.$refs.ChartTicketsStatus.updateOptions(this.ticketsStatusOptions)
          this.$refs.ChartTicketsStatus.updateSeries(series, true)
        })
        .catch(err => {
          console.error(err)
        })
    },
    getDashTicketsActiveUsers() {
      if (this.userProfile === 'user') {
        return
      }
      GetDashTicketsActiveUsers(this.params)
        .then(res => {
          this.ticketsActiveUsers = res.data

          const series = [
            {
              name: 'Atendimentos Ativos',
              data: this.ticketsActiveUsers.map(e => e.qtd)
            }
          ]
          const categories = this.ticketsActiveUsers.map(e => e.label || 'Sem usuário atribuído')

          this.ticketsActiveUsersOptions.series = series
          this.ticketsActiveUsersOptions.xaxis.categories = categories

          this.$refs.ChartTicketsActiveUsers.updateOptions(this.ticketsActiveUsersOptions)
          this.$refs.ChartTicketsActiveUsers.updateSeries(series, true)
        })
        .catch(err => {
          console.error(err)
        })
    },
    getDashTicketsUser() {
      if (this.userProfile === 'user') {
        return
      }
      GetDashTicketsUser(this.params)
        .then(res => {
          this.ticketsUser = res.data
          const series = []
          const labels = []

          this.ticketsUser.forEach(e => {
            series.push(+e.qtd)
            labels.push(e.label || 'Sem Usuário atribuído')
          })

          this.ticketsUserOptions.series = series
          this.ticketsUserOptions.labels = labels
          this.$refs.ChartTicketsUser.updateOptions(this.ticketsUserOptions)
          this.$refs.ChartTicketsUser.updateSeries(series, true)
        })
        .catch(err => {
          console.error(err)
        })
    },
    getDashTicketsEvolutionByHour() {
      if (this.userProfile === 'user') {
        return
      }
      GetDashTicketsEvolutionByHour(this.params)
        .then(res => {
          const hours = Array.from({ length: 24 }, (_, i) => i.toString())
          const qtdByHour = Array(24).fill(0)

          res.data.forEach(({ hour, qtd }) => {
            const index = parseInt(hour, 10)
            qtdByHour[index] = qtd
          })

          const series = [
            {
              name: 'Tickets',
              data: qtdByHour
            }
          ]

          this.ticketsEvolutionByHourOptions = {
            ...this.ticketsEvolutionByHourOptions,
            xaxis: {
              categories: hours
            },
            series
          }

          this.$refs.ChartTicketsEvolutionByHour.updateOptions(this.ticketsEvolutionByHourOptions)
          this.$refs.ChartTicketsEvolutionByHour.updateSeries(series, true)
        })
        .catch(error => {
          console.error(error)
        })
    },
    getDashTicketsEvolutionByPeriod () {
      GetDashTicketsEvolutionByPeriod(this.params)
        .then(res => {
          this.ticketsEvolutionByPeriod = res.data
          const series = [{
            name: 'Atendimentos',
            type: 'column',
            data: []
          }, {
            type: 'line',
            data: []
          }
          ]
          const labels = []
          this.ticketsEvolutionByPeriod.forEach(e => {
            series[0].data.push(+e.qtd)
            labels.push(e.label)
          })
          series[1].data = series[0].data
          this.ticketsEvolutionByPeriodOptions.labels = labels
          this.ticketsEvolutionByPeriodOptions.series = series
          this.$refs.ChartTicketsEvolutionByPeriod.updateOptions(this.ticketsEvolutionByPeriodOptions)
          this.$refs.ChartTicketsEvolutionByPeriod.updateSeries(series, true)
        })
        .catch(error => {
          console.error(error)
        })
    },
    async getDashTicketsPerUsersDetail() {
      try {
        const { data } = await GetDashTicketsPerUsersDetail(this.params)
        this.ticketsPerUsersDetail = data.map(user => ({
          ...user,
          avaliacao: user.average_rating || 0 // Ajuste para refletir o nome correto
        }))
      } catch (err) {
        console.error(err)
      }
    },
    getDashData () {
      this.setConfigWidth()
      this.getDashTicketsAndTimes()
      this.getDashTicketsChannels()
      this.getDashTicketsEvolutionChannels()
      this.getDashTicketsQueue()
      this.getDashTicketsEvolutionByPeriod()
      this.getDashTicketsPerUsersDetail()
      this.getDashTicketsEvolutionByHour()
      this.getDashTicketsUser()
      this.getDashTicketsActiveUsers()
      this.getDashTicketsActiveUsers()
      this.getDashTicketsStatus()
    }

  },
  beforeMount () {
    this.$store.commit('UPDATE_SHOW_MENU', this.showMenu)
    this.listarConfiguracoes()
    const mode = this.$q.dark.isActive ? 'dark' : 'light'
    const primaryColor = getComputedStyle(document.documentElement)
      .getPropertyValue('--q-cor1')
      .trim()
    const convertedColor = primaryColor.length === 9 ? primaryColor.slice(0, 7) : primaryColor

    const theme = {
      mode,
      palette: 'palette1',
      monochrome: {
        enabled: true,
        color: convertedColor,
        shadeTo: mode,
        shadeIntensity: 0.95
      }

    }
    this.ticketsQueueOptions = { ...this.ticketsQueueOptions, theme }
    this.ticketsUserOptions = { ...this.ticketsUserOptions, theme }
    this.ticketsChannelsOptions = { ...this.ticketsChannelsOptions, theme }
    this.ticketsEvolutionChannelsOptions = { ...this.ticketsEvolutionChannelsOptions, theme }
    this.ticketsEvolutionByPeriodOptions = { ...this.ticketsEvolutionByPeriodOptions, theme }
    this.ticketsEvolutionByHourOptions = { ...this.ticketsEvolutionByHourOptions, theme }
    this.ticketsActiveUsersOptions = { ...this.ticketsActiveUsersOptions, theme }
    this.ticketsStatusOptions = { ...this.ticketsStatusOptions, theme }
  },
  mounted () {
    this.loadColors()
    this.loadVersionp()
    this.userProfile = localStorage.getItem('profile')
    this.listarUsuarios()
    this.listarFilas()
    this.getDashData()
    this.listaWhatsapp()
  }
}
</script>

<style lang="scss" >
.text-branco{
  color: white;
}
.apexcharts-theme-dark svg {
  background: none !important;
}
.bg-vermelho {
  background-color: #f44336;
}
.bg-amarelo{
  background-color: #fec107;
}
.rdsPainelDate{
  display: flex;
  justify-content: space-around !important;
}
.donation-card {
  max-width: 500px;
  margin: auto;
  background-color: #f9f9f9;
  border-radius: 8px;
  padding: 16px;
}
.donation-image {
  max-width: 150px;
  height: auto;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}
</style>
