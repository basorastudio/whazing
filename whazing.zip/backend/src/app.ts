// Import necessary types from express
import type { Request, Response, NextFunction, Express } from "express";
import __importDefault from "./_importDefault"; // Assuming __importDefault is a local helper or adjust as needed

// Reflect metadata is often needed for decorators (though not used here, it was required)
import "reflect-metadata";
// Bootstrap environment variables first
import "./bootstrap";
// Database initialization (assuming ./database setup)
import "./database"; // Make sure this file exists and performs setup
// Error handling setup (assuming express-async-errors setup)
import "express-async-errors"; // Handles async errors in express routes

import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import { BullAdapter } from "@bull-board/api/bullAdapter"; // Correct import path
import { createBullBoard } from "@bull-board/api"; // Correct import path
import { ExpressAdapter } from "@bull-board/express"; // Correct import path
import basicAuth from "basic-auth";

// Import custom error class
import AppError from "./errors/AppError"; // Ensure this path is correct

// Import configurations and utilities
import uploadConfig from "./config/upload"; // Ensure this path is correct
import routes from "./routes"; // Ensure this path is correct
import { logger } from "./utils/logger"; // Ensure this path is correct

// Import Queue and RabbitMQ related modules
import Queue from "./libs/Queue"; // Ensure this path is correct
import RabbitmqServer from "./libs/rabbitmq-server"; // Ensure this path is correct

// Import Consumers
import Consumer360 from "./services/WABA360/Consumer360"; // Ensure this path is correct
import MessengerConsumer from "./services/MessengerChannelServices/MessengerConsumer"; // Ensure this path is correct

// --- Variable Setup ---
const origin: string | undefined = process.env.FRONTEND_URL; // Get frontend URL from env
const app: Express = express();

// --- Middleware Setup ---

// Helmet for security headers
app.use(helmet());

// Content Security Policy (CSP)
app.use(
  helmet.contentSecurityPolicy({
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"], // Allow inline scripts if necessary, review security implications
      styleSrc: ["'self'", "'unsafe-inline'", "https:"], // Allow inline styles and from https
      imgSrc: ["'self'", "data:", "https:"], // Allow images from self, data URIs, https
      connectSrc: ["'self'", origin || ""], // Allow connections to self and frontend URL
      fontSrc: ["'self'", "https:"], // Allow fonts from self and https
      objectSrc: ["'none'"], // Disallow plugins (Flash, etc.)
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"] // Disallow embedding in frames
      // The following seem less common or potentially typos in original, review if needed:
      // baseUri: ["'self'"],
      // blockAllMixedContent: [], // Use helmet's default or specific config
      // frameAncestors: ["'none'"], // Already covered by frameSrc generally
      // scriptSrcAttr: ["'none'"], // Stricter script attribute policy
      // upgradeInsecureRequests: [], // Use helmet's default HSTS instead
    }
  })
);

// CORS configuration
app.use(
  cors({
    origin: origin, // Allow requests from the frontend URL
    credentials: true // Allow cookies and authorization headers
  })
);

// Cookie parsing
app.use(cookieParser());

// Body parsing (JSON and URL-encoded)
app.use(express.json({ limit: "64MB" })); // Increase limit if needed
app.use(express.urlencoded({ extended: true, limit: "64MB" })); // Increase limit if needed

// Static files serving (from ./public directory)
app.use("/public", express.static(uploadConfig.directory)); // Serve uploads

// --- Bull Board Setup ---
const serverAdapter = new ExpressAdapter();
serverAdapter.setBasePath("/admin/queues"); // Base path for the Bull Board UI

// Bull Board Authentication Middleware
const authMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const user = basicAuth(req);
  const bullUser = process.env.BULL_USER || "admin"; // Default or from env
  const bullPass = process.env.BULL_PASS || "admin123"; // Default or from env

  if (!user || user.name !== bullUser || user.pass !== bullPass) {
    res.set("WWW-Authenticate", 'Basic realm="Área de Administración"'); // Translated realm
    // Sending 401 Unauthorized status
    res.status(401).send("Acceso denegado"); // Translated message
    return; // Important to return after sending response
  }
  next(); // Proceed if authentication is successful
};

// Conditionally apply auth middleware and setup Bull Board UI route
if (String(process.env.BULL_BOARD).toLowerCase() === "true") {
  app.use("/admin/queues", authMiddleware, serverAdapter.getRouter());
}

// Function to set up Bull queues with the adapter
export function setQueues(bullQueues: BullAdapter[]): void {
  createBullBoard({
    queues: bullQueues,
    serverAdapter: serverAdapter
  });
  logger.info("Bull Board UI created."); // Log message added for clarity
}

// Initialize Bull Board with queues from the Queue library
Queue.initialize()
  .then(() => {
    const bullAdapters = Queue.queues.map(q => new BullAdapter(q.bull));
    setQueues(bullAdapters);
    logger.info("Bull Board queues initialized."); // Log message added for clarity
  })
  .catch(error => {
    logger.error("Failed to initialize Bull Board queues:", error);
  });

// --- RabbitMQ Setup ---
let rabbitMQServer: RabbitmqServer | null = null;
let rabbitWhatsappServer: RabbitmqServer | null = null;

// Declare global rabbitWhatsapp for use in other modules if needed
// You might need a global.d.ts file:
// declare global {
//   var rabbitWhatsapp: RabbitmqServer | null;
// }
declare global {
  var rabbitWhatsapp: RabbitmqServer | null; // Declare global variable
}

if (process.env.AMQP_URL) {
  // Main RabbitMQ server
  (async () => {
    try {
      const amqpUrl = process.env.AMQP_URL!; // Use non-null assertion as we checked existence
      rabbitMQServer = new RabbitmqServer(amqpUrl);
      await rabbitMQServer.start();
      logger.info(`Rabbit iniciado en: ${amqpUrl}`); // Translated message
      // Assign to app instance if needed elsewhere via app
      (app as any).rabbit = rabbitMQServer; // Use 'any' or define a proper type for app extension
    } catch (error) {
      logger.error("Failed to start main RabbitMQ server:", error);
    }
  })();

  // WhatsApp specific RabbitMQ server (if URL is the same, could reuse instance?)
  // Assuming it might be a different connection or logical separation
  (async () => {
    try {
      const amqpUrl = process.env.AMQP_URL!; // Use non-null assertion
      rabbitWhatsappServer = new RabbitmqServer(amqpUrl);
      await rabbitWhatsappServer.start();
      logger.info(`Rabbit iniciado Whatsapp en: ${amqpUrl}`); // Translated message
      // Assign to global scope
      global.rabbitWhatsapp = rabbitWhatsappServer;
    } catch (error) {
      logger.error("Failed to start WhatsApp RabbitMQ server:", error);
    }
  })();

  // Start RabbitMQ Consumers
  Consumer360(); // Assuming this function starts the consumer
  MessengerConsumer(); // Assuming this function starts the consumer
} else {
  logger.warn(
    "AMQP_URL no está definido. Los servicios de RabbitMQ no se iniciarán."
  ); // Translated warning
}

// --- Routes ---
// Simple health check / info route
app.get("/", (req: Request, res: Response) => {
  // Translated HTML response
  res.send(
    `Backend está funcionando correctamente. Accede al frontend: <a href="${origin}">${origin}</a>`
  );
});

// Main application routes
app.use(routes);

// --- Error Handling Middleware ---
// This middleware should be last
app.use(async (err: Error, req: Request, res: Response, next: NextFunction) => {
  if (err instanceof AppError) {
    // Handle known application errors
    if (err.statusCode === 400) {
      // Log specific types of errors differently if needed
      logger.warn(err); // Log validation errors as warnings
    } else {
      logger.error(err); // Log other AppErrors as errors
    }
    return res.status(err.statusCode).json({ error: err.message });
  }

  // Handle unexpected errors
  logger.error("Error interno del servidor:", err); // Log unexpected errors
  // Translated generic error message
  return res.status(500).json({ error: "Error interno del servidor." });
});

// --- Exports ---
// Export the configured Express app instance
export default app;
// Export the serverAdapter if it needs to be accessed externally (e.g., for testing)
export { serverAdapter };

// Helper simulation (remove if you have a real __importDefault)
function __importDefault<T>(mod: { default: T } | T): { default: T } | T {
  return mod && (mod as any).__esModule ? mod : { default: mod };
}
