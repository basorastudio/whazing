import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      // Elimina la columna 'initialStep' (probablemente de tipo INTEGER) de la tabla 'StepsReply'
      queryInterface.removeColumn('StepsReply', 'initialStep')
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Vuelve a añadir la columna 'initialStep', pero ahora como BOOLEAN
    return Promise.all([
      queryInterface.addColumn('StepsReply', 'initialStep', {
        type: DataTypes.BOOLEAN,
        defaultValue: false // Valor predeterminado es false
      })
    ]);
  }
};