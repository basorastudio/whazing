import { QueryInterface, DataTypes, Sequelize } from 'sequelize'; // Added Sequelize
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'Kanbans' table (representing Kanban columns/stages)
    await queryInterface.createTable(
      'Kanbans', // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
          allowNull: false,
        },
        name: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        color: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        isActive: {
          type: DataTypes.BOOLEAN,
          allowNull: false,
          defaultValue: true, // Default to active
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
        },
        userId: {
          type: DataTypes.INTEGER,
          references: { model: 'Users', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL', // Allow Kanban column to exist if user is deleted?
          allowNull: true,
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: { model: 'Tenants', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL', // Allow Kanban column to exist if tenant is deleted? Or CASCADE?
          allowNull: true,
        },
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'Kanbans' table
    await queryInterface.dropTable('Kanbans');
  }
};

export = migration;