import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Propiedades comunes para las nuevas columnas
    const commonProps = {
      allowNull: true, // Permite nulos
      defaultValue: null
    };

    return Promise.all([
      // Añade la columna 'closedAt' (DATE) a 'Tickets'
      queryInterface.addColumn('Tickets', 'closedAt', {
        type: DataTypes.DATE,
        ...commonProps
      }),
      // Añade la columna 'chatFlowId' (INTEGER) a 'Tickets'
      queryInterface.addColumn('Tickets', 'chatFlowId', {
        type: DataTypes.INTEGER,
        ...commonProps
      }),
      // Añade la columna 'stepChatFlow' (STRING) a 'Tickets'
      queryInterface.addColumn('Tickets', 'stepChatFlow', {
        type: DataTypes.STRING,
        ...commonProps
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina las columnas añadidas
    return Promise.all([
      queryInterface.removeColumn('Tickets', 'closedAt'),
      queryInterface.removeColumn('Tickets', 'chatFlowId'),
      queryInterface.removeColumn('Tickets', 'stepChatFlow')
    ]);
  }
};