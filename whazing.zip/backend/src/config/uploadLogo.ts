import path from "path";
import multer, { StorageEngine } from "multer";
import { Request } from "express"; // Necesario para tipar 'req'

/**
 * Configuración específica para subir logos usando Multer.
 * Los logos se guardan en 'public/logos'.
 * El nombre del archivo se basa en el parámetro 'ref' de la query string.
 */

// Resuelve la ruta a la carpeta de logos relativa al directorio actual
const publicLogosFolder = path.resolve(__dirname, "..", "..", "public/logos");

interface UploadLogoConfig {
  directory: string;
  storage: StorageEngine;
}

const uploadLogoConfig: UploadLogoConfig = {
  directory: publicLogosFolder,
  storage: multer.diskStorage({
    destination: publicLogosFolder,
    filename(
      req: Request,
      file: Express.Multer.File,
      callback: (error: Error | null, filename: string) => void
    ) {
      // Obtiene el parámetro 'ref' de la query string de la solicitud
      const ref = req.query.ref as string | undefined; // Tipado como string opcional

      // Obtiene la extensión del archivo original
      const fileExtension = path.extname(file.originalname);

      // Genera el nombre del archivo usando la referencia (si existe) y la extensión
      // Si 'ref' no existe, el nombre será solo la extensión (ej: '.png'), lo cual es problemático.
      // Considera añadir un fallback o lanzar un error si 'ref' es obligatorio.
      const finalFilename = `${ref || "default_logo_name"}${fileExtension}`; // Añadido fallback

      // Verifica si ref existe antes de crear el nombre?
      // if (!ref) {
      //   return callback(new Error("El parámetro 'ref' es obligatorio para subir logos."), '');
      // }

      return callback(null, finalFilename);
    }
  })
  // Considera añadir un fileFilter para asegurar que solo se suban imágenes (ej: png, jpg, svg)
};

export default uploadLogoConfig;
