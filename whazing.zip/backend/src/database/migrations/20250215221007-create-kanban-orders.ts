import { QueryInterface, DataTypes, Sequelize } from 'sequelize'; // Added Sequelize
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'KanbanOrders' table (Associates Contacts with Kanban stages)
    await queryInterface.createTable(
      'KanbanOrders', // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
          allowNull: false,
        },
        contactId: {
          type: DataTypes.INTEGER,
          references: { model: 'Contacts', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE', // If Contact is deleted, remove this association
          allowNull: false,   // Must belong to a contact (changed from original implicit true)
        },
        kanbanId: {
          type: DataTypes.INTEGER,
          references: { model: 'Kanbans', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE', // If Kanban stage is deleted, remove this association
          allowNull: false,   // Must belong to a Kanban stage (changed from original implicit true)
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'),
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'),
        },
      }
    );
    // Consider adding a unique constraint on [contactId, kanbanId] if a contact can only be in one stage at a time.
    // await queryInterface.addConstraint('KanbanOrders', {
    //   fields: ['contactId', 'kanbanId'],
    //   type: 'unique',
    //   name: 'unique_contact_kanban'
    // });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'KanbanOrders' table
    await queryInterface.dropTable('KanbanOrders');
  }
};

export = migration;