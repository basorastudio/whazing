import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'LogTickets';
    // Add index on [ticketId]
    await queryInterface.addIndex(tableName, ['ticketId'], {
      name: 'idx_logtickets_ticketid', // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'LogTickets';
    // Remove the index
    await queryInterface.removeIndex(tableName, 'idx_logtickets_ticketid');
  }
};

export = migration;