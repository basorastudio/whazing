import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'isActive' (booleana) a la tabla 'Queues'
    return Promise.all([
      queryInterface.addColumn("Queues", "isActive", {
        type: DataTypes.BOOLEAN,
        allowNull: false, // No permite nulos
        defaultValue: true // Valor predeterminado es true
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'isActive' de la tabla 'Queues'
    return queryInterface.removeColumn("Queues", "isActive");
  }
};
