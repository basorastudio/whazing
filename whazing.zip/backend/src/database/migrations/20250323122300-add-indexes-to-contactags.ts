import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "ContactTags"; // Pluralized table name
    // Add composite index on [contactId, tagId]
    await queryInterface.addIndex(tableName, ["contactId", "tagId"], {
      name: "idx_contact_tags" // Explicit index name
      // unique: true // Consider if this combination should be unique
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "ContactTags";
    // Remove the index
    await queryInterface.removeIndex(tableName, "idx_contact_tags");
  }
};

export = migration;
