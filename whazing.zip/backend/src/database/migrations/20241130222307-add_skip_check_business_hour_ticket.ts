import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'skipCheckBusinessHour' column to the 'Tickets' table
    // Flag to bypass business hour checks for this specific ticket.
    await queryInterface.addColumn(
      "Tickets", // Table name
      "skipCheckBusinessHour", // New column name
      {
        type: DataTypes.BOOLEAN,
        allowNull: true, // Original allowed null
        defaultValue: false // Default to not skipping
      }
    );
    // Original code wrapped this in Promise.all, unnecessary here.
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'skipCheckBusinessHour' column from the 'Tickets' table
    await queryInterface.removeColumn(
      "Tickets", // Table name
      "skipCheckBusinessHour" // Column name to remove
      // Original code wrapped the remove operation in Promise.all and passed the column definition again, which is incorrect for removeColumn. Corrected here.
    );
  }
};

export = migration;
