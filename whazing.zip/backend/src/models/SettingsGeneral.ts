import {
  Table,
  Column,
  Model,
  PrimaryKey,
  CreatedAt,
  UpdatedAt,
  DataType, // Added import
  AutoIncrement // Added import
} from "sequelize-typescript";

@Table({ tableName: "SettingsGeneral" }) // Explicit table name
class SettingsGeneral extends Model<SettingsGeneral> {
  @PrimaryKey
  @AutoIncrement // Added based on likely usage for settings ID
  @Column
  id: number; // Changed to number based on AutoIncrement

  @PrimaryKey // Made 'key' part of the primary key as is common for settings
  @Column
  key: string;

  @Column
  value: string; // Assuming string value, adjust if other types are needed

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default SettingsGeneral;