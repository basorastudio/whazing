import { getWbot } from '../libs/wbot';
import SendMessagesSystemWbotBaileys from '../services/WbotServices/SendMessagesSystemWbotBaileys'; // Adjust as needed
import SendMessagesSystemHub from '../services/WbotNotificame/SendMessagesSystemHub'; // Adjust as needed
import { logger } from '../utils/logger';
import { proto } from '@whiskeysockets/baileys'; // Or other relevant types

// Define interfaces for the data structures (can be shared/imported)
interface MessageToSend {
    number: string;
    message?: string;
    options?: any;
    media?: {
        mimetype: string;
        url?: string;
        path?: string;
        filename?: string;
        caption?: string;
    }
    // Add other potential message properties
}

/**
 * Sends messages using the Baileys Wbot instance.
 * @param whatsappId - The ID of the WhatsApp session.
 * @param tenantId - The tenant ID.
 * @param messages - An array of messages to send.
 */
export const sendMessageBaileys = async (
    whatsappId: number,
    tenantId: number | string,
    messages: MessageToSend[] | undefined = undefined // Made optional like original
): Promise<void> => {
    const logPrefix = `sendMessageBaileys::Tenant-${tenantId}::Session-${whatsappId}`;
    try {
        if (!messages || messages.length === 0) {
            logger.warn(`${logPrefix}: No messages provided. Skipping.`);
            return;
        }
        const wbot = getWbot(whatsappId);
        await SendMessagesSystemWbotBaileys(wbot, tenantId, messages);
        logger.info(`${logPrefix}: Successfully initiated sending of ${messages.length} messages via Baileys.`);
    } catch (error: any) {
        logger.error({
            message: `${logPrefix}: Error sending messages`, // Original: Error send messages
            error: error?.message,
            originalError: error
        });
        // Re-throwing the original error allows the caller (queue handler) to manage it
        throw error;
    }
};

/**
 * Sends messages using the Hub service.
 * @param whatsappId - The ID of the WhatsApp session (or relevant identifier for the Hub).
 * @param tenantId - The tenant ID.
 * @param messages - An array of messages to send.
 */
export const sendMessageHub = async (
    whatsappId: number, // Or string if Hub uses different ID
    tenantId: number | string,
    messages: MessageToSend[] | undefined = undefined // Made optional
): Promise<void> => {
    const logPrefix = `sendMessageHub::Tenant-${tenantId}::Session-${whatsappId}`;
    try {
         if (!messages || messages.length === 0) {
             logger.warn(`${logPrefix}: No messages provided. Skipping.`);
             return;
         }
        // Assuming SendMessagesSystemHub doesn't need a wbot instance directly
        await SendMessagesSystemHub(whatsappId, tenantId, messages);
         logger.info(`${logPrefix}: Successfully initiated sending of ${messages.length} messages via Hub.`);
    } catch (error: any) {
        logger.error({
            message: `${logPrefix}: Error sending messages`, // Original: Error send messages
            error: error?.message,
            originalError: error
        });
        throw error;
    }
};