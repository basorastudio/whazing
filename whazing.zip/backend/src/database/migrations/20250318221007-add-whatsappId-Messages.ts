import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'whatsappId' column to the 'Messages' table as a foreign key
    await queryInterface.addColumn(
      'Messages',   // Table name
      'whatsappId', // New column name
      {
        type: DataTypes.INTEGER,
        allowNull: true, // Allow null
        references: {
          model: 'Whatsapps', // References the Whatsapps table
          key: 'id',
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL', // Keep message if Whatsapp connection is deleted
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'whatsappId' column from the 'Messages' table
    await queryInterface.removeColumn(
      'Messages',   // Table name
      'whatsappId'  // Column name to remove
    );
  }
};

export = migration;