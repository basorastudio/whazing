import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'name' (string) a la tabla 'Tenants'
    return Promise.all([
      queryInterface.addColumn('Tenants', 'name', {
        type: DataTypes.STRING,
        allowNull: false, // No permite nulos
        defaultValue: '' // Valor predeterminado es una cadena vacía
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'name' de la tabla 'Tenants'
    return Promise.all([
      queryInterface.removeColumn('Tenants', 'name')
    ]);
  }
};