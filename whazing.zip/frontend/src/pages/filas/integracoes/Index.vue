<template>
  <div v-if="!canAccessPage">
    <q-banner dense inline-actions class="bg-red text-white">
      <template v-slot:avatar>
        <q-icon name="warning" />
      </template>
      Integraciones no forman parte de su plan. Para contratar, contacte con el soporte.
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               v-if="whatsappNumber"
               icon="mdi-whatsapp"
               label="Llamar Soporte"
               @click="abrirWhatsApp2"
        />
      </template>
    </q-banner>
  </div>
  <div v-else-if="userProfile === 'admin'">
    <q-table flat
      bordered
      square
      hide-bottom
             class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
             :class="{'full-height': $q.screen.lt.sm}"
      :data="integracoes"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :rows-per-page-options="[0]">
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-hub-outline q-pr-sm" />
            Integraciones
          </h2>
          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline"
          label="Añadir"
          @click="integracaoEdicao = {}; modalIntegracao = true" />
          <q-btn flat
                 class="generate-button btn-rounded-50"
                 :class="{'generate-button-dark' : $q.dark.isActive}"
                 v-if="whatsappNumber"
                 icon="mdi-whatsapp"
                 label="Llamar Soporte"
                 @click="abrirWhatsApp"
          />
        </div>

      </template>
      <template v-slot:body-cell-color="props">
        <q-td class="text-center">
          <div
            class="q-pa-sm rounded-borders"
            :style="`background: ${props.row.color}`"
          >
            {{ props.row.color }}
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'" />
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn flat
            round
                 class="color-light1"
                 :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-edit-outline"
            @click="editarIntegracao(props.row)" />
          <q-btn flat
            round
                 class="color-light1"
                 :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-trash-outline"
            @click="deletarIntegracao(props.row)" />
        </q-td>
      </template>
    </q-table>
    <ModalIntegracao :modalIntegracao.sync="modalIntegracao"
      :integracaoEdicao.sync="integracaoEdicao"
      @modal-integracao:criada="integracaoCriada"
      @modal-integracao:editada="integracaoEditada" />
  </div>
</template>

<script>
import { DeletarIntegracao, ListarIntegracoes } from 'src/service/integracoes'
import { ListarConfiguracaoPublica } from 'src/service/configuracoesgeneral'
import { MostrarPlano } from 'src/service/empresas'
import ModalIntegracao from './ModalIntegracao'
export default {
  name: 'Integrações',
  components: {
    ModalIntegracao
  },
  data () {
    return {
      userProfile: 'user',
      integracaoEdicao: {},
      modalIntegracao: false,
      canAccessPage: false,
      integracoes: [],
      loading: false,
      whatsappNumber: null,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'name', label: 'Nombre', field: 'name', align: 'left' },
        { name: 'type', label: 'Tipo', field: 'type', align: 'left' },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.integrations !== false
      } catch (error) {
        console.error('Error al cargar el plan:', error)
      }
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Error al buscar configuraciones:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Ol%C3%A1%21+tenho+duvidas+integrações`
        window.open(url, '_blank')
      }
    },
    abrirWhatsApp2() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Ol%C3%A1%21+quero+adquirir+integrações`
        window.open(url, '_blank')
      }
    },
    async listarIntegracoes () {
      const { data } = await ListarIntegracoes()
      this.integracoes = data
    },
    integracaoCriada (integracao) {
      const newIntegracaos = [...this.integracoes]
      newIntegracaos.push(integracao)
      this.integracoes = [...newIntegracaos]
    },
    integracaoEditada (integracao) {
      const newIntegracaos = [...this.integracoes]
      const idx = newIntegracaos.findIndex(f => f.id === integracao.id)
      if (idx > -1) {
        newIntegracaos[idx] = integracao
      }
      this.integracoes = [...newIntegracaos]
    },
    editarIntegracao (integracao) {
      this.integracaoEdicao = { ...integracao }
      this.modalIntegracao = true
    },
    deletarIntegracao(integracao) {
      this.$q.dialog({
        title: '¡Atención!',
        message: `¿Desea realmente eliminar la Integración "${integracao.name}"?`,
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarIntegracao(integracao)
          .then(res => {
            let newIntegracaos = [...this.integracoes]
            newIntegracaos = newIntegracaos.filter(f => f.id !== integracao.id)

            this.integracoes = [...newIntegracaos]
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: `¡Integración ${integracao.name} eliminada!`,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .catch((error) => {
            console.error('Error deleting integration:', error) // Log the error for debugging
            this.$q.notify({
              type: 'negative',
              progress: true,
              position: 'top',
              message: 'Error al eliminar integración. No es posible eliminar una integración que ya fue usada o asignada a una fila.',
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }],
              group: false
            })
          })
          .finally(() => {
            this.loading = false
          })
      })
    }

  },
  mounted () {
    this.fetchConfigurations()
    this.listarPlano()
    this.listarIntegracoes()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 50px)
  .q-table__top
    padding: 8px
</style>
