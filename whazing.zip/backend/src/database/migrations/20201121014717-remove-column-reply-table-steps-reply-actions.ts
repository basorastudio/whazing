import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'reply' de la tabla 'StepsReplyActions'
    return queryInterface.removeColumn('StepsReplyActions', 'reply');
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Vuelve a añadir la columna 'reply' a la tabla 'StepsReplyActions'
    return queryInterface.addColumn('StepsReplyActions', 'reply', {
      type: DataTypes.STRING,
      allowNull: true // Se permite nulo en el rollback, podría necesitar ajuste
    });
  }
};