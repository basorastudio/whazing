import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna vcardContactId a la tabla Messages
    return queryInterface.addColumn("Messages", "vcardContactId", {
      // Nombre de columna preservado
      type: DataTypes.INTEGER,
      references: {
        model: "Contacts", // Referencia a la tabla Contacts
        key: "id"
      },
      onUpdate: "CASCADE",
      onDelete: "CASCADE", // O SET NULL si se prefiere
      allowNull: true // Permitir nulos
    });
    // Nota: Esta columna fue eliminada en la migración 20201004955719.
    // La presencia de ambas migraciones sugiere un posible error o cambio de decisión.
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna vcardContactId
    return queryInterface.removeColumn("Messages", "vcardContactId");
  }
};
