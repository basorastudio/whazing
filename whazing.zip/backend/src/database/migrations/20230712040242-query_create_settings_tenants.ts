// --- START OF FILE 20230712040242-query_create_settings_tenants.ts ---

"use strict";
import { QueryInterface, Sequelize, QueryTypes } from "sequelize"; // Added QueryTypes

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ): Promise<void> => {
    // Define setting keys and default values
    const settingsToInsert = [
      {
        key: "newTicketTransference", // 'newTicketT' + 'ransferenc' + 'e'
        value: "disabled", // Original 'disabled'
        // Spanish Translation of original message: "Las llamadas de voz y vídeo están deshabilitadas para este WhatsApp, por favor envíe un mensaje de texto."
        description: "Configuración para transferencia de nuevos tickets" // Example description
      },
      {
        key: "rejectCall", // Original 'rejectCall'
        value: "disabled", // Original 'disabled'
        // Spanish Translation of original message: "Las llamadas de voz y vídeo están deshabilitadas para este WhatsApp, por favor envíe un mensaje de texto."
        description: "Configuración para rechazar llamadas" // Example description
      },
      {
        key: "callRejectMessage", // 'callReject' + 'Message'
        // Original Portuguese: As chamadas de voz e vídeo estão desabilitadas para este WhatsApp, favor enviar mensagem de texto.
        value:
          "Las llamadas de voz y vídeo están deshabilitadas para este WhatsApp, favor enviar mensaje de texto.", // Translated value
        description: "Mensaje a enviar cuando se rechaza una llamada" // Example description
      }
      // Add more default settings here if needed
    ];

    // Get all tenant IDs
    const getTenantsQuery = 'SELECT id FROM "Tenants"';
    const tenants = await queryInterface.sequelize.query<{ id: number }>(
      getTenantsQuery,
      {
        type: QueryTypes.SELECT
      }
    );

    const bulkSettingsData: any[] = [];

    // Prepare bulk insert data for each tenant
    for (const tenant of tenants) {
      const tenantId = tenant.id;
      const now = new Date();

      for (const setting of settingsToInsert) {
        // Basic check if setting might already exist for the tenant (optional but good practice)
        // This check is simplified; a real check might query the Settings table
        // const checkQuery = `SELECT 1 FROM "Settings" WHERE "tenantId" = ${tenantId} AND key = '${setting.key}' LIMIT 1`;
        // const exists = await queryInterface.sequelize.query(checkQuery, { type: QueryTypes.SELECT });
        // if (exists.length === 0) { // Only add if it doesn't exist

        bulkSettingsData.push({
          key: setting.key,
          value: setting.value,
          tenantId: tenantId,
          createdAt: now,
          updatedAt: now
        });
        // }
      }
    }

    // Perform bulk insert if there's data to insert
    if (bulkSettingsData.length > 0) {
      try {
        await queryInterface.bulkInsert("Settings", bulkSettingsData);
      } catch (error) {
        console.error(
          "Error durante la inserción masiva de configuraciones:",
          error
        );
        // Handle potential bulk insert errors (e.g., constraint violations if settings already exist)
        // Depending on the desired behavior, you might want to log the error and continue,
        // or stop the migration.
      }
    } else {
      console.log(
        "No se encontraron nuevos tenants o las configuraciones ya existen. No se realizaron inserciones masivas."
      );
    }

    // The original migration had complex logic involving max(id) from Settings,
    // which seems unnecessary and potentially problematic for simply inserting default settings.
    // The revised approach directly inserts the required settings for each tenant.
    // The original SELECT max(id) queries have been removed as they don't contribute to the goal.
  },

  down: async (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ): Promise<void> => {
    // This 'down' migration is tricky. It should ideally remove *only* the settings added by 'up'.
    // A simple approach is to delete the specific keys added.
    const keysToRemove = [
      "newTicketTransference",
      "rejectCall",
      "callRejectMessage"
    ];

    // Construct the WHERE clause carefully
    const whereClause = keysToRemove.map(key => `key = '${key}'`).join(" OR ");

    // Get all tenant IDs again to ensure we only target relevant tenants (optional, safer)
    // const getTenantsQuery = 'SELECT id FROM "Tenants"';
    // const tenants = await queryInterface.sequelize.query<{ id: number }>(getTenantsQuery, { type: QueryTypes.SELECT });
    // const tenantIds = tenants.map(t => t.id);
    // const tenantFilter = tenantIds.length > 0 ? `"tenantId" IN (${tenantIds.join(',')}) AND` : '';

    // const deleteQuery = `DELETE FROM "Settings" WHERE ${tenantFilter} (${whereClause})`;

    // Simpler delete without tenant check (if appropriate)
    const deleteQuery = `DELETE FROM "Settings" WHERE ${whereClause}`;

    try {
      await queryInterface.sequelize.query(deleteQuery, {
        type: QueryTypes.DELETE
      });
    } catch (error) {
      console.error("Error eliminando configuraciones:", error);
      // Handle potential errors during deletion
    }

    // The original 'down' queried SELECT id FROM "Settings", which doesn't perform any cleanup.
    // The revised 'down' attempts to remove the settings added by 'up'.
  }
};

export default migration;

// --- END OF FILE 20230712040242-query_create_settings_tenants.ts ---
