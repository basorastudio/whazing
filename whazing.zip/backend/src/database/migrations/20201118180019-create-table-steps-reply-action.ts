import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    return queryInterface.createTable('StepsReplyActions', { // Nombre de la tabla 'StepsReplyActions'
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      stepReplyId: {
        type: DataTypes.INTEGER,
        references: {
          model: 'StepsReply', // Referencia a la tabla StepsReply
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE' // Si se elimina StepsReply, también se eliminan las acciones asociadas
      },
      words: {
        type: DataTypes.STRING,
        allowNull: false
      },
      action: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      reply: {
        type: DataTypes.STRING,
        allowNull: false
      },
      userId: {
        type: DataTypes.INTEGER,
        references: {
          model: 'Users', // Referencia a la tabla Users
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL' // Si se elimina el usuario, userId se establece en NULL
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    return queryInterface.dropTable('StepsReplyActions');
  }
};