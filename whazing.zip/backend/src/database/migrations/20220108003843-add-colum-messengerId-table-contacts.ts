// --- START OF FILE 20220108003843-add-colum-messengerId-table-contacts.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Contacts";
    const columnName = "messengerId"; // 'messengerI' + 'd'
    const attributes = {
      type: DataTypes.TEXT,
      allowNull: true, // Changed !![] to true
      defaultValue: null
    };
    await Promise.all([
      queryInterface.addColumn(tableName, columnName, attributes)
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Contacts";
    const columnName = "messengerId"; // 'messengerI' + 'd'
    await Promise.all([queryInterface.removeColumn(tableName, columnName)]);
  }
};

export default migration;

// --- END OF FILE 20220108003843-add-colum-messengerId-table-contacts.ts ---
