import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add columns related to auto-responding to 'Whatsapps' table
    await queryInterface.addColumn("Whatsapps", "RespondAuto", {
      // Note: Unusual capitalization kept
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      allowNull: false // Original had false
    });
    await queryInterface.addColumn("Whatsapps", "RespondAutoComment", {
      // Note: Unusual capitalization kept
      type: DataTypes.STRING, // Original was STRING, consider TEXT
      defaultValue: null,
      allowNull: true // Original allowed null
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added columns
    await queryInterface.removeColumn("Whatsapps", "RespondAutoComment");
    await queryInterface.removeColumn("Whatsapps", "RespondAuto");
  }
};

export = migration;
