import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'singleLogin' column to the 'Users' table
    // Flag to enforce only one active session per user.
    await queryInterface.addColumn(
      "Users", // Table name
      "singleLogin", // New column name
      {
        type: DataTypes.BOOLEAN,
        defaultValue: true, // Default to enforcing single login (Original was true)
        allowNull: false // Cannot be null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'singleLogin' column from the 'Users' table
    await queryInterface.removeColumn(
      "Users", // Table name
      "singleLogin" // Column name to remove
    );
  }
};

export = migration;
