<template>
  <q-dialog
    title="Ayuda"
    v-model="dialogVisible"
    width="70%"
    customClass="flowHelp"
  >
    <el-tabs tab-position="left">
      <el-tab-pane label="Cómo agregar">
        <el-divider content-position="left">Cómo agregar</el-divider>
        <div>Mantén presionado el ratón y arrastra el componente desde la izquierda hasta el lienzo central, luego suelta el ratón</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo eliminar">
        <el-divider content-position="left">Eliminación en la página</el-divider>
        <div>
          Haz clic en el nodo que deseas eliminar, luego haz clic en el icono de eliminar en la esquina superior izquierda
        </div>
        <el-divider content-position="left">Eliminación a través de código</el-divider>
        <pre>this.deleteNode(nodeId)</pre>
      </el-tab-pane>
      <el-tab-pane label="Cómo mover">
        <el-divider content-position="left">Cómo mover</el-divider>
        <div>Mueve el ratón sobre el nodo, cuando el cursor cambie a un icono de arrastrable, presiona el ratón y muévelo a una nueva posición, luego suelta</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo conectar">
        <el-divider content-position="left">Cómo conectar</el-divider>
        <div>Mueve el ratón sobre el icono en el lado izquierdo del nodo, cuando el cursor cambie a +, presiona el ratón y muévelo a otro nodo, luego suelta</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo añadir condiciones">
        <el-divider content-position="left">Cómo añadir condiciones</el-divider>
        <div>Haz clic en la línea de conexión en el lienzo, aparecerá un formulario en el lado derecho de la página, introduce la nueva condición y haz clic en [Guardar]</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo interactuar con el almacenamiento del backend">
        <el-divider content-position="left">Cómo interactuar con el almacenamiento del backend</el-divider>
        <div>Referencia: https://gitee.com/xiaoka2017/easy-flow-sdk</div>
      </el-tab-pane>
    </el-tabs>
  </q-dialog>
</template>

<script>
export default {
  data () {
    return {
      dialogVisible: false
    }
  },
  components: {},
  methods: {
    init () {
      this.dialogVisible = true
    }
  }
}
</script>

<style>
.flowHelp {
  height: 80%;
}
</style>
