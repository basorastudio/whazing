import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: async (queryInterface: QueryInterface, sequelize: Sequelize): Promise<void> => {
    // Nombre de la restricción única original
    const constraintName = 'unique_contact_number_tenant';

    // Añade la columna 'telegramId' (BIGINT) a 'Contacts'
    await queryInterface.addColumn('Contacts', 'telegramId', {
      type: DataTypes.BIGINT,
      defaultValue: null,
      allowNull: true
    });

    // Elimina la restricción única existente sobre 'number' y 'tenantId'
    await queryInterface.removeConstraint('Contacts', constraintName);

    // Cambia el tipo de la columna 'number' a BIGINT (y permite nulos)
    // Advertencia: Cambiar el tipo puede causar pérdida de datos si los números existentes no caben en BIGINT
    // o si no son numéricos. También, permitir null en 'number' puede ser problemático.
    await queryInterface.changeColumn('Contacts', 'number', {
      type: DataTypes.BIGINT,
      allowNull: true, // Permitir null
      primaryKey: false, // Asegurar que no sea primary key
      unique: false, // Asegurar que no sea única por sí sola
      defaultValue: null
    });
  },

  down: async (queryInterface: QueryInterface, sequelize: Sequelize): Promise<void> => {
     // Nombre de la restricción única
    const constraintName = 'unique_contact_number_tenant';

    // Elimina la columna 'telegramId'
    await queryInterface.removeColumn('Contacts', 'telegramId');

    // Cambia el tipo de la columna 'number' de nuevo a STRING (o el tipo original)
    // Asumiendo que era STRING y NOT NULL originalmente. Ajustar si es necesario.
    await queryInterface.changeColumn('Contacts', 'number', {
      type: DataTypes.STRING, // Vuelve a STRING
      allowNull: false, // No permite nulos
      unique: false // No es única por sí sola
    });

    // Vuelve a añadir la restricción única sobre 'number' y 'tenantId'
    await queryInterface.addConstraint('Contacts', {
      fields: ['number', 'tenantId'],
      type: 'unique',
      name: constraintName
    });
  }
};