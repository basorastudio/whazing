import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'queue' a la tabla 'Tickets'
    return queryInterface.addColumn('Tickets', 'queue', {
      type: DataTypes.INTEGER,
      defaultValue: null,
      allowNull: true
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'queue' de la tabla 'Tickets'
    return queryInterface.removeColumn('Tickets', 'queue');
  }
};