// --- START OF FILE MessageHubController.ts ---

import type { Request, Response } from 'express';
import SendReplyComentaryInstagram from '../services/WbotNotificame/SendReplyComentaryInstagram';
import SyncListTemplate from '../services/WbotNotificame/SyncListTemplate';
import ListTemplateCategories from '../services/WbotNotificame/ListTemplateCategories';
import ListTemplatesByCategory from '../services/WbotNotificame/ListTemplatesByCategory';
import { logger } from '../utils/logger';
import User from '../models/User';
import CreateMessageSystemService from '../services/MessageServices/CreateMessageSystemService';
import ShowTicketService from '../services/TicketServices/ShowTicketService';
import AppError from '../errors/AppError'; // Assuming path
import path from 'path'; // Needed for path.join
import fs from 'fs';    // Needed for file operations

interface SendCommentaryBody {
    body: string;
    quotedMsgId?: string; // Assuming optional
    wabaMediaId?: string; // Assuming optional
}

export const sendcomentary = async (req: Request, res: Response): Promise<Response> => {
    const {
        body,
        quotedMsgId,
        wabaMediaId
    } = req.body as SendCommentaryBody;
    const { ticketId } = req.params;
    const { tenantId, id: userId } = req.user;

    logger.debug('Sending hub message controller: '); // Traducido

    try {
        const user = await User.findByPk(userId);
        if (!user) {
             throw new AppError('Usuario no encontrado.', 404); // Traducido
        }

        await SendReplyComentaryInstagram(
            body,
            Number(ticketId),
            Number(tenantId),
            wabaMediaId, // Pass it along
            quotedMsgId, // Pass it along
            user.name // Pass user name
        );

        return res.status(200).json({ message: 'Mensaje enviado' }); // Traducido

    } catch (err: any) {
        logger.error('e ' + err); // Traducido (manteniendo 'e')
         // Handle known AppErrors
        if (err instanceof AppError) {
            return res.status(err.statusCode).json({ error: err.message });
        }
         // Handle generic errors
        return res.status(500).json({ error: 'Error al enviar mensaje', details: err.message }); // Traducido
    }
};


export const SynclistTemplates = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { tenantId } = req.user;
        const { whatsappId } = req.params;

        if (!tenantId || !whatsappId) {
            return res.status(400).json({ error: true, message: 'tenantId y whatsappId son obligatorios' }); // Traducido
        }

        await SyncListTemplate(Number(tenantId), Number(whatsappId));

        return res.status(200).json({ error: false, message: 'Plantillas sincronizadas con éxito' }); // Traducido

    } catch (err: any) {
        logger.error('Error al sincronizar plantillas controller: ' + err); // Traducido
        return res.status(500).json({ error: true, message: err.message || 'Error al sincronizar plantillas' }); // Traducido
    }
};

export const listTemplateCategories = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { tenantId } = req.user;
        const { whatsappId } = req.params;

        if (!tenantId || !whatsappId) {
            return res.status(400).json({ error: true, message: 'tenantId y whatsappId son obligatorios' }); // Traducido
        }

        const categories = await ListTemplateCategories(Number(tenantId), Number(whatsappId));

        return res.status(200).json({ error: false, categories: categories });

    } catch (err: any) {
        logger.error('Error al listar categorías de plantillas controller: ' + err); // Traducido
        return res.status(500).json({ error: true, message: err.message || 'Error al listar categorías de plantillas' }); // Traducido
    }
};

export const listTemplatesByCategory = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { tenantId } = req.user;
        const { whatsappId, category } = req.params;

        if (!tenantId || !whatsappId || !category) {
            return res.status(400).json({ error: true, message: 'tenantId, whatsappId y categoría son obligatorios' }); // Traducido
        }

        const templates = await ListTemplatesByCategory(Number(tenantId), Number(whatsappId), String(category));

        return res.status(200).json({ error: false, templates: templates });

    } catch (err: any) {
        logger.error('Error al listar plantillas por categoría controller: ' + err); // Traducido
        return res.status(500).json({ error: true, message: err.message || 'Error al listar plantillas por categoría' }); // Traducido
    }
};

interface TemplateSendBody {
    idFront: string;
    body: string; // This seems to hold JSON data based on usage
    components?: any[]; // Structure depends on the template
}

export const templatesend = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { ticketId } = req.params;
        const { tenantId, id: userId } = req.user;
        const { idFront, body } = req.body as TemplateSendBody; // Assuming body contains the JSON string
        const file = req.file; // For handling potential file uploads

        let dataJson: any; // To store parsed JSON
        try {
            dataJson = JSON.parse(body); // Parse the JSON string from body
        } catch (parseError) {
            return res.status(400).json({ error: true, message: 'Invalid dataJson format' }); // Keep original error message structure
        }

        logger.debug("Sending template message controller: user: " + userId); // Traducido

        const user = await User.findByPk(userId);
         if (!user) {
             throw new AppError('Usuario no encontrado.', 404); // Traducido
         }

        if (!ticketId) {
            return res.status(400).json({ error: true, message: 'ticketId son obligatorios' }); // Traducido
        }

        // Handle file if present
        if (file) {
             const publicDir = path.join(__dirname, '..', '..', 'public'); // Adjust path as necessary
             const tenantDir = path.join(publicDir, String(tenantId));

             if (!fs.existsSync(tenantDir)) {
                 fs.mkdirSync(tenantDir, { recursive: true });
             }

             const originalFilename = file.path; // Path where multer saved the file
             const newFilename = file.filename; // The generated filename by multer
             const destPath = path.join(tenantDir, newFilename);

             if (fs.existsSync(originalFilename)) {
                 fs.copyFileSync(originalFilename, destPath); // Use copyFileSync
                 fs.unlinkSync(originalFilename); // Remove the original temp file
             }

             const mediaUrl = `${process.env.BACKEND_URL}/public/${tenantId}/${newFilename}`;

             // Find the header component and update the image link
             if (dataJson.components) {
                 const headerComponent = dataJson.components.find((comp: any) => comp.type === 'header' && comp.parameters && comp.parameters.some((param: any) => param.type === 'image'));
                 if (headerComponent) {
                     const imageParam = headerComponent.parameters.find((param: any) => param.type === 'image');
                     if (imageParam && imageParam.image) {
                         imageParam.image.link = mediaUrl;
                     }
                 }
             }
         }


        const ticket = await ShowTicketService({ id: ticketId, tenantId: Number(tenantId) });

        const msgData = {
            body: body, // Send the original JSON string or the parsed object? API might expect string
            fromMe: true,
            read: true,
            mediaType: 'template', // Explicitly set mediaType
            sendType: `template:${user.name || 'System'}`, // Include user name or default
            tenantId: ticket.tenantId,
            dataJson: JSON.stringify(dataJson) // Ensure it's stringified if needed by service
        };

        const newMessage = await CreateMessageSystemService({
            msgData: msgData,
            tenantId: ticket.tenantId,
            ticket: ticket,
            userId: userId,
            // scheduleDate: undefined, // Add if scheduling is implemented
            // sendType: 'template', // Already set in msgData
            status: 'pending',
            idFront: idFront
        });

        return res.status(200).json({
            error: false,
            message: 'Template message sent', // Keep original
            msg: newMessage
        });

    } catch (err: any) {
        logger.error('Error in template message controller: ' + err); // Traducido
        return res.status(500).json({ error: true, message: err.message || 'Error al enviar mensaje de plantilla' }); // Traducido
    }
};

// --- END OF FILE MessageHubController.ts ---