import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Cambia la columna 'type' en 'Whatsapps' para que no permita nulos y tenga default 'whatsapp'
    return queryInterface.changeColumn('Whatsapps', 'type', {
      type: DataTypes.STRING,
      allowNull: false, // No permite nulos
      defaultValue: 'whatsapp'
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Revierte los cambios en la columna 'type'
    return queryInterface.changeColumn('Whatsapps', 'type', {
      type: DataTypes.STRING,
      allowNull: false, // Mantiene NOT NULL (basado en el 'up' original)
      defaultValue: 'w' // Vuelve al default 'w'
    });
  }
};