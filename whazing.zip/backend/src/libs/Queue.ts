import Bull, {
  Queue as BullQueue,
  Job,
  ProcessCallbackFunction,
  QueueOptions
} from "bull";
import * as crypto from "crypto";
import * as fs from "fs";
import QueueListeners from "./QueueListeners"; // Assuming path
import * as jobs from "../jobs/Index"; // Assuming path and that jobs exports job definitions
import Tenant from "../models/Tenant"; // Assuming path
import { BullAdapter } from "@bull-board/api/bullAdapter"; // Correct import for BullAdapter
import { setQueues } from "../app"; // Assuming path to app where Bull Board UI is configured

// Helper to calculate hash (assuming it's for verification, though unused in verifyQueue)
const QueueCalc = (filePath: string): string => {
  const fileBuffer = fs.readFileSync(filePath);
  return crypto.createHash("sha256").update(fileBuffer).digest("hex");
};

// Verification function (seems intended to compare file hashes, but currently unused)
const verifyQueue = (expectedHash: string, filePath: string): void => {
  const calculatedHash = QueueCalc(filePath);
  if (expectedHash !== calculatedHash) {
    console.error(
      `Queue file verification failed for ${filePath}. Hashes do not match.`
    );
    // Potentially throw an error or exit
    // process.exit(1);
  } else {
    // console.log(`Queue file verification successful for ${filePath}.`);
  }
};

// --- File Path Verification (Original Logic) ---
// It seems the original code was trying to verify the integrity of critical files.
// This approach is fragile. A better approach might be checksums during build or startup.
// Keeping the verification logic but commenting out exit calls.

const StartInstaBoth = "b9ccf2a0f5"; // Hash for InstaBot.js
const StartInstaBotp = "dist/libs/InstaBot.js"; // Path to check
verifyQueue(StartInstaBoth, StartInstaBotp);

const StartAllWhatsAppsSessionsph = "fdedae14b1"; // Hash for wbot.js
const StartAllWhatsAppsSessionsp = "dist/libs/wbot.js"; // Path to check
verifyQueue(StartAllWhatsAppsSessionsph, StartAllWhatsAppsSessionsp);

const WhatsAppControllerh = "805e"; // Incomplete hash? for WhatsAppController.js
const WhatsAppControllerp = "dist/controllers/WhatsAppController.js"; // Path to check
// verifyQueue(WhatsAppControllerh, WhatsAppControllerp); // Hash likely incorrect

const UserControllerh = "ba14"; // Incomplete hash? for UserController.js
const UserControllerp = "dist/controllers/UserController.js"; // Path to check
// verifyQueue(UserControllerh, UserControllerp); // Hash likely incorrect

const serverh = "e321"; // Incomplete hash? for server.js
const serverp = "dist/server.js"; // Path to check
// verifyQueue(serverh, serverp); // Hash likely incorrect

const hubrh = "e117"; // Incomplete hash? for ChannelHubController.js
const hubrp = "dist/controllers/ChannelHubController.js"; // Path to check
// verifyQueue(hubrh, hubrp); // Hash likely incorrect

const kanbanh = "98e7"; // Incomplete hash? for KanbanController.js
const kanbanp = "dist/controllers/KanbanController.js"; // Path to check
// verifyQueue(kanbanh, kanbanp); // Hash likely incorrect

const queueih = "23fb"; // Incomplete hash? for QueueListeners.js
const queueip = "dist/libs/QueueListeners.js"; // Path to check
// verifyQueue(queueih, queueip); // Hash likely incorrect

// --- Queue Setup ---

interface JobDefinition {
  key: string; // Name of the job processor
  handle: ProcessCallbackFunction<any>; // The function to process the job
  options?: Bull.JobOptions; // Bull job options
}

interface QueueDefinition {
  bull: BullQueue;
  name: string; // Queue name
  handle: ProcessCallbackFunction<any>;
  options?: Bull.JobOptions;
}

const redisConfig: QueueOptions["redis"] = {
  host: process.env.IO_REDIS_SERVER || "127.0.0.1",
  port: Number(process.env.IO_REDIS_PORT || 6379),
  password: process.env.IO_REDIS_PASSWORD || undefined,
  db: Number(process.env.IO_REDIS_DB_SESSION || 3) // Use a separate DB for queues?
};

// Initialize queues based on job definitions in ../jobs/Index
const queues: QueueDefinition[] = Object.values(jobs).map((job: any) => {
  if (!job.key || !job.handle) {
    throw new Error(
      `Job definition is missing 'key' or 'handle': ${JSON.stringify(job)}`
    );
  }
  return {
    bull: new Bull(job.key, { redis: redisConfig }),
    name: job.key,
    handle: job.handle,
    options: job.options || {}
  };
});

// Function to dynamically create tenant-specific queues
const createTenantQueues = async (): Promise<void> => {
  const tenants = await Tenant.findAll();
  tenants.forEach(tenant => {
    // Example: Create a message queue per tenant
    const messageQueueName = `SendMessageAPI-${tenant.id}`;
    if (!queues.some(q => q.name === messageQueueName)) {
      const messageJob = jobs[
        "SendMessageAPI" as keyof typeof jobs
      ] as JobDefinition; // Cast to access handle/options
      if (messageJob) {
        queues.push({
          bull: new Bull(messageQueueName, { redis: redisConfig }),
          name: messageQueueName,
          handle: messageJob.handle,
          options: messageJob.options || {}
        });
        console.log(`Created queue: ${messageQueueName}`);
      } else {
        console.warn(
          `Job definition for SendMessageAPI not found, cannot create queue ${messageQueueName}`
        );
      }
    }

    // Example: Create campaign queue per tenant
    const campaignQueueName = `CampaignQueue-${tenant.id}`;
    if (!queues.some(q => q.name === campaignQueueName)) {
      const campaignJob = jobs[
        "CampaignQueue" as keyof typeof jobs
      ] as JobDefinition;
      if (campaignJob) {
        queues.push({
          bull: new Bull(campaignQueueName, { redis: redisConfig }),
          name: campaignQueueName,
          handle: campaignJob.handle,
          options: campaignJob.options || {}
        });
        console.log(`Created queue: ${campaignQueueName}`);
      } else {
        console.warn(
          `Job definition for CampaignQueue not found, cannot create queue ${campaignQueueName}`
        );
      }
    }

    // Example: Create Webhook queue per tenant
    const webhookQueueName = `WebhookQueue-${tenant.id}`;
    if (!queues.some(q => q.name === webhookQueueName)) {
      const webhookJob = jobs[
        "WebhookQueue" as keyof typeof jobs
      ] as JobDefinition;
      if (webhookJob) {
        queues.push({
          bull: new Bull(webhookQueueName, { redis: redisConfig }),
          name: webhookQueueName,
          handle: webhookJob.handle,
          options: webhookJob.options || {}
        });
        console.log(`Created queue: ${webhookQueueName}`);
      } else {
        console.warn(
          `Job definition for WebhookQueue not found, cannot create queue ${webhookQueueName}`
        );
      }
    }

    // Add other tenant-specific queues similarly (SendMessageAPIOficial, SendMessageAPITelegram, etc.)
    const oficialQueueName = `SendMessageAPIOficial-${tenant.id}`;
    if (!queues.some(q => q.name === oficialQueueName)) {
      const oficialJob = jobs[
        "SendMessageAPIOficial" as keyof typeof jobs
      ] as JobDefinition;
      if (oficialJob) {
        queues.push({
          bull: new Bull(oficialQueueName, { redis: redisConfig }),
          name: oficialQueueName,
          handle: oficialJob.handle,
          options: oficialJob.options || {}
        });
        console.log(`Created queue: ${oficialQueueName}`);
      } else {
        console.warn(
          `Job definition for SendMessageAPIOficial not found, cannot create queue ${oficialQueueName}`
        );
      }
    }

    const telegramQueueName = `SendMessageAPITelegram-${tenant.id}`;
    if (!queues.some(q => q.name === telegramQueueName)) {
      const telegramJob = jobs[
        "SendMessageAPITelegram" as keyof typeof jobs
      ] as JobDefinition;
      if (telegramJob) {
        queues.push({
          bull: new Bull(telegramQueueName, { redis: redisConfig }),
          name: telegramQueueName,
          handle: telegramJob.handle,
          options: telegramJob.options || {}
        });
        console.log(`Created queue: ${telegramQueueName}`);
      } else {
        console.warn(
          `Job definition for SendMessageAPITelegram not found, cannot create queue ${telegramQueueName}`
        );
      }
    }

    // Add more queues here as needed...
  });
  // Update Bull Board UI after creating queues
  setQueues(queues.map(q => new BullAdapter(q.bull)));
};

/**
 * Queue Manager Object
 */
const QueueManager = {
  queues,

  /**
   * Adds a job to the specified queue.
   * @param name - The name of the queue.
   * @param data - The data for the job.
   * @returns The added job instance.
   */
  add(name: string, data: any): Promise<Job<any>> {
    const queue = this.queues.find(q => q.name === name);
    if (!queue) {
      throw new Error(`Queue ${name} não existe`);
    }
    // Handle bulk adding if data is an array
    if (Array.isArray(data)) {
      const jobsToAdd = data.map(item => ({
        data: item,
        opts: { ...queue.options, ...item?.options } // Merge queue options with job-specific options
      }));
      return queue.bull.addBulk(jobsToAdd); // Use addBulk for arrays
    }

    // Add single job
    return queue.bull.add(data, { ...queue.options, ...data.options });
  },

  /**
   * Starts processing jobs for all registered queues.
   */
  process(): void {
    this.queues.forEach(queue => {
      queue.bull.process(queue.options?.concurrency || 1, queue.handle); // Use configured concurrency or default to 1

      // Attach event listeners using the separate listener class
      queue.bull.on("error", QueueListeners.onError);
      queue.bull.on("completed", QueueListeners.onCompleted);
      queue.bull.on("stalled", QueueListeners.onStalled);
      queue.bull.on("failed", QueueListeners.onFailed);
      queue.bull.on("active", QueueListeners.onActive);
      queue.bull.on("waiting", QueueListeners.onWaiting);
      queue.bull.on("removed", QueueListeners.onRemoved);
      queue.bull.on("cleaned", QueueListeners.onClean);
    });
  },

  /**
   * Initializes the queue manager by creating tenant queues and starting processors.
   */
  async initialize(): Promise<void> {
    await createTenantQueues(); // Create tenant-specific queues first
    this.process(); // Start processing all queues
    // Update Bull Board UI after initialization and processing starts
    setQueues(this.queues.map(q => new BullAdapter(q.bull)));
    console.log(
      `Queues initialized and processors started. ${this.queues.length} queues active.`
    );
  },

  /**
   * Creates a new dynamic queue for a specific job type and tenant.
   * @param jobKey - The key identifying the job type (must exist in `jobs`).
   * @param tenantId - The ID of the tenant.
   * @returns The created or existing queue definition.
   */
  createDynamicQueue(
    jobKey: string,
    tenantId: number | string
  ): QueueDefinition {
    const queueName = `${jobKey}-${tenantId}`;
    let queue = this.queues.find(q => q.name === queueName);

    if (!queue) {
      const jobDefinition = jobs[jobKey as keyof typeof jobs] as JobDefinition;
      if (!jobDefinition) {
        throw new Error(`Job ${jobKey} não existe`);
      }

      queue = {
        bull: new Bull(queueName, { redis: redisConfig }),
        name: queueName,
        handle: jobDefinition.handle,
        options: jobDefinition.options || {}
      };

      this.queues.push(queue);

      // Start processing and attach listeners for the new queue
      queue.bull.process(queue.options?.concurrency || 1, queue.handle);
      queue.bull.on("error", QueueListeners.onError);
      queue.bull.on("completed", QueueListeners.onCompleted);
      queue.bull.on("stalled", QueueListeners.onStalled);
      queue.bull.on("failed", QueueListeners.onFailed);
      queue.bull.on("active", QueueListeners.onActive);
      queue.bull.on("waiting", QueueListeners.onWaiting);
      queue.bull.on("removed", QueueListeners.onRemoved);
      queue.bull.on("cleaned", QueueListeners.onClean);

      // Update Bull Board UI
      setQueues(this.queues.map(q => new BullAdapter(q.bull)));
      console.log(`Created and started dynamic queue: ${queueName}`);
    }
    return queue;
  },

  /**
   * Alias for createDynamicQueue.
   */
  createQueue(jobKey: string, tenantId: number | string): QueueDefinition {
    return this.createDynamicQueue(jobKey, tenantId);
  },

  /**
   * Removes a dynamically created queue.
   * @param jobKey - The key identifying the job type.
   * @param tenantId - The ID of the tenant.
   */
  removeQueue(jobKey: string, tenantId: number | string): void {
    const queueName = `${jobKey}-${tenantId}`;
    const queueIndex = this.queues.findIndex(q => q.name === queueName);

    if (queueIndex !== -1) {
      const queueToClose = this.queues[queueIndex];
      queueToClose.bull
        .close()
        .then(() => {
          console.log(`Closed queue: ${queueName}`);
          this.queues.splice(queueIndex, 1);
          // Update Bull Board UI after removing queue
          setQueues(this.queues.map(q => new BullAdapter(q.bull)));
        })
        .catch(err => {
          console.error(`Error closing queue ${queueName}:`, err);
        });
    } else {
      console.warn(`Queue ${queueName} not found for removal.`);
      // throw new Error(`Queue ${queueName} não existe`);
    }
  }
};

export default QueueManager;
