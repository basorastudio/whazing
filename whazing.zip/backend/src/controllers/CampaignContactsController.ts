import { Request, Response } from "express";
import CreateCampaignContactsService from "../services/CampaignServices/CreateCampaignContactsService";
import ListCampaignContactsService from "../services/CampaignServices/ListCampaignContactsService";
import DeleteCampaignContactsService from "../services/CampaignServices/DeleteCampaignContactsService";
import DeleteAllCampaignContactsService from "../services/CampaignServices/DeleteAllCampaignContactsService";

interface ContactData {
  // Define structure of contact data expected in the array
  // Example:
  name: string;
  number: string;
  email?: string;
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const contacts: ContactData[] = [...req.body]; // Assuming body is an array of contacts
  const { campaignId } = req.params;

  const serviceData = {
    campaignContacts: contacts, // Use a more descriptive name
    campaignId: parseInt(campaignId, 10) // Ensure campaignId is a number
  };

  const records = await CreateCampaignContactsService(serviceData);

  return res.status(201).json(records); // 201 Created
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user; // Assuming tenantId is on req.user
  const { campaignId } = req.params;

  const serviceData = {
    campaignId: parseInt(campaignId, 10), // Ensure campaignId is a number
    tenantId
  };

  const contacts = await ListCampaignContactsService(serviceData);

  return res.status(200).json(contacts);
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const { campaignId, contactId } = req.params;

  const serviceData = {
    campaignId: parseInt(campaignId, 10),
    contactId: parseInt(contactId, 10), // Ensure contactId is a number
    tenantId
  };

  await DeleteCampaignContactsService(serviceData);

  return res.status(200).json({ message: "Contacto de Campaña eliminado" });
};

export const removeAll = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const { campaignId } = req.params;

  const serviceData = {
    campaignId: parseInt(campaignId, 10),
    tenantId
  };

  await DeleteAllCampaignContactsService(serviceData);

  return res.status(200).json({ message: "Contactos de Campaña eliminados" });
};
