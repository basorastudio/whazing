import { Request, Response } from "express";
import { getIO } from "../libs/socket";
import AppError from "../errors/AppError";
import DeleteWhatsAppService from "../services/WhatsappService/DeleteWhatsAppService";
import ListWhatsAppsService from "../services/WhatsappService/ListWhatsAppsService";
import ShowWhatsAppService from "../services/WhatsappService/ShowWhatsAppService";
import UpdateWhatsAppService from "../services/WhatsappService/UpdateWhatsAppService";
import CreateWhatsAppService from "../services/WhatsappService/CreateWhatsAppService";
import Tenant from "../models/Tenant"; // Ajustar ruta
import Plan from "../models/Plan"; // Ajustar ruta
import { removeWbot, restartWbot } from "../libs/wbot"; // Asumiendo estas funciones existen y están exportadas
import CheckSettingsHelper from "../helpers/CheckSettingsHelper"; // Ajustar ruta
import ListTotalWhatsAppService from "../services/WhatsappService/ListTotalWhatsAppService";
import { tokenSchema as RefreshToken } from "../helpers/RefreshToken"; // Ajustar ruta

// Extiende la interfaz Request
interface WhatsAppRequest extends Request {
  user?: {
    id: string | number;
    tenantId: string | number;
    profile: string;
  };
  // Tipado más específico para body/params si es necesario
  body: any;
  params: {
    whatsappId?: string;
  };
}

// Obtener todas las conexiones WhatsApp para el tenant
export const index = async (
  req: WhatsAppRequest,
  res: Response
): Promise<Response> => {
  // Lógica de verificación de token (mantener como en el original, pero con comentarios)
  const tokenDR = "50372a5ac8ebc1de57e585f153913d"; // Token específico
  const tokenDRencoded = RefreshToken(tokenDR); // Codifica token
  const tokenDN = "d1a25cdd43757f798d95c1a9b5ead6c77d08e4b8"; // Otro token específico
  const tokenDNencoded = RefreshToken(tokenDN); // Codifica token
  const settingType = await CheckSettingsHelper(tokenDNencoded); // Verifica configuración

  // Compara configuración con token esperado
  if (settingType !== tokenDRencoded) {
    const totalConnections = await ListTotalWhatsAppService(); // Obtiene total global
    // Si la comparación falla y hay 3 o más conexiones, sale del proceso
    // Esta lógica parece una medida de seguridad/licenciamiento muy específica
    if (totalConnections >= 3) {
      console.error(
        "Token check failed and connection limit reached. Exiting."
      ); // Log y salida
      process.exit(1); // Termina el proceso Node.js
    }
  }

  const { tenantId } = req.user!;
  const whatsapps = await ListWhatsAppsService(Number(tenantId)); // Pasa tenantId como número

  return res.status(200).json(whatsapps);
};

// Obtener una conexión WhatsApp específica
export const show = async (
  req: WhatsAppRequest,
  res: Response
): Promise<Response> => {
  const { whatsappId } = req.params;
  const { tenantId } = req.user!;

  if (!whatsappId) {
    throw new AppError("whatsappId is required", 400); // "whatsappId es requerido"
  }

  const params = {
    id: whatsappId,
    tenantId: Number(tenantId)
  };

  const whatsapp = await ShowWhatsAppService(params);

  return res.status(200).json(whatsapp);
};

// Crear una nueva conexión WhatsApp
export const store = async (
  req: WhatsAppRequest,
  res: Response
): Promise<Response> => {
  const whatsappData = req.body;
  const { tenantId } = req.user!;

  // Lógica de verificación de token y límite (similar a index)
  const tokenDR = "50372a5ac8ebc1de57e585f153913d";
  const tokenDRencoded = RefreshToken(tokenDR);
  const tokenDN = "d1a25cdd43757f798d95c1a9b5ead6c77d08e4b8";
  const tokenDNencoded = RefreshToken(tokenDN);
  const settingType = await CheckSettingsHelper(tokenDNencoded);

  if (settingType !== tokenDRencoded) {
    const totalConnections = await ListTotalWhatsAppService();
    if (totalConnections >= 2) {
      // Límite diferente aquí (2)
      throw new AppError("ERR_NO_PERMISSION_CONNECTIONS_LIMIT", 403); // "ERR_SIN_PERMISO_LIMITE_CONEXIONES"
    }
  }

  // Verifica el límite de conexiones del plan del tenant
  const currentConnections = await ListWhatsAppsService(Number(tenantId));
  const tenant = await Tenant.findByPk(tenantId);
  if (!tenant) {
    throw new AppError("Tenant not found", 404); // "Tenant no encontrado"
  }
  const plan = await Plan.findByPk(tenant.planId);
  if (!plan) {
    throw new AppError("Plan not found for the tenant", 404); // "Plan no encontrado para el tenant"
  }

  if (currentConnections.length >= (plan?.maxConnections || 0)) {
    // Compara con el límite del plan
    throw new AppError("ERR_NO_PERMISSION_CONNECTIONS_LIMIT", 403); // "ERR_SIN_PERMISO_LIMITE_CONEXIONES"
  }

  // Prepara los datos para el servicio de creación
  const dataToCreate = {
    ...whatsappData,
    // whatsappId no se pasa aquí, se genera o viene en el body
    tenantId: Number(tenantId)
  };

  // Llama al servicio para crear la conexión
  const { whatsapp } = await CreateWhatsAppService(dataToCreate);

  return res.status(201).json(whatsapp); // 201 Created
};

// Actualizar una conexión WhatsApp existente
export const update = async (
  req: WhatsAppRequest,
  res: Response
): Promise<Response> => {
  const { whatsappId } = req.params;
  const whatsappData = req.body;
  const { tenantId } = req.user!;

  if (!whatsappId) {
    throw new AppError("whatsappId is required", 400); // "whatsappId es requerido"
  }

  const updateParams = {
    whatsappData: whatsappData,
    whatsappId: whatsappId,
    tenantId: Number(tenantId)
  };

  const { whatsapp } = await UpdateWhatsAppService(updateParams);

  return res.status(200).json(whatsapp);
};

// Eliminar una conexión WhatsApp
export const remove = async (
  req: WhatsAppRequest,
  res: Response
): Promise<Response> => {
  const { whatsappId } = req.params;
  const { tenantId } = req.user!;

  if (!whatsappId) {
    throw new AppError("whatsappId is required", 400); // "whatsappId es requerido"
  }

  const numericWhatsappId = Number(whatsappId);
  const numericTenantId = Number(tenantId);

  // Llama al servicio para eliminar la configuración de la BD
  await DeleteWhatsAppService(numericWhatsappId, numericTenantId);

  // Llama a la función para desconectar y limpiar la sesión de wbot
  removeWbot(numericWhatsappId);

  // Emite evento por socket para notificar la eliminación
  const io = getIO();
  io.emit(`${numericTenantId}:whatsapp`, {
    // Evento específico del tenant
    action: "delete",
    whatsappId: numericWhatsappId
  });

  return res.status(200).json({ message: "Whatsapp deleted." }); // "Whatsapp eliminado."
};

// Reiniciar una conexión WhatsApp específica
export const restart = async (
  req: WhatsAppRequest,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user!; // Asume que la acción es a nivel de tenant
  // Si es por whatsappId específico, obtenerlo de req.params

  // Llama a la función para reiniciar el wbot del tenant
  // Nota: restartWbot podría necesitar más parámetros como el whatsappId específico
  await restartWbot(Number(tenantId)); // Asegura que tenantId es número

  return res.status(200).json({ message: "Whatsapp restart." }); // "Whatsapp reiniciado."
};
