/*
 * Este archivo se ejecuta en un contexto de Node (NO es transpilado por Babel), así que usa solo
 * las características de ES6 que son soportadas por tu versión de Node. https://node.green/
 */

// Configuración para tu aplicación
// https://quasar.dev/quasar-cli/quasar-conf-js
/* eslint-env node */

module.exports = function (ctx) {
  require('dotenv').config()
  return {
    // https://quasar.dev/quasar-cli/supporting-ts
    // supportTS: false,

    // https://quasar.dev/quasar-cli/prefetch-feature
    // preFetch: true,

    // archivo de arranque de la aplicación (/src/boot)
    // --> los archivos de arranque son parte de "main.js"
    // https://quasar.dev/quasar-cli/boot-files
    boot: ['vuelidate', 'ccComponents'],

    // https://quasar.dev/quasar-cli/quasar-conf-js#Property%3A-css
    css: ['app.sass'],

    // https://github.com/quasarframework/quasar/tree/dev/extras
    extras: [
      'ionicons-v4',
      'mdi-v7',
      'fontawesome-v6',
      'eva-icons',
      'themify',
      'line-awesome',
      'roboto-font-latin-ext', // esto o 'roboto-font', ¡NUNCA ambos!

      'roboto-font', // opcional, no estás obligado a usarlo
      'material-icons', // opcional, no estás obligado a usarlo
      'material-icons-outlined'
    ],

    // Lista completa de opciones: https://quasar.dev/quasar-cli/quasar-conf-js#Property%3A-build
    build: {
      env: {
        URL_API: process.env.URL_API || 'http://localhost:3000',
        FACEBOOK_APP_ID: process.env.FACEBOOK_APP_ID
      },
      vueRouterMode: 'hash', // valores disponibles: 'hash', 'history'

      // transpile: false,

      // Agregar dependencias para transpilar con Babel (Array de string/regex)
      // (desde node_modules, que por defecto no son transpilados).
      // Aplica solo si "transpile" está configurado como true.
      // transpileDependencies: [],

      // rtl: false, // https://quasar.dev/options/rtl-support
      // preloadChunks: true,
      // showProgress: false,
      // gzip: true,
      // analyze: true,

      // Las opciones a continuación se configuran automáticamente dependiendo del entorno, configúralas si deseas sobrescribir
      // extractCSS: false,

      // https://quasar.dev/quasar-cli/handling-webpack
      extendWebpack(cfg) {
        cfg.devtool = 'source-map'
      }
    },

    // Lista completa de opciones: https://quasar.dev/quasar-cli/quasar-conf-js#Property%3A-devServer
    devServer: {
      https: false,
      // port: 8080,
      open: true // abre la ventana del navegador automáticamente
    },

    // https://quasar.dev/quasar-cli/quasar-conf-js#Property%3A-framework
    framework: {
      iconSet: 'material-icons', // Conjunto de iconos de Quasar
      lang: 'pt-br',
      config: {
        dark: false
      },
      directives: ['Ripple', 'ClosePopup'],
      // Valores posibles para "importStrategy":
      // * 'auto' - (POR DEFECTO) Auto-importar los componentes y directivas de Quasar necesarios
      // * 'all'  - Especificar manualmente qué importar
      importStrategy: 'auto',

      // Para casos especiales fuera de donde "auto" importStrategy puede tener un impacto
      // (como componentes funcionales como uno de los ejemplos),
      // puedes especificar manualmente los componentes/directivas de Quasar para que estén disponibles en todas partes:
      //
      // components: [],
      // directives: [],

      // Plugins de Quasar
      plugins: ['Notify', 'Dialog', 'LocalStorage']
    },

    animations: 'all', // --- incluye todas las animaciones
    // https://quasar.dev/options/animations
    // animations: [],

    // https://quasar.dev/quasar-cli/developing-ssr/configuring-ssr
    ssr: {
      pwa: false
    },

    // https://quasar.dev/quasar-cli/developing-pwa/configuring-pwa
    pwa: {
      workboxPluginMode: 'GenerateSW', // 'GenerateSW' o 'InjectManifest'
      workboxOptions: {
        maximumFileSizeToCacheInBytes: 5 * 1024 * 1024
      }, // solo para GenerateSW
      manifest: {
        name: 'Whazing',
        // maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
        short_name: 'Whazing',
        description: 'Bot Multi-atención',
        display: 'standalone',
        orientation: 'portrait',
        background_color: '#ffffff',
        theme_color: '#027be3',
        icons: [
          {
            src: 'icons/icon-128x128.png',
            sizes: '128x128',
            type: 'image/png'
          },
          {
            src: 'icons/icon-192x192.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: 'icons/icon-256x256.png',
            sizes: '256x256',
            type: 'image/png'
          },
          {
            src: 'icons/icon-384x384.png',
            sizes: '384x384',
            type: 'image/png'
          },
          {
            src: 'icons/icon-512x512.png',
            sizes: '512x512',
            type: 'image/png'
          }
        ]
      }
    },

    // Lista completa de opciones: https://quasar.dev/quasar-cli/developing-cordova-apps/configuring-cordova
    cordova: {
      // noIosLegacyBuildFlag: true, // descomentar solo si sabes lo que estás haciendo
    },

    // Lista completa de opciones: https://quasar.dev/quasar-cli/developing-capacitor-apps/configuring-capacitor
    capacitor: {
      hideSplashscreen: true
    },

    // Lista completa de opciones: https://quasar.dev/quasar-cli/developing-electron-apps/configuring-electron
    electron: {
      bundler: 'builder', // 'packager' o 'builder'

      packager: {
        // https://github.com/electron-userland/electron-packager/blob/master/docs/api.md#options
        // OS X / Mac App Store
        // appBundleId: '',
        // appCategoryType: '',
        // osxSign: '',
        // protocol: 'myapp://path',
        // Solo Windows
        // win32metadata: { ... }
      },

      builder: {
        // https://www.electron.build/configuration/configuration
        appId: 'Whazing'
      },

      // Más información: https://quasar.dev/quasar-cli/developing-electron-apps/node-integration
      nodeIntegration: true,

      extendWebpack(/* cfg */) {
        // hacer algo con el cfg de Webpack del proceso principal de Electron
        // chainWebpack también está disponible además de este extendWebpack
      }
    }
  }
}
