<template>
  <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-banner v-if="!premium" dense inline-actions class="bg-amber-8 text-white q-mb-md">
      <template v-slot:avatar>
        <q-icon name="star" />
      </template>
      {{ $t('general.msgRecursoPremium') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               icon="mdi-whatsapp"
               :label="$t('general.linkobterpremium')"
               @click="abrirWhatsApp3"
        />
      </template>
    </q-banner>

    <q-card-section v-if="!premium">
      <div class="row items-center justify-around q-col-gutter-md">
        <!-- Texto -->
        <div class="col-xs-12 col-sm-6 text-left">
          <div class="text-h6">
            {{ $t('dashboard.supportPlatform') }}
          </div>
          <div class="text-body q-mt-sm">
            {{ $t('dashboard.donationMessage') }}
          </div>
        </div>
        <!-- Imagem -->
        <div class="col-xs-12 col-sm-4 text-center">
          <img src="https://raw.githubusercontent.com/cleitonme/Whazing-SaaS/main/donate.jpg"
               alt="QR Code para doação via Pix"
               class="donation-image">
        </div>
      </div>
      <!-- Ícones de redes sociais -->
      <div class="row justify-center q-mt-md">
        <div class="social-icons">
          <q-btn round color="green" icon="mdi-whatsapp" size="md" class="q-mx-xs"
                 type="a" href="https://grupo.whazing.com.br/" target="_blank">
            <q-tooltip>Nosso Grupo de WhatsApp</q-tooltip>
          </q-btn>
          <q-btn round color="primary" icon="mdi-web" size="md" class="q-mx-xs"
                 type="a" href="https://www.whazing.com.br" target="_blank">
            <q-tooltip>Nosso Site</q-tooltip>
          </q-btn>
        </div>
      </div>
    </q-card-section>
    <q-table
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      :data="ratings"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="star" class="q-pr-sm"/>
            {{ $t('avaliacao.titulo') }}
          </h2>
          <div class="absolute-top-right q-ma-md">
            <q-btn
              icon="arrow_back"
              :label="$t('relatorios.voltar')"
              to="/relatorios"
              class="color-light1"
              :class="$q.dark.isActive ? ('color-dark1') : ''"
            />
          </div>

          <div class="row q-col-gutter-md">
            <!-- Média das Avaliações - Lado Esquerdo -->
            <div class="col-12 col-md-4">
              <q-card class="bg-primary text-white">
                <q-card-section>
                  <div class="row items-center">
                    <div class="col">
                      <div class="text-h6">{{ $t('avaliacao.media') }}</div>
                      <div class="text-h4">{{ averageRating.toFixed(1) }} / 5.0</div>
                    </div>
                    <div class="col">
                      <q-rating
                        v-model="averageRating"
                        size="2em"
                        color="yellow"
                        readonly
                      />
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </div>

            <!-- Filtros - Lado Direito -->
            <!-- Modify the filters section in your template -->
            <div class="col-12 col-md-8">
              <div class="row q-col-gutter-md">
                <!-- User filter -->
                <div class="col-12 col-md-6">
                  <q-select
                    v-model="filters.userId"
                    :options="usuarios"
                    option-value="id"
                    option-label="name"
                    :label="$t('avaliacao.filtro_usuario')"
                    outlined
                    dense
                    clearable
                    @input="onFilterChange"
                  />
                </div>

                <!-- Channel filter -->
                <div class="col-12 col-md-6">
                  <q-select
                    v-model="filters.whatsappId"
                    :options="whatsapps"
                    emit-value
                    map-options
                    option-value="id"
                    option-label="name"
                    :label="$t('avaliacao.filtro_canal')"
                    outlined
                    dense
                    clearable
                    @input="onFilterChange"
                  />
                </div>

                <!-- Date filters in a separate row -->
                <div class="col-12">
                  <div class="row q-col-gutter-md">
                    <div class="col-12 col-md-6">
                      <p>{{ $t('avaliacao.data_inicial') }}</p>
                      <DatePick
                        dense
                        outlined
                        v-model="filters.startDate"
                        @input="onFilterChange"
                      />
                    </div>
                    <div class="col-12 col-md-6">
                      <p>{{ $t('avaliacao.data_final') }}</p>
                      <DatePick
                        dense
                        outlined
                        v-model="filters.endDate"
                        @input="onFilterChange"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-12">
              <div class="row q-col-gutter-md">
                <div class="col" v-for="(stat, index) in ratingStats" :key="index">
                  <q-card
                    class="text-center cursor-pointer"
                    :class="{'bg-primary text-white': filters.ratingFilter === stat.rating}"
                    @click="filterByRating(stat.rating)"
                  >
                    <q-card-section>
                      <div class="text-h6">{{ stat.emoji }}</div>
                      <div class="text-subtitle1">{{ stat.label }}</div>
                      <div class="text-h5">{{ stat.count }}</div>
                    </q-card-section>
                  </q-card>
                </div>
                <div class="col">
                  <q-card
                    class="text-center cursor-pointer"
                    :class="{'bg-primary text-white': filters.ratingFilter === null}"
                    @click="filterByRating(null)"
                  >
                    <q-card-section>
                      <div class="text-h6">🔍</div>
                      <div class="text-subtitle1">{{ $t('avaliacao.todas_avaliacoes') }}</div>
                      <div class="text-h5" v-if="totalRecords > 0">{{ totalRecords }}</div>
                    </q-card-section>
                  </q-card>
                </div>
              </div>
            </div>

          </div>
        </div>
      </template>

      <template v-slot:body-cell-ticketId="props">
        <q-td :props="props">
          <button
            class="q-mr-sm"
            @click.prevent="visualizarChat(props.row.ticketId)"
          >
            <i class="fa fa-comments"></i> {{ props.row.ticketId }}
          </button>
        </q-td>
      </template>

      <!-- Template para a coluna de avaliação -->
      <template v-slot:body-cell-rate="props">
        <q-td :props="props">
          <q-rating
            v-model="props.row.rate"
            size="1.5em"
            color="yellow"
            readonly
          />
        </q-td>
      </template>

      <!-- Template para a coluna de data -->
      <template v-slot:body-cell-createdAt="props">
        <q-td :props="props">
          {{ formatDate(props.row.createdAt) }}
        </q-td>
      </template>
    </q-table>

    <!-- Modal de Chat -->
    <ChatModal v-if="mostrarModal" :ticketId="String(ticketIdAtual)" @close="fecharChatModal" />

  </div>
</template>

<script>
import { date } from 'quasar'
import { ListarAvaliacoes, ListarAvaliacoesMedia } from 'src/service/avaliacoes'
import { ListarUsuarios } from 'src/service/user'
import { ListarCores, Listarp } from 'src/service/configuracoesgeneral'
import ChatModal from 'src/pages/relatorios/ChatModal.vue'
import { mapGetters } from 'vuex'

export default {
  name: 'Avaliações',
  components: {
    ChatModal
  },
  data () {
    return {
      ratingStats: [
        { emoji: '🤩', label: this.$t('avaliacao.extremamente_satisfeito'), count: 0, rating: 5 },
        { emoji: '😊', label: this.$t('avaliacao.muito_satisfeito'), count: 0, rating: 4 },
        { emoji: '🙂', label: this.$t('avaliacao.satisfeito'), count: 0, rating: 3 },
        { emoji: '🙁', label: this.$t('avaliacao.insatisfeito'), count: 0, rating: 2 },
        { emoji: '😞', label: this.$t('avaliacao.muito_insatisfeito'), count: 0, rating: 1 }
      ],
      ratings: [],
      averageRating: 0,
      userProfile: 'user',
      mostrarModal: false,
      loading: false,
      premium: true,
      userId: null,
      usuarios: [],
      whatsappNumbers: [],
      totalRecords: 0,
      filters: {
        userId: null,
        whatsappId: null,
        startDate: null,
        endDate: null,
        ratingFilter: null
      },
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        page: 1,
        hasMore: true
      },
      columns: [
        { name: 'ticketId', label: this.$t('avaliacao.coluna_ticket'), field: 'ticketId', align: 'left' },
        {
          name: 'rate',
          label: this.$t('avaliacao.coluna_avaliacao'),
          field: 'rate',
          align: 'center',
          sortable: true
        },
        {
          name: 'userName',
          label: this.$t('avaliacao.coluna_usuario'),
          field: row => row.user?.name,
          align: 'left'
        },
        {
          name: 'contactName',
          label: this.$t('avaliacao.coluna_contato'),
          field: row => row.contact?.name,
          align: 'left'
        },
        {
          name: 'createdAt',
          label: this.$t('avaliacao.coluna_data'),
          field: 'createdAt',
          align: 'center',
          sortable: true
        }
      ]
    }
  },
  computed: {
    ...mapGetters([
      'whatsapps'
    ])
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    formatDate(dateString) {
      return date.formatDate(dateString, 'DD/MM/YYYY HH:mm')
    },
    async listarUsuarios() {
      const data = await ListarUsuarios()
      this.usuarios = data.data.users
    },
    fecharChatModal () {
      this.mostrarModal = false
    },
    visualizarChat (ticketId) {
      this.ticketIdAtual = ticketId
      this.mostrarModal = true
    },
    onFilterChange() {
      this.pagination.page = 1
      this.fetchRatings()
    },
    async fetchRatings() {
      this.loading = true
      try {
        const startDate = this.filters.startDate
          ? new Date(this.filters.startDate).toISOString()
          : null

        const endDate = this.filters.endDate
          ? (() => {
            const date = new Date(this.filters.endDate)
            date.setDate(date.getDate() + 1)
            return date.toISOString()
          })()
          : null

        // Reset ratings array when filters change
        if (this.pagination.page === 1) {
          this.ratings = []
        }

        const params = {
          startDate,
          endDate,
          userId: null,
          whatsappId: this.filters.whatsappId,
          pageNumber: this.pagination.page
        }

        if (this.filters.userId && this.filters.userId.id) {
          params.userId = this.filters.userId.id
        }

        const [response, averageResponse] = await Promise.all([
          ListarAvaliacoes(params),
          ListarAvaliacoesMedia(params)
        ])

        if (response.data && Array.isArray(response.data.records)) {
          let records = response.data.records.map((rating) => ({
            id: rating.id,
            ticketId: rating.ticketId,
            rate: rating.rate,
            user: rating.user,
            contact: rating.contact,
            createdAt: rating.createdAt
          }))

          // Aplicar filtro de pontuação localmente (frontend)
          if (this.filters.ratingFilter !== null) {
            records = records.filter(rating => rating.rate === this.filters.ratingFilter)
          }

          // Quando os filtros mudam, substitui todo o array ao invés de concatenar
          if (this.pagination.page === 1) {
            this.ratings = records
            this.totalRecords = response.data.count || 0
          } else {
            // Apenas concatena para paginação
            this.ratings = [...this.ratings, ...records]
          }

          // Atualiza metadados de paginação
          if (this.filters.ratingFilter !== null) {
            // Se estiver filtrando por pontuação, ajuste a contagem total
            this.pagination.rowsNumber = this.ratings.length
            this.pagination.hasMore = false // Todos os dados já estão carregados
          } else {
            this.pagination.rowsNumber = response.data.count || 0
            this.pagination.hasMore = response.data.hasMore
          }

          this.averageRating = Number(averageResponse.data) || 0

          // Atualiza as estatísticas de avaliação com base nos dados filtrados
          this.ratingStats.forEach(stat => {
            stat.count = response.data.records.filter(r => r.rate === stat.rating).length
          })
        }
      } catch (error) {
        console.error('Erro ao buscar avaliações:', error)
        this.$q.notify({
          type: 'negative',
          message: this.$t('avaliacao.erro_carregar')
        })
      } finally {
        this.loading = false
      }
    },
    onScroll({ to }) {
      if (!this.loading && this.pagination.hasMore && to >= (this.ratings.length - 10)) {
        this.pagination.page++
        this.fetchRatings()
      }
    },
    abrirWhatsApp3() {
      const message = encodeURIComponent(this.$t('general.obterpremium'))
      const url = `https://wa.me/554899416725?text=${message}`
      window.open(url, '_blank')
    },
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    filterByRating(rating) {
      this.filters.ratingFilter = rating
      this.pagination.page = 1
      this.fetchRatings()
    }
  },
  async mounted() {
    this.loadColors()
    await this.fetchRatings()
    await this.listarUsuarios()
    this.userProfile = localStorage.getItem('profile')
    await this.loadVersionp()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

.ratings-table
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1

  thead tr:last-child th
    top: 63px

  thead tr:first-child th
    top: 0
</style>
