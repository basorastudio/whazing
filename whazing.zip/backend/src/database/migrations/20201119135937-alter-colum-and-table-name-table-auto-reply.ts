import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      // Renombra la columna 'reply' a 'name' en la tabla 'AutoReply'
      queryInterface.renameColumn('AutoReply', 'reply', 'name'),
      // Elimina la columna 'words' de la tabla 'AutoReply'
      queryInterface.removeColumn('AutoReply', 'words')
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
       // Renombra la columna 'name' de nuevo a 'reply'
      queryInterface.renameColumn('AutoReply', 'name', 'reply'),
      // Vuelve a añadir la columna 'words' con el tipo ARRAY de STRING
      queryInterface.addColumn('AutoReply', 'words', {
        type: DataTypes.ARRAY(DataTypes.STRING)
      })
    ]);
  }
};