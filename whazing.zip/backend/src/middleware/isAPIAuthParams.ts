/**
 * Middleware para autenticar solicitudes de API usando un token JWT
 * proporcionado como parámetro de consulta (query parameter) llamado 'bearertoken'.
 */
import { Response, NextFunction } from "express";
import { verify } from "jsonwebtoken";
import AppError from "../errors/AppError";
import authConfig from "../config/auth";
import { AuthRequest } from "./interfaces/AuthRequest"; // Importa la interfaz

interface TokenPayload {
  apiId: string | number;
  sessionId: string | number; // El original lo convertía a Number, así que puede venir como string
  tenantId: string | number;
  iat: number;
  exp: number;
}

const isAPIAuthParams = (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): void => {
  // Extrae el token del parámetro de consulta 'bearertoken'
  const tokenFromQuery = req.query.bearertoken as string | undefined;

  // Verifica si el token existe y es una cadena de texto
  if (!tokenFromQuery || typeof tokenFromQuery !== "string") {
    throw new AppError("Token no proporcionado o inválido en parámetros.", 401); // 401 Unauthorized
  }

  try {
    // Verifica el token usando el secreto
    const decoded = verify(tokenFromQuery, authConfig.secret);

    // Extrae los datos del payload
    const { apiId, sessionId, tenantId } = decoded as TokenPayload;

    // Adjunta los datos al objeto request, convirtiendo sessionId a número como en el original
    // Asegúrate de que la interfaz AuthRequest tenga la propiedad apiAuth
    req.apiAuth = {
      apiId,
      sessionId: Number(sessionId), // Convierte a número
      tenantId
    };

    // Pasa al siguiente middleware/controlador
    return next();
  } catch (err) {
    // Si la verificación falla
    throw new AppError("Token inválido.", 401); // 401 Unauthorized
  }
};

// Exporta la función con ambos nombres como en el original para compatibilidad
export { isAPIAuthParams }; // Exportación nombrada
export default isAPIAuthParams; // Exportación default (el original tenía `exports.default = exports.isAPIAuthParams`)
