import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'initialStep' a la tabla 'StepsReply'
    return queryInterface.addColumn("StepsReply", "initialStep", {
      type: DataTypes.INTEGER, // Tipo INTEGER
      defaultValue: null,
      allowNull: true
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'initialStep' de la tabla 'StepsReply'
    return queryInterface.removeColumn("StepsReply", "initialStep");
  }
};
