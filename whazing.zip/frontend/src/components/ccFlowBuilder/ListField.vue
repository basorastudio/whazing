<template>
  <div>
    <q-card flat class="q-pa-sm q-pb-md">
      <q-card-section class="q-pa-none">
        <div class="text-subtitle2 q-mb-sm">
          {{ $t('ccFlowBuilder.addlist') }}
        </div>
        <!-- Header -->
        <div class="q-mb-md">
          <q-input
            outlined
            dense
            required
            v-model="$attrs.element.data.header.text"
            :label="$t('ccFlowBuilder.titulo')"
          />
        </div>

        <!-- Body -->
        <div class="q-mb-md">
          <q-input
            outlined
            dense
            type="textarea"
            autogrow
            v-model="$attrs.element.data.body.text"
            :label="$t('ccFlowBuilder.descricao')"
          />
        </div>

        <!-- Sections -->
        <div class="q-mb-md">
          <div class="text-caption q-mb-xs">{{ $t('ccFlowBuilder.secoes') }}</div>

          <div v-for="(section, sectionIndex) in $attrs.element.data.action.sections" :key="'section-' + sectionIndex" class="q-mb-lg q-pa-md bg-grey-2 rounded-borders">
            <!-- Section Title -->
            <div class="row q-col-gutter-sm items-center q-mb-sm">
              <div class="col">
                <q-input
                  dense
                  outlined
                  required
                  v-model="section.title"
                  :label="$t('ccFlowBuilder.tituloSecao')"
                />
              </div>
              <div class="col-auto">
                <q-btn
                  flat
                  round
                  color="negative"
                  icon="mdi-delete"
                  @click="removeSection(sectionIndex)"
                >
                  <q-tooltip>{{ $t('general.remover') }}</q-tooltip>
                </q-btn>
              </div>
            </div>

            <!-- Rows -->
            <div class="q-pl-md q-mb-md">
              <div class="text-caption q-mb-xs">{{ $t('ccFlowBuilder.linhas') }}</div>

              <div v-for="(row, rowIndex) in section.rows" :key="'row-' + rowIndex" class="q-mb-md q-pa-sm bg-white rounded-borders">
                <div class="row q-col-gutter-sm items-center q-mb-sm">
                  <div class="col">
                    <q-input
                      dense
                      outlined
                      required
                      v-model="row.title"
                      :label="$t('ccFlowBuilder.tituloLinha')"
                    />
                  </div>
                  <div class="col-auto">
                    <q-btn
                      flat
                      round
                      color="negative"
                      icon="mdi-delete"
                      @click="removeRow(sectionIndex, rowIndex)"
                    >
                      <q-tooltip>{{ $t('general.remover') }}</q-tooltip>
                    </q-btn>
                  </div>
                </div>

                <q-input
                  dense
                  outlined
                  type="textarea"
                  autogrow
                  v-model="row.description"
                  :label="$t('ccFlowBuilder.descricaoLinha')"
                />
              </div>

              <!-- Add row button -->
              <div class="text-center q-mt-md">
                <q-btn
                  outline
                  class="q-mr-sm generate-button btn-rounded-50"
                  :class="{'generate-button-dark' : $q.dark.isActive}"
                  icon="mdi-plus"
                  :label="$t('ccFlowBuilder.adicionarLinha')"
                  @click="addRow(sectionIndex)"
                  size="sm"
                />
              </div>
            </div>
          </div>

          <!-- Add section button -->
          <div class="text-center q-mt-md">
            <q-btn
              outline
              class="q-mr-sm generate-button btn-rounded-50"
              :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="mdi-plus"
              :label="$t('ccFlowBuilder.adicionarSecao')"
              @click="addSection"
            />
          </div>
        </div>

        <!-- Action Button -->
        <div class="q-mb-md">
          <q-input
            outlined
            dense
            required
            v-model="$attrs.element.data.action.button"
            :label="$t('ccFlowBuilder.textoBotao')"
          />
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
export default {
  name: 'ListField',
  data() {
    return {}
  },
  mounted() {
    // Initialize the data structure if it doesn't exist
    if (!this.$attrs.element.data.header) {
      this.$attrs.element.data.header = {
        type: 'text',
        text: ''
      }
    }

    if (!this.$attrs.element.data.body) {
      this.$attrs.element.data.body = {
        text: ''
      }
    }

    if (!this.$attrs.element.data.action) {
      this.$attrs.element.data.action = {
        sections: [],
        button: 'Clique aqui'
      }
    }

    if (!this.$attrs.element.data.action.sections || !this.$attrs.element.data.action.sections.length) {
      this.$attrs.element.data.action.sections = [
        {
          title: 'Nova Lista',
          rows: [
            {
              id: 1,
              title: 'Nova Linha',
              description: ''
            }
          ]
        }
      ]
    }

    // Ensure all sections and rows have valid IDs
    this.reindexAll()
  },
  methods: {
    addSection() {
      const newSectionId = this.$attrs.element.data.action.sections.length + 1
      this.$attrs.element.data.action.sections.push({
        title: `Nova Lista ${newSectionId}`,
        rows: [
          {
            id: 1,
            title: 'Nova Linha',
            description: ''
          }
        ]
      })
      this.reindexAll()
    },
    removeSection(sectionIndex) {
      this.$attrs.element.data.action.sections.splice(sectionIndex, 1)
      this.reindexAll()
    },
    addRow(sectionIndex) {
      const section = this.$attrs.element.data.action.sections[sectionIndex]
      const nextId = section.rows.length + 1
      section.rows.push({
        id: nextId,
        title: `Nova Linha ${nextId}`,
        description: ''
      })
      this.reindexRows(sectionIndex)
    },
    removeRow(sectionIndex, rowIndex) {
      this.$attrs.element.data.action.sections[sectionIndex].rows.splice(rowIndex, 1)
      this.reindexRows(sectionIndex)
    },
    reindexRows(sectionIndex) {
      const section = this.$attrs.element.data.action.sections[sectionIndex]
      section.rows.forEach((row, index) => {
        row.id = index + 1
      })
    },
    reindexAll() {
      this.$attrs.element.data.action.sections.forEach((section, sectionIndex) => {
        this.reindexRows(sectionIndex)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
