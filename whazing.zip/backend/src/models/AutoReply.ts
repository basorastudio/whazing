import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  HasMany,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AutoIncrement
} from "sequelize-typescript";
import User from "./User";
import StepsReply from "./StepsReply"; // Assuming relation exists
import Tenant from "./Tenant";

@Table({ freezeTableName: true })
class AutoReply extends Model<AutoReply> {
  @PrimaryKey
  @AutoIncrement // Assuming AutoIncrement based on original name resolution
  @Column
  id: number; // Changed to number based on AutoIncrement

  @Column(DataType.TEXT)
  name: string;

  @Default(null)
  @Column(DataType.TEXT)
  celularTeste: string; // 'celularTeste' resolved

  @Default(true)
  @Column
  isActive: boolean;

  @Default(0)
  @Column
  action: number;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @HasMany(() => StepsReply) // Assuming relation exists
  stepsReply: StepsReply[];

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;
}

export default AutoReply;
