import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla de unión 'ContactTags' para la relación muchos a muchos entre Contacts y Tags
    return queryInterface.createTable("ContactTags", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      tagId: {
        type: DataTypes.INTEGER,
        references: { model: "Tags", key: "id" }, // Referencia a Tags
        onUpdate: "CASCADE",
        onDelete: "RESTRICT", // No permite eliminar Tag si tiene asociaciones
        allowNull: false
      },
      contactId: {
        type: DataTypes.INTEGER,
        references: { model: "Contacts", key: "id" }, // Referencia a Contacts
        onUpdate: "CASCADE",
        onDelete: "CASCADE", // Si se elimina Contact, se elimina la asociación
        allowNull: false
      },
      tenantId: {
        type: DataTypes.INTEGER,
        references: { model: "Tenants", key: "id" }, // Referencia a Tenants
        onUpdate: "CASCADE",
        onDelete: "CASCADE", // Si se elimina Tenant, se elimina la asociación
        allowNull: false
        // defaultValue no especificado, podría heredar de la DB o necesitar ser provisto
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la tabla 'ContactTags'
    return queryInterface.dropTable("ContactTags");
  }
};
