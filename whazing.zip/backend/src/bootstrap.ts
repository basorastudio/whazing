// Deobfuscated string access is now inline
import __importDefault from "./_importDefault"; // Assuming __importDefault is a local helper or adjust as needed

import dotenv from "dotenv";

// Definir tipo para las variables de entorno
type Environment = "development" | "production" | "test";

// Validar y tipar NODE_ENV
const currentEnv = (process.env.NODE_ENV || "development") as Environment;

// Cargar configuración de entorno
dotenv.config({
  path: currentEnv === "test" ? ".env.test" : ".env"
});

// Exportar configuración para uso en otros módulos
export const envConfig = {
  environment: currentEnv,
  isTest: currentEnv === "test",
  isProduction: currentEnv === "production"
};

// Helper simulation (remove if you have a real __importDefault)
function __importDefault<T>(mod: { default: T } | T): { default: T } | T {
  return mod && (mod as any).__esModule ? mod : { default: mod };
}

// This file primarily configures environment variables, no main export needed unless used elsewhere directly.
