// --- START OF FILE ForgotController.ts ---

import { Request, Response } from "express";
import { v4 as uuidv4 } from "uuid";
import SendForgotPasswordEmailService from "../services/ForgotPasswordServices/SendForgotPasswordEmailService"; // Asumiendo nombre
import ResetPasswordService from "../services/ForgotPasswordServices/ResetPasswordService"; // Asumiendo nombre

// Interfaces
interface StoreRequestBody {
  email: string;
}
interface StoreRequest extends Request {
  body: StoreRequestBody;
}

interface ResetRequestBody {
  email: string;
  token: string;
  password: string;
}
interface ResetRequest extends Request {
  body: ResetRequestBody;
}

/**
 * @description Inicia el proceso de recuperación de contraseña enviando un correo electrónico.
 * @param {StoreRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const store = async (
  req: StoreRequest,
  res: Response
): Promise<Response> => {
  const { email } = req.body;
  const token = uuidv4();

  const mailSent = await SendForgotPasswordEmailService(email, token);

  if (!mailSent) {
    return res.status(400).json({
      error:
        "Error al enviar el correo. Verifique la dirección de correo electrónico informada."
    }); // HTTP 400 Bad Request - Ajustado error
  }

  return res.status(200).json({
    message: "E-mail enviado con éxito con el token de recuperación."
  }); // HTTP 200 OK - Ajustado mensaje
};

/**
 * @description Restablece la contraseña utilizando el token recibido por correo electrónico.
 * @param {ResetRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const resetPasswords = async (
  req: ResetRequest,
  res: Response
): Promise<Response> => {
  const { email, token, password } = req.body;

  const passwordResetted = await ResetPasswordService(email, token, password);

  if (!passwordResetted) {
    return res.status(400).json({
      error:
        "Token inválido o expirado. Solicite una nueva recuperación de contraseña."
    }); // HTTP 400 Bad Request - Ajustado error
  }

  return res
    .status(200)
    .json({ message: "Contraseña restablecida con éxito." }); // HTTP 200 OK - Ajustado mensaje
};

// --- END OF FILE ForgotController.ts ---
