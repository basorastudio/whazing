import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      // Añade la columna 'isActive' (booleana) a la tabla 'AutoReply'
      queryInterface.addColumn('AutoReply', 'isActive', {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true // Valor predeterminado es true
      }),
      // Añade la columna 'celularTeste' (string) a la tabla 'AutoReply'
      queryInterface.addColumn('AutoReply', 'celularTeste', {
        type: DataTypes.STRING,
        allowNull: true, // Permite nulos
        defaultValue: null // Valor predeterminado es null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      // Elimina la columna 'isActive' de la tabla 'AutoReply'
      queryInterface.removeColumn('AutoReply', 'isActive'),
      // Elimina la columna 'celularTeste' de la tabla 'AutoReply'
      queryInterface.removeColumn('AutoReply', 'celularTeste')
    ]);
  }
};