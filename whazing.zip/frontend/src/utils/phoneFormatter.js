class FormatMask {
  /**
   * Formatea números telefónicos dominicanos
   * Acepta números de 10 dígitos (formato local) o 11 dígitos (con prefijo 1)
   * @param {string} phoneToFormat - Número telefónico a formatear
   * @returns {string} Número formateado como +1 (XXX) XXX-XXXX
   */
  setPhoneFormatMask(phoneToFormat) {
    if (!phoneToFormat) {
      return null
    }

    const number = ('' + phoneToFormat).replace(/\D/g, '')
    
    // Caso 1: Número de 10 dígitos (formato local dominicano)
    if (number.length === 10) {
      const phoneNumberFormatted = number.match(/^(\d{3})(\d{3})(\d{4})$/)
      if (!phoneNumberFormatted) return null
      
      return (
        '+1' +
        ' (' +
        phoneNumberFormatted[1] +
        ') ' +
        phoneNumberFormatted[2] +
        '-' +
        phoneNumberFormatted[3]
      )
    } 
    // Caso 2: Número de 11 dígitos con código de país (1)
    else if (number.length === 11 && number.startsWith('1')) {
      const phoneNumberFormatted = number.match(/^1(\d{3})(\d{3})(\d{4})$/)
      if (!phoneNumberFormatted) return null
      
      return (
        '+1' +
        ' (' +
        phoneNumberFormatted[1] +
        ') ' +
        phoneNumberFormatted[2] +
        '-' +
        phoneNumberFormatted[3]
      )
    }

    return null
  }

  removeMask(number) {
    const filterNumber = number.replace(/\D/g, '')
    return filterNumber
  }

  /**
   * Devuelve el patrón de máscara para números dominicanos
   * Equivalente a (###)###-#### con código de país
   */
  maskPhonePattern(phoneNumber) {
    return '+1 (999) 999-9999'
  }
}

export { FormatMask }

const formatSerializedId = (serializedId) => {
  const formatMask = new FormatMask()
  const number = serializedId?.replace('@c.us', '')

  return formatMask.setPhoneFormatMask(number)?.replace('+1', '🇩🇴')
}

export default formatSerializedId
