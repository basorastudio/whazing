import pdf from 'pdf-parse'; // pdf-parse exports default function
import docxParser from 'docx-parser'; // Assuming docx-parser exports default
import xlsx from 'xlsx';
import tesseract from 'tesseract.js';
import path from 'path';
import fs from 'fs/promises'; // Use promises API
import { parse as csvParse } from 'csv-parse'; // Use named import
import { parseString as xmlParseString } from 'xml2js'; // Use named import
import { JSDOM } from 'jsdom';
import rtfToHtml from '@iarna/rtf-to-html'; // Assuming default export
import mammoth from 'mammoth';
import iconv from 'iconv-lite';

// Helper to resolve local path if URL points to '/public/...'
function getLocalPath(filePathOrUrl: string): string {
    try {
        if (filePathOrUrl.startsWith('http') || filePathOrUrl.startsWith('/public')) {
            // Assuming URLs like http://server/public/tenant/file.ext or /public/tenant/file.ext
            const urlPath = new URL(filePathOrUrl, 'http://dummybase').pathname; // Use dummy base for relative paths
            const relativePath = decodeURIComponent(urlPath.replace(/^\/public/, '')); // Remove /public prefix
            // Assumes the 'public' folder is two levels up from the current file's directory
            return path.join(__dirname, '..', '..', 'public', relativePath);
        }
    } catch (e) {
         // If URL parsing fails, assume it's already a local path
         console.warn("No se pudo analizar la ruta como URL, asumiendo ruta local:", filePathOrUrl);
    }
    return filePathOrUrl; // Return original path if not http or /public
}

export async function readTXT(filePath: string, encoding: string = 'utf-8'): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const buffer = await fs.readFile(localPath);
        return iconv.decode(buffer, encoding);
    } catch (error: any) {
        console.error(`Error al procesar TXT (${filePath}):`, error);
        throw new Error(`Error al procesar TXT: ${error.message}`);
    }
}

export async function readDOC(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const buffer = await fs.readFile(localPath);
        const result = await mammoth.extractRawText({ buffer });
        return result.value;
    } catch (error: any) {
        console.error(`Error al procesar DOC (${filePath}):`, error);
        throw new Error(`Error al procesar documento DOC: ${error.message}`);
    }
}

export async function readRTF(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const rtfContent = await fs.readFile(localPath, 'utf-8'); // RTF is usually text

        return new Promise((resolve, reject) => {
            rtfToHtml.fromString(rtfContent, (err, html) => {
                if (err) {
                     console.error(`Error al convertir RTF a HTML (${filePath}):`, err);
                    return reject(new Error(`Error al procesar RTF: ${err.message}`));
                }
                // Extract text from the generated HTML
                const dom = new JSDOM(html);
                const text = dom.window.document.body.textContent || '';
                resolve(text);
            });
        });
    } catch (error: any) {
        console.error(`Error al procesar RTF (${filePath}):`, error);
        throw new Error(`Error al procesar RTF: ${error.message}`);
    }
}

export async function readHTML(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const htmlContent = await fs.readFile(localPath, 'utf-8');
        const dom = new JSDOM(htmlContent);
        return dom.window.document.body.textContent || '';
    } catch (error: any) {
        console.error(`Error al procesar HTML (${filePath}):`, error);
        throw new Error(`Error al procesar HTML: ${error.message}`);
    }
}

export async function readXML(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const xmlContent = await fs.readFile(localPath, 'utf-8');

        return new Promise((resolve, reject) => {
            xmlParseString(xmlContent, (err, result) => {
                if (err) {
                     console.error(`Error al procesar XML (${filePath}):`, err);
                    return reject(new Error(`Error al procesar XML: ${err.message}`));
                }
                // Stringify the parsed object to get text representation
                // You might want more sophisticated text extraction depending on XML structure
                resolve(JSON.stringify(result, null, 2));
            });
        });
    } catch (error: any) {
        console.error(`Error al procesar XML (${filePath}):`, error);
        throw new Error(`Error al procesar XML: ${error.message}`);
    }
}

export async function readCSV(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const csvContent = await fs.readFile(localPath); // Read as buffer first

        return new Promise((resolve, reject) => {
            let fullText = '';
            const parser = csvParse({
                delimiter: ',', // Adjust if needed
                from_line: 1    // Adjust if headers exist and should be skipped
            });

            parser.on('readable', () => {
                let record;
                while ((record = parser.read()) !== null) {
                    fullText += record.join(',') + '\n'; // Reconstruct lines (adjust format as needed)
                }
            });

            parser.on('end', () => {
                resolve(fullText);
            });

            parser.on('error', (err) => {
                 console.error(`Error al procesar CSV (${filePath}):`, err);
                reject(new Error(`Error al procesar CSV: ${err.message}`));
            });

            // Detect encoding or assume UTF-8
            // For simplicity, assuming UTF-8 here. Use libraries like 'chardet' for detection if needed.
            parser.write(iconv.decode(csvContent, 'utf-8'));
            parser.end();
        });
    } catch (error: any) {
        console.error(`Error al procesar CSV (${filePath}):`, error);
        throw new Error(`Error al procesar CSV: ${error.message}`);
    }
}

export async function readImage(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const { data: { text } } = await tesseract.recognize(localPath);
        return text;
    } catch (error: any) {
        console.error(`Error al procesar imagen (${filePath}):`, error);
        throw new Error(`Error al procesar imagen: ${error.message}`);
    }
}

export async function readXLSX(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const buffer = await fs.readFile(localPath);
        const workbook = xlsx.read(buffer, { type: 'buffer' });
        let fullText = '';
        workbook.SheetNames.forEach(sheetName => {
            const worksheet = workbook.Sheets[sheetName];
            fullText += xlsx.utils.sheet_to_csv(worksheet); // Convert sheet to CSV text
        });
        return fullText;
    } catch (error: any) {
        console.error(`Error al procesar XLSX (${filePath}):`, error);
        throw new Error(`Error al procesar XLSX: ${error.message}`);
    }
}

export async function readDOCX(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
         // docx-parser might need specific handling or a different library might be preferred
         // Using mammoth as it handles .docx well and was used for .doc
         // If docx-parser is strictly required, its async usage would look different.
         // Example with Mammoth:
         const buffer = await fs.readFile(localPath);
         const result = await mammoth.extractRawText({ buffer });
         return result.value;

        // // Example IF using docx-parser (assuming it has an async API or needs promisifying)
        // return new Promise((resolve, reject) => {
        //     docxParser.parseDocx(localPath, (data: string | null, err: Error | null) => {
        //         if (err) {
        //              console.error(`Error al procesar DOCX (${filePath}):`, err);
        //             return reject(new Error(`Error al procesar documento DOCX: ${err.message}`));
        //         }
        //         resolve(data || '');
        //     });
        // });

    } catch (error: any) {
        console.error(`Error al procesar DOCX (${filePath}):`, error);
        throw new Error(`Error al procesar documento DOCX: ${error.message}`);
    }
}

export async function readPDF(filePath: string): Promise<string> {
    try {
        const localPath = getLocalPath(filePath);
        const buffer = await fs.readFile(localPath);
        const data = await pdf(buffer);
        return data.text;
    } catch (error: any) {
        console.error(`Error al procesar PDF (${filePath}):`, error);
        throw new Error(`Error al procesar documento PDF: ${error.message}`);
    }
}