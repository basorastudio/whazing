import { Request, Response } from "express";
import { Op } from "sequelize"; // Importa Op para búsquedas OR

import { getIO } from "../libs/socket"; // Ruta a socket.io
import Message from "../models/Message";
import User from "../models/User";
import Queue from "../models/Queue";
import CreateLogTicketService from "../services/TicketServices/CreateLogTicketService";
import CreateTicketService from "../services/TicketServices/CreateTicketService";
import DeleteTicketService from "../services/TicketServices/DeleteTicketService";
import ListTicketsService from "../services/TicketServices/ListTicketsService";
import ShowLogTicketService from "../services/TicketServices/ShowLogTicketService";
import ShowTicketService from "../services/TicketServices/ShowTicketService";
import UpdateTicketService from "../services/TicketServices/UpdateTicketService";
import UpdateTicketServiceBot from "../services/TicketServices/UpdateTicketServiceBot"; // Servicio específico para bot
import { closeTickets as closeTicketsService } from "../services/TicketServices/closeTicketsService";
import { delTickets as delTicketsService } from "../services/TicketServices/delTicketsService";
import Whatsapp from "../models/Whatsapp";
import AppError from "../errors/AppError";
import CreateMessageSystemService from "../services/MessageServices/CreateMessageSystemService";
import Ticket from "../models/Ticket";
import ListSettingsService from "../services/SettingServices/ListSettingsService";
import UserRating from "../models/UserRating";
import Mustache from "../helpers/Mustache"; // Asumiendo ubicación correcta
import { tokenSchema as RefreshToken } from "../helpers/RefreshToken"; // Asumiendo ubicación y exportación
import CheckSettingsHelper from "../helpers/CheckSettingsHelper"; // Asumiendo ubicación correcta
import CountUserTickets from "../services/TicketServices/CountUserTicketsService"; // Ajustar nombre del servicio

// Interfaz para los parámetros de consulta de la lista de tickets
interface ListTicketsQuery {
  searchParam?: string;
  searchParamMessage?: string;
  pageNumber?: string;
  status?: string[] | string; // Puede ser un array o un string JSON
  date?: string;
  showAll?: string;
  withUnreadMessages?: string;
  queuesIds?: string[] | string; // Array o string JSON
  tagsIds?: string[] | string; // Array o string JSON
  useradmId?: string;
  whatsappIds?: string[] | string; // Array o string JSON
  isNotAssignedUser?: string;
  includeNotQueueDefined?: string;
}

// Interfaz para el cuerpo de la solicitud de creación
interface StoreTicketBody {
  contactId: number | string;
  status: "open" | "pending" | "closed";
  userId?: number | string; // Opcional si se asigna después
  channel: string;
  channelId?: number | string; // Opcional (ej. whatsappId)
}

// Interfaz para el cuerpo de la solicitud de actualización
interface UpdateTicketBody {
  status?: "open" | "pending" | "closed";
  userId?: number | string | null;
  queueId?: number | string | null;
  isTransference?: boolean; // Propiedad específica del servicio original
  isTicketNew?: boolean; // Propiedad específica del servicio original
  chatbotid?: number | string; // Para actualización por bot
  queueOptionId?: number | string; // Para actualización por bot
  // otras propiedades que se puedan actualizar
}

// Interfaz para el cuerpo de la solicitud de cierre/eliminación masiva
interface BulkActionBody {
  status?: "open" | "pending" | "closed";
  startDate?: string;
  endDate?: string;
  whatsappId?: number | string;
  isGroup?: boolean; // Ajustar tipo si es necesario
}

// Extiende la interfaz Request
interface TicketRequest extends Request {
  user?: {
    id: string | number;
    tenantId: string | number;
    profile: string;
  };
  body: StoreTicketBody | UpdateTicketBody | BulkActionBody | any; // Tipo unión o any
  query: ListTicketsQuery;
  params: {
    ticketId?: string;
  };
}

// Helper para parsear IDs de string JSON/array a array de números
const parseIds = (
  param: string | string[] | undefined
): number[] | undefined => {
  if (!param) return undefined;
  try {
    const parsed = typeof param === "string" ? JSON.parse(param) : param;
    return Array.isArray(parsed)
      ? parsed.map(Number).filter(id => !isNaN(id))
      : undefined;
  } catch (error) {
    console.error("Error parsing IDs:", param, error);
    return undefined;
  }
};

export const index = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  const { tenantId, profile, id: userId } = req.user!;
  const {
    searchParam,
    searchParamMessage,
    pageNumber = "1", // Valor por defecto
    status: statusParam,
    date,
    showAll: showAllParam,
    withUnreadMessages: withUnreadParam,
    queuesIds: queuesIdsParam,
    tagsIds: tagsIdsParam,
    useradmId,
    whatsappIds: whatsappIdsParam,
    isNotAssignedUser: isNotAssignedUserParam,
    includeNotQueueDefined: includeNotQueueDefinedParam
  } = req.query;

  // Convertir parámetros booleanos/string a sus tipos correctos
  const showAll = showAllParam === "true";
  const withUnreadMessages = withUnreadParam === "true";
  const isNotAssignedUser = isNotAssignedUserParam === "true";
  const includeNotQueueDefined = includeNotQueueDefinedParam === "true";

  let status: string[] | undefined;
  try {
    status = statusParam
      ? typeof statusParam === "string"
        ? JSON.parse(statusParam)
        : statusParam
      : undefined;
  } catch (e) {
    status = undefined; // Ignora si el JSON es inválido
  }

  const queuesIds = parseIds(queuesIdsParam);
  const tagsIds = parseIds(tagsIdsParam);
  const whatsappIds = parseIds(whatsappIdsParam);

  const params = {
    searchParam,
    searchParamMessage,
    pageNumber,
    status,
    date,
    showAll,
    userId: String(userId), // El servicio espera string
    withUnreadMessages,
    queuesIds,
    tagsIds,
    useradmId: useradmId ? String(useradmId) : undefined, // Asegura que es string si existe
    whatsappIds,
    isNotAssignedUser,
    includeNotQueueDefined,
    tenantId,
    profile
  };

  const { tickets, count, hasMore } = await ListTicketsService(params);

  return res.status(200).json({ tickets, count, hasMore });
};

export const store = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user!;
  const { contactId, status, userId, channel, channelId } =
    req.body as StoreTicketBody;

  // Buscar si ya existe un ticket abierto o pendiente para este contacto y canal
  const existingTicket = await Ticket.findOne({
    where: {
      contactId,
      tenantId,
      channel,
      whatsappId: channelId, // Asume que channelId es whatsappId
      status: {
        [Op.or]: ["open", "pending"]
      }
    }
  });

  // Obtener la configuración para saber si se debe usar cola
  const settings = await ListSettingsService(tenantId);
  const useQueuesSetting = settings?.find(s => s.key === "sendInactiveMessage"); // Asumiendo que esta setting controla el flujo
  const useQueues = useQueuesSetting?.value === "enabled"; // Ajustar lógica según la setting real

  // Validaciones de conflicto
  if (existingTicket) {
    if (existingTicket.userId && existingTicket.userId !== userId) {
      const user = await User.findOne({ where: { id: existingTicket.userId } });
      return res.status(409).json({
        // 409 Conflict
        error: true,
        message: `Já existe um ticket aberto para outro usuário: ${user?.name}` // "Ya existe un ticket abierto para otro usuario: ..."
      });
    }
    if (existingTicket.queueId && !userId && useQueues) {
      // Si está en cola y no se intenta asignar a usuario
      const queue = await Queue.findOne({
        where: { id: existingTicket.queueId }
      });
      return res.status(409).json({
        // 409 Conflict
        error: true,
        message: `Já existe um ticket aberto atribuído a fila: ${queue?.name}` // "Ya existe un ticket abierto atribuido a la fila: ..."
      });
    }
    // Si el ticket existente es del mismo usuario o no está en cola (o no se usan colas), devolverlo
    return res
      .status(200)
      .json({ message: "Ticket já existe", ticket: existingTicket }); // "Ticket ya existe"
  }

  // Crear nuevo ticket si no existe uno conflictivo
  const ticketData = {
    contactId,
    status,
    userId: userId || null, // Permite crear sin usuario asignado
    tenantId,
    channel,
    whatsappId: channelId // Asume channelId es whatsappId
  };

  const newTicket = await CreateTicketService(ticketData);

  // Emitir evento por socket si no se asignó usuario (para que aparezca en paneles generales)
  if (!userId) {
    const io = getIO();
    io.to(`${tenantId}:${newTicket.status}`) // Canal específico de tenant y status
      .to(`${tenantId}:notification`) // Canal general de notificaciones del tenant
      .emit(`${tenantId}:ticket`, {
        // Nombre del evento con prefijo de tenant
        action: "create",
        ticket: newTicket
      });
  }

  return res.status(201).json(newTicket); // 201 Created
};

export const show = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  const { ticketId } = req.params;
  const { tenantId, id: userIdRequest } = req.user!;

  if (!ticketId) {
    throw new AppError("ticketId is required", 400); // "ticketId es requerido"
  }

  const params = {
    id: Number(ticketId),
    tenantId: Number(tenantId)
  };

  const ticket = await ShowTicketService(params);

  // Marcar mensajes como leídos
  await Message.update(
    { read: true },
    { where: { ticketId: ticket.id, read: { [Op.is]: null }, fromMe: false } } // Marcar solo los no leídos del contacto
  );

  // Registrar log de visualización
  await CreateLogTicketService({
    userId: parseInt(String(userIdRequest), 10), // Asegurar número base 10
    ticketId: Number(ticketId),
    type: "access" // Tipo de log
  });

  return res.status(200).json(ticket);
};

export const update = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  const { ticketId } = req.params;
  const { tenantId, id: userIdRequest } = req.user!;
  const { isTransference, isTicketNew, ...ticketData } =
    req.body as UpdateTicketBody; // Separa props especiales

  if (!ticketId) {
    throw new AppError("ticketId is required", 400); // "ticketId es requerido"
  }

  const updateParams = {
    ticketData: { ...ticketData, tenantId }, // Asegura que tenantId está en los datos
    ticketId: parseInt(ticketId, 10),
    isTransference: isTransference || false,
    isTicketNew: isTicketNew || false,
    userIdRequest: parseInt(String(userIdRequest), 10)
  };

  const { ticket } = await UpdateTicketService(updateParams);

  // Lógica de envío de mensaje de evaluación si el ticket se cierra y no es de grupo
  if (!ticket.isGroup && ticketData.status === "closed") {
    const whatsappConnection = await Whatsapp.findOne({
      where: { id: ticket.whatsappId, tenantId },
      attributes: ["id", "ratingMessage", "status"] // Solo los atributos necesarios
    });

    if (
      whatsappConnection?.ratingMessage &&
      whatsappConnection.status === "CONNECTED" &&
      !ticket.chatbotid
    ) {
      // Verifica si la conexión está activa y no es un bot
      const ratingMessage = await Mustache(
        whatsappConnection.ratingMessage,
        ticket.contact,
        ticket
      ); // Renderiza el mensaje

      let finalMessage =
        ratingMessage ||
        "*1* - 😞 _Muy Insatisfecho_\n" + // *1* - 😞 _Muito Insatisfeito_
          "*2* - 🙁 _Insatisfecho_\n" + // *2* - 🙁 _Insatisfeito_
          "*3* - 🙂 _Satisfecho_\n" + // *3* - 🙂 _Satisfeito_
          "*4* - 😊 _Muy Satisfecho_\n" + // *4* - 😊 _Muito Satisfeito_
          "*5* - 🤩 _Extremadamente Satisfecho_\n\n" + // *5* - 🤩 _Extremamente Satisfeito_\n\n
          "Digite de 1 a 5 para calificar nuestro atendimiento:\n"; // "Digite de 1 a 5 para qualificar nosso atendimento:\n"

      // Lógica de verificación de token (muy específica y probablemente necesite revisión)
      const tokenDR = "eb75100f441d67cabf5790a6acde49869b0feb33";
      const tokenDRencoded = RefreshToken(tokenDR);
      const tokenDN = "d1a25cdd43757f798d95c1a9b5ead6c77d08e4b8";
      const tokenDNencoded = RefreshToken(tokenDN);
      const settingType = await CheckSettingsHelper(tokenDNencoded);

      if (settingType === tokenDRencoded) {
        const customToken = "78faaa942550372a5ac8ebc1de57e585f153913d";
        finalMessage = RefreshToken(customToken); // Codifica el mensaje si los tokens coinciden
      }

      // Crear registro de evaluación pendiente
      await UserRating.findOrCreate({
        where: {
          ticketId: ticket.id,
          userId: ticket.userId,
          contactId: ticket.contactId,
          whatsappId: ticket.whatsappId
        },
        defaults: {
          ticketId: ticket.id,
          userId: ticket.userId,
          contactId: ticket.contactId,
          whatsappId: ticket.whatsappId,
          tenantId: ticket.tenantId,
          rate: null
        }
      });

      // Crear y enviar el mensaje de sistema para la evaluación
      const messageData = {
        body: finalMessage,
        fromMe: true,
        read: true,
        sendType: "bot", // Indica que es un mensaje del sistema/bot
        tenantId: ticket.tenantId
      };
      await CreateMessageSystemService({
        msg: messageData,
        tenantId: ticket.tenantId,
        ticket: ticket,
        sendType: messageData.sendType,
        status: "pending" // El mensaje se enviará cuando la conexión esté lista
      });
    }
  }

  return res.status(200).json(ticket);
};

export const remove = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  const { ticketId } = req.params;
  const { tenantId, id: userId } = req.user!;

  if (!ticketId) {
    throw new AppError("ticketId is required", 400); // "ticketId es requerido"
  }

  const params = {
    id: ticketId,
    tenantId: Number(tenantId),
    userId: String(userId) // El servicio parece esperar userId como string
  };

  await DeleteTicketService(params);

  return res.status(200).json({ message: "ticket deleted" }); // "ticket eliminado"
};

export const showLogsTicket = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  const { ticketId } = req.params;

  if (!ticketId) {
    throw new AppError("ticketId is required", 400); // "ticketId es requerido"
  }

  const params = { ticketId: Number(ticketId) };
  const logs = await ShowLogTicketService(params);

  return res.status(200).json(logs);
};

export const closeTickets = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  try {
    const { id: userId, tenantId } = req.user!;
    const { status, startDate, endDate, whatsappId, isGroup } =
      req.body as BulkActionBody;

    // Validación básica de parámetros requeridos
    if (
      (!status && !startDate) ||
      !endDate ||
      !whatsappId ||
      isGroup === undefined
    ) {
      const missingParams = { status, startDate, endDate, whatsappId, isGroup };
      console.warn(
        "Faltan parámetros para cerrar/actualizar tickets:",
        missingParams
      ); // "Faltando parâmetros para fechar/atualizar tickets:"
      return res
        .status(400)
        .json({ message: "Faltan filtros para la solicitud" }); // "Filtros faltando para solicitação"
    }

    const params = {
      status,
      startDate,
      endDate,
      whatsappId: Number(whatsappId),
      isGroup,
      userId: Number(userId),
      tenantId: Number(tenantId)
    };

    await closeTicketsService(params);

    return res.status(200).json({ message: "Tickets closed successfully" }); // "Tickets cerrados exitosamente"
  } catch (error: any) {
    return res
      .status(500)
      .json({ message: error.message || "Internal server error" }); // "Error interno del servidor"
  }
};

export const delTickets = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  try {
    const { status, startDate, endDate, whatsappId, isGroup } =
      req.body as BulkActionBody;

    // Validación básica de parámetros requeridos
    if (
      (!status && !startDate) ||
      !endDate ||
      !whatsappId ||
      isGroup === undefined
    ) {
      const missingParams = { status, startDate, endDate, whatsappId, isGroup };
      console.warn("Faltan parámetros para eliminar tickets:", missingParams); // "Faltando parâmetros para deletar tickets:"
      return res
        .status(400)
        .json({ message: "Faltan filtros para la solicitud" }); // "Filtros faltando para solicitação"
    }

    const params = {
      status,
      startDate,
      endDate,
      whatsappId: Number(whatsappId),
      isGroup
    };

    await delTicketsService(params);

    return res.status(200).json({ message: "Tickets deleted successfully" }); // "Tickets eliminados exitosamente"
  } catch (error: any) {
    return res
      .status(500)
      .json({ message: error.message || "Internal server error" }); // "Error interno del servidor"
  }
};

// Controlador específico para actualizaciones iniciadas por el bot
export const updateBot = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  // Validación de token (lógica muy específica, mantenerla como está pero comentada)
  const tokenBot = "d1a25cdd43757f798d95c1a9b5ead6c77d08e4b8";
  const tokenBotEncoded = RefreshToken(tokenBot); // Codifica el token esperado
  const tokenAuth = "eb75100f441d67cabf5790a6acde49869b0feb33";
  const tokenAuthEncoded = RefreshToken(tokenAuth); // Codifica el token de autenticación
  const settingType = await CheckSettingsHelper(tokenAuthEncoded); // Obtiene la configuración (¿relacionada con el token?)

  if (settingType !== tokenBotEncoded) {
    // Compara configuración con token esperado
    throw new AppError("ERR_NO_PERMISSION", 403); // "ERR_SIN_PERMISO"
  }

  const { ticketId } = req.params;
  const { tenantId } = req.user!; // Asume que un usuario (quizás de sistema) está asociado a la req del bot
  const { chatbotid } = req.body as UpdateTicketBody; // Obtiene el ID del chatbot

  if (!ticketId || !chatbotid) {
    throw new AppError("ticketId and chatbotid are required", 400); // "ticketId y chatbotid son requeridos"
  }

  const params = {
    ticketId: Number(ticketId),
    tenantId: Number(tenantId),
    chatbotid: Number(chatbotid) // Asegura que es número
  };

  await UpdateTicketServiceBot(params);

  return res.status(200).json({ message: "Tickets updated successfully" }); // "Tickets actualizados exitosamente"
};

export const countUserTickets = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  try {
    const { tenantId, id: userId } = req.user!;
    const count = await CountUserTickets(Number(userId), Number(tenantId));
    return res.status(200).json(count);
  } catch (error: any) {
    console.error("Error contando tickets de usuario:", error); // "Erro ao contar tickets do usuário:"
    return res.status(500).json({
      error: true,
      message: "Internal server error",
      details: error.message
    }); // "Error interno del servidor"
  }
};

// Controlador para crear un nuevo ticket (parece redundante con 'store', pero sigue la lógica original)
export const newticket = async (
  req: TicketRequest,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId } = req.user!;
  const { contactId, status, channelId, queueId } = req.body; // Ajusta según los campos reales necesarios

  // Busca la conexión Whatsapp asociada al channelId
  const whatsappConnection = await Whatsapp.findOne({
    where: { id: channelId, tenantId }
  });

  if (!whatsappConnection) {
    return res
      .status(404)
      .json({ error: true, message: "Canal de comunicación no encontrado" }); // "Canal de comunicação não encontrado"
  }

  const channelType = whatsappConnection.channel; // Obtiene el tipo de canal (e.g., 'whatsapp')

  // Busca si ya existe un ticket abierto o pendiente
  const existingTicket = await Ticket.findOne({
    where: {
      contactId,
      tenantId,
      channel: channelType,
      whatsappId: channelId,
      status: { [Op.or]: ["open", "pending"] }
    }
  });

  // Validaciones de conflicto (similar a 'store')
  if (existingTicket) {
    if (existingTicket.userId && existingTicket.userId !== userId) {
      const user = await User.findOne({ where: { id: existingTicket.userId } });
      return res.status(409).json({
        error: true,
        message: `Já existe um ticket aberto para outro usuário: ${user?.name}` // "Ya existe un ticket abierto para otro usuario: ..."
      });
    }
    if (existingTicket.queueId && !userId) {
      // Si está en cola y no se intenta asignar usuario
      const queue = await Queue.findOne({
        where: { id: existingTicket.queueId }
      });
      return res.status(409).json({
        error: true,
        message: `Já existe um ticket aberto atribuído a fila: ${queue?.name}` // "Ya existe un ticket abierto atribuido a la fila: ..."
      });
    }
    // Si no hay conflicto, devuelve el existente
    return res
      .status(200)
      .json({ message: "Ticket já existe", ticket: existingTicket }); // "Ticket ya existe"
  }

  // Crear el nuevo ticket
  const ticketData = {
    contactId,
    status,
    userId: userId, // Asigna el usuario que crea
    tenantId,
    channel: channelType,
    whatsappId: channelId,
    queueId: queueId || null // Asigna cola si se proporciona
  };

  const newTicket = await CreateTicketService(ticketData);

  // Emitir evento por socket
  const io = getIO();
  io.to(`${tenantId}:${newTicket.status}`)
    .to(`${tenantId}:notification`)
    .emit(`${tenantId}:ticket`, {
      action: "create", // Acción de creación
      ticket: newTicket
    });

  return res.status(201).json(newTicket);
};
