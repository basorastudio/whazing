import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull
} from "sequelize-typescript";
import { v4 as uuidv4 } from "uuid";
import Contact from "./Contact";
import Tenant from "./Tenant";
import Ticket from "./Ticket";
import User from "./User";
import Queue from "./Queue"; // Added missing import
import Whatsapp from "./Whatsapp"; // Added missing import

@Table
class Message extends Model<Message> {

    // Getters preserved
    get mediaName(): string | null {
        return this.getDataValue("mediaName");
    }

    get mediaUrl(): string | null {
        const filename = this.getDataValue("mediaUrl");
        if (filename) {
            const { BACKEND_URL, PROXY_PORT } = process.env;
            return `${BACKEND_URL}:${PROXY_PORT}/public/${filename}`;
        }
        return null;
    }

  @PrimaryKey
  @Default(uuidv4)
  @Column
  id: string; // Assuming string UUID based on default

  @Default(null) // Original default was 0, but BIGINT suggests null might be better if optional
  @AllowNull(true)
  @Column(DataType.BIGINT) // Using BIGINT as specified
  timestamp: number | null;

  @Column
  ack: number; // Assuming number for ack status

  @Default(null) // Assuming default for body
  @AllowNull(true)
  @Column(DataType.TEXT) // Use TEXT for message body
  body: string | null;

  @Column(DataType.VIRTUAL) // Define as VIRTUAL, calculated by getter
  mediaName: string | null;

  @Column(DataType.VIRTUAL) // Define as VIRTUAL, calculated by getter
  mediaUrl: string | null;

  @Column
  mediaType: string; // Store the actual filename/path here

  @Default(false)
  @Column
  isDeleted: boolean;

  @Default(false)
  @Column
  read: boolean;

  @Column(DataType.TEXT) // Assuming TEXT for potentially long ID
  idFront: string;

  @Column(DataType.JSON) // Assuming JSON for reactions
  reactions: any; // Use a specific type/interface if possible

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @ForeignKey(() => Message) // Self-referencing FK for quoted message
  @Column
  quotedMsgId: string | null; // Assuming string UUID

  @BelongsTo(() => Message, "quotedMsgId")
  quotedMsg: Message | null;

  @ForeignKey(() => Ticket)
  @Column
  ticketId: number;

  @BelongsTo(() => Ticket)
  ticket: Ticket;

  @ForeignKey(() => Contact)
  @Column
  contactId: number;

  @BelongsTo(() => Contact, "contactId") // Specify FK if needed
  contact: Contact;

  @ForeignKey(() => User)
  @AllowNull(true)
  @Default(null)
  @Column
  userId: number | null;

  @BelongsTo(() => User)
  user: User | null;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE(6))
  scheduleDate: Date | null; // 'scheduleDate' resolved

  @AllowNull(true)
  @Default(null)
  @Column(DataType.ENUM(
      "campaign",
      "chat", // Assuming default 'chat'
      "bot",  // Added based on column name
      "sync", // Added based on column name
      "api",  // Added based on column name
      "openai",// Added based on column name
      "groq", // Added based on column name
      "typebot"// Added based on column name
  ))
  sendType: string | null;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @AllowNull(true)
  @Default(null)
  @Column
  idAPI: string; // Assuming 'API' mapped to this

  @ForeignKey(() => Queue) // Added based on likely schema
  @AllowNull(true)
  @Default(null)
  @Column
  IdQueue: number | null; // Assuming this FK exists

  // Missing relation for IdQueue, add if needed:
  // @BelongsTo(() => Queue, 'IdQueue')
  // queue: Queue | null;

  @Default(false)
  @Column
  isForwarded: boolean; // 'isForwarded' resolved

  @ForeignKey(() => Whatsapp) // Added based on likely schema
  @AllowNull(true)
  @Default(null)
  @Column
  whatsappId: number | null;

  @BelongsTo(() => Whatsapp) // Added based on likely schema
  whatsapp: Whatsapp | null;
}

export default Message;