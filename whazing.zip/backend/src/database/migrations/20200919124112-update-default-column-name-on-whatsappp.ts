import { QueryInterface } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface) => {
    // Renombra la columna 'default' a 'isDefault' en la tabla Whatsapps
    return queryInterface.renameColumn('Whatsapps', 'default', 'isDefault');
  },

  down: (queryInterface: QueryInterface) => {
    // Revierte el cambio, renombrando 'isDefault' de nuevo a 'default'
    return queryInterface.renameColumn('Whatsapps', 'isDefault', 'default');
  }
};