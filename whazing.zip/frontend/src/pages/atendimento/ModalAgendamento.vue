<template>
  <q-dialog
    persistent
    :value="modalAgendamento"
    @hide="fecharModal"
    @show="abrirModal"
  >
    <q-card class="q-pa-md modal-container container-rounded-10" style="max-width: 600px;">
      <q-overlay v-if="loading" class="bg-primary">
        <q-spinner color="white" size="50px" />
      </q-overlay>

      <q-card-section class="row items-center justify-between q-my-sm q-px-none">
        <div class="text-h6 text-center font-family-main col">
          Crear Nueva Programación
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="q-pa-sm container-border container-rounded-10">
        <div class="text-h6 font-family-main q-mb-sm">
          Mensaje
        </div>
        <div class="row items-center">
          <div class="col-xs-3 col-sm-2 col-md-1">
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-emoticon-happy-outline" />
              <q-tooltip>Emoji</q-tooltip>
              <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                <VEmojiPicker
                  style="width: 40vw"
                  :showSearch="true"
                  :emojisByRow="20"
                  labelSearch="Buscar..."
                  lang="es"
                  @select="onInsertSelectEmoji"
                />
              </q-menu>
            </q-btn>
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-variable" />
              <q-tooltip>Variables</q-tooltip>
              <q-menu touch-position>
                <q-list dense style="min-width: 100px">
                  <q-item
                    v-for="variavel in variaveis"
                    :key="variavel.label"
                    clickable
                    @click="onInsertSelectVariable(variavel.value)"
                    v-close-popup
                  >
                    <q-item-section>{{ variavel.label }}</q-item-section>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>
          </div>
          <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm q-mt-sm">
            <textarea
              ref="inputEnvioMensagem"
              :disabled="audiogravado"
              style="min-height: 15vh; max-height: 15vh;"
              class="q-pa-sm bg-white full-width"
              placeholder="Escriba el mensaje"
              :value="agendamento.mensagem"
              @input="(v) => agendamento.mensagem = v.target.value"
            />
          </div>
        </div>

        <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm q-mt-md row items-center">
          <!-- Botón de micrófono -->
          <q-btn
            round
            flat
            :color="isRecordingAudio ? 'negative' : 'primary'"
            @click="handleAudioRecording"
            class="color-light1 q-ml-sm"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
          >
            <q-icon
              :name="isRecordingAudio ? 'stop' : 'mic'"
              size="2em"
            />
            <q-tooltip>
              {{ isRecordingAudio ? 'Parar Grabación' : 'Grabar Audio' }}
            </q-tooltip>
          </q-btn>
          <!-- Botón de carga de archivo - oculto durante la grabación -->
          <q-file
            v-if="!isRecordingAudio"
            dense
            outlined
            v-model="agendamento.anexo"
            label="Elija el archivo"
            filled
            class="col"
          />

          <!-- Temporizador de grabación -->
          <RecordingTimer
            v-if="isRecordingAudio"
            class="q-ml-sm"
          />
        </div>

        <div class="text-h6 font-family-main q-mb-sm q-mt-sm">
          Fecha para Enviar
        </div>
        <div class="row q-col-gutter-sm">
          <div class="col-xs-12 col-md-6">
            <q-select :options="schedule.options" v-model="schedule.selected" map-options outlined @input="onSelectSchedule" />
          </div>
          <div class="col-xs-12 col-md-6">
            <q-datetime-picker
              outlined
              stack-label
              label="Fecha/Hora Programación"
              mode="datetime"
              v-model="agendamento.dataParaEnviar"
              format24h
              :readonly="schedule.selected.value !== 'custom'"
            />
          </div>
          <div class="full-width q-mt-sm">
            <q-checkbox v-model="agendamento.repetir" label="Repetir programación" />
            <q-select
              v-if="agendamento.repetir"
              :options="periodo.options"
              v-model="agendamento.periodo"
              map-options
              outlined
            />
            <q-input
              v-if="agendamento.repetir"
              outlined
              label="Número de repeticiones"
              type="number"
              v-model="agendamento.repeticao"
            />
          </div>
        </div>
      </q-card-section>

      <q-card-actions align="right" class="q-mt-sm">
        <q-btn label="Cancelar" color="negative" v-close-popup class="q-mr-sm btn-rounded-50" />
        <q-btn
          :loading="loading"
          :disable="loading"
          label="Guardar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          @click="handleAgendamento"
          icon="eva-save-outline"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { CriarAgendamento } from 'src/service/agendamentos'
import { add, format } from 'date-fns'
import { VEmojiPicker } from 'v-emoji-picker'

import RecordingTimer from './RecordingTimer'
import MicRecorder from 'mic-recorder-to-mp3'

const Mp3Recorder = new MicRecorder({
  bitRate: 128,
  encodeAfterRecord: true
})

export default {
  name: 'ModalAgendamento',
  components: { VEmojiPicker, RecordingTimer },
  props: {
    modalAgendamento: {
      type: Boolean,
      default: false
    },
    ticketFocado: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      isRecordingAudio: false,
      audioBlob: null,
      audiogravado: false,
      contatos: [],
      variaveis: [
        { label: 'Nombre Completo', value: '{{name}}' },
        { label: 'Nombre', value: '{{firstName}}' },
        { label: 'Saludo', value: '{{greeting}}' },
        { label: 'Teléfono', value: '{{phoneNumber}}' },
        { label: 'Email del Contacto', value: '{{email}}' },
        { label: 'Hora', value: '{{hour}}' },
        { label: 'Fecha', value: '{{date}}' }
      ],
      periodo: {
        selected: { label: 'Período', value: '' },
        options: [
          { label: 'Mensual', value: 'mensal' },
          { label: 'Semanal', value: 'semanal' },
          { label: 'Quincenal', value: 'quinzena' },
          { label: 'Bimestral', value: 'bimestral' }
        ]
      },
      schedule: {
        selected: { label: 'Personalizado', value: 'custom', func: null },
        options: [
          { label: 'Personalizado', value: 'custom', func: null },
          { label: 'En 30 minutos', value: '30_mins', func: () => add(new Date(), { minutes: 30 }) },
          { label: 'Mañana', value: 'amanha', func: () => add(new Date(), { days: 1 }) },
          { label: 'Próxima semana', value: 'prox_semana', func: () => add(new Date(), { weeks: 1 }) }
        ]
      },
      agendamento: {
        contato: '',
        whatsapp: '',
        mensagem: '',
        anexo: null,
        dataParaEnviar: '',
        repetir: false,
        repeticao: 1,
        periodo: null
      },
      loading: false
    }
  },
  methods: {
    async handleAudioRecording () {
      if (!this.isRecordingAudio) {
        try {
          await navigator.mediaDevices.getUserMedia({ audio: true })
          await Mp3Recorder.start()
          this.isRecordingAudio = true
        } catch (error) {
          this.$q.notify({
            type: 'negative',
            message: 'Error al iniciar la grabación de audio'
          })
          this.isRecordingAudio = false
        }
      } else {
        try {
          const [, blob] = await Mp3Recorder.stop().getMp3()
          this.isRecordingAudio = false

          if (blob.size < 10000) {
            this.$q.notify({
              type: 'warning',
              message: 'Audio muy corto'
            })
            return
          }

          // Crear objeto de archivo para adjuntar
          const audioFile = new File([blob], `audio_${Date.now()}.mp3`, {
            type: 'audio/mp3'
          })

          // Establecer el archivo de audio en agendamento.anexo
          this.agendamento.anexo = audioFile

          this.audiogravado = true

          this.$q.notify({
            type: 'positive',
            message: '¡Audio grabado con éxito!'
          })
        } catch (error) {
          this.$q.notify({
            type: 'negative',
            message: 'Error al finalizar la grabación de audio'
          })
        }
      }
    },
    async cancelRecording () {
      if (this.isRecordingAudio) {
        try {
          await Mp3Recorder.stop().getMp3()
          this.isRecordingAudio = false
        } catch (error) {
          console.error('Error al cancelar grabación:', error)
        }
      }
    },
    onInsertSelectVariable (variable) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      // obtener la posición del cursor:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filtro:
      if (!variable) {
        return
      }
      // insertar:
      self.txtContent = this.agendamento.mensagem
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.agendamento.mensagem = self.txtContent
      // mover cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      if (!emoji.data) {
        return
      }
      self.txtContent = this.agendamento.mensagem
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.agendamento.mensagem = self.txtContent
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    onSelectSchedule(newValue) {
      if (newValue.func) {
        // Obtener la fecha con la función proporcionada
        const date = newValue.func();
        // Formatear la fecha considerando la zona horaria local
        this.agendamento.dataParaEnviar = format(date, 'yyyy-MM-dd HH:mm');
      } else {
        this.agendamento.dataParaEnviar = null;
      }
    },
    fecharModal() {
      this.$emit('update:modalAgendamento', false)
    },
    abrirModal() {
      this.audiogravado = false
      this.agendamento = {
        contato: '',
        whatsapp: '',
        mensagem: '',
        anexo: null,
        dataParaEnviar: '',
        repetir: false,
        repeticao: 1,
        periodo: null
      }
    },
    async handleAgendamento() {
      const { mensagem, dataParaEnviar, periodo, repetir, repeticao, anexo } = this.agendamento

      if (!anexo && !mensagem) {
        this.$q.notify({ type: 'negative', message: 'Es necesario informar un mensaje cuando no hay adjunto.' })
        return
      }

      // Utilizar this.ticketFocado directamente
      const contatoId = this.ticketFocado.contactId
      const whatsapp = this.ticketFocado.whatsappId
      const periodoValue = periodo ? periodo.value : null

      if (!dataParaEnviar) {
        this.$q.notify({ type: 'negative', message: 'Complete todos los campos obligatorios.' })
        return
      }

      if (repetir && (isNaN(repeticao) || repeticao > 12)) {
        this.$q.notify({ type: 'negative', message: 'El campo repetición debe ser un número menor o igual a 12.' })
        return
      }

      this.loading = true
      try {
        const formData = new FormData()
        formData.append('repetir', repetir)
        formData.append('repeticao', repeticao)
        formData.append('contatoId', contatoId)
        formData.append('whatsapp', whatsapp)
        formData.append('mensagem', mensagem)
        
        // Ajustar a UTC considerando el offset local
        const dateToSend = new Date(dataParaEnviar);
        const utcDate = new Date(dateToSend.getTime() - (dateToSend.getTimezoneOffset() * 60000));
        formData.append('dataParaEnviar', utcDate.toISOString())
        
        formData.append('medias', anexo)

        if (periodoValue) formData.append('periodo', periodoValue)

        // Envía los datos de la programación al backend
        await CriarAgendamento(formData)
        this.$q.notify({ type: 'positive', message: '¡Programación creada con éxito!' })
        this.fecharModal()
      } catch (error) {
        console.error(error)
        this.$q.notify({ type: 'negative', message: 'Error al crear programación.' })
      } finally {
        this.loading = false
      }
    }
  },
  beforeDestroy () {
    this.cancelRecording()
  }
}
</script>
