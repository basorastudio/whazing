import { default as Redis } from 'ioredis';
import { promisify } from 'util'; // Import promisify if needed for older Node versions or specific methods

// Define Redis client options based on environment variables
const redisOptions = {
    port: Number(process.env.IO_REDIS_PORT),
    host: process.env.IO_REDIS_SERVER,
    db: Number(process.env.IO_REDIS_DB_SESSION) || 3, // Default DB 3 for sessions?
    password: process.env.IO_REDIS_PASSWORD || undefined
};

// Create the Redis client instance
const redisClient = new Redis(redisOptions);

redisClient.on('connect', () => {
  console.log('Redis client connected successfully.');
});

redisClient.on('error', (err) => {
  console.error('Redis client connection error:', err);
});


/**
 * Gets a value from Redis by key.
 * @param key - The key to retrieve.
 * @returns Promise resolving with the value (parsed if JSON) or null.
 */
export const getValue = (key: string): Promise<any | null> => {
    return new Promise((resolve, reject) => {
        redisClient.get(key, (err, result) => {
            if (err) {
                console.error(`Redis GET error for key ${key}:`, err);
                return reject(err);
            }
            let data: any = null;
            if (result) {
                try {
                    // Attempt to parse if it looks like JSON
                    if (result.startsWith('{') || result.startsWith('[')) {
                         data = JSON.parse(result);
                    } else {
                         data = result; // Return as string if not JSON-like
                    }
                } catch (parseError) {
                    console.warn(`Failed to parse Redis value for key ${key} as JSON, returning raw string:`, parseError);
                    data = result; // Fallback to raw string if parsing fails
                }
            }
            resolve(data);
        });
    });
};

/**
 * Sets a value in Redis.
 * @param key - The key to set.
 * @param value - The value to store (will be stringified if object/array).
 * @returns Promise resolving with the result of the Redis SET command (usually 'OK').
 */
export const setValue = (key: string, value: any): Promise<string | null> => {
    return new Promise((resolve, reject) => {
        let valueToStore: string;
        if (typeof value === 'object' && value !== null) {
            try {
                 valueToStore = JSON.stringify(value);
            } catch (stringifyError) {
                 console.error(`Failed to stringify value for key ${key}:`, stringifyError);
                 return reject(stringifyError);
            }
        } else {
            valueToStore = String(value); // Convert non-objects/arrays to string
        }

        redisClient.set(key, valueToStore, (err, reply) => {
            if (err) {
                console.error(`Redis SET error for key ${key}:`, err);
                return reject(err);
            }
            resolve(reply); // 'OK' or null
        });
    });
};

/**
 * Deletes one or more keys from Redis.
 * @param keys - A single key or an array of keys to delete.
 * @returns Promise resolving with the number of keys deleted.
 */
export const removeValue = (keys: string | string[]): Promise<number> => {
    return new Promise((resolve, reject) => {
        redisClient.del(keys, (err, reply) => {
            if (err) {
                console.error(`Redis DEL error for keys ${JSON.stringify(keys)}:`, err);
                return reject(err);
            }
            resolve(reply); // Number of keys deleted
        });
    });
};

// Export the client instance directly if needed elsewhere, or just the functions
// export default redisClient;