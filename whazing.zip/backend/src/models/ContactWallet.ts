import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  AutoIncrement
} from "sequelize-typescript";
import Contact from "./Contact";
import Tenant from "./Tenant";
import User from "./User"; // Assuming 'Wallet' refers to a User

@Table
class ContactWallet extends Model<ContactWallet> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @ForeignKey(() => Contact)
  @Column
  contactId: number;

  @BelongsTo(() => Contact)
  contact: Contact;

  @ForeignKey(() => User) // Assuming Wallet refers to User ID
  @Column
  walletId: number; // FK name

  @BelongsTo(() => User) // Assuming Wallet refers to User model
  wallet: User; // Relation name

  @ForeignKey(() => Tenant) // Added based on likely schema design
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant) // Added based on likely schema design
  tenant: Tenant;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default ContactWallet;