// --- START OF FILE SessionController.ts ---

import type { Request, Response } from "express";

import AppError from "../errors/AppError"; // Assuming path
import AuthUserService from "../services/UserServices/AuthUserService"; // Corrected service name assumption
import { SendRefreshToken } from "../helpers/SendRefreshToken"; // Assuming path
import { RefreshTokenService } from "../services/AuthServices/RefreshTokenService"; // Assuming path
import { getIO } from "../libs/socket"; // Assuming path
import User from "../models/User"; // Assuming path

interface StoreResponseBody {
  token: string;
  username: string;
  email: string;
  profile: string;
  status: string; // Assuming status is a property
  userId: number; // Assuming user id is returned
  tenantId: number; // Assuming tenantId is returned
  configs: any; // Define more specifically if possible
  usuariosOnline: number; // Assuming this count is returned
  queues: any[]; // Define Queue type if possible
}

interface UpdateResponseBody {
  token: string; // The new token
  user: any; // Define User type if possible
}

interface LogoutParams {
  userId?: string;
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const io = getIO();
  const { email, password } = req.body;
  const lowerCaseEmail = email.toLowerCase();

  const {
    token,
    user,
    refreshToken,
    usuariosOnline // Assuming this is returned by the service
  } = await AuthUserService({ email: lowerCaseEmail, password });

  SendRefreshToken(res, refreshToken);

  const responseData: StoreResponseBody = {
    token: token,
    username: user.username,
    email: user.email,
    profile: user.profile,
    status: user.status,
    userId: user.id,
    tenantId: user.tenantId,
    configs: user.configs, // Assuming configs is part of user
    usuariosOnline: usuariosOnline,
    queues: user.queues // Assuming queues is part of user
  };

  // Emit socket event for user login
  io.emit(`${responseData.tenantId}:users`, {
    // Use template literal
    action: "update", // Action type
    data: {
      // Payload
      username: responseData.username,
      email: responseData.email,
      isOnline: true,
      lastLogin: new Date() // Assuming you want to update last login time
    }
  });

  return res.status(200).json(responseData);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  // Get refresh token from cookies
  const token = req.cookies.refreshToken; // Adjust cookie name if different

  if (!token) {
    throw new AppError("ERR_SESSION_EXPIRED", 401); // Keep error code
  }

  const {
    user,
    newToken, // Renamed for clarity, assuming service returns this
    refreshToken: newRefreshToken // Renamed for clarity
  } = await RefreshTokenService(res, token); // Pass res for potential cookie setting in service

  // Send the new refresh token back to the client
  SendRefreshToken(res, newRefreshToken);

  const responseData: UpdateResponseBody = {
    token: newToken,
    user: user // Send back updated user info if needed
  };

  return res.json(responseData); // Status defaults to 200 if not set
};

export const logout = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { userId } = req.body as LogoutParams; // Assuming userId might be in body for admin logout? Or use req.user.id if available

  // Usually, logout invalidates the token on the client-side.
  // Server-side might involve blacklist tokens or just clear cookies.
  // We'll clear the refresh token cookie and update user status.

  if (!userId) {
    // If userId is needed and not provided (e.g., admin logging out another user)
    // Or, more commonly, use the logged-in user's ID if available from auth middleware
    // const userId = req.user?.id; // Example if auth middleware adds user to req
    // If still no userId, throw error:
    throw new AppError("ERR_USER_NOT_FOUND", 404); // Keep error code
  }

  const io = getIO();
  const user = await User.findByPk(userId);

  if (user) {
    await user.update({
      isOnline: false,
      lastLogout: new Date()
    });

    // Emit socket event for user logout
    io.emit(`${user.tenantId}:users`, {
      // Use template literal and user's tenantId
      action: "update", // Action type
      data: {
        // Payload
        username: user.username,
        email: user.email,
        isOnline: false,
        lastLogout: new Date()
      }
    });
  }

  // Clear the refresh token cookie
  res.clearCookie("refreshToken"); // Adjust cookie name if different

  return res.json({ message: "USER_LOGOUT" }); // Keep message code
};

// --- END OF FILE SessionController.ts ---
