import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna whatsappId a la tabla Tickets
    return queryInterface.addColumn('Tickets', 'whatsappId', { // Nombre de columna preservado
      type: DataTypes.INTEGER,
      references: {
        model: 'Whatsapps', // Referencia a la tabla Whatsapps
        key: 'id'
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL', // Permite que el ticket exista si se elimina el Whatsapp
      allowNull: true // Permite nulo si un ticket no está asociado a un Whatsapp específico
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna whatsappId
    return queryInterface.removeColumn('Tickets', 'whatsappId');
  }
};