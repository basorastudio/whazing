// --- START OF FILE 20231018110255-add_column_tenantId_to_group.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Groups";
    const tenantIdColumn = "tenantId";
    const isActiveColumn = "isActive";

    const tableDescription = await queryInterface.describeTable(tableName); // describeTa' + 'ble'

    if (!tableDescription || !tableDescription[tenantIdColumn]) {
      await queryInterface.addColumn(tableName, tenantIdColumn, {
        type: DataTypes.INTEGER,
        references: {
          model: "Tenants", // Original 'Tenants'
          key: "id"
        },
        onUpdate: "CASCADE", // Original 'CASCADE'
        onDelete: "restrict", // Original 'restrict'
        allowNull: false, // Changed ![] to false
        defaultValue: 1 // Original default value 0x1 -> 1
      });
    } else {
      console.log(
        `La columna ${tenantIdColumn} ya existe en la tabla ${tableName}. Saltando adición.`
      );
    }

    if (!tableDescription || !tableDescription[isActiveColumn]) {
      await queryInterface.addColumn(tableName, isActiveColumn, {
        type: DataTypes.BOOLEAN,
        allowNull: false, // Changed ![] to false
        defaultValue: true // Changed !![] to true
      });
    } else {
      console.log(
        `La columna ${isActiveColumn} ya existe en la tabla ${tableName}. Saltando adición.`
      );
    }
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Groups";
    const tenantIdColumn = "tenantId";
    const isActiveColumn = "isActive";

    const tableDescription = await queryInterface.describeTable(tableName);

    if (tableDescription && tableDescription[tenantIdColumn]) {
      await queryInterface.removeColumn(tableName, tenantIdColumn);
    } else {
      console.log(
        `La columna ${tenantIdColumn} no existe en la tabla ${tableName}. Saltando eliminación.`
      );
    }

    if (tableDescription && tableDescription[isActiveColumn]) {
      await queryInterface.removeColumn(tableName, isActiveColumn);
    } else {
      console.log(
        `La columna ${isActiveColumn} no existe en la tabla ${tableName}. Saltando eliminación.`
      );
    }
  }
};

export default migration;
// --- END OF FILE 20231018110255-add_column_tenantId_to_group.ts ---
