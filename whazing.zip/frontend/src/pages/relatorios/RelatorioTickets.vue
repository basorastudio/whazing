<template>
  <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-card bordered>
      <q-card-section>
        <div class="text-h6 q-px-sm">Relatório Tickets</div>
      </q-card-section>
      <q-card-section class="q-pt-none">
        <fieldset class="rounded-all">
          <legend class="q-px-sm">Filtros</legend>
          <div class="row q-gutter-md items-center">
            <!-- Primeira linha com múltiplos filtros -->
            <div class="col-xs-12 col-md-3">
              <q-input label="Buscar Contato" v-model="pesquisaTickets.searchParam" dense outlined rounded type="search" class="full-width" :debounce="700" @input="BuscarTicketFiltro()" >
            </div>
            <div class="col-xs-12 col-md-3">
              <q-input label="Buscar Mensagem" v-model="pesquisaTickets.searchParamMessage" dense outlined rounded type="search" class="full-width" :debounce="700" @input="BuscarTicketFiltro()" >
            </div>
            <div class="col-xs-6 col-md-3">
              <q-select
                rounded
                dense
                outlined
                hide-bottom-space
                emit-value
                map-options
                multiple
                options-dense
                use-chips
                label="Status"
                color="primary"
                v-model="pesquisaTickets.status"
                :options="optionsStatus"
                :input-debounce="700"
                option-value="value"
                option-label="label"
                @input="BuscarTicketFiltro()"
                input-style="width: 300px; max-width: 300px;"
              />
            </div>
            <div class="col-xs-6 col-md-3">
              <DatePick
                dense
                rounded
                v-model="pesquisaTickets.startDate"
                label="Data Inicial"
                @input="BuscarTicketFiltro()"
              />
            </div>
            <div class="col-xs-6 col-md-3">
              <DatePick
                dense
                rounded
                v-model="pesquisaTickets.endDate"
                label="Data Final"
                @input="debounce(applyFilters(), 700)"
              />
            </div>
            <div class="col-xs-6 col-md-3">
              <q-select
                rounded
                dense
                outlined
                hide-bottom-space
                emit-value
                map-options
                multiple
                options-dense
                use-chips
                label="Filas"
                color="primary"
                v-model="pesquisaTickets.queuesIds"
                :options="queues"
                :input-debounce="700"
                option-value="id"
                option-label="queue"
                @input="debounce(BuscarTicketFiltro(), 700)"
                input-style="width: 300px; max-width: 300px;"
              />
            </div>
            <div class="col-xs-6 col-md-3">
              <q-select
                rounded
                dense
                outlined
                hide-bottom-space
                emit-value
                map-options
                multiple
                options-dense
                use-chips
                label="Etiquetas"
                color="primary"
                v-model="pesquisaTickets.tagsIds"
                :options="etiquetas"
                :input-debounce="700"
                option-value="id"
                option-label="tag"
                @input="debounce(BuscarTicketFiltro(), 700)"
                input-style="width: 300px; max-width: 300px;"
              />
            </div>
            <div class="col-xs-6 col-md-3">
              <q-select
                rounded
                dense
                outlined
                hide-bottom-space
                emit-value
                map-options
                multiple
                options-dense
                use-chips
                label="Usuários"
                color="primary"
                v-model="pesquisaTickets.useradmId"
                :options="attendants"
                :input-debounce="700"
                option-value="id"
                option-label="name"
                @input="debounce(BuscarTicketFiltro(), 700)"
                input-style="width: 300px; max-width: 300px;"
              />
            </div>
            <div class="col-xs-6 col-md-3">
              <q-select
                rounded
                dense
                outlined
                hide-bottom-space
                emit-value
                map-options
                multiple
                options-dense
                use-chips
                label="Canais"
                color="primary"
                v-model="pesquisaTickets.whatsappIds"
                :options="whatsapps"
                :input-debounce="700"
                option-value="id"
                option-label="name"
                @input="debounce(BuscarTicketFiltro(), 700)"
                input-style="width: 300px; max-width: 300px;"
              />
            </div>
            <!-- Botões de ação -->
            <div class="col-grow text-center">
              <q-btn
                color="green"
                label="Excel"
                @click="exportTable('tRelatorioTickets')"
              />
              <q-btn icon="print" label="Imprimir" class="q-mr-sm" color="black" @click="imprimirModal" />
            </div>
          </div>
        </fieldset>
      </q-card-section>
    </q-card>

    <div class="row">
      <div class="col-xs-12 q-mt-sm">
        <div
          class="tableLarge q-ma-sm q-markup-table q-table__container q-table__card q-table--cell-separator q-table--flat q-table--bordered q-table--no-wrap" id="tRelatorioTickets">
          <!-- Exibir estado de carregamento -->
          <div v-if="loading" class="loading">
            Carregando informações, por favor aguarde...
          </div>

          <!-- Tabela de atendimentos -->
          <table v-if="!loading" class="q-pb-md q-table q-tabs--dense " id="tableRelatorioTickets">
            <thead>
            <tr>
              <th>Ticket</th>
              <th>Status</th>
              <th>Nome</th>
              <th>Fila</th>
              <th>Conexão</th>
              <th>Usuário</th>
              <th>Horário Criação</th>
              <th>Horário Finalização</th>
              <th>Chat</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="ticket in filteredTickets" :key="ticket.id">
              <td><a :href="getTicketUrl(ticket.id)">{{ ticket.id }}</a></td>
              <td>
  <span :class="getStatusClass(ticket.status)">
    {{ getStatusText(ticket.status) }}
  </span>
              </td>
              <td>{{ ticket.contact.name }}</td>
              <td>
                <q-chip
                  v-if="ticket && ticket.queue"
                  :style="{ backgroundColor: ticket.queue.color, color: 'white' }"
                  dense
                  square
                  :label="ticket.queue.queue"
                  size="11px"
                  class="q-mr-md text-bold"
                />

              </td>
              <td>
                <q-chip
                  v-if="ticket && ticket.whatsapp"
                  :style="{ backgroundColor: ticket.whatsapp.color, color: 'white' }"
                  dense
                  square
                  :label="ticket.whatsapp.name"
                  size="11px"
                  class="q-mr-md text-bold"
                />

              </td>
              <td>{{ ticket.user?.name || 'N/A' }}</td>
              <td>{{ formatDate(ticket.createdAt) }}</td>
              <td>{{ formatDate(ticket.updatedAt) }}</td>
              <td>
                <button
                  class="q-mr-sm"
                  @click.prevent="visualizarChat(ticket.id)"
                >
                  <i class="fa fa-comments"></i> Chat
                </button>
              </td>
            </tr>
            </tbody>
          </table>

          <div v-if="hasMore && !loading" class="pagination">
            <button
              class="filter-button"
              v-if="hasMore && !loading"
              @click="onLoadMore">
              CARREGAR MAIS
            </button>
          </div>

        </div>
      </div>
    </div>

    <!-- Modal de Chat -->
    <ChatModal v-if="mostrarModal" :ticketId="String(ticketIdAtual)" @close="fecharChatModal" />
  </div>

</template>

<script>
import { RelatorioTickets } from 'src/service/estatisticas'
import { ListarFilas } from 'src/service/filas'
import { ListarUsuarios } from 'src/service/user'
import { ListarEtiquetas } from 'src/service/etiquetas'
import * as XLSX from 'xlsx'
import { debounce } from 'quasar'
import { mapGetters } from 'vuex'
import ChatModal from './ChatModal.vue'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  data () {
    return {
      pesquisaTickets: {
        searchParam: '',
        searchParamMessage: '',
        pageNumber: 1,
        status: ['open', 'pending', 'closed'],
        showAll: false,
        count: null,
        queuesIds: [],
        tagsIds: [],
        withUnreadMessages: false,
        isNotAssignedUser: false,
        includeNotQueueDefined: true,
        useradmId: [],
        whatsappIds: [],
        startDate: '',
        endDate: ''
      },
      optionsStatus: [
        { value: 'open', label: 'Aberto' },
        { value: 'pending', label: 'Pendente' },
        { value: 'closed', label: 'Fechado' }
      ],
      userProfile: 'user',
      contacts: [],
      debounce,
      queues: [],
      attendants: [],
      etiquetas: [],
      filteredTickets: [],
      hasMore: true,
      loading: false,
      mostrarModal: false,
      ticketIdAtual: null
    }
  },
  computed: {
    ...mapGetters([
      'whatsapps'
    ])
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    },
    imprimirModal() {
      const modalContent = document.getElementById('tableRelatorioTickets')
      if (!modalContent) {
        console.error('Erro: Não foi possível localizar o conteúdo do modal.')
        return
      }

      const printWindow = window.open('', '_blank', 'width=800,height=600')
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Imprimir</title>
              <style>
                body {
                  font-family: Arial, sans-serif;
                  margin: 20px;
                }
                .header {
                  display: flex;
                  justify-content: space-between;
                  align-items: center;
                  margin-bottom: 20px;
                }
                .title {
                  font-size: 18px;
                  font-weight: bold;
                  text-align: center;
                }
                .logo {
                  max-height: 50px;
                }
                #tableRelatorioTickets {
                  margin-top: 20px;
                }
              </style>
            </head>
            <body>
              <div class="header">
                <div class="title">Relatório de Tickets</div>
              </div>
              ${modalContent.outerHTML}
            </body>
          </html>
        `)
        printWindow.document.close()
        printWindow.focus()
        printWindow.print()
        printWindow.close()
      } else {
        console.error('Erro ao abrir a janela de impressão.')
      }
    },
    async BuscarTicketFiltro() {
      this.loading = true

      // Limpa os dados anteriores antes de buscar novos
      this.contacts = []
      this.filteredTickets = [] // Certifique-se de limpar também se estiver usando filteredTickets

      this.pesquisaTickets = {
        ...this.pesquisaTickets,
        pageNumber: 1
      }

      try {
        await this.consultarTickets(this.pesquisaTickets)
      } catch (err) {
        this.$notificarErro('Erro ao buscar tickets', err)
        console.error(err)
      } finally {
        this.loading = false
        this.$setConfigsUsuario({ isDark: this.$q.dark.isActive })
      }
    },
    async listarEtiquetas () {
      const { data } = await ListarEtiquetas(true)
      this.etiquetas = data
    },
    async consultarTickets(paramsInit = {}) {
      const params = {
        ...this.pesquisaTickets,
        ...paramsInit
      }
      try {
        const { data } = await RelatorioTickets(params)

        if (data && data.tickets && data.tickets.length > 0) {
          this.contacts = this.pageNumber === 1
            ? data.tickets
            : this.contacts.concat(data.tickets)
          this.filteredTickets = this.contacts
          this.hasMore = data.hasMore
        } else {
          this.hasMore = false
        }
      } catch (err) {
        this.$notificarErro('Algum problema', err)
        console.error(err)
      }
    },
    async loadQueuesAndAttendants () {
      try {
        const queuesData = await ListarFilas()
        this.queues = queuesData.data

        const attendantsData = await ListarUsuarios()
        this.attendants = attendantsData.data.users
      } catch (error) {
        console.error('Erro ao carregar filas e atendentes:', error)
      }
    },
    applyFilters () {
      this.pageNumber = 1
      this.consultarTickets()
    },
    async onLoadMore() {
      if (this.loading || !this.hasMore) return

      this.loading = true
      this.pesquisaTickets = {
        ...this.pesquisaTickets,
        pageNumber: this.pesquisaTickets.pageNumber + 1
      }

      try {
        await this.consultarTickets(this.pesquisaTickets)
      } catch (err) {
        this.$notificarErro('Erro ao carregar mais tickets', err)
        console.error(err)
      } finally {
        this.loading = false
      }
    },
    formatDate (dateString) {
      const date = new Date(dateString)
      return date.toLocaleString()
    },
    getTicketUrl(ticketId) {
      const route = this.$router.resolve({ path: `/atendimento/${ticketId}` })
      return route.href
    },
    getStatusClass(status) {
      switch (status) {
        case 'open':
          return 'status-open'
        case 'closed':
          return 'status-closed'
        case 'pending':
          return 'status-pending'
        default:
          return ''
      }
    },
    exportTable () {
      const json = XLSX.utils.table_to_sheet(
        document.getElementById('tableRelatorioTickets'),
        { raw: true }
      )
      for (const col in json) {
        if (col[0] == 'J') {
          json[col].t = 'n'
          json[col].v = json[col].v.replace(/\./g, '').replace(',', '.')
          // json[col].f = `VALUE(${json[col].v})`
        }
      }
      const wb = XLSX.utils.book_new()
      XLSX.utils.book_append_sheet(wb, json, 'Relatório Tickets')
      XLSX.writeFile(wb, 'relatorio-tickets.xlsx')
    },
    getStatusText(status) {
      switch (status) {
        case 'open':
          return 'Aberto'
        case 'closed':
          return 'Fechado'
        case 'pending':
          return 'Pendente'
        default:
          return status // Retorna o status original caso não seja reconhecido
      }
    },
    visualizarChat (ticketId) {
      this.ticketIdAtual = ticketId
      this.mostrarModal = true
    },
    fecharChatModal () {
      this.mostrarModal = false
    }
  },
  mounted () {
    this.loadColors()
    this.userProfile = localStorage.getItem('profile')
    this.consultarTickets()
    this.listarEtiquetas()
    this.loadQueuesAndAttendants()
  },
  components: {
    ChatModal
  }
}
</script>

<style scoped>

.filter-bar {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin-bottom: 20px;
  gap: 10px;
}

.filter-input, .filter-select {
  padding: 10px;
  background-color: #333;
  border: 1px solid #555;
  color: white;
  border-radius: 5px;
  flex: 1;
}

.filter-button {
  padding: 10px 20px;
  background-color: #007bff;
  border: none;
  color: white;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.filter-button:hover {
  background-color: #0056b3;
}

.status-open {
  background-color: #5c67f2;
  padding: 5px 10px;
  border-radius: 5px;
  color: white;
}

.status-closed {
  background-color: #25d366;
  padding: 5px 10px;
  border-radius: 5px;
  color: white;
}

.status-pending {
  background-color: #f44336;
  padding: 5px 10px;
  border-radius: 5px;
  color: white;
}

.loading {
  font-size: 18px;
  text-align: center;
  margin-top: 20px;
}

.styled-table a {
  color: #2196f3;
  text-decoration: none;
}

.styled-table a:hover {
  text-decoration: underline;
}

.pagination {
  text-align: center;
  margin-top: 20px;
}

.text-right {
  text-align: right;
}

thead tr:nth-child(1) td {
  color: #ffffff;
  background: rgb(0, 0, 0);
  position: sticky;
  opacity: 1;
  top: 0;
  z-index: 1000;
}

.tableSmall {
  max-height: calc(100vh - 130px);
  height: calc(100vh - 130px);
}

.tableLarge {
  max-height: calc(100vh - 220px);
  height: calc(100vh - 220px);
}
</style>
