import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert default general settings into the 'SettingsGeneral' table
    // Note: Using raw query for multiple inserts. Table name might need schema prefix depending on setup.
    // Assuming 'public."SettingsGeneral"' or just '"SettingsGeneral"' if 'public' is default schema.
    // Original code used public."SettingsGeneral".
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('timeCheckTickets', '3', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('allowSignup', 'enabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted settings from 'SettingsGeneral' table
    // Deleting based on keys, though a more robust approach might be needed
    // depending on whether other rows could have these keys.
    await queryInterface.bulkDelete(
      "SettingsGeneral", // Table name (adjust schema if needed, e.g., { tableName: 'SettingsGeneral', schema: 'public' })
      {
        key: ["timeCheckTickets", "allowSignup"] // Delete rows with these keys
      }
    );
    // Or, if you want to completely clear the table (use with caution):
    // await queryInterface.bulkDelete('SettingsGeneral', null, {});
  }
};

export = migration;
