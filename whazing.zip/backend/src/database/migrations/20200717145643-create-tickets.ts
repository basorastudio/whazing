import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    return queryInterface.createTable("Tickets", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      status: {
        type: DataTypes.STRING,
        defaultValue: "pending", // estado pendiente
        allowNull: false
      },
      lastMessage: {
        // Nombre de columna preservado
        type: DataTypes.STRING
      },
      contactId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Contacts",
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE" // O 'SET NULL' si el ticket puede existir sin contacto
      },
      userId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Users",
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL" // Permite que el ticket exista si el usuario es eliminado
      },
      createdAt: {
        type: DataTypes.DATE(6), // Preservando precisión si es relevante
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE(6), // Preservando precisión si es relevante
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    return queryInterface.dropTable("Tickets");
  }
};
