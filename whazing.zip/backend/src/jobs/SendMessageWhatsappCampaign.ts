"use strict";

import { logger } from "../utils/logger";
import CampaignContacts from "../models/CampaignContacts";
import Ticket from "../models/Ticket";
import FindOrCreateTicketService from "../services/TicketServices/FindOrCreateTicketService";
import ShowTicketService from "../services/TicketServices/ShowTicketService";
import socketEmit from "../helpers/socketEmit";
import Whatsapp from "../models/Whatsapp";
import CreateMessageSystemService from "../services/MessageServices/CreateMessageSystemService";
import AppError from "../errors/AppError"; // Asumiendo que tienes un archivo para errores personalizados
import Campaign from "../models/Campaign";

// Opciones para el trabajo de la cola (ejemplo con Bull)
// Backoff exponencial con un retraso base de 1 minuto
const jobOptions = {
  attempts: 3, // Número máximo de reintentos
  backoff: { type: "fixed" as "fixed", delay: 60000 } // Retraso fijo de 60 segundos
  // o exponencial: backoff: { type: 'exponential', delay: 60000 }
};

const queueOptions = {
  removeOnComplete: true, // Elimina el trabajo al completar
  // removeOnFail: false, // Mantener si falla para inspección (depende de la estrategia)
  jobId: "SendMessageWhatsappCampaign", // Puedes hacerlo dinámico si necesitas IDs únicos por mensaje
  ...jobOptions
};

interface CampaignData {
  campaignContact: {
    id: number;
    contactId: number;
    campaignId: number;
    // Añade otros campos de CampaignContact si son necesarios
  };
  campaign: {
    id: number;
    name: string;
    tenantId: number;
    whatsappId: number; // ID del WhatsApp a usar para enviar
    // Añade otros campos de Campaign si son necesarios
  };
  // mediaUrl?: string; // Opcional
  // mediaName?: string; // Opcional
  message: string; // Mensaje a enviar (puede ser un array o string)
  sendType: "template" | "media" | "text"; // Tipo de mensaje
  tenantId: number;
  jobId?: string | number; // El jobId si se genera externamente
  messageRandom?: string; // Ejemplo de campo adicional
  // Añade cualquier otro dato necesario para el job
}

export default {
  key: "SendMessageWhatsappCampaign", // Clave única para este tipo de trabajo
  options: queueOptions,

  async handle({ data }: { data: CampaignData }): Promise<void> {
    const {
      campaignContact,
      campaign,
      message,
      sendType,
      tenantId,
      jobId,
      messageRandom
    } = data;

    try {
      // Encuentra o crea el ticket para este contacto y campaña
      const whereTicket = {
        contactId: campaignContact.contactId,
        tenantId: tenantId,
        whatsappId: campaign.whatsappId,
        status: { [Op.ne]: "closed" as "closed" } // Usar Op de Sequelize
      };

      let ticket: Ticket | null = await Ticket.findOne({
        where: whereTicket,
        order: [["id", "DESC"]] // Obtener el más reciente si hay varios abiertos
      });

      // Si no existe ticket o está cerrado, crear uno nuevo
      if (!ticket) {
        const whatsapp = await Whatsapp.findOne({
          where: { id: campaign.whatsappId },
          attributes: ["id", "channel"]
        });
        if (!whatsapp) {
          logger.warn(
            `Whatsapp con ID ${campaign.whatsappId} no encontrado para la campaña ${campaign.id}`
          );
          throw new AppError(
            `Whatsapp ID ${campaign.whatsappId} no encontrado.`
          );
        }

        ticket = await FindOrCreateTicketService({
          contactId: campaignContact.contactId,
          whatsappId: campaign.whatsappId,
          unreadMessages: 0,
          tenantId: tenantId,
          groupContact: undefined, // Ajustar si la campaña permite grupos
          channel: whatsapp.channel || "whatsapp" // Canal del WhatsApp
        });

        await ticket.update({ status: "pending" }); // Marcar como pendiente

        // Emitir evento de socket para nuevo ticket
        const ticketToSend = await ShowTicketService({
          id: ticket.id,
          tenantId: tenantId
        });
        socketEmit({
          tenantId: tenantId,
          type: "ticket:update",
          payload: ticketToSend
        });
      }

      // Obtener detalles completos del ticket
      const ticketToShow = await ShowTicketService({
        id: ticket.id,
        tenantId: tenantId
      });

      // Preparar datos del mensaje a enviar
      let messageData: any;
      const messageBody = message || ""; // Asegurar que el cuerpo no sea null/undefined

      if (sendType === "template") {
        // Asumiendo que 'template' significa JSON complejo
        const parsedMessage =
          typeof messageBody === "string"
            ? JSON.parse(messageBody)
            : messageBody;
        const stringifiedJson = JSON.stringify(parsedMessage); // Para guardar en dataJson
        messageData = {
          body: "template", // O un identificador si es necesario
          fromMe: true,
          read: true,
          mediaUrl: "", // Las plantillas no suelen tener mediaUrl directo aquí
          mediaType: "template", // Identificador para plantillas
          tenantId: ticketToShow.tenantId,
          dataJson: stringifiedJson, // Guardar el JSON aquí
          channel: ticketToShow.channel || "whatsapp" // Canal del ticket
        };
      } else {
        // Para texto o media simple (adaptar si hay más tipos)
        messageData = {
          body: messageBody,
          fromMe: true,
          read: true,
          // mediaUrl: data.mediaUrl || '', // Descomentar y usar si aplica
          // mediaType: data.mediaType || 'chat', // Descomentar y usar si aplica
          tenantId: ticketToShow.tenantId,
          channel: ticketToShow.channel || "whatsapp" // Canal del ticket
        };
      }

      // Crear el mensaje en el sistema (aún no lo envía a WhatsApp)
      const createdMessage = await CreateMessageSystemService({
        msg: messageData,
        tenantId: tenantId,
        ticket: ticketToShow // Pasar el objeto ticket
        // Aquí es donde se debería disparar el envío real a través de la API de WhatsApp
        // El servicio CreateMessageSystemService debería manejar esto o delegarlo
      });

      // Actualizar el registro de CampaignContacts con el ID del mensaje y estado
      await CampaignContacts.update(
        {
          messageId: createdMessage.id,
          ack: 1, // Marcar como enviado (ACK 1 usualmente significa recibido por el servidor)
          messageRandom: messageRandom || null,
          body:
            typeof messageBody === "string"
              ? messageBody
              : JSON.stringify(messageBody), // Guardar el cuerpo
          // mediaName: data.mediaName || null, // Guardar si aplica
          timestamp: Math.floor(Date.now() / 1000), // Timestamp UNIX
          jobId: jobId || null
        },
        { where: { id: campaignContact.id } }
      );

      logger.info(
        `Campanha enviada para: ${campaignContact.contactId} campaign: ${campaign.id}`
      );
    } catch (err: any) {
      logger.error(
        `Error enviar message campaign: ${campaign.id} para contato: ${campaignContact.contactId} :: ${err.message}`
      );
      // Capturar la excepción con Sentry
      Sentry.captureException(err);
      // Podrías querer actualizar CampaignContacts con un estado de error aquí
      try {
        await CampaignContacts.update(
          {
            ack: 4, // Un ACK que signifique error
            jobId: jobId || null
            // Podrías guardar el mensaje de error si tienes un campo para ello
          },
          { where: { id: campaignContact.id } }
        );
      } catch (updateError: any) {
        Sentry.captureException(updateError);
        logger.error(
          `Error actualizando estado de error para CampaignContact ${campaignContact.id}: ${updateError.message}`
        );
      }
      throw err; // Re-lanzar para que Bull maneje los reintentos/fallo
    }
  }
};
