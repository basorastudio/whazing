import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Propiedades comunes para las nuevas columnas
    const commonProps = {
      allowNull: true, // Permite nulos
      defaultValue: null
    };

    return Promise.all([
      // Añade la columna 'phone' (string) a 'Whatsapps'
      queryInterface.addColumn('Whatsapps', 'phone', {
        type: DataTypes.STRING,
        ...commonProps
      }),
      // Añade la columna 'number' (jsonb) a 'Whatsapps'
      queryInterface.addColumn('Whatsapps', 'number', {
        type: DataTypes.JSONB,
        ...commonProps
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina las columnas añadidas
    return Promise.all([
        queryInterface.removeColumn('Whatsapps', 'phone'),
        queryInterface.removeColumn('Whatsapps', 'number') // Corregido: eliminar ambas columnas
    ]);
  }
};