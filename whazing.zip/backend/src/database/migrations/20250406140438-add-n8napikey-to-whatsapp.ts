import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'n8nApiKey' column to the 'Whatsapps' table
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "n8nApiKey", // New column name
      {
        type: DataTypes.TEXT // TEXT for potentially long API keys
        // allowNull defaults to true
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'n8nApiKey' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      "Whatsapps", // Table name
      "n8nApiKey" // Column name to remove
    );
  }
};

export = migration;
