import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'wavoip' column to the 'Whatsapps' table
    // Likely stores configuration data for WhatsApp Voice over IP (VoIP) / Calls.
    await queryInterface.addColumn(
      'Whatsapps', // Table name
      'wavoip',    // New column name
      {
        type: DataTypes.TEXT, // TEXT for potentially large configuration data
        // allowNull defaults to true
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'wavoip' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps', // Table name
      'wavoip'     // Column name to remove
    );
  }
};

export = migration;