import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      // Elimina la columna 'queue' (probablemente INTEGER simple)
      queryInterface.removeColumn('StepsReplyActions', 'queue'),
      // Añade 'queueId' como clave foránea a 'Queues'
      queryInterface.addColumn('StepsReplyActions', 'queueId', {
        type: DataTypes.INTEGER,
        references: { model: 'Queues', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'restrict', // No permite eliminar Queue si hay acciones asociadas
        defaultValue: null,
        allowNull: true,
      }),
      // Elimina la columna 'userIdDestination' (probablemente INTEGER simple)
      queryInterface.removeColumn('StepsReplyActions', 'userIdDestination'),
      // Añade 'userIdDestination' como clave foránea a 'Users'
      queryInterface.addColumn('StepsReplyActions', 'userIdDestination', {
        type: DataTypes.INTEGER,
        references: { model: 'Users', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'restrict', // No permite eliminar User si hay acciones asociadas
        defaultValue: null,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Revierte los cambios
    const queueColumn = {
        type: DataTypes.INTEGER,
        defaultValue: null,
        allowNull: true,
    };
    const userIdDestColumn = {
        type: DataTypes.INTEGER,
        defaultValue: null,
        allowNull: true,
    };
    return Promise.all([
      queryInterface.removeColumn('StepsReplyActions', 'queueId'),
      queryInterface.addColumn('StepsReplyActions', 'queue', queueColumn),
      queryInterface.removeColumn('StepsReplyActions', 'userIdDestination'),
      queryInterface.addColumn('StepsReplyActions', 'userIdDestination', userIdDestColumn),
    ]);
  }
};