import { i18n } from 'src/boot/i18n'
import Vuelidate from 'vuelidate'
import VuelidateErrorExtractor from 'vuelidate-error-extractor'

import linkify from 'vue-linkify'

/* We need messages for validation */
const messages = {
  required: i18n.t('vuelidate.required'),
  email: i18n.t('vuelidate.emailvalida'),
  minValue: i18n.t('vuelidate.minValue'),
  minLength: i18n.t('vuelidate.minLength'),
  maxLength: i18n.t('vuelidate.maxLength'),
  validaData: i18n.t('vuelidate.validaData')
}

const mapNames = {
  email: i18n.t('vuelidate.email'),
  name: i18n.t('vuelidate.name'),
  nome: i18n.t('vuelidate.name'),
  username: i18n.t('vuelidate.username')
}

export default ({
  Vue
}) => {
  Vue.directive('linkified', linkify)
  Vue.use(Vuelidate)
  Vue.use(VuelidateErrorExtractor, {
    messages,
    attributes: mapNames
  })
}
