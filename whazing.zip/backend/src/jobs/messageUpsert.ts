import Message from '../models/Message'; // Assuming default export
import Queue from '../libs/Queue';
import Long from 'long'; // Import Long if needed for timestamp conversion
import { FindOptions, WhereOptions } from 'sequelize'; // Import necessary Sequelize types
import { proto } from '@whiskeysockets/baileys'; // Assuming Baileys types

// Define interfaces for the data structures
interface MessageInfo extends proto.IWebMessageInfo {
    // Extend Baileys type if necessary, or use it directly
    // Handle potential Long types:
    messageTimestamp?: number | Long; // Keep original or convert
}

interface UpsertData {
    whatsappId: number | string;
    tenantId: number | string;
    messages: MessageInfo[];
}

interface QueueJobData {
    message: MessageInfo;
    whatsappId: number | string;
    isImported: boolean;
    tenantId: number | string;
    jobId?: string; // Added jobId for queue
}

interface Job {
    data: UpsertData;
}

interface BackoffOptions {
    type: string;
    delay: number;
}

interface HandleOptions {
    delay: number;
    attempts: number;
    removeOnComplete: boolean;
    removeOnFail: boolean;
    backoff: BackoffOptions;
}

const backoffOptions: BackoffOptions = {
    type: 'fixed',
    delay: 5000 // 0x1388
};

const handleOptions: HandleOptions = {
    delay: 100,         // 0x64
    attempts: 10,
    removeOnComplete: true,
    removeOnFail: false, // Original: ![]
    backoff: backoffOptions
};

export const messageUpsert = {
    key: 'messageUpsert',
    options: handleOptions,
    async handle({ data }: Job): Promise<void> {
        const { whatsappId, tenantId, messages } = data;

        for (const message of messages) {
            // Handle Long conversion for timestamp if necessary
            // Check if it's a Long object before calling toNumber()
            if (message.messageTimestamp && Long.isLong(message.messageTimestamp)) {
                 // Convert Long to number (potentially losing precision for very large numbers)
                 // Or store as string/bigint if precision is critical
                message.messageTimestamp = (message.messageTimestamp as Long).toNumber();
            }

            if (!message.key?.id) {
                console.warn(`Skipping message upsert due to missing key ID for tenant ${tenantId}, WhatsApp ${whatsappId}`);
                continue; // Skip if message ID is missing
            }

            const messageId = message.key.id;

            // Check if message already exists
            const where: WhereOptions = {
                messageId: messageId,
                tenantId: tenantId,
                whatsappId: whatsappId // Added whatsappId to make the check more specific
            };
            const findOptions: FindOptions = { where };

            // Use count for efficiency if only existence check is needed
            // const existingMessageCount = await Message.count(findOptions);
            // Or use findOne if you need the message data later
            const existingMessage = await Message.findOne(findOptions);

            if (!existingMessage) {
                // If message doesn't exist, queue it for insertion via handleMessageQueue
                const queueData: QueueJobData = {
                    message: message,
                    whatsappId: whatsappId,
                    isImported: false, // Assuming these are new messages, not imported ones
                    tenantId: tenantId,
                    // Construct a unique Job ID
                    jobId: `${whatsappId}-handleMessage-${messageId}`
                };
                // The queue name was 'HandleMessageQueue' concatenated with tenantId
                // Ensure Queue.add handles dynamic queue names or adjust accordingly
                const queueName = `HandleMessageQueue-${tenantId}`;
                await Queue.add(queueName, queueData);
                // console.log(`Message ${messageId} queued for insertion for tenant ${tenantId}`);
            } else {
                // console.log(`Message ${messageId} already exists for tenant ${tenantId}. Skipping queue.`);
                // Optionally update the existing message if needed, but original logic didn't
            }
        }
    }
};