<template>
  <div>
    <wait-dialog :d-wait="dialogWait" />
    <q-card class="no-shadow">
      <q-card-section class="text-h6 text-bold q-py-xs q-mb-sm">
        <div class="row flex-gap-1">
        CRM
          <q-select
            v-model="params.selectedUser"
            v-if="userProfile === 'admin'"
            :options="usuarios"
            option-value="id"
            option-label="name"
            label="Cambiar Usuario CRM"
            @input="filtrarCRM"
            class="contact-search"
            style="width: 300px; min-height: 30px; height: 30px;"
            filled
            dense
            debounce="500"
            clearable
          >
          </q-select>
          <q-btn
            @click="showDialog()"
            color="primary"
            dense
            flat
            icon="add"
            v-if="!showNew"
          />
        <!-- Nueva lista -->
        <q-form @reset="cancelNewList" @submit="newList" v-else>
          <div class="row items-center no-wrap">
            <div class="col q-mr-sm">
              <q-card
                class="bg-white btn-rounded q-pa-sm"
                style="width: 100%"
                bordered
                flat
              >
                <q-card-section class="text-bold q-px-none" :class="{'text-white': $q.dark.isActive}">
                  Nueva lista
                  <q-separator />
                </q-card-section>
                <q-card-section class="q-pa-none">
                  <q-input
                    autofocus
                    dense
                    outlined
                    label="Nombre"
                    v-model="newListTitle"
                    :class="{'text-white': $q.dark.isActive}"
                  />
                  <q-input
                    autofocus
                    dense
                    outlined
                    label="Posición en la lista"
                    type="number"
                    v-model="newListOrder"
                    :class="{'text-white': $q.dark.isActive}"
                  />
                  <q-input
                    filled
                    dense
                    hide-bottom-space
                    label="Color"
                    :style="`background: ${titleColor} `"
                    v-model="titleColor"
                    :rules="['anyColor']"
                    class="q-my-md"
                    :class="{'text-white': $q.dark.isActive}"
                    :dark="false"
                  >
                    <template v-slot:preappend> </template>
                    <template v-slot:append>
                      <q-icon name="colorize" class="cursor-pointer" :color="$q.dark.isActive ? 'white' : 'black'">
                        <q-popup-proxy
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-color
                            format-model="hex"
                            square
                            default-view="palette"
                            no-header
                            bordered
                            v-model="titleColor"
                          />
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                </q-card-section>
              </q-card>
            </div>
            <div class="col-auto">
              <q-btn color="primary" dense flat icon="close" type="reset" />
              <q-btn color="primary" dense flat icon="done" type="submit" />
            </div>
          </div>
        </q-form>
        </div>
      </q-card-section>
    </q-card>
    <q-card class="no-shadow q-mt-sm">
      <q-card-section class="q-px-sm q-py-none">
        <draggable
          class="kanban-container"
          v-model="lists"
          @change="log($event)"
          group="upper"
        >
          <List
            :data="list"
            :key="list.id"
            @delete-list="deleteList"
            @update-list="updateList"
            @update-card="updateCard"
            @save-ordenacao="salvarOrdem"
            v-for="list in lists"
          />
        </draggable>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
const userId = +localStorage.getItem('userId')

import WaitDialog from 'src/components/WaitDialog.vue'
import {
  ListarKanbans,
  DeletarKanban,
  AlterarKanban,
  ConsultarContatosKanbanService,
  CriarKanban, AlterarContactKanban
} from 'src/service/kanban'
import { ListarFilas } from 'src/service/filas'
import { DadosUsuario, ListarUsuarios, UpdateUsuarios } from 'src/service/user'

import _ from 'lodash'

import draggable from 'vuedraggable'
import List from './List.vue'

export default {
  name: 'Board',
  components: {
    List,
    WaitDialog,
    draggable
  },
  data: (vm) => ({
    dialogWait: false,
    contatos: [],
    filas: [],
    params: {
      selectedUser: null
    },
    showNew: false,
    usuario: {},
    usuarios: [],
    userIdAdmin: null,
    newListTitle: '',
    userProfile: 'user',
    newListOrder: null,
    titleColor: null,
    scrollSpeed: 20,
    lists: [
      {
        id: 0,
        name: 'Contactos',
        cards: []
      }
    ]
  }),
  async mounted() {
    this.userProfile = localStorage.getItem('profile')
    const draggableContainer = this.$el.querySelector('.kanban-container')
    draggableContainer.addEventListener('dragstart', this.enableAutoScroll)
    this.userProfile = localStorage.getItem('profile')
    try {
      await this.listarUsuarios()
      this.dialogWait = true
      const { data } = await ListarFilas()
      this.filas = data
      const { data: usu } = await DadosUsuario(userId)
      this.usuario = usu
      await this.consultarContatos()
      await this.listarKanbans()
      this.ordenar()
    } finally {
      this.dialogWait = false
    }
  },
  methods: {
    async filtrarCRM() {
      const selectedUserId = this.params.selectedUser ? this.params.selectedUser.id : +localStorage.getItem('userId')
      this.userId = selectedUserId

      this.lists = [
        {
          id: 0,
          name: 'Contactos',
          cards: []
        }
      ]

      try {
        const { data: usu } = await DadosUsuario(selectedUserId)
        this.usuario = usu
        await this.consultarContatos()
        await this.listarKanbans()
        this.ordenar()
      } catch (error) {
        console.error('Error al cargar datos del usuario:', error)
      }
    },
    enableAutoScroll() {
      const kanbanContainer = this.$el.querySelector('.kanban-container')

      let scrollInterval = null

      const onDragOver = (event) => {
        const { clientX } = event
        const { left, right } = kanbanContainer.getBoundingClientRect()

        if (clientX < left + 50) {
          if (!scrollInterval) {
            scrollInterval = setInterval(() => {
              kanbanContainer.scrollLeft -= this.scrollSpeed
            }, 20)
          }
        } else if (clientX > right - 50) {
          if (!scrollInterval) {
            scrollInterval = setInterval(() => {
              kanbanContainer.scrollLeft += this.scrollSpeed
            }, 20)
          }
        } else {
          if (scrollInterval) {
            clearInterval(scrollInterval)
            scrollInterval = null
          }
        }
      }

      const onDragEnd = () => {
        if (scrollInterval) {
          clearInterval(scrollInterval)
          scrollInterval = null
        }
        kanbanContainer.removeEventListener('dragover', onDragOver)
        kanbanContainer.removeEventListener('dragend', onDragEnd)
      }

      kanbanContainer.addEventListener('dragover', onDragOver)
      kanbanContainer.addEventListener('dragend', onDragEnd)
    },
    log(evt) {},
    showDialog() {
      this.newListTitle = ''
      this.titleColor = null
      this.newListOrder = null
      this.showNew = true
    },
    ordenar() {
      const ordenacion = this.usuario.kanbanOrder || []
      let itemsOthersArraysOrdenacao = []
      const contactIds = new Set()
      for (let i = 1; i < this.lists.length; i++) {
        const id = this.lists[i].id
        const savedOrdem = ordenacion.find((el) => el.id == id)?.value || []
        itemsOthersArraysOrdenacao = [
          ...itemsOthersArraysOrdenacao,
          ...savedOrdem
        ]
        this.lists[i].cards = this.doOrdenacao(this.contatos, savedOrdem)
        const mc = this.lists[i].cards.map((o) => {
          if (o.id) return o.id
        })
        for (const el of mc) {
          contactIds.add(el)
        }
      }
      const arrContactIds = [...contactIds]
      const tempContatos = this.contatos.filter(
        (x) =>
          !itemsOthersArraysOrdenacao.includes(x.id) &&
          !arrContactIds.includes(x.id)
      )
      this.lists[0].cards = _.uniqBy(tempContatos, (obj) => obj.id)
      this.lists = _.cloneDeep(this.lists)
    },

    doOrdenacao(list, ordenacoes) {
      const indexObject = _.reduce(
        list,
        (result, currentObject) => {
          result[currentObject.id] = currentObject
          return result
        },
        {}
      )
      const temp = ordenacoes.reduce(function (res, el) {
        const cel = indexObject[el]
        if (cel) {
          res.push(cel)
        }
        return res
      }, [])
      return temp
    },
    async salvarOrdem(dados = {}) {
      if (this.params.selectedUser) {
        this.$notificarErro('Solo lectura no puedes editar CRM de otro usuario!')
        return
      }
      const ordenacion = []
      for (const tasks of this.lists) {
        const tempCardsIds = tasks.cards.map((el) => el.id)
        const tempListId = tasks.id
        const ob = { id: tempListId, value: tempCardsIds }
        ordenacion.push(ob)
      }
      const { email, id, name, tenantId, password } = this.usuario

      const params = {
        email,
        id,
        name,
        tenantId,
        password,
        kanbanOrder: ordenacion
      }

      if (this.$store.state.user.isAdmin) {
        params.profile = this.usuario.profile
      }

      try {
        await UpdateUsuarios(params.id, params)

        if (dados.added) {
          console.log('Kanban ID para actualizar:', dados.kanbanId)
          console.log('Contact ID para actualizar:', dados.contactId)

          const response = await AlterarContactKanban({
            contactId: dados.contactId,
            kanbanId: dados.kanbanId
          })

          console.log('Respuesta del backend para AlterarKanban:', response)
        }

        this.usuario.kanbanOrder = params.kanbanOrder || []
        this.ordenar()
      } catch (error) {
        this.$notificarErro(error)
        console.log(error)
      }
    },
    async getKanbans() {
      const { data } = await ListarKanbans({
        userIdAdmin: this.userIdAdmin
      })
      return data
    },
    async listarUsuarios() {
      const data = await ListarUsuarios()
      this.usuarios = data.data.users
    },
    async listarKanbans() {
      const data = await this.getKanbans()
      this.lists = [...this.lists, ...data]
      const nmap = this.lists.map((el) => {
        el.filas = this.filas
        if (el.id !== 0) {
          el.cards = []
        } else {
          el.cards = this.contatos
        }
        return el
      })
      this.lists = _.cloneDeep(nmap)
    },
    async consultarContatos() {
      const ordenacion = this.usuario.kanbanOrder || []
      const Ids = new Set()
      const values = ordenacion.map((o) => o.value)
      for (let i = 0; i < values.length; i++) {
        if (values[i].length > 0) {
          Ids.add(...values[i])
        }
      }
      try {
        const { data } = await ConsultarContatosKanbanService({
          userIdAdmin: this.userIdAdmin
        })
        this.contatos = data
      } catch (error) {
        console.error(error)
        this.$notificarErro('Error al consultar atenciones', error)
      }
    },
    async newList() {
      if (this.params.selectedUser) {
        this.$notificarErro('Solo lectura no puedes editar CRM de otro usuario!')
        return
      }
      try {
        const { data } = await CriarKanban({
          name: this.newListTitle,
          color: this.titleColor,
          order: this.newListOrder
        })
        this.lists.push({
          id: data.id,
          name: this.newListTitle,
          cards: [],
          filas: this.filas,
          color: this.titleColor
        })
        this.showNew = false
        this.newListOrder = null
        this.newListTitle = ''
        this.$emit('modal-kanban:criada', data)
        this.$q.notify({
          type: 'positive',
          progress: true,
          position: 'top',
          message: 'Lista Kanban creada!',
          actions: [
            {
              icon: 'close',
              round: true,
              color: 'white'
            }
          ]
        })
        window.location.reload()
      } catch (error) {
        console.error(error)
        this.$notificarErro('¡Ocurrió un error!', error)
      }
    },
    cancelNewList() {
      this.newListTitle = ''
      this.titleColor = null
      this.newListOrder = null
      this.showNew = false
    },
    updateCard(ob) {
      const { contato } = ob

      for (const list of this.lists) {
        const cardIndex = list.cards.findIndex(
          (item) => item.id === contato.id
        )
        this.consultarContatos()
        if (cardIndex >= 0) {
          const { deadline, commentary, kanbanPrice } = contato

          list.cards[cardIndex] = {
            ...list.cards[cardIndex],
            deadline,
            commentary,
            kanbanPrice,
            contact: contato
          }
        }
      }

      this.lists = _.cloneDeep(this.lists)
    },
    async updateList(newdata) {
      if (this.params.selectedUser) {
        this.$notificarErro('Solo lectura no puedes editar CRM de otro usuario!')
        return
      }
      this.salvarOrdem()
      try {
        const { data } = await AlterarKanban(newdata)
        this.$q.notify({
          type: 'positive',
          progress: true,
          position: 'top',
          message: `Lista ${data.name} actualizada!`,
          actions: [
            {
              icon: 'close',
              round: true,
              color: 'white'
            }
          ]
        })
        window.location.reload()
      } catch (error) {
        console.error(error)
        this.$notificarErro('¡Ocurrió un error!', error)
      }
    },
    async deleteList(data) {
      if (this.params.selectedUser) {
        this.$notificarErro('Solo lectura no puedes editar CRM de otro usuario!')
        return
      }
      this.lists[0].cards = [...this.lists[0].cards, ...data.cards]
      this.salvarOrdem()
      await DeletarKanban({ id: data.id })
      let newLists = [...this.lists]
      newLists = newLists.filter((f) => f.id !== data.id)

      this.lists = [...newLists]
      this.$q.notify({
        type: 'positive',
        progress: true,
        position: 'top',
        message: `Ítem ${data.name} eliminado!`,
        actions: [
          {
            icon: 'close',
            round: true,
            color: 'white'
          }
        ]
      })
    }
  }
}
</script>
<style lang="scss">
.kanban-container {
  display: flex;
  flex-wrap: nowrap;
  overflow-x: auto;
  gap: 16px;
  padding: 8px;
}

.kanban-container > * {
  flex: 0 0 300px; /* Define un tamaño fijo para cada lista */
  max-width: 300px; /* Garantiza que las listas no sean más pequeñas de lo deseado */
}

.kanban-container::-webkit-scrollbar {
  height: 8px;
}

.kanban-container::-webkit-scrollbar-thumb {
  background-color: rgba(0, 0, 0, 0.5);
  border-radius: 4px;
}

.kanban-container::-webkit-scrollbar-track {
  background-color: rgba(0, 0, 0, 0.1);
}
</style>
