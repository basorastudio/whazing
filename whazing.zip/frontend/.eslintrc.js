module.exports = {
  // https://eslint.org/docs/user-guide/configuring#configuration-cascading-and-hierarchy
  // Esta opción interrumpe la jerarquía de configuración en este archivo
  // Elimina esto si tienes un archivo de configuración ESLint de nivel superior (suele ocurrir en monorepos)
  root: true,

  parserOptions: {
    parser: 'babel-eslint',
    ecmaVersion: 2018, // Permite el análisis de características modernas de ECMAScript
    sourceType: 'module' // Permite el uso de imports
  },

  env: {
    browser: true
  },

  // El orden de las reglas es importante, por favor evita reorganizarlas
  extends: [
    // Reglas recomendadas base de ESLint
    // 'eslint:recommended',


    // Descomenta cualquiera de las líneas a continuación para elegir el nivel de estrictitud deseado,
    // ¡pero deja solo una descomentada!
    // Ver https://eslint.vuejs.org/rules/#available-rules
    'plugin:vue/essential', // Prioridad A: Esencial (Prevención de Errores)
    // 'plugin:vue/strongly-recommended', // Prioridad B: Fuertemente Recomendado (Mejorando la Legibilidad)
    // 'plugin:vue/recommended', // Prioridad C: Recomendado (Minimizando Elecciones Arbitrarias y Sobrecarga Cognitiva)

    'standard'

  ],

  plugins: [
    // https://eslint.vuejs.org/user-guide/#why-doesn-t-it-work-on-vue-file
    // requerido para lint archivos *.vue
    'vue',

  ],

  globals: {
    ga: true, // Google Analytics
    cordova: true,
    __statics: true,
    process: true,
    Capacitor: true,
    chrome: true
  },

  // agrega tus reglas personalizadas aquí
  rules: {
    // permitir async-await
    'generator-star-spacing': 'off',
    // permitir funciones flecha sin paréntesis
    'arrow-parens': 'off',
    'one-var': 'off',
    'eqeqeq': 0,
    'space-before-function-paren': "off",
    'camelcase': "off",
    'import/first': 'off',
    'import/named': 'error',
    'import/namespace': 'error',
    'import/default': 'error',
    'import/export': 'error',
    'import/extensions': 'off',
    'import/no-unresolved': 'off',
    'import/no-extraneous-dependencies': 'off',
    'prefer-promise-reject-errors': 'off',
    'space-before-function-paren' : 'off',
    "no-use-v-if-with-v-for": 0,
    "vue/no-use-v-if-with-v-for": [
      "error",
      {
        allowUsingIterationVar: true
      }
    ],

    // permitir console.log solo durante el desarrollo
    "no-console": 0,

    // permitir debugger solo durante el desarrollo
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off'
  }
}
