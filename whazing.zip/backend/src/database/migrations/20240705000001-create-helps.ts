import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'Helps' table
    await queryInterface.createTable(
      "Helps", // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false
        },
        title: {
          type: DataTypes.STRING,
          allowNull: false
        },
        description: {
          type: DataTypes.TEXT, // TEXT for longer descriptions
          allowNull: true // Description can be optional
        },
        video: {
          type: DataTypes.STRING,
          allowNull: true // Video link can be optional
        },
        link: {
          type: DataTypes.STRING,
          allowNull: true // External link can be optional
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        }
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'Helps' table
    await queryInterface.dropTable("Helps");
  }
};

export = migration;
