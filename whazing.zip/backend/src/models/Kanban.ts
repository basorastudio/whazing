import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import Tenant from "./Tenant";
import User from "./User";
import ChatFlow from "./ChatFlow";

@Table
class Kanban extends Model<Kanban> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  name: string;

  @Column
  color: string;

  @Column
  order: number; // Assuming numeric order

  @Default(true)
  @Column
  isActive: boolean;

  @AllowNull(true) // Making FK nullable as per decorator
  @ForeignKey(() => ChatFlow)
  @Column
  chatFlowId: number | null;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @BelongsTo(() => ChatFlow)
  chatFlow: ChatFlow;
}

export default Kanban;