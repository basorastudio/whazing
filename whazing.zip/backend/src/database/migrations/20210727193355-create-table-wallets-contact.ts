import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla de unión 'ContactWallets' para asociar contactos a "billeteras" (Usuarios?)
    return queryInterface.createTable("ContactWallets", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      walletId: {
        // ID de la "billetera", referenciando a la tabla Users
        type: DataTypes.INTEGER,
        references: {
          model: "Users", // !! Referencia a Users, ¿debería ser una tabla Wallets?
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: false
      },
      contactId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Contacts", // Referencia a la tabla Contacts
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: false
      },
      tenantId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Tenants", // Referencia a la tabla Tenants
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "CASCADE",
        allowNull: false
        // defaultValue no especificado
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la tabla 'ContactWallets'
    return queryInterface.dropTable("ContactWallets");
  }
};
