import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    return queryInterface.createTable('Whatsapps', {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      session: { // Nombre de columna preservado
        type: DataTypes.TEXT
      },
      qrcode: { // Nombre de columna preservado
        type: DataTypes.TEXT
      },
      status: { // Nombre de columna preservado
        type: DataTypes.STRING
      },
      battery: { // Nombre de columna preservado
        type: DataTypes.STRING
      },
      plugged: { // Nombre de columna preservado
        type: DataTypes.BOOLEAN
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
      // Otras columnas como name, isDefault, retries, phone, isDeleted, etc.,
      // fueron añadidas en migraciones posteriores.
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    return queryInterface.dropTable('Whatsapps');
  }
};