import { api } from './api';

export default {
  async createOrder(value, currency = 'USD', description) {
    try {
      const { data } = await api.post('/paypal/create-order', {
        value,
        currency,
        description
      });
      return data;
    } catch (error) {
      throw new Error('Error al crear la orden de PayPal');
    }
  },

  async capturePayment(orderId) {
    try {
      const { data } = await api.post(`/paypal/capture/${orderId}`);
      return data;
    } catch (error) {
      throw new Error('Error al capturar el pago de PayPal');
    }
  },

  async getClientId() {
    try {
      const { data } = await api.get('/paypal/client-id');
      return data.clientId;
    } catch (error) {
      throw new Error('Error al obtener el Client ID de PayPal');
    }
  }
};