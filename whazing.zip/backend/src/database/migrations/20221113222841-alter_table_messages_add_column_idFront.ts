// --- START OF FILE 20221113222841-alter_table_messages_add_column_idFront.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Messages";
    const columnName = "idFront";
    const attributes = {
      type: DataTypes.STRING,
      allowNull: true, // Changed !![] to true
      defaultValue: null
    };
    await Promise.all([
      queryInterface.addColumn(tableName, columnName, attributes)
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Messages";
    const columnName = "idFront";
    await Promise.all([queryInterface.removeColumn(tableName, columnName)]);
  }
};

export default migration;

// --- END OF FILE 20221113222841-alter_table_messages_add_column_idFront.ts ---
