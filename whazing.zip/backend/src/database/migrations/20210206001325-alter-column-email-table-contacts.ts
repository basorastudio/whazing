import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Modifica la columna 'email' en la tabla 'Contacts' para permitir nulos
    return Promise.all([
      queryInterface.changeColumn("Contacts", "email", {
        type: DataTypes.STRING,
        allowNull: true, // Permite nulos
        defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Revierte los cambios en la columna 'email'
    return Promise.all([
      queryInterface.changeColumn("Contacts", "email", {
        type: DataTypes.STRING,
        allowNull: false, // No permite nulos
        defaultValue: "" // Vuelve al valor predeterminado de cadena vacía
      })
    ]);
  }
};
