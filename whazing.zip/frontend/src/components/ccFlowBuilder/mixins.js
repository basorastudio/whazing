export const easyFlowMixin = {
  data () {
    return {
      jsplumbSetting: {
        // Puntos de anclaje dinámicos, adaptación de posición
        Anchors: ['Top', 'TopCenter', 'TopRight', 'TopLeft', 'Right', 'RightMiddle', 'Bottom', 'BottomCenter', 'BottomRight', 'BottomLeft', 'Left', 'LeftMiddle'],
        // ID del contenedor
        Container: 'efContainer',
        // Estilo de conexión, línea recta o curva, valores opcionales: StateMachine, Flowchart, Bezier, Straight
        Connector: ['Bezier', { curviness: 100 }],
        // Connector: ['Straight', {stub: 20, gap: 1}],
        // Connector: ['Flowchart', {stub: 30, gap: 1, alwaysRespectStubs: false, midpoint: 0.5, cornerRadius: 10}],
        // Connector: ['StateMachine', {margin: 5, curviness: 10, proximityLimit: 80}],
        // El ratón no puede arrastrar para eliminar líneas
        ConnectionsDetachable: false,
        // Los nodos no se eliminan al borrar líneas
        DeleteEndpointsOnDetach: false,
        /**
         * Tipo de punto final en ambos extremos de la conexión: circular
         * radius: Radio del círculo, cuanto mayor sea el radio, mayor será el círculo
         */
        // Endpoint: ['Dot', {radius: 5, cssClass: 'ef-dot', hoverClass: 'ef-dot-hover'}],
        /**
         * Tipo de punto final en ambos extremos de la conexión: rectangular
         * height: Altura del rectángulo
         * width: Ancho del rectángulo
         */
        // Endpoint: ['Rectangle', {height: 20, width: 20, cssClass: 'ef-rectangle', hoverClass: 'ef-rectangle-hover'}],
        /**
         * Punto final de imagen
         */
        // Endpoint: ['Image', {src: 'https://www.easyicon.net/api/resizeApi.php?id=1181776&size=32', cssClass: 'ef-img', hoverClass: 'ef-img-hover'}],
        /**
         * Punto final en blanco
         */
        Endpoint: ['Blank', { Overlays: '' }],
        // Endpoints: [['Dot', {radius: 5, cssClass: 'ef-dot', hoverClass: 'ef-dot-hover'}], ['Rectangle', {height: 20, width: 20, cssClass: 'ef-rectangle', hoverClass: 'ef-rectangle-hover'}]],
        /**
         * Estilo de los puntos finales en ambos extremos de la conexión
         * fill: Valor de color, ej: #12aabb, si está vacío no se muestra
         * outlineWidth: Ancho del borde exterior
         */
        EndpointStyle: { fill: '#1879ffa1', outlineWidth: 1 },
        // Habilitar registro interno de jsPlumb
        LogEnabled: true,
        /**
         * Estilo de la conexión
         */
        PaintStyle: {
          // Color de la línea
          stroke: '#5c67f2',
          // Grosor de la línea, cuanto mayor sea el valor, más gruesa será la línea
          strokeWidth: 1,
          // Establecer color del borde exterior, por defecto transparente para que no sea visible, al hacer clic en la línea no es necesario ser preciso, referencia: https://blog.csdn.net/roymno2/article/details/72717101
          outlineStroke: 'transparent',
          // Ancho del borde exterior de la línea, cuanto mayor sea el valor, mayor será el área de clic de la línea
          outlineWidth: 10
        },
        DragOptions: { cursor: 'pointer', zIndex: 2000 },
        /**
         *  叠加 参考： https://www.jianshu.com/p/d9e9918fd928
         */
        Overlays: [
          // 箭头叠加
          ['Arrow', {
            width: 10, // 箭头尾部的宽度
            length: 8, // 从箭头的尾部到头部的距离
            location: 1, // 位置，建议使用0～1之间
            direction: 1, // 方向，默认值为1（表示向前），可选-1（表示向后）
            foldback: 0.623 // 折回，也就是尾翼的角度，默认0.623，当为1时，为正三角
          }],
          // ['Diamond', {
          //     events: {
          //         dblclick: function (diamondOverlay, originalEvent) {
          //             console.log('double click on diamond overlay for : ' + diamondOverlay.component)
          //         }
          //     }
          // }],
          ['Label', {
            label: '',
            location: 0.1,
            cssClass: 'aLabel'
          }]
        ],
        // 绘制图的模式 svg、canvas
        RenderMode: 'svg',
        // Estilo al pasar el ratón sobre la línea
        HoverPaintStyle: { stroke: '#5c67f2', strokeWidth: 1 },
        // Efecto al pasar sobre puntos de anclaje
        // EndpointHoverStyle: {fill: 'red'}
        Scope: 'jsPlumb_DefaultScope' // Alcance, solo los puntos con el mismo scope pueden conectarse
      },
      /**
       * Parámetros de conexión
       */
      jsplumbConnectOptions: {
        isSource: true,
        isTarget: true,
        // Puntos de anclaje dinámicos, proporciona 4 direcciones: Continuous, AutoDefault
        anchor: 'Continuous',
        // Establecer estilo de etiqueta en la conexión
        labelStyle: {
          cssClass: 'flowLabel'
        },
        // Modificado el código fuente de jsplumb para admitir estilo personalizado cuando label está vacío
        emptyLabelStyle: {
          cssClass: 'emptyFlowLabel'
        }
      },
      /**
       * Parámetros de configuración del punto de origen
       */
      jsplumbSourceOptions: {
        // Establecer nombre de clase para arrastrar, cuando el ratón se mueve sobre el DOM con esta clase, se puede arrastrar la conexión
        filter: '.flow-node-drag',
        filterExclude: false,
        anchor: 'Continuous',
        // Permitir conexión consigo mismo
        allowLoopback: true,
        maxConnections: -1,
        onMaxConnections: function (info, e) {
          console.log(`Se excedió el número máximo de conexiones: ${info.maxConnections}`)
        }
      },
      // Referencia: https://www.cnblogs.com/mq0036/p/7942139.html
      jsplumbSourceOptions2: {
        // Establecer nombre de clase para arrastrar, cuando el ratón se mueve sobre el DOM con esta clase, se puede arrastrar la conexión
        filter: '.flow-node-drag',
        filterExclude: false,
        // anchor: 'Continuous',
        // Permitir conexión consigo mismo
        allowLoopback: true,
        connector: ['Flowchart', { curviness: 50 }],
        connectorStyle: {
          // Color de la línea
          stroke: 'red',
          // Grosor de la línea, cuanto mayor sea el valor, más gruesa será la línea
          strokeWidth: 1,
          // Establecer color del borde exterior, por defecto transparente para que no sea visible, al hacer clic en la línea no es necesario ser preciso, referencia: https://blog.csdn.net/roymno2/article/details/72717101
          outlineStroke: 'transparent',
          // Ancho del borde exterior de la línea, cuanto mayor sea el valor, mayor será el área de clic de la línea
          outlineWidth: 10
        },
        connectorHoverStyle: { stroke: 'red', strokeWidth: 2 }
      },
      jsplumbTargetOptions: {
        // Establecer nombre de clase para arrastrar, cuando el ratón se mueve sobre el DOM con esta clase, se puede arrastrar la conexión
        filter: '.flow-node-drag',
        filterExclude: false,
        // Permitir conexión consigo mismo
        anchor: 'Continuous',
        allowLoopback: true,
        dropOptions: { hoverClass: 'ef-drop-hover' }
      }
    }
  }
}
