import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  AutoIncrement
} from "sequelize-typescript";
import Contact from "./Contact";
import Kanban from "./Kanban"; // Assuming Kanban model exists
import Tenant from "./Tenant";

@Table
class KanbanOrder extends Model<KanbanOrder> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @ForeignKey(() => Contact)
  @Column
  contactId: number;

  @BelongsTo(() => Contact)
  contact: Contact;

  @ForeignKey(() => Kanban) // Assuming relation to Kanban model
  @Column
  kanbanId: number;

  @BelongsTo(() => Kanban) // Assuming relation to Kanban model
  kanban: Kanban;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default KanbanOrder;