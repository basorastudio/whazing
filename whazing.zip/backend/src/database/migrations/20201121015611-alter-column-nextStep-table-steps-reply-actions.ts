import { QueryInterface, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Renombra la columna 'nextStep' a 'nextStepId' en la tabla 'StepsReplyActions'
    return Promise.all([
      queryInterface.renameColumn("StepsReplyActions", "nextStep", "nextStepId")
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Renombra la columna 'nextStepId' de nuevo a 'nextStep'
    return Promise.all([
      queryInterface.renameColumn("StepsReplyActions", "nextStepId", "nextStep")
    ]);
  }
};
