<template>
  <div v-if="userProfile === 'admin'">
    <q-table
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      title="Notas"
      :data="anotacoes"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-note-edit-outline"/>
            Notas
          </h2>
          <q-input
            :class="{
              'order-last q-mt-md': $q.screen.width < 500
            }"
            class="contact-search"
            style="width: 300px"
            filled
            dense
            debounce="500"
            v-model="filter"
            clearable
            placeholder="Buscar"
            @input="filtrarAnotacoes"
          >
            <template v-slot:prepend>
              <q-icon name="search"/>
            </template>
          </q-input>
        </div>
      </template>
      <template v-slot:body-cell-ticketId="props">
        <q-td :props="props">
          <button
            class="q-mr-sm"
            @click.prevent="visualizarChat(props.row.ticketId)"
          >
            <i class="fa fa-comments"></i> {{ props.row.ticketId }}
          </button>
        </q-td>
      </template>
      <template v-slot:body-cell-note="props">
        <q-td :props="props" style="white-space: pre-wrap; word-wrap: break-word;">
          {{ props.row.note.length > 100 ? props.row.note.slice(0, 100) + '...' : props.row.note }}
          <q-btn
            v-if="props.row.note.length > 100"
            flat
            dense
            label="Ver mais"
            class="text-primary q-ml-sm"
            @click="abrirModalTextoCompleto(props.row.note)"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-contactId="props">
        <q-td :props="props">
          {{ props.row.contactName || 'Carregando...' }}
        </q-td>
      </template>
      <template v-slot:body-cell-userId="props">
        <q-td :props="props">
          {{ formatUser(props.row.userId) }}
        </q-td>
      </template>
      <template v-slot:body-cell-createdAt="props">
        <q-td :props="props">
          {{ formatDate(props.row.createdAt) }}
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td :props="props">
          <q-btn
            flat
            round
            icon="eva-trash-outline"
            @click="excluirAnotacao(props.row.id)"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
          />
        </q-td>
      </template>
      <template v-slot:pagination="{ pagination }">
        {{ anotacoes.length }}/{{ pagination.rowsNumber }}
      </template>
    </q-table>

    <q-dialog v-model="modalTextoCompleto">
      <q-card>
        <q-card-section>
          <div class="text-h6">Texto Completo</div>
        </q-card-section>
        <q-card-section style="white-space: pre-wrap; word-wrap: break-word;">
          <p>{{ textoCompleto }}</p>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="Cerrar" color="primary" @click="modalTextoCompleto = false" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- Modal de Chat -->
    <ChatModal v-if="mostrarModal" :ticketId="String(ticketIdAtual)" @close="fecharChatModal" />

  </div>
</template>

<script>
import { ListarNote, DeletarNote } from 'src/service/ticketnote'
import { ListarUsuarios } from 'src/service/user'
import { ObterContato } from 'src/service/contatos'
import { ListarCores } from 'src/service/configuracoesgeneral'
import ChatModal from 'src/pages/relatorios/ChatModal.vue'

export default {
  name: 'Anotacoes',
  components: {
    ChatModal
  },
  data() {
    return {
      userProfile: 'user',
      filter: null,
      contatosCache: {},
      usuarios: [],
      modalTextoCompleto: false,
      textoCompleto: '',
      mostrarModal: false,
      ticketIdAtual: null,
      anotacoes: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        searchParam: null,
        hasMore: true
      },
      loading: false,
      columns: [
        { name: 'ticketId', label: 'Ticket', field: 'ticketId', align: 'left' },
        { name: 'note', label: 'Nota', field: 'note', align: 'left' },
        { name: 'contactId', label: 'Contacto', field: 'contactId', align: 'center', format: (val) => this.formatContact(val), sortable: false },
        { name: 'userId', label: 'Usuario', field: 'userId', align: 'center', format: (val) => this.formatUser(val) },
        { name: 'createdAt', label: 'Fecha', field: 'createdAt', align: 'center', format: (val) => this.formatDate(val) },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    async listarUsuarios() {
      const data = await ListarUsuarios()
      this.usuarios = data.data.users
    },
    async listarAnotacoes() {
      this.loading = true
      try {
        const response = await ListarNote({
          searchParam: this.filter,
          pageNumber: this.params.pageNumber,
          tenantId: localStorage.getItem('tenantId')
        })

        if (response.data && Array.isArray(response.data.ticketNotes)) {
          this.anotacoes = [
            ...this.anotacoes,
            ...(await Promise.all(
              response.data.ticketNotes.map(async (protocolo) => {
                protocolo.contactName = await this.getContactName(protocolo.contactId)
                return protocolo
              })
            ))
          ]
          this.pagination.rowsNumber = response.data.count || 0
          this.pagination.hasMore = response.data.hasMore
        } else {
          console.error('Resposta da API não está no formato esperado:', response.data)
        }
      } catch (error) {
        console.error('Erro ao listar anotacoes:', error)
      } finally {
        this.loading = false
      }
    },
    abrirModalTextoCompleto(note) {
      this.textoCompleto = note
      this.modalTextoCompleto = true
    },
    async getContactName(contactId) {
      if (this.contatosCache[contactId]) {
        return this.contatosCache[contactId].name
      }
      try {
        const response = await ObterContato(contactId)
        const contact = response.data
        this.contatosCache[contactId] = contact
        return contact.name
      } catch (error) {
        console.error('Error al buscar contacto:', error)
        return 'Contacto no encontrado'
      }
    },
    formatUser(userId) {
      const user = this.usuarios.find(user => user.id === userId)
      return user ? user.name : 'Usuario no encontrado'
    },
    fecharChatModal () {
      this.mostrarModal = false
    },
    visualizarChat (ticketId) {
      this.ticketIdAtual = ticketId
      this.mostrarModal = true
    },
    async excluirAnotacao(id, index) {
      this.$q.dialog({
        title: '¡Atención!',
        message: '¿Realmente desea eliminar la nota?',
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        // Só executa a exclusão quando o usuario clicar em "Sim"
        this.loading = true

        DeletarNote({ id })
          .then(() => {
            // Remove a anotação da lista localmente após exclusão bem-sucedida
            this.anotacoes.splice(index, 1)

            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: 'Nota eliminada!',
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .catch((error) => {
            console.error('Erro ao excluir anotação:', error)

            this.$q.notify({
              type: 'negative',
              message: 'Error al eliminar la nota.'
            })
          })
          .finally(() => {
            this.loading = false // Para a loading state
          })
      })
    },
    formatDate(data) {
      return new Date(data).toLocaleString()
    },
    async filtrarAnotacoes() {
      this.params.pageNumber = 1
      this.params.hasMore = true // Garantir que há mais dados a serem carregados
      this.anotacoes = [] // Limpar anotacoes atuais para aplicar o novo filtro
      await this.listarAnotacoes()
    },
    onScroll({ to, ref, ...all }) {
      if (!this.loading && this.params.hasMore && to >= (this.anotacoes.length - 10)) {
        this.loading = true
        this.params.pageNumber++
        this.listarAnotacoes()
      }
    }
  },
  async mounted() {
    this.loadColors()
    await this.listarAnotacoes()
    await this.listarUsuarios()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass" >
.my-sticky-dynamic
  /* height or max-height is important */
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th /* bg color is important for th; just specify one */
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1
  /* this will be the loading indicator */
  thead tr:last-child th
    /* height of all previous header rows */
    top: 63px
  thead tr:first-child th
    top: 0

.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

#tabela-contatos-atendimento
  thead
    th
      height: 55px

.blur-effect
  filter: blur(0px)
</style>
