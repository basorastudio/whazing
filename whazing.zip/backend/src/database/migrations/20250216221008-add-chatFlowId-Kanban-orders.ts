import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'chatFlowId' column to the 'KanbanOrders' table as a foreign key
    await queryInterface.addColumn(
      'KanbanOrders', // Table name
      'chatFlowId',   // New column name
      {
        type: DataTypes.INTEGER,
        allowNull: true,      // Allow null
        defaultValue: null,
        references: {
          model: 'ChatFlow', // References ChatFlow table (assuming name)
          key: 'id',
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL', // Keep KanbanOrder if ChatFlow is deleted
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'chatFlowId' column from the 'KanbanOrders' table
    await queryInterface.removeColumn(
      'KanbanOrders', // Table name
      'chatFlowId'    // Column name to remove
    );
  }
};

export = migration;