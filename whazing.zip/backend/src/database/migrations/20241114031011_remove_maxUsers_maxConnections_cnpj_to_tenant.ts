import { QueryInterface, DataTypes } from "sequelize"; // Added DataTypes
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove columns 'maxUsers', 'maxConnections', 'cnpj' from 'Tenants' table
    await queryInterface.removeColumn("Tenants", "maxUsers");
    await queryInterface.removeColumn("Tenants", "maxConnections");
    await queryInterface.removeColumn("Tenants", "cnpj");
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Add back the removed columns to 'Tenants' table
    // Note: Data is lost in the 'up' migration. This 'down' only restores structure.
    await queryInterface.addColumn("Tenants", "maxUsers", {
      type: DataTypes.INTEGER,
      allowNull: true // Assuming original allowed null
    });
    await queryInterface.addColumn("Tenants", "maxConnections", {
      type: DataTypes.INTEGER,
      allowNull: true // Assuming original allowed null
    });
    await queryInterface.addColumn("Tenants", "cnpj", {
      type: DataTypes.STRING,
      allowNull: true // Assuming original allowed null
    });
  }
};

export = migration;
