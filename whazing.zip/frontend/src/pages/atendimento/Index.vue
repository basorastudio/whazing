<template>
  <div
    class="WAL position-relative bg-grey-3"
    :style="style"
  >
    <q-layout
      container
      view="lHr LpR lFr"
    >
      <q-drawer
        v-model="drawerTickets"
        @hide="drawerTickets = false"
        show-if-above
        :overlay="$q.screen.lt.md"
        persistent
        :breakpoint="769"
        bordered
        :width="$q.screen.lt.md ? $q.screen.width : 380"
        :content-class="`custom-scrollbar full-width ${$q.dark.isActive ? 'dark-scrollbar' : 'light-scrollbar'}`"
      >
        <q-toolbar class="q-pr-none menu-header menu-left q-gutter-xs full-width" style="height: 64px">
          <q-btn
            v-if="$q.screen.width < 500"
            flat
            class="chat-button-avatar" size="lg">
            <q-avatar size="sm">
              {{ $iniciaisString(username) }}
            </q-avatar>
            <q-menu>
              <q-list style="min-width: 100px">
                <q-item-label header> ¡Hola! <b> {{ username }} </b> </q-item-label>
                <cStatusUsuario @update:usuario="atualizarUsuario"
                  :usuario="usuario" />
                <q-item clickable
                  v-close-popup
                  @click="abrirModalUsuario">
                  <q-item-section>Perfil</q-item-section>
                </q-item>
                <q-item clickable
                  v-close-popup
                  @click="efetuarLogout">
                  <q-item-section>Salir</q-item-section>
                </q-item>
              </q-list>
            </q-menu>

            <q-tooltip>Usuario</q-tooltip>
          </q-btn>
          <q-space />

          <q-btn flat class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" :icon="isSilentMode ? 'volume_off' : 'volume_up'" @click="toggleSilentMode" :disable="loadingMount">
            <q-tooltip content-class="text-bold"> {{ isSilentMode ? 'Modo Silencioso Activado' : 'Modo Silencioso Desactivado' }} </q-tooltip>
          </q-btn>

          <q-btn flat class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" icon="eva-message-circle-outline" @click="() => $router.push({ name: 'chat-interno' })" :disable="loadingMount">
            <q-tooltip content-class="text-bold"> Chat Interno </q-tooltip>
            <q-badge v-if="this.notificacaoInternaNaoLida > 0"
              color="red"
              floating
              class="badge-left"
            > {{ this.notificacaoInternaNaoLida }}</q-badge>
          </q-btn>
          <q-btn flat class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" icon="mdi-clipboard-list-outline" @click="tarefaEdicao = {}; modalTarefa = true" :disable="loadingMount">
            <q-tooltip content-class="text-bold"> Crear Tarea </q-tooltip>
            <q-badge v-if="(delayed + venceHoje) > 0"
              color="red"
              floating
              class="badge-left"
              @click="() => $router.push({ name: 'tarefas' })"
            > {{ delayed + venceHoje }}</q-badge>
          </q-btn>
          <q-btn style="margin-right: 5px;" flat class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" icon="eva-undo-outline" @click="() => $router.push({ name: 'home-dashboard' })" :disable="loadingMount">
            <q-tooltip content-class="text-bold"> Volver al menú </q-tooltip>
          </q-btn>
        </q-toolbar>
        <q-linear-progress
          v-if="loadingMount"
          indeterminate
          color="primary"
          class="absolute-top"
          style="width: 100%;"
        />
        <StatusWhatsapp v-if="false" class="q-mx-sm full-width" />
        <q-toolbar v-show="toolbarSearch" class="menu-container column q-gutter-sm items-center full-width">
          <q-input v-model="pesquisaTickets.searchParam" dense outlined rounded type="search" class="full-width" :debounce="700" @input="BuscarTicketFiltro()" >
            <template v-slot:append>
              <q-icon name="search" />
            </template>
          </q-input>
          <div class="row-buttons full-width">
            <q-btn
              flat
              class="bg-grey-3"
              :class="cFiltroSelecionado
            ? ($q.dark.isActive ? 'btn-rounded-50-cor2-dark' : 'btn-rounded-50-cor2')
            : ($q.dark.isActive ? 'btn-rounded-50-cor1-dark' : 'btn-rounded-50-cor1')"
              :color="cFiltroSelecionado ? 'deep-orange-9' : 'cor1'"
              style="flex: 1;"
            >
            Filtro
            <q-menu content-class="shadow-10 no-scroll container-rounded-10 max-height-none" style="max-height: 100vh !important">
              <div class="row q-pa-sm" style="min-width: 350px; max-width: 350px">
                <div class="q-ma-sm">
                  <div class="text-h6 q-mb-md font-family-main">Filtros Avanzados</div>
                  <q-toggle
                    v-if="profile === 'admin'"
                    class="full-width"
                    v-model="pesquisaTickets.showAll"
                    label="(Admin) - Visualizar Todos Tickets"
                    :class="{ 'q-mb-lg': pesquisaTickets.showAll }"
                    @input="debounce(BuscarTicketFiltro(), 700)"
                  />
                  <div v-if="pesquisaTickets.showAll">
                    <q-select
                      :disable="!pesquisaTickets.showAll"
                      rounded
                      dense
                      outlined
                      hide-bottom-space
                      emit-value
                      map-options
                      multiple
                      options-dense
                      use-chips
                      label="Usuarios"
                      color="primary"
                      v-model="pesquisaTickets.useradmId"
                      :options="usuarios"
                      :input-debounce="700"
                      option-value="id"
                      option-label="name"
                      @input="debounce(BuscarTicketFiltro(), 700)"
                      input-style="width: 300px; max-width: 300px;"
                    />
                    <q-select
                      :disable="!pesquisaTickets.showAll"
                      rounded
                      dense
                      outlined
                      hide-bottom-space
                      emit-value
                      map-options
                      multiple
                      options-dense
                      use-chips
                      label="Canales"
                      color="primary"
                      v-model="pesquisaTickets.whatsappIds"
                      :options="whatsapps"
                      :input-debounce="700"
                      option-value="id"
                      option-label="name"
                      @input="debounce(BuscarTicketFiltro(), 700)"
                      input-style="width: 300px; max-width: 300px;"
                    />
                  </div>
                  <q-toggle v-if="!pesquisaTickets.showAll" v-model="ordenar" label="Ordenar por fecha de creación" />
                  <q-separator class="q-mb-md" v-if="!pesquisaTickets.showAll" />
                  <div>
                  <q-input v-model="pesquisaTickets.searchParamMessage" dense outlined rounded label="Buscar Mensajes" type="search" class="full-width" :debounce="700" @input="BuscarTicketFiltro()" >
                    <template v-slot:append>
                      <q-icon name="search" />
                    </template>
                  </q-input>
                  </div>
                  <div v-if="!pesquisaTickets.showAll">
                    <q-select
                      :disable="pesquisaTickets.showAll"
                      rounded
                      dense
                      outlined
                      hide-bottom-space
                      emit-value
                      map-options
                      multiple
                      options-dense
                      use-chips
                      label="Colas"
                      color="primary"
                      v-model="pesquisaTickets.queuesIds"
                      :options="cUserQueues"
                      :input-debounce="700"
                      option-value="id"
                      option-label="queue"
                      @input="debounce(BuscarTicketFiltro(), 700)"
                      input-style="width: 300px; max-width: 300px;"
                    />
                      <q-select
                        :disable="pesquisaTickets.showAll"
                        rounded
                        dense
                        outlined
                        hide-bottom-space
                        emit-value
                        map-options
                        multiple
                        options-dense
                        use-chips
                        label="Etiquetas"
                        color="primary"
                        v-model="pesquisaTickets.tagsIds"
                        :options="etiquetas"
                        :input-debounce="700"
                        option-value="id"
                        option-label="tag"
                        @input="debounce(BuscarTicketFiltro(), 700)"
                        input-style="width: 300px; max-width: 300px;"
                      />

                    <q-list dense class="q-my-md">
                      <q-item tag="label" v-ripple>
                        <q-item-section avatar>
                          <q-checkbox v-model="pesquisaTickets.status" val="open" color="primary" keep-color @input="debounce(BuscarTicketFiltro(), 700)" />
                        </q-item-section>
                        <q-item-section>
                          <q-item-label>Abiertos</q-item-label>
                        </q-item-section>
                      </q-item>
                      <q-item tag="label" v-ripple v-if="profile === 'admin'">
                        <q-item-section avatar>
                          <!-- <q-checkbox v-model="pesquisaTickets.showAll" color="negative" keep-color @input="debounce(BuscarTicketFiltro(), 700)" /> -->
                          <q-checkbox v-model="pesquisaTickets.status" val="pending" color="negative" keep-color @input="debounce(BuscarTicketFiltro(), 700)" />
                        </q-item-section>
                        <q-item-section>
                          <q-item-label>Pendientes</q-item-label>
                        </q-item-section>
                      </q-item>
                      <q-item tag="label" v-ripple v-if="profile !== 'admin'">
                        <q-item-section avatar>
                          <q-checkbox v-model="pesquisaTickets.status" val="pending" color="negative" keep-color @input="debounce(BuscarTicketFiltro(), 700)" />
                        </q-item-section>
                        <q-item-section>
                          <q-item-label>Pendientes</q-item-label>
                        </q-item-section>
                      </q-item>
                      <q-item tag="label" v-ripple>
                        <q-item-section avatar>
                          <q-checkbox v-model="pesquisaTickets.status" val="closed" color="positive" keep-color @input="debounce(BuscarTicketFiltro(), 700)" />
                        </q-item-section>
                        <q-item-section>
                          <q-item-label>Cerrados</q-item-label>
                        </q-item-section>
                      </q-item>
                    </q-list>
                    <q-separator class="q-mb-md" />
                    <q-toggle v-model="pesquisaTickets.withUnreadMessages" label="Solo Tickets con mensajes no leídos" @input="debounce(BuscarTicketFiltro(), 700)" />
                    <!-- <q-toggle v-model="pesquisaTickets.isNotAssignedUser" label="Solo Tickets no asignados (sin usuario definido)" @input="debounce(BuscarTicketFiltro(), 700)" /> -->
                  </div>
                  <q-separator class="q-my-md" spaced v-if="!pesquisaTickets.showAll" />
                  <q-btn class="float-right q-my-md" color="negative" label="Cerrar" push v-close-popup />
                </div>
              </div>
            </q-menu>
            <q-tooltip content-class="text-bold"> Filtro Avanzado </q-tooltip>
          </q-btn>
          <q-btn flat class="bg-grey-3 btn-rounded-50-cor1" :class="$q.dark.isActive ? ('bg-grey-3 btn-rounded-50-cor1-dark') : ''" @click="$q.screen.lt.md ? (modalNovoTicket = true) : $router.push({ name: 'chat-contatos' })" style="flex: 1;" v-if="canAccessPageContact">
            Contactos
          <q-tooltip :content-class="`${$q.dark.isActive ? 'text-white bg-black' : ''} text-bold`">Contactos</q-tooltip>
          </q-btn>
          <q-btn flat class="bg-grey-3 btn-rounded-50" :class="$q.dark.isActive ? 'color-dark3 bg-black' : ''" @click="showNotification()" v-if="hasMoreTickets"  style="flex: 1;">
            Atenciones
            <q-tooltip :content-class="`${$q.dark.isActive ? 'color-dark3 bg-black' : ''} text-bold`"> Cargar Más Atenciones </q-tooltip>
          </q-btn>
          </div>

        </q-toolbar>

        <q-toolbar class="padding-person menu-left items-center ">
          <q-separator class="absolute-top" />
          <div class="full-width">

            <q-tabs
              v-model="tabTickets"
              narrow-indicator
              dense
              :active-bg-color="$q.dark.isActive ? 'primary' : 'grey-3'"
              inline-label
              align="justify"
              :class="{
                'color-dark3': $q.dark.isActive,
                'text-black': !$q.dark.isActive
              }"

              class="btn-rounded"

            >
            <q-tab
              :ripple="false"
              name="private"
              class="btn-rounded-50-cor1"
              :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              icon="eva-person-outline"
            >

              <q-badge
                v-if="grupoAtivo === 'disabled' && openTickets.some(ticket => ticket.unreadMessages > 0)"
                color="red"
                floating
                class="badge-left"
              >
                {{
                  openTickets.filter(ticket => ticket.unreadMessages > 0).length
                }}
              </q-badge>
              <q-tooltip content-class="text-bold"> Conversaciones Privadas </q-tooltip>

            </q-tab>
            <q-tab
              v-if="grupoAtivo === 'disabled'"
              :ripple="false"
              name="groups"
              class="btn-rounded-50-cor1"
              :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              icon="eva-people-outline"
            >
              <q-badge
                v-if="openGroupTickets.some(ticket => ticket.unreadMessages > 0)"
                color="red"
                floating
                class="badge-left"
              >
                {{
                  openGroupTickets.filter(ticket => ticket.unreadMessages > 0).length
                }}
              </q-badge>
            <q-tooltip content-class="text-bold"> Conversaciones en Grupo </q-tooltip>
            </q-tab>

          <q-btn
            class="btn-rounded-50-cor1"
            :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
            icon="mdi-book-account-outline"
            @click="loadMoreOpenTickets" :disable="loadingMount">
            <q-tooltip content-class="text-bold"> Cargar Más Tickets </q-tooltip>
          </q-btn>

            </q-tabs>
          </div>
        </q-toolbar>

        <q-toolbar
          v-show="tabTickets === 'private'"
          class="items-center"
        >
          <div class="full-width q-py-xs">
            <q-tabs
              v-model="tabTicketsStatus"
              narrow-indicator
              dense
              align="justify"
              :active-bg-color="$q.dark.isActive ? 'primary' : 'grey-2'"
              class="text-primary btn-rounded"
            >
              <q-tab
                v-if="!hidetab || (hidetab && openTickets.length > 0)"
                :ripple="false"
                name="open"
                icon="eva-message-circle-outline"
                label="Abiertos"
                class="btn-rounded-50-cor1"
                :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              >
                <q-badge
                  :color="openTickets.filter(ticket => ticket.unreadMessages > 0).length > 0 ? 'red' : 'color-light2'"
                  floating
                  class="badge-left"
                >
                  {{
                    openTickets.filter(ticket => ticket.unreadMessages > 0).length > 0
                      ? openTickets.filter(ticket => ticket.unreadMessages > 0).length
                      : openTickets.length
                  }}
                </q-badge>
                <q-tooltip content-class="text-bold"> Tickets en atención </q-tooltip>
              </q-tab>
              <q-tab
                v-if="!hidetab || (hidetab && pendingTickets.length > 0)"
                :ripple="false"
                name="pending"
                icon="eva-clock-outline"
                label="Pendientes"
                class="btn-rounded-50-cor1"
                :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              >
                <q-badge
                  color="color-light2"
                  floating
                  class="badge-left"
                > {{ pendingTickets.length }}</q-badge>
                <q-tooltip content-class="text-bold"> Tickets pendientes </q-tooltip>
              </q-tab>
              <q-tab
                v-if="!hidetab || (hidetab && closedTickets.length > 0)"
                :ripple="false"
                name="closed"
                icon="eva-lock-outline"
                label="Cerrados"
                class="btn-rounded-50-cor1"
                :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              >
                <q-badge
                  color="color-light2"
                  floating
                  class="badge-left"
                > {{ closedTickets.length }}</q-badge>
                <q-tooltip content-class="text-bold"> Tickets cerrados </q-tooltip>
              </q-tab>
              <q-tab
                v-if="chatbotLane === 'enabled' && (!hidetab || (hidetab && pendingTicketsChatBot.length > 0))"
                :ripple="false"
                name="chatbot"
                icon="mdi-robot-outline"
                label="Chatbot"
                class="btn-rounded-50-cor1"
                :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              >
                <q-badge
                  color="color-light2"
                  floating
                  class="badge-left"
                > {{ pendingTicketsChatBot.length }}</q-badge>
                <q-tooltip content-class="text-bold"> Chatbot </q-tooltip>
              </q-tab>
            </q-tabs>
          </div>
        </q-toolbar>

        <q-toolbar
          v-show="tabTickets === 'groups'"
          class="items-center"
        >
          <div class="full-width q-py-xs">
            <q-tabs
              v-model="tabTicketsStatus"
              narrow-indicator
              dense
              align="justify"
              :active-bg-color="$q.dark.isActive ? 'primary' : 'grey-2'"
              class="text-primary btn-rounded"
            >
              <q-tab
                v-if="!hidetab || (hidetab && openGroupTickets.length > 0)"
                :ripple="false"
                name="open"
                icon="eva-message-circle-outline"
                label="Abiertos"
                class="btn-rounded-50-cor1"
                :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              >
                <q-badge
                  :color="openGroupTickets.filter(ticket => ticket.unreadMessages > 0).length > 0 ? 'red' : 'color-light2'"
                  floating
                  class="badge-left"
                >
                  {{
                    openGroupTickets.filter(ticket => ticket.unreadMessages > 0).length > 0
                      ? openGroupTickets.filter(ticket => ticket.unreadMessages > 0).length
                      : openGroupTickets.length
                  }}
                </q-badge>
                <q-tooltip content-class="text-bold"> Conversaciones Abiertas </q-tooltip>
              </q-tab>
              <q-tab
                v-if="!hidetab || (hidetab && pendingGroupTickets.length > 0)"
                :ripple="false"
                name="pending"
                icon="eva-clock-outline"
                label="Pendientes"
                class="btn-rounded-50-cor1"
                :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              >
                <q-badge
                  color="color-light2"
                  floating
                  class="badge-left"
                > {{ pendingGroupTickets.length }}</q-badge>
                <q-tooltip content-class="text-bold"> Conversaciones Pendientes </q-tooltip>
              </q-tab>
              <q-tab
                v-if="!hidetab || (hidetab && closedGroupTickets.length > 0)"
                :ripple="false"
                name="closed"
                icon="eva-lock-outline"
                label="Cerrados"
                class="btn-rounded-50-cor1"
                :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"
              >
                <q-badge
                  color="color-light2"
                  floating
                  class="badge-left"
                > {{ closedGroupTickets.length }}</q-badge>
                <q-tooltip content-class="text-bold"> Conversaciones Cerradas </q-tooltip>
              </q-tab>
            </q-tabs>
          </div>
        </q-toolbar>

        <ItemTicket
          v-show="tabTickets === 'private' && tabTicketsStatus === 'open'"
          v-for="ticket in openTickets"
          :key="ticket.id"
          :ticket="ticket"
          :filas="filas"
        />

        <ItemTicket
          v-show="tabTickets === 'private' && tabTicketsStatus === 'pending'"
          v-for="ticket in pendingTickets"
          :key="ticket.id"
          :ticket="ticket"
          :filas="filas"
        />

        <ItemTicket
          v-show="tabTickets === 'private' && tabTicketsStatus === 'chatbot'"
          v-for="ticket in pendingTicketsChatBot"
          :key="ticket.id+'bot'"
          :ticket="ticket"
          :filas="filas"
        />

        <ItemTicket
          v-show="tabTickets === 'private' && tabTicketsStatus === 'closed'"
          v-for="ticket in closedTickets"
          :key="ticket.id"
          :ticket="ticket"
          :filas="filas"
        />

        <ItemTicket
        v-show="tabTickets === 'groups' && tabTicketsStatus === 'open'"
          v-for="ticket in openGroupTickets"
          :key="ticket.id"
          :ticket="ticket"
          :filas="filas"
        />

        <ItemTicket
        v-show="tabTickets === 'groups' && tabTicketsStatus === 'pending'"
          v-for="ticket in pendingGroupTickets"
          :key="ticket.id"
          :ticket="ticket"
          :filas="filas"
        />

        <ItemTicket
        v-show="tabTickets === 'groups' && tabTicketsStatus === 'closed'"
          v-for="ticket in closedGroupTickets"
          :key="ticket.id"
          :ticket="ticket"
          :filas="filas"
        />

        <div class="absolute-bottom row justify-between" style="height: 50px" v-if="ExibirConexao === 'enabled'">
          <div class="flex flex-inline q-pt-xs">
            <q-scroll-area horizontal style="height: 40px; width: 300px">
              <template v-for="item in whatsapps">
                <q-btn rounded flat dense size="18px" :key="item.id" class="q-mx-xs q-pa-none" :style="`opacity: ${item.status === 'CONNECTED' ? 1 : 0.2}`" :icon="`img:${item.type}-logo.png`">
                  <q-tooltip max-height="300px" content-class="bg-blue-1 text-white hide-scrollbar">
                    <ItemStatusChannel :item="item" />
                  </q-tooltip>
                </q-btn>
              </template>
            </q-scroll-area>
          </div>
        </div>

      </q-drawer>

      <q-page-container>
        <router-view :mensagensRapidas="mensagensRapidas" :key="ticketFocado.id"></router-view>
      </q-page-container>

      <q-drawer
        v-if="!cRouteContatos && ticketFocado.id"
        v-model="drawerContact"
        persistent
        bordered
        side="right"
        class="dados-contato"
        content-class="bg-grey-3"
      >
    <div class="flex justify-start items-end bg-white full-width no-border-radius q-pa-sm" style="height: 60px">
        <span class=" text-h6">
            <q-btn flat class="btn-small color-light1" :class="$q.dark.isActive ? ('btn-small color-dark1') : ''" @click="toggleDrawer" label="" icon="mdi-close" />
            Datos de Contacto
        </span>
    </div>

        <q-scroll-area style="height: calc(100vh - 70px)">
          <div>
            <q-card class="bg-white border-radius-none q-mt-sm" style="width: 100%" flat>
              <q-card-section class="text-center">
                <q-avatar style="border: 1px solid #9e9e9ea1 !important; width: 100px; height: 100px">
                  <q-icon name="mdi-account" style="width: 100px; height: 100px" size="6em" color="grey-5" v-if="!ticketFocado.contact.profilePicUrl" />
                  <q-img :src="ticketFocado.contact.profilePicUrl" style="width: 100px; height: 100px">
                    <template v-slot:error>
                      <q-icon name="mdi-account" size="1.5em" :color="$q.dark.isActive ? ('color-dark3') : 'grey-5'" />
                    </template>
                  </q-img>
                </q-avatar>
                <div class="text-caption q-mt-md blur-effect"  style="font-size: 14px">
                  {{ ticketFocado.contact.name || '' }}
                </div>
                <div class="text-caption q-mt-sm blur-effect"  style="font-size: 14px" id="number">
                  <template v-if="ticketFocado.contact.number">
                    <a :class="$q.dark.isActive ? ('color-dark3') : ''" :href="getPhoneNumberLink(ticketFocado.contact.number)">
                      {{ formatId(ticketFocado.contact.number) }}
                    </a>
                  </template>
                </div>
                <div class="text-caption q-mt-md" style="font-size: 14px" id="email">
                  <template v-if="ticketFocado.contact.email">
                    <a :href="'mailto:' + ticketFocado.contact.email">{{ ticketFocado.contact.email }}</a>
                  </template>
                  <template v-else>
                    {{ ticketFocado.contact.email || '' }}
                  </template>
                </div>
                <div class="text-caption q-mt-md blur-effect"  style="font-size: 14px" v-if="ticketFocado.contact.kanbanPrice">
                  {{`$ ${formatKanbanPrice(ticketFocado.contact.kanbanPrice)}`}}
                </div>

                <q-btn flat class="btn-rounded-50-cor1 btn-outline btn-small" icon="eva-edit-outline" label="Editar" @click="editContact(ticketFocado.contact.id)" :class="$q.dark.isActive ? ('btn-rounded-50-cor1-dark') : ''"/>
                <template v-if="cIsExtraInfo">
                  <q-list>
                    <q-item v-for="(info, idx) in ticketFocado.contact.extraInfo" :key="idx">
                      <q-item-section>
                        <q-item-label>{{ info.name }}</q-item-label>
                        <q-item-label>{{ info.value }}</q-item-label>
                        <q-separator inset></q-separator>
                      </q-item-section>
                    </q-item>
                  </q-list>
                </template>
              </q-card-section>
            </q-card>
            <q-card class="bg-white border-radius-none q-mt-sm" style="width: 100%" flat>
              <q-card-section class="text-bold text-center q-pa-sm">
                <q-btn flat icon="fa-comments" class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" @click="visualizarChat(ticketFocado.id)">
                  <q-tooltip content-class="bg-primary text-bold">
                    Mostrar Chat Completo
                  </q-tooltip>
                </q-btn>
                <q-btn flat icon="mdi-file-pdf-box" class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" @click="downloadPDF">
                  <q-tooltip content-class="bg-primary text-bold">
                    Descargar PDF de mensajes del ticket activo
                  </q-tooltip>
                </q-btn>
                <q-btn flat icon="mdi-timeline-text-outline" class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" @click="abrirModalLogs">
                  <q-tooltip content-class="bg-primary text-bold">
                    Logs
                  </q-tooltip>
                </q-btn>
                <q-btn v-if="this.userProfile === 'admin'" flat  icon="mdi-delete" class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" @click="deleteTicket(ticketFocado.id)">
                  <q-tooltip content-class="bg-primary text-bold">
                    Eliminar Ticket
                  </q-tooltip>
                </q-btn>
              </q-card-section>
            </q-card>

            <q-card class="bg-white q-mt-sm border-radius-none q-pa-sm" style="width: 100%" flat :key="ticketFocado.id + $uuid()">
              <q-card-section class="text-bold q-pb-none" :class="$q.dark.isActive ? ('color-dark3') : ''">
                Etiquetas
                <q-separator />
              </q-card-section>
              <q-card-section class="q-pa-none" :class="$q.dark.isActive ? ('color-dark3') : ''">
                <q-select
                  square
                  borderless
                  :value="ticketFocado.contact.tags"
                  multiple
                  :options="etiquetas"
                  use-chips
                  option-value="id"
                  option-label="tag"
                  emit-value
                  map-options
                  dropdown-icon="add"
                  @input="tagSelecionada"
                  :content-class="$q.dark.isActive ? ('color-dark3') : ''"
                >
                  <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                    <q-item v-bind="itemProps" v-on="itemEvents">
                      <q-item-section>
                        <q-item-label v-html="opt.tag"></q-item-label>
                      </q-item-section>
                      <q-item-section side>
                        <q-checkbox :value="selected" @input="toggleOption(opt)" />
                      </q-item-section>
                    </q-item>
                  </template>
                  <template v-slot:selected-item="{ opt }">
                    <q-chip dense square color="white" text-color="primary" class="q-ma-xs row col-12 text-body1">
                      <q-icon :style="`color: ${opt.color}`" name="mdi-pound-box-outline" size="28px" class="q-mr-sm" />
                      {{ opt.tag }}
                    </q-chip>
                  </template>
                  <template v-slot:no-option="{ itemProps, itemEvents }">
                    <q-item v-bind="itemProps" v-on="itemEvents">
                      <q-item-section>
                        <q-item-label class="text-negative text-bold"> ¡Ops... No hay etiquetas creadas! </q-item-label>
                        <q-item-label caption> Registre nuevas etiquetas en la administración de sistemas. </q-item-label>
                      </q-item-section>
                    </q-item>
                  </template>
                </q-select>
              </q-card-section>
            </q-card>

            <q-card class="bg-white q-mt-sm border-radius-none q-pa-sm" style="width: 100%" flat :key="ticketFocado.id + $uuid()">
              <q-card-section class="text-bold q-pb-none" :class="$q.dark.isActive ? ('color-dark3') : ''">
                CRM
                <q-separator />
              </q-card-section>
              <q-card-section class="q-pa-none" :class="$q.dark.isActive ? ('color-dark3') : ''">
                <q-select
                  square
                  borderless
                  v-model="ticketFocado.contact.kanbanId"
                  :options="kanbans"
                  use-chips
                  option-value="id"
                  option-label="name"
                  emit-value
                  map-options
                  dropdown-icon="add"
                  @input="(newKanbanId) => updateKanban(newKanbanId, ticketFocado.contact.id)"
                  :content-class="$q.dark.isActive ? ('color-dark3') : ''"
                >
                  <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                    <q-item v-bind="itemProps" v-on="itemEvents">
                      <q-item-section avatar>
                        <!-- Muestra el color asociado al kanban -->
                        <div
                          :style="{ backgroundColor: opt.color, width: '24px', height: '24px', borderRadius: '50%' }"
                          title="Color asociado"
                        ></div>
                      </q-item-section>
                      <q-item-section>
                        <q-item-label v-html="opt.name"></q-item-label>
                      </q-item-section>
                      <q-item-section side>
                        <q-checkbox :value="selected" @input="toggleOption(opt)" />
                      </q-item-section>
                    </q-item>
                  </template>

                  <!-- Plantillas para el chip (opción seleccionada) -->
                  <template v-slot:selected-item="{ opt }">
                    <div class="row items-center">
                      <!-- Color al lado del nombre en el chip -->
                      <div
                        :style="{ backgroundColor: opt.color, width: '16px', height: '16px', borderRadius: '50%', marginRight: '8px' }"
                      ></div>
                      <span class="text-body1">{{ opt.name }}</span>
                      <!-- Botón para desmarcar -->
                      <q-icon
                        name="close"
                        size="sm"
                        class="q-ml-xs cursor-pointer text-negative"
                        @click.stop="clearKanban(ticketFocado.contact.id)"
                      />
                    </div>
                  </template>
                </q-select>
              </q-card-section>
            </q-card>

            <q-card
              class="bg-white q-mt-sm border-radius-none q-pa-sm"
              style="width: 100%"
              flat
              :key="ticketFocado.id + $uuid()"
            >
              <!-- Cabecera con el botón de añadir anotación -->
              <q-card-section
                class="text-bold q-pb-none flex items-center justify-between"
                :class="$q.dark.isActive ? ('color-dark3') : ''"
              >
                <span>Anotaciones</span>
                <q-btn
                  round
                  flat
                  dense
                  icon="mdi-note-edit-outline"
                  class="color-light1"
                  :class="$q.dark.isActive ? ('color-dark1') : ''"
                  @click="abrirModalNote">
                <q-tooltip content-class="bg-primary text-bold">
                  Añadir anotación al ticket
                </q-tooltip>
                </q-btn>
                <q-separator />
              </q-card-section>

              <!-- Listado de anotaciones -->
              <q-card-section
                align="center"
                class="q-pa-none"
                :class="$q.dark.isActive ? ('color-dark3') : ''"
              >
                <div class="q-mt-sm">
                  <div v-if="anotacoes.length > 0" class="q-mt-sm">
                    <q-list>
                      <q-item
                        v-for="(anotacao, index) in anotacoes"
                        :key="index"
                        class="q-mb-sm"
                      >
                        <q-item-section>
                          <!-- Limita el texto a 100 caracteres y añade "..." si el texto es mayor -->
                          <q-item-label
                            class="text-caption"
                            style="white-space: pre-wrap; word-wrap: break-word;"
                          >
                            {{ anotacao.note.length > 100 ? anotacao.note.slice(0, 100) + '...' : anotacao.note }}
                            <q-btn
                              v-if="anotacao.note.length > 100"
                              flat
                              dense
                              label="Ver más"
                              class="text-primary q-ml-sm"
                              @click="abrirModalTextoCompleto(anotacao.note)"
                            />
                          </q-item-label>
                          <q-item-label caption class="text-caption">
                            Por: {{ anotacao.user.name }}
                          </q-item-label>
                          <q-item-label caption class="text-caption">
                            Creado en: {{ formatarData(anotacao.createdAt) }}
                          </q-item-label>
                        </q-item-section>

                        <!-- Botón eliminar (visible solo para admin) -->
                        <q-item-section side v-if="userProfile === 'admin'">
                          <q-btn
                            flat
                            dense
                            icon="mdi-delete"
                            @click="excluirAnotacao(anotacao.id, index)"
                            class="color-light1"
                            :class="$q.dark.isActive ? ('color-dark1') : ''"
                            title="Eliminar anotación"
                          />
                        </q-item-section>
                      </q-item>
                    </q-list>
                  </div>
                  <p v-else class="text-caption">No hay anotaciones registradas.</p>
                </div>
              </q-card-section>
            </q-card>

            <q-card class="bg-white q-mt-sm border-radius-none q-pa-sm" style="width: 100%" flat :key="ticketFocado.id + $uuid()">
              <q-card-section class="text-bold q-pb-none" :class="$q.dark.isActive ? ('color-dark3') : ''">
                Cartera
                <q-separator />
              </q-card-section>
              <q-card-section class="q-pa-none">
                <q-select
                  square
                  borderless
                  :value="ticketFocado.contact.wallets"
                  multiple
                  :max-values="1"
                  :options="usuarios"
                  use-chips
                  option-value="id"
                  option-label="name"
                  emit-value
                  map-options
                  dropdown-icon="add"
                  @input="carteiraDefinida"
                >
                  <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                    <q-item v-bind="itemProps" v-on="itemEvents">
                      <q-item-section>
                        <q-item-label v-html="opt.name"></q-item-label>
                      </q-item-section>
                      <q-item-section side>
                        <q-checkbox :value="selected" @input="toggleOption(opt)" />
                      </q-item-section>
                    </q-item>
                  </template>
                  <template v-slot:selected-item="{ opt }">
                    <q-chip dense square color="white" text-color="primary" class="q-ma-xs row col-12 text-body1">
                      {{ opt.name }}
                    </q-chip>
                  </template>
                  <template v-slot:no-option="{ itemProps, itemEvents }">
                    <q-item v-bind="itemProps" v-on="itemEvents">
                      <q-item-section>
                        <q-item-label class="text-negative text-bold"> ¡Ops... No hay carteras disponibles!! </q-item-label>
                      </q-item-section>
                    </q-item>
                  </template>
                </q-select>
              </q-card-section>
            </q-card>

          </div>
        </q-scroll-area>
      </q-drawer>

      <ModalNovoTicket :modalNovoTicket.sync="modalNovoTicket" />
      <ContatoModal
        :contactId="selectedContactId"
        :modalContato.sync="modalContato"
        @contatoModal:contato-editado="contatoEditado"
      />
      <ModalTarefa
        :modalTarefa.sync="modalTarefa"
      />

      <ModalUsuario
        :isProfile="true"
        :modalUsuario.sync="modalUsuario"
        :usuarioEdicao.sync="usuario"
      />

      <q-dialog v-model="exibirModalLogs" no-backdrop-dismiss full-height position="right" @hide="logsTicket = []">
        <q-card style="width: 400px">
          <q-card-section :class="{ 'bg-grey-2': !$q.dark.isActive, 'bg-primary': $q.dark.isActive }">
            <div class="text-h6">
              Logs Ticket: {{ ticketFocado.id }}
              <q-btn icon="close" color="negative" flat class="bg-padrao float-right" round v-close-popup />
            </div>
          </q-card-section>
          <q-card-section class="">
            <q-scroll-area style="height: calc(100vh - 200px)" class="full-width">
              <q-timeline color="black" style="width: 360px" class="q-pl-sm" :class="{ 'text-black': !$q.dark.isActive }">
                <template v-for="(log, idx) in logsTicket">
                    <q-timeline-entry
                      :key="(log && log.id) || idx"
                      :subtitle="$formatarData(log.createdAt, 'dd/MM/yyyy HH:mm')"
                      :color="(messagesLog[log.type] && messagesLog[log.type].color) || ''"
                      :icon="(messagesLog[log.type] && messagesLog[log.type].icon) || ''"
                    >
                      <template v-slot:title>
                        <div :class="{ 'color-dark3': $q.dark.isActive }" style="width: calc(100% - 20px)">
                          <div class="row col text-bold text-body2">{{ (log.user && log.user.name) || 'Bot' }}:</div>
                          <div class="row col">{{ messagesLog[log.type] && messagesLog[log.type].message }}</div>
                        </div>
                      </template>
                    </q-timeline-entry>
                </template>
              </q-timeline>
            </q-scroll-area>
          </q-card-section>
        </q-card>
      </q-dialog>

      <!-- Modal de creación de anotación -->
      <q-dialog v-model="mostrarModalNote">
        <q-card class="q-pa-lg modal-container container-rounded-10">
          <q-card-section>
            <div class="text-h6">Nueva Anotación</div>
          </q-card-section>
          <q-card-section>
            <textarea
              style="min-height: 15vh; max-height: 15vh;"
              class="q-pa-sm bg-white full-width"
              placeholder="Anotación"
              v-model="novaAnotacao.note"
              autogrow
              dense
              outlined
            />
          </q-card-section>
          <q-card-actions align="right">
            <q-btn label="Cancelar" color="negative" @click="fecharModalNote" />
            <q-btn label="Guardar" color="primary" @click="salvarAnotacao" />
          </q-card-actions>
        </q-card>
      </q-dialog>

      <q-dialog v-model="modalTextoCompleto">
        <q-card>
          <q-card-section>
            <div class="text-h6">Texto Completo</div>
          </q-card-section>
          <q-card-section style="white-space: pre-wrap; word-wrap: break-word;">
            <p>{{ textoCompleto }}</p>
          </q-card-section>
          <q-card-actions align="right">
            <q-btn flat label="Cerrar" color="primary" @click="modalTextoCompleto = false" />
          </q-card-actions>
        </q-card>
      </q-dialog>

      <ChatModal v-if="mostrarModalChat" :ticketId="String(ticketIdAtual)" @close="fecharChatModal" />

      <audio ref="audioNotification">
        <source :src="currentAlertSound" type="audio/mp3">
      </audio>

    </q-layout>
  </div>
</template>

<script>
import ChatModal from 'src/pages/relatorios/ChatModal.vue'
import ContatoModal from 'src/pages/contatos/ContatoModal'
import ItemStatusChannel from 'src/pages/sessaoWhatsapp/ItemStatusChannel.vue'
import ItemTicket from './ItemTicket'
import { ConsultarLogsTicket, ConsultarTickets, DeletarMensagem, DeletarTicket, LocalizarMensagensPDF } from 'src/service/tickets'
import { mapGetters } from 'vuex'
import mixinSockets from './mixinSockets'
import ModalNovoTicket from './ModalNovoTicket'
import { ListarFilas } from 'src/service/filas'
import { ConsultarResumoTarefas } from 'src/service/tarefas'
const UserQueues = JSON.parse(localStorage.getItem('queues'))
const profile = localStorage.getItem('profile')
const username = localStorage.getItem('username')
const usuario = JSON.parse(localStorage.getItem('usuario'))
import StatusWhatsapp from 'src/components/StatusWhatsapp'
import { ListarWhatsapps } from 'src/service/sessoesWhatsapp'
import { debounce } from 'quasar'
import { format } from 'date-fns'
import ModalUsuario from 'src/pages/usuarios/usuarios/ModalUsuario'
import { ListarConfiguracoes } from 'src/service/configuracoes'
import { ListarMensagensRapidas } from 'src/service/mensagensRapidas'
import { ListarEtiquetas } from 'src/service/etiquetas'
import { EditarEtiquetasContato, EditarCarteiraContato } from 'src/service/contatos'
import { ListarKanbans, AlterarContactKanban2 } from 'src/service/kanban'
import { CriarNote, ListarNotesTickets, DeletarNote } from 'src/service/ticketnote'
import { RealizarLogout } from 'src/service/login'
import { ListarUsuarios, DadosUsuario } from 'src/service/user'
import { ListarCores } from 'src/service/configuracoesgeneral'
import { messagesLog } from '../../utils/constants'
import { listCountUnreadMessage, listCountUnreadMessageGroup } from 'src/service/chatInterno'
import ModalTarefa from 'src/pages/tarefas/ModalTarefa'
import formatSerializedId from 'src/utils/phoneFormatter'
import { jsPDF } from 'jspdf'
import alertSound from 'src/assets/sound.mp3'
import silenceSound from 'src/assets/silence.mp3'
import alertInterno from 'assets/chatInterno.mp3'

export default {
  name: 'IndexAtendimento',
  mixins: [mixinSockets],
  components: {
    ChatModal,
    ItemTicket,
    ModalNovoTicket,
    StatusWhatsapp,
    ContatoModal,
    ModalUsuario,
    ModalTarefa,
    ItemStatusChannel
  },
  data () {
    return {
      mostrarModalNote: false,
      novaAnotacao: {
        note: ''
      },
      modalTextoCompleto: false,
      textoCompleto: '',
      delayed: 0,
      venceHoje: 0,
      userProfile: 'user',
      tarefaEdicao: {},
      modalTarefa: false,
      tabTickets: 'private',
      tabTicketsStatus: 'open',
      messagesLog,
      alertSound,
      alertInterno,
      silenceSound,
      isSilentMode: false,
      configuracoes: [],
      debounce,
      usuario,
      usuarios: [],
      selectedTab: 'open',
      username,
      modalUsuario: false,
      toolbarSearch: true,
      drawerTickets: true,
      loading: false,
      profile,
      modalNovoTicket: false,
      modalContato: false,
      selectedContactId: null,
      filterBusca: '',
      showDialog: false,
      atendimentos: [],
      countTickets: 0,
      ExibirConexao: null,
      pesquisaTickets: {
        searchParam: '',
        searchParamMessage: '',
        pageNumber: 1,
        status: ['open', 'pending', 'closed'],
        showAll: false,
        count: null,
        queuesIds: [],
        tagsIds: [],
        withUnreadMessages: false,
        isNotAssignedUser: false,
        includeNotQueueDefined: true,
        useradmId: [],
        whatsappIds: []
        // date: new Date(),
      },
      ordenar: false,
      filter: false,
      filas: [],
      filasUser: [],
      etiquetas: [],
      kanbans: [],
      anotacoes: [],
      mensagensRapidas: [],
      modalEtiquestas: false,
      exibirModalLogs: false,
      logsTicket: [],
      notificacaoInternaNaoLida: '',
      drawerContact: false,
      ContactAdmin: null,
      chatbotLane: null,
      spyticket: null,
      hidetab: null,
      pageNumber: 1,
      hasMore: true,
      mostrarModalChat: false
    }
  },
  computed: {
    currentAlertSound() {
      return this.isSilentMode ? this.silenceSound : this.alertSound
    },
    canAccessPageContact() {
      return this.ContactAdmin !== 'enabled' || this.userProfile === 'admin'
    },
    ...mapGetters([
      'tickets',
      'ticketFocado',
      'hasMore',
      'whatsapps',
      'notificacoesChat',
      'notificacaoChatInterno'
    ]),
    cUserQueues () {
      return UserQueues
    },
    style () {
      return {
        height: (this.$q.screen.height - 8) + 'px'
      }
    },
    cToolbarSearchHeigthAjust () {
      return this.toolbarSearch ? 58 : 0
    },
    cHeigVerticalTabs () {
      return `${50 + this.cToolbarSearchHeigthAjust}px`
    },
    cRouteContatos () {
      return this.$route.name === 'chat-contatos'
    },
    cFiltroSelecionado () {
      const { tagsIds, queuesIds, showAll, withUnreadMessages, isNotAssignedUser } = this.pesquisaTickets
      return !!(tagsIds?.length, queuesIds?.length || showAll || withUnreadMessages || isNotAssignedUser)
    },
    cIsExtraInfo () {
      return this.ticketFocado?.contact?.extraInfo?.length > 0
    },
    openTickets() {
      let filteredTickets = this.tickets.filter(ticket => ticket.status === 'open' && !ticket.isGroup)
      filteredTickets = this.ordenar ? this.sortTicketsAscending(filteredTickets) : this.sortTicketsDescending(filteredTickets)
      return Object.values(this.groupTickets(filteredTickets))
    },
    pendingTickets() {
      let filteredTickets = this.tickets.filter(ticket => ticket.status === 'pending' && !ticket.isGroup)
      filteredTickets = this.ordenar ? this.sortTicketsAscending(filteredTickets) : this.sortTicketsDescending(filteredTickets)
      return Object.values(this.groupTickets(filteredTickets))
    },
    pendingTicketsChatBot() {
      let filteredTickets = this.tickets.filter(ticket =>
        ticket.status === 'pending' &&
      !ticket.isGroup &&
      ((ticket.stepAutoReplyId && ticket.autoReplyId) || (ticket.chatFlowId && ticket.stepChatFlow))
      )
      filteredTickets = this.ordenar ? this.sortTicketsAscending(filteredTickets) : this.sortTicketsDescending(filteredTickets)
      return Object.values(this.groupTickets(filteredTickets))
    },
    closedTickets() {
      let tickets = this.tickets.filter(ticket => ticket.status === 'closed' && !ticket.isGroup)
      tickets = this.ordenar ? this.sortTicketsAscending(tickets) : this.sortTicketsDescending(tickets)
      return tickets
    },
    closedGroupTickets() {
      let tickets = this.tickets.filter(ticket => ticket.status === 'closed' && ticket.isGroup)
      tickets = this.ordenar ? this.sortTicketsAscending(tickets) : this.sortTicketsDescending(tickets)
      return tickets
    },
    openGroupTickets() {
      let filteredTickets = this.tickets.filter(ticket => ticket.status === 'open' && ticket.isGroup)
      filteredTickets = this.ordenar ? this.sortTicketsAscending(filteredTickets) : this.sortTicketsDescending(filteredTickets)
      return Object.values(this.groupTickets(filteredTickets))
    },
    pendingGroupTickets() {
      let filteredTickets = this.tickets.filter(ticket => ticket.status === 'pending' && ticket.isGroup)
      filteredTickets = this.ordenar ? this.sortTicketsAscending(filteredTickets) : this.sortTicketsDescending(filteredTickets)
      return Object.values(this.groupTickets(filteredTickets))
    },
    privateMessages() {
      let tickets = this.tickets.filter(ticket => ticket.unreadMessages && !ticket.isGroup)
      tickets = this.ordenar ? this.sortTicketsAscending(tickets) : this.sortTicketsDescending(tickets)
      return tickets
    },
    groupMessages() {
      let tickets = this.tickets.filter(ticket => ticket.unreadMessages && ticket.isGroup)
      tickets = this.ordenar ? this.sortTicketsAscending(tickets) : this.sortTicketsDescending(tickets)
      return tickets
    }
  },
  watch: {
    ticketFocado: {
      immediate: true,
      handler(newTicket) {
        if (newTicket?.id) {
          this.carregarAnotacoes()
        }
      }
    },
    notificacaoChatInterno: {
      handler() {
        this.listarMensagens()
      }
    }
  },
  methods: {
    playNotificationSound() {
      if (this.isSilentMode || !this.currentAlertSound) return

      if (!this.audioElement) {
        this.audioElement = new Audio(this.currentAlertSound)
      }

      if (!this.audioElement.paused) return

      this.audioElement.play().catch((error) => {
        console.error('Error playing audio:', error)
      })
    },
    async loadColors() {
      const root = document.documentElement

      try {
        // API call
        const response = await ListarCores()

        // Extract values returned by the API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Apply colors as CSS variables to :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error loading colors:', error)
      }
    },
    formatarData(data) {
      return new Date(data).toLocaleString()
    },
    fecharChatModal () {
      this.mostrarModalChat = false
    },
    visualizarChat (ticketId) {
      this.ticketIdAtual = ticketId
      this.mostrarModalChat = true
    },
    replaceEmojis(str) {
      const ranges = [
        '[🀄-🧀]' // Emojis
      ]
      return str.replace(new RegExp(ranges.join('|'), 'ug'), '') // Replace emojis with empty string
    },
    async downloadPDF() {
      // eslint-disable-next-line new-cap
      const doc = new jsPDF()

      try {
        // Load background image
        const imgBackground = new Image()
        imgBackground.src = require('src/assets/wa-background.png')

        // Wait for image to load
        await new Promise((resolve, reject) => {
          imgBackground.onload = resolve
          imgBackground.onerror = reject
        })

        // Find messages
        const response = await LocalizarMensagensPDF({ ticketId: this.ticketFocado.id, todostickets: false })
        const mensagens = response.data.messages

        // Add background image to the first page
        doc.addImage(imgBackground, 'PNG', 0, 0, 210, 297)

        // Title with contact and ticket
        const primeiroContato = mensagens[0]?.contact?.name || 'Contact'
        const sanitizedContactName = this.replaceEmojis(primeiroContato)
        doc.setFontSize(16)
        doc.text(`Contact: ${sanitizedContactName} - Ticket: ${this.ticketFocado.id}`, 10, 20)

        let yPosition = 40

        mensagens.forEach((mensagem) => {
          if (yPosition > 280) {
            doc.addPage()
            doc.addImage(imgBackground, 'PNG', 0, 0, 210, 297)
            yPosition = 20
          }

          const remetente = mensagem.fromMe ? 'Me' : this.replaceEmojis(mensagem.contact.name || 'Contact')
          const sanitizedMessageBody = this.replaceEmojis(mensagem.body || '')
          const formattedDate = this.formatarData(mensagem.createdAt, 'DD/MM/YYYY HH:mm')

          doc.setFontSize(12)
          doc.text(`Message from: ${remetente}`, 10, yPosition)
          yPosition += 10

          doc.text(`Sent at: ${formattedDate}`, 10, yPosition)
          yPosition += 10

          const lines = doc.splitTextToSize(sanitizedMessageBody, 180)
          doc.text(lines, 10, yPosition)
          yPosition += lines.length * 10 + 10
        })

        doc.save(`attendance_${this.ticketFocado.id}_messages.pdf`)
      } catch (error) {
        console.error('Error generating PDF:', error)
      }
    },
    formatKanbanPrice(price) {
      // If price is null, undefined or not a number, return '0.00'
      return !isNaN(price) ? Number(price).toFixed(2) : '0.00'
    },
    getPhoneNumberLink(number) {
      if (!number) {
        return null
      }
      if ((number.startsWith('55')) && (number.charAt(4) > 5)) {
        return `tel:${number.slice(0, 4)}9${number.slice(-8)}`
      } else {
        return `tel:${number}`
      }
    },
    toggleSilentMode() {
      this.isSilentMode = !this.isSilentMode
      localStorage.setItem('silentMode', this.isSilentMode)
      window.location.reload()
    },
    sortTicketsAscending(tickets) {
      return tickets.sort((a, b) => new Date(a.updatedAt) - new Date(b.updatedAt))
    },
    sortTicketsDescending(tickets) {
      return tickets.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
    },
    groupTickets(tickets) {
      return tickets.reduce((acc, ticket) => {
        const key = `${ticket.whatsappId}_${ticket.userId}_${ticket.status}_${ticket.contactId}`
        if (!acc[key] || acc[key].id > ticket.id) {
          acc[key] = ticket
        }
        return acc
      }, {})
    },
    async getTaskSummary() {
      const owner = localStorage.getItem('username')
      try {
        const response = await ConsultarResumoTarefas({ owner })
        this.delayed = response.data.delayed
        this.venceHoje = response.data.venceHoje
      } catch (error) {
        console.error('Error fetching task summary:', error)
      }
    },
    async carregarAnotacoes() {
      if (!this.ticketFocado?.id) return

      try {
        const response = await ListarNotesTickets(this.ticketFocado.id) // Only the ID is passed
        this.anotacoes = response.data
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: 'Error loading notes.'
        })
        console.error('Error loading notes:', error)
      }
    },
    async excluirAnotacao(id, index) {
      this.$q.dialog({
        title: 'Attention!!',
        message: 'Do you really want to delete the note?',
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Yes',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        // Only execute deletion when the user clicks "Yes"
        this.loading = true

        DeletarNote({ id })
          .then(() => {
            // Remove the note from the local list after successful deletion
            this.anotacoes.splice(index, 1)

            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: 'Note deleted!',
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .catch((error) => {
            console.error('Error deleting note:', error)

            this.$q.notify({
              type: 'negative',
              message: 'Error deleting note.'
            })
          })
          .finally(() => {
            this.loading = false // End loading state
          })
      })
    },
    abrirModalNote() {
      this.mostrarModalNote = true
    },
    abrirModalTextoCompleto(note) {
      this.textoCompleto = note
      this.modalTextoCompleto = true
    },
    fecharModalNote() {
      this.mostrarModalNote = false
      this.novaAnotacao.note = '' // Clear the field when closing
    },
    async salvarAnotacao() {
      if (!this.novaAnotacao.note.trim()) {
        this.$q.notify({
          type: 'negative',
          message: 'The note name cannot be empty.'
        })
        return
      }
      try {
        // Prepare the data for the request
        const data = {
          note: this.novaAnotacao.note,
          contactId: this.ticketFocado.contactId,
          ticketId: this.ticketFocado.id
        }

        // Make the request to create the note
        await CriarNote(data)

        this.$q.notify({
          type: 'positive',
          message: 'Note created successfully!'
        })
        this.fecharModalNote() // Close the modal after saving
        await this.carregarAnotacoes()
        // Update the notes list (to be implemented in the future)
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: 'Error creating note. Please try again.'
        })
        console.error('Error creating note:', error)
      }
    },
    async atualizarUsuario() {
      try {
        const { data } = await DadosUsuario(this.usuario.userId)
        this.filasUser = data.queues
      } catch (error) {
        console.error(error)
        this.$notificarErro('Problem loading user', error)
      }
    },
    async loadMoreOpenTickets() {
      this.$q.notify({
        type: 'warning',
        message: 'Attendances loaded in the open, pending and closed tabs!',
        position: 'top'
      })
      try {
        this.loading = true
        this.pesquisaTickets.pageNumber++
        await this.consultarTickets()
        this.loading = false
      } catch (error) {
        this.loading = false
      }
    },
    showNotification() {
      this.$q.notify({
        type: 'warning',
        message: 'Attendances loaded in the open, pending and closed tabs!',
        position: 'top'
      })
      this.loadMoreOpenTickets()
    },
    toggleDrawer() {
      this.drawerContact = false
    },
    formatId(id) {
      const formattedId = formatSerializedId(id)
      return formattedId
    },
    async listarMensagens() {
      try {
        const [messageResponse, groupResponse] = await Promise.all([
          listCountUnreadMessage(this.usuario.userId),
          listCountUnreadMessageGroup(this.usuario.userId)
        ])

        this.notificacaoInternaNaoLida =
          (messageResponse.data?.count || 0) +
          (groupResponse.data?.count || 0)
      } catch (error) {
        console.error('Error listing messages:', error)
        this.notificacaoInternaNaoLida = 0
      }
    },
    handlerNotifications (data) {
      // Retrieve configurations from localStorage
      const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))

      // Check if there is a configuration 'groupnotification'
      const confGroupNotification = configuracoes?.find(c => c.key === 'groupnotification')

      // If the value of 'groupnotification' is 'disabled' and data.ticket.isGroup is true, do not display notification
      if (confGroupNotification?.value === 'disabled' && data.ticket?.isGroup) {
        return // Exit the function without displaying the notification
      }

      const options = {
        body: `${data.body} - ${format(new Date(), 'HH:mm')}`,
        icon: data.ticket.contact.profilePicUrl,
        tag: data.ticket.id,
        renotify: true
      }

      this.playNotificationSound()
      const notification = new Notification(
        `Message from ${data.ticket.contact.name}`,
        options
      )

      setTimeout(() => {
        notification.close()
      }, 10000)

      notification.onclick = e => {
        e.preventDefault()
        window.focus()
        this.$store.dispatch('AbrirChatMensagens', data.ticket)
        this.$router.push({ name: 'atendimento' })
      }
    },
    async listarConfiguracoes () {
      const { data } = await ListarConfiguracoes()
      localStorage.setItem('configuracoes', JSON.stringify(data))
      const ignoreGroupMsg = data.find(config => config.key === 'ignoreGroupMsg')
      this.grupoAtivo = ignoreGroupMsg.value
      const ExibirConexao = data.find(config => config.key === 'ExibirConexao')
      this.ExibirConexao = ExibirConexao.value
      const ContactAdmin = data.find(config => config.key === 'ContactAdmin')
      this.ContactAdmin = ContactAdmin.value
      const chatbotLane = data.find(config => config.key === 'chatbotLane')
      this.chatbotLane = chatbotLane.value
      const spyticket = data.find(config => config.key === 'spyticket')
      this.spyticket = spyticket.value
      const hidetabConfig = data.find(config => config.key === 'hidetab')
      this.hidetab = hidetabConfig ? hidetabConfig.value === 'enabled' : false
    },
    onScroll (info) {
      if (info.verticalPercentage <= 0.85) return
      this.onLoadMore()
    },
    editContact (contactId) {
      this.selectedContactId = contactId
      this.modalContato = true
    },
    deleteTicket (ticketId) {
      this.$q.dialog({
        title: 'Attention!! Do you really want to delete the Ticket? ',
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Yes',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarTicket(ticketId)
          .then(res => {
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: 'Ticket deleted!',
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })

            // Redirect to the /atendimento/chats route
            this.$router.push('/atendimento/chats')

            // Wait 5 seconds and reload the page
            setTimeout(() => {
              window.location.reload()
            }, 5000) // 5000 milliseconds = 5 seconds
          })
          .catch(error => {
            console.error(error)
            this.$notificarErro('Unable to delete the ticket', error)
          })
        this.loading = false
      })
    },
    contatoEditado (contato) {
      this.$store.commit('UPDATE_TICKET_FOCADO_CONTACT', contato)
    },
    async consultarTickets (paramsInit = {}) {
      const params = {
        ...this.pesquisaTickets,
        ...paramsInit
      }
      try {
        const { data } = await ConsultarTickets(params)
        this.countTickets = data.count
        this.$store.commit('LOAD_TICKETS', data.tickets)
        this.$store.commit('SET_HAS_MORE', data.hasMore)
      } catch (err) {
        this.$notificarErro('Some problem', err)
        console.error(err)
      }
    },
    async consultarTicketsOrdenados (paramsInit = {}) {
      const params = {
        ...this.pesquisaTickets,
        ...paramsInit
      }
      try {
        const { data } = await ConsultarTickets(params)
        this.countTickets = data.count

        const tickets = data.tickets

        if (this.ordenar == true) {
          tickets.sort((a, b) => {
            const data1 = new Date(a.updatedAt)
            const data2 = new Date(b.updatedAt)
            if (data1.getTime() > data2.getTime()) {
              return 1
            }
            if (data1.getTime() < data2.getTime()) {
              return -1
            }
            return 0
          })
          this.$store.commit('LOAD_TICKETS', tickets)
        }
        if (this.ordenar == false) {
          tickets.sort((a, b) => {
            const data1 = new Date(a.updatedAt)
            const data2 = new Date(b.updatedAt)
            if (data1.getTime() > data2.getTime()) {
              return 1
            }
            if (data1.getTime() < data2.getTime()) {
              return -1
            }
            return 0
          })
          this.$store.commit('LOAD_TICKETS', tickets)
        }
        if (this.ordenar == null) {
          this.$store.commit('LOAD_TICKETS', tickets)
        }

        this.$store.commit('SET_HAS_MORE', data.hasMore)

        console.log(tickets)
      } catch (err) {
        this.$notificarErro('Some problem', err)
        console.error(err)
      }
    },
    async BuscarTicketFiltro () {
      this.$store.commit('RESET_TICKETS')
      this.loading = true
      localStorage.setItem('filtrosAtendimento', JSON.stringify(this.pesquisaTickets))
      this.pesquisaTickets = {
        ...this.pesquisaTickets,
        pageNumber: 1
      }
      await this.consultarTickets(this.pesquisaTickets)
      this.loading = false
      this.$setConfigsUsuario({ isDark: this.$q.dark.isActive })
    },
    async onLoadMore () {
      if (this.tickets.length === 0 || !this.hasMore || this.loading) {
        return
      }
      try {
        this.loading = true
        this.pesquisaTickets.pageNumber++
        await this.consultarTickets()
        this.loading = false
      } catch (error) {
        this.loading = false
      }
    },
    async listarFilas () {
      const { data } = await ListarFilas()
      this.filas = data
      localStorage.setItem('filasCadastradas', JSON.stringify(data || []))
    },
    async listarWhatsapps () {
      const { data } = await ListarWhatsapps()
      this.$store.commit('LOAD_WHATSAPPS', data)
    },
    async listarEtiquetas () {
      const { data } = await ListarEtiquetas(true)
      this.etiquetas = data
    },
    async getKanbans() {
      const { data } = await ListarKanbans()
      this.kanbans = data
    },
    clearKanban(contactId) {
      this.ticketFocado.contact.kanbanId = 0
      this.updateKanban(0, contactId) // Send the update to the backend with value 0
    },
    async updateKanban(newKanbanId, contactId) {
      try {
        // Make the call to update the kanban
        const response = await AlterarContactKanban2({
          contactId: contactId, // Use the contactId passed as an argument
          kanbanId: newKanbanId || 0 // New value of kanbanId or 0 to uncheck
        })

        // Show success notification
        this.$q.notify({
          type: 'info',
          progress: true,
          position: 'top',
          textColor: 'black',
          message: 'CRM updated successfully!',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })

        console.log('CRM updated successfully:', response)
      } catch (error) {
        // Show error notification
        this.$q.notify({
          type: 'negative',
          progress: true,
          position: 'top',
          message: 'Error updating the Kanban',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })

        console.error('Error updating the CRM:', error)
      }
    },
    async abrirModalUsuario () {
      this.modalUsuario = true
    },
    async efetuarLogout () {
      try {
        await RealizarLogout(usuario)
        localStorage.removeItem('token')
        localStorage.removeItem('username')
        localStorage.removeItem('profile')
        localStorage.removeItem('userId')
        localStorage.removeItem('queues')
        localStorage.removeItem('usuario')
        localStorage.removeItem('filtrosAtendimento')

        this.$router.go({ name: 'login', replace: true })
      } catch (error) {
        this.$notificarErro(
          'Unable to logout',
          error
        )
      }
    },
    copyContent (content) {
      navigator.clipboard.writeText(content)
        .then(() => {
        })
        .catch((error) => {
          console.error('Error copying content: ', error)
        })
    },
    deletarMensagem (mensagem) {
      const data = { ...mensagem }
      this.$q.dialog({
        title: 'Attention!! Do you really want to delete the message? ',
        message: 'Old messages will not be deleted on the client.',
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Yes',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarMensagem(data)
          .then(res => {
            this.loading = false
            mensagem.isDeleted = true
          })
          .catch(error => {
            this.loading = false
            console.error(error)
            this.$notificarErro('Unable to delete the message', error)
          })
      }).onCancel(() => {
      })
    },
    async tagSelecionada (tags) {
      const { data } = await EditarEtiquetasContato(this.ticketFocado.contact.id, [...tags])
      this.contatoEditado(data)
    },
    async carteiraDefinida (wallets) {
      const { data } = await EditarCarteiraContato(this.ticketFocado.contact.id, [...wallets])
      this.contatoEditado(data)
    },
    async listarUsuarios () {
      try {
        const { data } = await await ListarUsuarios({ pageNumber: this.pageNumber })
        this.usuarios = [...this.usuarios, ...data.users]
        this.hasMore = data.hasMore

        if (this.hasMore) {
          this.pageNumber += 1
          this.listarUsuarios()
        }
      } catch (error) {
        console.error(error)
        this.$notificarErro('Problem loading users', error)
      }
    },
    setValueMenu () {
      this.drawerTickets = !this.drawerTickets
    },
    setValueMenuContact () {
      this.drawerContact = !this.drawerContact
    },
    async abrirModalLogs () {
      const { data } = await ConsultarLogsTicket({ ticketId: this.ticketFocado.id })
      this.logsTicket = data
      this.exibirModalLogs = true
    }
  },
  beforeMount () {
    this.$store.commit('RESET_TICKETS')
    this.listarFilas()
    this.listarEtiquetas()
    this.getKanbans()
    this.listarConfiguracoes()
    const filtros = JSON.parse(localStorage.getItem('filtrosAtendimento'))
    if (!filtros?.pageNumber) {
      localStorage.setItem('filtrosAtendimento', JSON.stringify(this.pesquisaTickets))
    }
  },
  async mounted () {
    this.loadColors()
    this.getTaskSummary()
    this.loadingMount = true

    this.notify = this.$q.notify({
      position: 'top',
      type: 'positive',
      message: 'Please wait while the tickets are loading...',
      progress: true,
      actions: [{ icon: 'close', round: true, color: 'white' }]
    })

    try {
      this.$root.$on('infor-cabecalo-chat:acao-menu', this.setValueMenu)
      this.$root.$on('update-ticket:info-contato', this.setValueMenuContact)
      await this.atualizarUsuario()
      await this.listarMensagens()
      this.$store.commit('UPDATE_SHOW_MENU', this.showMenu)
      this.socketTicketList()
      this.pesquisaTickets = JSON.parse(localStorage.getItem('filtrosAtendimento'))
      this.$root.$on('handlerNotifications', this.handlerNotifications)
      await this.listarWhatsapps()
      await this.consultarTickets()
      await this.listarUsuarios()
      try {
        await this.loadColors()
        await this.atualizarUsuario()
        await this.listarMensagens()
      } catch (e) {
        console.log(e)
      }
      const { data } = await ListarMensagensRapidas()
      this.mensagensRapidas = data

      const savedSilentMode = localStorage.getItem('silentMode')
      if (savedSilentMode !== null) {
        this.isSilentMode = JSON.parse(savedSilentMode)
      }

      if ('Notification' in window) {
        Notification.requestPermission()
      }
      this.userProfile = localStorage.getItem('profile')

      if (this.$route?.params?.ticketId) {
        const ticketId = this.$route.params.ticketId
        if (ticketId && this.tickets.length > 0) {
          const ticket = this.tickets.find((t) => t.id === +ticketId)
          if (ticket) {
            if (this.$q.screen.lt.md && ticket.status !== 'pending') {
              this.$root.$emit('infor-cabecalo-chat:acao-menu')
            }
            this.$store.commit('SET_HAS_MORE', true)
            this.$store.dispatch('AbrirChatMensagens', ticket)
          }
        }
      } else {
        this.$router.push({ name: 'chat-empty' })
      }
    } catch (error) {
      console.error('Error mounting the component:', error)
    } finally {
      this.isMounted = true
      this.loadingMount = false
      if (this.notify) {
        this.notify()
      }
    }
  },
  beforeRouteLeave(to, from, next) {
    if (!this.isMounted) {
      next(false)
    } else {
      next()
    }
  },
  destroyed() {
    this.$store.commit('RESET_TICKETS')
    this.$root.$off('handlerNotifications', this.handlerNotifications)
    this.$root.$off('infor-cabecalo-chat:acao-menu', this.setValueMenu)
    this.$root.$on('update-ticket:info-contato', this.setValueMenuContact)
    this.$store.commit('TICKET_FOCADO', {})
  }
}
</script>

<style lang="sass">

absolute-top
  position: absolute
  top: 0
.upload-btn-wrapper
  position: relative
  overflow: hidden
  display: inline-block

  & input[type="file"]
    font-size: 100px
    position: absolute
    left: 0
    top: 0
    opacity: 0

.WAL
  width: 100%
  height: 100%

  &:before
    content: ''
    height: 127px
    position: fixed
    top: 0
    width: 100%

  &__layout
    margin: 0 auto
    z-index: 4000
    height: 100%
    width: 100%

  &__field.q-field--outlined .q-field__control:before
    border: none

  .q-drawer--standard
    .WAL__drawer-close
      display: none

@media (max-width: 850px)
  .WAL
    padding: 0
    &__layout
      width: 100%
      border-radius: 0

@media (min-width: 691px)
  .WAL
    &__drawer-open
      display: none

.conversation__summary
  margin-top: 4px

.conversation__more
  margin-top: 0!important
  font-size: 1.4rem

.tab-container
  overflow-x: auto
  font-size: 0.75rem

.tab-scroll
  white-space: nowrap

.badge-left
  border-radius: 50%

.black-icon
  color: black !important

.q-tabs__indicator
  background: transparent !important

.blur-effect
  filter: blur(0px)

.custom-scrollbar
  overflow-y: auto

  &::-webkit-scrollbar
    width: 0

  &:hover
    &::-webkit-scrollbar
      width: 6px

    &::-webkit-scrollbar-thumb
      border-radius: 4px

    &::-webkit-scrollbar-track
      background: transparent

  scrollbar-width: none

  &:hover
    scrollbar-width: thin

.light-scrollbar
  &::-webkit-scrollbar-thumb
    background-color: rgba(0, 0, 0, 0.1)

  &::-webkit-scrollbar-thumb:hover
    background-color: rgba(0, 0, 0, 0.4)

  &:hover
    scrollbar-color: rgba(0, 0, 0, 0.1) transparent

.dark-scrollbar
  &::-webkit-scrollbar-thumb
    background-color: rgba(255, 255, 255, 0.2)

  &::-webkit-scrollbar-thumb:hover
    background-color: rgba(255, 255, 255, 0.4)

  &:hover
    scrollbar-color: rgba(255, 255, 255, 0.2) transparent

</style>
