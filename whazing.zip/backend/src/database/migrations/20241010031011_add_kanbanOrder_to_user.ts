import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'kanbanOrder' column to the 'Users' table
    // Stores user-specific ordering/preference for Kanban columns, likely as JSON.
    await queryInterface.addColumn(
      "Users", // Table name
      "kanbanOrder", // New column name
      {
        type: DataTypes.JSONB, // JSONB is generally preferred over JSON in PostgreSQL
        allowNull: true,
        defaultValue: null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'kanbanOrder' column from the 'Users' table
    await queryInterface.removeColumn(
      "Users", // Table name
      "kanbanOrder" // Column name to remove
    );
  }
};

export = migration;
