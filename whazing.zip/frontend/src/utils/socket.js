import { io } from 'socket.io-client'

export const socketIO = () => {
  return io(process.env.URL_API, {
    reconnection: true,
    autoConnect: true,
    pingTimeout: 20000,
    pingInterval: 25000,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    reconnectionAttempts: Infinity,
    timeout: 20000,
    transports: ['websocket', 'polling'],
    forceNew: true,
    auth: (cb) => {
      const tokenItem = localStorage.getItem('token')
      const token = tokenItem ? JSON.parse(tokenItem) : null
      // eslint-disable-next-line standard/no-callback-literal
      cb({ token })
    }
  })
}

const socket = socketIO()
let reconnectAttempts = 0

socket.io.on('reconnect_attempt', (attempt) => {
  console.info('Reconnection attempt:', attempt)
  reconnectAttempts++
})

socket.io.on('error', (error) => {
  console.error('Socket.io error:', error)
})

// eslint-disable-next-line handle-callback-err
socket.on('connect_error', (error) => {
  reconnectAttempts++
})

socket.on('disconnect', (reason) => {
  console.info('Socket disconnected:', reason)

  if (!socket.connected) {
    setTimeout(() => socket.connect(), 2000)
  }
})

socket.on('connect', () => {
  console.info('Socket connected successfully')
  reconnectAttempts = 0
})

socket.on('reconnecting', (attemptNumber) => {
  console.info('Attempting to reconnect...', attemptNumber)
})

// Add reconnect_failed event listener
socket.on('reconnect_failed', () => {
  console.error('Failed to reconnect after all attempts')
  console.info('Recarregando a página após falha completa na reconexão')
  window.location.reload()
})

export default socket
