import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'Tickets';
    // Add index on [tenantId, status]
    await queryInterface.addIndex(tableName, ['tenantId', 'status'], {
      name: 'idx_tickets_tenantid_status', // Explicit index name
    });
    // Add index on [contactId, tenantId]
    await queryInterface.addIndex(tableName, ['contactId', 'tenantId'], {
      name: 'idx_tickets_contactid_tenantid', // Explicit index name
    });
     // Add index on [queueId, tenantId]
    await queryInterface.addIndex(tableName, ['queueId', 'tenantId'], {
       name: 'idx_tickets_queueid_tenantid', // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'Tickets';
    // Remove indexes in reverse order of creation (optional but good practice)
    await queryInterface.removeIndex(tableName, 'idx_tickets_queueid_tenantid');
    await queryInterface.removeIndex(tableName, 'idx_tickets_contactid_tenantid');
    await queryInterface.removeIndex(tableName, 'idx_tickets_tenantid_status');
  }
};

export = migration;