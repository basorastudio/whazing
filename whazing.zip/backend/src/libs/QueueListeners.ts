import { Job, JobOptions } from 'bull';
import axios from 'axios';

// Define structure for Job data and options if known
interface JobData {
    id?: any;
    data?: any;
    name?: string;
    opts?: JobOptions & { repeat?: any }; // Bull's JobOptions + potential repeat property
    timestamp?: number;
    // Add other properties if available on the job object
}

interface FailedJobData extends JobData {
     failedReason?: string; // Reason for failure provided by Bull
     stacktrace?: string[]; // Stacktrace if available
}

interface RetryOptions {
    fallbackUrl?: string; // URL to notify on failure
    // Add other retry options if used
}

// Define execution types if needed elsewhere, or keep local
enum ExecutionType {
    REPEAT = 'REPEAT',
    DELAY = 'DELAY',
    UNKNOWN = 'UNKNOWN'
}

/**
 * Handles queue events and logs them. Provides fallback mechanism via webhook.
 */
class QueueListener {
    /**
     * Logs job completion.
     * @param job - The completed job instance.
     */
    static onCompleted(job: Job): void {
        // console.log(`Job completed: ${job.name} ID ${job.id}`);
    }

    /**
     * Logs job activation.
     * @param job - The activated job instance.
     */
    static onActive(job: Job): void {
        // console.log(`Job active: ${job.name} ID ${job.id}`);
    }

    /**
     * Logs when a job is waiting.
     * @param jobId - The ID of the waiting job.
     */
    static onWaiting(jobId: string | number): void {
        // console.log(`Job waiting: ID ${jobId}`);
    }

    /**
     * Logs when a job is removed.
     * @param job - The removed job instance.
     */
    static onRemoved(job: Job): void {
        // console.log(`Job removed: ${job.name} ID ${job.id}`);
    }

    /**
     * Logs when a job is cleaned.
     * @param jobs - Array of cleaned jobs.
     * @param type - Type of clean operation.
     */
    static onClean(jobs: Job[], type: string): void {
        // console.log(`Jobs cleaned: ${jobs.length} of type ${type}`);
    }

    /**
     * Logs job stalling.
     * @param job - The stalled job instance.
     */
    static onStalled(job: Job): void {
        console.warn(`Job stalled: ${job.name} ID ${job.id}`);
    }

    /**
     * Logs job errors.
     * @param job - The job instance where the error occurred.
     * @param error - The error object.
     */
    static onError(job: Job, error: Error): void {
        console.error(`Job error: ${job?.name} ID ${job?.id}`, error);
    }

    /**
     * Handles failed jobs, logs detailed information, and attempts webhook fallback if configured.
     * @param job - The failed job instance.
     * @param error - The error that caused the failure.
     */
    static onFailed(job: Job<any>, error: Error): void {
        const jobData: FailedJobData = { ...job }; // Clone job data
         jobData.failedReason = error.message; // Add failure reason
         jobData.stacktrace = error.stack?.split('\n'); // Add stack trace

        console.error(`Job - ${job?.name} ID ${job?.id} failed. Attempts made: ${job?.opts?.attempts}. Max attempts: ${job?.opts?.repeat?.count || 'N/A'}`, error);


        // Fallback mechanism using webhook if configured in job options
        const retryOptions = job?.opts as JobOptions & { retryOptions?: RetryOptions }; // Type assertion
        if (retryOptions?.retryOptions?.fallbackUrl) {
            const payload = {
                ...retryOptions, // Include original options
                id: job?.id,
                failedReason: error.message,
                stacktrace: error.stack
            };
             const htmlMessage = `
             <div>
               <p> Job Name: ${job?.name || 'N/A'} </p>
               <p> Job ID : ${job?.id || 'N/A'} </p>
               <p> Timestamp: ${job?.timestamp ? new Date(job.timestamp).toISOString() : 'N/A'} </p>
               <p> JobOptions : </p>
                     <div>
                         <h1> Job Failed Repeatedly </h1>
                         <p> Attempts made: ${job?.attemptsMade || 0} </p>
                         <p> Max attempts ${retryOptions?.repeat?.count || 'N/A'} </p>
                         <p> Failed Reason : </p>
                         <code> ${error?.message || 'Unknown reason'} </code>
                         <p> Job Data : </p>
                         <code> ${JSON.stringify(job?.data || {})} </code>
                         <p> Job Opts : </p>
                         <code> ${JSON.stringify(job?.opts || {})} </code>
                         <p> Stacktrace : </p>
                         <code> ${error?.stack || 'No stacktrace available'} </code>
                     </div>
             </div>
            `;

            axios_1.default.post(retryOptions.retryOptions.fallbackUrl, payload)
                 .then(() => console.log(`Fallback notification sent for job ${job?.id}`))
                 .catch(err => console.error(`Failed to send fallback notification for job ${job?.id}:`, err));
        } else {
            console.log(`Job ${job?.id} failed without a configured fallback URL.`);
        }
    }
}

export default QueueListener;