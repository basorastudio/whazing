import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'Invoices' table
    await queryInterface.createTable(
      "Invoices", // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false
        },
        detail: {
          type: DataTypes.STRING // Assuming details are short text
          // allowNull defaults to true
        },
        status: {
          type: DataTypes.STRING
          // allowNull defaults to true
        },
        value: {
          type: DataTypes.FLOAT // Use FLOAT or DECIMAL for monetary values
          // allowNull defaults to true
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        dueDate: {
          type: DataTypes.STRING // Original was STRING, consider DATE?
          // allowNull defaults to true
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: {
            model: "Tenants", // References the 'Tenants' table
            key: "id"
          },
          onUpdate: "CASCADE",
          onDelete: "CASCADE", // If Tenant is deleted, delete associated Invoices
          allowNull: false // Invoice must belong to a Tenant
        },
        txId: {
          type: DataTypes.STRING // Transaction ID from payment gateway
          // allowNull defaults to true
          // Consider adding unique: true if txId should be unique
        },
        payGw: {
          type: DataTypes.STRING // Payment Gateway name (e.g., 'stripe', 'paypal')
          // allowNull defaults to true
        },
        payGwData: {
          type: DataTypes.TEXT // Store raw data/response from payment gateway (JSON string, etc.)
          // allowNull defaults to true
        }
      }
    );

    // Add an index to the 'txId' column for faster lookups
    // Note: Original specified unique: false explicitly, which is the default.
    await queryInterface.addIndex(
      "Invoices", // Table name
      ["txId"], // Column(s) to index
      {
        name: "idx_txid" // Optional index name
        // unique: false // Default behavior
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'Invoices' table
    await queryInterface.dropTable("Invoices");
    // Note: Indexes associated with the table are typically dropped automatically.
  }
};

export = migration;
