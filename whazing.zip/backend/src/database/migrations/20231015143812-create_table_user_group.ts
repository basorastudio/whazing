// --- START OF FILE 20231015143812-create_table_user_group.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "UsersGroups"; // Changed 'UsersGroup' + 's' to standard plural 'UsersGroups'
    const tableDefinition = {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // 'autoIncrem' + 'ent'
        allowNull: false
      },
      groupId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Groups", // Original 'Groups'
          key: "id"
        },
        onUpdate: "CASCADE", // Original 'CASCADE'
        onDelete: "CASCADE", // Original 'CASCADE'
        allowNull: false // Changed ![] to false
      },
      userId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Users", // Original 'Users'
          key: "id"
        },
        onUpdate: "CASCADE", // Original 'CASCADE'
        onDelete: "CASCADE", // Original 'CASCADE'
        allowNull: false // Changed ![] to false
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    };
    await queryInterface.createTable(tableName, tableDefinition);

    // Optional: Add a unique constraint on (groupId, userId) to prevent duplicates
    await queryInterface.addConstraint(tableName, {
      fields: ["groupId", "userId"],
      type: "unique",
      name: "unique_user_group_constraint" // Explicit constraint name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "UsersGroups"; // Changed 'UsersGroup' + 's' to standard plural 'UsersGroups'
    // Remove the constraint first if added
    try {
      await queryInterface.removeConstraint(
        tableName,
        "unique_user_group_constraint"
      );
    } catch (error) {
      // Ignore error if constraint doesn't exist
      console.log(
        "Constraint 'unique_user_group_constraint' not found or already removed."
      );
    }
    await queryInterface.dropTable(tableName);
  }
};

export default migration;
// --- END OF FILE 20231015143812-create_table_user_group.ts ---
