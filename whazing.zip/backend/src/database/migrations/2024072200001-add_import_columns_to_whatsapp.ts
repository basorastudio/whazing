import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: async (queryInterface: QueryInterface, sequelize: Sequelize) => {
    const tableInfo = await queryInterface.describeTable("Whatsapps");

    // Añade la columna importOldMessages si no existe
    if (!tableInfo || !tableInfo["importOldMessages"]) {
      await queryInterface.addColumn("Whatsapps", "importOldMessages", {
        type: DataTypes.BOOLEAN,
        allowNull: true, // Permite nulos inicialmente si la tabla ya tiene datos
        defaultValue: false // Valor predeterminado para nuevas filas o al actualizar
      });
    }

    // Añade la columna importRecentMessages si no existe
    if (!tableInfo || !tableInfo["importRecentMessages"]) {
      await queryInterface.addColumn("Whatsapps", "importRecentMessages", {
        type: DataTypes.BOOLEAN,
        allowNull: true, // Permite nulos inicialmente
        defaultValue: false // Valor predeterminado
      });
    }
    // Si se desea asegurar que las columnas no sean nulas después de la creación:
    // await queryInterface.changeColumn('Whatsapps', 'importOldMessages', {
    //   type: DataTypes.BOOLEAN,
    //   allowNull: false,
    //   defaultValue: false
    // });
    // await queryInterface.changeColumn('Whatsapps', 'importRecentMessages', {
    //   type: DataTypes.BOOLEAN,
    //   allowNull: false,
    //   defaultValue: false
    // });
  },

  down: async (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina las columnas añadidas
    await queryInterface.removeColumn("Whatsapps", "importOldMessages");
    await queryInterface.removeColumn("Whatsapps", "importRecentMessages");
  }
};
