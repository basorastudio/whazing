import { QueryInterface, DataTypes, Sequelize } from 'sequelize'; // Added Sequelize
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'KeywordChatflows'; // Pluralized table name
    // Create the 'KeywordChatflows' table
    await queryInterface.createTable(tableName, {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      keyword: {
        type: DataTypes.TEXT, // TEXT for potentially long keywords/phrases
        allowNull: false,
      },
      chatFlowId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: 'ChatFlow', key: 'id' }, // Assumed table name 'ChatFlow'
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Delete keyword mapping if ChatFlow is deleted
      },
      tenantId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: 'Tenants', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Delete keyword mapping if Tenant is deleted
      },
      whatsappId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: { model: 'Whatsapps', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Delete keyword mapping if Whatsapp connection is deleted
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        allowNull: false, // Assuming isActive should not be null
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn('NOW'),
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn('NOW'),
      },
    });

    // Add indexes
    await queryInterface.addIndex(tableName, ['keyword'], { name: 'keyword_idx' });
    await queryInterface.addIndex(tableName, ['tenantId'], { name: 'keyword_tenant_idx' });
    await queryInterface.addIndex(tableName, ['whatsappId'], { name: 'keyword_whatsapp_idx' });
    // Composite index for efficient lookups
    await queryInterface.addIndex(tableName, ['tenantId', 'whatsappId', 'keyword'], { name: 'keyword_tenant_whatsapp_keyword_idx' });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'KeywordChatflows' table (indexes are dropped automatically)
    await queryInterface.dropTable('KeywordChatflows');
  }
};

export = migration;