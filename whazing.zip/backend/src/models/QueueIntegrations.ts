import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import Queue from "./Queue";
import Tenant from "./Tenant";

@Table
class QueueIntegrations extends Model<QueueIntegrations> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column(DataType.STRING)
  type: string; // Type of integration (e.g., 'typebot', 'n8n')

  @Column(DataType.STRING)
  name: string; // Name of the integration setup

  @Column(DataType.STRING)
  projectName: string; // 'projectName' resolved

  @Column(DataType.TEXT) // TEXT for potentially long JSON
  jsonContent: string; // Or DataType.JSONB

  @Column(DataType.STRING)
  urlN8N: string;

  @Column(DataType.STRING)
  apiKey: string;

  @Column(DataType.STRING)
  language: string;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @Column(DataType.STRING)
  typebotKey: string; // Resolved

  @Default(60) // Default value from original options
  @Column
  typebotExpires: number; // 'typebotExpires' resolved

  @Column(DataType.STRING)
  typebotSlug: string; // 'typebotSlug' resolved

  @Column(DataType.STRING)
  typebotRestartMessage: string; // 'typebotRestartMessage' resolved

  @Column(DataType.STRING)
  typebotUnknownMessage: string; // 'typebotUnknownMessage' resolved

  @Column(DataType.STRING)
  typebotDelayMessage: string; // 'typebotDelayMessage' resolved

  @AllowNull(true)
  @Column
  aiModel: string; // AI Model name

  @AllowNull(true)
  @Column
  aiMaxTokens: number; // Assuming numeric

  @AllowNull(true)
  @Column
  aiTemperature: number; // Assuming numeric (e.g., 0.7)

  @AllowNull(true)
  @Column
  aiVoiceKey: string; // Assuming string key

  @AllowNull(true)
  @Column
  aiVoiceRegion: string; // Assuming string region

  @AllowNull(true)
  @Column
  wordRestart: string; // Word to restart flow

  @AllowNull(true)
  @Column
  wordFinish: string; // Word to finish flow

  @AllowNull(true)
  @Column
  n8nApiKey: string; // API Key for N8N

  @AllowNull(true)
  @ForeignKey(() => Queue)
  @Column
  queueId: number;

  @BelongsTo(() => Queue)
  queue: Queue;
}

export default QueueIntegrations;
