import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert Mercado Pago related settings into 'SettingsGeneral'
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('keyMp', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('mp_pix', 'enabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('mp_boleto', 'enabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('mp_cartao_debito', 'enabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('mp_cartao_credito', 'enabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted Mercado Pago settings
    await queryInterface.bulkDelete(
      "SettingsGeneral", // Adjust schema if needed
      {
        key: [
          "keyMp",
          "mp_pix",
          "mp_boleto",
          "mp_cartao_debito",
          "mp_cartao_credito"
        ]
      }
    );
  }
};

export = migration;
