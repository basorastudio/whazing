import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add columns related to accepting audio messages to 'Whatsapps' table
    await queryInterface.addColumn("Whatsapps", "acceptAudioMessage", {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      allowNull: false // Original had false
    });
    await queryInterface.addColumn("Whatsapps", "sendacceptAudioMessage", {
      type: DataTypes.TEXT,
      defaultValue: null,
      allowNull: true // Original allowed null
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added audio message columns
    await queryInterface.removeColumn("Whatsapps", "sendacceptAudioMessage");
    await queryInterface.removeColumn("Whatsapps", "acceptAudioMessage");
  }
};

export = migration;
