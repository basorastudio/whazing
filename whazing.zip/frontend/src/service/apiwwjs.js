import request from 'src/service/request'

export function CheckApiwwjsStatus(whatsappId) {
  return request({
    url: `/apiwwjs/status/${whatsappId}`,
    method: 'get'
  })
}

export function StartApiwwjsSession(whatsappId) {
  return request({
    url: `/apiwwjs/start/${whatsappId}`,
    method: 'post'
  })
}

export function GetApiwwjsQrCode(whatsappId) {
  return request({
    url: `/apiwwjs/qrcode/${whatsappId}`,
    method: 'get'
  })
}

export function TerminateApiwwjsSession(whatsappId) {
  return request({
    url: `/apiwwjs/terminate/${whatsappId}`,
    method: 'post'
  })
}
