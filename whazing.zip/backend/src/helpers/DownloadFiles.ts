// Original: DownloadFiles.js
// Deobfuscated, converted to TS, and translated

'use strict';

import axios, { AxiosResponse } from 'axios';
import { join as pathJoin } from 'path';
import { createWriteStream } from 'fs';
import mime from 'mime-types'; // Importación por defecto
import { makeRandomId } from './MakeRandomId'; // Asumiendo exportación nombrada
import { Worker, isMainThread, parentPort, workerData } from 'worker_threads';
import { Stream } from 'stream'; // Importar Stream

// Define el tipo para los datos pasados al worker
interface WorkerData {
    url: string;
}

// Define la estructura del objeto de resultado
interface DownloadResult {
    mimeType: string;
    extension: string | false; // mime.extension puede devolver false
    filename: string;
    originalname: string;
    size: number;
}

// Define el tipo para los mensajes enviados desde el worker
type WorkerMessage =
  | { type: 'progress'; downloadedSize: number; totalSize: number }
  | { type: 'complete'; data: DownloadResult }
  | { type: 'error'; error: string };

// Función que se ejecuta en el worker thread
const workerFunction = async (url: string): Promise<DownloadResult> => {
    try {
        const response: AxiosResponse<Stream> = await axios({
            url,
            method: 'GET',
            responseType: 'stream',
            maxBodyLength: Infinity, // Permitir descargas grandes
            maxContentLength: Infinity
        });

        const contentType = response.headers['content-type'] || mime.lookup(url) || 'application/octet-stream';
        const extension = mime.extension(contentType) || 'bin'; // Default a .bin si no se encuentra extensión
        const originalname = url.split('/').pop() || `downloaded_file.${extension}`; // Obtener nombre original o generar uno

        const filename = `${makeRandomId(5)}-${new Date().getTime()}.${extension}`;
        const filePath = pathJoin(__dirname, '..', '..', 'public', filename); // Ruta para guardar el archivo

        const writer = createWriteStream(filePath);

        return new Promise((resolve, reject) => {
            const totalSize = parseInt(response.headers['content-length'] || '0', 10);
            let downloadedSize = 0;

            response.data.on('data', (chunk: Buffer) => {
                downloadedSize += chunk.length;
                if (parentPort) {
                    parentPort.postMessage({ type: 'progress', downloadedSize, totalSize } as WorkerMessage);
                }
            });

            response.data.pipe(writer);

            writer.on('finish', () => {
                const result: DownloadResult = {
                    mimeType: contentType,
                    extension: extension,
                    filename: filename,
                    originalname: originalname,
                    size: downloadedSize
                };
                 if (parentPort) {
                     parentPort.postMessage({ type: 'complete', data: result } as WorkerMessage);
                 }
                resolve(result);
            });

            writer.on('error', (err) => {
                 if (parentPort) {
                     parentPort.postMessage({ type: 'error', error: err.message } as WorkerMessage);
                 }
                reject(err)
            });
            response.data.on('error', (err) => {
                 if (parentPort) {
                     parentPort.postMessage({ type: 'error', error: err.message } as WorkerMessage);
                 }
                reject(err)
            });
        });

    } catch (error: any) {
        console.error("Error downloading file:", error.message);
        // Re-lanzar para que el worker pueda capturarlo y enviar mensaje
        throw error;
    }
};

// Ejecutar workerFunction si estamos en un worker thread
if (!isMainThread) {
    const { url: workerUrl } = workerData as WorkerData;
    workerFunction(workerUrl)
        // El resultado o error se comunica a través de postMessage dentro de workerFunction
        .catch(error => {
             // El error ya se envía a través de postMessage si parentPort existe
            if (!parentPort) {
                console.error("Worker error (no parentPort):", error.message);
            }
             // process.exit(1); // Considerar salir con error
        });
}

// Función principal exportada que crea y maneja el worker
export const downloadFile = (
    url: string,
    progressCallback?: (percent: number) => void // Callback opcional para progreso
): Promise<DownloadResult> => {

    return new Promise((resolve, reject) => {
        const worker = new Worker(__filename, {
            workerData: { url } as WorkerData
        });

        worker.on('message', (message: WorkerMessage) => {
            switch (message.type) {
                case 'progress':
                    if (progressCallback && message.totalSize > 0) {
                        const percent = Math.round((message.downloadedSize / message.totalSize) * 100);
                        progressCallback(percent);
                    }
                    break;
                case 'complete':
                    resolve(message.data);
                    break;
                case 'error':
                     // Traducido: Error del worker
                    reject(new Error(`Worker error: ${message.error}`));
                    break;
            }
        });

        worker.on('error', (err) => {
             // Traducido: Error fatal del worker
            reject(new Error(`Fatal worker error: ${err.message}`));
        });

        worker.on('exit', (code) => {
            if (code !== 0) {
                 // Traducido: Worker parado con código de salida
                reject(new Error(`Worker stopped with exit code ${code}`));
            }
             // Si el código es 0, 'complete' o 'error' ya deberían haber resuelto/rechazado
        });
    });
};