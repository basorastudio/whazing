import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'Contacts';
    // Add index on [tenantId]
    await queryInterface.addIndex(tableName, ['tenantId'], {
      name: 'idx_contacts_tenantid', // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'Contacts';
    // Remove the index
    await queryInterface.removeIndex(tableName, 'idx_contacts_tenantid');
  }
};

export = migration;