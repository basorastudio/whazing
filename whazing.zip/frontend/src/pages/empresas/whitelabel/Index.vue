<template>
  <div class="mass-container container-rounded-10" :class="$q.dark.isActive ? ('text-white bg-grey-10') : 'container-border'">
    <q-list class="text-weight-medium"/>
    <q-item-label :class="$q.dark.isActive ? ('text-color-dark') : ''">Módulo: White Label</q-item-label>
    <q-separator spaced />

    <div class="row q-px-md">
      <div class="col-12">
        <q-item-section>
          <q-input v-model="title" type="textarea" autogrow dense outlined
                   label="Título del Sitio:" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                   @input="atualizarConfiguracao('title')" />
          <q-item-label :class="$q.dark.isActive ? ('text-color-dark') : ''">Cambio de logo / Título</q-item-label>
          <q-item tag="label" v-ripple>
            <q-item-section>
              <q-item-label>Seleccionar archivo:</q-item-label>
            </q-item-section>
            <q-item-section avatar>
              <input
                type="file"
                @change="onFileChangeLogo"
                ref="fileInput"
                class="q-mt-md"
                :accept="fileAcceptType"
              />
            </q-item-section>
          </q-item>
        </q-item-section>
        <q-item tag="label" v-ripple>
          <q-item-section>
            <q-item-label>Seleccionar Archivo</q-item-label>
          </q-item-section>
          <q-item-section avatar>
            <q-select
              style="width: 300px"
              outlined
              dense
              v-model="selectedFileType"
              :options="fileOptions"
              emit-value
              option-value="value"
              option-label="label"
              @input="handleFileTypeChange"
            />
          </q-item-section>
        </q-item>
      </div>
    </div>

      <div class="col-12">
        <q-item tag="label" v-ripple>
          <q-item-section>
            <q-item-label :class="$q.dark.isActive ? ('text-color-dark') : ''">Whatsapp Soporte</q-item-label>
            <q-input v-model="whatsappnumber" type="number" autogrow dense outlined
                     label="Whatsapp Soporte" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                     @input="atualizarConfiguracao('whatsappnumber')" />
          </q-item-section>
        </q-item>
      </div>

    <div class="row q-px-md">
      <div class="col-12 q-mb-sm">
        <q-input
          label="Color 1:"
          autogrow
          dense
          outlined
          :style="`background: ${cor1}`"
          v-model="cor1"
          input-style="min-height: 6vh; max-height: 9vh;"
          debounce="700"
          :dark="false"
          @input="atualizarConfiguracao('cor1')"
        >
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer q-ml-sm"
              @click="openColorPicker = true"
            ></q-icon>
            <q-popup-proxy
              v-model="openColorPicker"
              transition-show="scale"
              transition-hide="scale"
            >
              <q-color
                format-model="hex"
                square
                default-view="palette"
                no-header
                bordered
                v-model="cor1"
                @input="atualizarConfiguracao('cor1')"
              />
            </q-popup-proxy>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          label="Color 2:"
          autogrow
          dense
          outlined
          :style="`background: ${cor2}`"
          v-model="cor2"
          input-style="min-height: 6vh; max-height: 9vh;"
          debounce="700"
          :dark="false"
          @input="atualizarConfiguracao('cor2')"
        >
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer q-ml-sm"
              @click="openColorPicker2 = true"
            ></q-icon>
            <q-popup-proxy
              v-model="openColorPicker2"
              transition-show="scale"
              transition-hide="scale"
            >
              <q-color
                format-model="hex"
                square
                default-view="palette"
                no-header
                bordered
                v-model="cor2"
                @input="atualizarConfiguracao('cor2')"
              />
            </q-popup-proxy>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          label="Color 3:"
          autogrow
          dense
          outlined
          :style="`background: ${textcor1}`"
          v-model="textcor1"
          input-style="min-height: 6vh; max-height: 9vh;"
          debounce="700"
          :dark="false"
          @input="atualizarConfiguracao('textcor1')"
        >
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer q-ml-sm"
              @click="openColorPicker3 = true"
            ></q-icon>
            <q-popup-proxy
              v-model="openColorPicker3"
              transition-show="scale"
              transition-hide="scale"
            >
              <q-color
                format-model="hex"
                square
                default-view="palette"
                no-header
                bordered
                v-model="textcor1"
                @input="atualizarConfiguracao('textcor1')"
              />
            </q-popup-proxy>
          </template>
        </q-input>
      </div>
    </div>

    <div class="row q-px-md">
      <div class="col-12 q-mb-sm">
        <q-input
          label="Color 1 Dark:"
          autogrow
          dense
          outlined
          :style="`background: ${cor1dark}`"
          v-model="cor1dark"
          input-style="min-height: 6vh; max-height: 9vh;"
          debounce="700"
          :dark="false"
          @input="atualizarConfiguracao('cor1dark')"
        >
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer q-ml-sm"
              @click="openColorPicker4 = true"
            ></q-icon>
            <q-popup-proxy
              v-model="openColorPicker4"
              transition-show="scale"
              transition-hide="scale"
            >
              <q-color
                format-model="hex"
                square
                default-view="palette"
                no-header
                bordered
                v-model="cor1dark"
                @input="atualizarConfiguracao('cor1dark')"
              />
            </q-popup-proxy>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          label="Color 2 Dark:"
          autogrow
          dense
          outlined
          :style="`background: ${cor2dark}`"
          v-model="cor2dark"
          input-style="min-height: 6vh; max-height: 9vh;"
          debounce="700"
          :dark="false"
          @input="atualizarConfiguracao('cor2dark')"
        >
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer q-ml-sm"
              @click="openColorPicker5 = true"
            ></q-icon>
            <q-popup-proxy
              v-model="openColorPicker5"
              transition-show="scale"
              transition-hide="scale"
            >
              <q-color
                format-model="hex"
                square
                default-view="palette"
                no-header
                bordered
                v-model="cor2dark"
                @input="atualizarConfiguracao('cor2dark')"
              />
            </q-popup-proxy>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          label="Color 3 Dark:"
          autogrow
          dense
          outlined
          :style="`background: ${textcor1dark}`"
          v-model="textcor1dark"
          input-style="min-height: 6vh; max-height: 9vh;"
          debounce="700"
          :dark="false"
          @input="atualizarConfiguracao('textcor1dark')"
        >
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer q-ml-sm"
              @click="openColorPicker6 = true"
            ></q-icon>
            <q-popup-proxy
              v-model="openColorPicker6"
              transition-show="scale"
              transition-hide="scale"
            >
              <q-color
                format-model="hex"
                square
                default-view="palette"
                no-header
                bordered
                v-model="textcor1dark"
                @input="atualizarConfiguracao('textcor1dark')"
              />
            </q-popup-proxy>
          </template>
        </q-input>
      </div>
    </div>

  </div>
</template>

<script>
import { ListarConfiguracoesGeneral, AlterarConfiguracaoGeneral } from '../../../service/configuracoesgeneral'
import { UploadLogo } from '../../../service/empresas'

export default {
  name: 'ConfiguracoesWhiteLabel',
  data() {
    return {
      fileOptions: [
        { label: 'Logo Pantalla Login 481 x 186  PNG', value: 'login' },
        { label: 'Logo Registro 481 x 186  PNG', value: 'signup' },
        { label: 'Logo Pantalla Atención 481 x 186 PNG', value: 'atendimento' },
        { label: 'Favicon 16x16 PNG', value: 'favicon-16x16' },
        { label: 'Favicon 32x32 PNG', value: 'favicon-32x32' },
        { label: 'Favicon 96x96 PNG', value: 'favicon-96x96' },
        { label: 'Icono 128x128 PNG', value: 'icon-128x128' },
        { label: 'Icono  192x192 PNG', value: 'icon-192x192' },
        { label: 'Icono 256x256 PNG', value: 'icon-256x256' },
        { label: 'Icono 384x384 PNG', value: 'icon-384x384' },
        { label: 'Icono 512x512 PNG', value: 'icon-512x512' },
        { label: 'Icono Favorito ICO', value: 'favicon' }
      ],
      configuracoes: [],
      webhookUrl: '',
      allowSignup: null,
      apienviarwhatsapp: null,
      apiendpoint: '',
      apitoken: '',
      apiexternalKey: '',
      apimessage: '',
      timeTest: '',
      informative: null,
      paymentGateway: null,
      openColorPicker: false,
      openColorPicker2: false,
      openColorPicker3: false,
      openColorPicker4: false,
      openColorPicker5: false,
      openColorPicker6: false,
      efiClientId: '',
      efiClientSecret: '',
      efiPixKey: '',
      title: '',
      filename: '',
      habilitasmtp: '',
      selectedFileType: null,
      fileAcceptType: '',
      whatsappnumber: null,
      cor1: '',
      cor2: '',
      textcor1: '',
      cor1dark: '',
      cor2dark: '',
      textcor1dark: ''
    }
  },
  methods: {
    generateWebhookUrl() {
      return `${process.env.URL_API}/subscription/whazing/webhook/`
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.apimessage
      // obtener la posición del cursor:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filtrar:
      if (!emoji.data) {
        return
      }
      // insertar:
      self.txtContent = this.apimessage
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.apimessage = self.txtContent
      // mover cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    onInsertSelectVariable (variable) {
      const self = this
      var tArea = this.$refs.apimessage
      // obtener la posición del cursor:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filtrar:
      if (!variable) {
        return
      }
      // insertar:
      self.txtContent = this.apimessage
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.apimessage = self.txtContent
      // mover cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    },
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoesGeneral()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        const value = el.value
        this.$data[el.key] = value
      })
    },
    async atualizarConfiguracao(key) {
      const params = {
        key,
        value: this.$data[key]
      }
      try {
        await AlterarConfiguracaoGeneral(params)
        this.$q.notify({
          type: 'positive',
          message: '¡Configuración cambiada!',
          progress: true,
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (error) {
        console.error('error - AlterarConfiguracao', error)
        this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
        this.$notificarErro('¡Ocurrió un error!', error)
      }
    },
    async onFileChangeLogo(event) {
      const file = event.target.files[0]
      if (file) {
        try {
          await UploadLogo(file, this.selectedFileType)
          this.filename = file.name
          this.$q.notify({
            type: 'positive',
            message: '¡Archivo enviado con éxito!',
            progress: true,
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } catch (error) {
          console.error('Error al enviar archivo', error)
          this.$q.notify({
            type: 'negative',
            message: '¡Error al enviar archivo!',
            progress: true,
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        }
      }
    },
    handleFileTypeChange(value) {
      // Actualiza el tipo de archivo aceptado según la selección
      switch (value) {
        case 'login':
        case 'signup':
        case 'atendimento':
        case 'favicon-16x16':
        case 'favicon-96x96':
        case 'icon-128x128':
        case 'icon-192x192':
        case 'icon-256x256':
        case 'icon-384x384':
        case 'icon-512x512':
          this.fileAcceptType = 'image/png'
          break
        case 'favicon':
          this.fileAcceptType = 'image/x-icon'
          break
        default:
          this.fileAcceptType = ''
      }
    }
  },
  async mounted() {
    await this.listarConfiguracoes()
    this.webhookUrl = this.generateWebhookUrl()
  }
}
</script>

<style scoped>

</style>
