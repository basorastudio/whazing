/* eslint-disable */
import Wavoip from "wavoip-api";
import { cloneDeep } from "lodash";
import parsePhoneNumber from "libphonenumber-js";
import { Notify } from "quasar";

const findRecordById = ($state, id) =>
  $state.records.find((record) => record.id === Number(id)) || {};
const webphone = {
  namespaced: true,
  state: {
    records: [],
    uiFlags: {
      isOpen: true,
      isFetching: false,
      isFetchingItem: false,
      isUpdating: false,
      isCheckoutInProcess: false,
    },

    call: {
      id: null,
      contactId: null,
      contact_name: null,
      ticketId: null,
      duration: 0,
      tag: null,
      phone: null,
      picture_profile: null,
      call_id: null,
      status: null,
      direction: null,
      whatsapp_instance: null,
      active_start_date: null,
      inbox_name: null,
      freezeToken: null,
    },
    wavoip: {},
  },
  getters: {
    getAccount: ($state) => (id) => {
      return findRecordById($state, id);
    },
    getUIFlags($state) {
      return $state.uiFlags;
    },
    getCallInfo($state) {
      return $state.call;
    },
    getWavoip($state) {
      return $state.wavoip;
    },
  },
  mutations: {
    SET_WEBPHONE_UI_FLAG($state, data) {
      $state.uiFlags = {
        ...$state.uiFlags,
        ...data,
      };
    },
    ADD_WAVOIP($state, data) {
      const vdata = cloneDeep(data);
      $state.wavoip = {
        ...$state.wavoip,
        [vdata.token]: {
          inbox_name: vdata.inboxName,
          token: vdata.token,
          whatsapp_instance: vdata.whatsapp_instance,
        },
      };
    },
    SET_WEBPHONE_CALL($state, data) {
      $state.call = {
        ...$state.call,
        ...data,
      };
    },

  },
  actions: {
    async startWavoip({ commit, state, dispatch }, { inboxName, token }) {
      if (state.wavoip[token] && token) {
        return;
      }
      console.log(`starting device:${inboxName}-${token}`);
      const WAV = new Wavoip();
      const whatsapp_instance = await WAV.connect(token);

      whatsapp_instance.socket.off("signaling");
      whatsapp_instance.socket.on("signaling", (...args) => {
        const data = args[0];


        if (data.attrs && data.attrs["call-id"]) {
          const callId = data.attrs["call-id"];

          // Atualizar o call_id no estado
          commit("SET_WEBPHONE_CALL", {
            call_id: callId
          });
        }

        if (state.call.inbox_name) {
          if (state.call.inbox_name !== inboxName) {
            return;
          }
        }

        dispatch("updateCallStatus", data?.tag);
        if (data?.tag === "offer") {
          const name = data?.content?.from_tag;
          const whatsapp_id = data?.content?.phone;
          const phone =
            parsePhoneNumber(`+${whatsapp_id}`).formatInternational() ||
            whatsapp_id;
          const profile_picture = data?.content?.profile_picture;

          // Usar o call_id extraído do attrs, se disponível
          const call_id = data.attrs && data.attrs["call-id"];

          dispatch("incomingCall", {
            token: token,
            phone: phone,
            contact_name: name,
            profile_picture: profile_picture,
            call_id: call_id,
          });
        } else if (data?.tag === "terminate") {
          setTimeout(() => {
            dispatch("resetCall");
          }, 3500);
        } else if (data?.tag === "reject") {
          setTimeout(() => {
            dispatch("resetCall");
          }, 3500);
        } else if (data?.tag === "accept_elsewhere") {
          setTimeout(() => {
            dispatch("resetCall");
          }, 3500);
        } else if (data?.tag === "reject_elsewhere") {
          setTimeout(() => {
            dispatch("resetCall");
          }, 3500);
        }
      });

      commit("ADD_WAVOIP", {
        token: token,
        whatsapp_instance: whatsapp_instance,
        inboxName: inboxName,
      });

      whatsapp_instance.socket.on("connect", () => {
        console.log(`Device connected:${inboxName}-${token}`);
      });
      whatsapp_instance.socket.on("disconnect", (reason, details) => {
        console.log(`Device disconnected:${inboxName}-${token}`);
        console.log(`Reason:${reason} Detail:${details}`);
      });
      whatsapp_instance.socket.io.on("error", () => {
        console.error("Erro conectando wavoip!");
      });
    },
    async outcomingCall({ commit, state, dispatch }, callInfo) {

      const { phone, contact_name, ticketId, profile_picture, call_id } = callInfo;
      const instances = callInfo.instances || Object.keys(state.wavoip);
      const token = callInfo.token || instances[0];
      const wavoip = state.wavoip?.[token]?.whatsapp_instance;
      const inbox_name = state.wavoip?.[token]?.inbox_name;

      const freezeToken = callInfo?.freezeToken;

      const currentTicketId = ticketId || state.call.ticketId;

      if (currentTicketId) {
        localStorage.setItem('temp_webphone_ticketId', currentTicketId);
      }

      const remainingInstances = freezeToken
        ? []
        : instances.filter((instance) => instance !== token);

      if (wavoip && !!phone) {
        try {
          // Primeiro, definimos o status como "outcoming_calling" para o UI
          commit("SET_WEBPHONE_CALL", {
            id: token,
            duration: 0,
            tag: contact_name,
            ticketId: currentTicketId,
            phone: phone,
            picture_profile: profile_picture,
            call_id: call_id,
            status: "outcoming_calling",
            direction: "outcoming",
            whatsapp_instance: token,
            inbox_name: inbox_name,
          });

          commit("SET_WEBPHONE_UI_FLAG", {
            isOpen: true,
          });

          // Agora fazemos a chamada e esperamos pela resposta
          const response = await wavoip.callStart({
            whatsappid: phone,
          });

          if (response.type === "success") {
            // Obter call_id, primeiro verificando result.call_id
            const responseCallId = response.result?.call_id;
            const responseProfilePicture = response.result?.profile_picture;

            if (responseCallId) {

              const currentTicketId = state.call.ticketId;

              // Atualizamos com call_id após obter resposta
              commit("SET_WEBPHONE_CALL", {
                call_id: responseCallId,
                picture_profile: responseProfilePicture || profile_picture,
                ticketId: state.call.ticketId || localStorage.getItem('temp_webphone_ticketId'),
              });
            }
          } else {
            // Tratamento de erro
            if (response.result === "Numero não existe") {
              throw new Error(response.result);
            } else if (response.result === "Limite de ligações atingido") {
           //   Notify.create({
            //    position: "top",
           //     type: "negative",
            //    html: true,
           //     progress: true,
           //     message: `Limite de ligações diários atingido`,
          //    });

              // Resetamos a chamada em caso de erro
              dispatch("resetCall");
            }

            // Se ainda há instâncias restantes, tente novamente com a próxima
            if (remainingInstances.length > 0) {
              return dispatch("outcomingCall", {
                ...callInfo,
                instances: remainingInstances,
                token: null,
              });
            } else {
          //    Notify.create({
           //     position: "top",
           //     type: "negative",
            //    html: true,
           //     progress: true,
           //     message: `Linha ocupada, tente mais tarde`,
          //    });
              throw new Error("Linha ocupada, tente mais tarde");
            }
          }
        } catch (error) {
          console.error("Erro na chamada:", error);

          // Tente novamente com outra instância, se disponível
          if (remainingInstances.length > 0) {
            return dispatch("outcomingCall", {
              ...callInfo,
              instances: remainingInstances,
              token: null,
            });
          } else {
          //  Notify.create({
          //    position: "top",
           //   type: "negative",
           //   html: true,
          //    progress: true,
          //    message: `Erro ao realizar chamada: ${error.message || "Desconhecido"}`,
          //  });
            throw error;
          }
        }
      } else {
        // Se não há wavoip ou telefone, notifique o erro
        Notify.create({
          position: "top",
          type: "negative",
          html: true,
          progress: true,
          message: `Não foi possível iniciar a chamada. Verifique a conexão.`,
        });
      }
    },
    async incomingCall({ commit, state, dispatch }, callInfo) {
      try {
        if (state.call.id) {
          dispatch("rejectCall", callInfo.token);
          return;
        }

        const { phone, contact_name, profile_picture, token, call_id } = callInfo;

        const inbox_name = state.wavoip[token].inbox_name;

        commit("SET_WEBPHONE_CALL", {
          id: token,
          duration: 0,
          tag: contact_name,
          phone: phone,
          picture_profile: profile_picture,
          call_id: call_id,
          status: "offer",
          direction: "incoming",
          whatsapp_instance: token,
          inbox_name: inbox_name,
          ticketId: null,
        });

        commit("SET_WEBPHONE_UI_FLAG", {
          isOpen: true,
        });
      } catch (error) {
        throw new Error(error);
      }
    },
    updateCallStatus({ commit, state }, status) {
      // Obtém o call_id atual para preservá-lo na atualização
      const currentCallId = state.call.call_id;
      const currentTicketId = state.call.ticketId;

      commit("SET_WEBPHONE_CALL", {
        status: status,
        ticketId: currentTicketId,
      });

      // Se o status for "accept", definimos active_start_date e preservamos o call_id
      if (status === "accept") {
        commit("SET_WEBPHONE_CALL", {
          active_start_date: new Date(),
          call_id: currentCallId,
          ticketId: state.call.ticketId
        });

      }
    },
    async acceptCall({ state, dispatch, commit }) {
      try {
        const wavoip_token = state.call.whatsapp_instance;
        const wavoip = state.wavoip[wavoip_token].whatsapp_instance;

        // Salvar o call_id antes de aceitar a chamada
        const currentCallId = state.call.call_id;
        const currentTicketId = state.call.ticketId;

        await wavoip.acceptCall();

        dispatch("updateCallStatus", "accept");

        if (currentCallId || currentTicketId) {
          commit("SET_WEBPHONE_CALL", {
            call_id: currentCallId,
            ticketId: currentTicketId,
          });

        }

      } catch (error) {
        console.error(error);
        // Ignore error
      }
    },
    async rejectCall({ state, dispatch }, token) {
      try {
        const wavoip_token = token || state.call.whatsapp_instance;
        const wavoip = state.wavoip[wavoip_token].whatsapp_instance;
        dispatch("resetCall");
        await wavoip.rejectCall();
      } catch (error) {
        console.error("rejectCall error:", error);
        // Ignore error
      }
    },
    async endCall({ state }) {
      try {

              const wavoip_token = state.call?.id || state.call?.whatsapp_instance || state.call?.token;

        if (!wavoip_token) {
          console.warn("No valid token or wavoip instance found to end call");
          return;
        }

        const wavoip = state.wavoip[wavoip_token]?.whatsapp_instance;

        if (wavoip) {
          await wavoip.endCall();
        }
      } catch (error) {
        console.error("endCall error:", error);
        // Ignore error
      }
    },
    async resetCall({ commit }) {
      const data = {
        id: null,
        duration: 0,
        tag: null,
        phone: null,
        picture_profile: null,
        call_id: null,
        status: null,
        direction: null,
        whatsapp_instance: null,
        active_start_date: null,
        inbox_name: null,
        ticketId: null,
        freezeToken: null,
      };
      commit("SET_WEBPHONE_CALL", data);
      localStorage.setItem("wavo_call_info", JSON.stringify(data));
    },
    async mute({ state, dispatch }, token) {
      try {
        const wavoip_token = token || state.call.whatsapp_instance;
        const wavoip = state.wavoip[wavoip_token].whatsapp_instance;

        await wavoip.mute();
      } catch (error) {
        // Ignore error
      }
    },
    async unMute({ state, dispatch }, token) {
      try {
        const wavoip_token = token || state.call.whatsapp_instance;
        const wavoip = state.wavoip[wavoip_token].whatsapp_instance;

        await wavoip.unMute();
      } catch (error) {
        // Ignore error
      }
    },
    updateWebphoneVisible({ commit }, { isOpen }) {
      commit("SET_WEBPHONE_UI_FLAG", {
        isOpen: isOpen,
      });
    },
    openWebphoneFromStore({ commit }) {
      commit("SET_WEBPHONE_UI_FLAG", {
        isOpen: true,
      });
    },
  },
};

export default webphone;
