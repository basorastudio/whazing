<template>
  <q-dialog persistent :value="modalAjuda" @hide="fecharModal" @show="abrirModal">
    <q-card class="container-rounded-10 modal-container q-pa-lg">

       <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ ajudaEdicao.id ? 'Editar' : 'Crear' }} Ayuda
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <div class="container-border container-rounded-10">

      <q-card-section class="row flex-gap-1 q-col-gutter-sm">
        <div class="text-h6 font-family-main">
          Información
        </div>
        <div class="flex-gap-1 full-width row q-col-gutter-sm">
          <div class="full-width">
            <c-input rounded outlined v-model="ajuda.title" label="Título" />
          </div>
          <div class="full-width">
            <c-input rounded outlined v-model="ajuda.description" label="Descripción" />
          </div>
          <div class="full-width">
            <q-select
              rounded
              outlined
              v-model="ajuda.type"
              :options="typeOptions"
              label="Tipo de contenido"
              emit-value
              map-options
              @input="ajustarContenido"
            />
          </div>
          <div class="full-width">
            <c-input 
              rounded 
              outlined 
              v-model="ajuda.video" 
              :label="ajuda.type === 'youtube' ? 'Código del Vídeo de YouTube' : 'URL completa del iframe'" 
            />
            <div v-if="ajuda.type === 'kroto'" class="text-caption text-grey q-mt-xs">
              Formato: https://app.kroto.one/embed/knowledge-base/... (URL completa)
            </div>
          </div>
        </div>
      </q-card-section>
      </div>
      <q-card-actions align="right">
        <q-btn
          label="Cancelar"
          class="q-px-md q-mr-sm btn-rounded-50"
          color="negative"
          v-close-popup
        />
        <q-btn
          label="Guardar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          icon="eva-save-outline"
          @click="handleAjuda"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { UpdateHelp, CriarHelp } from '../../../service/help'
export default {
  name: 'ModalAjuda',
  props: {
    modalAjuda: {
      type: Boolean,
      default: false
    },
    ajudaEdicao: {
      type: Object,
      default: () => {
        return { id: null }
      }
    }
  },
  data() {
    return {
      ajuda: {
        id: null,
        title: null,
        description: null,
        video: null,
        type: 'youtube'
      },
      typeOptions: [
        { label: 'Video de YouTube', value: 'youtube' },
        { label: 'Contenido embebido (iframe)', value: 'kroto' }
      ]
    }
  },
  methods: {
    resetarAjuda() {
      this.ajuda = {
        id: null,
        title: null,
        description: null,
        video: null,
        type: 'youtube'
      }
    },
    ajustarContenido(type) {
      // Limpiar el campo al cambiar el tipo
      this.ajuda.video = null;
    },
    fecharModal() {
      this.resetarAjuda()
      this.$emit('update:ajudaEdicao', { id: null })
      this.$emit('update:modalAjuda', false)
    },
    abrirModal() {
      if (this.ajudaEdicao.id) {
        this.ajuda = { ...this.ajudaEdicao }
        // Si es una ayuda creada anteriormente sin tipo, establecer por defecto
        if (!this.ajuda.type) {
          // Detectamos el tipo según el formato del valor en video
          if (this.ajuda.video && (this.ajuda.video.includes('http://') || this.ajuda.video.includes('https://'))) {
            this.ajuda.type = 'kroto';
          } else {
            this.ajuda.type = 'youtube';
          }
        }
      } else {
        this.resetarAjuda()
      }
    },
    async handleAjuda() {
      try {
        this.loading = true
        
        // Validación para asegurar datos correctos
        if (!this.ajuda.video) {
          this.$q.notify({
            type: 'negative',
            progress: true,
            position: 'top',
            message: this.ajuda.type === 'kroto' 
              ? 'Por favor ingrese la URL completa del iframe' 
              : 'Por favor ingrese el código del video de YouTube',
            actions: [{ icon: 'close', round: true, color: 'white' }]
          });
          this.loading = false;
          return;
        }

        // Para YouTube, verificamos que solo se ingrese el código del video, no la URL completa
        if (this.ajuda.type === 'youtube' && (this.ajuda.video.includes('youtube.com') || this.ajuda.video.includes('youtu.be'))) {
          // Intentamos extraer solo el ID del video
          let videoId = this.ajuda.video;
          
          if (this.ajuda.video.includes('youtube.com/watch?v=')) {
            videoId = this.ajuda.video.split('v=')[1];
          } else if (this.ajuda.video.includes('youtu.be/')) {
            videoId = this.ajuda.video.split('youtu.be/')[1];
          }
          
          // Si hay parámetros adicionales, los eliminamos
          if (videoId.includes('&')) {
            videoId = videoId.split('&')[0];
          }
          
          this.ajuda.video = videoId;
        }

        // Continuar con el guardado
        if (this.ajuda.id) {
          const { data } = await UpdateHelp(this.ajuda.id, this.ajuda)
          this.$emit('modal-ajuda:editada', data)
          this.$q.notify({
            type: 'info',
            progress: true,
            position: 'top',
            textColor: 'black',
            message: 'Ayuda editada!',
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else {
          const { data } = await CriarHelp(this.ajuda)
          this.$emit('modal-ajuda:criada', data)
          this.$q.notify({
            type: 'positive',
            progress: true,
            position: 'top',
            message: 'Ayuda creada!',
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        }
        this.loading = false
        this.fecharModal()
      } catch (error) {
        console.error(error)
        this.$notificarErro('¡Ocurrió un error!', error)
      }
    }
  }

}
</script>

<style lang="scss" scoped>
</style>
