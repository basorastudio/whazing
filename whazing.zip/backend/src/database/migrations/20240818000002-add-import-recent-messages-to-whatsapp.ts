import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'importRecentMessages' column to the 'Whatsapps' table
    // This likely stores data related to importing recent messages.
    await queryInterface.addColumn(
      'Whatsapps',              // Table name
      'importRecentMessages',   // New column name
      {
        type: DataTypes.TEXT, // TEXT allows storing larger amounts of data (e.g., status, progress, config)
        // allowNull defaults to true
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'importRecentMessages' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps',              // Table name
      'importRecentMessages'    // Column name to remove
    );
  }
};

export = migration;