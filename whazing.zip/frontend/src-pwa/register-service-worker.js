import { register } from 'register-service-worker'

register(process.env.SERVICE_WORKER_FILE, {
  ready() {
    console.log('El service worker está activo.')
  },
  registered() {
    console.log('El service worker ha sido registrado.')
  },
  cached() {
    console.log('El contenido ha sido cacheado para uso sin conexión.')
  },
  updatefound() {
    console.log('Nuevo contenido se está descargando.')
  },
  updated() {
    console.log('Nuevo contenido está disponible; por favor refresca.')
  },
  offline() {
    console.log('No se encontró conexión a internet. La aplicación está funcionando en modo sin conexión.')
  },
  error(err) {
    console.error('Error durante el registro del service worker:', err)
  }
})
