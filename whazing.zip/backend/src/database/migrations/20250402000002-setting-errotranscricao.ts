import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert transcription error message setting into 'SettingsGeneral'
    const errorMessage = 'Error al intentar transformar audio en texto'; // Translated message
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('errotranscricao', '${errorMessage.replace(/'/g, "''")}', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `); // Escaping single quotes
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted transcription error message setting
    await queryInterface.bulkDelete(
      'SettingsGeneral', // Adjust schema if needed
      {
        key: ['errotranscricao']
      }
    );
  }
};

export = migration;