import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default
} from "sequelize-typescript";
import { v4 as uuidv4 } from "uuid";
import User from "./User";
import Tenant from "./Tenant";
import Whatsapp from "./Whatsapp";

// @Table decorator was missing in the original deobfuscated code, adding it.
@Table
class ApiConfig extends Model<ApiConfig> {
  @PrimaryKey
  @Default(uuidv4) // Use uuidv4 for default
  @Column(DataType.UUID) // Use UUID type
  id: string;

  @ForeignKey(() => Whatsapp)
  @Column
  sessionId: number; // Assuming 'session' mapped to sessionId (FK to Whatsapp)

  @BelongsTo(() => Whatsapp)
  session: Whatsapp; // Relation name

  @Column
  name: string;

  @Default(true)
  @Column
  isActive: boolean;

  @Column
  token: string; // Assuming 'authToken' mapped to 'token'

  @Column
  urlServiceStatus: string; // 'urlService' likely mapped to this

  @Column
  urlMessageStatus: string; // 'urlMessage' likely mapped to this

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @CreatedAt
  @Column(DataType.DATE(6)) // Specify precision if needed
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6)) // Specify precision if needed
  updatedAt: Date;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;
}

export default ApiConfig;