// --- START OF FILE 20231020184502-alter_table_tenant_ownerId.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Tenants';
        const columnName = 'ownerId';
        const constraintName = 'Tenants_ownerId_fkey'; // 'Tenants_ow' + 'nerId_fkey'

        // 1. Remove existing constraint if it exists (to modify the column)
        try {
            await queryInterface.removeConstraint(tableName, constraintName);
        } catch (error) {
            // Ignore if constraint doesn't exist
             console.log(`Constraint ${constraintName} not found or already removed, continuing.`);
             // Check specific error code if needed (e.g., 42704 for PostgreSQL)
             // const dialect = queryInterface.sequelize.getDialect();
             // if (dialect === 'postgres' && (error as any).original?.code !== '42704') {
             //     throw error; // Re-throw unexpected errors
             // }
        }


        // 2. Change the column to allow NULL and set onDelete to CASCADE
         // Ensure the column exists before changing it
         const tableDescription = await queryInterface.describeTable(tableName);
         if (tableDescription && tableDescription[columnName]) {
            await queryInterface.changeColumn(tableName, columnName, {
                type: DataTypes.INTEGER, // Original INTEGER
                 // References kept same ('Tenants' self-reference assumed, adjust if 'Users')
                 // Assuming ownerId refers to the Users table instead of self-referencing Tenants
                references: {
                    model: 'Users', // Changed from 'Tenants' to 'Users' based on typical use case
                    key: 'id'
                },
                onUpdate: 'CASCADE', // Original 'CASCADE'
                onDelete: 'CASCADE', // Original 'CASCADE' (changed from implied RESTRICT/NO ACTION)
                allowNull: true // Changed from implicit false (PK/FK constraint?) to true
            });
         } else {
             console.error(`Column ${columnName} not found in table ${tableName}. Cannot change column.`);
             // If the column doesn't exist, perhaps it should be added instead?
             // await queryInterface.addColumn(tableName, columnName, { ... });
         }

         // Note: Re-adding the constraint explicitly is often unnecessary after changeColumn
         // if references are specified correctly. Sequelize usually handles it.
         // If needed: await queryInterface.addConstraint(tableName, { fields: [columnName], type: 'foreign key', ... });

    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        // Reverting requires setting allowNull back to false and potentially changing onDelete.
        // !! IMPORTANT !! Reverting allowNull to false might fail if NULL values exist.
        const tableName = 'Tenants';
        const columnName = 'ownerId';
        const constraintName = 'Tenants_ownerId_fkey'; // Consistent name

        // Revert the column changes
        // Remove constraint first if it was potentially re-added or handled differently
        try {
            await queryInterface.removeConstraint(tableName, constraintName);
        } catch (error) {
            console.log(`Constraint ${constraintName} not found or already removed during rollback.`);
        }

         const tableDescription = await queryInterface.describeTable(tableName);
         if (tableDescription && tableDescription[columnName]) {
             try {
                 await queryInterface.changeColumn(tableName, columnName, {
                    type: DataTypes.INTEGER,
                    references: {
                        model: 'Users', // Assuming it was Users before
                        key: 'id'
                    },
                    onUpdate: 'CASCADE',
                    onDelete: 'NO ACTION', // Or RESTRICT - Reverting from CASCADE requires care
                    allowNull: false // Reverting to false - potential data issue
                });
             } catch (error) {
                 console.error(`Error reverting ${columnName} column: ${(error as Error).message}. Check for NULL values.`);
                 // Decide how to handle error (e.g., update NULLs first, then change)
             }
         } else {
             console.error(`Column ${columnName} not found in table ${tableName} during rollback.`);
         }

         // Optionally re-add the constraint if the original state required it explicitly named
         // await queryInterface.addConstraint(tableName, { fields: [columnName], type: 'foreign key', name: constraintName, references: ..., onDelete: 'NO ACTION', onUpdate: 'CASCADE' });
    }
};

export default migration;
// --- END OF FILE 20231020184502-alter_table_tenant_ownerId.ts ---