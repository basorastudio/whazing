// Original: CheckContactOpenTickets.js
// Deobfuscated, converted to TS, and translated

'use strict';

import { Op } from 'sequelize';
import AppError from '../errors/AppError'; // Asumiendo que AppError es la exportación predeterminada
import Ticket from '../models/Ticket'; // Asumiendo que Ticket es la exportación predeterminada

// Interfaz para los parámetros de la función
interface CheckContactOpenTicketsParams {
  contactId: number;
  whatsappId: number;
}

// Define el tipo de retorno de la función como Promise<void>
const CheckContactOpenTickets = async (
  contactId: number,
  whatsappId: number | string // Permitir string si whatsappId puede venir así de la fuente original
): Promise<void> => {

  const whereOptions = {
    [Op.or]: [
      { status: 'open' },
      { status: 'pending' }
    ]
  };

  // Asegurarse de que whatsappId sea un número si es necesario para la consulta
  const numericWhatsappId = typeof whatsappId === 'string' ? parseInt(whatsappId, 10) : whatsappId;
  if (isNaN(numericWhatsappId)) {
     throw new AppError('ERR_INVALID_WHATSAPP_ID', 400); // Error si whatsappId no es convertible a número
  }


  const ticket = await Ticket.findOne({
    where: {
      ...whereOptions,
      contactId: contactId,
      whatsappId: numericWhatsappId // Usar el ID numérico
    }
  });

  if (ticket) {
    // Traducido: Error ya existe un ticket abierto para este contacto.
    throw new AppError(
      JSON.stringify(ticket), // Puede ser útil mantener el objeto ticket en el error para depuración
      409 // Código de conflicto HTTP
    );
  }
};

export default CheckContactOpenTickets; // Usar export default