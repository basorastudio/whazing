import { QueryInterface } from "sequelize";

export default {
  up: (queryInterface: QueryInterface) => {
    return queryInterface.sequelize.query(`
          INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('errodownloadmedia', '*Mensaje del sistema*:\nFallo en la descarga del medio, verifique en el dispositivo', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
          INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('emailsubjectemail', 'Recuperación de Contraseña', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
          INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('emailtop', 'Redefinición de Contraseña', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
          INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('emaillinha1', 'Usted solicitó la recuperación de contraseña del panel', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
          INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('emaillinha2', 'Código de Verificación:', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
          INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('emaillinha3', 'Está con dudas?', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
          INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('emaillinha4', 'Entre en contacto ahora mismo con nosotros.', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
          INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('emaillinha5', 'Entre en contacto por WhatsApp!', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      `);
  },

  down: (queryInterface: QueryInterface) => {
    // Elimina las configuraciones específicas insertadas en 'up'
    return queryInterface.bulkDelete("SettingsGeneral", {
      key: [
        "errodownloadmedia",
        "emailsubjectemail",
        "emailtop",
        "emaillinha1",
        "emaillinha2",
        "emaillinha3",
        "emaillinha4",
        "emaillinha5"
      ]
    });
  }
};
