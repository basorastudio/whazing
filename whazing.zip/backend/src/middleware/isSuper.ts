/**
 * Middleware para verificar si el usuario es 'admin' Y pertenece al tenantId 1 (superadministrador).
 */
import { Response, NextFunction } from "express";
import AppError from "../errors/AppError";
import User from "../models/User";
import { AuthRequest } from "./interfaces/AuthRequest"; // Importa la interfaz

const isSuper = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  // Asume que req.user.id y req.user.tenantId están disponibles
  if (!req.user?.id || req.user?.tenantId === undefined) {
    // Verifica también tenantId
    throw new AppError("Autenticación requerida o incompleta.", 401);
  }

  const tenantId = req.user.tenantId;

  // Busca el usuario para obtener el perfil actualizado (aunque ya podría estar en req.user)
  // Podríamos optimizar y usar req.user.profile si isAuth siempre lo añade.
  const user = await User.findByPk(req.user.id);

  if (!user) {
    throw new AppError("Usuario no encontrado.", 404);
  }

  const profile = user.profile; // Asume propiedad 'profile'

  // Verifica si el perfil NO es 'admin' O si el tenantId NO es 1
  // Nota: Asegúrate de comparar tenantId con el tipo correcto (número 1, no string '1')
  if (profile !== "admin" || tenantId !== 1) {
    // Si no cumple ambas condiciones, lanza error (Forbidden)
    throw new AppError("Acceso no permitido", 403); // 403 Forbidden
  }

  // Si es admin y pertenece al tenant 1, permite continuar
  return next();
};

export default isSuper; // Exportación default
