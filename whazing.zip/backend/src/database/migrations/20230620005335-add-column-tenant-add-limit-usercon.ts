// --- START OF FILE 20230620005335-add-column-tenant-add-limit-usercon.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Tenants';
        const maxUsersColumn = 'maxUsers';
        const maxConnectionsColumn = 'maxConnections'; // 'maxConnect' + 'ions'

        const tableDescription = await queryInterface.describeTable(tableName);

        if (!tableDescription || !tableDescription[maxUsersColumn]) {
            const attributes = {
                type: DataTypes.INTEGER,
                allowNull: true // Changed !![] to true
                // defaultValue wasn't specified in the original for adding, assuming null is ok
            };
            await queryInterface.addColumn(tableName, maxUsersColumn, attributes);
        } else {
            console.log(`La columna ${maxUsersColumn} ya existe en la tabla ${tableName}. Saltando adición.`);
        }

        if (!tableDescription || !tableDescription[maxConnectionsColumn]) {
            const attributes = {
                type: DataTypes.INTEGER,
                allowNull: true // Changed !![] to true
                // defaultValue wasn't specified in the original for adding, assuming null is ok
            };
            await queryInterface.addColumn(tableName, maxConnectionsColumn, attributes);
         } else {
            console.log(`La columna ${maxConnectionsColumn} ya existe en la tabla ${tableName}. Saltando adición.`);
        }
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Tenants';
        const maxUsersColumn = 'maxUsers';
        const maxConnectionsColumn = 'maxConnections'; // 'maxConnect' + 'ions'

        // Remove columns if they exist
        const tableDescription = await queryInterface.describeTable(tableName);

        if (tableDescription && tableDescription[maxUsersColumn]) {
            await queryInterface.removeColumn(tableName, maxUsersColumn);
        } else {
             console.log(`La columna ${maxUsersColumn} no existe en la tabla ${tableName}. Saltando eliminación.`);
        }

        if (tableDescription && tableDescription[maxConnectionsColumn]) {
            await queryInterface.removeColumn(tableName, maxConnectionsColumn);
        } else {
             console.log(`La columna ${maxConnectionsColumn} no existe en la tabla ${tableName}. Saltando eliminación.`);
        }
    }
};

export default migration;

// --- END OF FILE 20230620005335-add-column-tenant-add-limit-usercon.ts ---