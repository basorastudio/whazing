// --- START OF FILE 20230520005335-alter_table_Whatsapps_add_chatFlowId.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Whatsapps';
        const columnName = 'chatFlowId';
        const attributes = {
            type: DataTypes.INTEGER,
            references: {
                model: 'ChatFlow', // Target table name
                key: 'id'
            },
            onUpdate: 'CASCADE', // Original 'CASCADE'
            onDelete: 'SET NULL', // Original 'SET NULL'
            allowNull: true, // Changed !![] to true
            defaultValue: null
        };
        await queryInterface.addColumn(tableName, columnName, attributes);
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Whatsapps';
        const columnName = 'chatFlowId';
        await queryInterface.removeColumn(tableName, columnName);
    }
};

export default migration;

// --- END OF FILE 20230520005335-alter_table_Whatsapps_add_chatFlowId.ts ---