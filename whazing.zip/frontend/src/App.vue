<template>
  <div id="q-app">
    <router-view />
  </div>
</template>
<script>
export default {
  name: 'App',
  data () {
    return {
      IDLE_TIMEOUT: 1800, // seconds
      idleSecondsCounter: 0,
      allowedDomains: [
        'https://multiagente.net',
        '*' // Permite todos los dominios. Elimina esta línea si quieres restringir a dominios específicos
      ]
    }
  },
  methods: {
    CheckIdleTime () {
      this.idleSecondsCounter++
      if (this.idleSecondsCounter >= this.IDLE_TIMEOUT) {
        window.location.reload()
      }
    },
    bindEventListeners() {
      document.onclick = () => {
        this.idleSecondsCounter = 0
      }
      document.onmousemove = () => {
        this.idleSecondsCounter = 0
      }
      document.onkeypress = () => {
        this.idleSecondsCounter = 0
      }
    },
    notifyParentUrl() {
      // Notify parent window about current URL
      if (window.parent !== window) {
        // Si allowedDomains incluye '*', permite todos los dominios
        if (this.allowedDomains.includes('*')) {
          window.parent.postMessage({ currentUrl: window.location.href }, '*')
        } else {
          // Envía el mensaje a todos los dominios permitidos
          this.allowedDomains.forEach(domain => {
            window.parent.postMessage({ currentUrl: window.location.href }, domain)
          })
        }
      }
    }
  },
  watch: {
    '$route': {
      handler() {
        this.notifyParentUrl()
      },
      immediate: true
    }
  },
  beforeMount() {
    const usuario = JSON.parse(localStorage.getItem('usuario'))
    if (usuario?.configs?.isDark) {
      this.$q.dark.set(usuario?.configs?.isDark)
    }
    this.bindEventListeners()
    setInterval(this.CheckIdleTime, 1000)
    // Initial URL notification
    this.notifyParentUrl()
  }
}
</script>
