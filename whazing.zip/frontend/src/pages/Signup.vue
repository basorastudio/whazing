<template>
  <div class="container">
    <div class="login-section"  :class="$q.dark.isActive ? 'bg-black' : ''">
      <q-layout class="full-width">
        <q-page-container>
          <q-page class="flex justify-center items-center">
            <q-ajax-bar
              position="top"
              class="color-light2"
              size="5px"
            />
            <div class="login-content">
              <q-img
                :src="generateMediaUrl()"
                spinner-color="white"
                class="logo-image q-mb-lg q-px-md"
                style="max-width: 100%"
              />
              <q-separator spaced />
              <div class="text-primary">
                <div>
              <!-- Nombre de la Empresa -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                v-model="form.nomeEmpresa"
                placeholder="Nombre de la Empresa"
                outlined
              >
                <!-- Ícono para Nombre de la Empresa -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-domain"
                    class="cursor-pointer color-light1"
                  />
                </template>
              </q-input>

              <!-- para mostrar campo cnpj quite esta línea
                  <q-input
                    rounded
                    :color="$q.dark.isActive ? 'white ' : 'black'"
                    class="q-mb-md"
                    clearable
                mask="##.###.###/####-##"
                v-model="form.cnpj"
                placeholder="CNPJ"
                outlined
              >

                <template v-slot:prepend>
                  <q-icon
                    name="mdi-numeric-0-box-outline"
                    class="cursor-pointer"
                    color="primary"
                  />
                </template>
              </q-input>
              para mostrar campo cnpj quite esta línea -->
              <!-- whatsapp -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                mask="(##)#####-####"
                v-model="form.whatsapp"
                placeholder="Whatsapp"
                outlined
              >
                <!-- Ícono para whatsapp -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-whatsapp"
                    class="cursor-pointer color-light1"
                  />
                </template>
              </q-input>

              <!-- nombreResponsable -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                v-model="form.nomeResponsavel"
                placeholder="Nombre del Responsable"
                outlined
              >
                <!-- Ícono para nombreResponsable -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-account-star"
                    class="cursor-pointer color-light1"
                  />
                </template>
              </q-input>

              <!-- email -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                v-model="form.email"
                placeholder="mi@email.com"
                :error="$v.form.email.$error"
                error-message="Debe ser un email válido."
                outlined
              >
                <!-- Ícono para email -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-email-outline"
                    class="cursor-pointer color-light1"
                  />
                </template>
              </q-input>

              <!-- contraseña -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                placeholder="CONTRASEÑA"
                v-model="form.password"
                :type="isPwd ? 'password' : 'text'"
                @keypress.enter="fazerLogin"
                outlined
              >
                <!-- Ícono para contraseña -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-shield-key-outline"
                    class="cursor-pointer color-light1"
                  />
                </template>
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'visibility_off' : 'visibility'"
                    class="cursor-pointer color-light1"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>

              <!-- Plan (selección) -->
              <q-select
                rounded
                class="q-mb-md"
                clearable
                v-model="form.plano"
                :options="options"
                label="Plan"
                outlined
              />
            </div>
              <q-btn
                class="q-mr-sm q-my-lg generate-button btn-rounded-50 color-light2"
                style="width: 150px"
                :loading="loading"
                @click="handleTenant"
              >
                Registrarse
              </q-btn>

            <q-btn
              flat
              color="info"
              no-caps
              dense
              class="q-px-sm color-light1"
              label="¿Ya tienes una cuenta? ¡Inicia sesión!"
              @click="redirecionarParaLogin"
            />
              </div>
            </div>
          </q-page>
        </q-page-container>
      </q-layout>
    </div>

    <q-btn
      v-if="whatsappNumber"
      fab
      icon="mdi-whatsapp"
      class="whatsapp-float"
      color="green"
      round
      @click="abrirWhatsApp"
    >
      <q-tooltip>
        ¡Solicitar soporte!
      </q-tooltip>
    </q-btn>
  </div>
</template>

<script>
import { required, email, minLength } from 'vuelidate/lib/validators'
import { listPlanosPublic } from 'src/service/plans'
import { CriarTeste } from 'src/service/empresas'
import { ListarConfiguracaoPublica, ListarCores } from 'src/service/configuracoesgeneral'

export default {
  name: 'Signup',
  data() {
    return {
      isPwd: true,
      loading: false,
      form: {
        nomeEmpresa: '',
        cnpj: '',
        whatsapp: '',
        nomeResponsavel: '',
        email: '',
        password: '',
        plano: null,
        whatsappNumber: null
      },
      planos: []
    }
  },
  computed: {
    options() {
      return this.formattedPlanos()
    }
  },
  validations: {
    form: {
      email: { required, email },
      password: { required, minLength: minLength(6) },
      nomeEmpresa: { required },
      whatsapp: { required },
      nomeResponsavel: { required },
      plano: { required }
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores devueltos por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Error al buscar configuraciones:', error)
      }
    },
    generateMediaUrl() {
      return `${process.env.URL_API}/public/logos/signup.png`
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Hola%21+tengo+dudas+prueba`
        window.open(url, '_blank') // Abre WhatsApp en una nueva pestaña
      }
    },
    async fetchPlanData() {
      try {
        const response = await listPlanosPublic()
        this.planos = response.data
      } catch (error) {
        console.error('Error fetching plan data:', error)
      }
    },
    formattedPlanos() {
      const formatted = this.planos.map(plan => ({
        label: `${plan.name} - Agentes: ${plan.maxUsers} - Canales: ${plan.maxConnections} - R$ ${plan.value.toFixed(2).replace('.', ',')}`,
        value: plan.id,
        maxUsers: plan.maxUsers,
        maxConnections: plan.maxConnections
      }))
      return formatted
    },
    redirecionarParaLogin() {
      this.$router.push('/login')
    },
    async handleTenant() {
      if (this.$v.form.$invalid) {
        this.$v.$touch()
        this.$q.notify('Introduzca todos los datos correctamente.')
        return
      }
      const data = {
        name: this.form.nomeResponsavel,
        email: this.form.email,
        password: this.form.password,
        tenantName: this.form.nomeEmpresa,
        cnpj: this.form.cnpj,
        phone: this.form.whatsapp,
        plano: this.form.plano
      }

      this.loading = true

      try {
        await CriarTeste(data)
        this.$q.notify({
          type: 'positive',
          message: 'Prueba registrada con éxito.',
          position: 'top',
          progress: true,
          actions: [{ icon: 'close', round: true, color: 'white' }]
        })
        // Redirige a la página de login después del éxito
        this.redirecionarParaLogin()
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: 'Error al registrar prueba. Inténtelo de nuevo.',
          position: 'top',
          progress: true,
          actions: [{ icon: 'close', round: true, color: 'white' }]
        })
        console.error('Error creating tenant:', error)
      } finally {
        this.loading = false
      }
    },
    clear() {
      this.form.email = ''
      this.form.password = ''
      this.$v.form.$reset()
    }
  },
  mounted() {
    this.loadColors()
    this.fetchConfigurations()
    this.fetchPlanData()
  }
}
</script>

<style scoped>
.container {
  display: flex;
  height: 150vh;
  width: 100vw;
  justify-content: center;
  align-items: center;
}

.login-section {
  width: 400px;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  background-color: white;
  border-radius: 10px
}

.full-width {
  width: 100%;
}

.login-content {
  text-align: center;
}

.video-container {
  display: flex;
  justify-content: flex-end;
  width: 55%;
}

.logo-image {
  height: auto;
  max-width: 100%;
}

.fixed-layout {
  width: 45%;
}

.whatsapp-float {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 1000;
  border-radius: 50%; /* Deja el contorno redondeado */
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s;
}

.whatsapp-float:hover {
  transform: scale(1.1);
}

</style>
