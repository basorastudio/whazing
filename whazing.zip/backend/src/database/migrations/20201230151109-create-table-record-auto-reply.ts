import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla 'AutoReplyLogs' para registrar los logs de respuestas automáticas
    return queryInterface.createTable("AutoReplyLogs", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      autoReplyId: {
        type: DataTypes.INTEGER,
        allowNull: false // ID de la respuesta automática
      },
      autoReplyName: {
        type: DataTypes.STRING, // Nombre de la respuesta automática
        allowNull: false
      },
      stepsReplyId: {
        type: DataTypes.INTEGER, // ID del paso de la respuesta
        allowNull: false
      },
      stepsReplyMessage: {
        type: DataTypes.STRING, // Mensaje del paso de la respuesta
        allowNull: false
      },
      wordsReply: {
        type: DataTypes.STRING, // Palabras clave asociadas al paso
        allowNull: false
      },
      contactId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Contacts", // Referencia a la tabla Contacts
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "restrict" // No permite eliminar el contacto si tiene logs
      },
      ticketId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Tickets", // Referencia a la tabla Tickets
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "restrict", // No permite eliminar el ticket si tiene logs
        allowNull: false // No puede ser nulo
      },
      createdAt: {
        type: DataTypes.DATE(6), // Fecha con precisión de microsegundos
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE(6), // Fecha con precisión de microsegundos
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la tabla 'AutoReplyLogs'
    return queryInterface.dropTable("AutoReplyLogs");
  }
};
