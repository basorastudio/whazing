import {
    Table,
    Column,
    Model,
    PrimaryKey,
    ForeignKey,
    BelongsTo,
    CreatedAt,
    UpdatedAt,
    DataType
  } from "sequelize-typescript";
import Whatsapp from "./Whatsapp"; // Assuming it relates to Whatsapp

@Table({ timestamps: false }) // Added timestamps: false based on original options
class BaileysKeys extends Model<BaileysKeys> {
    @PrimaryKey
    @ForeignKey(() => Whatsapp)
    @Column(DataType.INTEGER) // Assuming integer ID for Whatsapp
    whatsappId: number;

    @BelongsTo(() => Whatsapp)
    whatsapp: Whatsapp;

    @PrimaryKey
    @Column(DataType.TEXT) // Assuming TEXT for key type identifier
    type: string;

    @PrimaryKey
    @Column(DataType.TEXT) // Assuming TEXT for key ID
    key: string;

    @Column(DataType.TEXT) // Assuming TEXT for potentially large key data
    value: string;

    @CreatedAt // Still included, though timestamps are false for the table
    createdAt: Date;

    @UpdatedAt // Still included, though timestamps are false for the table
    updatedAt: Date;
}

export default BaileysKeys;