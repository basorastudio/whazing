import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'BussinessHoursRetries' column to the 'Tickets' table
    await queryInterface.addColumn(
      "Tickets", // Table name
      "BussinessHoursRetries", // New column name (Note: unusual capitalization, kept from original)
      {
        type: DataTypes.INTEGER,
        allowNull: false, // Does not allow null values
        defaultValue: 0 // Default value is 0
      }
    );
    // Original code wrapped this in Promise.all([ ... ]), but it's unnecessary.
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'BussinessHoursRetries' column from the 'Tickets' table
    await queryInterface.removeColumn(
      "Tickets", // Table name
      "BussinessHoursRetries" // Column name to remove
    );
    // Original code wrapped this in Promise.all([ ... ]), but it's unnecessary.
  }
};

export = migration;
