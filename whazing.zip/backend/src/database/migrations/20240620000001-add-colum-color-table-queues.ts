// --- START OF FILE 20240620000001-add-colum-color-table-queues.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Queues";
    const columnName = "color"; // Original column name
    const attributes = {
      type: DataTypes.STRING, // Original STRING
      allowNull: true, // Changed !![] to true
      defaultValue: null
    };
    await Promise.all([
      queryInterface.addColumn(tableName, columnName, attributes)
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Queues";
    const columnName = "color";
    await Promise.all([queryInterface.removeColumn(tableName, columnName)]);
  }
};

export default migration;

// --- END OF FILE 20240620000001-add-colum-color-table-queues.ts ---
