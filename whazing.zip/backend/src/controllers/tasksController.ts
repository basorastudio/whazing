import { Request, Response, NextFunction } from 'express'; // Añade NextFunction si se usa
import * as Yup from 'yup';
import AppError from '../errors/AppError';
import CreateTasksService from '../services/TasksServices/CreateTasksService';
import ListTasksService from '../services/TasksServices/ListTasksService';
import DeleteTasksService from '../services/TasksServices/DeleteTasksService';
import UpdateTasksService from '../services/TasksServices/UpdateTasksService';
import GetTaskSummaryService from '../services/TasksServices/GetTaskSummaryService';

// Interfaz para el cuerpo de la solicitud de creación/actualización
interface TaskBody {
    name?: string;
    description?: string;
    owner?: string; // ¿ID de usuario o nombre? Asumiendo string por ahora
    priority?: string; // ¿Enum o string? Asumiendo string
    status?: string; // ¿Enum o string? Asumiendo string
    // userId y tenantId se añadirán internamente
}

// Interfaz para los parámetros de consulta de la lista
interface ListTasksQuery {
    status?: string;
}

// Extiende la interfaz Request
interface TaskRequest extends Request {
    user?: {
        id: string | number;
        tenantId: string | number;
        profile: string; // Asumiendo que profile existe
    };
    body: TaskBody;
    query: ListTasksQuery;
    params: {
        id?: string; // ID de la tarea para update/delete
    };
}

// Esquema de validación para creación/actualización
// Ajusta los tipos según sea necesario (e.g., priority podría ser number)
const taskSchema = Yup.object().shape({
    name: Yup.string().required(),
    description: Yup.string().required(),
    owner: Yup.string().required(),
    priority: Yup.string().required(),
    userId: Yup.number().required(), // ID del usuario que crea/actualiza
    tenantId: Yup.number().required()
});


export const store = async (req: TaskRequest, res: Response, next: NextFunction): Promise<Response | void> => {
    const { tenantId, id: userId } = req.user!;
    const taskDataFromRequest = { ...req.body };

    const taskData = {
        ...taskDataFromRequest,
        userId: Number(userId),
        tenantId: Number(tenantId)
    };

    try {
        await taskSchema.validate(taskData);
    } catch (err: any) {
        // Pasa el error al middleware de manejo de errores
        // O lanza AppError como en otros controladores
        throw new AppError(err.message, 400);
        // Originalmente llamaba a next(err), lo cual es otra forma válida
        // return next(err);
    }

    const newTask = await CreateTasksService(taskData);

    return res.status(201).json(newTask);
};

export const index = async (req: TaskRequest, res: Response, next: NextFunction): Promise<Response | void> => {
    const { tenantId, id: userId } = req.user!;
    const { status } = req.query;

    const params: { tenantId: number; userId: number; status?: string } = {
        tenantId: Number(tenantId),
        userId: Number(userId)
    };

    if (status) {
        params.status = status;
    }

    const tasks = await ListTasksService(params);

    return res.status(200).json(tasks);
};

export const update = async (req: TaskRequest, res: Response, next: NextFunction): Promise<Response | void> => {
    const { tenantId, id: userId } = req.user!;
    const taskDataFromRequest = { ...req.body };
    const { id: taskId } = req.params;

     if (!taskId) {
        throw new AppError("Task ID is required", 400); // "ID de tarea es requerido"
    }

    const taskData = {
        ...taskDataFromRequest,
        userId: Number(userId),
        tenantId: Number(tenantId)
    };

    try {
        // Podrías tener un esquema diferente para update si algunos campos no son requeridos
        await taskSchema.validate(taskData);
    } catch (err: any) {
         throw new AppError(err.message, 400);
        // return next(err);
    }

    const updateParams = {
        taskData: taskData, // Datos validados
        id: Number(taskId) // ID de la tarea a actualizar
    };

    const updatedTask = await UpdateTasksService(updateParams);

    return res.status(200).json(updatedTask);
};

export const remove = async (req: TaskRequest, res: Response): Promise<Response> => {
    const { id: taskId } = req.params;

    if (!taskId) {
        throw new AppError("Task ID is required", 400); // "ID de tarea es requerido"
    }

    // DeleteTasksService probablemente solo necesite el ID
    // Añade tenantId si el servicio lo requiere para seguridad
    await DeleteTasksService(Number(taskId));

    // El original devolvía el resultado del servicio, que podría ser un mensaje o nada.
    // Devolvemos un 204 No Content o un 200 con mensaje.
    return res.status(200).json({ message: "Task deleted successfully" }); // "Tarea eliminada exitosamente"
    // o return res.status(204).send();
};

export const getTaskSummary = async (req: TaskRequest, res: Response, next: NextFunction): Promise<Response | void> => {
    const { tenantId } = req.user!;
    const { owner } = req.body; // ¿El owner viene del body o del usuario autenticado? Ajustar según lógica.

    const params = {
        tenantId: Number(tenantId),
        owner: owner // Asumiendo que owner es el criterio de filtro
    };

    const summary = await GetTaskSummaryService(params);

    return res.status(200).json(summary);
};