import { Request, Response } from "express";
import * as Yup from "yup";
import AppError from "../errors/AppError";
import CreateTagService from "../services/TagServices/CreateTagService";
import ListTagService from "../services/TagServices/ListTagService";
import DeleteTagService from "../services/TagServices/DeleteTagService";
import UpdateTagService from "../services/TagServices/UpdateTagService";

// Interfaz para el cuerpo de la solicitud de creación/actualización
interface TagRequestBody {
  tag?: string;
  color?: string;
  isActive?: boolean;
  // userId y tenantId se añadirán internamente
}

// Interfaz para los parámetros de consulta de la lista
interface ListTagQuery {
  isActive?: string; // Viene como string desde la query
}

// Extiende la interfaz Request para incluir la propiedad user y query/body/params tipados
interface TagRequest extends Request {
  user?: {
    id: string | number;
    tenantId: string | number;
    profile: string; // Asumiendo que profile existe
  };
  body: TagRequestBody;
  query: ListTagQuery;
  params: {
    tagId?: string;
  };
}

// Esquema de validación para la creación
const createTagSchema = Yup.object().shape({
  tag: Yup.string().required(),
  color: Yup.string().required(),
  userId: Yup.number().required(),
  tenantId: Yup.number().required()
});

// Esquema de validación para la actualización
const updateTagSchema = Yup.object().shape({
  tag: Yup.string().required(),
  color: Yup.string().required(),
  isActive: Yup.boolean().required(),
  userId: Yup.number().required()
  // tenantId se usa para buscar, no necesita estar en el body validado
});

export const store = async (
  req: TagRequest,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId } = req.user!;
  const tagDataFromRequest = { ...req.body };

  // Prepara los datos para el servicio y validación
  const tagData = {
    ...tagDataFromRequest,
    userId: Number(userId), // Asegura que es número
    tenantId: Number(tenantId) // Asegura que es número
  };

  try {
    await createTagSchema.validate(tagData);
  } catch (err: any) {
    throw new AppError(err.message, 400);
  }

  const newTag = await CreateTagService(tagData);

  return res.status(201).json(newTag);
};

export const index = async (
  req: TagRequest,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user!;
  const { isActive } = req.query;

  const params = {
    tenantId: Number(tenantId),
    isActive: isActive ? isActive === "true" : false // Convierte string 'true' a booleano
  };

  const tags = await ListTagService(params);

  return res.status(200).json(tags);
};

export const update = async (
  req: TagRequest,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId } = req.user!;
  const tagDataFromRequest = { ...req.body };

  // Prepara los datos para validación (sin tenantId)
  const dataToValidate = {
    ...tagDataFromRequest,
    userId: Number(userId)
  };

  try {
    await updateTagSchema.validate(dataToValidate);
  } catch (err: any) {
    throw new AppError(err.message, 400);
  }

  const { tagId } = req.params;
  if (!tagId) {
    throw new AppError("tagId is required", 400); // "tagId es requerido"
  }

  // Prepara los datos para el servicio de actualización
  const updateData = {
    tagData: dataToValidate, // Contiene tag, color, isActive, userId
    id: tagId
    // tenantId se usa internamente en el servicio para asegurar la pertenencia
  };

  const updatedTag = await UpdateTagService(updateData);

  return res.status(200).json(updatedTag);
};

export const remove = async (
  req: TagRequest,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user!;
  const { tagId } = req.params;

  if (!tagId) {
    throw new AppError("tagId is required", 400); // "tagId es requerido"
  }

  const deleteParams = {
    id: tagId,
    tenantId: Number(tenantId)
  };

  await DeleteTagService(deleteParams);

  return res.status(200).json({ message: "Tag deleted" }); // "Etiqueta eliminada"
};
