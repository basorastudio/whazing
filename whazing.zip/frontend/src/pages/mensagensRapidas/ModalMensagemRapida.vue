<template>
  <q-dialog
    persistent
    :value="modalMensagemRapida"
    @hide="fecharModal"
    @show="abrirModal"
  >
    <q-card class="q-pa-lg modal-container container-rounded-10">
      <!-- Loading Spinner -->
      <q-overlay v-if="loading" class="bg-primary">
        <q-spinner color="white" size="50px" />
      </q-overlay>

      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ mensagemRapida.id ? 'Editar' : 'Crear' }} Mensaje Rápido {{ mensagemRapida.id ? `(ID: ${mensagemRapida.id})` : '' }}
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="q-pa-none">
        <div class="row q-my-md q-pa-lg container-border container-rounded-10">
          <div class="full-width text-h6 font-family-main q-mb-sm">Clave</div>
          <div class="full-width">
            <q-input
              rounded
              outlined
              v-model="mensagemRapida.key"
              label="Clave"
            />
            <p class="text-center" style="font-size: 10px;">
              La clave es el atajo para la búsqueda del mensaje por los usuarios.
            </p>
          </div>
          <div class="full-width" v-if="userProfile === 'admin' || userProfile === 'supervisor'">
            <q-checkbox
              v-model="mensagemRapida.global"
              label="Mostrar para todos"
            />
          </div>
        </div>

        <div class="row items-center container-border container-rounded-10 q-pa-lg">
          <div class="text-h6 full-width font-family-main q-mb-sm">Mensaje</div>
          <div class="col-xs-3 col-sm-2 col-md-1">
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-emoticon-happy-outline" />
              <q-tooltip>Emoji</q-tooltip>
              <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                <VEmojiPicker
                  style="width: 40vw"
                  :showSearch="true"
                  :emojisByRow="20"
                  labelSearch="Buscar..."
                  lang="es"
                  @select="onInsertSelectEmoji"
                />
              </q-menu>
            </q-btn>
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-variable" />
              <q-tooltip>Variables</q-tooltip>
              <q-menu touch-position>
                <q-list dense style="min-width: 100px">
                  <q-item
                    v-for="variavel in variaveis"
                    :key="variavel.label"
                    clickable
                    @click="onInsertSelectVariable(variavel.value)"
                    v-close-popup
                  >
                    <q-item-section>{{ variavel.label }}</q-item-section>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>
          </div>
          <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm">
            <label class="text-caption">Mensaje:</label>
            <textarea
              ref="inputEnvioMensagem"
              :disabled="audiogravado"
              style="min-height: 15vh; max-height: 15vh;"
              class="q-pa-sm bg-white full-width"
              placeholder="Escribe el mensaje"
              autogrow
              dense
              outlined
              @input="(v) => mensagemRapida.message = v.target.value"
              :value="mensagemRapida.message"
            />
          </div>
          <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm q-mt-md row items-center">
            <!-- Microphone button -->
            <q-btn
              round
              flat
              :color="isRecordingAudio ? 'negative' : 'primary'"
              @click="handleAudioRecording"
              class="q-ml-sm color-light1"
              :class="$q.dark.isActive ? ('color-dark1') : ''"
            >
              <q-icon
                :name="isRecordingAudio ? 'stop' : 'mic'"
                size="2em"
              />
              <q-tooltip>
                {{ isRecordingAudio ? 'Detener Grabación' : 'Grabar Audio' }}
              </q-tooltip>
            </q-btn>
            <!-- File upload button - hidden while recording -->
            <q-file
              v-if="!isRecordingAudio"
              dense
              outlined
              v-model="arquivoCarregado"
              label="Elige el archivo"
              filled
              class="col"
            />

            <!-- Recording Timer -->
            <RecordingTimer
              v-if="isRecordingAudio"
              class="q-ml-sm"
            />
          </div>
        </div>
      </q-card-section>
      <q-card-actions align="right" class="q-mt-md">
        <q-btn
          label="Cancelar"
          color="negative"
          v-close-popup
          class="q-mr-md btn-rounded-50"
        />
        <q-btn
          :loading="loading"
          :disable="loading"
          label="Guardar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          @click="handleMensagemRapida"
          icon="eva-save-outline"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { VEmojiPicker } from 'v-emoji-picker'
import { CriarMensagemRapida, AlterarMensagemRapida } from 'src/service/mensagensRapidas'

import RecordingTimer from '../atendimento/RecordingTimer'
import MicRecorder from 'mic-recorder-to-mp3'

const Mp3Recorder = new MicRecorder({
  bitRate: 128,
  encodeAfterRecord: true
})

export default {
  name: 'ModalMensagemRapida',
  components: { VEmojiPicker, RecordingTimer },
  props: {
    modalMensagemRapida: {
      type: Boolean,
      default: false
    },
    mensagemRapidaEmEdicao: {
      type: Object,
      default: () => {
        return { id: null, key: '', message: '', medias: '', global: false }
      }
    }
  },
  data() {
    return {
      isRecordingAudio: false,
      audioBlob: null,
      audiogravado: false,
      userProfile: 'user',
      mensagemRapida: {
        key: null,
        message: '',
        medias: null,
        global: false
      },
      arquivoCarregado: null,
      loading: false,
      variaveis: [
        { label: 'Nombre Completo', value: '{{name}}' },
        { label: 'Nombre', value: '{{firstName}}' },
        { label: 'Saludo', value: '{{greeting}}' },
        { label: 'Protocolo', value: '{{protocol}}' },
        { label: 'Teléfono', value: '{{phoneNumber}}' },
        { label: 'Email del Contacto', value: '{{email}}' },
        { label: 'Número de Ticket', value: '{{ticket_id}}' },
        { label: 'Hora', value: '{{hour}}' },
        { label: 'Fecha', value: '{{date}}' },
        { label: 'Cola', value: '{{fila}}' },
        { label: 'Nombre del agente', value: '{{user}}' },
        { label: 'Email del agente', value: '{{userEmail}}' }
      ]
    }
  },
  methods: {
    async handleAudioRecording () {
      if (!this.isRecordingAudio) {
        try {
          await navigator.mediaDevices.getUserMedia({ audio: true })
          await Mp3Recorder.start()
          this.isRecordingAudio = true
        } catch (error) {
          this.$q.notify({
            type: 'negative',
            message: 'Error al iniciar grabación de audio'
          })
          this.isRecordingAudio = false
        }
      } else {
        try {
          const [, blob] = await Mp3Recorder.stop().getMp3()
          this.isRecordingAudio = false

          if (blob.size < 10000) {
            this.$q.notify({
              type: 'warning',
              message: 'Audio muy corto'
            })
            return
          }

          // Create file object for attachment
          const audioFile = new File([blob], `audio_${Date.now()}.mp3`, {
            type: 'audio/mp3'
          })

          // Set the audio file to agendamento.anexo
          this.arquivoCarregado = audioFile

          this.audiogravado = true

          this.$q.notify({
            type: 'positive',
            message: 'Audio grabado con éxito!'
          })
        } catch (error) {
          this.$q.notify({
            type: 'negative',
            message: 'Error al finalizar grabación de audio'
          })
        }
      }
    },
    async cancelRecording () {
      if (this.isRecordingAudio) {
        try {
          await Mp3Recorder.stop().getMp3()
          this.isRecordingAudio = false
        } catch (error) {
          console.error('Error al cancelar grabación:', error)
        }
      }
    },
    limparArquivo() {
      this.arquivoCarregado = null
    },
    onInsertSelectVariable (variable) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!variable) {
        return
      }
      // insert:
      self.txtContent = this.mensagemRapida.message
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.mensagemRapida.message = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      if (!emoji.data) {
        return
      }
      self.txtContent = this.mensagemRapida.message
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.mensagemRapida.message = self.txtContent
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    fecharModal () {
      this.$emit('update:mensagemRapidaEmEdicao', { id: null })
      this.$emit('update:modalMensagemRapida', false)
    },
    abrirModal () {
      if (this.mensagemRapidaEmEdicao.id) {
        this.mensagemRapida = { ...this.mensagemRapidaEmEdicao }
        this.arquivoCarregado = this.mensagemRapidaEmEdicao.media
      } else {
        this.audiogravado = false
        this.mensagemRapida = {
          key: null,
          message: '',
          medias: null,
          global: false
        }
        this.arquivoCarregado = null
      }
    },
    async handleMensagemRapida() {
      if (!this.mensagemRapida.key) {
        this.$q.notify({
          type: 'negative',
          message: 'La clave no puede estar en blanco.'
        })
        return
      }
      if (!this.mensagemRapida.message && !this.arquivoCarregado) {
        this.$q.notify({
          type: 'negative',
          message: 'Debes completar el mensaje o elegir un archivo.'
        })
        return
      }

      this.loading = true // Ativa o loading

      try {
        let data
        const formData = new FormData()
        formData.append('key', this.mensagemRapida.key)
        formData.append('message', this.mensagemRapida.message)
        formData.append('medias', this.arquivoCarregado || null)
        const mensagemRapidaClonada = { ...this.mensagemRapida }
        formData.append('global', !!mensagemRapidaClonada.global)

        if (this.mensagemRapida.id) {
          data = await AlterarMensagemRapida(this.mensagemRapida.id, formData)
          this.$emit('mensagemRapida:editada', { ...this.mensagemRapida, ...data.data })
        } else {
          data = await CriarMensagemRapida(formData)
          this.$emit('mensagemRapida:criada', { ...this.mensagemRapida, ...data.data })
        }

        this.$q.notify({
          type: 'positive',
          message: this.mensagemRapida.id
            ? 'Mensaje rápido actualizado con éxito!'
            : 'Mensaje rápido creado con éxito!'
        })

        this.fecharModal()
      } catch (error) {
        console.error(error)
        this.$q.notify({
          type: 'negative',
          message: 'Ocurrió un error al guardar el mensaje rápido.'
        })
      } finally {
        this.loading = false // Desativa o loading
      }
    }
  },
  mounted() {
    this.userProfile = localStorage.getItem('profile')
  },
  beforeDestroy () {
    this.cancelRecording()
  }
}
</script>
