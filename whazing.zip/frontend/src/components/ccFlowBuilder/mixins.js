export const easyFlowMixin = {
  data () {
    return {
      jsplumbSetting: {
        // anclajes dinámicos, posición adaptativa
        Anchors: ['Top', 'TopCenter', 'TopRight', 'TopLeft', 'Right', 'RightMiddle', 'Bottom', 'BottomCenter', 'BottomRight', 'BottomLeft', 'Left', 'LeftMiddle'],
        // ID del contenedor
        Container: 'efContainer',
        // estilo de la línea de conexión, línea recta o curva, etc., valores posibles: StateMachine、Flowchart，Bezier、Straight
        Connector: ['Bezier', { curviness: 100 }],
        // Connector: ['Straight', {stub: 20, gap: 1}],
        // Connector: ['Flowchart', {stub: 30, gap: 1, alwaysRespectStubs: false, midpoint: 0.5, cornerRadius: 10}],
        // Connector: ['StateMachine', {margin: 5, curviness: 10, proximityLimit: 80}],
        // el ratón no puede arrastrar para eliminar líneas
        ConnectionsDetachable: false,
        // al eliminar la línea los puntos finales no se eliminan
        DeleteEndpointsOnDetach: false,
        /**
         * tipo de punto final para las dos puntas de la línea: circular
         * radius: radio del círculo, cuanto más grande más grande será el círculo
         */
        // Endpoint: ['Dot', {radius: 5, cssClass: 'ef-dot', hoverClass: 'ef-dot-hover'}],
        /**
         * tipo de punto final para las dos puntas de la línea: rectangular
         * height: altura del rectángulo
         * width: ancho del rectángulo
         */
        // Endpoint: ['Rectangle', {height: 20, width: 20, cssClass: 'ef-rectangle', hoverClass: 'ef-rectangle-hover'}],
        /**
         * punto final de imagen
         */
        // Endpoint: ['Image', {src: 'https://www.easyicon.net/api/resizeApi.php?id=1181776&size=32', cssClass: 'ef-img', hoverClass: 'ef-img-hover'}],
        /**
         * punto final en blanco
         */
        Endpoint: ['Blank', { Overlays: '' }],
        // Endpoints: [['Dot', {radius: 5, cssClass: 'ef-dot', hoverClass: 'ef-dot-hover'}], ['Rectangle', {height: 20, width: 20, cssClass: 'ef-rectangle', hoverClass: 'ef-rectangle-hover'}]],
        /**
         * estilo de los puntos finales en ambos extremos de la línea
         * fill: valor del color, ej: #12aabb, si está vacío no se muestra
         * outlineWidth: ancho del borde exterior
         */
        EndpointStyle: { fill: '#1879ffa1', outlineWidth: 1 },
        // habilitar el registro interno de jsPlumb
        LogEnabled: true,
        /**
         * estilo de la línea de conexión
         */
        PaintStyle: {
          // color de la línea
          stroke: '#5c67f2',
          // grosor de la línea, cuanto mayor sea el valor más gruesa será
          strokeWidth: 1,
          // establece el color del borde exterior, por defecto transparente para que no sea visible
          outlineStroke: 'transparent',
          // ancho del borde exterior de la línea, cuanto mayor sea el valor, mayor será el área para hacer clic
          outlineWidth: 10
        },
        DragOptions: { cursor: 'pointer', zIndex: 2000 },
        /**
         *  superposiciones
         */
        Overlays: [
          // superposición de flecha
          ['Arrow', {
            width: 10, // ancho de la cola de la flecha
            length: 8, // distancia desde la cola hasta la punta de la flecha
            location: 1, // posición, se recomienda usar entre 0~1
            direction: 1, // dirección, valor predeterminado 1 (hacia adelante), opcional -1 (hacia atrás)
            foldback: 0.623 // plegado, es decir el ángulo de las aletas, por defecto 0.623, cuando es 1 forma un triángulo equilátero
          }],
          // ['Diamond', {
          //     events: {
          //         dblclick: function (diamondOverlay, originalEvent) {
          //             console.log('double click on diamond overlay for : ' + diamondOverlay.component)
          //         }
          //     }
          // }],
          ['Label', {
            label: '',
            location: 0.1,
            cssClass: 'aLabel'
          }]
        ],
        // modo de dibujo svg、canvas
        RenderMode: 'svg',
        // estilo al pasar el ratón sobre la línea
        HoverPaintStyle: { stroke: '#5c67f2', strokeWidth: 1 },
        // efecto al pasar sobre el punto de anclaje
        // EndpointHoverStyle: {fill: 'red'}
        Scope: 'jsPlumb_DefaultScope' // ámbito, solo se pueden conectar puntos con el mismo scope
      },
      /**
       * parámetros de conexión
       */
      jsplumbConnectOptions: {
        isSource: true,
        isTarget: true,
        // anclaje dinámico, proporciona 4 direcciones Continuous、AutoDefault
        anchor: 'Continuous',
        // establece el estilo de la etiqueta en la línea de conexión
        labelStyle: {
          cssClass: 'flowLabel'
        },
        // modificó el código fuente de jsplumb, admite etiqueta vacía para pasar estilo personalizado
        emptyLabelStyle: {
          cssClass: 'emptyFlowLabel'
        }
      },
      /**
       * parámetros de configuración del punto de origen
       */
      jsplumbSourceOptions: {
        // establece el nombre de clase que se puede arrastrar, el ratón puede arrastrar una línea cuando se mueve sobre el DOM con esta clase
        filter: '.flow-node-drag',
        filterExclude: false,
        anchor: 'Continuous',
        // si se permite conectar consigo mismo
        allowLoopback: true,
        maxConnections: -1,
        onMaxConnections: function (info, e) {
          console.log(`Se superó el valor máximo de conexiones: ${info.maxConnections}`)
        }
      },
      // 参考 https://www.cnblogs.com/mq0036/p/7942139.html
      jsplumbSourceOptions2: {
        // establece el nombre de clase que se puede arrastrar, el ratón puede arrastrar una línea cuando se mueve sobre el DOM con esta clase
        filter: '.flow-node-drag',
        filterExclude: false,
        // anchor: 'Continuous',
        // si se permite conectar consigo mismo
        allowLoopback: true,
        connector: ['Flowchart', { curviness: 50 }],
        connectorStyle: {
          // color de la línea
          stroke: 'red',
          // grosor de la línea, cuanto mayor sea el valor más gruesa será
          strokeWidth: 1,
          // establece el color del borde exterior, por defecto transparente para que no sea visible
          outlineStroke: 'transparent',
          // ancho del borde exterior de la línea, cuanto mayor sea el valor, mayor será el área para hacer clic
          outlineWidth: 10
        },
        connectorHoverStyle: { stroke: 'red', strokeWidth: 2 }
      },
      jsplumbTargetOptions: {
        // establece el nombre de clase que se puede arrastrar, el ratón puede arrastrar una línea cuando se mueve sobre el DOM con esta clase
        filter: '.flow-node-drag',
        filterExclude: false,
        // si se permite conectar consigo mismo
        anchor: 'Continuous',
        allowLoopback: true,
        dropOptions: { hoverClass: 'ef-drop-hover' }
      }
    }
  }
}
