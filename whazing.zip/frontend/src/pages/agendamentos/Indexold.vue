<template>
  <div v-if="userProfile === 'admin'">
    <q-table
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      title="Programaciones"
      :data="agendamentos"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="eva-clock-outline q-pr-sm"/>
            Programaciones Antiguas
          </h2>
          <div class="contact-header full-width">
            Fecha de envío:
            <DatePick dense rounded outlined label="Fecha Inicial Fecha Envío"
              class="row col"
              v-model="params.startDate"
              @input="onDateChange"
            />
            <DatePick dense rounded outlined label="Fecha Final Fecha Envío"
              class="row col"
              v-model="params.endDate"
              @input="onDateChange"
            />
            Fecha que fue programado:
            <DatePick dense rounded outlined label="Fecha Inicial Fecha Programación"
                      class="row col"
                      v-model="params.startDateCreatedAt"
                      @input="onDateChange"
            />
            <DatePick dense rounded outlined label="Fecha Final Fecha Programación"
                      class="row col"
                      v-model="params.endDateCreatedAt"
                      @input="onDateChange"
            />
          </div>
        </div>
      </template>
      <template v-slot:body-cell-mediaUrl="props">
        <q-td :props="props">
          <span v-if="props.row.mediaUrl">
            <a :href="props.row.mediaUrl" target="_blank" style="text-decoration: underline; cursor: pointer;">
              Abrir Archivo
            </a>
          </span>
          <span v-else>
            Sin Archivo
          </span>
        </q-td>
      </template>
      <template v-slot:body-cell-ticketId="props">
        <q-td :props="props">
          <a :href="getTicketUrl(props.row.ticketId)">{{ props.row.ticketId }}</a>
        </q-td>
      </template>
      <template v-slot:body-cell-contactId="props">
        <q-td :props="props">
          {{ props.row.contactName || 'Cargando...' }}
        </q-td>
      </template>
      <template v-slot:body-cell-userId="props">
        <q-td :props="props">
          {{ formatUser(props.row.userId) }}
        </q-td>
      </template>
      <template v-slot:body-cell-createdAt="props">
        <q-td :props="props">
          {{ formatDate(props.row.createdAt) }}
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-trash-outline"
            @click="deletarMensagem(props.row)"
          />
        </q-td>
      </template>
      <template v-slot:pagination="{ pagination }">
        {{ agendamentos.length }}/{{ pagination.rowsNumber }}
      </template>
    </q-table>
  </div>
</template>

<script>
import { ListarAgendamento, DeletarMensagem } from 'src/service/tickets'
import { ListarUsuarios } from 'src/service/user'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  name: 'Protocolos',
  data() {
    return {
      userProfile: 'user',
      contatosCache: {},
      usuarios: [],
      agendamentos: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        startDate: null,
        endDate: null,
        startDateCreatedAt: null,
        endDateCreatedAt: null,
        hasMore: true
      },
      loading: false,
      columns: [
        { name: 'body', label: 'Mensaje', field: row => row.body.substring(0, 20) + '...', align: 'left' },
        { name: 'mediaUrl', label: 'Archivo', field: 'mediaUrl', align: 'left' },
        { name: 'ticketId', label: 'Ticket', field: 'ticketId', align: 'left' },
        { name: 'scheduleDate', label: 'Fecha Envío', field: 'scheduleDate', align: 'left', format: (val) => this.formatDate(val) },
        { name: 'userId', label: 'Usuario', field: 'userId', align: 'center', format: (val) => this.formatUser(val) },
        { name: 'createdAt', label: 'Fecha fue programado', field: 'createdAt', align: 'center', format: (val) => this.formatDate(val) },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores retornados por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    deletarMensagem(mensagem) {
      this.$q
        .dialog({
          title: '¡Atención! ¿Desea realmente eliminar este mensaje?',
          message: 'Los mensajes antiguos no serán borrados en el cliente.',
          cancel: {
            label: 'No',
            color: 'primary',
            push: true
          },
          ok: {
            label: 'Sí',
            color: 'negative',
            push: true
          },
          persistent: true
        })
        .onOk(() => {
          this.loading = true
          DeletarMensagem(mensagem)
            .then((res) => {
              this.loading = false
              mensagem.isDeleted = true
              window.location.reload()
            })
            .catch((error) => {
              this.loading = false
              console.error(error)
              this.$notificarErro('No fue posible borrar el mensaje', error)
            })
        })
        .onCancel(() => {})
    },
    async listarUsuarios() {
      const data = await ListarUsuarios()
      this.usuarios = data.data.users
    },
    async listarAgendamentos() {
      this.loading = true
      try {
        // Tratamiento para sumar 1 día a las fechas
        const startDate = this.params.startDate
          ? new Date(this.params.startDate).toISOString() // Convierte a ISO 8601
          : null

        const endDate = this.params.endDate
          ? (() => {
            const date = new Date(this.params.endDate)
            date.setDate(date.getDate() + 1) // Suma 1 día
            return date.toISOString() // Convierte a ISO 8601
          })()
          : null

        const startDateCreatedAt = this.params.startDateCreatedAt
          ? new Date(this.params.startDateCreatedAt).toISOString()
          : null

        const endDateCreatedAt = this.params.endDateCreatedAt
          ? (() => {
            const date = new Date(this.params.endDateCreatedAt)
            date.setDate(date.getDate() + 1) // Suma 1 día
            return date.toISOString() // Convierte a ISO 8601
          })()
          : null

        const response = await ListarAgendamento({
          startDate,
          endDate,
          startDateCreatedAt,
          endDateCreatedAt,
          pageNumber: this.params.pageNumber,
          tenantId: localStorage.getItem('tenantId')
        })

        if (response.data && Array.isArray(response.data.messages)) {
          this.agendamentos = [
            ...this.agendamentos,
            ...(await Promise.all(
              response.data.messages.map(async (protocolo) => {
                return protocolo
              })
            ))
          ]
          this.pagination.rowsNumber = response.data.count || 0
          this.pagination.hasMore = response.data.hasMore
        } else {
          console.error('Respuesta de la API no está en el formato esperado:', response.data)
        }
      } catch (error) {
        console.error('Error al listar programaciones:', error)
      } finally {
        this.loading = false
      }
    },
    formatUser(userId) {
      const user = this.usuarios.find(user => user.id === userId)
      return user ? user.name : 'Usuario no encontrado'
    },
    getTicketUrl(ticketId) {
      const route = this.$router.resolve({ path: `/atendimento/${ticketId}` })
      return route.href
    },
    formatDate(dateString) {
      const date = new Date(dateString)

      // Configura el formateador de fecha para la zona horaria deseada (ejemplo: 'America/Sao_Paulo')
      const options = {
        timeZone: 'America/Sao_Paulo', // Ajuste para la zona horaria deseada
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false // Usa el formato de 24 horas
      }

      const formatter = new Intl.DateTimeFormat('es-ES', options)
      return formatter.format(date).replace(',', '')
    },
    async filtrarProtocolos() {
      this.params.pageNumber = 1
      this.params.hasMore = true // Asegurar que hay más datos por cargar
      this.agendamentos = [] // Limpiar programaciones actuales para aplicar el nuevo filtro
      await this.listarAgendamentos()
    },
    onDateChange() {
      if (this.params.startDate && this.params.endDate) {
        this.filtrarProtocolos()
      }
      if (this.params.startDateCreatedAt && this.params.endDateCreatedAt) {
        this.filtrarProtocolos()
      }
    },
    onScroll({ to, ref, ...all }) {
      if (!this.loading && this.params.hasMore && to >= (this.agendamentos.length - 10)) {
        this.loading = true
        this.params.pageNumber++
        this.listarAgendamentos()
      }
    }
  },
  async mounted() {
    this.loadColors()
    await this.listarAgendamentos()
    await this.listarUsuarios()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.my-sticky-dynamic
  /* height or max-height is important */
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th /* bg color is important for th; just specify one */
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1
  /* this will be the loading indicator */
  thead tr:last-child th
    /* height of all previous header rows */
    top: 63px
  thead tr:first-child th
    top: 0

.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

#tabela-contatos-atendimento
  thead
    th
      height: 55px

.blur-effect
  filter: blur(0px)
</style>
