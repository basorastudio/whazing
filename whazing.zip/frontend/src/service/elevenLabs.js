import axios from 'axios'

export function listarVozesElevenLabs(apiKey) {
  return axios.get('https://api.elevenlabs.io/v2/voices', {
    params: {
      include_total_count: true
    },
    headers: {
      'xi-api-key': apiKey
    }
  })
}

export function listarModelosElevenLabs(apiKey) {
  return axios.get('https://api.elevenlabs.io/v1/models', {
    headers: {
      'xi-api-key': apiKey
    }
  })
}
