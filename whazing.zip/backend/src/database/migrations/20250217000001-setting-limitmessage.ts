import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert message limit warning setting into 'SettingsGeneral'
    // Translated the example message value from Portuguese to Spanish.
    const messageValue = `*Mensaje recibido más allá del límite de tamaño del sistema, si es necesario, se puede obtener en la aplicación de WhatsApp.*`;
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('limitmessage', '${messageValue.replace(/'/g, "''")}', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `); // Escaping single quotes
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted message limit warning setting
    await queryInterface.bulkDelete(
      "SettingsGeneral", // Adjust schema if needed
      {
        key: ["limitmessage"]
      }
    );
  }
};

export = migration;
