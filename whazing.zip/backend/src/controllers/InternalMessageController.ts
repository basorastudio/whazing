// --- START OF FILE InternalMessageController.ts ---

import type { Request, Response } from 'express';
import { getIO } from '../libs/socket';
import InternalMessage from '../models/InternalMessage';
import UsersGroups from '../models/UsersGroups';
import User from '../models/User';
import Group from '../models/Group';
import ListCountUnreadMessage from '../services/InternalMessageService/ListCountUnreadMessage';
import MessageService from '../services/InternalMessageService/MessageService';
import ReadMessageService from '../services/InternalMessageService/ReadMessageService';
import { logger } from '../utils/logger';
import iconv from 'iconv-lite';
import path from 'path';
import fs from 'fs';
import ListCountUnreadMessageGroup from '../services/InternalMessageService/ListCountUnreadMessageGroup';

interface ListarMensagensQuery {
    isGroup?: string | boolean; // Adjust based on actual usage
}

interface MarcarMensagemNaoLidaBody {
    isGroup?: string | boolean; // Adjust based on actual usage
}

interface MarcarMensagemNaoLidaParams {
    contactId?: string;
}

export const listarMensagens = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { id } = req.user;
    const { userId } = req.params;
    const { isGroup } = req.query as ListarMensagensQuery;

    const messages = await MessageService.listarMensagens(id, Number(userId), isGroup);
    return res.status(200).json({ mensagens: messages }); // "mensagens" kept as variable name
  } catch (error: any) {
    console.error(error);
    return res.status(500).json({ error: 'Ocurrió un error al listar los mensajes.' }); // Traducido
  }
};

const fixFileName = (filename: string): string => {
  try {
    const buffer = Buffer.from(filename, 'binary');
    return iconv.decode(buffer, 'utf-8');
  } catch (error) {
    console.error('Error al decodificar nombre del archivo:', error); // Traducido
    return filename;
  }
};

const renameFileInPlace = async (dirPath: string, oldName: string, newName: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    const oldPath = path.join(dirPath, oldName);
    const newPath = path.join(dirPath, newName);
    fs.rename(oldPath, newPath, (err) => {
      if (err) {
        console.error('Error al renombrar archivo:', err); // Traducido
        reject(err);
      } else {
        resolve();
      }
    });
  });
};


interface FileData {
    filename: string;
    mimetype: string;
    // Add other potential file properties if available from multer or similar
}

interface CriarMensagemBody {
    text: string;
    timestamp: number | string; // Could be number or comma-separated string
    receiverId: number | string; // Could be number or comma-separated string
    isGroup: boolean | string;
}

export const criarMensagem = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { text, timestamp, receiverId, isGroup } = req.body as CriarMensagemBody;
    const { id: senderId, tenantId } = req.user;
    const files = req.files as Express.Multer.File[] | undefined; // Type assertion for Multer files
    const io = getIO();

    // Normalize timestamp and receiverId
    const finalTimestampStr = Array.isArray(timestamp) ? timestamp[0] : (typeof timestamp === 'string' ? timestamp.split(',')[0] : String(timestamp));
    const finalReceiverIdStr = Array.isArray(receiverId) ? receiverId[0] : (typeof receiverId === 'string' ? receiverId.split(',')[0] : String(receiverId));
    const finalTimestamp = Number(finalTimestampStr);
    const finalReceiverId = Number(finalReceiverIdStr);


    const now = new Date();
    let messageTime = now.getTime();

    const messageData: any = { // Use a more specific type if possible
      text,
      timestamp: finalTimestamp,
      receiverId: finalReceiverId,
      senderId: senderId,
      tenantId: tenantId,
      groupId: null,
      mediaType: '_SYSTEM', // Assuming default
      mediaUrl: undefined,
      createdAt: now,
      updatedAt: now,
    };

    if (isGroup === true || String(isGroup).toLowerCase() === 'true') {
       messageData.receiverId = undefined;
       messageData.groupId = finalReceiverId; // Assuming receiverId is groupId in this case
    }

    let createdMessages: InternalMessage[] = [];

    if (files && files.length > 0) {
       await Promise.all(files.map(async (file) => {
          try {
             // Ensure filename is present
             if (!file.filename) {
                 // Handle missing filename - maybe skip or log an error
                 logger.error(`Archivo sin nombre de archivo encontrado: ${file.originalname}`);
                 return; // Skip processing this file
             }
          } catch (err) {
             logger.error(err);
             return; // Skip on error accessing filename
          }

         const publicDir = path.join(__dirname, '..', '..', 'public');
         const tenantDir = path.join(publicDir, String(tenantId));

         if (!fs.existsSync(tenantDir)) {
           fs.mkdirSync(tenantDir, { recursive: true });
         }

         const originalFilename = file.filename;
         const fixedFilename = fixFileName(originalFilename);

         // Check if renaming is needed and if the original file exists
         if (originalFilename !== fixedFilename && fs.existsSync(path.join(publicDir, originalFilename))) {
              await renameFileInPlace(publicDir, originalFilename, fixedFilename);
         }
         file.filename = fixedFilename; // Update the filename in the file object

         const sourcePath = path.join(publicDir, fixedFilename);
         const destPath = path.join(tenantDir, fixedFilename);

         if (fs.existsSync(sourcePath)) {
           await new Promise<void>((resolve, reject) => {
             fs.rename(sourcePath, destPath, (err) => {
               if (err) {
                 console.error('Error al mover archivo:', err); // Traducido
                 reject(err);
               } else {
                 // console.log('Archivo movido con éxito.'); // Traducido (Optional log)
                 resolve();
               }
             });
           });
         } else {
           // It seems the file was already moved or doesn't exist, maybe log this?
            logger.warn(`Archivo fuente no encontrado para mover: ${sourcePath}`);
            // Depending on the logic, you might want to throw an error or just proceed
            // throw new Error(`Archivo fuente no encontrado: ${sourcePath}`);
         }

         // Increment message time slightly for each attachment to maintain order
         const messageDate = new Date(messageTime += 1000); // Add 1 second

         const attachmentMessageData = {
           ...messageData,
           text: fixedFilename, // Use the fixed filename as text
           createdAt: messageDate,
           updatedAt: messageDate,
           mediaUrl: path.join(String(tenantId), fixedFilename), // Relative path for URL
           mediaType: file.mimetype || file.filename.substr(file.filename.lastIndexOf('.')) || 'application/octet-stream', // Determine mimetype
         };

         const newMessage = await MessageService.criarMensagem(attachmentMessageData);
         const fetchedMessage = await InternalMessage.findByPk(newMessage.id); // Fetch to include associations if needed later
         if (!fetchedMessage) {
           throw new Error('ERR_CREATING_MESSAGE'); // Keep error code
         }
         createdMessages.push(fetchedMessage);
       }));
    } else {
       // Create a single text message
       const newMessage = await MessageService.criarMensagem(messageData);
       const fetchedMessage = await InternalMessage.findByPk(newMessage.id, {
         include: [ // Include associations if needed for emission
            { model: User, as: 'sender', attributes: ['id', 'name'] },
            { model: User, as: 'receiver', attributes: ['id', 'name'] },
            { model: Group, as: 'group', attributes: ['group'] }
         ]
       });
       if (!fetchedMessage) {
          throw new Error('ERR_CREATING_MESSAGE');
       }
       createdMessages.push(fetchedMessage);
    }

     // Fetch full details for all created messages if not already done
     const detailedMessages = await InternalMessage.findAll({
         where: { id: createdMessages.map(msg => msg.id) },
         include: [
             { model: User, as: 'sender', attributes: ['id', 'name'] },
             { model: User, as: 'receiver', attributes: ['id', 'name'] },
             { model: Group, as: 'group', attributes: ['group', 'id'] } // Include group ID
         ]
     });


    // Emit messages via Socket.IO
    detailedMessages.forEach(async (msg) => {
      const messagePayload = {
          id: msg.id,
          receiverId: msg.receiverId,
          mediaType: msg.mediaType,
          mediaName: msg.mediaName, // Assuming this exists or needs mapping
          mediaUrl: msg.mediaUrl,
          senderId: senderId,
          timestamp: msg.timestamp,
          createdAt: msg.createdAt,
          groupId: msg.groupId,
          tenantId: msg.tenantId,
          text: msg.text,
          // Map sender/receiver/group data if needed for frontend
          sender: msg.sender,
          receiver: msg.receiver,
          group: msg.group,
          updatedAt: msg.updatedAt,
      };

      const socketPayload = {
          action: 'update', // Or 'create'? Depends on frontend logic
          data: messagePayload
      };

      // Emit to the general internal chat channel for the tenant
      io.emit(`${tenantId}-chat-interno`, socketPayload);


      if (msg.groupId) { // Message to a group
          const groupUsers = await UsersGroups.findAll({
              where: { groupId: msg.groupId },
              attributes: ["userId"]
          });
          const userIdsInGroup = groupUsers.map(gu => gu.userId);

          const onlineUsers = Array.from(io.sockets.sockets.values());
          let onlineCount = 0;
          onlineUsers.forEach(socket => {
               const socketUserId = socket.handshake.auth?.id; // Adjust based on your auth setup
               if (socketUserId && userIdsInGroup.includes(Number(socketUserId))) {
                   // Emit specifically to users in the group who are online
                   socket.emit(`${tenantId}-chat-interno-notificacao`, socketPayload);
                   onlineCount++;
               }
           });
           logger.info(`Notificación emitida a ${onlineCount} usuarios en el grupo ${msg.groupId}`); // Traducido

      } else { // Direct message
          const onlineUsers = Array.from(io.sockets.sockets.values());
          let onlineCount = 0;
          onlineUsers.forEach(socket => {
              const socketUserId = socket.handshake.auth?.id;
              // Emit to sender and receiver if they are online
              if (socketUserId && (Number(socketUserId) === senderId || Number(socketUserId) === msg.receiverId)) {
                   socket.emit(`${tenantId}-chat-interno-notificacao`, socketPayload);
                   onlineCount++;
              }
          });
           logger.info(`Notificación emitida a ${onlineCount} usuarios en mensaje directo (remitente: ${senderId}, receptor: ${msg.receiverId})`); // Traducido
      }
    });


    return res.status(201).json({ mensagens: detailedMessages }); // "mensagens" kept as variable name
  } catch (error: any) {
    console.error(error);
    return res.status(500).json({ error: 'Error al crear el mensaje.' }); // Traducido
  }
};


export const marcarMensagemNaoLida = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { contactId } = req.params as MarcarMensagemNaoLidaParams;
    const { id: userId, tenantId } = req.user;
    const { isGroup } = req.body as MarcarMensagemNaoLidaBody;
    const io = getIO();

    await ReadMessageService({
        userId: userId,
        senderId: Number(contactId), // Assuming contactId is senderId here
        isGroup: isGroup
    });

    // Emit an event to notify clients (e.g., to update UI)
     io.emit(`${tenantId}:unread-messages`, { // Use tenantId for channel
       action: 'update', // Or a specific action like 'marked_read'
       data: {
         receiverId: userId, // The user who read the messages
         isGroup: isGroup,
         senderId: Number(contactId) // The chat/group whose messages were read
       }
     });

    return res.status(200).json({ message: 'Mensajes marcados como leídos.' }); // Traducido
  } catch (error: any) {
    console.error(error);
    return res.status(500).json({ error: 'Ocurrió un error al marcar los mensajes como leídos.' }); // Traducido
  }
};

export const listCountUnreadMessage = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { id: userId } = req.user;
    const count = await ListCountUnreadMessage(userId);
    return res.status(200).json({ count });
  } catch (error: any) {
    console.error(error);
    return res.status(500).json({ error: 'Ocurrió un error al contar los mensajes no leídos.' }); // Traducido
  }
};

export const listCountUnreadMessageGroup = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { id: userId } = req.user;
    const count = await ListCountUnreadMessageGroup(userId);
    return res.status(200).json({ count });
  } catch (error: any) {
    console.error(error);
    return res.status(500).json({ error: 'Ocurrió un error al contar los mensajes no leídos.' }); // Traducido
  }
};


// --- END OF FILE InternalMessageController.ts ---