import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'disableRespondHub' column to the 'Tickets' table
    // Flag to disable some kind of "Respond Hub" functionality for this ticket.
    await queryInterface.addColumn(
      'Tickets',           // Table name
      'disableRespondHub', // New column name
      {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false, // Original had false
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'disableRespondHub' column from the 'Tickets' table
    await queryInterface.removeColumn(
      'Tickets',           // Table name
      'disableRespondHub'  // Column name to remove
    );
  }
};

export = migration;