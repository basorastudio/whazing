import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'id' como clave primaria autoincremental a 'Settings'
    return Promise.all([
      queryInterface.addColumn("Settings", "id", {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false // Las claves primarias no deben ser nulas
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'id' de 'Settings'
    return Promise.all([queryInterface.removeColumn("Settings", "id")]);
  }
};
