<template>
  <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-banner v-if="!premium" dense inline-actions class="bg-amber-8 text-white q-mb-md">
      <template v-slot:avatar>
        <q-icon name="star" />
      </template>
      {{ $t('general.msgRecursoPremium') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               icon="mdi-whatsapp"
               :label="$t('general.linkobterpremium')"
               @click="abrirWhatsApp3"
        />
      </template>
    </q-banner>

    <q-card-section v-if="!premium">
      <div class="row items-center justify-around q-col-gutter-md">
        <!-- Texto -->
        <div class="col-xs-12 col-sm-6 text-left">
          <div class="text-h6">
            {{ $t('dashboard.supportPlatform') }}
          </div>
          <div class="text-body q-mt-sm">
            {{ $t('dashboard.donationMessage') }}
          </div>
        </div>
        <!-- Imagem -->
        <div class="col-xs-12 col-sm-4 text-center">
          <img src="https://raw.githubusercontent.com/cleitonme/Whazing-SaaS/main/donate.jpg"
               alt="QR Code para doação via Pix"
               class="donation-image">
        </div>
      </div>
      <!-- Ícones de redes sociais -->
      <div class="row justify-center q-mt-md">
        <div class="social-icons">
          <q-btn round color="green" icon="mdi-whatsapp" size="md" class="q-mx-xs"
                 type="a" href="https://grupo.whazing.com.br/" target="_blank">
            <q-tooltip>Nosso Grupo de WhatsApp</q-tooltip>
          </q-btn>
          <q-btn round color="primary" icon="mdi-web" size="md" class="q-mx-xs"
                 type="a" href="https://www.whazing.com.br" target="_blank">
            <q-tooltip>Nosso Site</q-tooltip>
          </q-btn>
        </div>
      </div>
    </q-card-section>

    <q-table
      class="logs-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
        'full-height': $q.screen.lt.sm
      }"
      :data="logs"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="phone" class="q-pr-sm"/>
            {{ $t('logswavoip.titulo') }}
          </h2>
          <div class="absolute-top-right q-ma-md">
            <q-btn
              icon="arrow_back"
              :label="$t('relatorios.voltar')"
              to="/relatorios"
              class="color-light1"
              :class="$q.dark.isActive ? ('color-dark1') : ''"
            />
          </div>

          <div class="row q-col-gutter-md">
            <!-- Estatísticas de Chamadas - Lado Esquerdo -->
            <div class="col-12 col-md-4">
              <q-card class="bg-primary text-white">
                <q-card-section>
                  <div class="row items-center">
                    <div class="col">
                      <div class="text-h6">{{ $t('logswavoip.chamadas_totais') }}</div>
                      <div class="text-h4">{{ totalRecords }}</div>
                    </div>
                    <div class="col text-right">
                      <q-icon name="phone_in_talk" size="3.5em" />
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </div>

            <!-- Filtros - Lado Direito -->
            <div class="col-12 col-md-8">
              <div class="row q-col-gutter-md">
                <!-- User filter -->
                <div class="col-12 col-md-6">
                  <q-select
                    v-model="filters.userId"
                    :options="usuarios"
                    option-value="id"
                    option-label="name"
                    :label="$t('logswavoip.filtro_usuario')"
                    outlined
                    dense
                    clearable
                    @input="onFilterChange"
                  />
                </div>

                <!-- Contact filter -->
                <div class="col-12 col-md-6">

                  <q-select
                    outlined
                    dense
                    hide-dropdown-icon
                    :loading="loading"
                    v-model="filters.contactId"
                    :options="contatos"
                    @filter="localizarContato"
                    use-input
                    hide-selected
                    fill-input
                    option-label="name"
                    option-value="id"
                    :label="$t('modalAgendamento.contato.localizar')"
                    :hint="$t('modalAgendamento.contato.dica')"
                    clearable
                    @input="onFilterChange"
                  >
                    <!-- Adicione este slot para personalizar a aparência das opções -->
                    <template v-slot:option="scope">
                      <q-item v-bind="scope.itemProps"
                              v-on="scope.itemEvents"
                              v-if="scope.opt.name">
                        <q-item-section avatar>
                          <q-avatar size="32px">
                            <img v-if="scope.opt.profilePicUrl" :src="scope.opt.profilePicUrl" />
                            <q-icon
                              v-else
                              name="mdi-account"
                              size="1.5em"
                              color="grey-5"
                            />
                          </q-avatar>
                        </q-item-section>
                        <q-item-section>
                          <q-item-label>{{ scope.opt.name }}</q-item-label>
                          <q-item-label caption>{{ scope.opt.number }}</q-item-label>
                        </q-item-section>
                      </q-item>
                    </template>
                  </q-select>

                </div>

                <!-- Ticket filter -->
                <div class="col-12 col-md-6">
                  <q-input
                    v-model="filters.ticketId"
                    type="number"
                    :label="$t('logswavoip.filtro_ticket')"
                    outlined
                    dense
                    clearable
                    @input="onFilterChange"
                  />
                </div>

                <!-- Whatsapp filter -->
                <div class="col-12 col-md-6">
                  <q-select
                    v-model="filters.whatsappId"
                    :options="filteredWhatsapps"
                    emit-value
                    map-options
                    option-value="id"
                    option-label="name"
                    :label="$t('logswavoip.filtro_canal')"
                    outlined
                    dense
                    clearable
                    @input="onFilterChange"
                  />
                </div>

                <!-- Date filters in a separate row -->
                <div class="col-12">
                  <div class="row q-col-gutter-md">
                    <div class="col-12 col-md-6">
                      <p>{{ $t('logswavoip.data_inicial')}}</p>
                      <DatePick
                        dense
                        outlined
                        v-model="filters.startDate"
                        @input="onFilterChange"
                      />
                    </div>
                    <div class="col-12 col-md-6">
                      <p>{{ $t('logswavoip.data_final') }}</p>
                      <DatePick
                        dense
                        outlined
                        v-model="filters.endDate"
                        @input="onFilterChange"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-12">
              <div class="row q-col-gutter-md">
                <!-- Call Direction Stats -->
                <div class="col-12 col-md-4">
                  <q-card
                    class="text-center cursor-pointer"
                    :class="{'bg-primary text-white': filters.direction === 'incoming'}"
                    @click="filterByDirection('incoming')"
                  >
                    <q-card-section>
                      <div class="text-h6"><q-icon name="call_received" /></div>
                      <div class="text-subtitle1">{{ $t('logswavoip.chamadas_recebidas') }}</div>
                      <div class="text-h5">{{ callStats.incoming }}</div>
                    </q-card-section>
                  </q-card>
                </div>

                <div class="col-12 col-md-4">
                  <q-card
                    class="text-center cursor-pointer"
                    :class="{'bg-primary text-white': filters.direction === 'outcoming'}"
                    @click="filterByDirection('outcoming')"
                  >
                    <q-card-section>
                      <div class="text-h6"><q-icon name="call_made" /></div>
                      <div class="text-subtitle1">{{ $t('logswavoip.chamadas_realizadas') }}</div>
                      <div class="text-h5">{{ callStats.outcoming }}</div>
                    </q-card-section>
                  </q-card>
                </div>

                <div class="col-12 col-md-4">
                  <q-card
                    class="text-center cursor-pointer"
                    :class="{'bg-primary text-white': filters.direction === null}"
                    @click="filterByDirection(null)"
                  >
                    <q-card-section>
                      <div class="text-h6"><q-icon name="phone" /></div>
                      <div class="text-subtitle1">{{ $t('logswavoip.todas_chamadas') }}</div>
                      <div class="text-h5">{{ totalRecords }}</div>
                    </q-card-section>
                  </q-card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </template>

      <template v-slot:body-cell-callid="props">
        <q-td :props="props">
          <div>
            <audio
              v-if="props.row.callid && props.row.status === 'terminate'"
              controls
              style="height: 30px; margin-left: 8px;"
              :src="`https://storage.wavoip.com/${props.row.callid}`"
            ></audio>
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-ticketId="props">
        <q-td :props="props">
          <button
            v-if="props.row.ticketId"
            class="q-mr-sm"
            @click.prevent="visualizarChat(props.row.ticketId)"
          >
            <i class="fa fa-comments"></i> {{ props.row.ticketId }}
          </button>
          <span v-else>-</span>
        </q-td>
      </template>

      <!-- Template para a coluna de duração -->
      <template v-slot:body-cell-duration="props">
        <q-td :props="props">
          {{ formatDuration(props.row.duration) }}
        </q-td>
      </template>

      <!-- Template para a coluna de direção -->
      <template v-slot:body-cell-direction="props">
        <q-td :props="props" class="text-center">
          <q-badge :color="props.row.direction === 'incoming' ? 'green' : 'blue'">
            <q-icon
              :name="props.row.direction === 'incoming' ? 'call_received' : 'call_made'"
              size="xs"
              class="q-mr-xs"
            />
            {{ props.row.direction === 'incoming' ? ($t('logswavoip.chamadas_recebida')) : ($t('logswavoip.chamadas_realizada')) }}
          </q-badge>
        </q-td>
      </template>

      <!-- Template para a coluna de status -->
      <template v-slot:body-cell-status="props">
        <q-td :props="props">
          <q-badge :color="getStatusColor(props.row.status)">
            {{ getStatusLabel(props.row.status) }}
          </q-badge>
        </q-td>
      </template>

      <!-- Template para a coluna de data -->
      <template v-slot:body-cell-createdAt="props">
        <q-td :props="props">
          {{ formatDate(props.row.createdAt) }}
        </q-td>
      </template>

      <!-- Template para a coluna de contato -->
      <template v-slot:body-cell-contact="props">
        <q-td :props="props">
          {{ props.row.contact?.name || '-' }}
          <small v-if="props.row.contact?.number">({{ props.row.contact.number }})</small>
        </q-td>
      </template>
    </q-table>

    <!-- Modal de Chat -->
    <ChatModal v-if="mostrarModal" :ticketId="String(ticketIdAtual)" @close="fecharChatModal" />

  </div>
</template>

<script>
import { date } from 'quasar'
import { ListarLogsWavoip } from 'src/service/wavoip'
import { ListarUsuarios } from 'src/service/user'
import { ListarContatos } from 'src/service/contatos'
import { ListarCores, Listarp } from 'src/service/configuracoesgeneral'
import ChatModal from 'src/pages/relatorios/ChatModal.vue'
import { mapGetters } from 'vuex'

export default {
  name: 'LogsWavoip',
  components: {
    ChatModal
  },
  data () {
    return {
      logs: [],
      callStats: {
        incoming: 0,
        outcoming: 0
      },
      userProfile: 'user',
      mostrarModal: false,
      loading: false,
      premium: true,
      usuarios: [],
      contatos: [],
      totalRecords: 0,
      ticketIdAtual: null,
      filters: {
        userId: null,
        contactId: null,
        ticketId: null,
        whatsappId: null,
        direction: null,
        startDate: null,
        endDate: null
      },
      directionOptions: [
        { label: this.$t('logswavoip.chamadas_recebida'), value: 'incoming' },
        { label: this.$t('logswavoip.chamadas_realizada'), value: 'outcoming' }
      ],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        page: 1,
        hasMore: true
      },
      columns: [
        {
          name: 'direction',
          label: this.$t('logswavoip.filtro_direcao'),
          field: 'direction',
          align: 'center'
        },
        {
          name: 'status',
          label: this.$t('logswavoip.coluna_status'),
          field: 'status',
          align: 'center'
        },
        {
          name: 'user',
          label: this.$t('logswavoip.filtro_usuario'),
          field: row => row.user?.name,
          align: 'left'
        },
        {
          name: 'contact',
          label: this.$t('logswavoip.filtro_contato'),
          field: row => row.contact?.name,
          align: 'left'
        },
        { name: 'callid', label: this.$t('logswavoip.coluna_callid'), field: 'callid', align: 'left' },
        { name: 'ticketId', label: this.$t('logswavoip.filtro_ticket'), field: 'ticketId', align: 'left' },
        {
          name: 'whatsapp',
          label: this.$t('logswavoip.filtro_canal'),
          field: row => row.whatsapp?.name,
          align: 'left'
        },
        {
          name: 'createdAt',
          label: this.$t('logswavoip.coluna_data'),
          field: 'createdAt',
          align: 'center',
          sortable: true
        }
      ]
    }
  },
  computed: {
    ...mapGetters([
      'whatsapps'
    ]),
    filteredWhatsapps () {
      return this.whatsapps.filter(canal =>
        canal.type === 'whatsapp' && canal.wavoip !== null
      )
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    formatDate(dateString) {
      if (!dateString) return '-'
      return date.formatDate(dateString, 'DD/MM/YYYY HH:mm')
    },
    formatDuration(seconds) {
      if (!seconds) return '0s'

      const hours = Math.floor(seconds / 3600)
      const minutes = Math.floor((seconds % 3600) / 60)
      const remainingSeconds = seconds % 60

      let result = ''
      if (hours > 0) result += `${hours}h `
      if (minutes > 0 || hours > 0) result += `${minutes}m `
      result += `${remainingSeconds}s`

      return result.trim()
    },
    getStatusLabel(status) {
      if (!status) return '-'

      switch (status.toLowerCase()) {
        case 'outcoming_calling':
          return this.$t('logswavoip.status_chamando')
        case 'accept':
          return this.$t('logswavoip.status_atendida')
        case 'terminate':
          return this.$t('logswavoip.status_terminada')
        default:
          return status
      }
    },
    getStatusColor(status) {
      switch (status?.toLowerCase()) {
        case 'accept':
          return 'positive'
        case 'outcoming_calling':
          return 'warning'
        case 'terminate':
          return 'negative'
        default:
          return 'grey'
      }
    },
    async listarUsuarios() {
      try {
        const data = await ListarUsuarios()
        this.usuarios = data.data.users
      } catch (error) {
        console.error('Erro ao listar usuários:', error)
      }
    },
    async localizarContato(search, update, abort) {
      if (search.length < 2) {
        if (this.contatos.length) update(() => { this.contatos = [...this.contatos] })
        abort()
        return
      }
      this.loading = true
      try {
        const { data } = await ListarContatos({ searchParam: search })
        update(() => { this.contatos = data.contacts || [] })
      } finally {
        this.loading = false
      }
    },
    fecharChatModal() {
      this.mostrarModal = false
    },
    visualizarChat(ticketId) {
      this.ticketIdAtual = ticketId
      this.mostrarModal = true
    },
    onFilterChange() {
      this.pagination.page = 1
      this.fetchLogs()
    },
    async fetchLogs() {
      this.loading = true
      try {
        const startDate = this.filters.startDate
          ? new Date(this.filters.startDate).toISOString()
          : null

        const endDate = this.filters.endDate
          ? (() => {
            const date = new Date(this.filters.endDate)
            date.setDate(date.getDate() + 1)
            return date.toISOString()
          })()
          : null

        // Reset logs array when filters change
        if (this.pagination.page === 1) {
          this.logs = []
        }

        const params = {
          startDate,
          endDate,
          pageNumber: this.pagination.page,
          pageSize: this.pagination.rowsPerPage,
          direction: this.filters.direction,
          whatsappId: this.filters.whatsappId
        }

        if (this.filters.userId) {
          params.userId = typeof this.filters.userId === 'object'
            ? this.filters.userId.id
            : this.filters.userId
        }

        if (this.filters.contactId) {
          params.contactId = typeof this.filters.contactId === 'object'
            ? this.filters.contactId.id
            : this.filters.contactId
        }

        if (this.filters.ticketId) {
          params.ticketId = this.filters.ticketId
        }

        const response = await ListarLogsWavoip(params)

        if (response.data) {
          const records = response.data.logs || []

          // Quando os filtros mudam, substitui todo o array ao invés de concatenar
          if (this.pagination.page === 1) {
            this.logs = records
            this.totalRecords = response.data.count || 0
          } else {
            // Apenas concatena para paginação
            this.logs = [...this.logs, ...records]
          }

          // Atualiza metadados de paginação
          this.pagination.rowsNumber = response.data.count || 0
          this.pagination.hasMore = response.data.hasMore

          // Calcular estatísticas de chamadas
          if (this.pagination.page === 1) {
            this.updateCallStats(response.data.logs || [])
          }
        }
      } catch (error) {
        console.error('Erro ao buscar logs de chamadas:', error)
        this.$q.notify({
          type: 'negative',
          message: this.$t('logswavoip.erro_carregar')
        })
      } finally {
        this.loading = false
      }
    },

    updateCallStats(logs) {
      const allLogs = logs || []
      // Filtra apenas chamadas com status "terminate"
      const terminatedCalls = allLogs.filter(log => log.status === 'terminate')

      // Conta chamadas de entrada e saída terminadas
      this.callStats = {
        incoming: terminatedCalls.filter(log => log.direction === 'incoming').length,
        outcoming: terminatedCalls.filter(log => log.direction === 'outcoming').length
      }

      // Atualiza o total de chamadas (soma das terminadas)
      this.totalRecords = terminatedCalls.length
    },
    onScroll({ to }) {
      if (!this.loading && this.pagination.hasMore && to >= (this.logs.length - 10)) {
        this.pagination.page++
        this.fetchLogs()
      }
    },
    abrirWhatsApp3() {
      const message = encodeURIComponent(this.$t('general.obterpremium'))
      const url = `https://wa.me/554899416725?text=${message}`
      window.open(url, '_blank')
    },
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    filterByDirection(direction) {
      this.filters.direction = direction
      this.pagination.page = 1
      this.fetchLogs()
    }
  },
  async mounted() {
    this.loadColors()
    await Promise.all([
      this.fetchLogs(),
      this.listarUsuarios(),
      this.loadVersionp()
    ])
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 280px)
  .q-table__top
    padding: 8px

.logs-table
  height: auto
  min-height: 50px

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1

  thead tr:last-child th
    top: 63px

  thead tr:first-child th
    top: 0

.donation-image
  max-width: 100%
  max-height: 200px
  border-radius: 8px
</style>
