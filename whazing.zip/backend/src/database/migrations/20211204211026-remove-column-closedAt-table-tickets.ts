import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'closedAt' de la tabla 'Tickets'
    return Promise.all([queryInterface.removeColumn("Tickets", "closedAt")]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Vuelve a añadir la columna 'closedAt' (DATE) a 'Tickets'
    return Promise.all([
      queryInterface.addColumn("Tickets", "closedAt", {
        type: DataTypes.DATE(), // Tipo DATE
        allowNull: true, // Permite nulos
        defaultValue: null
      })
    ]);
  }
};
