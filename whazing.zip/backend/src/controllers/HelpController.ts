// --- START OF FILE HelpController.ts ---

import type { Request, Response } from "express";
import * as Yup from "yup";

import { getIO } from "../libs/socket";
import ListService from "../services/HelpServices/ListService";
import CreateService from "../services/HelpServices/CreateService";
import ShowService from "../services/HelpServices/ShowService";
import UpdateService from "../services/HelpServices/UpdateService";
import DeleteService from "../services/HelpServices/DeleteService";
import FindService from "../services/HelpServices/FindService";
import AppError from "../errors/AppError";

type IndexQuery = {
  searchParam?: string;
  pageNumber?: string;
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { searchParam, pageNumber } = req.query as IndexQuery;

  const { records, count, hasMore } = await ListService({
    searchParam,
    pageNumber
  });

  return res.json({ records, count, hasMore });
};

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const helpData = req.body;

  const schema = Yup.object().shape({
    title: Yup.string().required()
  });

  try {
    await schema.validate(helpData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const record = await CreateService({ ...helpData });

  const io = getIO();
  io.to(`tenant-${tenantId}-mainchannel`).emit(`tenant-${tenantId}-help`, {
    action: "create",
    record: record
  });

  return res.status(201).json(record);
};

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { id } = req.params;

  const record = await ShowService(id);

  return res.status(200).json(record);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const helpData = req.body;
  const { tenantId } = req.user;

  const schema = Yup.object().shape({
    title: Yup.string().required()
  });

  try {
    await schema.validate(helpData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const { id } = req.params;
  const record = await UpdateService({ ...helpData, id: Number(id) });

  const io = getIO();
  io.to(`tenant-${tenantId}-mainchannel`).emit(`tenant-${tenantId}-help`, {
    action: "update",
    record: record
  });

  return res.status(200).json(record);
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { id } = req.params;
  const { tenantId } = req.user;

  await DeleteService(id);

  const io = getIO();
  io.to(`tenant-${tenantId}-mainchannel`).emit(`tenant-${tenantId}-help`, {
    action: "delete",
    id: id
  });

  return res.status(200).json({ message: "Help eliminado" }); // Traducido
};

export const findList = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const records = await FindService();

  return res.status(200).json(records);
};

// --- END OF FILE HelpController.ts ---
