import { Request, Response } from 'express';
import * as Yup from 'yup';
import CreateApiConfigService from '../services/ApiConfigServices/CreateApiConfigService';
import ListApiConfigService from '../services/ApiConfigServices/ListApiConfigService';
import AppError from '../errors/AppError';
import UpdateApiConfigService from '../services/ApiConfigServices/UpdateApiConfigService';
import DeleteApiConfigService from '../services/ApiConfigServices/DeleteApiConfigService';
import RenewApiConfigTokenService from '../services/ApiConfigServices/RenewApiConfigTokenService';

interface ApiConfigData {
  name: string;
  sessionId: number;
  urlServiceStatus?: string;
  urlMessageStatus?: string;
  userId: number;
  tenantId: number | string; // Assuming tenantId can be string from req
  isActive?: boolean; // Added for update
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, id: userId } = req.user;

  if (req.user.profile !== 'admin') {
    throw new AppError('ERR_NO_PERMISSION', 403);
  }

  const newApiConfig: ApiConfigData = { ...req.body };
  newApiConfig.userId = userId;
  newApiConfig.tenantId = tenantId;

  const apiData = newApiConfig;

  const schema = Yup.object().shape({
    name: Yup.string().required(),
    sessionId: Yup.number().required(),
    urlServiceStatus: Yup.string().url().nullable(),
    urlMessageStatus: Yup.string().url().nullable(),
    userId: Yup.number().required(),
    tenantId: Yup.number().required(),
  });

  try {
    await schema.validate(apiData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const api = await CreateApiConfigService(apiData);

  return res.status(200).json(api);
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;

  if (req.user.profile !== 'admin') {
    throw new AppError('ERR_NO_PERMISSION', 403);
  }

  const requestData = { tenantId }; // Match service expectation

  const api = await ListApiConfigService(requestData);

  return res.status(200).json(api);
};

export const update = async (req: Request, res: Response): Promise<Response> => {
  if (req.user.profile !== 'admin') {
    throw new AppError('ERR_NO_PERMISSION', 403);
  }

  const { tenantId, id: userId } = req.user;
  const { apiId } = req.params;
  const apiData: ApiConfigData = { ...req.body };

  apiData.userId = userId;
  apiData.tenantId = tenantId;

  const schema = Yup.object().shape({
    name: Yup.string().required(),
    sessionId: Yup.number().required(),
    urlServiceStatus: Yup.string().url().nullable(),
    urlMessageStatus: Yup.string().url().nullable(),
    userId: Yup.number().required(),
    tenantId: Yup.number().required(),
    isActive: Yup.boolean().required(),
  });

  try {
    await schema.validate(apiData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const updateData = {
    apiData: apiData,
    apiId: apiId, // apiId needs to be passed correctly
    tenantId: tenantId,
  };

  const api = await UpdateApiConfigService(updateData);

  return res.status(200).json(api);
};

export const remove = async (req: Request, res: Response): Promise<Response> => {
  if (req.user.profile !== 'admin') {
    throw new AppError('ERR_NO_PERMISSION', 403);
  }

  const { tenantId } = req.user;
  const { apiId } = req.params;

  const deleteData = {
    apiId: apiId,
    tenantId: tenantId,
  };

  await DeleteApiConfigService(deleteData);

  const responseMessage = { message: 'API Config Eliminado' };
  return res.status(200).json(responseMessage);
};

export const renewTokenApi = async (req: Request, res: Response): Promise<Response> => {
  if (req.user.profile !== 'admin') {
    throw new AppError('ERR_NO_PERMISSION', 403);
  }

  const { tenantId, id: userId } = req.user;
  const { apiId } = req.params;
  const apiData: Partial<ApiConfigData> = { ...req.body }; // Partial might be needed

  apiData.userId = userId;
  apiData.tenantId = tenantId;

  const schema = Yup.object().shape({
    sessionId: Yup.number().required(),
    userId: Yup.number().required(),
    tenantId: Yup.number().required(),
  });

  try {
    await schema.validate(apiData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const renewData = {
    apiId: apiId,
    userId: apiData.userId, // Ensure userId is passed
    sessionId: apiData.sessionId, // Ensure sessionId is passed
    tenantId: apiData.tenantId,
  };

  const api = await RenewApiConfigTokenService(renewData);

  return res.status(200).json(api);
};