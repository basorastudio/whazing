import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'userIdDestination' a la tabla 'StepsReplyActions'
    return queryInterface.addColumn('StepsReplyActions', 'userIdDestination', {
      type: DataTypes.INTEGER
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'userIdDestination' de la tabla 'StepsReplyActions'
    return queryInterface.removeColumn('StepsReplyActions', 'userIdDestination');
  }
};