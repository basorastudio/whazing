import { QueryInterface, DataTypes, Sequelize } from "sequelize"; // Added Sequelize for DataTypes.fn
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'QueueIntegrations' table
    await queryInterface.createTable(
      "QueueIntegrations", // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false
        },
        type: {
          // Type of integration (e.g., 'n8n', 'typebot', 'webhook')
          type: DataTypes.STRING,
          allowNull: true
        },
        name: {
          // Name for this integration instance
          type: DataTypes.STRING,
          allowNull: true
        },
        projectName: {
          // Optional project name (e.g., for n8n or Typebot)
          type: DataTypes.STRING,
          allowNull: true
        },
        jsonContent: {
          // Store configuration or credentials as JSON
          type: DataTypes.TEXT, // TEXT for potentially large JSON
          allowNull: true
        },
        urlN8N: {
          // Specific URL for N8N integration
          type: DataTypes.STRING,
          allowNull: true
        },
        language: {
          // Language setting for the integration (e.g., 'pt-BR')
          type: DataTypes.STRING,
          allowNull: true
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        tenantId: {
          // Foreign key to Tenants
          type: DataTypes.INTEGER,
          references: {
            model: "Tenants",
            key: "id"
          },
          onUpdate: "CASCADE",
          onDelete: "SET NULL", // Allow integration to exist if tenant is deleted? Or CASCADE?
          allowNull: true
        },
        // Typebot specific fields
        typebotSlug: {
          type: DataTypes.STRING,
          allowNull: true
        },
        typebotExpires: {
          // Expiry time for typebot sessions?
          type: DataTypes.INTEGER,
          allowNull: true,
          defaultValue: 0
        },
        typebotKeywordFinish: {
          // Keyword to end the typebot session
          type: DataTypes.STRING,
          allowNull: true
        },
        typebotUnknownMessage: {
          // Message for unrecognized input
          type: DataTypes.STRING,
          allowNull: true
        },
        typebotDelayMessage: {
          // Delay before sending messages (ms?)
          type: DataTypes.INTEGER,
          allowNull: true,
          defaultValue: 1000 // Default 1 second
        },
        typebotKeywordRestart: {
          // Keyword to restart the typebot session
          type: DataTypes.STRING,
          allowNull: true
        },
        typebotRestartMessage: {
          // Message sent upon restarting
          type: DataTypes.STRING,
          allowNull: true
        }
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'QueueIntegrations' table
    await queryInterface.dropTable("QueueIntegrations");
  }
};

export = migration;
