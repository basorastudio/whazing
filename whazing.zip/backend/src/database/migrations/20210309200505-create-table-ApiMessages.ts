import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Validaciones para las columnas 'body' y 'number'
    const bodyValidation = { notEmpty: true };
    const numberValidation = { notEmpty: true, len: [1, 20] }; // No vacío y longitud entre 1 y 20

    // Crea la tabla 'ApiMessages'
    return Promise.all([
      // Usar Promise.all aunque solo sea una operación
      queryInterface.createTable("ApiMessages", {
        id: {
          allowNull: false,
          primaryKey: true,
          type: DataTypes.UUID,
          defaultValue: Sequelize.literal("gen_random_uuid()") // Usa la función de PostgreSQL
        },
        messageId: {
          // ID del mensaje (probablemente de la plataforma externa)
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        externalKey: {
          // Clave externa para identificación
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        body: {
          // Contenido del mensaje
          type: DataTypes.TEXT,
          allowNull: false,
          validate: bodyValidation // Aplica validación
        },
        ack: {
          // Estado de confirmación
          type: DataTypes.INTEGER,
          allowNull: false,
          defaultValue: 0
        },
        number: {
          // Número de teléfono destinatario
          type: DataTypes.STRING,
          allowNull: false,
          validate: numberValidation // Aplica validación
        },
        mediaName: {
          // Nombre del archivo multimedia
          type: DataTypes.TEXT, // Debería ser STRING? TEXT para nombres largos
          allowNull: true,
          defaultValue: null
        },
        timestamp: {
          // Marca de tiempo
          type: DataTypes.INTEGER, // Podría ser mejor DATE o BIGINT
          allowNull: true,
          defaultValue: null
        },
        sessionId: {
          // ID de la sesión de WhatsApp
          type: DataTypes.INTEGER,
          references: { model: "Whatsapps", key: "id" },
          onUpdate: "CASCADE",
          onDelete: "SET NULL"
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: { model: "Tenants", key: "id" },
          onUpdate: "CASCADE",
          onDelete: "CASCADE",
          allowNull: false,
          defaultValue: 1
        },
        messageWA: {
          // ¿Datos adicionales del mensaje de WhatsApp? (JSONB)
          type: DataTypes.JSONB,
          allowNull: true,
          defaultValue: null
        },
        apiConfig: {
          // ¿Configuración de API asociada? (JSONB)
          type: DataTypes.JSONB,
          allowNull: true,
          defaultValue: null
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        }
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la tabla 'ApiMessages'
    return Promise.all([
      // Usar Promise.all aunque solo sea una operación
      queryInterface.dropTable("ApiMessages")
    ]);
  }
};
