<template>
  <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <div class="bg-white mass-container container-rounded-10">
      <div class="row col full-width q-pa-lg">
      <q-card
        flat
        bordered
        class="full-width"
      >
        <q-card-section class="text-h6 text-bold">
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-cellphone-wireless q-pr-sm" />
            {{ $t('canais.canaisComunicacao') }}
          </h2>
          <div class="q-pa-sm">
            <q-btn flat
                   class="generate-button btn-rounded-50"
                   :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="eva-plus-outline"
                   :label="$t('canais.adicionarCanal')"
              @click="modalWhatsapp = true"
              v-if="userProfile === 'admin'"
            />
            <q-btn flat
                   class="generate-button btn-rounded-50"
                   :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="mdi-restart"
                   :label="$t('canais.reiniciarConexoes')"
              @click="reiniciarConexoes"
            />
            <q-btn
              class="generate-button btn-rounded-50"
              v-if="userProfile === 'admin'"
              :class="{'generate-button-dark' : $q.dark.isActive}"
                   icon="mdi-cog"
              :label="$t('canais.tokenHub')"
                   @click="modalHub = true"
            />
            <q-btn flat
                   class="generate-button btn-rounded-50"
                   :class="{'generate-button-dark' : $q.dark.isActive}"
                   v-if="whatsappNumber"
                   icon="mdi-whatsapp"
                   :label="$t('canais.chamarSuporte')"
                   @click="abrirWhatsApp"
            />

          </div>
        </q-card-section>
      </q-card>
    </div>
    <div class="container-border q-ma-lg q-pb-md container-rounded-10">
      <q-card-section>
        <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
        <q-icon name="eva-list-outline q-pr-sm" />
        {{ $t('canais.listagem') }}
      </h2>
      </q-card-section>

      <div class="row full-width  q-px-md ">
      <template v-for="item in canais">
        <q-card
          flat
          bordered
          class="col-xs-12 col-sm-5 col-md-4 col-lg-3 "
          :key="item.id"
        >
          <q-item>
            <q-item-section avatar>
              <q-avatar>
                <q-icon
                  size="40px"
                  :name="`img:${item.type}-logo.png`"
                />
              </q-avatar>
            </q-item-section>
            <q-item-section>
              <q-item-label class="text-h6 text-bold">{{ item.name }}</q-item-label>
              <q-item-label class="text-h6 text-caption">
                {{ item.type }}
              </q-item-label>
            </q-item-section>
            <q-item-section side>
              <q-btn
                round
                flat
                dense
                icon="eva-edit-outline"
                @click="handleOpenModalWhatsapp(item)"
                v-if="userProfile === 'admin'"
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
              />
            </q-item-section>
          </q-item>
          <q-separator />
          <q-card-section>
            <ItemStatusChannel :item="item" />
          </q-card-section>
          <q-card-section>
            <q-select
              v-if="userProfile === 'admin'"
              rounded
              outlined
              dense
              :label="$t('canais.chatbot')"
              v-model="item.chatFlowId"
              :options="listaChatFlow"
              map-options
              emit-value
              option-value="id"
              option-label="name"
              clearable
              @input="handleSaveWhatsApp(item)"
            />
          </q-card-section>
          <q-card-section>
            <q-select
              v-if="userProfile === 'admin'"
              rounded
              outlined
              dense
              :label="$t('canais.fila')"
              v-model="item.queueId"
              :options="listaFila"
              map-options
              emit-value
              option-value="id"
              option-label="queue"
              clearable
              @input="handleSaveWhatsApp(item)"
            >
              <q-tooltip>
                {{ $t('canais.filatooltip') }}
              </q-tooltip>
            </q-select>
          </q-card-section>
          <q-card-section>
            <q-select
              v-if="userProfile === 'admin'"
              rounded
              outlined
              dense
              :label="$t('canais.usuario')"
              v-model="item.userId"
              :options="listaUsuario"
              map-options
              emit-value
              option-value="id"
              option-label="name"
              clearable
              @input="handleSaveWhatsApp(item)"
              >
              <q-tooltip>
                {{ $t('canais.usertooltip') }}
              </q-tooltip>
            </q-select>
          </q-card-section>
          <q-card-section v-if="(item.status == 'DISCONNECTED' || item.status == 'qrcode') && item.type == 'whatsapp'">
            <q-checkbox
              v-model="item.importmessages"
              :label="$t('canais.importarMensagens')"
              @input="handleSaveWhatsApp(item)"
            />

            <!-- Conteúdo condicionalmente renderizado apenas se importmessages for true -->
            <template v-if="item.importmessages">
              <q-card-section>
                <DatePick
                  rounded
                  dense
                  hide-bottom-space
                  outlined
                  stack-label
                  bottom-slots
                  :label="$t('canais.importarinicio')"
                  v-model="item.importOldMessages"
                  @input="handleSaveWhatsApp(item)"
                />
              </q-card-section>

              <q-card-section>
                <DatePick
                  rounded
                  dense
                  hide-bottom-space
                  outlined
                  stack-label
                  bottom-slots
                  :label="$t('canais.importartermino')"
                  v-model="item.importRecentMessages"
                  @input="handleSaveWhatsApp(item)"
                />
              </q-card-section>

              <q-checkbox
                v-model="item.importOldMessagesGroups"
                :label="$t('canais.importargrupo')"
                @input="handleSaveWhatsApp(item)"
              />

              <q-checkbox
                v-model="item.closedTicketsPostImported"
                :label="$t('canais.importarencerar')"
                @input="handleSaveWhatsApp(item)"
              />
            </template>
          </q-card-section>
          <q-separator />

          <div v-if="(pairingCodes[item.id] || item.pairingCode) && item.type == 'whatsapp' && item.status == 'qrcode'"
               class="pairing-code-container q-py-md q-px-sm">
            <div class="row items-center justify-center">
              <q-icon name="mdi-cellphone"
                      size="24px"
                      class="q-mr-sm"
                      :class="$q.dark.isActive ? 'text-white' : 'color-light1'" />
              <div class="column">
                <div class="text-caption"
                     :class="$q.dark.isActive ? 'text-white' : 'text-grey-7'">{{ $t('canais.codigoPareamento') }}:</div>
                <div class="text-h6 text-weight-bold"
                     :class="$q.dark.isActive ? 'text-white' : 'color-light2'">
                  <!-- Use o valor do dicionário se existir, senão usa o valor do item -->
                  {{ formatPairingCode(pairingCodes[item.id] || item.pairingCode) }}
                </div>
              </div>
            </div>
          </div>
          <q-separator />
          <q-card-actions
            class="q-gutter-md q-pa-sm q-pt-none"
            align="center"
          >
           <template v-if="item.type !== 'messenger'">

                    <q-btn
                      v-if="item.type == 'hub_whatsapp' && userProfile === 'admin'"
                      class="generate-button btn-rounded-50"
                      :class="{'generate-button-dark' : $q.dark.isActive}"
                      :label="$t('canais.sincronizarTemplates')"
                      icon="mdi-sync"
                      @click="sincronizarTemplates(item.id)"
                    />

             <ItemApiwwjsStatus :item="item" v-if="item.type === 'hub_whatsapp' && item.isApiwwjs" />

                     <q-btn
                       v-if="item.type == 'whatsapp' && item.status == 'qrcode'"
                       :label="$t('canais.qrCode')"
                       @click="handleOpenQrModal(item, 'btn-qrCode')"
                       icon-right="mdi-qrcode-scan"
                       :disable="!isAdmin"
                       class="generate-button btn-rounded-50"
                       :class="{'generate-button-dark' : $q.dark.isActive}"
                     />

                     <div v-if="item.status == 'DISCONNECTED'" class="q-gutter-sm">
                       <q-btn
                         v-if="item.type != 'whatsapp'"
                         class="generate-button btn-rounded-50"
                         :class="{'generate-button-dark' : $q.dark.isActive}"
                         :label="$t('canais.conectar')"
                         @click="handleStartWhatsAppSession(item.id)"
                       />
                       <q-btn
                         v-if="item.status == 'DISCONNECTED' && item.type == 'whatsapp'"
                         :label="$t('canais.gerarNovo')"
                         @click="handleRequestNewQrCode(item, 'btn-qrCode')"
                         icon-right="mdi-qrcode-scan"
                         :disable="!isAdmin"
                         class="generate-button btn-rounded-50"
                         :class="{'generate-button-dark' : $q.dark.isActive}"
                       />

                     </div>

                     <div v-if="item.status == 'OPENING'" class="row items-center q-gutter-sm flex flex-inline">
                       <div class="text-bold">
                         {{ $t('canais.conectando') }}
                       </div>
                       <q-spinner-radio color="positive" size="2em" />
                       <q-separator vertical spaced="" />
                     </div>

                     <q-btn
                       v-if="['OPENING', 'CONNECTED', 'PAIRING', 'TIMEOUT'].includes(item.status) && !item.type.includes('hub')"
                       color="negative"
                       :label="$t('canais.desconectar')"
                       icon="eva-wifi-off-outline"
                       @click="handleDisconectWhatsSession(item.id)"
                       :disable="!isAdmin"
                       class="btn-rounded-50 q-mx-sm"
                     />

                   <q-btn
                     v-if="userProfile === 'admin'"
                     color="negative"
                     icon="eva-trash-outline"
                     @click="deleteWhatsapp(item)"
                     :disable="!isAdmin"
                     dense
                     round
                     flat
                     class="absolute-bottom-right color-light1"
                     :class="$q.dark.isActive ? ('color-dark1') : ''"
                   >
                    <q-tooltip>
                       {{ $t('canais.Deletar conexão') }}
                     </q-tooltip>
                   </q-btn>

                  </template>
                 </q-card-actions>

             </div>
             <ModalHub v-model="modalHub" />
             <ModalQrCode :abrirModalQR.sync="abrirModalQR" :channel="cDadosWhatsappSelecionado"
             @gerar-novo-qrcode="v => handleRequestNewQrCode(v, 'btn-qrCode')" />
           <ModalWhatsapp :modalWhatsapp.sync="modalWhatsapp" :whatsAppEdit.sync="whatsappSelecionado"
             @recarregar-lista="listarWhatsapps" />
           <q-inner-loading :showing="loading">
             <q-spinner-gears size="50px" color="primary" />
           </q-inner-loading>
         </div>
       </template>

<script>

import { DeletarWhatsapp, DeleteWhatsappSession, StartWhatsappSession, ListarWhatsapps, RequestNewQrCode, UpdateWhatsapp, ReiniciarConexoes } from 'src/service/sessoesWhatsapp'
import { format, parseISO } from 'date-fns'
import pt from 'date-fns/locale/pt-BR/index'
import ModalQrCode from './ModalQrCode'
import ModalHub from './ModalHub'
import { mapGetters } from 'vuex'
import ModalWhatsapp from './ModalWhatsapp'
import ItemStatusChannel from './ItemStatusChannel'
import ItemApiwwjsStatus from './ItemApiwwjsStatus'
import { ListarChatFlow } from 'src/service/chatFlow'
import { ListarFilas } from 'src/service/filas'
import { ListarUsuarios } from 'src/service/user'
import { ListarConfiguracaoPublica } from 'src/service/configuracoesgeneral'
import { SincronizarTemplates } from 'src/service/hub'

const userLogado = JSON.parse(localStorage.getItem('usuario'))

export default {
  name: 'IndexSessoesWhatsapp',
  components: {
    ModalQrCode,
    ModalWhatsapp,
    ModalHub,
    ItemStatusChannel,
    ItemApiwwjsStatus
  },
  data() {
    return {
      userProfile: 'user',
      loading: false,
      userLogado,
      isAdmin: false,
      abrirModalQR: false,
      modalWhatsapp: false,
      modalHub: false,
      whatsappNumber: null,
      whatsappSelecionado: {},
      listaChatFlow: [],
      listaFila: [],
      listaUsuario: [],
      pairingCodes: {},
      pageNumber: 1,
      hasMore: true,
      whatsAppId: null,
      canais: [],
      objStatus: {
        qrcode: ''
      },
      columns: [
        {
          name: 'name',
          label: this.$t('canais.nome'),
          field: 'name',
          align: 'left'
        },
        {
          name: 'status',
          label: this.$t('general.status'),
          field: 'status',
          align: 'center'
        },
        {
          name: 'session',
          label: this.$t('canais.sessao'),
          field: 'status',
          align: 'center'
        },
        {
          name: 'number',
          label: this.$t('canais.numero'),
          field: 'number',
          align: 'center'
        },
        {
          name: 'updatedAt',
          label: this.$t('canais.ultimaAtualizacao'),
          field: 'updatedAt',
          align: 'center',
          format: d => this.formatarData(d, 'dd/MM/yyyy HH:mm')
        },
        {
          name: 'isDefault',
          label: this.$t('canais.padrao'),
          field: 'isDefault',
          align: 'center'
        },
        {
          name: 'acoes',
          label: this.$t('general.actions'),
          field: 'acoes',
          align: 'center'
        }
      ]
    }
  },
  watch: {
    whatsapps: {
      handler() {
        this.canais = JSON.parse(JSON.stringify(this.whatsapps))
      },
      deep: true
    }
  },
  computed: {
    ...mapGetters(['whatsapps']),
    cDadosWhatsappSelecionado() {
      const { id } = this.whatsappSelecionado
      return this.whatsapps.find(w => w.id === id)
    }
  },
  methods: {
    formatPairingCode(code) {
      return code?.match(/.{1,4}/g)?.join('-') || code
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configurações:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const message = encodeURIComponent(this.$t('canais.whatsapp'))
        const url = `https://wa.me/${this.whatsappNumber}?text=${message}`
        window.open(url, '_blank')
      }
    },
    async reiniciarConexoes() {
      try {
        await ReiniciarConexoes()

        this.$q.notify({
          type: 'positive',
          message: this.$t('canais.reniciarwhatsapp')
        })
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: this.$t('canais.erroreniciarwhatsapp')
        })
        console.error(error)
      }
    },
    formatarData(data, formato) {
      return format(parseISO(data), formato, { locale: pt })
    },
    async buscaFilas() {
      const { data } = await ListarFilas()
      this.listaFila = data.filter(f => f.isActive)
    },
    async listarUsuario() {
      try {
        const { data } = await ListarUsuarios({ pageNumber: this.pageNumber })

        this.listaUsuario = [...this.listaUsuario, ...data.users]
        this.hasMore = data.hasMore

        if (this.hasMore) {
          this.pageNumber += 1
          this.listarUsuario()
        }
      } catch (error) {
        console.error('Erro ao carregar usuários:', error)
      }
    },
    handleOpenQrModal(channel) {
      this.whatsappSelecionado = channel
      this.abrirModalQR = true
    },
    handleOpenModalWhatsapp(whatsapp) {
      this.whatsappSelecionado = whatsapp
      this.modalWhatsapp = true
    },
    async handleDisconectWhatsSession(whatsAppId) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('canais.avisodesconectar'),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeleteWhatsappSession(whatsAppId).then(() => {
          const whatsapp = this.whatsapps.find(w => w.id === whatsAppId)
          this.$store.commit('UPDATE_WHATSAPPS', {
            ...whatsapp,
            status: 'DISCONNECTED'
          })
        }).finally(f => {
          this.loading = false
        })
      })
    },
    async handleStartWhatsAppSession(whatsAppId) {
      try {
        await StartWhatsappSession(whatsAppId)
      } catch (error) {
        console.error(error)
      }
    },

    async handleRequestNewQrCode(channel, origem) {
      if (channel.type === 'telegram' && !channel.tokenTelegram) {
        this.$notificarErro(this.$t('canais.tokentelegram'))
      }
      this.loading = true
      try {
        await RequestNewQrCode({ id: channel.id, isQrcode: true })
        setTimeout(() => {
          this.handleOpenQrModal(channel)
        }, 2000)
      } catch (error) {
        console.error(error)
      }
      this.loading = false
    },
    async listarWhatsapps() {
      const { data } = await ListarWhatsapps()
      this.$store.commit('LOAD_WHATSAPPS', data)
    },
    async deleteWhatsapp(whatsapp) {
      this.$q.dialog({
        title: this.$t('canais.deletarconexao'),
        message: this.$t('canais.deletarconexao2'),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarWhatsapp(whatsapp.id).then(r => {
          this.$store.commit('DELETE_WHATSAPPS', whatsapp.id)
        }).finally(f => {
          this.loading = false
        })
      })
    },
    async listarChatFlow() {
      const { data } = await ListarChatFlow()
      this.listaChatFlow = data.chatFlow.filter(chat => chat.isActive)
    },
    async handleSaveWhatsApp(whatsapp) {
      try {
        if (whatsapp.importOldMessages && whatsapp.importRecentMessages) {
          const oldDate = new Date(whatsapp.importOldMessages)
          const recentDate = new Date(whatsapp.importRecentMessages)

          const timeDiff = recentDate - oldDate
          const dayDiff = timeDiff / (1000 * 3600 * 24)

          if (dayDiff > 30) {
            this.$q.notify({
              type: 'negative',
              position: 'top',
              message: this.$t('canais.errorimportar'),
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
            return
          }
        }
        await UpdateWhatsapp(whatsapp.id, whatsapp)
        this.$q.notify({
          type: 'positive',
          progress: true,
          position: 'top',
          message: this.$t('canais.whatsappSucesso2'),
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (error) {
        console.error(error)
        return this.$q.notify({
          type: 'error',
          progress: true,
          position: 'top',
          message: this.$t('canais.errorname'),
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      }
    },
    async sincronizarTemplates(whatsappId) {
      this.loading = true
      try {
        await SincronizarTemplates(whatsappId)
        this.$q.notify({
          type: 'positive',
          message: this.$t('canais.templatesSincronizados')
        })
      } catch (error) {
        console.error('Erro ao sincronizar templates:', error)
        this.$q.notify({
          type: 'negative',
          message: error.response?.data?.message || this.$t('canais.erroSincronizarTemplates')
        })
      } finally {
        this.loading = false
      }
    },
    handleUpdateSession(session) {
      this.$store.commit('UPDATE_SESSION', session)

      // Atualizar nosso dicionário local de pairingCodes
      if (session && session.id && session.pairingCode) {
        // Armazena o código no nosso dicionário
        this.$set(this.pairingCodes, session.id, session.pairingCode)
      }
    }
  },
  beforeDestroy() {
    this.$root.$off('UPDATE_SESSION', this.handleUpdateSession)
  },
  mounted() {
    this.fetchConfigurations()
    this.userProfile = localStorage.getItem('profile')
    this.isAdmin = localStorage.getItem('profile')
    this.buscaFilas()
    this.listarUsuario()
    this.listarWhatsapps()
    this.listarChatFlow()
    this.$root.$on('UPDATE_SESSION', this.handleUpdateSession)
  }
}
</script>

       <style lang="scss" scoped>
       .pairing-code-container {
         background: rgba(25, 118, 210, 0.05);
         border: 1px solid rgba(25, 118, 210, 0.2);
         border-radius: 8px;
         margin: 8px 16px;
         transition: all 0.3s ease;

         &:hover {
           background: rgba(25, 118, 210, 0.1);
           box-shadow: 0 2px 4px rgba(0,0,0,0.1);
         }
       }
       </style>
