import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert API integration settings into 'SettingsGeneral'
    // Translated the example 'apimessage' value from Portuguese to Spanish.
    const apiMessageValue = `
      🌟 ¡Bienvenido(a) a la plataforma Whazing! 🌟

      Si necesita ayuda para configurar, no dude en enviar un mensaje al soporte. ¡Estamos listos para brindarle toda la ayuda necesaria! 😊

      🕒 ¡Aproveche su prueba de 3 días!
      www.whazing.com.br
    `.trim(); // Using template literal for multi-line string

    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('apiexternalKey', 'ID_UNICA_DO_SISTEMA_CLIENTE_PARA_EXECUTAR_UMA_ACAO_COM_WEBHOOK', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('apitoken', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRJZCI6MSwicHJvZmlsZSI6ImFkbWluIiwic2Vzc2lvbklkIjoiN2VkODIsImV4cCI6MTY3ODY4PUfOfvCuWmpO13nMhxuNSHVvZoLAV1pirhAg5jMXoQ', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('apiendpoint', 'http://localhost:3100/v1/api/external/999ab3a2-9f1f-4ffb-969a-bfb72234ece1', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('apienviarwhatsapp', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('apimessage', '${apiMessageValue.replace(/'/g, "''")}', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `); // Escaping single quotes within the message value for SQL
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted API settings
    await queryInterface.bulkDelete(
      'SettingsGeneral', // Adjust schema if needed
      {
        key: [
          'apiexternalKey',
          'apitoken',
          'apiendpoint',
          'apienviarwhatsapp',
          'apimessage'
        ]
      }
    );
  }
};

export = migration;