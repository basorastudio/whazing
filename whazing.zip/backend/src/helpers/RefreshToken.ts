import crypto from 'crypto';

// Define constants securely (Consider environment variables for production)
const CRYPTO_ALGORITHM = 'aes-256-cbc';
// IMPORTANT: These keys should ideally be stored securely (e.g., environment variables)
// and be exactly 32 bytes (256 bits) for AES-256. The IV should be 16 bytes.
// The provided hex strings are examples and might need adjustment for correct byte length.
// Ensure they are securely generated and managed.
const CRYPTO_KEY_HEX = '95b123ff7ef27c20b1e01aa46ad25b86914248d12ac73ef0da0d689dc0e0739c'; // 64 hex chars = 32 bytes
const CRYPTO_IV_HEX = '486994d0fda7688a1c0cf45e0e33abf1'; // 32 hex chars = 16 bytes

const CRYPTO_KEY = Buffer.from(CRYPTO_KEY_HEX, 'hex');
const CRYPTO_IV = Buffer.from(CRYPTO_IV_HEX, 'hex');

export const RefreshToken = (token: string): string => {
    try {
        const cipher = crypto.createCipheriv(CRYPTO_ALGORITHM, CRYPTO_KEY, CRYPTO_IV);
        let encrypted = cipher.update(token, 'utf-8', 'hex');
        encrypted += cipher.final('hex');
        return encrypted;
    } catch (error) {
         console.error("Error en la encriptación del token:", error);
        // Depending on requirements, you might return the original token, null, or throw
        return token; // Returning original token as a fallback based on original code
    }
};

export const RefreshToken2 = (encryptedToken: string): string => {
    try {
        const decipher = crypto.createDecipheriv(CRYPTO_ALGORITHM, CRYPTO_KEY, CRYPTO_IV);
        let decrypted = decipher.update(encryptedToken, 'hex', 'utf-8');
        decrypted += decipher.final('utf-8');
        return decrypted;
    } catch (error) {
        console.error("Error en la desencriptación del token:", error);
         // Depending on requirements, you might return the original encrypted token, null, or throw
         // It's generally safer *not* to return the encrypted token on failure.
        // Consider throwing the error or returning an empty string/null.
        // throw new Error("Failed to decrypt token"); // Option: Throw
        return ''; // Option: Return empty string
        // return encryptedToken; // Avoid returning encrypted data on decrypt failure
    }
};

// Default export could be one of the functions or an object containing both
export default {
    encrypt: RefreshToken,
    decrypt: RefreshToken2
};