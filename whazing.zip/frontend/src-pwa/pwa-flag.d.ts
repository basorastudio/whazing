// ESTE ARCHIVO DE FEATURE-FLAG ES AUTOGENERADO,
//  SU ELIMINACIÓN O CAMBIOS CAUSARÁN QUE LOS TIPOS RELACIONADOS DEJEN DE FUNCIONAR
import "quasar/dist/types/feature-flag";

declare module "quasar/dist/types/feature-flag" {
  interface QuasarFeatureFlags {
    pwa: true; // Asegura que la flag PWA está habilitada
  }
}
