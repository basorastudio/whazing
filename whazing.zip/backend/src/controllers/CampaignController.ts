import { Request, Response } from 'express';
import * as Yup from 'yup';
import * as fs from 'fs'; // Use ES6 import for fs
import * as path from 'path'; // Use ES6 import for path
import AppError from '../errors/AppError';
import CreateCampaignService from '../services/CampaignServices/CreateCampaignService';
import ListCampaignService from '../services/CampaignServices/ListCampaignService';
import DeleteCampaignService from '../services/CampaignServices/DeleteCampaignService';
import UpdateCampaignService from '../services/CampaignServices/UpdateCampaignService';
import StartCampaignService from '../services/CampaignServices/StartCampaignService';
import CancelCampaignService from '../services/CampaignServices/CancelCampaignService';
import Campaign from '../models/Campaign'; // Assuming Campaign model import

// Interfaces for structure
interface CampaignBodyData {
  name: string;
  start: string; // Date string
  message1?: string; // JSON string or object?
  message2?: string;
  message3?: string;
  userId?: number | string; // Set internally
  sessionId: number | string; // Connection/Whatsapp ID
  tenantId?: number | string; // Set internally
  delay?: number;
  // For Oficial
  campaignName?: string;
  scheduledDateTime?: string; // Date string
  whatsappId?: number | string; // Connection/Whatsapp ID
  dataJson?: string; // JSON string
  oficial?: boolean; // Set internally for oficial routes
  medias?: Express.Multer.File[]; // For file uploads
}

interface CampaignServiceData {
    campaign: Partial<CampaignBodyData>; // Use partial for flexibility
    medias?: Express.Multer.File[]; // From request if present
    campaignId?: number; // For update/delete/start/cancel
    tenantId: number | string;
    options?: { delay: number }; // For start service
}

// Helper to ensure upload directory exists
const ensureUploadDirExists = (tenantId: string | number): string => {
  const uploadDir = path.join(__dirname, '..', '..', 'public', tenantId.toString()); // Go up two levels from controller
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
  return uploadDir;
};

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const medias = req.files as Express.Multer.File[]; // Get uploaded files
  const bodyData: Omit<CampaignBodyData, 'userId' | 'tenantId'> = { ...req.body };

  const campaignData: Partial<CampaignBodyData> = {
      ...bodyData,
      userId: req.user.id,
      tenantId: tenantId
  }

  const schema = Yup.object().shape({
    name: Yup.string().required(),
    start: Yup.string().required(), // Consider date validation: Yup.date().required()
    // Validate messages if they are required or have specific formats
    // message1: Yup.string().required(),
    userId: Yup.number().required(),
    sessionId: Yup.number().required(), // Assuming sessionId is a number (Whatsapp ID)
    tenantId: Yup.number().required(),
    delay: Yup.number().required().min(1) // Ensure delay is positive
  });

  try {
    await schema.validate(campaignData, { abortEarly: false }); // Validate all fields
  } catch (err: any) {
     // Combine Yup errors into a single message or structure
     if (err instanceof Yup.ValidationError) {
        throw new AppError(err.errors.join(', '));
     }
    throw new AppError(err.message || "Validation Error");
  }

  const serviceData: CampaignServiceData = {
      campaign: campaignData,
      medias: medias, // Pass medias to the service
      tenantId: tenantId
  }

  const campaign = await CreateCampaignService(serviceData);
  return res.status(201).json(campaign); // 201 Created
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const { oficial } = req.query; // Check if 'oficial' query param exists

  const isOficial = oficial === 'true'; // Convert query param string to boolean

  const campaigns = await ListCampaignService({
    tenantId: tenantId,
    oficial: oficial !== undefined ? isOficial : undefined, // Pass boolean or undefined
  });

  return res.status(200).json(campaigns);
};

export const update = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId } = req.user;
    const medias = req.files as Express.Multer.File[]; // Get uploaded files if any
    const bodyData: Partial<CampaignBodyData> = { ...req.body }; // Use Partial for updates
    const { campaignId } = req.params;

    const campaignData: Partial<CampaignBodyData> = {
        ...bodyData,
        userId: req.user.id, // Record who updated it
        tenantId: tenantId
    }

    const schema = Yup.object().shape({
        // Validate only the fields being updated
        name: Yup.string(),
        start: Yup.string(), // Consider Yup.date()
        message1: Yup.string().nullable(), // Allow clearing messages
        message2: Yup.string().nullable(),
        message3: Yup.string().nullable(),
        // mediaUrl: Yup.string().nullable(), // Handled via file upload
        userId: Yup.number(),
        sessionId: Yup.number(),
        tenantId: Yup.number(),
        delay: Yup.number().min(1)
    });

    try {
        await schema.validate(campaignData, { abortEarly: false });
    } catch (err: any) {
       if (err instanceof Yup.ValidationError) {
            throw new AppError(err.errors.join(', '), 400);
       }
       throw new AppError(err.message || "Validation Error", 400);
    }

    // --- Additional Validation ---
    // Fetch existing campaign to check status before update
    const existingCampaign = await Campaign.findOne({
        where: { id: campaignId, tenantId }
    });

    if (!existingCampaign) {
        throw new AppError("ERR_CAMPAIGN_NOT_FOUND", 404);
    }

    // Prevent updates if campaign is not in a modifiable state (e.g., PENDING)
    if (existingCampaign.status !== 'pending') { // Or other allowed statuses
        throw new AppError("ERR_NO_UPDATE_CAMPAIGN", 400); // Cannot update campaign in current state
    }

     // Validate start date if provided
     if (campaignData.start) {
         const startDate = new Date(campaignData.start);
         const now = new Date();
         if (isNaN(startDate.getTime())) {
             throw new AppError("ERR_INVALID_DATE_FORMAT", 400);
         }
         // Optional: Ensure start date is in the future?
         // if (startDate <= now) {
         //     throw new AppError("ERR_DATE_MUST_BE_AFTER_CURRENT_DATE", 400);
         // }
     }


    // --- Prepare Service Data ---
    const serviceData: CampaignServiceData = {
        campaign: campaignData,
        medias: medias,
        campaignId: parseInt(campaignId, 10),
        tenantId: tenantId
    }

    const campaign = await UpdateCampaignService(serviceData);
    return res.status(200).json(campaign);
};


export const remove = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const { campaignId } = req.params;

  const serviceData = {
    id: parseInt(campaignId, 10),
    tenantId: tenantId,
  };

  await DeleteCampaignService(serviceData);

  return res.status(200).json({ message: 'Campaign eliminada' });
};

export const startCampaign = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const { campaignId } = req.params;
  const { delay = 1000 } = req.body; // Allow setting delay via body, default 1s

  const serviceData: CampaignServiceData = {
    campaignId: parseInt(campaignId, 10),
    tenantId: tenantId,
    options: { delay: Number(delay) },
  };

  await StartCampaignService(serviceData);

  return res.status(200).json({ message: 'Campaign iniciada' });
};

export const cancelCampaign = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const { campaignId } = req.params;

  const serviceData: CampaignServiceData = {
    campaignId: parseInt(campaignId, 10),
    tenantId: tenantId,
  };

  await CancelCampaignService(serviceData);

  return res.status(200).json({ message: 'Campaign cancelada' });
};

// --- Oficial Routes ---

// Helper function to handle media saving for oficial routes
const saveOficialMedia = (req: Request, tenantId: string | number): string | undefined => {
    if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
        return undefined; // No file uploaded
    }
    // Assuming only one file for oficial message media
    const mediaFile = req.files[0] as Express.Multer.File;
    const uploadDir = ensureUploadDirExists(tenantId);
    const uniqueFilename = `${Date.now()}_${mediaFile.originalname}`;
    const destinationPath = path.join(uploadDir, uniqueFilename);
    const sourcePath = mediaFile.path; // Path where multer temporarily saved the file

    try {
        // Check if source file exists before copying
        if (fs.existsSync(sourcePath)) {
            // Copy file from temp location to final destination
            fs.copyFileSync(sourcePath, destinationPath);
            // Clean up the temporary file
            fs.unlinkSync(sourcePath);
        } else {
            console.error(`Temporary file not found: ${sourcePath}`);
            // Handle error appropriately, maybe throw or return undefined
             return undefined;
        }

         // Return the public URL or relative path to the saved file
         const publicUrl = `${process.env.BACKEND_URL}/public/${tenantId}/${uniqueFilename}`;
         //const publicUrl = `/public/${tenantId}/${uniqueFilename}`; // Relative path if served statically
         return publicUrl;
    } catch (error) {
         console.error("Error saving oficial media:", error);
         // Clean up temp file even if copy fails
         if (fs.existsSync(sourcePath)) {
            try {
                fs.unlinkSync(sourcePath);
            } catch (unlinkError) {
                console.error("Error deleting temporary file after failed copy:", unlinkError);
            }
         }
         throw new AppError("Error saving media file.", 500);
    }
};


export const storeoficial = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId } = req.user;
    const userId = req.user.id;
    const {
        campaignName,
        scheduledDateTime,
        delay = 1000, // Default delay
        whatsappId, // Connection ID
        dataJson // JSON string for message components
    }: CampaignBodyData = req.body;

    let messageComponents: any; // To store parsed JSON
    let mediaUrl: string | undefined = undefined;

    try {
        messageComponents = JSON.parse(dataJson || '[]'); // Parse JSON or default to empty array
    } catch (error) {
        return res.status(400).json({ success: false, error: 'ERR_INVALID_DATA_JSON_FORMAT' });
    }

    // Handle media upload
    try {
        mediaUrl = saveOficialMedia(req, tenantId); // Save media and get URL
        // If media exists, find the header component and update its link parameter
        if (mediaUrl && Array.isArray(messageComponents)) {
            const headerComponent = messageComponents.find(
                (comp: any) => comp.type === 'header' &&
                               comp.parameters &&
                               Array.isArray(comp.parameters) &&
                               comp.parameters.some((param: any) => param.type === 'image' || param.type === 'document' || param.type === 'video') // Check for media type
            );

            if (headerComponent) {
                 const mediaParameter = headerComponent.parameters.find((param: any) => param.type === 'image' || param.type === 'document' || param.type === 'video');
                 if (mediaParameter) {
                     mediaParameter[mediaParameter.type] = { link: mediaUrl }; // Update link dynamically
                 }
            } else if (messageComponents.length === 0 || !messageComponents.some((comp:any) => comp.type === 'header')) {
                 // If no header exists, create one for the image (common scenario)
                 // Adjust this based on the expected structure for WhatsApp Cloud API
                 messageComponents.unshift({ // Add to the beginning
                     type: "header",
                     parameters: [
                         {
                             type: "image", // Assuming image, adjust if video/document
                             image: { link: mediaUrl }
                         }
                     ]
                 });
            }
        }
    } catch (error) {
        if (error instanceof AppError) {
             return res.status(error.statusCode).json({ error: error.message });
        }
         return res.status(500).json({ error: "Internal server error processing media." });
    }

    const campaignData = {
        name: campaignName,
        start: scheduledDateTime, // Use the scheduled date/time
        // Store the potentially modified components JSON as message1 (or dedicated field)
        message1: JSON.stringify(messageComponents),
        // message2 & message3 likely not used for Oficial API, set to null or empty
        message2: null,
        message3: null,
        userId: userId,
        delay: Number(delay),
        sessionId: Number(whatsappId), // Connection ID
        tenantId: String(tenantId), // Ensure tenantId is string if needed
        oficial: true // Mark as oficial
    };

    // Add validation if needed using Yup

    const campaign = await CreateCampaignService({ campaign: campaignData, tenantId });
    return res.status(201).json(campaign);
};

export const updateoficial = async (req: Request, res: Response): Promise<Response> => {
    const { tenantId } = req.user;
    const { campaignId } = req.params;
    const { start: scheduledDateTime }: { start?: string } = req.body; // Only allow updating start time?

    // --- Validation ---
    const campaign = await Campaign.findOne({
        where: { id: campaignId, tenantId, oficial: true } // Ensure it's an oficial campaign
    });

    if (!campaign) {
        throw new AppError("ERR_CAMPAIGN_NOT_FOUND", 404);
    }

    // Prevent updates if campaign is not in a modifiable state (e.g., PENDING)
    if (campaign.status !== 'pending' && campaign.status !== 'canceled') { // Allow update if canceled?
        throw new AppError("ERR_CAMPAIGN_NOT_IN_PENDING", 400); // Or specific error
    }

    if (!scheduledDateTime || isNaN(new Date(scheduledDateTime).getTime())) {
        throw new AppError("ERR_INVALID_DATE_FORMAT", 400);
    }

    const startDate = new Date(scheduledDateTime);
    const now = new Date();

    if (startDate <= now) { // Ensure new date is in the future
        throw new AppError("ERR_DATE_MUST_BE_AFTER_CURRENT_DATE", 400);
    }

    // --- Update ---
    campaign.start = startDate;
    // Reset status to pending if it was canceled and is being rescheduled
    if (campaign.status === 'canceled') {
        campaign.status = 'pending';
    }
    await campaign.save();

    // Re-fetch to include potential associations if needed by frontend
    const updatedCampaign = await Campaign.findByPk(campaign.id);

    return res.status(200).json(updatedCampaign);
};