import { QueryInterface, Sequelize } from 'sequelize';

export = {
  up: async (queryInterface: QueryInterface, sequelize: Sequelize): Promise<void> => {
    // Añade una restricción única combinada a las columnas 'tag' y 'tenantId' en la tabla 'Tags'
    await queryInterface.addConstraint('Tags', {
      fields: ['tag', 'tenantId'], // Campos de la restricción
      type: 'unique', // Tipo: única
      name: 'unique_contact_tag_tenant' // Nombre de la restricción
    });
  },

  down: async (queryInterface: QueryInterface, sequelize: Sequelize): Promise<void> => {
    // Elimina la restricción 'unique_contact_tag_tenant' de la tabla 'Tags'
    await queryInterface.removeConstraint('Tags', 'unique_contact_tag_tenant');
  }
};