const verifyLimit = async (company: Company) => {
  // Anular la verificación del límite
  return true;
};
