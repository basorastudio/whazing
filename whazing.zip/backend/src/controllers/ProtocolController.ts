// --- START OF FILE ProtocolController.ts ---

import type { Request, Response } from 'express';
import ListProtocolService from '../services/ProtocolServices/ListProtocolService'; // Assuming path

type ListProtocolQuery = {
  searchParam?: string;
  pageNumber?: string;
};

export const listProtocol = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user; // Assuming tenantId is available on req.user
  const { searchParam, pageNumber } = req.query as ListProtocolQuery;

  const { protocols, count, hasMore } = await ListProtocolService({
    searchParam,
    pageNumber,
    tenantId // Pass tenantId to the service
  });

  return res.json({ protocols, count, hasMore });
};

// --- END OF FILE ProtocolController.ts ---