<template>
  <div>
    <div v-if="!canAccessPage">
      <q-banner dense inline-actions class="bg-red text-white">
        <template v-slot:avatar>
          <q-icon name="warning" />
        </template>
        {{ $t('contacts.errors.accessDenied') }}
        <template v-slot:action>
          <q-btn flat dense @click="redirectHome">OK</q-btn>
        </template>
      </q-banner>
    </div>
    <div>
      <div v-if="canAccessPage">
        <q-table
          class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
          title="Contatos"
          :id="`tabela-contatos-${isChatContact ? 'atendimento' : ''}`"
          :data="contacts"
          :columns="tableColumns"
          :loading="loading"
          row-key="id"
          virtual-scroll
          :virtual-scroll-item-size="48"
          :virtual-scroll-sticky-size-start="48"
          :pagination.sync="pagination"
          :rows-per-page-options="[0]"
          @virtual-scroll="onScroll"
          :bordered="isChatContact"
          :square="isChatContact"
          :flat="isChatContact"
          :separator="isChatContact ? 'vertical' : 'horizontal'"
          :class="{
    'full-height': $q.screen.lt.sm
  }"
        >
          <template v-slot:top>
            <div class="row full-width q-table__title items-center ">
              <q-btn
                v-if="isChatContact"
                class="btn-small color-light1"
                :class="$q.dark.isActive ? ('btn-small color-dark1') : ''"
                round
                flat
                icon="mdi-close"
                @click="$router.push({ name: 'chat-empty' })"
              />
              <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
                <q-icon name="eva-people-outline q-pr-sm" />
                {{ $t('contacts.title') }}
              </h2>
              <div class="contact-header full-width">
                <q-input
                  class="contact-search"
                  :class="{
          'order-last q-mt-md': $q.screen.width < 500
        }"
                  style="width: 300px"
                  filled
                  debounce="500"
                  v-model="filter"
                  clearable
                  :placeholder="$t('general.search')"
                  @input="filtrarContato"
                >
                  <template v-slot:prepend>
                    <q-icon name="search" />
                  </template>
                </q-input>
                <q-select
                  v-model="selectedTag"
                  :options="tagsOptions"
                  option-value="id"
                  option-label="tag"
                  :label="$t('contacts.filters.byTag')"
                  @input="filtrarContatoPorEtiqueta"
                  class="contact-search"
                  :class="{
          'order-last q-mt-md': $q.screen.width < 500
        }"
                  style="width: 300px"
                  filled
                  debounce="500"
                  clearable
                >
                  <template v-slot:prepend>
                    <q-icon name="mdi-tag" />
                  </template>
                </q-select>
                <q-select
                  v-model="selectedWallet"
                  :options="usuarios"
                  option-value="id"
                  option-label="name"
                  :label="$t('contacts.filters.byWallet')"
                  @input="filtrarContatoPorCarteira"
                  class="contact-search"
                  :class="{
          'order-last q-mt-md': $q.screen.width < 500
        }"
                  style="width: 300px"
                  filled
                  debounce="500"
                  clearable
                >
                  <template v-slot:prepend>
                    <q-icon name="mdi-wallet" />
                  </template>
                </q-select>
                <q-input
                  class="contact-search"
                  :class="{
          'order-last q-mt-md': $q.screen.width < 500
        }"
                  style="width: 300px"
                  filled
                  debounce="500"
                  v-model="filteradicionais"
                  clearable
                  :placeholder="$t('contacts.search.additionalInfo')"
                  @input="filtrarContatoAdicionais"
                >
                  <template v-slot:prepend>
                    <q-icon name="mdi-text-search" />
                  </template>
                </q-input>
                <q-btn
                  class="generate-button btn-rounded-50"
                  :class="{'generate-button-dark' : $q.dark.isActive}"
                  icon="eva-sync-outline"
                  :label="$t('contacts.buttons.sync')"
                  v-if="!isChatContact"
                  @click="confirmarSincronizarContatos('whatsapp')"
                />
                <q-btn
                  class="generate-button btn-rounded-50"
                  :class="{'generate-button-dark' : $q.dark.isActive}"
                  icon="eva-cloud-upload-outline"
                  :label="$t('contacts.buttons.import')"
                  v-if="!isChatContact"
                  @click="modalImportarContatos = true"
                >
                </q-btn>
                <q-btn
                  class="generate-button btn-rounded-50"
                  :class="{'generate-button-dark' : $q.dark.isActive}"
                  v-if="!isChatContact && userProfile === 'admin'"
                  icon="eva-cloud-download-outline"
                  :label="$t('contacts.buttons.export')"
                  @click="handleExportContacts"
                />
                <q-btn
                  class="generate-button btn-rounded-50"
                  :class="{'generate-button-dark' : $q.dark.isActive}"
                  icon="eva-person-add-outline"
                  :label="$t('general.addButton')"
                  @click="selectedContactId = null; modalContato = true"
                />
              </div>
            </div>

          </template>
          <template  v-slot:body-cell-profilePicUrl="props">
            <q-td >
              <q-avatar style="border: 1px solid #9e9e9ea1 !important">
                <q-icon
                  name="mdi-account"
                  size="1.5em"
                  color="grey-5"
                  v-if="!props.value"
                />
                <q-img
                  :src="props.value"
                  style="max-width: 150px"
                >
                  <template v-slot:error>
                    <q-icon
                      name="mdi-account"
                      size="1.5em"
                      color="grey-5"
                    />
                  </template>
                </q-img>
              </q-avatar>
            </q-td>
          </template>
          <template v-slot:body-cell-acoes="props">
            <q-td class="text-center">
              <q-btn
                flat
                round
                icon="img:whatsapp-logo.png"
                @click="handleSaveTicket(props.row, 'whatsapp')"
                v-if="props.row.number"
              />
                <q-btn
                  flat
                  round
                  icon="img:telegram-logo.png"
                  @click="handleSaveTicket(props.row, 'telegram')"
                  v-if="props.row.telegramId"
                />
              <q-btn
                flat
                round
                icon="img:hub_instagram-logo.png"
                @click="handleSaveTicket(props.row, 'hub_facebook')"
                v-if="props.row.instagramPK"
              />
              <q-btn
                flat
                round
                icon="img:hub_facebook-logo.png"
                @click="handleSaveTicket(props.row, 'hub_facebook')"
                v-if="props.row.messengerId"
              />
              <q-btn
                flat
                round
                icon="img:hub_webchat-logo.png"
                v-if="props.row.webchatId"
              />
              <q-btn
                flat
                round
                icon="eva-edit-outline"
                @click="editContact(props.row.id)"
                class="color-light1"
                v-if="!isChatContact"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
              />
              <q-btn
                flat
                round
                icon="eva-trash-outline"
                @click="deleteContact(props.row.id)"
                class="color-light1"
                v-if="!isChatContact"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
              />
            </q-td>
          </template>
          <template v-slot:body-cell-number="props">
            <q-td>
    <span v-if="props.row.number" class="blur-effect">
      <template v-if="userProfile !== 'admin' && userProfile !== 'supervisor' && HideNumber === 'enabled'">
        <span :class="$q.dark.isActive ? ('text-white') : ''">
          {{ maskPhoneNumber(formatId(props.row.number)) }}
        </span>
      </template>
      <template v-else>
        <a :class="$q.dark.isActive ? ('text-white') : ''" :href="getPhoneNumberLink(props.row.number)">
          {{ formatId(props.row.number) }}
        </a>
      </template>
    </span>
            </q-td>
          </template>
          <template v-slot:body-cell-email="props">
            <q-td>
          <span  v-if="props.row.email">
            <a :class="$q.dark.isActive ? ('text-white') : ''" :href="'mailto:' + props.row.email">{{ props.row.email }}</a>
          </span>
            </q-td>
          </template>
          <template v-slot:body-cell-name="props">
            <q-td>
          <span  :class="$q.dark.isActive ? ('text-white') : ''" v-if="props.row.name">
            {{ props.row.name }}
          </span>
            </q-td>
          </template>
          <template v-slot:body-cell-tags="props">
            <q-td :props="props">
              <span :class="$q.dark.isActive ? ('bg-black text-white') : ''" v-html="formatTags(props.row.tags)"></span>
            </q-td>
          </template>
          <template v-slot:body-cell-disableBot="props">
            <q-td class="text-center">
              <q-icon
                size="24px"
                :name="props.value ? 'mdi-close-circle-outline' : 'mdi-check-circle-outline'"
                :color="props.value ? 'negative' : 'positive'"
              />
            </q-td>
          </template>
          <template v-slot:body-cell-disableCampaign="props">
            <q-td class="text-center">
              <q-icon
                size="24px"
                :name="props.value ? 'mdi-close-circle-outline' : 'mdi-check-circle-outline'"
                :color="props.value ? 'negative' : 'positive'"
              />
            </q-td>
          </template>
          <template v-slot:pagination="{ pagination }">
            {{ contacts.length }}/{{ pagination.rowsNumber }}
          </template>
        </q-table>
        <ContatoModal
          :contactId="selectedContactId"
          :modalContato.sync="modalContato"
          @contatoModal:contato-editado="UPDATE_CONTACTS"
          @contatoModal:contato-criado="UPDATE_CONTACTS"
        />

        <q-dialog
          v-model="modalImportarContatos"
          persistent
        >
          <q-card class="modal-container container-rounded-10">

            <q-card-section class="row items-center justify-between q-mt-md q-px-none">
              <div class="text-h6 text-center font-family-main col">
                {{ $t('contacts.modals.import.title') }}
              </div>
              <q-btn flat color="negative" v-close-popup icon="eva-close" @click="isImportCSV = false; modalImportarContatos = false" />
            </q-card-section>

            <div class="q-ma-lg container-border container-rounded-10">
              <q-card-section>
                <q-file
                  rounded
                  ref="PickerFileMessage"
                  id="PickerFileMessage"
                  bg-color="blue-grey-1"
                  outlined
                  dense
                  use-chips
                  accept=".csv"
                  v-model="file"
                  :label="$t('contacts.modals.import.title')"
                  :hint="$t('contacts.modals.import.fileUpload.hint')"
                >
                  <template v-slot:prepend>
                    <q-icon name="cloud_upload" />
                  </template>
                </q-file>

              </q-card-section>
            </div>

            <div class="q-ma-lg container-border container-rounded-10">
              <q-card-section>
                <q-card
                  class="bg-white q-mt-sm btn-rounded"
                  style="width: 100%"
                  bordered
                  flat
                >
                  <q-card-section class="text-bold font-family-main q-pb-none">
                    {{ $t('contacts.modals.import.sections.tags') }}
                    <q-separator />
                  </q-card-section>
                  <q-card-section class="q-pa-none">
                    <q-select
                      square
                      borderless
                      v-model="tags"
                      multiple
                      :options="etiquetas"
                      use-chips
                      option-value="id"
                      option-label="tag"
                      emit-value
                      map-options
                      dropdown-icon="add"
                    >
                      <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                        <q-item
                          v-bind="itemProps"
                          v-on="itemEvents"
                        >
                          <q-item-section>
                            <q-item-label v-html="opt.tag"></q-item-label>
                          </q-item-section>
                          <q-item-section side>
                            <q-checkbox
                              :value="selected"
                              @input="toggleOption(opt)"
                            />
                          </q-item-section>
                        </q-item>
                      </template>
                      <template v-slot:selected-item="{ opt }">
                        <q-chip
                          dense
                          square
                          color="white"
                          text-color="primary"
                          class="q-ma-xs row col-12 text-body1"
                        >
                          <q-icon
                            :style="`color: ${opt.color}`"
                            name="mdi-pound-box-outline"
                            size="28px"
                            class="q-mr-sm"
                          />
                          {{ opt.tag }}
                        </q-chip>
                      </template>
                      <template v-slot:no-option="{ itemProps, itemEvents }">
                        <q-item
                          v-bind="itemProps"
                          v-on="itemEvents"
                        >
                          <q-item-section>
                            <q-item-label class="text-negative text-bold">
                              Ops... Sem etiquetas criadas!
                            </q-item-label>
                            <q-item-label caption>
                              {{ $t('contacts.modals.import.sections.tagsadm') }}
                            </q-item-label>
                          </q-item-section>
                        </q-item>
                      </template>

                    </q-select>
                  </q-card-section>
                </q-card>
              </q-card-section>

              <q-card-section>
                <q-card
                  class="bg-white q-mt-sm btn-rounded"
                  style="width: 100%"
                  bordered
                  flat
                >
                  <q-card-section class="text-bold font-family-main q-pb-none">
                    {{ $t('contacts.modals.import.sections.wallet') }}
                    <q-separator />
                  </q-card-section>
                  <q-card-section class="q-pa-none">
                    <q-select
                      square
                      borderless
                      v-model="wallets"
                      multiple
                      :max-values="1"
                      :options="usuarios"
                      use-chips
                      option-value="id"
                      option-label="name"
                      emit-value
                      map-options
                      dropdown-icon="add"
                    >
                    </q-select>
                  </q-card-section>
                </q-card>
              </q-card-section>

              <q-card-section>
                <q-card
                  class="bg-white q-mt-sm btn-rounded"
                  style="width: 100%"
                  bordered
                  flat
                >
                  <q-card-section class="text-bold font-family-main q-pb-none">
                    {{ $t('contacts.modals.import.sections.crm') }}
                    <q-separator />
                  </q-card-section>
                  <q-card-section class="q-pa-none">

                    <q-select
                      dense
                      :max-values="1"
                      multiple
                      v-model="crm"
                      :options="kanbans"
                      use-chips
                      option-value="id"
                      option-label="name"
                      emit-value
                      map-options
                      dropdown-icon="add"
                    >
                      <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                        <q-item
                          v-bind="itemProps"
                          v-on="itemEvents"
                        >
                          <q-item-section>
                            <q-item-label v-html="opt.name"></q-item-label>
                          </q-item-section>
                          <q-item-section side>
                            <q-checkbox
                              :value="selected"
                              @input="toggleOption(opt)"
                            />
                          </q-item-section>
                        </q-item>
                      </template>
                      <template v-slot:selected-item="{ opt }">
                        <q-chip
                          dense
                          color="white"
                          text-color="primary"
                          class="q-ma-xs text-body1"
                        >
                          <q-icon
                            :style="`color: ${opt.color}`"
                            name="mdi-pound-box-outline"
                            size="28px"
                            class="q-mr-sm"
                          />
                          {{ opt.name }}
                        </q-chip>
                      </template>
                    </q-select>

                  </q-card-section>
                </q-card>
              </q-card-section>

            </div>

            <q-card-section>

            </q-card-section>
            <q-card-actions align="right">
              <q-btn
                class="q-ml-md btn-rounded-50"
                color="negative"
                :label="$t('general.cancelar')"
                v-close-popup
                @click="isImportCSV = false; modalImportarContatos = false"
              />

              <q-btn
                class="q-ml-md btn-rounded-50"
                color="positive"
                icon="eva-checkmark"
                :label="$t('general.Iniciar')"
                @click="handleImportCSV"
              />
              <q-btn
                class="q-ml-md generate-button btn-rounded-50"
                icon="eva-download"
                :label="$t('contacts.modals.import.buttons.downloadModel')"
                @click="downloadModelCsv"
              />
            </q-card-actions>
          </q-card>
        </q-dialog>

        <q-dialog v-model="modalSelecionarCanal" persistent>
          <q-card class="q-pa-md" style="width: 500px">
            <q-card-section>
              <div class="text-h6">{{ $t('newticket.title') }}</div>
            </q-card-section>

            <q-card-section>
              <q-select
                square
                outlined
                v-model="canalSelecionado"
                :options="canaisUsuario"
                emit-value
                map-options
                option-value="id"
                option-label="name"
                :label="$t('newticket.canal')"
              />
            </q-card-section>

            <q-card-section>
              <q-select
                square
                outlined
                v-model="filaSelecionada"
                :options="cUserQueues"
                emit-value
                map-options
                option-value="id"
                option-label="queue"
                :label="$t('newticket.fila')"
              />
            </q-card-section>

            <q-card-section v-if="erro" class="text-negative text-caption q-mt-sm">
              {{ erro }}
            </q-card-section>

            <q-card-actions align="right">
              <q-btn flat
                     :label="$t('general.cancelar')"
                     color="negative"
                     v-close-popup
                     @click="fecharModalCanal" />
              <q-btn flat
                     :label="$t('general.salvar')"
                     color="primary"
                     @click="criarTicket" />
            </q-card-actions>
          </q-card>
        </q-dialog>

      </div>
    </div>
</template>

<script>
const UserQueues = JSON.parse(localStorage.getItem('queues'))
import { CriarTicketNew } from 'src/service/tickets'
import formatSerializedId from 'src/utils/phoneFormatter'
import { ListarContatos, ImportarArquivoContato, DeletarContato, SyncronizarContatos, ExportarArquivoContato } from 'src/service/contatos'
import ContatoModal from './ContatoModal'
import { ListarUsuarios, ListarCanalUsuario } from 'src/service/user'
import { ListarEtiquetas } from 'src/service/etiquetas'
import { mapGetters } from 'vuex'
import { ListarConfiguracoes } from 'src/service/configuracoes'
import { ListarCores } from 'src/service/configuracoesgeneral'
import { ListarKanbans } from 'src/service/kanban'

export default {
  name: 'IndexContatos',
  components: { ContatoModal },
  userProfile: 'user',
  usuario: {},
  props: {
    isChatContact: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    canAccessPage() {
      return this.ContactAdmin !== 'enabled' || this.userProfile === 'admin' || this.userProfile === 'supervisor'
    },
    tableColumns() {
      const allColumns = [
        { name: 'profilePicUrl', label: '', field: 'profilePicUrl', style: 'width: 50px', align: 'center' },
        {
          name: 'name',
          label: this.$t('contacts.table.columns.Nome'),
          field: 'name',
          align: 'left',
          style: 'width: 300px',
          format: (v, r) => {
            if (r.number && r.name == r.number && r.pushname) {
              return r.pushname
            }
            return r.name
          }
        },
        {
          name: 'number',
          label: this.$t('contacts.table.columns.whatsapp'),
          field: 'number',
          align: 'center',
          style: 'width: 300px'
        },
        {
          name: 'wallet',
          label: this.$t('contacts.table.columns.wallet'),
          field: 'wallet',
          align: 'center',
          style: 'width: 300px'
        },
        {
          name: 'tags',
          label: this.$t('contacts.table.columns.tags'),
          field: 'tags',
          align: 'center',
          style: 'width: 300px'
        },
        { name: 'email', label: this.$t('contacts.table.columns.email'), field: 'email', style: 'width: 500px', align: 'left' },
        { name: 'disableBot', label: this.$t('contacts.table.columns.bot'), field: 'disableBot', align: 'center' },
        { name: 'disableCampaign', label: this.$t('contacts.table.columns.campaign'), field: 'disableCampaign', align: 'center' },
        { name: 'acoes', label: this.$t('general.actions'), field: 'acoes', align: 'center' }
      ]

      if (this.isChatContact) {
        return allColumns.filter(column =>
          !['email', 'wallet', 'disableBot', 'disableCampaign'].includes(column.name)
        )
      }

      return allColumns
    },
    cUserQueues () {
      return UserQueues
    },
    ...mapGetters(['whatsapps'])
  },
  data () {
    return {
      modalTransferirTicket: false,
      usuarioSelecionado: null,
      filaSelecionada: null,
      filas: [],
      erro: null,
      usuariosTransferencia: [],
      contacts: [],
      userProfile: 'user',
      ContactAdmin: null,
      HideNumber: null,
      ticketFocado: '',
      modalImportarContatos: false,
      modalContato: false,
      file: [],
      isImportCSV: false,
      filter: null,
      filteradicionais: null,
      selectedContactId: null,
      params: {
        pageNumber: 1,
        searchParam: null,
        searchParamAdicional: null,
        hasMore: true
      },
      wallets: [],
      tags: [],
      crm: [],
      kanbans: [],
      etiquetas: [],
      canaisUsuario: [],
      modalSelecionarCanal: false,
      canalSelecionado: null,
      tipoCanal: '',
      contatoAtual: null,
      usuarios: [],
      tagsOptions: [],
      selectedTag: null,
      selectedWallet: null,
      pagination: {
        rowsPerPage: 100,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'profilePicUrl', label: '', field: 'profilePicUrl', style: 'width: 50px', align: 'center' },
        {
          name: 'name',
          label: this.$t('contacts.table.columns.Nome'),
          field: 'name',
          align: 'left',
          style: 'width: 300px',
          format: (v, r) => {
            if (r.number && r.name == r.number && r.pushname) {
              return r.pushname
            }
            return r.name
          }
        },
        {
          name: 'number',
          label: this.$t('contacts.table.columns.whatsapp'),
          field: 'number',
          align: 'center',
          style: 'width: 300px'
        },
        {
          name: 'wallet',
          label: this.$t('contacts.table.columns.wallet'),
          field: 'wallet',
          align: 'center',
          style: 'width: 300px'
          // format: v => v ? v.map(n => n.name)?.join(', ') : ''
        },
        {
          name: 'tags',
          label: this.$t('contacts.table.columns.tags'),
          field: 'tags',
          align: 'center',
          style: 'width: 300px'
        },
        { name: 'email', label: this.$t('contacts.table.columns.email'), field: 'email', style: 'width: 500px', align: 'left' },
        { name: 'disableBot', label: this.$t('contacts.table.columns.bot'), field: 'disableBot', align: 'center' },
        { name: 'disableCampaign', label: this.$t('contacts.table.columns.campaign'), field: 'disableCampaign', align: 'center' },
        { name: 'acoes', label: this.$t('general.actions'), field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    filtrarContatoPorEtiqueta() {
      this.selectedWallet = null
      this.contacts = []
      this.params.pageNumber = 1
      this.params.tagId = this.selectedTag ? this.selectedTag.id : null
      this.listarContatos()
    },
    filtrarContatoPorCarteira() {
      this.selectedTag = null
      this.contacts = []
      this.params.pageNumber = 1
      this.params.walletId = this.selectedWallet || null
      this.listarContatos()
    },
    getPhoneNumberLink(number) {
      if (!number) {
        return null
      }
      if ((number.startsWith('55')) && (number.charAt(4) > 5)) {
        return `tel:${number.slice(0, 4)}9${number.slice(-8)}`
      } else {
        return `tel:${number}`
      }
    },
    async listarKanbans () {
      const { data } = await ListarKanbans({ showAll: true })
      this.kanbans = data
    },
    formatId(id) {
      const formattedId = formatSerializedId(id)
      return formattedId
    },
    redirectHome() {
      this.$router.push('/')
    },
    async listarConfiguracoes () {
      const { data } = await ListarConfiguracoes()
      localStorage.setItem('configuracoes', JSON.stringify(data))
      const ContactAdmin = data.find(config => config.key === 'ContactAdmin')
      this.ContactAdmin = ContactAdmin.value
      const HideNumber = data.find(config => config.key === 'HideNumber')
      this.HideNumber = HideNumber.value
    },
    formatTags(tags) {
      if (!Array.isArray(tags)) return ''

      return tags.map(tag => {
        return `<span style="background-color: ${tag.color}; padding: 2px 8px; border-radius: 4px; color: white; margin-right: 4px;">${tag.tag}</span>`
      }).join('')
    },
    async criarTicket() {
      if (!this.canalSelecionado || !this.filaSelecionada) {
        this.erro = this.$t('newticket.errorselecionar')
        return
      }

      this.erro = null
      this.loading = true

      try {
        const { data: ticket } = await CriarTicketNew({
          contactId: this.contatoAtual.id,
          isActiveDemand: true,
          channel: this.tipoCanal,
          channelId: this.canalSelecionado,
          queueId: this.filaSelecionada,
          status: 'open'
        })

        this.ticketFocado = ticket
        this.modalSelecionarCanal = false

        await this.$store.commit('SET_HAS_MORE', true)
        await this.$store.dispatch('AbrirChatMensagens', ticket)

        this.$q.notify({
          message: this.$t('contacts.newticket.ServiceStarted', { name: ticket.contact.name, ticketid: ticket.id }),
          type: 'positive',
          position: 'top',
          progress: true,
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })

        this.$router.push({ name: 'chat', params: { ticketId: ticket.id } })
      } catch (error) {
        this.loading = false
        console.log('error', error)
        const errorMessage = error?.data?.message || this.$t('general.Anunknownerrorhasoccurred')

        if (error.status === 409 && errorMessage === this.$t('general.Aticketalreadyexists')) {
          console.log('Erro 409:', error)
          const ticketAtual = error.data?.ticket
          this.abrirAtendimentoExistente(this.contatoAtual, ticketAtual)
        } else {
          if (error.status === 409) {
            console.log(error)
            this.$q.dialog({
              title: this.$t('general.Attention'),
              message: `${errorMessage}`,
              ok: {
                label: this.$t('general.close'),
                color: 'primary',
                push: true
              },
              persistent: true
            })
            this.$q.notify({
              message: errorMessage,
              type: 'negative',
              position: 'top',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          }
        }
      } finally {
        this.loading = false
        this.fecharModalCanal()
      }
    },
    downloadModelCsv() {
      const csvContent = 'nome;numero;email\nUser;5551900000;email@email.com'
      const blob = new Blob([csvContent], { type: 'text/csv' })
      const link = document.createElement('a')
      link.href = window.URL.createObjectURL(blob)
      link.setAttribute('download', 'model.csv')
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    },
    abrirEnvioArquivo (event) {
      this.isImportCSV = true
      this.$refs.PickerFileMessage.pickFiles(event)
    },
    async handleImportCSV () {
      try {
        if (!this.file) {
          this.$notificarErro(this.$t('contacts.errors.notifications.noFile'))
          return
        }

        if (!this.file.name.endsWith('.csv')) {
          this.$notificarErro(this.$t('contacts.errors.notifications.invalidFormat'))
          return
        }

        const text = await this.file.text()
        const lines = text.trim().split('\n')

        const header = lines[0].trim()
        if (header !== 'nome;numero;email') {
          this.$notificarErro(this.$t('contacts.errors.notifications.invalidFileStructure'))
          return
        }

        this.$q.notify({
          type: 'warning',
          message: this.$t('contacts.notifications.import.warning'),
          caption: this.$t('contacts.notifications.import.caption'),
          position: 'top'
        })

        const formData = new FormData()
        formData.append('file', this.file)
        if (this.tags.length > 0) {
          formData.append('tags', this.tags)
        }
        if (this.wallets.length > 0) {
          formData.append('wallets', this.wallets)
        }

        if (this.crm.length > 0) {
          formData.append('crm', this.crm)
        }

        await ImportarArquivoContato(formData)
        this.$notificarSucesso(this.$t('contacts.notifications.import.success'))
        this.$router.go(0)
      } catch (err) {
        this.$notificarErro(err)
      }
    },
    async listarUsuarios () {
      try {
        const { data } = await ListarUsuarios()
        this.usuarios = data.users
      } catch (error) {
        console.error(error)
        this.$notificarErro(this.$t('contacts.notifications.errors.loadUsers'), error)
      }
    },
    async listarEtiquetas () {
      const { data } = await ListarEtiquetas(true)
      this.etiquetas = data
      this.tagsOptions = data.map(tag => ({ id: tag.id, tag: tag.tag }))
    },
    downloadFile (downloadLink) {
      const link = document.createElement('a')
      link.href = downloadLink
      link.setAttribute('download', 'contatos.xlsx')
      link.style.display = 'none'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    },
    handleExportContacts () {
      ExportarArquivoContato()
        .then(res => {
          const downloadLink = res.data.downloadLink
          this.downloadFile(downloadLink)
        })
        .catch(error => {
          console.error('Erro ao exportar contatos:', error)
        })
    },
    LOAD_CONTACTS (contacts) {
      const newContacts = []
      contacts.forEach(contact => {
        const contactIndex = this.contacts.findIndex(c => c.id === contact.id)
        if (contactIndex !== -1) {
          this.contacts[contactIndex] = contact
        } else {
          newContacts.push(contact)
        }
      })
      const contactsObj = [...this.contacts, ...newContacts]
      this.contacts = contactsObj
    },
    UPDATE_CONTACTS (contact) {
      const newContacts = [...this.contacts]
      const contactIndex = newContacts.findIndex(c => c.id === contact.id)
      if (contactIndex !== -1) {
        newContacts[contactIndex] = contact
      } else {
        newContacts.unshift(contact)
      }
      this.contacts = [...newContacts]
    },
    fecharModalCanal() {
      this.modalSelecionarCanal = false
      this.canalSelecionado = null
      this.filaSelecionada = null
      this.contatoAtual = null
      this.tipoCanal = ''
      this.erro = null
    },
    DELETE_CONTACT (contactId) {
      const newContacts = [...this.contacts]
      const contactIndex = newContacts.findIndex(c => c.id === contactId)
      if (contactIndex !== -1) {
        newContacts.splice(contactIndex, 1)
      }
      this.contacts = [...newContacts]
    },
    filtrarContato (data) {
      this.contacts = []
      this.params.pageNumber = 1
      this.params.searchParam = data
      this.loading = true
      this.listarContatos()
    },
    filtrarContatoAdicionais (data) {
      this.contacts = []
      this.params.pageNumber = 1
      this.params.searchParamAdicional = data
      this.loading = true
      this.listarContatos()
    },
    async listarContatos () {
      this.loading = true
      const params = {
        ...this.params,
        walletId: this.selectedWallet || null,
        tagId: this.selectedTag ? this.selectedTag.id : null
      }
      const { data } = await ListarContatos(params)
      // console.log(data.contacts)
      // const user = this.usuario
      // console.log(data)
      // data.contacts = data.contacts.filter(function (element) {
      //   return (user.profile == 'admin' || element.tickets[0].userId == user.userId)
      // })
      this.params.hasMore = data.hasMore
      this.LOAD_CONTACTS(data.contacts)
      this.loading = false
      this.pagination.lastIndex = this.contacts.length - 1
      this.pagination.rowsNumber = data.count
    },
    onScroll ({ to, ref, ...all }) {
      if (this.loading !== true && this.params.hasMore === true && to === this.pagination.lastIndex) {
        this.loading = true
        this.params.pageNumber++
        this.listarContatos()
      }
    },
    async handleSaveTicket(contact, channel) {
      if (!contact.id) return

      try {
        this.contatoAtual = contact
        this.tipoCanal = channel

        const { data } = await ListarCanalUsuario(channel)
        this.canaisUsuario = data

        if (this.canaisUsuario.length === 0) {
          this.$q.notify({
            message: this.$t('newticket.noChannelsAvailable'),
            type: 'negative',
            position: 'top'
          })
          return
        }

        this.canalSelecionado = this.canaisUsuario.length > 0 ? this.canaisUsuario[0].id : null

        this.filaSelecionada = this.cUserQueues.length > 0 ? this.cUserQueues[0].id : null

        this.modalSelecionarCanal = true
      } catch (error) {
        this.$notificarErro(this.$t('newticket.loadChannels'), error)
      }
    },
    editContact (contactId) {
      this.selectedContactId = contactId
      this.modalContato = true
    },
    deleteContact (contactId) {
      this.$q.dialog({
        title: this.$t('contacts.modals.delete.title'),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarContato(contactId)
          .then(res => {
            this.DELETE_CONTACT(contactId)
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: this.$t('contacts.notifications.delete.success'),
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .catch(error => {
            console.error(error)
            this.$notificarErro(this.$t('contacts.errors.notifications.deleteContact'), error)
          })
        this.loading = false
      })
    },
    maskPhoneNumber(phoneNumber) {
      if (!phoneNumber) return ''
      const visiblePart = phoneNumber.substring(0, 4)
      const hiddenPart = '*'.repeat(phoneNumber.length - 4)
      return visiblePart + hiddenPart
    },
    abrirChatContato (ticket) {
      if (this.$q.screen.lt.md && ticket.status !== 'pending') {
        this.$root.$emit('infor-cabecalo-chat:acao-menu')
      }
      if (!(ticket.status !== 'pending' && (ticket.id !== this.$store.getters.ticketFocado.id || this.$route.name !== 'chat'))) return
      this.$store.commit('SET_HAS_MORE', true)
      this.$store.dispatch('AbrirChatMensagens', ticket)
    },
    abrirAtendimentoExistente (contato, ticket) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('contacts.newticket.ongoingservice', { name: contato.name, ticketid: ticket.id }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(async () => {
        try {
          this.abrirChatContato(ticket)
        } catch (error) {
          this.$notificarErro(
            this.$t('contacts.newticket.tokenerror'),
            error
          )
        }
      })
    },
    confirmarSincronizarContatos(channel) {
      const itens = []
      const channelId = null
      console.log(this.whatsapps)
      this.whatsapps.forEach(w => {
        if (w.type === channel) {
          itens.push({ label: w.name, value: w.id })
        }
      })
      this.$q.dialog({
        title: this.$t('contacts.modals.sync.title'),
        message: this.$t('contacts.modals.sync.message'),
        options: {
          type: 'radio',
          model: channelId,
          isValid: v => !!v,
          items: itens
        },
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'warning',
          push: true
        },
        persistent: true
      }).onOk(async (channelId) => {
        this.loading = true
        await this.sincronizarContatos(channelId)
        this.loading = false
      })
    },
    async sincronizarContatos (channelId) {
      try {
        this.loading = true
        await SyncronizarContatos(channelId)
        this.$q.notify({
          type: 'info',
          progress: true,
          position: 'top',
          textColor: 'black',
          message: this.$t('contacts.notifications.sync.inProgress'),
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (error) {
        console.error(error)
        this.$notificarErro(this.$t('contacts.errors.notifications.syncContacts'), error)
        this.loading = true
      }
      this.loading = true
    }
  },
  mounted () {
    this.loadColors()
    this.listarConfiguracoes()
    this.usuario = JSON.parse(localStorage.getItem('usuario'))
    this.userProfile = localStorage.getItem('profile')
    this.listarContatos()
    this.listarUsuarios()
    this.listarEtiquetas()
    this.listarKanbans()
  }
}
</script>

<style lang="sass" >
.my-sticky-dynamic
  /* height or max-height is important */
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th /* bg color is important for th; just specify one */
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1
  /* this will be the loading indicator */
  thead tr:last-child th
    /* height of all previous header rows */
    top: 63px
  thead tr:first-child th
    top: 0

.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

#tabela-contatos-atendimento
  thead
    th
      height: 55px

.blur-effect
  filter: blur(0px)

</style>
