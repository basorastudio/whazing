<template>
  <div class="full-width">
    <q-card flat class="no-shadow">
      <q-tabs
        v-model="tab"
        dense
        class="text-primary"
        active-color="color-light2"
        indicator-color="color-light2"
        align="justify"
      >
        <q-tab name="Filas" label="Colas" />
        <q-tab name="Integrações" label="Integraciones" />
      </q-tabs>
      <q-separator />

      <q-tab-panels v-model="tab" animated>
        <q-tab-panel name="Filas" class="q-pa-none">
          <filas/>
        </q-tab-panel>

        <q-tab-panel name="Integrações" class="q-pa-none">
          <integracoes/>
        </q-tab-panel>
      </q-tab-panels>
    </q-card>
  </div>
</template>

<script>
import filas from './filas.vue'
import integracoes from './integracoes/Index.vue'

export default {
  data () {
    return {
      tab: 'Filas',
      innerTab: 'innerMails',
      splitterModel: 20
    }
  },
  components: {
    filas,
    integracoes
  }
}
</script>
