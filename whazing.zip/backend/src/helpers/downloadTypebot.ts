import fs from "fs";
import path from "path";
import * as ytdl from "@distube/ytdl-core"; // Assuming ytdl-core exports this way
import fluent_ffmpeg from "fluent-ffmpeg";
import axios from "axios";
import File from "../models/File"; // Assuming File model path
import { spawn } from "child_process";
import ffmpegPath from "ffmpeg-static"; // Assuming ffmpeg-static exports the path as default

interface DownloadOptions {
  url: string;
}

interface TenantInfo {
  tenantId: string | number; // Assuming tenantId can be string or number
}

interface DownloadResult {
  mediaType: string;
  mediaUrl: string;
}

// Función auxiliar para asegurar una URL de YouTube válida (simplificada)
function ensureValidYouTubeUrl(url: string): string {
  if (!url.includes("youtube.com") && !url.includes("youtu.be")) {
    return "https://" + url; // Asume https si no está presente
  }
  return url;
}

async function downloadYouTubeVideo(
  videoUrl: string,
  outputPath: string
): Promise<void> {
  if (!ytdl.validateURL(videoUrl)) {
    throw new Error(
      "URL inválida proporcionada para descarga de YouTube: " + videoUrl
    );
  }

  const videoId = ytdl.getURLVideoID(videoUrl);
  console.log("Descargando vídeo de YouTube con ID: " + videoId);

  const info = await ytdl.getInfo(videoUrl);

  const audioStream = ytdl.downloadFromInfo(info, { quality: "highestaudio" });
  const videoStream = ytdl.downloadFromInfo(info, { quality: "highestvideo" });

  const ffmpegProcess = spawn(
    ffmpegPath!,
    [
      // Using non-null assertion for ffmpegPath
      "-loglevel",
      "error",
      "-hide_banner",
      "-i",
      "pipe:3", // Audio input from pipe 3
      "-i",
      "pipe:4", // Video input from pipe 4
      "-c:v",
      "copy", // Copy video codec
      "-c:a",
      "aac", // Convert audio to aac
      "-strict",
      "experimental", // Needed for some AAC conversions
      "-f",
      "mp4", // Output format
      outputPath
    ],
    {
      windowsHide: true,
      stdio: [
        "inherit",
        "inherit",
        "inherit", // stdin, stdout, stderr
        "pipe",
        "pipe",
        "pipe" // pipe:3, pipe:4, pipe:5 (extra pipes if needed)
      ]
    }
  );

  // Pipe streams to ffmpeg
  // Make sure the indices match the '-i' options in ffmpeg arguments
  if (ffmpegProcess.stdio[3]) {
    audioStream.pipe(ffmpegProcess.stdio[3]);
  }
  if (ffmpegProcess.stdio[4]) {
    videoStream.pipe(ffmpegProcess.stdio[4]);
  }

  return new Promise((resolve, reject) => {
    ffmpegProcess.on("close", code => {
      if (code === 0) {
        console.log(
          "Download e combinación de vídeo de YouTube con ID: " +
            videoId +
            " concluído!"
        );
        resolve();
      } else {
        console.error("Erro ao executar o ffmpeg: código " + code);
        reject(new Error("Ffmpeg: código de error " + code));
      }
    });

    ffmpegProcess.on("error", err => {
      console.error("Erro ao executar o ffmpeg:", err);
      reject(err);
    });
  });
}

async function downloadFiles(
  url: string
): Promise<{ filePath: string; mimeType: string; extension: string }> {
  const response = await axios.get(url, { responseType: "arraybuffer" });
  const contentType = response.headers["content-type"];
  const extension = contentType.split("/")[1] || "tmp"; // Fallback extension
  const tempFileName = `typebot_${Date.now()}.${extension}`;
  const tempDir = path.join(__dirname, "..", "..", "public"); // Assumes a public folder at project root
  const tempFilePath = path.join(tempDir, tempFileName);

  // Ensure directory exists (optional, depends on setup)
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
  }

  fs.writeFileSync(tempFilePath, response.data);

  // Check if it's audio and convert to mp3 if necessary (example)
  if (contentType.startsWith("audio/")) {
    const mp3FileName = `typebot_${Date.now()}.mp3`;
    const mp3FilePath = path.join(tempDir, mp3FileName);

    return new Promise((resolve, reject) => {
      fluent_ffmpeg(tempFilePath)
        .audioCodec("libmp3lame") // Or another suitable codec like 'aac'
        .toFormat("mp3")
        .save(mp3FilePath)
        .on("end", () => {
          fs.unlinkSync(tempFilePath); // Remove original file after conversion
          resolve({
            filePath: mp3FilePath,
            mimeType: "audio/mp3",
            extension: "mp3"
          });
        })
        .on("error", err => {
          fs.unlinkSync(tempFilePath); // Clean up on error
          console.error("Error al convertir audio:", err);
          reject(new Error("Error al convertir archivo de audio"));
        });
    });
  }

  return {
    filePath: tempFilePath,
    mimeType: contentType,
    extension: extension
  };
}

export const downloadTypebot = async (
  options: DownloadOptions,
  tenantInfo: TenantInfo
): Promise<DownloadResult> => {
  const { url } = options;
  const { tenantId } = tenantInfo;

  let mediaType: string | undefined;
  let mediaUrl: string | undefined;

  // Check cache/database first
  const existingFile = await File.findOne({
    where: { url: url, tenantId: tenantId }
  });

  if (existingFile) {
    mediaUrl = existingFile.mediaUrl;
    mediaType = existingFile.mediaType;
  } else {
    const publicTenantDir = path.join(
      __dirname,
      "..",
      "..",
      "public",
      String(tenantId)
    ); // Directory specific to tenant
    const finalDir = path.join("public", String(tenantId)); // Relative path for URL

    if (!fs.existsSync(publicTenantDir)) {
      fs.mkdirSync(publicTenantDir, { recursive: true });
    }

    if (url.startsWith("http://") || url.startsWith("https://")) {
      // YouTube URL Handling
      if (url.includes("youtube.com") || url.includes("youtu.be")) {
        const validYouTubeUrl = ensureValidYouTubeUrl(url);
        if (!ytdl.validateURL(validYouTubeUrl)) {
          throw new Error(
            `URL inválida de YouTube proporcionada: ${validYouTubeUrl}`
          );
        }

        const tempFileName = `typebot_${Date.now()}.mp4`;
        const tempFilePath = path.join(
          __dirname,
          "..",
          "..",
          "public",
          tempFileName
        ); // Temporary storage
        const finalFileName = tempFileName; // Keep same name for simplicity
        const finalFilePath = path.join(publicTenantDir, finalFileName);

        console.log(`Iniciando descarga de YouTube: ${validYouTubeUrl}`);
        await downloadYouTubeVideo(validYouTubeUrl, tempFilePath);
        console.log(
          `Descarga de YouTube completa, moviendo a: ${finalFilePath}`
        );

        fs.renameSync(tempFilePath, finalFilePath);

        mediaType = "video";
        mediaUrl = path.join(finalDir, finalFileName).replace(/\\/g, "/"); // Relative URL path
      } else {
        // Generic File Download
        console.log(`Iniciando descarga de archivo general: ${url}`);
        const downloadedFileInfo = await downloadFiles(url);
        console.log(
          `Descarga de archivo completa, procesando: ${downloadedFileInfo.filePath}`
        );

        const finalFileName = `typebot_${Date.now()}.${downloadedFileInfo.extension}`;
        const finalFilePath = path.join(publicTenantDir, finalFileName);

        fs.renameSync(downloadedFileInfo.filePath, finalFilePath);
        console.log(`Archivo movido a: ${finalFilePath}`);

        mediaType = downloadedFileInfo.mimeType.split("/")[0]; // e.g., 'audio', 'video', 'image'
        mediaUrl = path.join(finalDir, finalFileName).replace(/\\/g, "/"); // Relative URL path
      }
    } else {
      throw new Error(`Formato de URL no soportado: ${url}`);
    }

    // Save file info to database
    await File.create({
      url: url,
      tenantId: tenantId,
      mediaType: mediaType,
      mediaUrl: mediaUrl
    });
    console.log(
      `Información del archivo guardada en la base de datos para la URL: ${url}`
    );
  }

  if (!mediaType || !mediaUrl) {
    throw new Error(
      `No se pudo determinar mediaType o mediaUrl para la URL: ${url}`
    );
  }

  return { mediaType, mediaUrl };
};

// Export specific function if needed elsewhere by that name
export const downloadFromYoutube = downloadYouTubeVideo;
