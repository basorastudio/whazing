import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'proxyUrl' column to the 'Whatsapps' table
    await queryInterface.addColumn(
      'Whatsapps', // Table name
      'proxyUrl',  // New column name
      {
        type: DataTypes.TEXT, // TEXT for potentially long URLs
        allowNull: true,
        defaultValue: null,
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'proxyUrl' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps', // Table name
      'proxyUrl'   // Column name to remove
    );
  }
};

export = migration;