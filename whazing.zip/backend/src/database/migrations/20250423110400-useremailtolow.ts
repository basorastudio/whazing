import { QueryInterface, Sequelize, QueryTypes } from "sequelize"; // Added QueryTypes
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Update all email addresses in the Users table to lowercase
    await queryInterface.sequelize.query(
      `UPDATE "Users" SET email = LOWER(email) WHERE email IS NOT NULL`,
      { type: QueryTypes.UPDATE } // Specify query type
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // This migration cannot be safely reverted as original case information is lost.
    console.log(
      "Esta migración no se puede revertir ya que se pierde la información original de mayúsculas/minúsculas del correo electrónico."
    );
    // Throwing an error prevents accidental rollback, but might block other rollbacks.
    // throw new Error('Cannot revert lowercase email migration.');
    // Alternatively, do nothing:
    return Promise.resolve();
  }
};

export = migration;
