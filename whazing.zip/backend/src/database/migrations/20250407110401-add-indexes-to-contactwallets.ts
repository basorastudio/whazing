import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'ContactWallets';
    // Add index on [contactId]
    await queryInterface.addIndex(tableName, ['contactId'], {
      name: 'idx_contactwallets_contactid', // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'ContactWallets';
    // Remove the index
    await queryInterface.removeIndex(tableName, 'idx_contactwallets_contactid');
  }
};

export = migration;