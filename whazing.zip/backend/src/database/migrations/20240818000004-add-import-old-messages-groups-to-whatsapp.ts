import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'importOldMessagesGroups' column to the 'Whatsapps' table
    // Likely a flag to indicate whether old group messages should be imported.
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "importOldMessagesGroups", // New column name
      {
        type: DataTypes.BOOLEAN,
        allowNull: true // Allow null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'importOldMessagesGroups' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      "Whatsapps", // Table name
      "importOldMessagesGroups" // Column name to remove
    );
  }
};

export = migration;
