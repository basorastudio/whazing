<template>
  <q-page class="embedded-page">
    <router-view />
  </q-page>
</template>

<script>
export default {
  name: 'EmbeddedPage',
  mounted() {
    // Configurar comunicación con la página padre
    window.addEventListener('message', this.handleParentMessage);
    // Notificar que el iframe está listo
    this.notifyParentReady();
  },
  beforeDestroy() {
    window.removeEventListener('message', this.handleParentMessage);
  },
  methods: {
    notifyParentReady() {
      window.parent.postMessage({
        type: 'WHAZING_READY',
        height: document.documentElement.scrollHeight
      }, '*');
    },
    handleParentMessage(event) {
      // Manejar mensajes de la página padre
      const { type, data } = event.data;
      switch (type) {
        case 'INITIALIZE':
          // Manejar inicialización
          break;
        // Agregar más casos según sea necesario
      }
    },
    // Método para actualizar la altura del iframe
    updateIframeHeight() {
      window.parent.postMessage({
        type: 'RESIZE',
        height: document.documentElement.scrollHeight
      }, '*');
    }
  }
};
</script>

<style lang="scss">
.embedded-page {
  // Estilos específicos para la versión embebida
  min-height: 100vh;
  overflow-x: hidden;
  
  // Ocultar elementos que no deberían mostrarse en la versión embebida
  .q-drawer,
  .q-footer {
    display: none !important;
  }
}
</style>