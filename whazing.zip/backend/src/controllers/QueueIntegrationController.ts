// --- START OF FILE QueueIntegrationController.ts ---

import type { Request, Response } from "express";
// Assuming Yup for validation might be needed later, though not used in original
// import * as Yup from 'yup';
// import AppError from '../errors/AppError'; // Assuming path if error handling is added

import CreateQueueIntegrationService from "../services/QueueIntegrationServices/CreateQueueIntegrationService"; // Assuming path
import DeleteQueueIntegrationService from "../services/QueueIntegrationServices/DeleteQueueIntegrationService"; // Assuming path
import ListQueueIntegrationService from "../services/QueueIntegrationServices/ListQueueIntegrationService"; // Assuming path
import ShowQueueIntegrationService from "../services/QueueIntegrationServices/ShowQueueIntegrationService"; // Assuming path
import UpdateQueueIntegrationService from "../services/QueueIntegrationServices/UpdateQueueIntegrationService"; // Assuming path

interface StoreBody {
  type: string;
  name: string;
  projectName?: string;
  jsonContent?: string;
  language?: string;
  urlN8N?: string;
  typebotExpires?: number;
  typebotKeywordFinish?: string;
  typebotSlug?: string;
  typebotUnknownMessage?: string;
  typebotKeywordRestart?: string;
  typebotRestartMessage?: string;
  n8nApiKey?: string;
  aiModel?: string;
  apiKey?: string;
  maxTokens?: number;
  temperature?: number;
  maxMessages?: number;
  voice?: string;
  voiceKey?: string;
  voiceRegion?: string;
  queueId: number | string; // Queue ID it belongs to
}

interface UpdateBody extends Partial<StoreBody> {
  // All fields optional for update
  // No additional fields needed for update specific case here
}

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user; // Assuming tenantId is available
  const integrations = await ListQueueIntegrationService({ tenantId });
  return res.status(200).json(integrations);
};

export const store = async (req: Request, res: Response): Promise<Response> => {
  const {
    type,
    name,
    projectName,
    jsonContent,
    language,
    urlN8N,
    typebotExpires,
    typebotKeywordFinish,
    typebotSlug,
    typebotUnknownMessage,
    typebotKeywordRestart,
    typebotRestartMessage,
    n8nApiKey,
    aiModel,
    apiKey,
    maxTokens,
    temperature,
    maxMessages,
    voice,
    voiceKey,
    voiceRegion,
    queueId // The ID of the queue this integration belongs to
  } = req.body as StoreBody;
  const { tenantId } = req.user;
  const tenant = Number(tenantId); // Ensure tenantId is a number

  const integrationData = {
    type,
    name,
    projectName,
    jsonContent,
    language,
    urlN8N,
    tenantId: tenant,
    typebotExpires,
    typebotKeywordFinish,
    typebotSlug,
    typebotUnknownMessage,
    typebotKeywordRestart,
    typebotRestartMessage,
    n8nApiKey,
    aiModel,
    apiKey,
    maxTokens,
    temperature,
    maxMessages,
    voice,
    voiceKey,
    voiceRegion,
    queueId // Pass queueId to the service
  };

  const integration = await CreateQueueIntegrationService(integrationData);
  return res.status(201).json(integration); // 201 Created
};

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { integrationId } = req.params;
  const { tenantId } = req.user;
  const tenant = Number(tenantId); // Ensure tenantId is a number

  const integration = await ShowQueueIntegrationService(integrationId, tenant); // Pass ID and tenantId
  return res.status(200).json(integration);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { integrationId } = req.params;
  const integrationData = req.body as UpdateBody; // Use UpdateBody interface
  const { tenantId } = req.user;
  const tenant = Number(tenantId); // Ensure tenantId is a number

  const updatedIntegration = await UpdateQueueIntegrationService({
    integrationData: integrationData,
    integrationId: integrationId, // Pass the ID from params
    tenantId: tenant // Pass tenantId
  });

  return res.status(200).json(updatedIntegration);
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { integrationId } = req.params;
  const { tenantId } = req.user;
  const tenant = Number(tenantId); // Ensure tenantId is a number

  await DeleteQueueIntegrationService(integrationId, tenant); // Pass ID and tenantId
  return res.status(204).send(); // 204 No Content is appropriate for successful deletion
};

// --- END OF FILE QueueIntegrationController.ts ---
