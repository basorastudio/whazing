import { QueryInterface, Sequelize } from 'sequelize';

export = {
  up: async (queryInterface: QueryInterface, sequelize: Sequelize): Promise<void> => {
    // Elimina la restricción de clave primaria de la tabla 'Settings'
    // El nombre 'Settings_pkey' es el nombre predeterminado en PostgreSQL.
    await queryInterface.removeConstraint('Settings', 'Settings_pkey');
  },

  down: async (queryInterface: QueryInterface, sequelize: Sequelize): Promise<void> => {
    // Vuelve a añadir la restricción de clave primaria sobre la columna 'key'
    await queryInterface.addConstraint('Settings', {
        fields: ['key'], // Columna que será la clave primaria
        name: 'Settings_pkey', // Nombre de la restricción
        type: 'primary key' // Tipo de restricción
    });
  }
};