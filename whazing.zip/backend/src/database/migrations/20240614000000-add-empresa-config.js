'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn('Empresas', 'colorPrimario', {
      type: Sequelize.STRING,
      defaultValue: '#5c67f2'
    });
    await queryInterface.addColumn('Empresas', 'colorSecundario', {
      type: Sequelize.STRING,
      defaultValue: '#f5f5f9'
    });
    await queryInterface.addColumn('Empresas', 'logoPath', {
      type: Sequelize.STRING
    });
    await queryInterface.addColumn('Empresas', 'nombreApp', {
      type: Sequelize.STRING,
      defaultValue: 'Whazing'
    });
  },

  down: async (queryInterface) => {
    await queryInterface.removeColumn('Empresas', 'colorPrimario');
    await queryInterface.removeColumn('Empresas', 'colorSecundario');
    await queryInterface.removeColumn('Empresas', 'logoPath');
    await queryInterface.removeColumn('Empresas', 'nombreApp');
  }
};