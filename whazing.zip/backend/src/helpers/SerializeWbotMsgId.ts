// Define basic types or import them if available from Baileys/your models
interface ContactInfo {
    number: string;
    // other properties if needed
}

interface MessageInfo {
    id: string;
    // other properties if needed
}

interface WbotMessage {
     key: {
        remoteJid: string;
        id: string;
        fromMe: boolean;
    };
    // other wbot message properties
}

// Original function name kept
export const SerializeWbotMsgId = (wbotMsg: WbotMessage, msg: MessageInfo): string => {
    // Example logic based on typical Baileys structure - adjust if needed
    const remoteJid = wbotMsg.key.remoteJid;
    const msgId = msg.id; // Assuming msg has the DB ID
    const fromMe = wbotMsg.key.fromMe;

    // Extract number part and determine suffix (.us or .net)
    // This part might need adjustment based on exact remoteJid format
    const numberPart = remoteJid.split('@')[0];
    const serverSuffix = remoteJid.endsWith('g.us') ? 'g.us' : 's.whatsapp.net'; // Common suffixes

    const serializedId = `${fromMe}_${numberPart}@${serverSuffix}_${msgId}`;

    return serializedId;
};

export default SerializeWbotMsgId;