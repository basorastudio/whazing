<template>
  <div class="mass-container container-rounded-10" :class="$q.dark.isActive ? 'text-color-dark bg-grey-10' : 'container-border'" v-if="userProfile === 'admin'">
    <q-list class="text-weight-medium">
      <q-item-label header :class="['text-bold text-h6 q-mb-lg', $q.dark.isActive ? 'text-color-dark' : 'text-black']">
        {{ $t('configuracoes.titulo') }}
      </q-item-label>
      <q-item-label caption class="q-mt-lg q-pl-sm">{{ $t('configuracoes.modulo_atendimento') }}</q-item-label>
      <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.agrupar_mensagens') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.agrupar_mensagens_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="GroupTicketsMessages" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="GroupTicketsMessages === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('GroupTicketsMessages')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.visualizar_mensagens_fila') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.visualizar_mensagens_fila_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="MessagesforTicket" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="MessagesforTicket === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('MessagesforTicket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.admin_supervisor_auditoria') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.admin_supervisor_auditoria_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="auditMode" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="auditMode === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('auditMode')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.nao_visualizar_tickets_privados') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.nao_visualizar_tickets_privados_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="NotViewAssignedTickets" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="NotViewAssignedTickets === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('NotViewAssignedTickets')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.nao_visualizar_tickets_chatbot') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.nao_visualizar_tickets_chatbot_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="NotViewTicketsChatBot" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="NotViewTicketsChatBot === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('NotViewTicketsChatBot')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.habilitar_guia_chatbot') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.habilitar_guia_chatbot_desc') }}</q-item-label>
        </q-item-section>

      <q-item-section avatar>
        <q-toggle
            v-model="chatbotLane"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="chatbotLane === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('chatbotLane')"
        />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.ocultar_guia_sem_tickets') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.ocultar_guia_sem_tickets_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="hidetab" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="hidetab === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('hidetab')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.exibir_status_conexoes') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.exibir_status_conexoes_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ExibirConexao" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="ExibirConexao === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('ExibirConexao')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.hidenumber') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.hidenumber_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="HideNumber" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="HideNumber === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('HideNumber')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.contatos_admin') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.contatos_admin_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ContactAdmin" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="ContactAdmin === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('ContactAdmin')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.forcar_atendimento_carteira') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.forcar_atendimento_carteira_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="DirectTicketsToWallets" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="DirectTicketsToWallets === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('DirectTicketsToWallets')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.listar_contatos_carteira') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.listar_contatos_carteira_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userContactWallet" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="userContactWallet === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('userContactWallet')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.fluxo_ativo_bot') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.fluxo_ativo_bot_desc') }}</q-item-label>
        </q-item-section>
        <q-btn  @click="resetarFluxoAtivo"
            flat
            icon="mdi-replay"
            color="negative"
            class="bg-padrao btn-rounded" >
          <q-tooltip content-class="bg-negative text-bold">
            {{ $t('configuracoes.resetar_fluxo') }}
          </q-tooltip>
        </q-btn>
        <q-item-section avatar>
          <q-select style="width: 300px" outlined dense v-model="botTicketActive" :options="listaChatFlow" map-options
            emit-value option-value="id" option-label="name" @input="atualizarConfiguracao('botTicketActive')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="canAccessPage">
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.ignorar_mensagens_grupo') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.ignorar_mensagens_grupo_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ignoreGroupMsg" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
            :color="ignoreGroupMsg === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
            @input="atualizarConfiguracao('ignoreGroupMsg')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="canAccessPage">
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.habilitar_notificacoes_grupo') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.habilitar_notificacoes_grupo') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="groupnotification" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="groupnotification === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('groupnotification')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.ignorar_mensagens_externas') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.ignorar_mensagens_externas_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="IgnoreMessageExt" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
                    :color="IgnoreMessageExt === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
                    @input="atualizarConfiguracao('IgnoreMessageExt')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.recusar_chamadas') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.recusar_chamadas_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="rejectCalls" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
            :color="rejectCalls === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
            @input="atualizarConfiguracao('rejectCalls')" />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="rejectCalls === 'enabled'">
        <div class="col-12">
          <q-input v-model="callRejectMessage" type="textarea" autogrow dense outlined
                   :label="$t('configuracoes.mensagem_rejeicao')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('callRejectMessage')" />
        </div>
      </div>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.permitir_desabilitar_assinatura') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.permitir_desabilitar_assinatura_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userDisableSignature" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="userDisableSignature === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('userDisableSignature')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.usuarios_espiar_ticket') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.usuarios_espiar_ticket_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="spyticket" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="spyticket === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('spyticket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.usuarios_reabrir_ticket') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.usuarios_reabrir_ticket_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userReopenTicket" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="userReopenTicket === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('userReopenTicket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
<q-item-label>{{ $t('configuracoes.voltar_tickets_pendentes') }}</q-item-label>
<q-item-label caption>{{ $t('configuracoes.voltar_tickets_pendentes_desc') }}</q-item-label>
        </q-item-section>

      <q-item-section avatar>
        <q-toggle
            v-model="autoPending"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="autoPending === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('autoPending')"
        />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="autoPending === 'enabled'">
        <div class="col-12">
          <q-input
              v-model="autoPendingTime"
              type="number"
              :label="$t('configuracoes.tempo_voltar_pendentes')"
              dense
              outlined
              autogrow
              debounce="700"
              input-style="min-height: 6vh; max-height: 9vh;"
              @input="atualizarConfiguracao('autoPendingTime')"
            />
        </div>
      </div>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.max_msg_horario') }}</q-item-label>
            <q-item-label caption>{{ $t('configuracoes.max_msg_horario_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
              v-model="maxRetriesBusinessHours"
              type="number"
              dense
              outlined
              debounce="700"
              @input="atualizarConfiguracao('maxRetriesBusinessHours')"
              style="width: 300px"
            />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.qtd_tickets_abertos') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.qtd_tickets_abertos_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
            v-model="TicketsLimitOpen"
            type="number"
            dense
            outlined
            debounce="700"
            @input="atualizarConfiguracao('TicketsLimitOpen')"
            style="width: 300px"
          />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.qtd_tickets_pendentes') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.qtd_tickets_pendentes_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
            v-model="TicketsLimitPending"
            type="number"
            dense
            outlined
            debounce="700"
            @input="atualizarConfiguracao('TicketsLimitPending')"
            style="width: 300px"
          />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.qtd_tickets_fechados') }}</q-item-label>
            <q-item-label caption>{{ $t('configuracoes.qtd_tickets_fechados_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
              v-model="TicketsLimitClosed"
              type="number"
              dense
              outlined
              debounce="700"
              @input="atualizarConfiguracao('TicketsLimitClosed')"
              style="width: 300px"
            />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.exibir_ultimo_ticket') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.exibir_ultimo_ticket_desc') }}</q-item-label>
        </q-item-section>

        <q-item-section avatar>
          <q-toggle
            v-model="GroupClosedTicket"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="GroupClosedTicket === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('GroupClosedTicket')"
          />
        </q-item-section>
      </q-item>

      <q-item-label caption class="q-mt-lg q-pl-sm">{{ $t('configuracoes.modulo_crm') }}</q-item-label>
      <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.compartilhar_crm') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.compartilhar_crm_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanGlobal" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanGlobal === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanGlobal')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="KanbanGlobal === 'disabled'">
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.listar_contatos_sem_usuario') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.listar_contatos_sem_usuario_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanUserNull" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanUserNull === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanUserNull')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="KanbanNoTicket === 'disabled'">
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.listar_contatos_fechados') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.listar_contatos_fechados_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanTicketClosed" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanTicketClosed === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanTicketClosed')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="KanbanGlobal === 'disabled'">
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.separar_lane_usuario') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.separar_lane_usuario_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanforUser" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanforUser === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanforUser')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracoes.kanbannoticket') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracoes.kanbannoticket_desc') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanNoTicket" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanNoTicket === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanNoTicket')" />
        </q-item-section>
      </q-item>

    </q-list>

<q-separator spaced />
  </div>
</template>

<script>
import { ListarChatFlow } from 'src/service/chatFlow'
import { ListarConfiguracoes, AlterarConfiguracao } from 'src/service/configuracoes'
import { MostrarPlano } from 'src/service/empresas'
import { ListarCores } from 'src/service/configuracoesgeneral'
export default {
  name: 'IndexConfiguracoes',
  data() {
    return {
      userProfile: 'user',
      tempoOptions: [
        { value: '10', label: this.$t('configuracoes.10minutos') },
        { value: '60', label: this.$t('configuracoes.1hora') },
        { value: '1440', label: this.$t('configuracoes.1dia') },
        { value: '7200', label: this.$t('configuracoes.5dias') },
        { value: '14400', label: this.$t('configuracoes.10dias') }
      ],
      configuracoes: [],
      listaChatFlow: [],
      NotViewAssignedTickets: null,
      NotViewTicketsChatBot: null,
      ContactAdmin: null,
      HideNumber: null,
      DirectTicketsToWallets: null,
      botTicketActive: null,
      ignoreGroupMsg: null,
      userContactWallet: null,
      rejectCalls: null,
      userDisableSignature: null,
      sendGreetingAccepted: null,
      sendMsgTransfTicket: null,
      spyticket: null,
      userReopenTicket: null,
      universalCounter: null,
      chatbotLane: null,
      callRejectMessage: '',
      autoPendingTime: null,
      canAccessPage: false,
      autoPending: null,
      hidetab: null,
      maxRetriesBusinessHours: null,
      TicketsLimitOpen: null,
      TicketsLimitPending: null,
      TicketsLimitClosed: null,
      groupnotification: null,
      KanbanUserNull: null,
      KanbanTicketClosed: null,
      KanbanforUser: null,
      KanbanGlobal: null,
      KanbanNoTicket: null,
      IgnoreMessageExt: null,
      GroupTicketsMessages: null,
      MessagesforTicket: null,
      auditMode: null,
      GroupClosedTicket: null,
      ExibirConexao: null
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.group !== false
      } catch (error) {
        console.error('Erro ao carregar o plano:', error)
      }
    },
    resetarFluxoAtivo() {
      this.botTicketActive = ''
      this.atualizarConfiguracao('botTicketActive')
    },
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoes()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        let value = el.value
        if (el.key === 'botTicketActive' && el.value) {
          value = +el.value
        }
        this.$data[el.key] = value
      })
    },
    async listarChatFlow() {
      const { data } = await ListarChatFlow()
      this.listaChatFlow = data.chatFlow
    },
    async atualizarConfiguracao(key) {
      if (key === 'autoCloseTime') {
        const params = { key, value: this.$data[key].value }
        try {
          await AlterarConfiguracao(params)
          this.$q.notify({
            type: 'positive',
            message: this.$t('configuracoes.sucess'),
            progress: true,
            actions: [{ icon: 'close', round: true, color: 'white' }]
          })
        } catch (error) {
          console.error('error - AlterarConfiguracao', error)
          this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
          this.$notificarErro(this.$t('configuracoes.erro'), error)
        }
      } else {
        const params = { key, value: this.$data[key] }
        try {
          await AlterarConfiguracao(params)
          this.$q.notify({
            type: 'positive',
            message: this.$t('configuracoes.sucess'),
            progress: true,
            actions: [{ icon: 'close', round: true, color: 'white' }]
          })
        } catch (error) {
          console.error('error - AlterarConfiguracao', error)
          this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
          this.$notificarErro(this.$t('configuracoes.erro'), error)
        }
      }
    }
  },
  async mounted() {
    this.userProfile = localStorage.getItem('profile')
    this.loadColors()
    this.listarPlano()
    await this.listarConfiguracoes()
    await this.listarChatFlow()
  }
}
</script>

<style lang="scss" scoped></style>
