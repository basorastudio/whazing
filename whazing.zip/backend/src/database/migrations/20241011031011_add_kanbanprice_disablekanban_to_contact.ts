import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add 'disableKanban' and 'kanbanPrice' columns to 'Contacts' table
    await queryInterface.addColumn("Contacts", "disableKanban", {
      type: DataTypes.BOOLEAN,
      allowNull: false, // Cannot be null
      defaultValue: false // Default to enabled
    });
    await queryInterface.addColumn("Contacts", "kanbanPrice", {
      type: DataTypes.STRING, // Price stored as string? Consider DECIMAL or INTEGER if numeric.
      allowNull: true,
      defaultValue: null
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added columns
    await queryInterface.removeColumn("Contacts", "kanbanPrice");
    await queryInterface.removeColumn("Contacts", "disableKanban");
  }
};

export = migration;
