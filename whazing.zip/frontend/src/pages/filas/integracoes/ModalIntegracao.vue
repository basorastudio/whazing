<template>
  <q-dialog
    persistent
    :value="modalIntegracao"
    @hide="fecharModal"
    @show="abrirModal"
  >
    <q-card
      class="q-pa-lg modal-container container-rounded-10"
    >

      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ integracaoEdicao.id ? $t('integracao.tituloModalEditar') : $t('integracao.tituloModal') }}
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="container-border container-rounded-10">
        <div class="text-h6 font-family-main q-mb-sm">
          {{ $t('integracao.secaoInformacoes') }}
        </div>
          <div class="col-12 q-my-sm">
            <q-select :disable="!!integracao.id"
              v-model="integracao.type"
              :options="integracaoTypes"
              :validator="$v.integracao.type"
              @blur="$v.integracao.type.$touch"
              :label="$t('integracao.campoTipo')"
              emit-value
              map-options
              filled />
          </div>
          <div class="col-12">
        <q-input
          class="row col"
          rounded
          outlined
          v-model="integracao.name"
          :validator="$v.integracao.name"
          @blur="$v.integracao.name.$touch"
          :label="$t('integracao.campoNome')"
        />
          </div>
        <div class="col-12 q-my-sm">
          <q-select
            v-if="integracao.type === 'openai'"
            rounded
            outlined
            v-model="integracao.aiModel"
            :options="modelsOpenai"
            :label="$t('integracao.campoModel')"
            emit-value
            map-options
            filled />
        </div>
        <div class="col-12 q-my-sm">
          <q-select
            v-if="integracao.type === 'groq'"
            rounded
            outlined
            v-model="integracao.aiModel"
            :options="modelsGroq"
            :label="$t('integracao.campoModel')"
            emit-value
            map-options
            filled />
        </div>
        <div class="col-12 q-my-sm">
          <q-select
            v-if="integracao.type === 'deepseek'"
            rounded
            outlined
            v-model="integracao.aiModel"
            :options="modelsDeepSeek"
            :label="$t('integracao.campoModel')"
            emit-value
            map-options
            filled />
        </div>
        <div class="col-12 q-my-sm">
          <q-select
            v-if="integracao.type === 'grokx'"
            rounded
            outlined
            v-model="integracao.aiModel"
            :options="modelsXia"
            :label="$t('integracao.campoModel')"
            emit-value
            map-options
            filled />
        </div>
          <div class="col-12">
        <q-input
          v-if="integracao.type === 'typebot' | integracao.type === 'n8n'"
          class="row col"
          rounded
          outlined
          v-model="integracao.urlN8N"
          :label="$t('integracao.campoUrlIntegracao')"
        />
          </div>
        <div class="col-12">
        <textarea
          style="min-height: 25vh; max-height: 25vh;"
          class="q-pa-sm bg-white full-width rounded-borders"
          rounded
          outlined
          v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'grokx'"
          :placeholder="$t('integracao.campoPrompt')"
          v-model="integracao.jsonContent" />
        </div>
        <div class="col-12">
        <q-select
          v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === '2viaasaas' | integracao.type === 'deepseek' | integracao.type === 'openaiassistant' | integracao.type === 'grokx'"
          class="row col"
          rounded
          outlined
          :label="integracao.type === 'openai' || integracao.type === 'groq' || integracao.type === 'deepseek' || integracao.type === 'openaiassistant' || integracao.type === 'grokx'
  ? $t('integracao.campoFilaTransferencia')
  : integracao.type === '2viaasaas'
    ? $t('integracao.campoFilaTransferenciaErro')
    : ''"
          v-model="integracao.queueId"
          :options="listaFila"
          map-options
          emit-value
          option-value="id"
          option-label="queue"
          clearable
        >
          <q-tooltip>
            {{ $t('integracao.tooltipFila') }}
          </q-tooltip>
        </q-select>
        </div>
          <div class="col-12">
        <q-input
          v-if="integracao.type === 'n8n' | integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'grokx' | integracao.type === 'openaiassistant'"
          class="row col"
          rounded
          outlined
          v-model="integracao.n8nApiKey"
          :label="integracao.type === 'n8n' ? $t('integracao.campoN8nApiKey') : $t('integracao.iamsgtransferencia')"
        />
          </div>
          <div class="col-12">
        <q-input
          v-if="integracao.type === 'typebot'"
          class="row col"
          rounded
          outlined
          v-model="integracao.typebotSlug"
          :label="$t('integracao.campoTypebotSlug')"
        />
        <q-input
          v-if="integracao.type === 'typebot'"
          class="row col"
          rounded
          outlined
          type="number"
          v-model="integracao.typebotExpires"
          :label="$t('integracao.campoTypebotExpires')"
        />
        <q-input
          v-if="integracao.type === 'typebot' | integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'openaiassistant' | integracao.type === 'grokx'"
          class="row col"
          rounded
          outlined
          type="number"
          v-model="integracao.typebotDelayMessage"
          :label="$t('integracao.campoTypebotDelay')"
        />
        <q-input
          v-if="integracao.type === 'typebot'"
          class="row col"
          rounded
          outlined
          v-model="integracao.typebotKeywordFinish"
          :label="$t('integracao.campoTypebotKeywordFinish')"
        />
        <q-input
          v-if="integracao.type === 'typebot'"
          class="row col"
          rounded
          outlined
          v-model="integracao.typebotKeywordRestart"
          :label="$t('integracao.campoTypebotKeywordRestart')"
        />
        <q-input
          v-if="integracao.type === 'typebot'"
          class="row col"
          rounded
          outlined
          v-model="integracao.typebotUnknownMessage"
          :label="$t('integracao.campoTypebotUnknownMessage')"
        />
        <q-input
          v-if="integracao.type === 'typebot'"
          class="row col"
          rounded
          outlined
          v-model="integracao.typebotRestartMessage"
          :label="$t('integracao.campoTypebotRestartMessage')"
        />
            <q-input
              v-if="integracao.type === 'typebot'"
              class="row col"
              rounded
              outlined
              v-model="integracao.n8nApiKey"
              :label="$t('integracao.campoTypebotBotaoMessage')"
            />
            <q-input
              v-if="integracao.type === 'typebot'"
              class="row col"
              rounded
              outlined
              v-model="integracao.apiKey"
              :label="$t('integracao.campoTypebotTituloLista')"
            />
            <q-input
              v-if="integracao.type === 'typebot'"
              class="row col"
              rounded
              outlined
              v-model="integracao.voiceKey"
              :label="$t('integracao.campoTypebotsubTituloLista')"
            />
            <q-input
              v-if="integracao.type === 'typebot'"
              class="row col"
              rounded
              outlined
              v-model="integracao.voiceRegion"
              :label="$t('integracao.campoTypebotbotaoLista')"
            />
            <q-input
              v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === '2viaasaas' | integracao.type === 'deepseek' | integracao.type === 'openaiassistant' | integracao.type === 'grokx'"
              class="row col"
              rounded
              outlined
              v-model="integracao.apiKey"
              :label="$t('integracao.campoApiKey')"
            />
            <q-input
              v-if="integracao.type === 'openaiassistant'"
              class="row col"
              rounded
              outlined
              v-model="integracao.jsonContent"
              :label="$t('integracao.campoAssistantId')"
            />
            <q-input
              v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'grokx'"
              class="row col"
              rounded
              outlined
              type="number"
              v-model="integracao.maxTokens"
              :label="$t('integracao.campoMaxTokens')"
            />
            <q-input
              v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'grokx'"
              class="row col"
              rounded
              outlined
              type="number"
              v-model="integracao.maxMessages"
              :label="$t('integracao.campoMaxMessages')"
            />
            <q-input
              v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'grokx'"
              class="row col"
              rounded
              outlined
              type="number"
              v-model="integracao.temperature"
              :label="$t('integracao.campoTemperature')"
            />
          </div>
        <div class="col-12 q-my-sm">
        <q-input
          v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'openaiassistant' | integracao.type === 'grokx'"
          class="row col"
          rounded
          outlined
          v-model="integracao.voiceKey"
          :label="$t('integracao.campoVoiceKey')"
        />
        </div>
        <div class="col-12 q-my-sm">
          <q-select
            v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'openaiassistant' | integracao.type === 'grokx'"
            rounded
            outlined
            v-model="integracao.voice"
            :options="AudiosIA"
            :label="$t('integracao.campoFormatoResposta')"
            emit-value
            map-options
            filled />
        </div>
        <div class="col-12 q-my-sm">
          <q-select
            v-if="integracao.type === 'openai' | integracao.type === 'groq' | integracao.type === 'deepseek' | integracao.type === 'openaiassistant' | integracao.type === 'grokx'"
            class="row col"
            rounded
            outlined
            v-model="integracao.voiceRegion"
            :options="modelosElevenLabs"
            :label="$t('integracao.campoVoiceRegion')"
            emit-value
            map-options
            filled
          />
        </div>
      </q-card-section>
      <q-card-actions
        align="right"
        class="q-mt-md"
      >
        <q-btn
          :label="$t('general.cancelar')"
          color="negative"
          v-close-popup
          class="q-mr-md btn-rounded-50"
        />
        <q-btn
          :label="$t('general.salvar')"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          @click="handleIntegracao"
          icon="eva-save-outline"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>

</template>

<script>
import { CriarIntegracao, AlterarIntegracao } from 'src/service/integracoes'
import { ListarFilas } from 'src/service/filas'
import { required } from 'vuelidate/lib/validators'
import { listarModelosElevenLabs, listarVozesElevenLabs } from 'src/service/elevenLabs'

export default {
  name: 'ModalIntegracao',
  props: {
    modalIntegracao: {
      type: Boolean,
      default: false
    },
    integracaoEdicao: {
      type: Object,
      default: () => {
        return { id: null }
      }
    }
  },
  data () {
    return {
      listaFila: [],
      modelosElevenLabs: [],
      integracaoTypes: [
        { label: this.$t('integracao.typeN8n'), value: 'n8n' },
        { label: this.$t('integracao.typeTypebot'), value: 'typebot' },
        { label: this.$t('integracao.typeOpenAiAssistant'), value: 'openaiassistant' },
        { label: this.$t('integracao.typeOpenAi'), value: 'openai' },
        { label: this.$t('integracao.typeGroq'), value: 'groq' },
        { label: this.$t('integracao.typeGrokx'), value: 'grokx' },
        { label: this.$t('integracao.typeDeepseek'), value: 'deepseek' },
        { label: this.$t('integracao.typeAsaas'), value: '2viaasaas' }
      ],
      modelsXia: [
        { label: 'Grok 2', value: 'grok-2-latest' }
      ],
      modelsOpenai: [
        { label: 'gpt-4o', value: 'gpt-4o' },
        { label: 'gpt-4o-mini', value: 'gpt-4o-mini' },
        { label: 'gpt-3.5-turbo', value: 'gpt-3.5-turbo' }
      ],
      modelsGroq: [
        { label: 'Meta Llama 3 8B', value: 'llama3-8b-8192' },
        { label: 'Gemma 2 9B', value: 'gemma2-9b-it' },
        { label: 'llama-4-scout-17b-16e-instruct', value: 'meta-llama/llama-4-scout-17b-16e-instruct' },
        { label: 'Meta Llama 3 70B', value: 'llama3-70b-8192' },
        { label: 'Mixtral 8x7B', value: 'mixtral-8x7b-32768' }
      ],
      modelsDeepSeek: [
        { label: 'deepseek-chat', value: 'deepseek-chat' },
        { label: 'deepseek-reasoner', value: 'deepseek-reasoner' }
      ],
      AudiosIA: [
        { label: this.$t('integracao.texto'), value: 'texto' }
      ],
      integracao: {
        id: null,
        type: null,
        name: null,
        projectName: null,
        jsonContent: null,
        urlN8N: null,
        language: null,
        typebotSlug: null,
        typebotExpires: null,
        typebotKeywordFinish: null,
        typebotUnknownMessage: null,
        typebotDelayMessage: 1000,
        typebotKeywordRestart: null,
        typebotRestartMessage: null,
        n8nApiKey: null,
        aiModel: null,
        apiKey: null,
        maxTokens: 100,
        temperature: 0.2,
        maxMessages: 10,
        voice: 'texto',
        voiceKey: null,
        voiceRegion: null,
        queueId: null
      }
    }
  },
  validations: {
    integracao: {
      name: { required },
      type: { required }
    }
  },
  watch: {
    'integracao.voiceKey': function(newVal) {
      if (newVal && this.integracao.type &&
        ['openai', 'groq', 'deepseek', 'openaiassistant', 'grokx'].includes(this.integracao.type)) {
        this.buscaVozesElevenLabs()
        this.buscarModelosElevenLabs()
      }
    }
  },
  methods: {
    async buscaFilas() {
      const { data } = await ListarFilas()
      this.listaFila = data.filter(f => f.isActive)
    },
    resetarIntegracao () {
      this.integracao = {
        id: null,
        type: null,
        name: null,
        projectName: null,
        jsonContent: null,
        urlN8N: null,
        language: null,
        typebotSlug: null,
        typebotExpires: null,
        typebotKeywordFinish: null,
        typebotUnknownMessage: null,
        typebotDelayMessage: 1000,
        typebotKeywordRestart: null,
        typebotRestartMessage: null,
        n8nApiKey: null,
        aiModel: null,
        apiKey: null,
        maxTokens: 100,
        temperature: 0.2,
        maxMessages: 10,
        voice: 'texto',
        voiceKey: null,
        voiceRegion: null,
        queueId: null
      }
    },
    fecharModal () {
      this.resetarIntegracao()
      this.$emit('update:integracaoEdicao', { id: null })
      this.$emit('update:modalIntegracao', false)
    },
    async buscaVozesElevenLabs() {
      try {
        if (!this.integracao.voiceKey) return

        const { data } = await listarVozesElevenLabs(this.integracao.voiceKey)

        if (data && data.voices) {
          const vozesOptions = data.voices.map(voice => ({
            label: voice.name,
            value: voice.voice_id,
            description: voice.labels?.description || ''
          }))

          this.AudiosIA = [
            { label: this.$t('integracao.texto'), value: 'texto' },
            ...vozesOptions
          ]

          this.$q.notify({
            type: 'positive',
            message: this.$t('integracao.vocesCarregadas'),
            position: 'top'
          })
        }
      } catch (error) {
        console.error('Erro ao buscar vozes da Eleven Labs:', error)
        this.$q.notify({
          type: 'negative',
          message: this.$t('integracao.erroCarregarVozes'),
          position: 'top'
        })
      }
    },
    async buscarModelosElevenLabs() {
      try {
        if (!this.integracao.voiceKey) return

        const { data } = await listarModelosElevenLabs(this.integracao.voiceKey)

        if (data && data.length > 0) {
          this.modelosElevenLabs = data.map(model => ({
            label: model.name,
            value: model.model_id
          }))

          // Defina um valor padrão (Eleven Flash v2.5) se não houver valor selecionado
          if (!this.integracao.voiceRegion) {
            const flashModel = data.find(model => model.model_id === 'eleven_multilingual_v2')
            if (flashModel) {
              this.integracao.voiceRegion = flashModel.model_id
            }
          }
        }
      } catch (error) {
        console.error('Erro ao buscar modelos da Eleven Labs:', error)
      }
    },
    abrirModal () {
      if (this.integracaoEdicao.id) {
        this.integracao = { ...this.integracaoEdicao }
      } else {
        this.resetarIntegracao()
      }
    },
    async handleIntegracao () {
      if (this.$v.integracao.$invalid) {
        this.$v.$touch()
        this.$q.notify(this.$t('integracao.erroFormulario'))
        return
      }
      try {
        this.loading = true
        if (this.integracao.id) {
          const { data } = await AlterarIntegracao(this.integracao)
          this.$emit('modal-integracao:editada', data)
          this.$q.notify({
            type: 'info',
            progress: true,
            position: 'top',
            textColor: 'black',
            message: this.$t('integracao.integracaoEditada'),
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else {
          const { data } = await CriarIntegracao(this.integracao)
          this.$emit('modal-integracao:criada', data)
          this.$q.notify({
            type: 'positive',
            progress: true,
            position: 'top',
            message: this.$t('integracao.integracaoCriada'),
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        }
        this.loading = false
        this.fecharModal()
      } catch (error) {
        console.error('Erro capturado: ', error)
        if (error.data && error.data.error === 'name must be at least 2 characters') {
          this.$q.notify({
            type: 'negative',
            progress: true,
            position: 'top',
            message: this.$t('integracao.erroNomeCurto'),
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else if (error.data && error.data.error === 'This integration name is already used.') {
          this.$q.notify({
            type: 'negative',
            progress: true,
            position: 'top',
            message: this.$t('integracao.erroNomeExistente'),
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else {
          this.$notificarErro(this.$t('integracao.erroCriar'), error)
        }
      }
    }
  },
  mounted() {
    this.buscaFilas()
  }
}
</script>

<style lang="scss" scoped>
</style>
