import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'timestamp' (INTEGER) a la tabla 'Messages'
    return Promise.all([
      queryInterface.addColumn('Messages', 'timestamp', {
        type: DataTypes.INTEGER,
        allowNull: true, // Permite nulos
        defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'timestamp' de la tabla 'Messages'
    return Promise.all([
      queryInterface.removeColumn('Messages', 'timestamp')
    ]);
  }
};