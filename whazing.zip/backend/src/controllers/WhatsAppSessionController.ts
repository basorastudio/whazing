import { Request, Response } from 'express';
import ShowWhatsAppService from '../services/WhatsappService/ShowWhatsAppService';
import { StartWhatsAppSession } from '../services/WbotServices/StartWhatsAppSession';
import UpdateWhatsAppService from '../services/WhatsappService/UpdateWhatsAppService';
import { setValue } from '../libs/redisClient'; // Asumiendo exportación nombrada
import { logger } from '../utils/logger'; // Asumiendo exportación nombrada
import { getTbot, removeTbot } from '../libs/tbot'; // Para Telegram
import { getInstaBot, removeInstaBot } from '../libs/InstaBot'; // Para Instagram
import AppError from '../errors/AppError';
import { getIO } from '../libs/socket';
import { getWbot, removeWbot } from '../libs/wbot'; // Para WhatsApp (Baileys)
import DeleteBaileysKeysService from '../services/BaileysServices/DeleteBaileysKeysService';
import BaileysSessions from '../models/Baileys'; // Ajustar ruta

// Extiende la interfaz Request
interface WhatsAppSessionRequest extends Request {
    user?: {
        id: string | number;
        tenantId: string | number;
        profile: string;
    };
    params: {
        whatsappId?: string;
    };
}

// Iniciar/Restaurar sesión
const store = async (req: WhatsAppSessionRequest, res: Response): Promise<Response> => {
    const { whatsappId } = req.params;
    const { tenantId } = req.user!;

    if (!whatsappId) {
        throw new AppError("whatsappId is required", 400); // "whatsappId es requerido"
    }

    const params = {
        id: whatsappId,
        tenantId: Number(tenantId),
        isInternal: true // Indica que la búsqueda es interna, podría afectar qué se retorna
    };

    const whatsapp = await ShowWhatsAppService(params);
    StartWhatsAppSession(whatsapp); // Inicia o restaura la sesión

    return res.status(200).json({ message: 'Starting session.' }); // "Iniciando sesión."
};

// Actualizar QR Code (forzar nuevo QR)
const update = async (req: WhatsAppSessionRequest, res: Response): Promise<Response> => {
    const { whatsappId } = req.params;
    const { tenantId } = req.user!;

     if (!whatsappId) {
        throw new AppError("whatsappId is required", 400); // "whatsappId es requerido"
    }

    // Actualiza la sesión en la BD para borrar el QR anterior
    const updateParams = {
        whatsappId: whatsappId,
        whatsappData: { session: '' }, // Borra la sesión existente para forzar nuevo QR
        tenantId: Number(tenantId)
    };
    const { whatsapp } = await UpdateWhatsAppService(updateParams);

    // Inicia el proceso de conexión que generará un nuevo QR
    StartWhatsAppSession(whatsapp);

    return res.status(200).json({ message: 'Starting session.' }); // "Iniciando sesión."
};

// Desconectar sesión (Logout)
const remove = async (req: WhatsAppSessionRequest, res: Response): Promise<Response> => {
    const { whatsappId } = req.params;
    const { tenantId } = req.user!;

    if (!whatsappId) {
        throw new AppError("whatsappId is required", 400); // "whatsappId es requerido"
    }

    const numericWhatsappId = Number(whatsappId);
    const numericTenantId = Number(tenantId);

    const whatsapp = await ShowWhatsAppService({ id: whatsappId, tenantId: numericTenantId });
    const io = getIO();

    try {
        // Desconectar según el tipo de canal
        if (whatsapp.type === 'whatsapp') {
            const wbot = getWbot(numericWhatsappId);
            await setValue(`${numericWhatsappId}-retryQrCode`, 0); // Resetea contador de reintentos de QR en Redis
            await wbot.logout();
            wbot.ws.close(); // Cierra la conexión WebSocket subyacente
            removeWbot(numericWhatsappId); // Elimina la instancia de wbot de la memoria
            await DeleteBaileysKeysService(numericWhatsappId); // Elimina claves de sesión de Baileys
            await BaileysSessions.destroy({ where: { whatsappId: numericWhatsappId } }); // Elimina registro de sesión de Baileys
        } else if (whatsapp.type === 'telegram') {
            const tbot = getTbot(numericWhatsappId);
            await tbot.telegram.logOut().catch(err => logger.error(`Erro ao fazer logout no Telegram ${whatsappId}`, err)); // "Error al hacer logout en Telegram..."
            removeTbot(numericWhatsappId); // Elimina instancia de tbot
        } else if (whatsapp.type === 'instagram') {
            const instaBot = getInstaBot(numericWhatsappId);
            await instaBot.destroy(); // Desconecta Instagram
            removeInstaBot(whatsapp); // Elimina instancia de instaBot
        }

        // Actualizar estado en la base de datos
        await whatsapp.update({
            status: "DISCONNECTED",
            session: "",
            qrcode: null,
            retries: 0
        });

    } catch (err) {
        logger.error(err); // Loguea el error

        // Intenta actualizar el estado incluso si la desconexión falló
        await whatsapp.update({
            status: "DISCONNECTED",
            session: "",
            qrcode: null,
            retries: 0
        });

        // Emite evento de error por socket
        io.emit(`${numericTenantId}:whatsappSession`, { // Evento específico del tenant
            action: 'update',
            session: whatsapp // Envía el estado actualizado (desconectado)
        });

        throw new AppError(`Erro ao fazer logout da conexão ${whatsapp.name}.`, 500); // "Error al hacer logout de la conexión..."
    }

    return res.status(200).json({ message: 'Session disconnected.' }); // "Sesión desconectada."
};

// Exporta los controladores agrupados
export default { store, remove, update };