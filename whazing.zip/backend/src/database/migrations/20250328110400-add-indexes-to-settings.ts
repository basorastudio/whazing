import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Settings"; // Assuming 'Settings' table based on file 20241104000001
    // Add index on [tenantId]
    await queryInterface.addIndex(tableName, ["tenantId"], {
      name: "idx_settings_tenantid" // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Settings";
    // Remove the index
    await queryInterface.removeIndex(tableName, "idx_settings_tenantid");
  }
};

export = migration;
