import { getWbot } from "../libs/wbot";
import SendMessagesSystemWbotBaileys from "../services/WbotServices/SendMessagesSystemWbotBaileys"; // Adjust import as needed
import { logger } from "../utils/logger";
import { proto } from "@whiskeysockets/baileys"; // Assuming Baileys types

// Define interfaces for the data structures
interface MessageToSend {
  // Define the structure of the message object based on SendMessagesSystemWbotBaileys
  number: string;
  message?: string;
  options?: any; // Specify options type if known
  media?: {
    // Example media structure
    mimetype: string;
    url?: string;
    path?: string;
    filename?: string;
    caption?: string;
  };
}

interface SendData {
  whatsappId: number;
  tenantId: number | string;
  messages: MessageToSend[];
}

interface Job {
  data: SendData;
}

interface HandleOptions {
  removeOnComplete: boolean;
  removeOnFail: boolean;
  priority: number;
  attempts: number;
  delay: number; // Added delay based on original options
}

const handleOptions: HandleOptions = {
  removeOnComplete: true,
  removeOnFail: false, // Original: ![]
  priority: 1,
  attempts: 5,
  delay: 10000 // 0x2710 ms
};

export const sendMessageBaileys = {
  key: "SendMessageBaileys",
  options: handleOptions,
  async handle({ data }: Job): Promise<void> {
    const logPrefix = "SendMessageBaileys";
    try {
      const { whatsappId, tenantId, messages } = data;

      if (!messages || messages.length === 0) {
        logger.warn(
          `${logPrefix}: No messages provided for WhatsApp ID ${whatsappId}, Tenant ${tenantId}. Skipping job.`
        );
        return;
      }

      const wbot = getWbot(whatsappId);
      // Assuming SendMessagesSystemWbotBaileys handles sending the array of messages
      await SendMessagesSystemWbotBaileys(wbot, tenantId, messages);
      logger.info(
        `${logPrefix}: Job completed for WhatsApp ID ${whatsappId}, Tenant ${tenantId}. Messages sent: ${messages.length}`
      );
    } catch (error: any) {
      logger.error({
        message: `${logPrefix}: Error job`, // Original: Error in send Baileys job
        whatsappId: data?.whatsappId,
        tenantId: data?.tenantId,
        error: error?.message,
        originalError: error
      });
      throw error; // Re-throw error for queue handler
    }
  }
};
