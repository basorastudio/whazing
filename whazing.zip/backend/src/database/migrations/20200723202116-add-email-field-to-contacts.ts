import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    return queryInterface.addColumn("Contacts", "email", {
      type: DataTypes.STRING,
      allowNull: true, // Permitir nulos, puede que no todos los contactos tengan email
      defaultValue: "" // O null si se prefiere
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    return queryInterface.removeColumn("Contacts", "email");
  }
};
