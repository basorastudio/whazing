<template>
  <div v-if="userProfile === 'admin'">
    <q-card
      class="q-ma-lg container-border container-rounded-10"
      square
    >
      <div class="q-pa-sm q-ma-sm">
        <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
          {{ $t('horariodeatendimento.titulo') }}
          <q-icon name="help">
          <q-tooltip content-class="bg-light-blue-1 q-pa-sm shadow-4">
            <span class="text-weight-medium">{{ $t('horariodeatendimento.tipos_horario') }} </span>
            <span class="row col">
              {{ $t('horariodeatendimento.aberto_desc') }}
            </span>
            <span class="row col">
              {{ $t('horariodeatendimento.fechado_desc') }}
            </span>
            <span class="row col">
              {{ $t('horariodeatendimento.horario_desc') }}
            </span>
            <span class="row col">
              {{ $t('horariodeatendimento.importante_msg') }}
            </span>
          </q-tooltip>
        </q-icon>
        </h2>

        <q-btn
          class="generate-button btn-rounded-50"
          :class="{'generate-button-dark' : $q.dark.isActive}"
          :label="$t('general.salvar')"
          icon="eva-save-outline"
          @click="salvarHorariosAtendimento"
        />
      </div>
      <q-separator />
      <q-card-section>
        <div class="row q-col-gutter-sm">
          <div
            class="col-xs-12 col-sm-4 q-mt-sm"
            v-for="dia in businessHours"
            :key="dia.value"
          >
            <q-card
              square
              bordered
              flat
              class="container-rounded-10"
            >
              <div class="font-family-main text-bold bg-grey-2 q-pa-xs q-pl-sm" :class="$q.dark.isActive ? ('text-black') : ''">
                {{ dia.label }}
              </div>
              <q-separator />
              <q-card-section class="q-pt-none">
                <q-option-group
                  inline
                  class="row container-border container-rounded-10 q-mt-sm q-pr-md justify-between q-mb-md"
                  v-model="dia.type"
                  :options="optType"
                  color="primary"
                />

                <div class="row items-baseline q-gutter-sm">
                  <q-input
                    :disable="dia.type !== 'H'"
                    dense
                    outlined
                    class="col-grow"
                    error-message="Obrigatório"
                    hide-underline
                    type="time"
                    v-model="dia.hr1"
                  />
                  <h6>{{ $t('horariodeatendimento.as') }}</h6>
                  <q-input
                    :disable="dia.type !== 'H'"
                    dense
                    outlined
                    class="col-grow"
                    error-message="Obrigatório"
                    hide-underline
                    type="time"
                    v-model="dia.hr2"
                  />
                </div>
                <div class="row items-baseline q-gutter-sm">
                  <q-input
                    :disable="dia.type !== 'H'"
                    dense
                    outlined
                    class="col-grow"
                    error-message="Obrigatório"
                    hide-underline
                    type="time"
                    v-model="dia.hr3"
                  />
                  <h6>{{ $t('horariodeatendimento.as') }}</h6>
                  <q-input
                    :disable="dia.type !== 'H'"
                    dense
                    outlined
                    class="col-grow"
                    error-message="Obrigatório"
                    hide-underline
                    type="time"
                    v-model="dia.hr4"
                  />
                </div>
              </q-card-section>
            </q-card>
          </div>
        </div>
      </q-card-section>
    </q-card>
    <q-card
      square
      bordered
      class="q-ma-lg container-rounded-10 full-full-height"
    >
      <div class="q-pa-sm q-ma-sm">
        <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
          {{ $t('horariodeatendimento.mensagem_ausencia') }}
        </h2>

        <q-btn
          class="generate-button btn-rounded-50"
          :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-save-outline"
          :label="$t('general.salvar')"
          @click="salvarMensagemAusencia"
        />
      </div>
      <q-card-section class="q-pt-none">
        <div class="row items-center">
          <div class="col-xs-3 col-sm-2 col-md-1">
            <q-btn
              round
              flat
              class="q-ml-sm"
            >
              <q-icon
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                size="2em"
                name="mdi-emoticon-happy-outline"
              />
              <q-tooltip>
                {{ $t('horariodeatendimento.emoji') }}
              </q-tooltip>
              <q-menu
                anchor="top right"
                self="bottom middle"
                :offset="[5, 40]"
              >
                <VEmojiPicker
                  style="width: 40vw"
                  :showSearch="true"
                  :emojisByRow="20"
                  labelSearch="Localizar..."
                  lang="pt-BR"
                  @select="onInsertSelectEmoji"
                />
              </q-menu>
            </q-btn>
            <q-btn round
            flat
            dense>
            <q-icon size="2em"
                    class="color-light1"
                    :class="$q.dark.isActive ? ('color-dark1') : ''"
              name="mdi-variable" />
            <q-tooltip>
              {{ $t('horariodeatendimento.variaveis') }}
            </q-tooltip>
            <q-menu touch-position>
              <q-list dense
                style="min-width: 100px">
                <q-item v-for="variavel in variaveis"
                  :key="variavel.label"
                  clickable
                  @click="onInsertSelectVariable(variavel.value)"
                  v-close-popup>
                  <q-item-section>{{ variavel.label }}</q-item-section>
                </q-item>
              </q-list>
            </q-menu>
          </q-btn>
          </div>
          <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm">
            <textarea
              ref="inputEnvioMensagem"
              style="min-height: 9vh; max-height: 9vh;"
              class="q-pa-sm bg-white full-width"
              :placeholder="$t('horariodeatendimento.digite_mensagem')"
              autogrow
              dense
              outlined
              @input="(v) => messageBusinessHours = v.target.value"
              :value="messageBusinessHours"
            />
          </div>
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
import { VEmojiPicker } from 'v-emoji-picker'
import { MostrarHorariosAtendiemento, AtualizarHorariosAtendiemento, AtualizarMensagemHorariosAtendiemento } from 'src/service/empresas'
import { ListarCores } from 'src/service/configuracoesgeneral'
export default {
  name: 'HorarioAtendimento',
  components: { VEmojiPicker },
  data () {
    return {
      userProfile: 'user',
      optType: [
        { value: 'O', label: this.$t('horariodeatendimento.aberto') },
        { value: 'C', label: this.$t('horariodeatendimento.fechado') },
        { value: 'H', label: this.$t('horariodeatendimento.horario') }
      ],
      variaveis: [
        { label: this.$t('variaveis.nomeCompleto'), value: '{{name}}' },
        { label: this.$t('variaveis.nome'), value: '{{firstName}}' },
        { label: this.$t('variaveis.saudacaoPT'), value: '{{greeting}}' },
        { label: this.$t('variaveis.saudacaoEN'), value: '{{greetingEn}}' },
        { label: this.$t('variaveis.saudacaoES'), value: '{{greetingEs}}' },
        { label: this.$t('variaveis.protocol'), value: '{{protocol}}' },
        { label: this.$t('variaveis.ticket_id'), value: '{{ticket_id}}' },
        { label: this.$t('variaveis.hora'), value: '{{hour}}' },
        { label: this.$t('variaveis.data'), value: '{{date}}' }
      ],
      businessHours: [
        { day: 0, label: this.$t('horariodeatendimento.domingo'), type: 'O', hr1: '08:00', hr2: '12:00', hr3: '14:00', hr4: '18:00' },
        { day: 1, label: this.$t('horariodeatendimento.segunda_feira'), type: 'O', hr1: '08:00', hr2: '12:00', hr3: '14:00', hr4: '18:00' },
        { day: 2, label: this.$t('horariodeatendimento.terca_feira'), type: 'O', hr1: '08:00', hr2: '12:00', hr3: '14:00', hr4: '18:00' },
        { day: 3, label: this.$t('horariodeatendimento.quarta_feira'), type: 'O', hr1: '08:00', hr2: '12:00', hr3: '14:00', hr4: '18:00' },
        { day: 4, label: this.$t('horariodeatendimento.quinta_feira'), type: 'O', hr1: '08:00', hr2: '12:00', hr3: '14:00', hr4: '18:00' },
        { day: 5, label: this.$t('horariodeatendimento.sexta_feira'), type: 'O', hr1: '08:00', hr2: '12:00', hr3: '14:00', hr4: '18:00' },
        { day: 6, label: this.$t('horariodeatendimento.sabado'), type: 'O', hr1: '08:00', hr2: '12:00', hr3: '14:00', hr4: '18:00' }
      ],
      messageBusinessHours: null
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    onInsertSelectVariable (variable) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!variable) {
        return
      }
      // insert:
      self.txtContent = this.messageBusinessHours
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.messageBusinessHours = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!emoji.data) {
        return
      }
      // insert:
      self.txtContent = this.messageBusinessHours
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.messageBusinessHours = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    async listarMensagemHorariosAtendimento() {
      try {
        const { data } = await MostrarHorariosAtendiemento()

        this.businessHours = data.businessHours.map(day => ({
          ...day,
          label: this.getDayTranslation(day.day)
        }))

        this.messageBusinessHours = data.messageBusinessHours
      } catch (error) {
        console.error('Error loading business hours:', error)
      }
    },
    getDayTranslation(day) {
      const translations = {
        0: this.$t('horariodeatendimento.domingo'),
        1: this.$t('horariodeatendimento.segunda_feira'),
        2: this.$t('horariodeatendimento.terca_feira'),
        3: this.$t('horariodeatendimento.quarta_feira'),
        4: this.$t('horariodeatendimento.quinta_feira'),
        5: this.$t('horariodeatendimento.sexta_feira'),
        6: this.$t('horariodeatendimento.sabado')
      }
      return translations[day]
    },
    async salvarHorariosAtendimento() {
      try {
        const { data } = await AtualizarHorariosAtendiemento(this.businessHours)

        this.businessHours = data.businessHours.map(day => ({
          ...day,
          label: this.getDayTranslation(day.day)
        }))

        this.$q.notify({
          color: 'positive',
          position: 'top',
          message: this.$t('horariodeatendimento.horario_atualizado')
        })
      } catch (e) {
        console.log('Horário de funcionamento erro :' + e)
      }
    },
    async salvarMensagemAusencia () {
      try {
        const { data } = await AtualizarMensagemHorariosAtendiemento({
          messageBusinessHours: this.messageBusinessHours
        })
        this.messageBusinessHours = data.messageBusinessHours
        this.$q.notify({
          color: 'positive',
          position: 'top',
          message: this.$t('horariodeatendimento.mensagem_atualizada')
        })
      } catch (e) {
        console.log('Mensagem de ausência erro :' + e)
      }
    }
  },
  mounted () {
    this.loadColors()
    this.listarMensagemHorariosAtendimento()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="scss" scoped>
</style>
