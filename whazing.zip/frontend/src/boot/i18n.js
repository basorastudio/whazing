import Vue from 'vue'
import VueI18n from 'vue-i18n'

Vue.use(VueI18n)

const messages = {
  pt: require('src/locales/pt.json'),
  en: require('src/locales/en.json'),
  es: require('src/locales/es.json')
}

const getBrowserLanguage = () => {
  const browserLang = navigator.language.split('-')[0]

  if (messages[browserLang]) {
    return browserLang
  }

  return 'pt'
}

const i18n = new VueI18n({
  locale: localStorage.getItem('language') || getBrowserLanguage(),
  fallbackLocale: 'pt',
  messages
})

export default ({ app }) => {
  app.i18n = i18n
}

export { i18n }
