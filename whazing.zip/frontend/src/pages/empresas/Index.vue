<template>
  <div class="q-pa-md" style="max-width: 100%">
    <q-card>
      <q-tabs
        v-model="tab"
        dense
        align="justify"
      >
        <q-tab name="Dashboard" label="Dashboard" />
        <q-tab name="empresas" label="Empresas" />
        <q-tab name="planos" label="Planos" />
        <q-tab name="ayuda" label="Ayuda" />
        <q-tab name="config" label="Configuraciones" />
        <q-tab name="whitelabel" label="White Label" />
      </q-tabs>
      <q-separator />

      <q-tab-panels v-model="tab" animated>
        <q-tab-panel name="Dashboard" class="q-pa-none">
          <dashboard/>
        </q-tab-panel>

        <q-tab-panel name="empresas">
          <empresa/>
        </q-tab-panel>

        <q-tab-panel name="planos">
          <planos/>
        </q-tab-panel>

        <q-tab-panel name="ayuda">
          <ayuda/>
        </q-tab-panel>

        <q-tab-panel name="config">
          <config/>
        </q-tab-panel>

        <q-tab-panel name="whitelabel">
          <whitelabel/>
        </q-tab-panel>

      </q-tab-panels>
    </q-card>
  </div>
</template>

<script>
import empresa from './empresa.vue'
import dashboard from './dashboard/index.vue'
import planos from './planos/Index.vue'
import ayuda from './ajuda/Index.vue' // Traducido el nombre de la importación
import config from './config/Index.vue'
import whitelabel from './whitelabel/Index.vue'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  data () {
    return {
      tab: 'Dashboard', // Defina el nombre de la pestaña que desea abrir por defecto
      innerTab: 'innerMails',
      splitterModel: 20
    }
  },
  components: {
    empresa,
    dashboard,
    planos,
    ayuda, // Traducido el nombre del componente
    config,
    whitelabel
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores devueltos por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    }
  },
  mounted () {
    this.loadColors()
  }
}
</script>
