// --- START OF FILE 20230711161553-alter_table_campaign_add_delay.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Campaigns';
        const columnName = 'delay';
        const attributes = {
            type: DataTypes.INTEGER,
            allowNull: false, // Changed ![] to false
            defaultValue: 20 // Original was 0x14 -> 20
        };
        await queryInterface.addColumn(tableName, columnName, attributes);
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Campaigns';
        const columnName = 'delay';
        await queryInterface.removeColumn(tableName, columnName);
    }
};

export default migration;
// --- END OF FILE 20230711161553-alter_table_campaign_add_delay.ts ---