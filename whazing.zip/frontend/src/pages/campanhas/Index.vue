<template>
  <div v-if="!canAccessPage">
    <q-banner dense inline-actions class="bg-red text-white">
      <template v-slot:avatar>
        <q-icon name="warning" />
      </template>
      Las campañas no forman parte de tu plan. Para contratarlas, contacta con soporte.
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               v-if="whatsappNumber"
               icon="mdi-whatsapp"
               label="Llamar a Soporte"
               @click="abrirWhatsApp"
        />
      </template>
    </q-banner>
  </div>
  <div v-else-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-table
      flat
      bordered
      square
      hide-bottom
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      :data="campanhas"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
    >
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
          Campañas
        </h2>
        <div>
        <q-btn
          class="color-light1"
          :class="$q.dark.isActive ? ('color-dark1') : ''"
          icon="refresh"
          outline
          @click="listarCampanhas"
          >
        <q-tooltip>
          Actualizar Listado
        </q-tooltip>
        </q-btn>
        <q-btn
          class="generate-button btn-rounded-50"
          :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline"
          label="Añadir"
          @click="campanhaEdicao = {}; modalCampanha = true"
        />
        </div>
        </div>

      </template>
      <template v-slot:body-cell-color="props">
        <q-td class="text-center">
          <div
            class="q-pa-sm rounded-borders"
            :style="`background: ${props.row.color}`"
          >
            {{ props.row.color }}
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon
            size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
        flat
        round
        icon="mdi-account-details-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="contatosCampanha(props.row)"
      >
        <q-tooltip>
          Lista de Contactos de la Campaña
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        v-if="['pending', 'canceled'].includes(props.row.status)"
        icon="mdi-calendar-clock"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="iniciarCampanha(props.row)"
      >
        <q-tooltip>
          Programar Envío
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        v-if="['scheduled', 'processing'].includes(props.row.status)"
        icon="mdi-close-box-multiple"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="cancelarCampanha(props.row)"
      >
        <q-tooltip>
          Cancelar Campaña
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        icon="eva-edit-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="editarCampanha(props.row)"
      >
        <q-tooltip>
          Editar Campaña
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        icon="eva-trash-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="deletarCampanha(props.row)"
      >
        <q-tooltip>
          Eliminar Campaña
        </q-tooltip>
      </q-btn>
    </q-td>
      </template>
    </q-table>
    <ModalCampanha
      v-if="modalCampanha"
      :modalCampanha.sync="modalCampanha"
      :campanhaEdicao.sync="campanhaEdicao"
      @modal-campanha:criada="campanhaCriada"
      @modal-campanha:editada="campanhaEditada"
    />

    <q-dialog v-model="showWarningModal" persistent>
      <q-card>
        <q-card-section>
          <div class="text-h6">⚠️ Aviso Importante</div>
          <div class="text-body1 q-mt-md">
            <!-- Risco de Banimento -->
            <q-banner class="bg-orange-8 text-white q-mb-md" dense rounded>
              <q-icon name="warning" size="md" class="q-mr-sm" />
              <div class="text-subtitle1 text-bold">¡WhatsApp puede bloquear su número!</div>
              <div class="text-body2">
                El envío de mensajes masivos es monitoreado y puede llevar a un bloqueo permanente.
              </div>
            </q-banner>

            <!-- Política de Spam -->
            <q-banner class="bg-red-8 text-white q-mb-md" dense rounded>
              <q-icon name="error" size="md" class="q-mr-sm" />
              <div class="text-subtitle1 text-bold">🚨 ¡Tolerancia Cero para Spam!</div>
              <div class="text-body2">
                WhatsApp prohíbe envíos automatizados. El incumplimiento puede resultar en bloqueo inmediato.
              </div>
            </q-banner>

            <!-- Alerta de Denúncias -->
            <q-banner class="bg-red-10 text-white" dense rounded>
              <q-icon name="priority_high" size="md" class="q-mr-sm" />
              <div class="text-subtitle1 text-bold">⚠️ ¡Alto riesgo de bloqueo!</div>
              <div class="text-body2">
                Si <strong>2% de los contactos</strong> denuncian su mensaje, su número podría ser bloqueado.
              </div>
            </q-banner>
          </div>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="Cancelar" color="negative" @click="cancelNavigation" />
          <q-btn flat label="Entendido" color="positive" @click="confirmNavigation" />
        </q-card-actions>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
import { CancelarCampanha, DeletarCampanha, IniciarCampanha, ListarCampanhas } from 'src/service/campanhas'
import { MostrarPlano } from 'src/service/empresas'
import ModalCampanha from './ModalCampanha'
import { format, parseISO, startOfDay } from 'date-fns'
import { ListarConfiguracaoPublica, ListarCores } from 'src/service/configuracoesgeneral'

export default {
  name: 'Campanhas',
  components: {
    ModalCampanha
  },
  data () {
    return {
      userProfile: 'user',
      showWarningModal: false,
      canAccessPage: false,
      campanhaEdicao: {},
      modalCampanha: false,
      whatsappNumber: null,
      campanhas: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'name', label: 'Campaña', field: 'name', align: 'left' },
        { name: 'start', label: 'Inicio', field: 'start', align: 'center', format: (v) => format(parseISO(v), 'dd/MM/yyyy HH:mm') },
        {
          name: 'status',
          label: 'Estado',
          field: 'status',
          align: 'center',
          format: (v) => v ? this.status[v] : ''
        },
        { name: 'contactsCount', label: 'Cant. Contactos', field: 'contactsCount', align: 'center' },
        { name: 'pendentesEnvio', label: 'Por Enviar', field: 'pendentesEnvio', align: 'center' },
        { name: 'pendentesEntrega', label: 'Por Entregar', field: 'pendentesEntrega', align: 'center' },
        { name: 'recebidas', label: 'Recibidos', field: 'recebidas', align: 'center' },
        { name: 'lidas', label: 'Leídos', field: 'lidas', align: 'center' },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ],
      status: {
        pending: 'Pendiente',
        scheduled: 'Programada',
        processing: 'Procesando',
        canceled: 'Cancelada',
        finished: 'Finalizada'
      }
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores retornados por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    cancelNavigation() {
      this.showWarningModal = false
      this.$router.push({ name: 'home-dashboard' }) // Use 'push' para navegar a la ruta correcta
    },
    confirmNavigation() {
      localStorage.setItem('showWarningModalCampanhas', false)
      this.showWarningModal = false
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Error al buscar configuraciones:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Hola%21+quiero+adquirir+campañas`
        window.open(url, '_blank') // Abre WhatsApp en una nueva pestaña
      }
    },
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.campaign !== false
      } catch (error) {
        console.error('Error al cargar el plan:', error)
      }
    },
    async listarCampanhas () {
      const { data } = await ListarCampanhas()
      this.campanhas = data
    },
    isValidDate (v) {
      return startOfDay(new Date(parseISO(v))).getTime() >= startOfDay(new Date()).getTime()
    },
    campanhaCriada (campanha) {
      this.listarCampanhas()
    },
    campanhaEditada (campanha) {
      this.listarCampanhas()
    },
    editarCampanha (campanha) {
      if (campanha.status !== 'pending' && campanha.status !== 'canceled') {
        this.$notificarErro('Solo se permite editar campañas que estén pendientes o canceladas.')
      }
      this.campanhaEdicao = {
        ...campanha,
        start: campanha.start, // format(parseISO(campanha.start), 'yyyy-MM-dd'),
        end: campanha.start // format(parseISO(campanha.start), 'yyyy-MM-dd')
      }
      this.modalCampanha = true
    },
    deletarCampanha (campanha) {
      this.$q.dialog({
        title: '¡Atención!',
        message: `¿Realmente desea eliminar la Campaña "${campanha.name}"?`,
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarCampanha(campanha)
          .then(res => {
            let newCampanhas = [...this.campanhas]
            newCampanhas = newCampanhas.filter(f => f.id !== campanha.id)
            this.campanhas = [...newCampanhas]
            this.$notificarSucesso(`¡Campaña ${campanha.name} eliminada!`)
          })
        this.loading = false
      })
    },
    contatosCampanha (campanha) {
      this.$router.push({
        name: 'contatos-campanha',
        params: {
          campanhaId: campanha.id,
          campanha
        }
      })
    },
    cancelarCampanha (campanha) {
      this.$q.dialog({
        title: '¡Atención!',
        message: `¿Realmente desea eliminar la Campaña "${campanha.name}"?`,
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        CancelarCampanha(campanha.id)
          .then(res => {
            this.$notificarSucesso('Campaña cancelada.')
            this.listarCampanhas()
          }).catch(err => {
            this.$notificarErro('No fue posible cancelar la campaña.', err)
          })
      })
    },
    iniciarCampanha (campanha) {
      if (!this.isValidDate(campanha.start)) {
        this.$notificarErro('No es posible programar una campaña con fecha anterior a la actual')
      }

      if (campanha.contactsCount == 0) {
        this.$notificarErro('Es necesario tener contactos vinculados para programar la campaña.')
      }

      if (campanha.status !== 'pending' && campanha.status !== 'canceled') {
        this.$notificarErro('Solo se permite programar campañas que estén pendientes o canceladas.')
      }

      IniciarCampanha(campanha.id).then(res => {
        this.$notificarSucesso('Campaña iniciada.')
        this.listarCampanhas()
      }).catch(err => {
        this.$notificarErro('No fue posible iniciar la campaña.', err)
      })
    }
  },
  mounted () {
    this.loadColors()
    this.fetchConfigurations()
    this.listarPlano()
    this.listarCampanhas()
    this.userProfile = localStorage.getItem('profile')
    const showModalCampanha = JSON.parse(localStorage.getItem('showWarningModalCampanhas'))
    this.showWarningModal = !(!showModalCampanha && showModalCampanha !== null)
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px
</style>
