import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'oldStepAutoReplyId' de la tabla 'Tickets'
    return Promise.all([
        queryInterface.removeColumn('Tickets', 'oldStepAutoReplyId')
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Vuelve a añadir la columna 'oldStepAutoReplyId'
    return queryInterface.addColumn('Tickets', 'oldStepAutoReplyId', {
        type: DataTypes.INTEGER,
        references: {
            model: 'StepsReply', // Referencia a la tabla StepsReply
            key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL', // Si se elimina el StepsReply, establece el valor a NULL
        allowNull: true,
        defaultValue: null
    });
  }
};