<template>
  <q-dialog persistent :value="modalGrupo" @hide="fecharModal" @show="abrirModal">
    <q-card class="q-pa-lg modal-container container-rounded-10">

      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ grupoEdicao.id ? $t('equipes.editar') : $t('equipes.cadastrar') }}
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="q-pa-lg container-border container-rounded-10">
        <div class="text-h6 font-family-main q-mb-sm">
          {{ $t('equipes.info') }}
        </div>
        <div class="row">
          <div class="col-12">
            <q-input rounded outlined v-model="grupo.group" :label="$t('equipes.nomeequipe')" />
          </div>
          <div class="col-6">
            <q-toggle v-model="grupo.isActive" :label="$t('equipes.ativo')" />
          </div>
        </div>
      </q-card-section>
      <q-card-actions align="right" class="q-mt-md">
        <q-btn :label="$t('general.cancelar')" class="q-mr-md btn-rounded-50" color="negative" v-close-popup />
        <q-btn :label="$t('general.salvar')" icon="eva-save-outline" class="q-ml-lg q-px-md btn-rounded-50" color="primary" @click="handleGrupo" />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { CriarGrupo, AlterarGrupo } from 'src/service/grupos'
export default {
  name: 'ModalGrupo',
  props: {
    modalGrupo: {
      type: Boolean,
      default: false
    },
    grupoEdicao: {
      type: Object,
      default: () => {
        return { id: null }
      }
    }
  },
  data() {
    return {
      grupo: {
        id: null,
        grupo: null,
        isActive: true
      }
    }
  },
  methods: {
    resetarGrupo() {
      this.grupo = {
        id: null,
        grupo: null,
        isActive: true
      }
    },
    fecharModal() {
      this.resetarGrupo()
      this.$emit('update:grupoEdicao', { id: null })
      this.$emit('update:modalGrupo', false)
    },
    abrirModal() {
      if (this.grupoEdicao.id) {
        this.grupo = { ...this.grupoEdicao }
      } else {
        this.resetarGrupo()
      }
    },
    async handleGrupo() {
      try {
        this.loading = true
        if (this.grupo.id) {
          const { data } = await AlterarGrupo(this.grupo)
          this.$emit('modal-grupo:editada', data)
          this.$q.notify({
            type: 'info',
            progress: true,
            position: 'top',
            textColor: 'black',
            message: this.$t('equipes.editada'),
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else {
          const { data } = await CriarGrupo(this.grupo)
          this.$emit('modal-grupo:criada', data)
          this.$q.notify({
            type: 'positive',
            progress: true,
            position: 'top',
            message: this.$t('equipes.criada'),
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        }
        this.loading = false
        this.fecharModal()
      } catch (error) {
        console.error(error)
        this.$notificarErro(this.$t('usuarios.erros'), error)
      }
    }
  }

}
</script>

<style lang="scss" scoped></style>
