<template>
  <q-dialog persistent :value="modalPlano" @hide="fecharModal" @show="abrirModal">
    <q-card class="container-rounded-10 modal-container q-pa-lg">

      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ planoEdicao.id ? 'Editar' : 'Criar' }} Plano
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <div class="container-border container-rounded-10">

      <q-card-section class="row flex-gap-1 q-col-gutter-sm">
        <div class="text-h6 font-family-main">
          Informações
        </div>
        <div class="flex-gap-1 full-width row q-col-gutter-sm">
          <div class="full-width">
            <c-input rounded outlined v-model="plano.name" label="Nome do Plano" />
          </div>
          <div class="full-width">
            <c-input rounded outlined v-model="plano.maxUsers" type="number" label="Máx. Usuários" />
          </div>
          <div class="full-width">
            <c-input rounded outlined v-model="plano.maxConnections" type="number" label="Máx. Conexões" />
          </div>
          <div class="full-width">
            <c-input rounded outlined v-model="plano.value" type="number" label="Valor" />
          </div>
          <div class="full-width">
        <q-checkbox
          v-model="plano.isPublic"
          label="Publico"
        />
            <q-checkbox
              v-model="plano.group"
              label="Grupos"
            />
            <q-checkbox
              v-model="plano.campaign"
              label="Campanhas"
            />
            <q-checkbox
              v-model="plano.integrations"
              label="Integrações"
            />
          </div>
        </div>
      </q-card-section>
      </div>
      <q-card-actions align="right">
        <q-btn
          label="Cancelar"
          class="q-px-md q-mr-sm btn-rounded-50"
          color="negative"
          v-close-popup
        />
        <q-btn
          label="Salvar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          icon="eva-save-outline"
          @click="handlePlano"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { AlterarPlano, CriarPlano } from '../../../service/plans'
export default {
  name: 'ModalPlano',
  props: {
    modalPlano: {
      type: Boolean,
      default: false
    },
    planoEdicao: {
      type: Object,
      default: () => {
        return { id: null }
      }
    }
  },
  data() {
    return {
      plano: {
        id: null,
        name: null,
        maxUsers: null,
        maxConnections: null,
        value: null,
        isPublic: true,
        group: true,
        campaign: true,
        integrations: true
      }
    }
  },
  methods: {
    resetarPlano() {
      this.plano = {
        id: null,
        name: null,
        maxUsers: null,
        maxConnections: null,
        value: null,
        isPublic: true,
        group: true,
        campaign: true,
        integrations: true
      }
    },
    fecharModal() {
      this.resetarPlano()
      this.$emit('update:planoEdicao', { id: null })
      this.$emit('update:modalPlano', false)
    },
    abrirModal() {
      if (this.planoEdicao.id) {
        this.plano = { ...this.planoEdicao }
      } else {
        this.resetarPlano()
      }
    },
    async handlePlano() {
      try {
        this.loading = true

        if (!this.plano.name) {
          this.$q.notify({ type: 'negative', message: 'O campo Nome é obrigatório!' })
          this.loading = false
          return
        }

        if (!this.plano.maxUsers || !Number.isInteger(Number(this.plano.maxUsers))) {
          this.$q.notify({ type: 'negative', message: 'O campo Max Users deve ser um número inteiro!' })
          this.loading = false
          return
        }

        if (!this.plano.maxConnections || !Number.isInteger(Number(this.plano.maxConnections))) {
          this.$q.notify({ type: 'negative', message: 'O campo Max Connections deve ser um número inteiro!' })
          this.loading = false
          return
        }

        if (!this.plano.value) {
          this.$q.notify({ type: 'negative', message: 'O campo Valor é obrigatório!' })
          this.loading = false
          return
        }

        const valor = this.plano.value.toString().replace(',', '.')
        if (isNaN(valor) || Number(valor) <= 0) {
          this.$q.notify({ type: 'negative', message: 'O campo Valor deve ser um número válido!' })
          this.loading = false
          return
        }

        this.plano.value = parseFloat(valor).toFixed(2)

        let data
        if (this.plano.id) {
          ({ data } = await AlterarPlano(this.plano))
          this.$emit('modal-plano:editada', data)
          this.$q.notify({ type: 'info', message: 'Plano editado!' })
        } else {
          ({ data } = await CriarPlano(this.plano))
          this.$emit('modal-plano:criada', data)
          this.$q.notify({ type: 'positive', message: 'Plano criado!' })
        }

        this.loading = false
        this.$emit('reload-planos')
        this.fecharModal()
      } catch (error) {
        console.error(error)
        this.$notificarErro('Ocorreu um erro!', error)
        this.loading = false
      }
    }
  }

}
</script>

<style lang="scss" scoped></style>
