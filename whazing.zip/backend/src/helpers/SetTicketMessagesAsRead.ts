import { cacheLayer } from '../libs/cache'; // Assuming cacheLayer path
import Message from '../models/Message'; // Assuming Message model path
import Ticket from '../models/Ticket'; // Assuming Ticket model path (needed for typing)
import Contact from '../models/Contact'; // Assuming Contact model path (needed for typing)
import { logger } from '../utils/logger'; // Assuming logger path
import GetTicketWbotBaileys from '../libs/GetTicketWbotBaileys'; // Assuming GetTicketWbotBaileys path
import socketEmit from './socketEmit'; // Assuming socketEmit path (corrected filename)
import { proto } from '@adiwajshing/baileys'; // Import Baileys types if needed

// Define a more specific Ticket type or import it
interface TicketType extends Ticket { // Extend the base Sequelize model type if available
    id: number | string;
    contactId: number | string;
    whatsappId: number | string;
    status: string;
    isGroup: boolean;
    unreadMessages?: number; // Assuming this property exists
    contact?: Contact; // Assuming relation is loaded or available
    // Add other relevant properties
}

const SetTicketMessagesAsRead = async (ticket: TicketType): Promise<void> => {
    try {
         logger.debug(`Estableciendo mensajes como leídos para el ticket ID: ${ticket.id}`);

        // Update unreadMessages count in the database (if applicable)
        await ticket.update({ unreadMessages: 0 }, { silent: true }); // silent might prevent hooks/timestamps

        // Update cache
        await cacheLayer.set(`contacts:${ticket.contactId}:unreads`, '0');

        // Emit socket event for ticket update
        socketEmit({
            tenantId: ticket.tenantId, // Assuming tenantId exists on the ticket
            type: 'ticket:update',
            payload: ticket
        });

        // If the ticket is not from the bot, try to mark messages as read in WhatsApp
        if (!ticket.fromMe) { // Assuming ticket has a 'fromMe' property or similar logic
            const wbot = await GetTicketWbotBaileys(ticket);

             // Find messages to mark as read (last 10 unread fromMe=false as example)
            const messagesToMark = await Message.findAll({
                where: {
                    ticketId: ticket.id,
                    read: false,
                    fromMe: false
                },
                order: [['createdAt', 'DESC']], // Get the latest first
                limit: 10 // Limit the number of messages to mark in one go (optional)
            });

             logger.debug(`Encontrados ${messagesToMark.length} mensajes no leídos para marcar en WhatsApp para el ticket ID: ${ticket.id}`);

            if (messagesToMark.length > 0) {
                const messageKeys: proto.IMessageKey[] = [];
                messagesToMark.forEach(msg => {
                     // Assuming messageId format is like 'remoteJid_messageId' or stored in dataJson
                     // This logic needs careful adaptation based on how Baileys message keys are stored
                    let key: proto.IMessageKey | undefined;
                    try {
                         // Option 1: Parse from dataJson if stored there
                         if (msg.dataJson) {
                              const msgData = JSON.parse(msg.dataJson);
                              key = msgData?.key;
                         }
                         // Option 2: Reconstruct if needed (less reliable)
                         // key = { remoteJid: ticket.contact.number + (ticket.isGroup ? '@g.us' : '@s.whatsapp.net'), id: msg.messageId, fromMe: false };

                         if (key && key.id && key.remoteJid) {
                             messageKeys.push(key);
                         } else {
                              logger.warn(`No se pudo obtener la clave válida para el mensaje ID ${msg.id} en el ticket ${ticket.id}`);
                         }
                    } catch(parseError) {
                        logger.error(`Error al analizar dataJson para el mensaje ID ${msg.id}: ${parseError}`);
                    }

                });

                if (messageKeys.length > 0) {
                    try {
                         logger.debug(`Enviando actualización de lectura para ${messageKeys.length} mensajes en el ticket ${ticket.id}`);
                         await wbot.readMessages(messageKeys);
                         logger.info(`Mensajes marcados como leídos en WhatsApp para el ticket ID: ${ticket.id}`);

                         // Optionally update the 'read' status in your DB after successful WhatsApp confirmation
                         const messageDbIds = messagesToMark.map(m => m.id);
                         await Message.update({ read: true }, { where: { id: messageDbIds }});
                         logger.debug(`Estado de lectura actualizado en la base de datos para ${messageDbIds.length} mensajes.`);

                    } catch (wbotError: any) {
                         logger.error(`No se pudo marcar mensajes como leídos en WhatsApp para el ticket ${ticket.id}. Error: ${wbotError?.message}`);
                         // Consider specific error handling (e.g., session disconnected)
                    }
                }

                // Example using chatModify (less common for marking read, usually for archive/mute)
                // This part seems less likely based on the original code structure but included for possibility
                // if (v.length > 0) { // v was messagesToMark
                //     const lastMessage = messagesToMark[0]; // The latest unread message
                //     const chatModification = {
                //         markRead: true, // This might not be a valid field, check Baileys docs
                //         lastMessages: [lastMessage] // Needs actual Baileys message object
                //     };
                //     const contactJid = ticket.contact.number + (ticket.isGroup ? '@g.us' : '@s.whatsapp.net');
                //     await wbot.chatModify(chatModification, contactJid);
                // }
            }

            // Update all remaining messages in DB (redundant if done above, but matches original logic flow)
            // This ensures *all* fromMe=false messages are marked read in DB, even if WhatsApp failed
            // await Message.update(
            //     { read: true },
            //     { where: { ticketId: ticket.id, read: false, fromMe: false } }
            // );
            // logger.debug(`Actualización final de lectura de la base de datos completada para el ticket ${ticket.id}`);

        } else {
             logger.debug(`El ticket ${ticket.id} es de 'fromMe', no se marcarán mensajes en WhatsApp.`);
              // Still update DB messages if needed for internal consistency?
              await Message.update(
                 { read: true },
                 { where: { ticketId: ticket.id, read: false, fromMe: false } }
              );
              logger.debug(`Estado de lectura actualizado en la base de datos (fromMe=true) para el ticket ${ticket.id}`);
        }

    } catch (error: any) {
        console.error(error); // Log the full error object for details
        logger.error(`No se pudieron marcar los mensajes como leídos para el ticket ${ticket.id}. Error: ${error.message}. ¿Quizás la sesión de WhatsApp está desconectada?`);
    }
};

export default SetTicketMessagesAsRead;