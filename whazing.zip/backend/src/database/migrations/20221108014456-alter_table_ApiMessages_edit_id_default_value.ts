// --- START OF FILE 20221108014456-alter_table_ApiMessages_edit_id_default_value.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize, literal } from 'sequelize'; // Added literal

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

// Re-using the helper function from the ApiConfigs migration
const getUuidFunction = (dialect: string): string => {
    switch (dialect) {
        case 'postgres':
            return 'gen_random_uuid()';
        case 'mysql':
            return 'UUID()';
        case 'sqlite':
            console.warn("SQLite does not support UUID default values directly in migrations like this.");
            return '(hex(randomblob(16)))';
        case 'mssql':
             return 'NEWID()';
        default:
            console.warn(`Unsupported dialect for UUID generation: ${dialect}. Falling back to gen_random_uuid().`);
            return 'gen_random_uuid()';
    }
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface, sequelize: typeof Sequelize): Promise<void> => {
        const tableName = 'ApiMessages'; // 'ApiMessage' + 's'
        const columnName = 'id';
        const dialect = queryInterface.sequelize.getDialect();
        const uuidFunction = getUuidFunction(dialect); // 'gen_random' + '_uuid()' -> use helper
        const defaultValueExpression = uuidFunction ? literal(uuidFunction) : null;

         if (!defaultValueExpression) {
             console.error("Could not determine UUID generation function for the current dialect.");
              await Promise.all([
                 queryInterface.changeColumn(tableName, columnName, {
                    allowNull: false,
                    primaryKey: true,
                    type: DataTypes.UUID
                    // No default value
                 })
              ]);
        } else {
             await Promise.all([
                queryInterface.changeColumn(tableName, columnName, {
                    allowNull: false,
                    primaryKey: true,
                    type: DataTypes.UUID,
                    defaultValue: defaultValueExpression
                })
             ]);
        }
    },

    down: async (queryInterface: QueryInterface, sequelize: typeof Sequelize): Promise<void> => {
        const tableName = 'ApiMessages'; // 'ApiMessage' + 's'
        const columnName = 'id';
        const dialect = queryInterface.sequelize.getDialect();
        const uuidFunction = getUuidFunction(dialect); // 'gen_random' + '_uuid()' -> use helper
        const defaultValueExpression = uuidFunction ? literal(uuidFunction) : null;


         if (!defaultValueExpression) {
             console.error("Could not determine UUID generation function for the current dialect during rollback.");
              await Promise.all([
                 queryInterface.changeColumn(tableName, columnName, {
                    allowNull: false,
                    primaryKey: true,
                    type: DataTypes.UUID
                    // No default value
                 })
              ]);
        } else {
            // Assuming the previous state also had this default value. Adjust if necessary.
            await Promise.all([
                queryInterface.changeColumn(tableName, columnName, {
                    allowNull: false,
                    primaryKey: true,
                    type: DataTypes.UUID,
                    defaultValue: defaultValueExpression
                })
            ]);
        }
    }
};

export default migration;

// --- END OF FILE 20221108014456-alter_table_ApiMessages_edit_id_default_value.ts ---