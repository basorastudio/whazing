// --- START OF FILE 20220101191958-add-colum-tenantId-table-messages.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Messages';
        const columnName = 'tenantId';
        const attributes = {
            type: DataTypes.INTEGER,
            references: {
                model: 'Tenants',
                key: 'id'
            },
            onUpdate: 'CASCADE',
            onDelete: 'restrict', // Original was 'restrict', assuming it's valid. Common values: 'RESTRICT', 'CASCADE', 'NO ACTION', 'SET DEFAULT', 'SET NULL'
            allowNull: true, // Changed !![] to true
            defaultValue: null
        };
        await Promise.all([
            queryInterface.addColumn(tableName, columnName, attributes)
        ]);
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Messages';
        const columnName = 'tenantId';
        await Promise.all([
            queryInterface.removeColumn(tableName, columnName)
        ]);
    }
};

export default migration;

// --- END OF FILE 20220101191958-add-colum-tenantId-table-messages.ts ---