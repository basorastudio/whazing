import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'instagramPK' (INTEGER) a 'Contacts'
    return Promise.all([
      queryInterface.addColumn("Contacts", "instagramPK", {
        type: DataTypes.INTEGER, // Tipo INTEGER
        allowNull: true, // Permite nulos
        defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'instagramPK' de 'Contacts'
    return Promise.all([
      queryInterface.removeColumn("Contacts", "instagramPK")
    ]);
  }
};
