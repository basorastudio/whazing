import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import Tenant from "./Tenant";
import User from "./User";

@Table
class Tag extends Model<Tag> {
  // Changed class name to singular
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  name: string; // Assuming 'tag' resolved to 'name'

  @Column
  color: string;

  @Default(true)
  @Column
  isActive: boolean;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;
}

export default Tag; // Changed export name
