import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla 'Tenants'
    return queryInterface.createTable("Tenants", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      status: {
        // Estado del tenant (ej: 'active', 'inactive')
        type: DataTypes.STRING,
        defaultValue: "active", // Valor predeterminado es 'active'
        allowNull: false
      },
      ownerId: {
        // ID del usuario propietario del tenant
        type: DataTypes.INTEGER,
        references: {
          model: "Users", // Referencia a la tabla Users
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "restrict" // No permite eliminar al usuario propietario si tiene un tenant
      },
      createdAt: {
        type: DataTypes.DATE(6), // Fecha con precisión de microsegundos
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE(6), // Fecha con precisión de microsegundos
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    return queryInterface.dropTable("Tenants");
  }
};
