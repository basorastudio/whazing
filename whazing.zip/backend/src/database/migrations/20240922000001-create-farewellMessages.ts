import { QueryInterface, DataTypes, Sequelize } from 'sequelize'; // Added Sequelize for DataTypes.fn
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'FarewellMessages' table
    await queryInterface.createTable(
      'FarewellMessages', // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
          allowNull: false,
        },
        message: {
          type: DataTypes.TEXT, // TEXT for potentially long messages
          allowNull: false,
        },
        global: {
          type: DataTypes.BOOLEAN,
          defaultValue: false, // Default to not global
          allowNull: false,   // Cannot be null
        },
        userId: {
          type: DataTypes.INTEGER,
          allowNull: false,
          references: {
            model: 'Users', // Foreign key to Users
            key: 'id',
          },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE', // If user deleted, delete their messages
        },
        tenantId: {
          type: DataTypes.INTEGER,
          allowNull: false,
          references: {
            model: 'Tenants', // Foreign key to Tenants
            key: 'id',
          },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE', // If tenant deleted, delete associated messages
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'), // Use database's NOW function
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'), // Use database's NOW function
        },
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'FarewellMessages' table
    await queryInterface.dropTable('FarewellMessages');
  }
};

export = migration;