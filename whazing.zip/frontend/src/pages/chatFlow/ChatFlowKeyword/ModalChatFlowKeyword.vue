<template>
  <q-dialog
    :value="modalChatFlowKeyword"
    @hide="fecharModal"
    @show="abrirModal"
    persistent
  >
    <q-card class="q-pa-md modal-container container-rounded-10">

    <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ keyword.id ? $t('chatbotkeyword.editKeyword') : $t('chatbotkeyword.createKeyword') }}
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="q-pa-lg container-border container-rounded-10">
        <q-input
          rounded
          class="row col q-mb-md"
          outlined
          v-model="keyword.keyword"
          :label="$t('chatbotkeyword.keyword')"
          :rules="[val => !!val || $t('general.fieldRequired')]"
        />
        <div class="col-12 col-sm-6">
        <q-select
          rounded
          class="row col q-mb-md"
          outlined
          v-model="selectedChatFlow"
          :options="chatFlowOptions"
          option-value="id"
          option-label="name"
          :label="$t('chatbotkeyword.selectChatFlow')"
          :rules="[val => !!val || $t('general.fieldRequired')]"
          emit-value
          map-options
        />
        </div>

        <div class="col-12 col-sm-6">
        <q-select
          rounded
          class="row col q-mb-md"
          outlined
          v-model="selectedWhatsapp"
          :options="whatsappOptions"
          option-value="id"
          option-label="name"
          :label="$t('chatbotkeyword.selectWhatsapp')"
          :rules="[val => !!val || $t('general.fieldRequired')]"
          emit-value
          map-options
        />
        </div>

        <div class="row col q-mt-md" v-if="keyword.id">
          <q-checkbox
            v-model="keyword.isActive"
            :label="$t('chatbotkeyword.active')"
          />
        </div>
      </q-card-section>

      <q-card-actions align="right" class="q-mt-md">
        <q-btn
          :label="$t('general.cancelar')"
          color="negative"
          v-close-popup
          class="q-mr-md btn-rounded-50"
        />
        <q-btn
          :label="$t('general.salvar')"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          icon="eva-save-outline"
          @click="handleSalvarKeyword"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { CriarChatFlowKeyword, UpdateChatFlowKeyword, ListarChatFlow } from 'src/service/chatFlow'
import { mapGetters } from 'vuex'

export default {
  name: 'ModalChatFlowKeyword',
  props: {
    modalChatFlowKeyword: {
      type: Boolean,
      default: false
    },
    keywordEdicao: {
      type: Object,
      default: () => {
        return { id: null }
      }
    }
  },
  data () {
    return {
      keyword: {
        id: null,
        keyword: '',
        isActive: true,
        chatFlowId: null,
        whatsappId: null
      },
      selectedChatFlow: null,
      selectedWhatsapp: null,
      listachatFlow: []
    }
  },
  computed: {
    ...mapGetters([
      'whatsapps'
    ]),
    chatFlowOptions() {
      return this.listachatFlow.map(flow => ({
        id: flow.id,
        name: flow.name
      }))
    },
    whatsappOptions() {
      return this.whatsapps.map(whatsapp => ({
        id: whatsapp.id,
        name: whatsapp.name
      }))
    }
  },
  methods: {
    async abrirModal () {
      await this.listarChatFlow()

      if (this.keywordEdicao.id) {
        this.keyword = { ...this.keywordEdicao }
        this.selectedChatFlow = this.keyword.chatFlowId
        this.selectedWhatsapp = this.keyword.whatsappId
      } else {
        this.keyword = {
          id: null,
          keyword: '',
          isActive: true,
          chatFlowId: null,
          whatsappId: null
        }
        this.selectedChatFlow = null
        this.selectedWhatsapp = null
      }
    },
    fecharModal () {
      this.keyword = {
        id: null,
        keyword: '',
        isActive: true,
        chatFlowId: null,
        whatsappId: null
      }
      this.selectedChatFlow = null
      this.selectedWhatsapp = null
      this.$emit('update:keywordEdicao', { id: null })
      this.$emit('update:modalChatFlowKeyword', false)
    },
    async listarChatFlow () {
      const { data } = await ListarChatFlow()
      this.listachatFlow = data.chatFlow
    },
    async handleSalvarKeyword () {
      if (!this.keyword.keyword || !this.selectedChatFlow || !this.selectedWhatsapp) {
        this.$notificarErro(this.$t('general.allFieldsRequired'))
        return
      }

      this.keyword.chatFlowId = this.selectedChatFlow
      this.keyword.whatsappId = this.selectedWhatsapp

      try {
        if (this.keyword.id) {
          const { data } = await UpdateChatFlowKeyword(this.keyword)
          this.$notificarSucesso(this.$t('chatbotkeyword.keywordUpdated'))
          this.$emit('keyword:atualizada', data)
        } else {
          const { data } = await CriarChatFlowKeyword(this.keyword)
          this.$notificarSucesso(this.$t('chatbotkeyword.keywordCreated'))
          this.$emit('keyword:criada', data)
        }
        this.fecharModal()
      } catch (error) {
        this.$notificarErro(this.$t('chatbotkeyword.errorSaving'))
        console.error(error)
      }
    }
  }
}
</script>

<style scoped>
.file-input {
  display: none;
}

.file-button {
  font-size: 14px;
  line-height: 1.715em;
  color: inherit;
  font-weight: 500;
  text-transform: uppercase;
  text-align: center;
  padding: 8px 16px;
  border: none;
  border-radius: 50px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
}

.file-button-dark {
  background-color: #4caf50; /* Cor para o modo escuro */
  color: white;
}

.file-button-light {
  background-color: #5c67f2; /* Cor para o modo claro */
  color: white;
}

.file-button .q-icon {
  font-size: 1.2em; /* Ajuste o tamanho do ícone conforme necessário */
}

.generate-button-dark {
  background-color: #4caf50; /* Cor para o modo escuro */
  color: white;
}

.generate-button-light {
  background-color: #5c67f2; /* Cor para o modo claro */
  color: white;
}

.generate-button .q-icon {
  font-size: 1.2em; /* Ajuste o tamanho do ícone conforme necessário */
}
</style>
