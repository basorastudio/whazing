// Deobfuscated string access is now inline
import __importDefault from './_importDefault'; // Assuming __importDefault is a local helper or adjust as needed

import dotenv from 'dotenv';

// Environment-specific .env file loading logic
const envPath: string = process.env.NODE_ENV === 'test' ? '.env.test' : '.env';

// Configure dotenv
dotenv.config({ path: envPath });


// Helper simulation (remove if you have a real __importDefault)
function __importDefault<T>(mod: { default: T } | T): { default: T } | T {
    return mod && (mod as any).__esModule ? mod : { default: mod };
}

// This file primarily configures environment variables, no main export needed unless used elsewhere directly.