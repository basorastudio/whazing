import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Change unique constraint on 'Whatsapps' table from just 'name' to 'name' + 'tenantId'
    try {
      // Remove the old constraint (likely named 'Whatsapps_name_key' by convention)
      await queryInterface.removeConstraint("Whatsapps", "Whatsapps_name_key");
    } catch (error) {
      // Log a warning if the constraint wasn't found, but continue
      console.warn(
        "Constraint 'Whatsapps_name_key' no encontrada, prosiguiendo..."
      );
    }
    // Add the new composite unique constraint
    await queryInterface.addConstraint("Whatsapps", {
      fields: ["name", "tenantId"], // Fields included in the constraint
      type: "unique",
      name: "unique_tenant_name_constraint" // Explicit constraint name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Revert the constraint change: remove composite, add back single-column constraint
    try {
      // Remove the composite constraint
      await queryInterface.removeConstraint(
        "Whatsapps",
        "unique_tenant_name_constraint"
      );
    } catch (error) {
      console.warn(
        "Constraint 'unique_tenant_name_constraint' no encontrada, prosiguiendo..."
      );
    }
    // Add back the single-column unique constraint on 'name'
    // Note: This might fail if duplicate names exist across different tenants after the 'up' migration.
    await queryInterface.addConstraint("Whatsapps", {
      fields: ["name"],
      type: "unique",
      name: "Whatsapps_name_key" // Restore original conventional name
    });
  }
};

export = migration;
