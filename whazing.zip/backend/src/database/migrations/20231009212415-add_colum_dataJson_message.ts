// --- START OF FILE 20231009212415-add_colum_dataJson_message.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Messages";
    const columnName = "dataJson";

    const tableDescription = await queryInterface.describeTable(tableName); // describeTa' + 'ble'

    if (!tableDescription || !tableDescription[columnName]) {
      const attributes = {
        type: DataTypes.TEXT, // Original was TEXT
        allowNull: true // Changed !![] to true
        // defaultValue not specified, assuming null is ok
      };
      await queryInterface.addColumn(tableName, columnName, attributes);
    } else {
      console.log(
        `La columna ${columnName} ya existe en la tabla ${tableName}. Saltando adición.`
      );
    }
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Messages";
    const columnName = "dataJson";

    const tableDescription = await queryInterface.describeTable(tableName);

    if (tableDescription && tableDescription[columnName]) {
      await queryInterface.removeColumn(tableName, columnName);
    } else {
      console.log(
        `La columna ${columnName} no existe en la tabla ${tableName}. Saltando eliminación.`
      );
    }
  }
};

export default migration;

// --- END OF FILE 20231009212415-add_colum_dataJson_message.ts ---
