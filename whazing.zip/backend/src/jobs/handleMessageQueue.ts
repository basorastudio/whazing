import { handleMessage as handleMessageListener } from '../services/WbotServices/wbotMessageListener'; // Renamed to avoid conflict
import { getWbot } from '../libs/wbot';
import Queue from '../libs/Queue';
import { proto } from '@whiskeysockets/baileys'; // Assuming Baileys types are needed

// Define interfaces for the data structures
interface MessageData {
    message: proto.IWebMessageInfo; // Use actual Baileys type
    whatsappId: number;
    isImported?: boolean;
    tenantId: number | string; // Added based on usage in messageUpsert
    // Potentially other properties if the job data structure is richer
}

interface Job {
    data: MessageData;
    attemptsMade?: number; // Example of standard queue job property
    id?: string | number; // Example
    // Add other job properties as needed
}

interface BackoffOptions {
    type: string;
    delay: number;
}

interface HandleOptions {
    delay: number;
    attempts: number;
    removeOnComplete: boolean;
    removeOnFail: boolean;
    backoff: BackoffOptions;
}

const backoffOptions: BackoffOptions = {
    type: 'fixed',
    delay: 180000 // 0x2bf20
};

const handleOptions: HandleOptions = {
    delay: 600,        // 0x258
    attempts: 10,
    removeOnComplete: true,
    removeOnFail: false, // Original: ![]
    backoff: backoffOptions
};

// Constants
const MAX_RETRIES = 5; // From original code (j variable)
const RETRY_DELAY = 30000; // From original code (await new Promise timeout)

export const handleMessageQueue = {
    key: 'HandleMessageQueue',
    options: handleOptions,
    async handle({ data }: Job): Promise<void> {
        try {
            const { message: messageData, whatsappId, isImported, tenantId } = data; // Added tenantId extraction
            const wbot = getWbot(whatsappId);
            const messageKey = messageData.key;
            const remoteJid = messageKey?.remoteJid;

            // Placeholder/Resync Logic (simplified interpretation)
            const conversationText = messageData.message?.conversation || messageData.message?.extendedTextMessage?.text;
            if (conversationText) {
                if (conversationText === 'resync') {
                    console.log('Mensaje de Resync recibido, intentando recuperar historial:', messageKey);
                    // Original had fetchLatestMessageHistory, adjust if needed
                    // const history = await wbot.fetchMessageHistory(remoteJid, 100); // Example
                    // console.log('Historial recuperado:', history);
                    return; // Assuming resync just needs logging or specific handling
                }
                if (conversationText === 'placeholder') {
                     console.log('Mensaje de Placeholder recibido, solicitando mensajes bajo demanda:', messageKey);
                    // Original had fetchMessagesFromWA, adjust if needed
                    // const messages = await wbot.fetchMessagesFromWA(remoteJid, 100); // Example
                    // console.log('Mensajes bajo demanda recuperados:', messages);
                     return; // Assuming placeholder just needs logging or specific handling
                }
            }


            // Retry Logic for sent messages (simplified interpretation)
            const retryMap = new Map<string, number>();
            const handleRetry = async (msgToRetry: proto.IWebMessageInfo): Promise<proto.IWebMessageInfo | null> => {
                const msgId = msgToRetry.key.id;
                if (!msgId) return null;

                let attempt = retryMap.get(msgId) || 0;
                console.log(`Intentando reenviar mensaje ${msgId}, intento ${attempt}`);

                if (attempt >= MAX_RETRIES) {
                    console.log(`Máximo de reintentos alcanzado para el mensaje ${msgId}, eliminando del mapa.`);
                    retryMap.delete(msgId);
                    return null; // Stop retrying
                }

                attempt++;
                retryMap.set(msgId, attempt);
                console.log(`Reintento ${attempt} para el mensaje ${msgId}`);

                // Return a structure that can be re-queued or processed
                // The original structure manipulation was complex, this is a simplified approach
                // It might need adjustments based on how the queue handles retries
                return {
                    ...msgToRetry // Return the original message structure for simplicity
                };
            };

            // If it's an outgoing message and status is ERROR, attempt retry
            if (messageData.key?.fromMe && messageData.status === proto.WebMessageInfo.Status.ERROR) {
                 console.log(`Mensaje ${messageKey?.id} con error, iniciando lógica de reintento.`);
                 const retriedMessage = await handleRetry(messageData);
                 if (retriedMessage) {
                     console.log(`Reintentando enviar mensaje ${messageKey?.id}`);
                     try {
                         // Use relayMessage for retrying according to original logic
                         await new Promise(resolve => setTimeout(resolve, RETRY_DELAY)); // Delay before retry
                         await wbot.relayMessage(remoteJid!, retriedMessage.message!, { messageId: retriedMessage.key.id! });
                         console.log(`Mensaje ${messageKey?.id} reenviado exitosamente.`);
                     } catch (relayError: any) {
                         console.error(`Error al reenviar mensaje ${messageKey?.id}:`, relayError);
                         // Decide if further retries are needed or throw error
                         // throw relayError; // Option: throw to let queue handle failure
                     }
                 }
                 return; // Stop processing after handling retry logic
            }


            // Recovery Logic (Simplified Interpretation)
            // The original logic checked messageStubType and messageStubParameters
            // This part seems complex and might involve parsing specific Baileys internal structures
            const messageStubType = messageData.messageStubType;
            const messageStubParameters = messageData.messageStubParameters;
            if (messageStubType && messageStubParameters && messageStubParameters.length > 0) {
                 console.log(`Mensaje Stub detectado: Tipo ${messageStubType}, Parámetros: ${messageStubParameters}`);
                 // Enqueue for RecoveryMessage Job
                 const recoveryJobData = {
                     message: messageData,
                     whatsappId: whatsappId,
                     isImported: isImported,
                     tenantId: tenantId,
                 };
                 const jobId = `${whatsappId}-RecoveryMessage-${messageKey?.id}`;
                 await Queue.add('RecoveryMessage', recoveryJobData, { jobId });
                 console.log(`Trabajo RecoveryMessage encolado para mensaje ${messageKey?.id}`);
                 return; // Stop processing, let Recovery job handle it
            }

            // If none of the above conditions met, proceed with normal handling
            await handleMessageListener(wbot, messageData, whatsappId, isImported);

        } catch (error: any) {
            console.error("Error handling Message Queue job:", error);
            // Log specific details if available
            if (error?.message) {
                console.error("Error message:", error.message);
            }
            if (error?.stack) {
                 console.error("Stack trace:", error.stack);
            }
            // Optionally add job data to error context
            // Sentry.captureException(error, { extra: { jobId: data.jobId, messageId: data?.message?.key?.id } });
            throw error; // Re-throw error
        }
    }
};