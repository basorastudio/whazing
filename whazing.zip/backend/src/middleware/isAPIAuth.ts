/**
 * Middleware para autenticar solicitudes de API usando un token JWT en el header Authorization.
 */
import { Response, NextFunction } from "express";
import { verify } from "jsonwebtoken"; // Importación nombrada
import AppError from "../errors/AppError";
import authConfig from "../config/auth"; // Asume que authConfig es la exportación default
import { AuthRequest } from "./interfaces/AuthRequest"; // Importa la interfaz

interface TokenPayload {
  apiId: string | number;
  sessionId: number;
  tenantId: string | number;
  iat: number; // Issued at (standard JWT claim)
  exp: number; // Expiration time (standard JWT claim)
}

const isAPIAuth = (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): void => {
  const authHeader = req.headers.authorization;

  // Verifica si el header Authorization existe
  if (!authHeader) {
    throw new AppError("Token no proporcionado.", 401); // 401 Unauthorized
  }

  // Divide el header para obtener el token ("Bearer TOKEN_AQUI")
  const [, token] = authHeader.split(" ");

  try {
    // Verifica el token usando el secreto de la configuración
    const decoded = verify(token, authConfig.secret); // Usa el secreto de authConfig

    // Extrae los datos del payload decodificado
    const { apiId, sessionId, tenantId } = decoded as TokenPayload;

    // Adjunta los datos de autenticación de la API al objeto request
    // Asegúrate de que la interfaz AuthRequest tenga la propiedad apiAuth
    req.apiAuth = {
      apiId,
      sessionId,
      tenantId
    };

    // Pasa al siguiente middleware/controlador
    return next();

  } catch (err) {
    // Si la verificación falla (token inválido, expirado, etc.)
    throw new AppError("Token inválido.", 401); // 401 Unauthorized
  }
};

export default isAPIAuth; // Exportación default