import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'typebotSessionId' column to the 'Tickets' table
    // Stores the session ID for an active Typebot interaction.
    await queryInterface.addColumn(
      "Tickets", // Table name
      "typebotSessionId", // New column name
      {
        type: DataTypes.STRING,
        defaultValue: null, // Default is null
        allowNull: true // Allow null (no active session)
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'typebotSessionId' column from the 'Tickets' table
    await queryInterface.removeColumn(
      "Tickets", // Table name
      "typebotSessionId" // Column name to remove
    );
  }
};

export = migration;
