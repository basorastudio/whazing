<template>
  <q-dialog
    title="Ayuda"
    v-model="dialogVisible"
    width="70%"
    customClass="flowHelp"
  >
    <el-tabs tab-position="left">
      <el-tab-pane label="Cómo añadir">
        <el-divider content-position="left">Cómo añadir</el-divider>
        <div>Mantén presionado el ratón, arrastra el componente del lado izquierdo al lienzo central y suelta el ratón</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo eliminar">
        <el-divider content-position="left">Eliminar desde la página</el-divider>
        <div>
          Haz clic sobre el nodo que deseas eliminar y luego en el icono de eliminar ubicado en la esquina superior izquierda
        </div>
        <el-divider content-position="left">Eliminar mediante código</el-divider>
        <pre>this.deleteNode(nodeId)</pre>
      </el-tab-pane>
      <el-tab-pane label="Cómo mover">
        <el-divider content-position="left">Cómo mover</el-divider>
        <div>Mueve el ratón sobre el nodo; cuando se transforme en el icono de arrastrar, presiona y arrastra hasta la nueva posición y suelta</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo conectar">
        <el-divider content-position="left">Cómo conectar</el-divider>
        <div>Mueve el ratón sobre el icono del lado izquierdo del nodo; cuando aparezca un "+", presiona, arrastra a otro nodo y suelta</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo agregar condiciones">
        <el-divider content-position="left">Cómo agregar condiciones</el-divider>
        <div>Haz clic en la línea del lienzo; aparecerá un formulario en el lado derecho de la página, ingresa las nuevas condiciones y haz clic en [Guardar]</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo interactuar y almacenar en el backend">
        <el-divider content-position="left">Cómo interactuar y almacenar en el backend</el-divider>
        <div>Referencia: https://gitee.com/xiaoka2017/easy-flow-sdk</div>
      </el-tab-pane>
    </el-tabs>
  </q-dialog>
</template>

<script>
export default {
  data () {
    return {
      dialogVisible: false
    }
  },
  components: {},
  methods: {
    init () {
      this.dialogVisible = true
    }
  }
}
</script>

<style>
.flowHelp {
  height: 80%;
}
</style>
