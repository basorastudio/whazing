<template>
  <q-page padding>
    <div class="row q-col-gutter-md">
      <div class="col-12">
        <q-card>
          <q-card-section>
            <div class="text-h6">Administración del Sistema</div>
          </q-card-section>

          <q-card-section>
            <q-tabs
              v-model="tab"
              class="text-primary"
              active-color="primary"
              indicator-color="primary"
              align="left"
              narrow-indicator
            >
              <q-tab name="tokens" label="Gestión de Tokens" />
              <q-tab name="endpoints" label="Documentación API" />
            </q-tabs>

            <q-tab-panels v-model="tab" animated>
              <q-tab-panel name="tokens">
                <div class="row q-col-gutter-md">
                  <div class="col-12">
                    <q-btn
                      color="primary"
                      label="Generar Nuevo Token"
                      @click="generarNuevoToken"
                      :loading="generandoToken"
                    />
                  </div>

                  <div class="col-12" v-if="tokenActual">
                    <q-card flat bordered>
                      <q-card-section>
                        <div class="text-subtitle2">Token Actual</div>
                        <q-input
                          v-model="tokenActual"
                          type="textarea"
                          readonly
                          filled
                          autogrow
                        />
                        <div class="row q-gutter-sm q-mt-sm">
                          <q-btn
                            flat
                            color="primary"
                            icon="content_copy"
                            label="Copiar"
                            @click="copiarToken"
                          />
                          <q-btn
                            flat
                            color="primary"
                            icon="refresh"
                            label="Renovar"
                            @click="renovarToken"
                            :loading="renovandoToken"
                          />
                        </div>
                      </q-card-section>
                    </q-card>
                  </div>
                </div>
              </q-tab-panel>

              <q-tab-panel name="endpoints">
                <div class="text-subtitle1 q-mb-md">Endpoints de Administración</div>
                <q-list bordered separator>
                  <q-expansion-item
                    group="endpoints"
                    icon="post_add"
                    label="Generar Token de Administrador"
                    caption="POST /admin/token"
                    header-class="text-primary"
                  >
                    <q-card>
                      <q-card-section>
                        <div class="text-subtitle2">Descripción</div>
                        <p>Genera un nuevo token de administrador para acceder a las APIs del sistema.</p>
                        
                        <div class="text-subtitle2">Respuesta</div>
                        <q-markup-table flat bordered>
                          <thead>
                            <tr>
                              <th class="text-left">Campo</th>
                              <th class="text-left">Tipo</th>
                              <th class="text-left">Descripción</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>token</td>
                              <td>string</td>
                              <td>Token de acceso generado</td>
                            </tr>
                          </tbody>
                        </q-markup-table>
                      </q-card-section>
                    </q-card>
                  </q-expansion-item>

                  <q-expansion-item
                    group="endpoints"
                    icon="autorenew"
                    label="Renovar Token de Administrador"
                    caption="POST /admin/token/renew"
                    header-class="text-primary"
                  >
                    <q-card>
                      <q-card-section>
                        <div class="text-subtitle2">Descripción</div>
                        <p>Renueva un token de administrador existente.</p>

                        <div class="text-subtitle2">Parámetros</div>
                        <q-markup-table flat bordered>
                          <thead>
                            <tr>
                              <th class="text-left">Campo</th>
                              <th class="text-left">Tipo</th>
                              <th class="text-left">Descripción</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>token</td>
                              <td>string</td>
                              <td>Token actual a renovar</td>
                            </tr>
                          </tbody>
                        </q-markup-table>

                        <div class="text-subtitle2 q-mt-md">Respuesta</div>
                        <q-markup-table flat bordered>
                          <thead>
                            <tr>
                              <th class="text-left">Campo</th>
                              <th class="text-left">Tipo</th>
                              <th class="text-left">Descripción</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>token</td>
                              <td>string</td>
                              <td>Nuevo token de acceso</td>
                            </tr>
                          </tbody>
                        </q-markup-table>
                      </q-card-section>
                    </q-card>
                  </q-expansion-item>
                </q-list>
              </q-tab-panel>
            </q-tab-panels>
          </q-card-section>
        </q-card>
      </div>
    </div>

    <q-dialog v-model="confirmDialog">
      <q-card>
        <q-card-section>
          <div class="text-h6">Confirmar Acción</div>
        </q-card-section>

        <q-card-section>
          {{ confirmMessage }}
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="Cancelar" color="primary" v-close-popup />
          <q-btn
            flat
            label="Confirmar"
            color="primary"
            @click="confirmarAccion"
            v-close-popup
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script>
import { generarTokenAdmin, renovarTokenAdmin } from 'src/service/adminApi'
import { Notify } from 'quasar'

export default {
  name: 'TokenAdmin',

  data () {
    return {
      tab: 'tokens',
      tokenActual: null,
      generandoToken: false,
      renovandoToken: false,
      confirmDialog: false,
      confirmMessage: '',
      accionPendiente: null
    }
  },

  methods: {
    async generarNuevoToken () {
      this.confirmMessage = '¿Está seguro que desea generar un nuevo token? El token anterior dejará de funcionar.'
      this.accionPendiente = 'generar'
      this.confirmDialog = true
    },

    async renovarToken () {
      this.confirmMessage = '¿Está seguro que desea renovar el token actual?'
      this.accionPendiente = 'renovar'
      this.confirmDialog = true
    },

    async confirmarAccion () {
      if (this.accionPendiente === 'generar') {
        await this.ejecutarGenerarToken()
      } else if (this.accionPendiente === 'renovar') {
        await this.ejecutarRenovarToken()
      }
      this.accionPendiente = null
    },

    async ejecutarGenerarToken () {
      try {
        this.generandoToken = true
        const response = await generarTokenAdmin()
        this.tokenActual = response.data.token
        Notify.create({
          type: 'positive',
          message: 'Token generado exitosamente'
        })
      } catch (error) {
        console.error('Error al generar token:', error)
        Notify.create({
          type: 'negative',
          message: 'Error al generar el token'
        })
      } finally {
        this.generandoToken = false
      }
    },

    async ejecutarRenovarToken () {
      if (!this.tokenActual) {
        Notify.create({
          type: 'warning',
          message: 'No hay token para renovar'
        })
        return
      }

      try {
        this.renovandoToken = true
        const response = await renovarTokenAdmin({ token: this.tokenActual })
        this.tokenActual = response.data.token
        Notify.create({
          type: 'positive',
          message: 'Token renovado exitosamente'
        })
      } catch (error) {
        console.error('Error al renovar token:', error)
        Notify.create({
          type: 'negative',
          message: 'Error al renovar el token'
        })
      } finally {
        this.renovandoToken = false
      }
    },

    copiarToken () {
      if (this.tokenActual) {
        navigator.clipboard.writeText(this.tokenActual)
        Notify.create({
          type: 'positive',
          message: 'Token copiado al portapapeles'
        })
      }
    }
  }
}
</script>