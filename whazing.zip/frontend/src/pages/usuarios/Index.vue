<template>
  <div class="full-width">
    <q-card flat class="no-shadow">
      <q-tabs
        v-model="tab"
        dense
        class="text-primary"
        active-color="color-light2"
        indicator-color="color-light2"
        align="justify"
      >
        <q-tab name="Usuários" label="Usuarios" />
        <q-tab name="Equipes" label="Equipos" />
      </q-tabs>
      <q-separator />

      <q-tab-panels v-model="tab" animated>
        <q-tab-panel name="Usuários" class="q-pa-none">
          <usuarios/>
        </q-tab-panel>

        <q-tab-panel name="Equipes" class="q-pa-none">
          <equipes/>
        </q-tab-panel>

      </q-tab-panels>
    </q-card>
  </div>
</template>

<script>
import usuarios from './usuarios/index.vue'
import equipes from './equipes/Index.vue'

export default {
  data () {
    return {
      tab: 'Usuarios',
      innerTab: 'innerMails',
      splitterModel: 20
    }
  },
  components: {
    usuarios,
    equipes
  }
}
</script>
