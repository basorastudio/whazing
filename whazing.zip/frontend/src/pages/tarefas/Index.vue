<template>
  <div>
    <q-banner v-if="!premium" dense inline-actions class="bg-amber-8 text-white q-mb-md">
      <template v-slot:avatar>
        <q-icon name="star" />
      </template>
      {{ $t('general.msgRecursoPremium') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               icon="mdi-whatsapp"
               :label="$t('general.linkobterpremium')"
               @click="abrirWhatsApp3"
        />
      </template>
    </q-banner>

    <q-card-section v-if="!premium">
      <div class="row items-center justify-around q-col-gutter-md">
        <!-- Texto -->
        <div class="col-xs-12 col-sm-6 text-left">
          <div class="text-h6">
            {{ $t('dashboard.supportPlatform') }}
          </div>
          <div class="text-body q-mt-sm">
            {{ $t('dashboard.donationMessage') }}
          </div>
        </div>
        <!-- Imagem -->
        <div class="col-xs-12 col-sm-4 text-center">
          <img src="https://raw.githubusercontent.com/cleitonme/Whazing-SaaS/main/donate.jpg"
               alt="QR Code para doação via Pix"
               class="donation-image">
        </div>
      </div>
      <!-- Ícones de redes sociais -->
      <div class="row justify-center q-mt-md">
        <div class="social-icons">
          <q-btn round color="green" icon="mdi-whatsapp" size="md" class="q-mx-xs"
                 type="a" href="https://grupo.whazing.com.br/" target="_blank">
            <q-tooltip>Nosso Grupo de WhatsApp</q-tooltip>
          </q-btn>
          <q-btn round color="primary" icon="mdi-web" size="md" class="q-mx-xs"
                 type="a" href="https://www.whazing.com.br" target="_blank">
            <q-tooltip>Nosso Site</q-tooltip>
          </q-btn>
        </div>
      </div>
    </q-card-section>
    <q-table
      flat
      bordered
      square
      hide-bottom
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      title="Tarefas"
      :data="tarefas"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="eva-list-outline" />
            {{ $t('task.title') }}
          </h2>
          <div class="row flex-gap-col-1">
            <q-input
              :class="{
                'order-last q-mt-md': $q.screen.width < 500
              }"
              class="contact-search"
              style="width: 300px"
              filled
              dense
              debounce="500"
              v-model="filter"
              clearable
              :placeholder="$t('general.search')"
              @input="filtrarTarefa"
            >
              <template v-slot:prepend>
                <q-icon name="search" />
              </template>
            </q-input>
            <q-select
              v-model="params.status"
              :options="statusOptions"
              option-value="value"
              option-label="label"
              :label="$t('task.filterStatus')"
              @input="listarTarefas"
              class="contact-search"
              style="width: 300px"
              filled
              dense
              clearable
              debounce="500"
            />
            <q-btn
              icon="eva-plus-outline"
              :label="$t('general.addButton')"
              class="generate-button btn-rounded-50"
              :class="{'generate-button-dark' : $q.dark.isActive}"
              @click="tarefaEdicao = {}; modalTarefa = true"
            />
          </div>
        </div>
      </template>
      <template v-slot:body-cell-color="props">
        <q-td class="text-center">
          <div
            class="q-pa-sm rounded-borders"
            :style="`background: ${props.row.color}`"
          >
            {{ props.row.color }}
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon
            size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-eye-outline"
            @click="visualizarTarefa(props.row)"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              {{ $t('task.details.title') }}
            </q-tooltip>
          </q-btn>

          <q-btn
            flat
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            round
            icon="mdi-check-circle-outline"
            @click="concluirTarefa(props.row)"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              {{ $t('task.actions.completeTooltip') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="mdi-content-copy"
            @click="duplicarTarefa(props.row)"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              {{ $t('task.actions.duplicateTooltip') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            v-if="userProfile === 'admin' || userProfile === 'supervisor'"
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-edit-outline"
            @click="editarTarefa(props.row)"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              {{ $t('task.actions.editTooltip') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            v-if="userProfile === 'admin' || userProfile === 'supervisor'"
            flat
            round
            icon="eva-trash-outline"
            @click="deletarTarefa(props.row)"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              {{ $t('task.actions.deleteTooltip') }}
            </q-tooltip>
          </q-btn>
        </q-td>
      </template>
    </q-table>
    <ModalTarefa
      :modalTarefa.sync="modalTarefa"
      :tarefaEdicao.sync="tarefaEdicao"
      @modal-tarefa:criada="tarefaCriada"
      @modal-tarefa:editada="tarefaEditada"
    />

    <q-dialog v-model="modalVisualizacao">
      <q-card style="width: 700px; max-width: 80vw;">
        <q-card-section class="row items-center">
          <div class="text-h6">{{ $t('task.details.title') }}</div>
          <q-space />
          <q-btn
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="close" flat round dense v-close-popup />
        </q-card-section>

        <q-card-section>
          <div class="q-gutter-y-md">
            <div>
              <div class="text-subtitle2">{{ $t('task.details.task') }}</div>
              <div>{{ tarefaSelecionada.name }}</div>
            </div>

            <div>
              <div class="text-subtitle2">{{ $t('task.details.description') }}</div>
              <div>{{ tarefaSelecionada.description }}</div>
            </div>

            <div>
              <div class="text-subtitle2">{{ $t('task.details.status') }}</div>
              <div>
                  {{ formatStatus(tarefaSelecionada.status) }}
              </div>
            </div>

            <div>
              <div class="text-subtitle2">{{ $t('task.details.limitDate') }}</div>
              <div>{{ formatDate(tarefaSelecionada.limitDate) }}</div>
            </div>

            <div>
              <div class="text-subtitle2">{{ $t('task.details.priority') }}</div>
              <div>
                  {{ formatPriority(tarefaSelecionada.priority) }}
              </div>
            </div>

            <div>
              <div class="text-subtitle2">{{ $t('general.comments') }}</div>
              <div>
                {{ tarefaSelecionada.comments }}
              </div>
            </div>
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
import { DeletarTarefa, ListarTarefas, AlterarTarefa, CriarTarefa } from 'src/service/tarefas'
import ModalTarefa from './ModalTarefa'
import { ListarCores, Listarp } from 'src/service/configuracoesgeneral'
export default {
  name: 'Tarefas',
  components: {
    ModalTarefa
  },
  data () {
    return {
      userProfile: 'user',
      modalVisualizacao: false,
      tarefaSelecionada: {},
      statusOptions: [
        { label: this.$t('task.status.delayed'), value: 'delayed' },
        { label: this.$t('task.status.pending'), value: 'pending' },
        { label: this.$t('task.status.finished'), value: 'finished' }
      ],
      params: {
        status: '',
        searchParam: ''
      },
      filter: null,
      tarefaEdicao: {},
      modalTarefa: false,
      premium: true,
      tarefas: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: this.$t('general.id'), field: 'id', align: 'left' },
        { name: 'status', label: 'Status', field: 'status', align: 'left', format: (val) => this.formatStatus(val) },
        { name: 'name', label: this.$t('task.columns.task'), field: 'name', align: 'left' },
        { name: 'description', label: this.$t('task.columns.description'), field: 'description', align: 'left', format: (val) => this.formatComments(val) },
        { name: 'limitDate', label: this.$t('task.columns.limitDate'), field: 'limitDate', align: 'left', format: (val) => this.formatDate(val) },
        { name: 'owner', label: this.$t('task.columns.owner'), field: 'owner', align: 'left' },
        { name: 'priority', label: this.$t('task.columns.priority'), field: 'priority', align: 'left', format: (val) => this.formatPriority(val) },
        { name: 'comments', label: this.$t('general.comments'), field: 'comments', align: 'left', format: (val) => this.formatComments(val) },
        { name: 'acoes', label: this.$t('general.actions'), field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    visualizarTarefa (tarefa) {
      this.tarefaSelecionada = { ...tarefa }
      this.modalVisualizacao = true
    },
    async listarTarefas() {
      this.params.status = this.params.status && this.params.status.value ? this.params.status.value : null

      const { data } = await ListarTarefas({ status: this.params.status })

      let tarefas = []
      if (this.userProfile === 'admin' || this.userProfile === 'supervisor') {
        tarefas = data
      } else {
        tarefas = data.filter((e) => e.owner === localStorage.getItem('username'))
      }

      const statusOrder = { delayed: 1, pending: 2, finished: 3 }
      const priorityOrder = { high: 1, medium: 2, low: 3, none: 4 }

      tarefas.sort((a, b) => {
        if (a.status === 'finished' && b.status !== 'finished') {
          return 1
        }
        if (a.status !== 'finished' && b.status === 'finished') {
          return -1
        }

        const dateA = new Date(a.limitDate)
        const dateB = new Date(b.limitDate)

        if (dateA.getTime() !== dateB.getTime()) {
          return dateA - dateB
        }

        const statusComparison = statusOrder[a.status] - statusOrder[b.status]
        if (statusComparison !== 0) return statusComparison

        return priorityOrder[a.priority] - priorityOrder[b.priority]
      })

      this.tarefas = tarefas
    },
    async listarTarefasFiltro() {
      this.loading = true
      const response = await ListarTarefas()
      const tarefas = response.data
      try {
        const searchTerm = this.params.searchParam.toLowerCase()
        const tarefasFiltradas = tarefas.filter(tarefa => {
          const tarefaAsString = JSON.stringify(tarefa).toLowerCase()
          return tarefaAsString.includes(searchTerm)
        })
        this.LOAD_TAREFAS(tarefasFiltradas)
      } catch (e) {
        this.tarefas = response.data
      }
      this.loading = false
    },

    filtrarTarefa(data) {
      this.tarefas = []
      this.params.searchParam = data
      this.loading = true
      this.listarTarefasFiltro()
      this.loading = false
    },

    LOAD_TAREFAS(tarefasFiltradas) {
      this.tarefas = tarefasFiltradas
    },

    formatComments(comment) {
      if (comment && comment.length > 30) {
        return comment.substring(0, 30) + '...'
      }
      return comment
    },

    formatStatus(value) {
      const statusMap = {
        delayed: this.$t('task.status.delayed'),
        pending: this.$t('task.status.pending'),
        finished: this.$t('task.status.finished')
      }
      return statusMap[value] || value
    },

    formatPriority(value) {
      const priorityMap = {
        high: this.$t('task.priority.options.high'),
        medium: this.$t('task.priority.options.medium'),
        low: this.$t('task.priority.options.low'),
        none: this.$t('task.priority.options.none')
      }
      return priorityMap[value] || value
    },

    formatDate(dateString) {
      const date = new Date(dateString)
      date.setMinutes(date.getMinutes() + date.getTimezoneOffset())
      const day = date.getDate().toString().padStart(2, '0')
      const month = (date.getMonth() + 1).toString().padStart(2, '0')
      const year = date.getFullYear()
      return `${day}-${month}-${year}`
    },

    tarefaCriada(tarefa) {
      const newTarefas = [...this.tarefas]
      newTarefas.push(tarefa)
      this.tarefas = [...newTarefas]
    },

    tarefaEditada(tarefa) {
      const newTarefas = [...this.tarefas]
      const idx = newTarefas.findIndex(f => f.id === tarefa.id)
      if (idx > -1) {
        newTarefas[idx] = tarefa
      }
      this.tarefas = [...newTarefas]
    },

    editarTarefa(tarefa) {
      this.tarefaEdicao = { ...tarefa }
      this.modalTarefa = true
    },

    async concluirTarefa(tarefa) {
      this.loading = true
      try {
        const tarefaAtualizada = {
          ...tarefa,
          status: 'finished'
        }
        const { data } = await AlterarTarefa(tarefaAtualizada)
        this.$emit('modal-tarefa:editada', data)
        this.$q.notify({
          type: 'info',
          progress: true,
          position: 'top',
          textColor: 'black',
          message: this.$t('task.notifications.completed'),
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        window.location.reload()
      } catch (error) {
        console.error(error)
      }
      this.loading = false
    },

    async duplicarTarefa(tarefa) {
      this.loading = true
      try {
        const tarefaAtualizada = {
          ...tarefa
        }
        const { data } = await CriarTarefa(tarefaAtualizada)
        this.$emit('modal-tarefa:criada', data)
        this.$q.notify({
          type: 'info',
          progress: true,
          position: 'top',
          textColor: 'black',
          message: this.$t('task.notifications.duplicated'),
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        window.location.reload()
      } catch (error) {
        console.error(error)
      }
      this.loading = false
    },

    async checarAtrasadas() {
      try {
        const { data } = await ListarTarefas()
        let tarefasAtualizadas = false
        const atualizacoes = data.map(async (tarefa) => {
          const limitDate = new Date(tarefa.limitDate)
          const hoje = new Date()
          if ((limitDate < hoje && tarefa.status !== 'finished')) {
            const tarefaAtualizada = {
              ...tarefa,
              status: 'delayed'
            }
            await AlterarTarefa(tarefaAtualizada)
            tarefasAtualizadas = true
          }
        })
        await Promise.all(atualizacoes)
        if (tarefasAtualizadas) {
          //  window.location.reload();
        }
      } catch (error) {
        console.error('Erro ao checar tarefas atrasadas:', error)
      }
    },
    abrirWhatsApp3() {
      const message = encodeURIComponent(this.$t('general.obterpremium'))
      const url = `https://wa.me/554899416725?text=${message}`
      window.open(url, '_blank')
    },
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    deletarTarefa(tarefa) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('task.confirmations.delete.message', { name: tarefa.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarTarefa(tarefa)
          .then(res => {
            let newTarefas = [...this.tarefas]
            newTarefas = newTarefas.filter(f => f.id !== tarefa.id)
            this.tarefas = [...newTarefas]
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: this.$t('task.notifications.deleted', { name: tarefa.name }),
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
        this.loading = false
      })
    }
  },
  mounted () {
    this.loadColors()
    this.listarTarefas()
    this.checarAtrasadas()
    this.userProfile = localStorage.getItem('profile')
    this.loadVersionp()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

</style>
