<template>
  <q-dialog
    title="Ayuda"
    v-model="dialogVisible"
    width="70%"
    customClass="flowHelp"
  >
    <el-tabs tab-position="left">
      <el-tab-pane label="Cómo agregar">
        <el-divider content-position="left">Cómo agregar</el-divider>
        <div>Mantenga presionado el mouse y arrastre el componente del lado izquierdo al lienzo central, luego suelte el mouse</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo eliminar">
        <el-divider content-position="left">Eliminar página</el-divider>
        <div>
          Haga clic en el nodo que necesita eliminar, luego haga clic en el ícono de eliminar en la esquina superior izquierda
        </div>
        <el-divider content-position="left">Eliminar a través del código</el-divider>
        <pre>this.deleteNode(nodeId)</pre>
      </el-tab-pane>
      <el-tab-pane label="Cómo mover">
        <el-divider content-position="left">Cómo mover</el-divider>
        <div>Mueva el mouse al nodo, cuando el cursor cambie al ícono de arrastrar, presione el mouse y muévalo a la nueva posición, luego suéltelo</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo conectar líneas">
        <el-divider content-position="left">Cómo conectar líneas</el-divider>
        <div>Mueva el mouse al ícono en el lado izquierdo del nodo, cuando el cursor cambie a +, presione el mouse y muévalo a otro nodo, luego suéltelo</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo agregar condiciones">
        <el-divider content-position="left">Cómo agregar condiciones</el-divider>
        <div>Haga clic en la línea de conexión en el lienzo, aparecerá un formulario en el lado derecho de la página, ingrese la nueva condición y haga clic en [Guardar]</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo interactuar con el backend para almacenamiento">
        <el-divider content-position="left">Cómo interactuar con el backend para almacenamiento</el-divider>
        <div>Referencia: https://gitee.com/xiaoka2017/easy-flow-sdk</div>
      </el-tab-pane>
    </el-tabs>
  </q-dialog>
</template>

<script>
export default {
  data () {
    return {
      dialogVisible: false
    }
  },
  components: {},
  methods: {
    init () {
      this.dialogVisible = true
    }
  }
}
</script>

<style>
.flowHelp {
  height: 80%;
}
</style>
