import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'IA' column to the 'Tickets' table
    // Likely a flag indicating if AI is active/used for this ticket.
    await queryInterface.addColumn(
      "Tickets", // Table name
      "IA", // New column name (Note: Capitalization kept from original)
      {
        type: DataTypes.BOOLEAN,
        defaultValue: false, // Default to false
        allowNull: false // Cannot be null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'IA' column from the 'Tickets' table
    await queryInterface.removeColumn(
      "Tickets", // Table name
      "IA" // Column name to remove
    );
  }
};

export = migration;
