import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Define los valores permitidos para las columnas ENUM
    const sendTypeValues = ['campaign', 'chat', 'external', 'bot'];
    const statusValues = ['pending', 'sended', 'received'];

    return Promise.all([
      // Añade la columna 'scheduleDate' (DATE) a 'Messages'
      queryInterface.addColumn('Messages', 'scheduleDate', {
        type: DataTypes.DATE,
        defaultValue: null
      }),
      // Añade la columna 'sendType' (STRING ENUM) a 'Messages'
      queryInterface.addColumn('Messages', 'sendType', {
        type: DataTypes.STRING,
        defaultValue: null,
        values: sendTypeValues // Especifica los valores permitidos
      }),
      // Añade la columna 'status' (STRING ENUM) a 'Messages'
      queryInterface.addColumn('Messages', 'status', {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
        values: statusValues // Especifica los valores permitidos
      }),
      // Añade la columna 'messageId' (STRING) a 'Messages'
      // (Esta columna parece ya existir según otra migración, ¿quizás cambiando tipo o propiedades?)
      // Mantendremos la definición como está en el código original.
      queryInterface.addColumn('Messages', 'messageId', {
         type: DataTypes.STRING,
         allowNull: true, // Permite nulos
         defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina las columnas añadidas
    return Promise.all([
      queryInterface.removeColumn('Messages', 'scheduleDate'),
      queryInterface.removeColumn('Messages', 'sendType'),
      queryInterface.removeColumn('Messages', 'status'),
      queryInterface.removeColumn('Messages', 'messageId')
    ]);
  }
};