import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'groupsIgnore' column to the 'Whatsapps' table
    // Flag to ignore groups for this WhatsApp connection.
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "groupsIgnore", // New column name
      {
        type: DataTypes.BOOLEAN,
        allowNull: false, // Cannot be null
        defaultValue: false // Default to not ignoring groups
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'groupsIgnore' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      "Whatsapps", // Table name
      "groupsIgnore" // Column name to remove
    );
  }
};

export = migration;
