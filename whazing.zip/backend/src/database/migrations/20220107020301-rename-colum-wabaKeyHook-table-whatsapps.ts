// --- START OF FILE 20220107020301-rename-colum-wabaKeyHook-table-whatsapps.ts ---

"use strict";
import { QueryInterface, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Whatsapps";
    const oldColumnName = "wabaKeyHook"; // 'wabaKeyHoo' + 'k'
    const newColumnName = "tokenHook";
    await Promise.all([
      queryInterface.renameColumn(tableName, oldColumnName, newColumnName)
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Whatsapps";
    const newColumnName = "tokenHook";
    const oldColumnName = "wabaKeyHook"; // 'wabaKeyHoo' + 'k'
    await Promise.all([
      queryInterface.renameColumn(tableName, newColumnName, oldColumnName)
    ]);
  }
};

export default migration;

// --- END OF FILE 20220107020301-rename-colum-wabaKeyHook-table-whatsapps.ts ---
