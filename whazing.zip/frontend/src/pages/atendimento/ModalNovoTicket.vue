<template>
  <q-dialog
    :value="modalNovoTicket"
    persistent
    @hide="fecharModal"
  >
    <q-card
      class="q-pa-md"
      style="width: 500px"
    >
      <q-card-section>
        <div class="text-h6">{{ $t('modalNovoTicket.CriarTicket') }}</div>
      </q-card-section>
      <q-card-section>
        <q-select
          ref="selectAutoCompleteContato"
          autofocus
          square
          outlined
          filled
          hide-dropdown-icon
          :loading="loading"
          v-model="contatoSelecionado"
          :options="contatos"
          input-debounce="700"
          @filter="localizarContato"
          use-input
          hide-selected
          fill-input
          option-label="name"
          option-value="id"
          :label="$t('modalNovoTicket.LocalizarContato')"
          :hint="$t('modalNovoTicket.DigiteMinimoDuasLetras')"
        >
          <template v-slot:before-options>
            <q-btn
              color="primary"
              no-caps
              padding
              ripple
              class="full-width no-border-radius"
              outline
              icon="add"
              :label="$t('modalNovoTicket.AdicionarContato')"
              @click="modalContato = true"
            />

          </template>
          <template v-slot:option="scope">
            <q-item
              v-bind="scope.itemProps"
              v-on="scope.itemEvents"
              v-if="scope.opt.name"
            >
              <q-item-section avatar>
                <q-avatar size="32px">
                  <img v-if="scope.opt.profilePicUrl" :src="scope.opt.profilePicUrl" />
                  <q-icon
                    v-else
                    name="mdi-account"
                    size="1.5em"
                    color="grey-5"
                  />
                </q-avatar>
              </q-item-section>
              <q-item-section>
                <q-item-label> {{ scope.opt.name }}</q-item-label>
                <q-item-label caption v-if="!HideNumber || (userProfile === 'admin' || userProfile === 'supervisor')">{{ scope.opt.number }}</q-item-label>
              </q-item-section>
            </q-item>
          </template>
        </q-select>
      </q-card-section>
      <q-card-actions
        align="right"
        class="q-pr-md"
      >
        <q-btn
          :label="$t('modalNovoTicket.Sair')"
          color="negative"
          v-close-popup
          class="q-px-md q-mr-lg"
        />
        <q-btn
          :label="$t('general.salvar')"
          class="q-px-md "
          color="primary"
          @click="criarTicket"
        />
      </q-card-actions>
    </q-card>
    <ContatoModal
      :modalContato.sync="modalContato"
      @contatoModal:contato-criado="contatoCriadoNotoTicket"
    />
  </q-dialog>

</template>

<script>
const UserQueues = JSON.parse(localStorage.getItem('queues'))
import { ListarContatos } from 'src/service/contatos'
import { CriarTicketNew } from 'src/service/tickets'
import ContatoModal from 'src/pages/contatos/ContatoModal'
import { ListarCanalUsuario } from 'src/service/user'

export default {
  name: 'ModalNovoTicket',
  components: { ContatoModal },
  props: {
    modalNovoTicket: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      ticket: {},
      contatoSelecionado: null,
      contatos: [],
      modalContato: false,
      loading: false,
      canais: [],
      canalSelecionado: null,
      tipoCanal: 'whatsapp',
      HideNumber: null,
      userProfile: 'user',
      filaSelecionada: null
    }
  },
  computed: {
    cUserQueues () {
      return UserQueues
    }
  },
  methods: {
    fecharModal () {
      this.ticket = {}
      this.contatoSelecionado = null
      this.$emit('update:modalNovoTicket', false)
    },
    async localizarContato (search, update, abort) {
      if (search.length < 2) {
        if (this.contatos.length) update(() => { this.contatos = [...this.contatos] })
        abort()
        return
      }
      this.loading = true
      const { data } = await ListarContatos({
        searchParam: search
      })

      update(() => {
        if (data.contacts.length) {
          this.contatos = data.contacts
        } else {
          this.contatos = [{}]
          // this.$refs.selectAutoCompleteContato.toggleOption({}, true)
        }
      })
      this.loading = false
    },
    contatoCriadoNotoTicket (contato) {
      this.contatoSelecionado = contato
      this.criarTicket()
    },
    async criarTicket() {
      if (!this.contatoSelecionado.id) return

      this.loading = true

      try {
        const { data: canais } = await ListarCanalUsuario('whatsapp')

        if (canais.length === 0) {
          this.$q.notify({
            message: this.$t('newticket.noChannelsAvailable'),
            type: 'negative',
            position: 'top'
          })
          return
        }

        // Formatar os canais para o diálogo
        const itens = canais.map(canal => ({
          label: canal.name,
          value: canal.id
        }))

        let channelId = null
        let queueId = null

        // Primeiro diálogo para selecionar o canal
        this.$q.dialog({
          title: this.$t('contacts.newticket.contact', { name: this.contatoSelecionado.name }),
          message: this.$t('modalNovoTicket.SelecioneCanal'),
          options: {
            type: 'radio',
            model: channelId,
            isValid: v => !!v,
            items: itens
          },
          ok: {
            push: true,
            color: 'positive',
            label: this.$t('modalNovoTicket.continuar')
          },
          cancel: {
            push: true,
            label: this.$t('general.cancelar'),
            color: 'negative'
          },
          persistent: true
        }).onOk(async selectedChannelId => {
          if (!selectedChannelId) return
          channelId = selectedChannelId

          // Segundo diálogo para selecionar a fila
          this.$q.dialog({
            title: this.$t('contacts.newticket.contact', { name: this.contatoSelecionado.name }),
            message: this.$t('modalNovoTicket.selecionefila'),
            options: {
              type: 'radio',
              model: queueId,
              isValid: v => !!v,
              items: this.cUserQueues.map(queue => ({
                label: queue.queue,
                value: queue.id
              }))
            },
            ok: {
              push: true,
              color: 'positive',
              label: this.$t('general.Iniciar')
            },
            cancel: {
              push: true,
              label: this.$t('general.cancelar'),
              color: 'negative'
            },
            persistent: true
          }).onOk(async selectedQueueId => {
            if (!selectedQueueId) return
            queueId = selectedQueueId

            this.loading = true
            try {
              const { data: ticket } = await CriarTicketNew({
                contactId: this.contatoSelecionado.id,
                isActiveDemand: true,
                channel: 'whatsapp',
                channelId: channelId,
                queueId: queueId,
                status: 'open'
              })

              await this.$store.commit('SET_HAS_MORE', true)
              await this.$store.dispatch('AbrirChatMensagens', ticket)
              this.$q.notify({
                message: this.$t('contacts.newticket.ServiceStarted', { name: ticket.contact.name, ticketid: ticket.id }),
                type: 'positive',
                position: 'top',
                progress: true,
                actions: [{
                  icon: 'close',
                  round: true,
                  color: 'white'
                }]
              })
              this.fecharModal()

              this.$router.push({ name: 'chat', params: { ticketId: ticket.id } })
            } catch (error) {
              console.log('error', error)
              this.loading = false

              // Tratamento mais detalhado para o erro 409
              if (error.status === 409) {
                console.log('Erro 409:', error)

                // Verifica se é o caso específico de ticket já existente
                const errorMessage = error?.data?.message || this.$t('general.Anunknownerrorhasoccurred')

                if (errorMessage === this.$t('general.Aticketalreadyexists') && error.data?.ticket) {
                  // Redirecionar para o ticket existente
                  this.abrirAtendimentoExistente(this.contatoSelecionado, error.data.ticket)
                  this.fecharModal()
                } else {
                  // Para outros erros 409, mostrar um diálogo e notificação
                  // Use setTimeout para garantir que o diálogo apareça após o modal atual
                  setTimeout(() => {
                    this.$q.dialog({
                      title: this.$t('general.Attention'),
                      message: errorMessage,
                      ok: {
                        label: this.$t('general.close'),
                        color: 'primary',
                        push: true
                      },
                      persistent: true
                    })

                    this.$q.notify({
                      message: errorMessage,
                      type: 'negative',
                      position: 'top',
                      progress: true,
                      actions: [{
                        icon: 'close',
                        round: true,
                        color: 'white'
                      }]
                    })
                  }, 100)
                }
              } else {
                // Para outros tipos de erro, use a função de notificação existente
                this.$notificarErro(this.$t('modalNovoTicket.OcorreuErro'), error)
              }
            } finally {
              this.loading = false
              this.fecharModalCanal()
            }
          })
        })
      } catch (error) {
        this.loading = false
        this.$notificarErro(this.$t('modalNovoTicket.ErroAoListarCanais'), error)
      } finally {
        this.loading = false
      }
    },
    async listarConfiguracoes() {
      const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))
      const HideNumberConfig = configuracoes?.find(c => c.key === 'HideNumber')
      if (HideNumberConfig) {
        this.HideNumber = HideNumberConfig.value === 'enabled'
      }
    },
    abrirChatContato (ticket) {
      // caso esteja em um tamanho mobile, fechar a drawer dos contatos
      if (this.$q.screen.lt.md && ticket.status !== 'pending') {
        this.$root.$emit('infor-cabecalo-chat:acao-menu')
      }
      if (!(ticket.status !== 'pending' && (ticket.id !== this.$store.getters.ticketFocado.id || this.$route.name !== 'chat'))) return
      this.$store.commit('SET_HAS_MORE', true)
      this.$store.dispatch('AbrirChatMensagens', ticket)
    },
    abrirAtendimentoExistente (contato, ticket) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('contacts.newticket.ongoingservice', { name: contato.name, ticketid: ticket.id }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(async () => {
        try {
          this.abrirChatContato(ticket)
        } catch (error) {
          this.$notificarErro(
            this.$t('modalNovoTicket.ErroAtualizarToken'),
            error
          )
        }
      })
    }
  },
  mounted () {
    this.listarConfiguracoes()
    this.userProfile = localStorage.getItem('profile')
  },
  destroyed () {
    this.contatoSelecionado = null
  }
}
</script>

<style lang="scss" scoped>
</style>
