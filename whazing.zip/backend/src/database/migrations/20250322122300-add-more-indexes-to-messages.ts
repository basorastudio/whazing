import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Messages";
    // Add index on [tenantId, ticketId]
    await queryInterface.addIndex(tableName, ["tenantId", "ticketId"], {
      name: "idx_messages_tenantid_ticketid" // Explicit index name
    });
    // Add index on [tenantId, contactId]
    await queryInterface.addIndex(tableName, ["tenantId", "contactId"], {
      name: "idx_messages_tenantid_contactid" // Explicit index name
    });
    // Add index on [tenantId, whatsappId]
    await queryInterface.addIndex(tableName, ["tenantId", "whatsappId"], {
      name: "idx_messages_tenantid_whatsappid" // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Messages";
    // Remove indexes in reverse order
    await queryInterface.removeIndex(
      tableName,
      "idx_messages_tenantid_whatsappid"
    );
    await queryInterface.removeIndex(
      tableName,
      "idx_messages_tenantid_contactid"
    );
    await queryInterface.removeIndex(
      tableName,
      "idx_messages_tenantid_ticketid"
    );
  }
};

export = migration;
