<template>
  <q-dialog
    persistent
    :value="modalWavoipUsuario"
    @hide="fecharModal"
    @show="abrirModal"
  >
    <q-card class="q-pa-lg container-rounded-10">
      <q-card-section class="q-pa-none">
        <div class="full-width text-h6 row col font-family-main q-pa-sm">{{ $t('usuarios.wavoipUsuario') }}</div>
        <div
          style="font-size: 1em"
          class="text-caption text-bold row col q-px-sm q-pt-sm"
        >{{ $t('usuarios.nome') }} {{ usuarioSelecionado.name }}</div>
        <div
          style="font-size: 1em"
          class="text-caption text-bold row col q-px-sm"
        >{{ $t('usuarios.email') }} {{ usuarioSelecionado.email }}</div>
        <q-separator spaced />
      </q-card-section>
      <q-card-section>
        <template v-for="canal in filteredWhatsapps">
          <div
            class="row col"
            :key="canal.id"
          >
            <q-checkbox
              :disable="!canal.isActive"
              v-model="canaisUsuario"
              :label="`${canal.name} ${!canal.isActive ? $t('usuarios.inativo') : ''}`"
              :val="canal.id"
            />
          </div>
        </template>
      </q-card-section>
      <q-card-actions align="right">
        <q-btn
          :label="$t('general.cancelar')"
          class="q-px-md q-mr-sm btn-rounded-50"
          color="negative"
          v-close-popup
        />
        <q-btn
          :label="$t('general.salvar')"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          icon="eva-save-outline"
          @click="handleCanalUsuario"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { UpdateUsuarios } from 'src/service/user'
import { mapGetters } from 'vuex'

export default {
  name: 'ModalCanalUsuario',
  props: {
    modalWavoipUsuario: {
      type: Boolean,
      default: false
    },
    usuarioSelecionado: {
      type: Object,
      default: () => { return { id: null } }
    }
  },
  data () {
    return {
      canaisUsuario: [],
      originalWhatsapps: null
    }
  },
  computed: {
    ...mapGetters([
      'whatsapps'
    ]),
    filteredWhatsapps () {
      return this.whatsapps.filter(canal =>
        canal.type === 'whatsapp' && canal.wavoip !== null
      )
    }
  },
  methods: {
    abrirModal () {
      if (this.usuarioSelecionado.id) {
        this.originalWhatsapps = this.usuarioSelecionado.whatsapps || []

        this.canaisUsuario = this.usuarioSelecionado.wavoipUsers
          ? [...this.usuarioSelecionado.wavoipUsers.map(w => w.whatsappId)]
          : []
      }
    },
    fecharModal () {
      this.$emit('update:usuarioSelecionado', {})
      this.$emit('update:modalWavoipUsuario', false)
    },
    async handleCanalUsuario () {
      const whatsappsIds = this.originalWhatsapps.map(w => w.id)

      const req = {
        ...this.usuarioSelecionado,
        whatsapps: whatsappsIds,
        wavoipUsers: [...this.canaisUsuario.map(id => ({ whatsappId: id }))]
      }

      const { data } = await UpdateUsuarios(req.id, req)
      this.$emit('modalWavoipUsuario:sucesso', data)
      this.$q.notify({
        type: 'positive',
        progress: true,
        position: 'top',
        message: this.$t('usuarios.sucessoEditarWavoip'),
        actions: [{
          icon: 'close',
          round: true,
          color: 'white'
        }]
      })
      this.fecharModal()
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
