// Original: CheckSettingsGeneral.js
// Deobfuscated, converted to TS, and translated

'use strict';

import SettingsGeneral from '../models/SettingsGeneral'; // Asumiendo exportación predeterminada

const CheckSettingsGeneral = async (
    key: string,
    defaultValue: string | null = null
): Promise<string | null> => {

  const setting = await SettingsGeneral.findOne({
    where: { key: key }
  });

  // Si no se encuentra y no hay valor por defecto, retornar null
  if (!setting && !defaultValue) {
    return null;
  }

  // Retorna el valor encontrado o el valor por defecto
  return setting?.value || defaultValue;
};

export default CheckSettingsGeneral;