// Original: ConvertMp3ToMp4.js
// Deobfuscated, converted to TS, and translated

'use strict';

import { Worker, isMainThread, parentPort, workerData } from 'worker_threads';
import ffmpeg from 'fluent-ffmpeg';
import { path as ffmpegPath } from '@ffmpeg-installer/ffmpeg'; // Obtener path directamente
import fs from 'fs';
import { logger } from '../utils/logger';

// Define el tipo para los datos pasados al worker
interface WorkerData {
    inputPath: string;
    outputPath: string;
}

// Define el tipo para los mensajes enviados desde el worker
type WorkerMessage =
  | { type: 'progress'; data: number }
  | { type: 'complete' }
  | { type: 'error'; error: string };


// Función que se ejecuta en el worker thread
const workerConversion = (inputPath: string, outputPath: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Configura la ruta del ejecutable de ffmpeg
    ffmpeg.setFfmpegPath(ffmpegPath);

    // Verifica si el archivo de entrada existe
    if (!fs.existsSync(inputPath)) {
      // Traducido: Archivo de entrada no existe
      const errorMsg = `Input file does not exist: ${inputPath}`;
       if (parentPort) {
           parentPort.postMessage({ type: 'error', error: errorMsg } as WorkerMessage);
       }
      return reject(new Error(errorMsg));
    }

    ffmpeg(inputPath)
      .inputFormat('mp3') // Especifica formato de entrada
      .outputFormat('mp4') // Especifica formato de salida
      .output(outputPath)
      .on('start', (commandLine: string) => {
          // Traducido: Comando Ffmpeg generado
        logger.info(`Spawned Ffmpeg with command: ${commandLine}`);
         if (parentPort) {
            // No enviar mensaje de 'start' necesariamente, progreso es más útil
         }
      })
      .on('progress', (progress: { percent?: number }) => {
        if (progress.percent) {
          const percent = Math.round(progress.percent);
           // Traducido: Procesando
          logger.info(`Processing: ${percent}% done`);
           if (parentPort) {
               parentPort.postMessage({ type: 'progress', data: percent } as WorkerMessage);
           }
        }
      })
      .on('end', () => {
         // Traducido: Transcodificación de video exitosa
        logger.info('Video Transcoding succeeded !');
         if (parentPort) {
             parentPort.postMessage({ type: 'complete' } as WorkerMessage);
         }
        resolve();
      })
      .on('error', (err: Error) => {
         // Traducido: Error en la codificación
        logger.error(`Encoding Error: ${err.message}`);
         if (parentPort) {
             parentPort.postMessage({ type: 'error', error: err.message } as WorkerMessage);
         }
        reject(err);
      })
      .run();
  });
};

// Función principal que crea el worker o ejecuta la conversión directamente
export const convertMp3ToMp4 = (inputPath: string, outputPath: string): Promise<void> => {
  if (isMainThread) {
    // Si está en el hilo principal, crea un nuevo worker
    return new Promise((resolve, reject) => {
      const worker = new Worker(__filename, {
        workerData: { inputPath, outputPath } as WorkerData
      });

      worker.on('message', (message: WorkerMessage) => {
        switch (message.type) {
          case 'progress':
             // Traducido: Procesando desde worker
            logger.info(`Worker Processing: ${message.data}% done`);
            // Podrías emitir este progreso si es necesario
            break;
          case 'complete':
             // Traducido: Conversión completada por el worker
            logger.info('Worker conversion complete');
            resolve();
            break;
          case 'error':
             // Traducido: Error del worker
            logger.error(`Worker Error: ${message.error}`);
            reject(new Error(message.error));
            break;
        }
      });

      worker.on('error', (err) => {
         // Traducido: Error fatal del worker
        logger.error(`Fatal worker error: ${err.message}`);
        reject(err);
      });

      worker.on('exit', (code) => {
        if (code !== 0) {
           // Traducido: Worker parado con código de salida
          const errorMsg = `Worker stopped with exit code ${code}`;
          logger.error(errorMsg);
          reject(new Error(errorMsg));
        }
        // 'complete' ya debería haber llamado a resolve si code es 0
      });
    });
  } else {
    // Si está en el worker thread, ejecuta la conversión
    const { inputPath: workerInput, outputPath: workerOutput } = workerData as WorkerData;
    workerConversion(workerInput, workerOutput).catch(error => {
       // Asegurarse de que el error se maneje y se envíe al hilo principal si es posible
       if (parentPort) {
           parentPort.postMessage({ type: 'error', error: error.message } as WorkerMessage);
       } else {
           // Si no hay parentPort, simplemente registrar el error
           logger.error('Error in worker thread without parentPort:', error);
       }
       // Considerar salir del proceso del worker con error si la recuperación no es posible
       // process.exit(1);
    });
    // No retornar la promesa aquí directamente, el worker comunica vía postMessage
    return Promise.resolve(); // Devolver una promesa resuelta para satisfacer el tipo
  }
};

// Ejecuta la conversión si es un worker thread (esto se mantiene del JS original)
if (!isMainThread) {
    const { inputPath: workerInput, outputPath: workerOutput } = workerData as WorkerData;
    workerConversion(workerInput, workerOutput)
        .then(() => {
            // El mensaje 'complete' se envía dentro de workerConversion
        })
        .catch(error => {
             // Traducido: Error en la conversión del worker
            logger.error(`Error in worker conversion: ${error.message}`);
             if (parentPort) {
                 parentPort.postMessage({ type: 'error', error: error.message } as WorkerMessage);
             }
            // process.exit(1); // Considerar salir con error
        });
}