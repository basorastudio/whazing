class FormatMask {
  setPhoneFormatMask(phoneToFormat) {
    if (!phoneToFormat || phoneToFormat.length < 10) {
      return
    }

    const number = ('' + phoneToFormat).replace(/\D/g, '')

    // Formato para números dominicanos (10 dígitos: código de área de 3 dígitos + 7 dígitos)
    if (number.length === 10) {
      const phoneNumberFormatted = number.match(/^(\d{3})(\d{3})(\d{4})$/)
      if (!phoneNumberFormatted) return null
      return (
        '+1' +
        ' (' +
        phoneNumberFormatted[1] +
        ') ' +
        phoneNumberFormatted[2] +
        '-' +
        phoneNumberFormatted[3]
      )
    } 
    // Para números con código de país incluido (1 + 10 dígitos)
    else if (number.length === 11 && number.startsWith('1')) {
      const phoneNumberFormatted = number.match(/^(\d{1})(\d{3})(\d{3})(\d{4})$/)
      if (!phoneNumberFormatted) return null
      return (
        '+' +
        phoneNumberFormatted[1] +
        ' (' +
        phoneNumberFormatted[2] +
        ') ' +
        phoneNumberFormatted[3] +
        '-' +
        phoneNumberFormatted[4]
      )
    }

    return null
  }

  removeMask(number) {
    const filterNumber = number.replace(/\D/g, '')
    return filterNumber
  }

  maskPhonePattern(phoneNumber) {
    // Patrón para números dominicanos
    return '+1 (809) 999-9999'
  }
}

export { FormatMask }

const formatSerializedId = (serializedId) => {
  const formatMask = new FormatMask()
  const number = serializedId?.replace('@c.us', '')

  return formatMask.setPhoneFormatMask(number)?.replace('+1', '🇩🇴')
}

export default formatSerializedId
