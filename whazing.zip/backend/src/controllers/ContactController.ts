// --- START OF FILE ContactController.ts ---

import { Request, Response } from "express";
import * as Yup from "yup";
import { getIO } from "../libs/socket"; // Asumiendo ruta correcta
import { getWbot } from "../libs/wbot"; // Asumiendo ruta correcta
import Contact from "../models/Contact"; // Asumiendo ruta correcta
import Whatsapp from "../models/Whatsapp"; // Asumiendo ruta correcta
import AppError from "../errors/AppError"; // Asumiendo ruta correcta
import ListContactsService from "../services/ContactServices/ListContactsService";
import CreateContactService from "../services/ContactServices/CreateContactService";
import ShowContactService from "../services/ContactServices/ShowContactService";
import UpdateContactService from "../services/ContactServices/UpdateContactService";
import DeleteContactService from "../services/ContactServices/DeleteContactService";
import UpdateContactTagsService from "../services/ContactServices/UpdateContactTagsService";
import UpdateContactWalletsService from "../services/ContactServices/UpdateContactWalletsService";
import GetProfilePicUrl from "../services/WbotServices/GetProfilePicUrl";
import ImportContactsService from "../services/WbotServices/ImportContactsService";
import { ImportFileContactsService } from "../services/ContactServices/ImportFileContactsService"; // Exportación nombrada
import { logger } from "../utils/logger"; // Asumiendo ruta correcta
import { head } from "lodash"; // Importación nombrada
import xlsx from "xlsx";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";

// Interfaces
interface RequestUser {
  tenantId: string | number;
  id: string | number; // userId
  profile?: string;
}

interface IndexQuery {
  searchParam?: string;
  searchParamAdicional?: string;
  pageNumber?: string;
  tagId?: string;
  walletId?: string; // Podría ser un objeto, ajustar si es necesario
}

interface IndexRequest extends Request {
  user: RequestUser;
  query: IndexQuery;
}

interface SyncRequest extends Request {
  user: RequestUser;
  query: {
    // query en lugar de params para whatsappId
    whatsappId: string;
  };
}

interface StoreRequestBody {
  name: string;
  number: string;
  email?: string;
  // ... otros campos posibles como extraInfo
}

interface StoreRequest extends Request {
  user: RequestUser;
  body: StoreRequestBody;
}

interface ShowRequestParams {
  contactId: string;
}

interface ShowRequest extends Request {
  user: RequestUser;
  params: ShowRequestParams;
}

interface UpdateRequestBody {
  name?: string;
  number?: string;
  email?: string;
  extraInfo?: any[]; // Asumiendo array de objetos
}

interface UpdateRequestParams {
  contactId: string;
}

interface UpdateRequest extends Request {
  user: RequestUser;
  body: UpdateRequestBody;
  params: UpdateRequestParams;
}

interface DeleteRequestParams {
  contactId: string;
}

interface DeleteRequest extends Request {
  user: RequestUser;
  params: DeleteRequestParams;
}

interface UpdateTagsRequestBody {
  tags: (string | number)[]; // Asumiendo array de IDs
}

interface UpdateTagsRequestParams {
  contactId: string;
}

interface UpdateTagsRequest extends Request {
  user: RequestUser;
  body: UpdateTagsRequestBody;
  params: UpdateTagsRequestParams;
}

interface UpdateWalletRequestBody {
  wallets: (string | number)[]; // Asumiendo array de IDs
}

interface UpdateWalletRequestParams {
  contactId: string;
}

interface UpdateWalletRequest extends Request {
  user: RequestUser;
  body: UpdateWalletRequestBody;
  params: UpdateWalletRequestParams;
}

// Tipado para req.file (Multer)
interface MulterFile {
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  size: number;
  destination: string;
  filename: string;
  path: string;
  buffer: Buffer;
}

interface UploadRequestBody {
  tags?: string; // IDs separados por coma
  wallets?: string; // IDs separados por coma
  crm?: string; // IDs separados por coma (asumiendo)
}

interface UploadRequest extends Request {
  user: RequestUser;
  file: MulterFile; // Archivo es requerido
  body: UploadRequestBody;
}

interface ExportRequest extends Request {
  user: RequestUser;
}

// Esquemas de validación
const storeContactSchema = Yup.object().shape({
  name: Yup.string().required("El nombre es obligatorio."), // Traducido
  number: Yup.string()
    .required("El número es obligatorio.") // Traducido
    .matches(/^\d+$/, "Número inválido: solo se permiten dígitos.") // Traducido
});

const updateContactSchema = Yup.object().shape({
  name: Yup.string(),
  number: Yup.string()
    .matches(/^\d+$/, "Número inválido: solo se permiten dígitos.") // Traducido
    .nullable()
    .optional(), // Permite que el número no se envíe o sea null/undefined
  email: Yup.string()
    .email("Correo electrónico inválido.")
    .nullable()
    .optional() // Traducido
});

/**
 * @description Lista los contactos con paginación y filtros.
 * @param {IndexRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const index = async (
  req: IndexRequest,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId, profile } = req.user;
  const { searchParam, searchParamAdicional, pageNumber, tagId, walletId } =
    req.query;

  // Asegurarse de que walletId sea un número o undefined
  // const numericWalletId = walletId ? Number(walletId.id) : undefined; // Asumiendo que walletId es un objeto con 'id'
  const numericWalletId = walletId ? Number(walletId) : undefined; // Asumiendo que walletId es solo el ID

  const { contacts, count, hasMore } = await ListContactsService({
    searchParam,
    searchParamAdicional,
    pageNumber,
    tagId: tagId ? tagId.split(",").map(Number) : undefined,
    tenantId: Number(tenantId),
    profile,
    userId: Number(userId),
    walletId: numericWalletId
  });

  return res.json({ contacts, count, hasMore });
};

/**
 * @description Sincroniza los contactos de un Whatsapp específico.
 * @param {SyncRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const sync = async (
  req: SyncRequest,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const { whatsappId } = req.query; // Desde query

  if (!whatsappId) {
    throw new AppError("El ID de WhatsApp es obligatorio.", 400); // Traducido
  }

  await ImportContactsService(Number(tenantId), Number(whatsappId));

  return res.status(200).json({ message: "Contactos importados" }); // Traducido
};

/**
 * @description Almacena un nuevo contacto.
 * @param {StoreRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const store = async (
  req: StoreRequest,
  res: Response
): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  const newContact: StoreRequestBody = req.body;
  newContact.number = newContact.number
    .replace("-", "")
    .replace(" ", "")
    .replace("+", "");

  try {
    await storeContactSchema.validate(newContact);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  // Buscar si el contacto ya existe por número y tenantId
  const contactExists = await Contact.findOne({
    where: { number: newContact.number, tenantId }
  });

  if (contactExists) {
    // Podríamos devolver el contacto existente o un error específico
    // throw new AppError('Este número de contacto ya existe.', 409); // HTTP 409 Conflict - Traducido
    return res.status(200).json(contactExists); // O devolver el existente si esa es la lógica deseada
  }

  // Intentar obtener la imagen de perfil si hay un WhatsApp conectado
  let profilePicUrl: string | null = null;
  const defaultWhatsapp = await Whatsapp.findOne({
    where: { status: "CONNECTED", tenantId, isDefault: true } // Asumiendo 'CONNECTED' como estado válido
  });

  if (defaultWhatsapp) {
    try {
      const wbot = getWbot(defaultWhatsapp.id);
      // Normalizar número para la búsqueda en WhatsApp
      const whatsappNumber = `${newContact.number}@s.whatsapp.net`;
      const [result] = await wbot.onWhatsApp(whatsappNumber);

      if (result?.exists) {
        newContact.number = result.jid.split("@")[0]; // Actualizar con el número validado
        profilePicUrl = await GetProfilePicUrl(newContact.number, tenantId);
      } else {
        // Validar número internacional si no se encuentra directamente
        if (
          (newContact.number.length > 11 &&
            newContact.number.startsWith("55")) ||
          (newContact.number.length > 12 && /^[2-9]/.test(newContact.number))
        ) {
          const internationalPrefixLength =
            newContact.number.length > 12 ? 4 : 2; // 55XX o 55
          const nationalNumber = `${newContact.number.substring(0, internationalPrefixLength)}9${newContact.number.substring(internationalPrefixLength + 1)}`;
          const internationalJid = `${nationalNumber}@s.whatsapp.net`;

          const [interResult] = await wbot.onWhatsApp(internationalJid);
          if (interResult?.exists) {
            newContact.number = nationalNumber; // Actualizar al número con el 9 añadido
            profilePicUrl = await GetProfilePicUrl(newContact.number, tenantId);
          } else {
            logger.warn(
              `Número ${newContact.number} no encontrado en WhatsApp tras intentar añadir el 9.`
            ); // Traducido
            // Considerar si lanzar error o continuar sin foto
            // throw new AppError('Número no encontrado en WhatsApp.', 404); // Traducido
          }
        } else {
          logger.warn(`Número ${newContact.number} no encontrado en WhatsApp.`); // Traducido
          // Considerar si lanzar error o continuar sin foto
          // throw new AppError('Número no encontrado en WhatsApp.', 404); // Traducido
        }
      }
    } catch (err) {
      logger.error(
        `Error al verificar el número ${newContact.number} o al obtener la foto de perfil:`,
        err
      ); // Traducido
      // No lanzar error aquí, permitir crear el contacto sin foto
    }
  } else {
    logger.warn(
      `No hay un WhatsApp conectado por defecto para el tenant ${tenantId} para verificar el número.`
    ); // Traducido
  }

  const contact = await CreateContactService({
    ...newContact,
    profilePicUrl,
    tenantId
  });

  // Emitir evento de socket si es necesario
  // const io = getIO();
  // io.to(tenantId.toString()).emit(`contact-${tenantId}`, {
  //     action: 'create',
  //     contact: contact
  // });

  return res.status(200).json(contact); // Devuelve 200 según el código original, aunque 201 sería más apropiado
};

/**
 * @description Muestra los detalles de un contacto específico.
 * @param {ShowRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const show = async (
  req: ShowRequest,
  res: Response
): Promise<Response> => {
  const { contactId } = req.params;
  const { tenantId } = req.user;

  const contact = await ShowContactService({
    id: contactId,
    tenantId: Number(tenantId)
  });

  return res.status(200).json(contact); // HTTP 200 OK
};

/**
 * @description Actualiza un contacto existente.
 * @param {UpdateRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const update = async (
  req: UpdateRequest,
  res: Response
): Promise<Response> => {
  const contactData: UpdateRequestBody = req.body;
  const { tenantId } = req.user;
  const { contactId } = req.params;

  try {
    await updateContactSchema.validate(contactData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  // Filtrar información extra si es necesario (como en el original)
  // if (contactData.extraInfo) {
  //    contactData.extraInfo = contactData.extraInfo.filter(info => info.name && info.value);
  // }

  // Actualizar foto de perfil si el número cambia o si no tenía
  const contact = await ShowContactService({
    id: contactId,
    tenantId: Number(tenantId)
  });
  let profilePicUrl = contact.profilePicUrl; // Mantener la actual por defecto

  // Verificar si el número cambió o si no tenía foto y ahora hay WhatsApp conectado
  // (La lógica original parece obtener la foto siempre que haya un WhatsApp)
  const defaultWhatsapp = await Whatsapp.findOne({
    where: { status: "CONNECTED", tenantId: Number(tenantId), isDefault: true }
  });

  if (
    defaultWhatsapp &&
    contactData.number &&
    contactData.number !== contact.number
  ) {
    try {
      logger.info(
        `Actualizando foto de perfil para el contacto ${contactId} debido al cambio de número a ${contactData.number}`
      ); // Traducido
      profilePicUrl = await GetProfilePicUrl(
        contactData.number,
        Number(tenantId)
      );
    } catch (err) {
      logger.error(
        `Error al obtener la nueva foto de perfil para ${contactData.number}:`,
        err
      ); // Traducido
      // Mantener la foto anterior o poner null si se prefiere
    }
  } else if (defaultWhatsapp && !profilePicUrl && contact.number) {
    try {
      logger.info(
        `Intentando obtener foto de perfil para el contacto ${contactId} (número: ${contact.number}) ya que no tenía y hay WhatsApp conectado.`
      ); // Traducido
      profilePicUrl = await GetProfilePicUrl(contact.number, Number(tenantId));
    } catch (err) {
      logger.error(
        `Error al obtener la foto de perfil para ${contact.number}:`,
        err
      ); // Traducido
    }
  }

  const updatedContact = await UpdateContactService({
    contactData: { ...contactData, profilePicUrl }, // Incluir la URL de la foto
    contactId: contactId,
    tenantId: Number(tenantId)
  });

  // Emitir evento de socket si es necesario
  // const io = getIO();
  // io.to(tenantId.toString()).emit(`contact-${tenantId}`, {
  //     action: 'update',
  //     contact: updatedContact
  // });

  return res.status(200).json(updatedContact); // HTTP 200 OK
};

/**
 * @description Elimina un contacto.
 * @param {DeleteRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const remove = async (
  req: DeleteRequest,
  res: Response
): Promise<Response> => {
  const { contactId } = req.params;
  const { tenantId } = req.user;

  await DeleteContactService({ id: contactId, tenantId: Number(tenantId) });

  // Emitir evento de socket si es necesario
  // const io = getIO();
  // io.to(tenantId.toString()).emit(`contact-${tenantId}`, {
  //     action: 'delete',
  //     contactId: contactId
  // });

  return res.status(200).json({ message: "Contacto eliminado" }); // HTTP 200 OK - Traducido
};

/**
 * @description Actualiza las etiquetas de un contacto.
 * @param {UpdateTagsRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const updateContactTags = async (
  req: UpdateTagsRequest,
  res: Response
): Promise<Response> => {
  const { tags } = req.body;
  const { contactId } = req.params;
  const tenantId = Number(req.user.tenantId);

  const contact = await UpdateContactTagsService({ tags, contactId, tenantId });

  return res.status(200).json(contact); // HTTP 200 OK
};

/**
 * @description Actualiza las billeteras (wallets) de un contacto.
 * @param {UpdateWalletRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const updateContactWallet = async (
  req: UpdateWalletRequest,
  res: Response
): Promise<Response> => {
  const { wallets } = req.body;
  const { contactId } = req.params;
  const tenantId = Number(req.user.tenantId);

  const contact = await UpdateContactWalletsService({
    wallets,
    contactId,
    tenantId
  });

  return res.status(200).json(contact); // HTTP 200 OK
};

/**
 * @description Sube un archivo para importar contactos.
 * @param {UploadRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const upload = async (
  req: UploadRequest,
  res: Response
): Promise<Response> => {
  const file = req.file;
  const { tenantId } = req.user;
  let { tags, wallets, crm } = req.body;

  const tagIds = tags ? tags.split(",").map(Number) : undefined;
  const walletIds = wallets ? wallets.split(",").map(Number) : undefined;
  const crmIds = crm ? crm.split(",").map(Number) : undefined; // Asumiendo que crm también son IDs numéricos

  if (!file) {
    throw new AppError("Ningún archivo subido.", 400); // Traducido
  }

  const importedContacts = await ImportFileContactsService(
    Number(tenantId),
    file,
    tagIds,
    walletIds,
    crmIds // Pasar los IDs de CRM si existen
  );

  return res.status(200).json(importedContacts); // HTTP 200 OK
};

/**
 * @description Exporta los contactos a un archivo XLSX.
 * @param {ExportRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<void>} - Promesa que se resuelve cuando se envía el archivo o ocurre un error.
 */
export const exportContacts = async (
  req: ExportRequest,
  res: Response
): Promise<void> => {
  const { tenantId } = req.user;

  const contacts = await Contact.findAll({
    where: { tenantId: Number(tenantId) },
    attributes: ["id", "name", "number", "email"], // Campos a exportar
    order: [["name", "ASC"]],
    raw: true
  });

  // Preparar datos para XLSX
  const data = contacts.map(contact => ({
    // Nombre: contact.name, // Cabeceras en español
    // Número: contact.number,
    // Email: contact.email,
    // Puedes añadir más campos aquí si los necesitas
    // Usar los nombres originales para mantener la estructura como se pidió
    name: contact.name,
    number: contact.number,
    email: contact.email
  }));

  const worksheet = xlsx.utils.json_to_sheet(data);
  const workbook = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(workbook, worksheet, "Contactos"); // Nombre de la hoja en español

  const buffer = xlsx.write(workbook, { bookType: "xlsx", type: "buffer" });

  const downloadsDir = path.resolve(
    __dirname,
    "..",
    "..",
    "public",
    "downloads"
  );
  const filename = `${uuidv4()}_contatos.xlsx`; // Nombre del archivo
  const filePath = path.join(downloadsDir, filename);

  // Crear directorio si no existe
  if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
  }

  try {
    await fs.promises.writeFile(filePath, buffer);
    logger.info(`Archivo de contactos exportado guardado en: ${filePath}`); // Traducido

    // Devolver la URL de descarga
    // Asegúrate de que process.env.BACKEND_URL y process.env.PROXY_PORT estén configurados
    const backendUrl =
      process.env.BACKEND_URL || `http://localhost:${process.env.PORT || 3000}`;
    // const proxyPort = process.env.PROXY_PORT || process.env.PORT || 3000; // Ajustar según tu configuración
    const downloadUrl = `${backendUrl}/public/downloads/${filename}`; // Asumiendo que /public está servido estáticamente

    res.status(200).json({ downloadLink: downloadUrl }); // HTTP 200 OK
  } catch (error) {
    logger.error("Error al guardar el archivo de exportación:", error); // Traducido
    throw new AppError("Error al exportar contactos.", 500); // Traducido
  }

  // Alternativa: Enviar el archivo directamente como descarga
  // res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
  // res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  // res.send(buffer);
};

// --- END OF FILE ContactController.ts ---
