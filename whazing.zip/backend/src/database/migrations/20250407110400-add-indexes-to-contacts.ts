import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Contacts";
    // Add composite index on [tenantId, isGroup, disableKanban]
    await queryInterface.addIndex(
      tableName,
      ["tenantId", "isGroup", "disableKanban"],
      {
        name: "idx_contacts_tenant_isgroup_disablekanban" // Explicit index name
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Contacts";
    // Remove the index
    await queryInterface.removeIndex(
      tableName,
      "idx_contacts_tenant_isgroup_disablekanban"
    );
  }
};

export = migration;
