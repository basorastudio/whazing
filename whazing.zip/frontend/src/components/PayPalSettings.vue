<template>
  <div class="paypal-settings q-pa-md">
    <q-card class="settings-card">
      <q-card-section>
        <div class="text-h6 q-mb-md">Configuración de PayPal</div>
        <div class="text-caption q-mb-lg text-grey-8">
          Configure los parámetros de PayPal para habilitar los pagos en línea en su sistema.
        </div>
        <q-form @submit="saveSettings" class="q-gutter-md">
          <div class="row q-col-gutter-md">
            <!-- Sección de Modo de Operación -->
            <div class="col-12">
              <div class="text-subtitle2 q-mb-sm">Modo de Operación</div>
              <q-card flat bordered class="q-pa-sm bg-grey-1">
                <q-toggle
                  v-model="settings.sandbox"
                  label="Modo Sandbox"
                  color="primary"
                  class="q-mb-sm"
                >
                  <q-tooltip>Habilitar modo de pruebas de PayPal para realizar pruebas sin transacciones reales</q-tooltip>
                </q-toggle>
                <div class="text-caption text-grey-8">
                  El modo Sandbox es un entorno de prueba seguro para verificar la integración antes de procesar pagos reales.
                </div>
              </q-card>
            </div>

            <!-- Sección de Credenciales -->
            <div class="col-12">
              <div class="text-subtitle2 q-mb-sm">Credenciales de API</div>
              <q-card flat bordered class="q-pa-md bg-grey-1">
                <div class="row q-col-gutter-md">
                  <div class="col-12 col-md-6">
                    <q-input
                      v-model="settings.clientId"
                      label="Client ID"
                      :type="showSecrets ? 'text' : 'password'"
                      outlined
                      :rules="[val => !!val || 'Client ID es requerido']"
                      lazy-rules
                      class="settings-input"
                    >
                      <template v-slot:append>
                        <q-icon
                          :name="showSecrets ? 'visibility_off' : 'visibility'"
                          class="cursor-pointer"
                          @click="showSecrets = !showSecrets"
                        />
                      </template>
                      <template v-slot:hint>
                        Obtenga este ID en su cuenta de desarrollador de PayPal
                      </template>
                    </q-input>
                  </div>

                  <div class="col-12 col-md-6">
                    <q-input
                      v-model="settings.clientSecret"
                      label="Client Secret"
                      :type="showSecrets ? 'text' : 'password'"
                      outlined
                      :rules="[val => !!val || 'Client Secret es requerido']"
                      lazy-rules
                      class="settings-input"
                    >
                      <template v-slot:append>
                        <q-icon
                          :name="showSecrets ? 'visibility_off' : 'visibility'"
                          class="cursor-pointer"
                          @click="showSecrets = !showSecrets"
                        />
                      </template>
                      <template v-slot:hint>
                        Clave secreta asociada a su Client ID
                      </template>
                    </q-input>
                  </div>
                </div>
              </q-card>
            </div>

            <!-- Sección de Webhook -->
            <div class="col-12">
              <div class="text-subtitle2 q-mb-sm">Configuración de Webhook</div>
              <q-card flat bordered class="q-pa-md bg-grey-1">
                <div class="row q-col-gutter-md">
                  <div class="col-12">
                    <q-input
                      v-model="settings.webhookId"
                      label="Webhook ID"
                      :type="showSecrets ? 'text' : 'password'"
                      outlined
                      :rules="[val => !!val || 'Webhook ID es requerido']"
                      lazy-rules
                      class="settings-input"
                    >
                      <template v-slot:append>
                        <q-icon
                          :name="showSecrets ? 'visibility_off' : 'visibility'"
                          class="cursor-pointer"
                          @click="showSecrets = !showSecrets"
                        />
                      </template>
                      <template v-slot:hint>
                        ID único generado al configurar el webhook en PayPal
                      </template>
                    </q-input>
                  </div>

                  <div class="col-12">
                    <q-input
                      v-model="settings.webhookUrl"
                      label="URL del Webhook"
                      outlined
                      readonly
                      class="settings-input"
                    >
                      <template v-slot:append>
                        <q-btn
                          flat
                          round
                          icon="content_copy"
                          @click="copyWebhookUrl"
                        >
                          <q-tooltip>Copiar URL</q-tooltip>
                        </q-btn>
                      </template>
                      <template v-slot:hint>
                        Configure esta URL en su cuenta de PayPal para recibir notificaciones
                      </template>
                    </q-input>
                  </div>
                </div>
              </q-card>
            </div>

            <!-- Sección de Opciones de Pago -->
            <div class="col-12">
              <div class="text-subtitle2 q-mb-sm">Opciones de Pago</div>
              <q-card flat bordered class="q-pa-md bg-grey-1">
                <q-toggle
                  v-model="settings.allowCardPayments"
                  label="Aceptar pagos con tarjeta"
                  color="primary"
                  class="q-mb-sm"
                >
                  <q-tooltip>Permitir pagos con tarjeta sin cuenta de PayPal</q-tooltip>
                </q-toggle>
                <div class="text-caption text-grey-8">
                  Habilite esta opción para permitir que los clientes paguen directamente con tarjeta de crédito/débito sin necesidad de una cuenta PayPal.
                </div>
              </q-card>
            </div>

            <!-- Sección de Tipos de Eventos -->
            <div class="col-12">
              <div class="text-subtitle2 q-mb-sm">Tipos de Eventos</div>
              <q-card flat bordered class="q-pa-md bg-grey-1">
                <q-option-group
                  v-model="settings.eventTypes"
                  :options="eventTypeOptions"
                  type="checkbox"
                  class="event-types-group"
                />
                <div class="text-caption text-grey-8 q-mt-sm">
                  Seleccione los tipos de eventos de PayPal que desea monitorear en su sistema.
                </div>
              </q-card>
            </div>
          </div>

          <div class="row justify-end q-mt-lg">
            <q-btn
              type="submit"
              color="primary"
              label="Guardar Configuración"
              :loading="saving"
              icon="save"
            />
          </div>
        </q-form>
      </q-card-section>
    </q-card>
  </div>
</template>

<style lang="scss" scoped>
.settings-card {
  max-width: 1200px;
  margin: 0 auto;
}

.settings-input {
  width: 100%;
}

.event-types-group {
  .q-option-group {
    margin-top: 8px;
  }
}
</style>