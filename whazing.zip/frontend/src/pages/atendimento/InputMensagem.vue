<template>
  <div>

    <div class="bg-transparent fast-messages-list" v-if="cMensagensRapidas.length > 0 && ticketFocado.status === 'open'">
      <q-badge class="text-white item-fast-messages-list q-pa-sm" v-for="(resposta, index) in cMensagensRapidas" :key="resposta.key" clickable v-close-popup @click="mensagemRapidaSelecionada(resposta)"
               :class="getBadgeClass(index)">
        <q-item-label class="text-bold">
          {{ resposta.key }}
        </q-item-label>
        <q-tooltip content-class="text-white bg-padrao text-bold" anchor="top middle" self="bottom middle">
          {{ resposta.message }} {{ resposta.media }}
        </q-tooltip>
      </q-badge>
    </div>

    <div @drop.prevent="handleFileDrop" @dragover.prevent>
      <div class="drop-area" @drop="handleFileDrop" @dragover="handleDragOver" @dragleave="handleDragLeave">

        <div class="q-py-md row bg-white justify-start items-center text-grey-9 relative-position">
          <template v-if="!isRecordingAudio">

            <q-btn v-if="$q.screen.width > 500 && ticketFocado.status !== 'pending'" flat dense icon="mdi-emoticon-happy-outline" :disable="cDisableActions" class="btn-rounded-cor1 q-mx-xs" :class="$q.dark.isActive ? ('btn-rounded-cor1-dark q-mx-xs') : ''">
              <q-tooltip content-class="text-bold">{{ $t('inputmensagem.emoji') }}</q-tooltip>
              <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                <VEmojiPicker style="width: 40vw" :showSearch="true" :emojisByRow="calculateEmojisByRow()" :labelSearch="$t('inputmensagem.localizar')" lang="pt-BR" @select="onInsertSelectEmoji" />
              </q-menu>
            </q-btn>

            <q-btn flat dense round icon="eva-plus-outline"
                   class="color-light1"
                   :class="$q.dark.isActive ? ('color-dark1') : ''"
                   v-if="$q.screen.width > 500 && ticketFocado.status !== 'pending'">
              <q-menu>
                <q-list style="min-width: 100px;">
                  <q-item class="text-left" style="padding: 0">
                    <q-btn
                      flat
                      @click="abrirEnvioArquivo"
                      icon="mdi-paperclip"
                      :disable="cDisableActions"
                      class="btn-rounded-cor1 full-width"
                      :class="$q.dark.isActive ? ('btn-rounded-cor1-dark full-width') : ''"
                      :label="$t('inputmensagem.enviar_arquivo')"
                    >
                    </q-btn>
                  </q-item>

                  <q-item class="text-left" style="padding: 0" v-if="ticketFocado.channel === 'whatsapp' || ticketFocado.channel === 'hub_whatsapp'">
                    <q-btn
                      flat
                      @click="abrirEnvioSticker"
                      icon="mdi-sticker-emoji"
                      :disable="cDisableActions"
                      class="btn-rounded-cor1 full-width"
                      :class="$q.dark.isActive ? ('btn-rounded-cor1-dark full-width') : ''"
                      :label="$t('inputmensagem.enviarsticker')"
                    >
                    </q-btn>
                  </q-item>

                  <q-item class="text-left" style="padding: 0">
                    <q-btn
                      flat
                      @click="handlSendLinkVideo"
                      icon="mdi-message-video"
                      :disable="cDisableActions"
                      class="color-light1"
                      :class="$q.dark.isActive ? ('color-dark1') : ''"
                      :label="$t('inputmensagem.enviar_videoconferencia')"
                    >
                    </q-btn>
                  </q-item>

                   <q-item class="text-left" style="padding: 0" v-if="ticketFocado.channel === 'hub_whatsapp'">
                  <q-btn
                      flat
                      @click="handleOpenTemplates"
                      icon="mdi-message-text-outline"
                      :disable="cDisableActions"
                      class="btn-rounded-cor1 full-width"
                      :class="$q.dark.isActive ? ('btn-rounded-cor1-dark full-width') : ''"
                      :label="$t('inputtemplate.Enviartemplate')"
                    >
                    </q-btn>
                  </q-item>

                </q-list>
              </q-menu>
            </q-btn>

            <q-btn
              v-if="mensagemRapidaMedia"
              flat
              dense
              icon="mdi-cancel"
              class="bg-padrao btn-rounded q-mx-xs"

              :color="$q.dark.isActive ? 'red' : 'red'"
              @click="removerMediaMensagemRapida"
            >
              <q-tooltip content-class="text-bold">{{ $t('inputmensagem.remover_midia') }}</q-tooltip>
            </q-btn>

            <div class="row justify-center full-width" v-if="ticketFocado.status === 'pending'">
            <q-btn @click="iniciarAtendimento(ticketFocado)"
                     v-if="!ticketFocado.disableRespondHub"
                     flat
                     icon="mdi-send-circle"
                     :label="$t('InforCabecalhoChat.messages.startChat')"
                     class="generate-button btn-rounded-50"
                     :class="{'generate-button-dark' : $q.dark.isActive}">
                <q-tooltip content-class="text-bold">
                  {{ $t('InforCabecalhoChat.messages.startChat') }}
                </q-tooltip>
              </q-btn>

              <q-btn @click="FecharTicket(ticketFocado)"
                     v-if="ticketFocado.disableRespondHub"
                     flat
                     icon="mdi-close-circle"
                     :label="$t('InforCabecalhoChat.messages.closeTicket')"
                     class="generate-button btn-rounded-50"
                     :class="{'generate-button-dark' : $q.dark.isActive}">
                <q-tooltip content-class="text-bold">
                  {{ $t('InforCabecalhoChat.messages.closeTicket') }}
                </q-tooltip>
              </q-btn>
            </div>

            <q-input
              :disable="cDisableActions"
              hide-bottom-space
              :loading="loading"
              ref="inputEnvioMensagem"
              id="inputEnvioMensagem"
              type="textarea"
              @keydown.exact.enter.prevent="enviarMensagemOnEnter"
              v-show="ticketFocado.status !== 'pending' && ((ticketFocado.channel === 'whatsapp' || ticketFocado.channel === 'hub_whatsapp') ? !cMostrarEnvioArquivo2 : !cMostrarEnvioArquivo)"
              class="col-grow q-mx-xs text-grey-10 inputEnvioMensagem"
              bg-color="grey-2"
              color="grey-7"
              :placeholder="$t('inputmensagem.digitar_mensagem')"
              input-style="max-height: 30vh"
              autogrow
              rounded
              dense
              outlined
              autofocus
              v-model="textChat"
              :value="textChat"
              @paste="handleInputPaste"
            >

              <template v-slot:prepend v-if="$q.screen.width < 500">
                <q-btn  flat icon="mdi-emoticon-happy-outline" :disable="cDisableActions" dense round  class="btn-rounded-cor1 q-mx-xs" :class="$q.dark.isActive ? ('btn-rounded-cor1-dark q-mx-xs') : ''">
                  <q-tooltip content-class="text-bold">{{ $t('inputmensagem.emoji') }}</q-tooltip>
                  <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                    <VEmojiPicker style="width: 40vw" :showSearch="false" :emojisByRow="calculateEmojisByRow()" :labelSearch="$t('inputmensagem.localizar')" lang="pt-BR" @select="onInsertSelectEmoji" />
                  </q-menu>
                </q-btn>
              </template>

              <template v-slot:append>
                <q-btn
                  flat
                  @click="abrirEnvioArquivo"
                  icon="mdi-paperclip"
                  :disable="cDisableActions"
                  dense
                  round
                  v-if="$q.screen.width < 500"
                  class="color-light1 bg-padrao full-width"
                  :class="$q.dark.isActive ? ('color-dark1 bg-padrao full-width') : ''"
                >
                  <q-tooltip content-class=" text-bold">{{ $t('inputmensagem.enviar_arquivo') }}</q-tooltip>
                </q-btn>

                <q-toggle keep-color v-model="sign" dense @input="handleSign" class="q-mx-sm q-ml-md" :color="sign ? 'positive' : 'black'" type="toggle" v-if="userProfile === 'admin'">
                  <q-tooltip>{{ sign ? $t('inputmensagem.desativar_assinatura') : $t('inputmensagem.ativar_assinatura') }}</q-tooltip>
                </q-toggle>
                <q-toggle keep-color v-model="sign" dense @input="handleSign" class="q-mx-sm q-ml-md" :color="sign ? 'positive' : 'black'" type="toggle" v-if="disabledSign && userProfile !== 'admin'">
                  <q-tooltip>{{ sign ? $t('inputmensagem.desativar_assinatura') : $t('inputmensagem.ativar_assinatura') }}</q-tooltip>
                </q-toggle>

              </template>
            </q-input>

            <q-file
              :loading="loading"
              :disable="cDisableActions"
              ref="PickerFileMessage"
              id="PickerFileMessage"
              v-show="cMostrarEnvioArquivo"
              v-model="arquivos"
              class="col-grow q-mx-xs PickerFileMessage"
              bg-color="blue-grey-1"
              input-style="max-height: 30vh"
              outlined
              use-chips
              multiple
              autogrow
              dense
              rounded
              append
              :max-files="5"
              :max-file-size="ticketFocado.channel === 'hub_instagram' ? 8388608 : 104857600"
              :max-total-size="ticketFocado.channel === 'hub_instagram' ? 8388608 : 104857600"
              :accept="ticketFocado.channel === 'hub_instagram' ? '.jpg, .jpeg, .png, .ico, .bmp, .webp' : '.txt, .xml, .jpg, .png, image/jpeg, .pdf, .doc, .docx, .mp4, .mp3, .xls, .xlsx, .jpeg, .rar, .zip, .ppt, .pptx, image/*, .dwg, .cad, .cdr, .psd, .ai, .csv, .pfx, *'"
              @rejected="onRejectedFiles"
              @input="validarArquivoTamanho"
            />

            <q-btn
              v-if="textChat || cMostrarEnvioArquivo || removeMedia"
              ref="btnEnviarMensagem"
              @click="enviarMensagemOnEnter"
              :disabled="ticketFocado.status !== 'open' || isSending"
              flat
              icon="mdi-send"
              class="color-light1 bg-padrao btn-rounded q-mx-xs"
              :class="$q.dark.isActive ? ('color-dark1 bg-padrao btn-rounded q-mx-xs') : ''"
            >
              <q-tooltip content-class=" text-bold">{{ $t('inputmensagem.enviar') }}</q-tooltip>
            </q-btn>

            <q-btn
              v-if="!textChat && !cMostrarEnvioArquivo && !isRecordingAudio && ticketFocado.status !== 'pending'"
              @click="handleStartRecordingAudio"
              :disabled="cDisableActions"
              flat
              icon="eva-mic-outline"
              class="color-light1 btn-rounded q-mx-xs"
              :class="$q.dark.isActive ? ('color-dark1 btn-rounded q-mx-xs') : ''"
            >
              <q-tooltip content-class="text-bold">{{ $t('inputmensagem.enviar_audio') }}</q-tooltip>
            </q-btn>
          </template>

          <template v-else>
            <div class="full-width items-center row justify-end">
              <q-skeleton animation="pulse-y" class="col-grow q-mx-md" type="text" />
              <div style="width: 200px" class="flex flex-center items-center" v-if="isRecordingAudio">
                <q-btn flat icon="mdi-close" color="negative" @click="handleCancelRecordingAudio" class="bg-padrao btn-rounded q-mx-xs" />
                <RecordingTimer class="text-bold" :class="{ 'color-dark3': $q.dark.isActive }" />
                <q-btn flat icon="mdi-send-circle-outline" color="positive" @click="handleStopRecordingAudio" class="bg-padrao btn-rounded q-mx-xs" />
              </div>
            </div>
          </template>
        </div>

        <!-- Modal seleção de categorias de template -->
        <q-dialog v-model="templateCategoryModal" persistent>
          <q-card style="min-width: 350px">
            <q-card-section>
              <div class="text-h6">{{ $t('inputtemplate.Selecioneumacategoria') }}</div>
            </q-card-section>

            <q-card-section v-if="loadingTemplateCategories" class="q-pa-md text-center">
              <q-spinner color="primary" size="2em" />
              <div class="q-mt-sm">{{ $t('inputtemplate.carregandocategorias') }}</div>
            </q-card-section>

            <q-card-section v-else-if="templateCategories.length === 0" class="q-pa-md text-center">
              <q-icon name="mdi-alert-circle-outline" color="warning" size="2em" />
              <div class="q-mt-sm">{{ $t('inputtemplate.nenhumtemplatedisponivel') }}</div>
            </q-card-section>

            <q-card-section v-else class="q-pt-none">
              <q-list>
                <q-item v-for="category in templateCategories" :key="category" clickable @click="selectTemplateCategory(category)">
                  <q-item-section>
                    <q-item-label>{{ category }}</q-item-label>
                  </q-item-section>
                </q-item>
              </q-list>
            </q-card-section>

            <q-card-actions align="right">
              <q-btn :label="$t('general.cancelar')" class="q-mr-md btn-rounded-50" color="negative" v-close-popup />
            </q-card-actions>
          </q-card>
        </q-dialog>

        <!-- Modal seleção de template específico -->
        <q-dialog v-model="templateListModal" persistent>
          <q-card style="width: 700px; max-width: 80vw;">
            <q-card-section>
              <div class="text-h6">{{ $t('inputtemplate.Selecioneumtemplate') }}</div>
              <div class="text-subtitle2">{{ $t('inputtemplate.categoria') }} {{ selectedCategory }}</div>
            </q-card-section>

            <q-card-section v-if="loadingTemplates" class="q-pa-md text-center">
              <q-spinner color="primary" size="2em" />
              <div class="q-mt-sm">{{ $t('inputtemplate.carregandotemplates') }}</div>
            </q-card-section>

            <q-card-section v-else class="q-pt-none">
              <q-input outlined v-model="templateSearch" :label="$t('inputtemplate.buscartemplate')" dense>
                <template v-slot:append>
                  <q-icon name="search" />
                </template>
              </q-input>

              <q-list separator>
                <q-item v-for="template in filteredTemplates" :key="template.id" clickable @click="selectTemplate(template)">
                  <q-item-section>
                    <q-item-label class="text-weight-bold">{{ template.name }}</q-item-label>
                    <q-item-label caption>{{ getTemplatePreview(template) }}</q-item-label>
                  </q-item-section>
                </q-item>
              </q-list>
            </q-card-section>

            <q-card-actions align="right">
              <q-btn :label="$t('inputtemplate.voltar')" color="primary" class="q-mr-md btn-rounded-50" @click="templateListModal = false; templateCategoryModal = true" />
              <q-btn :label="$t('general.cancelar')" color="negative" class="q-mr-md btn-rounded-50" v-close-popup />
            </q-card-actions>
          </q-card>
        </q-dialog>

        <!-- Modal edição de template para envio -->
        <q-dialog v-model="templateEditModal" persistent>
          <q-card style="width: 700px; max-width: 80vw;">
            <q-card-section>
              <div class="text-h6">{{ $t('inputtemplate.editarenviartemplate') }}</div>
              <div class="text-subtitle2">{{ selectedTemplate?.name }}</div>
            </q-card-section>

            <q-card-section>
              <div class="text-body1 q-mb-md">{{ getTemplatePreview(selectedTemplate) }}</div>

              <div v-if="templateParameters.length > 0">
                <div v-for="(param, index) in templateParameters" :key="index" class="q-mb-md">
                  <q-input
                    outlined
                    v-model="templateParamValues[index]"
                    :label="`${$t('inputtemplate.parametro')} ${index + 1}`"
                    :hint="getParameterHint(param, index)"
                  />
                </div>
              </div>

              <div v-else class="text-body2 q-my-md">
                {{ $t('inputtemplate.templatenaopossuiparametros') }}
              </div>
            </q-card-section>

            <q-card-section v-if="selectedTemplate?.components?.find(c => c.type === 'HEADER' && c.format === 'IMAGE')">
              <q-file
                v-model="templateHeaderImage"
                :label="$t('inputtemplate.imagemcabecalho')"
                outlined
                accept=".jpg, .jpeg, .png"
              >
                <template v-slot:prepend>
                  <q-icon name="image" />
                </template>
              </q-file>
            </q-card-section>

            <q-card-actions align="right">
              <q-btn :label="$t('inputtemplate.voltar')" class="q-mr-md btn-rounded-50" color="primary" @click="templateEditModal = false; templateListModal = true" />
              <q-btn :label="$t('general.cancelar')" class="q-mr-md btn-rounded-50" color="negative" v-close-popup />
              <q-btn unelevated :label="$t('inputtemplate.enviar')" class="q-mr-md btn-rounded-50" color="primary" @click="sendTemplate" :loading="sendingTemplate" />
            </q-card-actions>
          </q-card>
        </q-dialog>

        <q-dialog v-model="abrirModalPreviewImagem" position="right" @hide="hideModalPreviewImagem" @show="showModalPreviewImagem">
          <q-card style="height: 90vh; min-width: 60vw; max-width: 60vw" class="q-pa-md">
            <q-card-section>
              <div class="text-h6">
                {{ urlMediaPreview.title }}
                <q-btn class="float-right" icon="close" color="negative" round outline @click="hideModalPreviewImagem" />
              </div>
            </q-card-section>
            <q-card-section>
              <q-img :src="urlMediaPreview.src" class="color-dark3 img-responsive mdi-image-auto-adjust q-uploader__file--img" style="height: 60vh; min-width: 55vw; max-width: 55vw" />
            </q-card-section>
            <q-card-section>
              <q-input @keypress.enter.exact="enviarMensagemOnEnter()" v-model="textChat" :label="$t('inputmensagem.digitar_mensagem')" filled dense />
            </q-card-section>
            <q-card-actions align="center">
              <q-btn ref="qbtnPasteEnvioMensagem" :label="$t('inputmensagem.enviar')" class="color-light1 bg-padrao btn-rounded q-mx-xs" v-close-popup @click="enviarMensagemOnEnter" @keypress.enter.exact="enviarMensagemOnEnter()" />
            </q-card-actions>
            <span class="row col text-caption text-blue-grey-10">{{ $t('inputmensagem.confirmar_envio') }}</span>
            <span class="row col text-caption text-blue-grey-10">{{ $t('inputmensagem.cancelar') }}</span>
          </q-card>
        </q-dialog>

      </div>

    </div>
  </div>
</template>

<script>
import { LocalStorage, uid } from 'quasar'
import mixinCommon from './mixinCommon'
import mixinAtualizarStatusTicket from './mixinAtualizarStatusTicket'
import { EnviarMensagemTexto, checkMessageWindow } from 'src/service/tickets'
import { ListarCategoriasTemplates, ListarTemplates, EnviarMensagemTemplate } from 'src/service/hub'
import { VEmojiPicker } from 'v-emoji-picker'
import { mapGetters } from 'vuex'
import RecordingTimer from './RecordingTimer'
import MicRecorder from 'mic-recorder-to-mp3'
const Mp3Recorder = new MicRecorder({
  bitRate: 128,
  encodeAfterRecord: true
})
import { format } from 'date-fns'
import { ListarConfiguracoes } from 'src/service/configuracoes'

export default {
  name: 'InputMensagem',
  mixins: [mixinCommon, mixinAtualizarStatusTicket],
  props: {
    replyingMessage: {
      type: Object,
      default: null
    },
    isScheduleDate: {
      type: Boolean,
      default: false
    },
    mensagensRapidas: {
      type: Array,
      default: () => []
    }
  },
  components: {
    VEmojiPicker,
    RecordingTimer
  },
  data () {
    return {
      loading: false,
      inputText: '',
      abrirFilePicker: false,
      abrirModalPreviewImagem: false,
      isRecordingAudio: false,
      urlMediaPreview: {
        title: '',
        src: ''
      },
      visualizarMensagensRapidas: false,
      arquivos: [],
      textChat: '',
      isSending: false,
      sign: false,
      scheduleDate: null,
      userProfile: 'user',
      mensagemRapidaMedia: '',
      mensagemRapidaSetada: false,
      removeMedia: false,
      disabledSign: false,
      templateCategoryModal: false,
      templateListModal: false,
      templateEditModal: false,
      loadingTemplateCategories: false,
      loadingTemplates: false,
      sendingTemplate: false,
      templateCategories: [],
      templateList: [],
      templateSearch: '',
      selectedCategory: '',
      selectedTemplate: null,
      templateParameters: [],
      templateParamValues: [],
      templateHeaderImage: null
    }
  },
  computed: {
    ...mapGetters(['ticketFocado']),
    cDisableActions () {
      return (this.isRecordingAudio || this.ticketFocado.status !== 'open' || this.isSending)
    },
    cMostrarEnvioArquivo () {
      return this.arquivos.length > 0
    },
    cMostrarEnvioArquivo2 () {
      return this.arquivos.length > 1
    },
    cMensagensRapidas () {
      let search = this.textChat?.toLowerCase()
      if (search && search.trim().startsWith('/')) {
        search = search.replace('/', '')
      }
      return !search ? this.mensagensRapidas : this.mensagensRapidas.filter(r => r.key.toLowerCase().indexOf(search) !== -1)
      // return this.mensagensRapidas
    },
    filteredTemplates() {
      if (!this.templateSearch) return this.templateList

      const search = this.templateSearch.toLowerCase()
      return this.templateList.filter(template =>
        template.name.toLowerCase().includes(search) ||
        this.getTemplatePreview(template).toLowerCase().includes(search)
      )
    }
  },
  methods: {
    onSelectSchedule(newValue) {
      if (!newValue.func) {
        this.scheduleDate = null
        return
      }
      const date = newValue.func()
      this.scheduleDate = format(date, 'yyyy-MM-dd HH:mm')
    },
    async enviarMensagemOnEnter() {
      if (this.isSending) return

      this.isSending = true

      try {
        await this.enviarMensagem()
      } catch (error) {
        console.error('Erro ao enviar mensagem:', error)
      } finally {
        this.isSending = false
      }
    },
    handleFileDrop(event) {
      const files = event.dataTransfer.files
      if (files.length) {
        // this.textChat = ''
        this.arquivos = [files[0]]
        this.abrirModalPreviewImagem = true
        this.urlMediaPreview = {
          title: this.$t('inputmensagem.enviar_imagem', { contactName: this.ticketFocado?.contact?.name }),
          src: this.openFilePreviewDD(files[0])
        }
        this.$refs.inputEnvioMensagem.focus()
      }
    },
    handleDragOver(event) {
      event.preventDefault()
      event.currentTarget.classList.add('dragover')
    },
    handleDragLeave(event) {
      event.currentTarget.classList.remove('dragover')
    },
    openFilePreviewDD(file) {
      const urlImg = window.URL.createObjectURL(file)
      return urlImg
    },
    async abrirEnvioSticker() {
      const fileInput = document.createElement('input')
      fileInput.type = 'file'
      fileInput.accept = '.jpg, .jpeg, .png, .webp, .gif, image/*'
      fileInput.multiple = false

      fileInput.onchange = (event) => {
        const file = event.target.files[0]
        if (file) {
          this.enviarSticker(file)
        }
      }

      fileInput.click()
    },
    async enviarSticker(arquivo) {
      const ticketId = this.ticketFocado.id
      this.loading = true

      try {
        if (arquivo.size < 10000) {
          this.loading = false
          return
        }

        const username = localStorage.getItem('username')
        const sendType = 'user: ' + username

        const formData = new FormData()
        formData.append('medias', arquivo, arquivo.name)
        formData.append('body', '')
        formData.append('sendType', sendType)
        formData.append('fromMe', true)
        formData.append('isSticker', true)

        // Verificar o canal e a janela de 24 horas
        if (this.ticketFocado.channel === 'hub_whatsapp') {
          try {
            // Verificar a janela de 24 horas
            const response = await checkMessageWindow({
              ticketId: this.ticketFocado.id
            })

            // Verificar se está fora da janela de 24 horas
            if (!response.data.isWithin24Hours) {
              // Formatar a data da última mensagem para exibição (se existir)
              let lastMessageInfo = ''
              if (response.data.lastMessageDate) {
                const lastMessageDate = new Date(response.data.lastMessageDate)
                const formattedDate = lastMessageDate.toLocaleString()
                lastMessageInfo = `A última mensagem do cliente foi em: ${formattedDate}`
              }

              this.loading = false

              // Mostrar alerta para o usuário
              const confirmSend = await new Promise(resolve => {
                this.$q.dialog({
                  title: this.$t('message_window.out_of_window_title'),
                  message: this.$t('message_window.out_of_window_message', { lastMessageInfo }),
                  ok: this.$t('message_window.understand_continue'),
                  cancel: this.$t('message_window.cancel'),
                  persistent: true
                }).onOk(() => {
                  resolve(true)
                }).onCancel(() => {
                  resolve(false)
                })
              })

              if (!confirmSend) {
                return
              }

              this.loading = true
            }
          } catch (error) {
            console.error('Erro ao verificar janela de 24 horas:', error)
          }
        }

        await EnviarMensagemTexto(ticketId, formData)
        this.arquivos = []
        this.textChat = ''
        this.$emit('update:replyingMessage', null)
        this.abrirFilePicker = false
        this.abrirModalPreviewImagem = false
        this.loading = false

        setTimeout(() => {
          this.scrollToBottom()
        }, 300)
      } catch (error) {
        this.loading = false
        this.$notificarErro(this.$t('inputmensagem.erro_ocorrido'), error)
      }
    },
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoes()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        let value = el.value
        if (el.key === 'botTicketActive' && el.value) {
          value = +el.value
        }
        this.$data[el.key] = value
      })
      const enabledSign = this.configuracoes.filter(item => item.key === 'userDisableSignature')[0]
      if (enabledSign.value === 'enabled') {
        this.disabledSign = true
      } else {
        LocalStorage.set('sign', true)
        this.disabledSign = false
      }
    },
    openFilePreview (event) {
      const data = event.clipboardData.files[0]
      const urlImg = window.URL.createObjectURL(data)
      return urlImg
    },
    handleInputDrop(evt) {
      const allowed = this.accept.split(',').map((a) => a.trim())
      // this.textChat = ''
      this.arquivos = [
        ...this.arquivos,
        ...[...evt.dataTransfer.files].filter((file) => {
          const ext = file.name.split('.').pop()
          const extensionPattern = allowed.map((ext) => ext.replace(/\./g, '\\.').replace(/\*/g, '.*')).join('|')
          const regex = new RegExp(`^(${extensionPattern})$`, 'i')
          return regex.test(file.type) || regex.test('.' + ext)
        })
      ]

      if (!this.arquivos.length) {
        this.$q.notify({
          message: this.$t('inputmensagem.arquivo_invalido'),
          caption: this.$t('inputmensagem.formatos_aceitos', { formats: allowed.join(', ') }),
          type: 'negative'
        })
        return
      }

      this.$refs.inputEnvioMensagem.focus()
    },
    handleInputPaste (e) {
      if (!this.ticketFocado?.id) return
      if (e.clipboardData.files[0]) {
        // .textChat = ''
        this.arquivos = [e.clipboardData.files[0]]
        this.abrirModalPreviewImagem = true
        this.urlMediaPreview = {
          title: this.$t('inputmensagem.enviar_imagem', { contactName: this.ticketFocado?.contact?.name }),
          src: this.openFilePreview(e)
        }
        this.$refs.inputEnvioMensagem.focus()
      }
    },
    removerMediaMensagemRapida() {
      this.removeMedia = false
      this.mensagemRapidaMedia = ''
      this.mensagemRapidaSetada = false
    },
    mensagemRapidaSelecionada(mensagem) {
      if (mensagem.message !== 'null') {
        this.textChat = mensagem.message
      }
      if (this.mensagemRapidaMedia !== null) {
        this.mensagemRapidaMedia = mensagem.media
        this.removeMedia = true
      }
      if (this.mensagemRapidaMedia !== null) {
        this.mensagemRapidaSetada = true
        this.removeMedia = true
      }
      setTimeout(() => {
        this.$refs.inputEnvioMensagem.focus()
      }, 300)
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem.$refs.input
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value

      // filter:
      if (!emoji.data) {
        return
      }

      // insert:
      self.txtContent = this.textChat
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.textChat = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    abrirEnvioArquivo (event) {
      // this.textChat = ''
      this.abrirFilePicker = true
      this.$refs.PickerFileMessage.pickFiles(event)
    },
    async handleStartRecordingAudio () {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true })
        await Mp3Recorder.start()
        this.isRecordingAudio = true
      } catch (error) {
        this.isRecordingAudio = false
      }
    },
    async handleStopRecordingAudio () {
      const ticketId = this.ticketFocado.id
      this.loading = true
      this.isRecordingAudio = false
      try {
        const [, blob] = await Mp3Recorder.stop().getMp3()
        if (blob.size < 10000) {
          this.loading = false
          return
        }
        const username = localStorage.getItem('username')

        const sendType = 'user: ' + username

        const formData = new FormData()
        const filename = `${new Date().getTime()}.mp3`
        formData.append('medias', blob, filename)
        formData.append('body', '')
        formData.append('sendType', sendType)
        formData.append('fromMe', true)
        if (this.isScheduleDate) {
          formData.append('scheduleDate', this.scheduleDate)
        }

        // Verificar o canal e a janela de 24 horas
        if (this.ticketFocado.channel === 'hub_whatsapp') {
          try {
            // Verificar a janela de 24 horas
            const response = await checkMessageWindow({
              ticketId: this.ticketFocado.id
            })

            // Verificar se está fora da janela de 24 horas
            if (!response.data.isWithin24Hours) {
              // Formatar a data da última mensagem para exibição (se existir)
              let lastMessageInfo = ''
              if (response.data.lastMessageDate) {
                const lastMessageDate = new Date(response.data.lastMessageDate)
                const formattedDate = lastMessageDate.toLocaleString()
                lastMessageInfo = `A última mensagem do cliente foi em: ${formattedDate}`
              }

              this.loading = false

              // Mostrar alerta para o usuário
              const confirmSend = await new Promise(resolve => {
                this.$q.dialog({
                  title: this.$t('message_window.out_of_window_title'),
                  message: this.$t('message_window.out_of_window_message', { lastMessageInfo }),
                  ok: this.$t('message_window.understand_continue'),
                  cancel: this.$t('message_window.cancel'),
                  persistent: true
                }).onOk(() => {
                  resolve(true)
                }).onCancel(() => {
                  resolve(false)
                })
              })

              if (!confirmSend) {
                return // Usuário cancelou o envio
              }

              this.loading = true
            }
          } catch (error) {
            console.error('Erro ao verificar janela de 24 horas:', error)
            // Em caso de erro na verificação, continuamos normalmente
          }
        }

        await EnviarMensagemTexto(ticketId, formData)
        this.arquivos = []
        this.textChat = ''
        this.$emit('update:replyingMessage', null)
        this.abrirFilePicker = false
        this.abrirModalPreviewImagem = false
        this.isRecordingAudio = false
        this.loading = false
        setTimeout(() => {
          this.scrollToBottom()
        }, 300)
      } catch (error) {
        this.isRecordingAudio = false
        this.loading = false
        this.$notificarErro(this.$t('inputmensagem.erro_ocorrido'), error)
      }
    },
    async handleCancelRecordingAudio () {
      try {
        await Mp3Recorder.stop().getMp3()
        this.isRecordingAudio = false
        this.loading = false
      } catch (error) {
        this.$notificarErro(this.$t('inputmensagem.erro_ocorrido'), error)
      }
    },
    prepararUploadMedia() {
      if (!this.arquivos.length) {
        throw new Error('Não existem arquivos para envio')
      }

      const formData = new FormData()
      formData.append('fromMe', true)

      const bodyText = this.inputText && this.inputText.trim()
        ? this.inputText.trim()
        : this.textChat && this.textChat.trim()
          ? this.prepararMensagemTexto().body
          : null

      const username = localStorage.getItem('username')

      const sendType = 'user: ' + username

      this.arquivos.forEach((media) => {
        formData.append('medias', media)
        formData.append('body', bodyText || '')
        formData.append('sendType', sendType)
        formData.append('idFront', uid())

        if (this.ticketFocado.channel === 'hub_whatsapp') {
          formData.append('quotedMsgId', this.replyingMessage?.id)
        }

        if (this.isScheduleDate) {
          formData.append('scheduleDate', this.scheduleDate)
        }
      })

      return formData
    },
    prepararMensagemTexto () {
      if (this.textChat.trim() === '' && !this.removeMedia) {
        throw new Error('Mensagem Inexistente')
      }

      if (this.textChat.trim() && this.textChat.trim().startsWith('/')) {
        let search = this.textChat.trim().toLowerCase()
        search = search.replace('/', '')
        const mensagemRapida = this.cMensagensRapidas.find(m => m.key.toLowerCase() === search)
        if (mensagemRapida?.message) {
          this.textChat = mensagemRapida.message
        } else {
          const error = this.cMensagensRapidas.length > 1
            ? this.$t('inputmensagem.erro_multiplas_mensagens')
            : this.$t('inputmensagem.erro_mensagem_rapida')
          this.$notificarErro(error)
          this.loading = false
          console.error(error)
          throw new Error(error)
        }
      }

      let mensagem = this.textChat.trim()
      const username = localStorage.getItem('username')
      if (username && this.sign) {
        mensagem = this.ticketFocado.channel === 'whatsapp' || this.ticketFocado.channel === 'hub_whatsapp'
          ? `*${username}*:\n${mensagem}`
          : `${username}:\n${mensagem}`
      }

      const sendType = 'user: ' + username

      const message = {
        read: 1,
        fromMe: true,
        mediaUrl: this.mensagemRapidaSetada ? `${this.mensagemRapidaMedia}` : '',
        body: mensagem,
        sendType: sendType,
        scheduleDate: this.isScheduleDate ? this.scheduleDate : null,
        quotedMsg: this.replyingMessage,
        idFront: uid()
      }

      if (this.isScheduleDate) {
        message.scheduleDate = this.scheduleDate
      }

      return message
    },
    async enviarMensagem() {
      const ticketId = this.ticketFocado.id

      this.loading = true

      if (this.mensagemRapidaSetada) {
        this.cMostrarEnvioArquivo = false
      }

      const message = !this.cMostrarEnvioArquivo
        ? this.prepararMensagemTexto()
        : this.prepararUploadMedia()

      try {
        if (!this.cMostrarEnvioArquivo && !this.textChat && !this.removeMedia) {
          this.loading = false
          return
        }

        // Verificar o canal e a janela de 24 horas
        if (this.ticketFocado.channel === 'hub_whatsapp') {
          try {
            // Verificar a janela de 24 horas
            const response = await checkMessageWindow({
              ticketId: this.ticketFocado.id
            })

            // Verificar se está fora da janela de 24 horas
            if (!response.data.isWithin24Hours) {
              // Formatar a data da última mensagem para exibição (se existir)
              let lastMessageInfo = ''
              if (response.data.lastMessageDate) {
                const lastMessageDate = new Date(response.data.lastMessageDate)
                const formattedDate = lastMessageDate.toLocaleString()
                lastMessageInfo = `A última mensagem do cliente foi em: ${formattedDate}`
              }

              this.loading = false

              // Mostrar alerta para o usuário
              const confirmSend = await new Promise(resolve => {
                this.$q.dialog({
                  title: this.$t('message_window.out_of_window_title'),
                  message: this.$t('message_window.out_of_window_message', { lastMessageInfo }),
                  ok: this.$t('message_window.understand_continue'),
                  cancel: this.$t('message_window.cancel'),
                  persistent: true
                }).onOk(() => {
                  resolve(true)
                }).onCancel(() => {
                  resolve(false)
                })
              })

              if (!confirmSend) {
                return // Usuário cancelou o envio
              }

              this.loading = true
            }
          } catch (error) {
            console.error('Erro ao verificar janela de 24 horas:', error)
            // Em caso de erro na verificação, continuamos normalmente
          }
        }

        // Continua com o envio da mensagem normalmente
        await EnviarMensagemTexto(ticketId, message)
        this.arquivos = []
        this.textChat = ''
        this.inputText = ''
        this.$emit('update:replyingMessage', null)
        this.abrirFilePicker = false
        this.abrirModalPreviewImagem = false

        setTimeout(() => {
          this.scrollToBottom()
        }, 300)
      } catch (error) {
        this.isRecordingAudio = false
        this.removeMedia = false
        this.mensagemRapidaMedia = ''
        this.mensagemRapidaSetada = false
        this.loading = false
        this.$notificarErro(this.$t('inputmensagem.erro_ocorrido'), error)
        console.error('Erro ao enviar mensagem:', error)
      }

      this.removeMedia = false
      this.mensagemRapidaMedia = ''
      this.mensagemRapidaSetada = false
      this.isRecordingAudio = false
      this.loading = false

      setTimeout(() => {
        this.$refs.inputEnvioMensagem.focus()
      }, 300)
    },
    async handlSendLinkVideo () {
      const ticketId = this.ticketFocado.id
      const link = `https://meet.jit.si/${uid()}/${uid()}`
      let mensagem = link
      const username = localStorage.getItem('username')
      if (username && this.sign) {
        mensagem = this.ticketFocado.channel === 'whatsapp' || this.ticketFocado.channel === 'hub_whatsapp'
          ? `*${username}*:\n${mensagem}`
          : `${username}:\n${mensagem}`
      }

      const sendType = 'user: ' + username

      const message = {
        read: 1,
        fromMe: true,
        mediaUrl: '',
        sendType: sendType,
        body: mensagem,
        scheduleDate: this.isScheduleDate ? this.scheduleDate : null,
        quotedMsg: this.replyingMessage,
        idFront: uid(),
        ticket: this.ticketFocado,
        group: this.ticketFocado.isGroup
      }

      this.loading = true
      try {
        // Verificar o canal e a janela de 24 horas
        const hubChannels = ['hub_whatsapp', 'hub_instagram']
        if (hubChannels.includes(this.ticketFocado.channel)) {
          try {
            // Verificar a janela de 24 horas
            const response = await checkMessageWindow({
              ticketId: this.ticketFocado.id
            })

            // Verificar se está fora da janela de 24 horas
            if (!response.data.isWithin24Hours) {
              // Formatar a data da última mensagem para exibição (se existir)
              let lastMessageInfo = ''
              if (response.data.lastMessageDate) {
                const lastMessageDate = new Date(response.data.lastMessageDate)
                const formattedDate = lastMessageDate.toLocaleString()
                lastMessageInfo = `${this.$t('message_window.ultima_mensagem_cliente', { date: formattedDate })}`
              }

              this.loading = false

              // Mostrar alerta para o usuário
              const confirmSend = await new Promise(resolve => {
                this.$q.dialog({
                  title: this.$t('message_window.out_of_window_title'),
                  message: this.$t('message_window.out_of_window_message', { lastMessageInfo }),
                  ok: this.$t('message_window.understand_continue'),
                  cancel: this.$t('message_window.cancel'),
                  persistent: true
                }).onOk(() => {
                  resolve(true)
                }).onCancel(() => {
                  resolve(false)
                })
              })

              if (!confirmSend) {
                return // Usuário cancelou o envio
              }

              this.loading = true
            }
          } catch (error) {
            console.error('Erro ao verificar janela de 24 horas:', error)
            // Em caso de erro na verificação, continuamos normalmente
          }
        }

        await EnviarMensagemTexto(ticketId, message)
        setTimeout(() => {
          this.scrollToBottom()
        }, 200)
        setTimeout(() => {
          window.open(link, '_blank')
        }, 800)
      } catch (error) {
        this.loading = false
        this.$notificarErro(this.$t('inputmensagem.erro_ocorrido'), error)
      }
      this.loading = false
    },
    handlerInputMensagem (v) {
      this.textChat = v.target.value
    },
    showModalPreviewImagem () {
      this.$nextTick(() => {
        setTimeout(() => {
          this.$refs.qbtnPasteEnvioMensagem.$el.focus()
        }, 20)
      })
    },
    hideModalPreviewImagem () {
      this.arquivos = []
      this.urlMediaPreview = {}
      this.abrirModalPreviewImagem = false
    },
    onRejectedFiles (rejectedEntries) {
      if (!rejectedEntries.length) return

      let message

      if (this.ticketFocado.channel === 'hub_whatsapp') {
        const entry = rejectedEntries[0]

        if (entry.failedPropValidation === 'file-too-big') {
          message = this.$t('inputmensagem.erro_tamanho_arquivo_geral')
        } else {
          message = this.$t('inputmensagem.erro_arquivo_whatsapp')
        }
      } else if (this.ticketFocado.channel === 'hub_instagram') {
        message = this.$t('inputmensagem.erro_arquivo_instagram')
      } else {
        message = this.$t('inputmensagem.erro_arquivo_geral')
      }

      this.$q.notify({
        html: true,
        message: message,
        type: 'negative',
        progress: true,
        position: 'top',
        actions: [{
          icon: 'close',
          round: true,
          color: 'white'
        }]
      })
    },
    validarArquivoTamanho (files) {
      if (!files || !files.length || this.ticketFocado.channel !== 'hub_whatsapp') {
        return
      }

      const invalidFiles = []

      files.forEach(file => {
        let maxSize = 26214400 // 25MB padrão

        // Verificar o tipo de arquivo
        if (/^video\/|\.mp4$|\.avi$|\.mov$|\.wmv$|\.flv$|\.mkv$/i.test(file.type || file.name)) {
          maxSize = 16777216 // 16MB para vídeos
        } else if (/^audio\/|\.mp3$|\.wav$|\.ogg$|\.m4a$|\.aac$/i.test(file.type || file.name)) {
          maxSize = 16777216 // 16MB para áudios
        } else if (/^image\/|\.jpg$|\.jpeg$|\.png$|\.gif$|\.bmp$|\.webp$/i.test(file.type || file.name)) {
          maxSize = 5242880 // 5MB para imagens
        }

        if (file.size > maxSize) {
          invalidFiles.push({
            file,
            maxSize: Math.floor(maxSize / (1024 * 1024))
          })
        }
      })

      if (invalidFiles.length > 0) {
        // Remover arquivos inválidos
        this.arquivos = this.arquivos.filter(file => {
          return !invalidFiles.some(invalid => invalid.file.name === file.name)
        })

        // Mostrar mensagem de erro
        const fileInfo = invalidFiles[0]
        const message = this.$t('inputmensagem.erro_tamanho_arquivo', {
          fileName: fileInfo.file.name,
          fileSize: (fileInfo.file.size / (1024 * 1024)).toFixed(2),
          maxSize: fileInfo.maxSize
        })

        this.$q.notify({
          html: true,
          message: message,
          type: 'negative',
          progress: true,
          position: 'top',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      }
    },
    onResize() {
      this.$forceUpdate()
    },
    calculateEmojisByRow() {
      const screenWidth = window.innerWidth
      if (screenWidth < 600) {
        return 5
      } else if (screenWidth >= 600 && screenWidth < 1200) {
        return 10
      } else {
        return 20
      }
    },
    getBadgeClass(index) {
      const colors = ['bg-green-6', 'bg-orange-6', 'bg-teal-6', 'bg-blue-6', 'bg-deep-purple-6', 'bg-yellow-6', 'bg-brown-6', 'bg-cyan-6']
      const colorIndex = index % 8
      // console.log(index);
      return colors[colorIndex]
    },
    handleSign (state) {
      this.sign = state
      LocalStorage.set('sign', this.sign)
    },
    async handleOpenTemplates() {
      if (!this.ticketFocado?.whatsappId) {
        this.$q.notify({
          message: this.$t('inputtemplate.whatsappnaoidentificado'),
          type: 'negative'
        })
        return
      }

      this.templateCategoryModal = true
      this.loadTemplateCategories()
    },
    async loadTemplateCategories() {
      this.loadingTemplateCategories = true
      this.templateCategories = []

      try {
        const response = await ListarCategoriasTemplates(this.ticketFocado.whatsappId)
        if (response.data && response.data.categories) {
          this.templateCategories = response.data.categories
        } else {
          this.$q.notify({
            message: this.$t('inputtemplate.naofoipossivelcarregartemplates'),
            type: 'warning'
          })
        }
      } catch (error) {
        console.error('Erro ao carregar categorias:', error)
        this.$q.notify({
          message: this.$t('inputtemplate.errocarregarcategorias'),
          type: 'negative'
        })
      } finally {
        this.loadingTemplateCategories = false
      }
    },
    async selectTemplateCategory(category) {
      this.selectedCategory = category
      this.templateCategoryModal = false
      this.templateListModal = true
      this.loadTemplates()
    },
    async loadTemplates() {
      this.loadingTemplates = true
      this.templateList = []
      this.templateSearch = ''

      try {
        const response = await ListarTemplates(this.ticketFocado.whatsappId, this.selectedCategory)
        if (response.data && response.data.templates) {
          this.templateList = response.data.templates
        } else {
          this.$q.notify({
            message: this.$t('inputtemplate.errocarregartemplates'),
            type: 'warning'
          })
        }
      } catch (error) {
        console.error('Erro ao carregar templates:', error)
        this.$q.notify({
          message: this.$t('inputtemplate.errocarregartemplates'),
          type: 'negative'
        })
      } finally {
        this.loadingTemplates = false
      }
    },
    getTemplatePreview(template) {
      if (!template || !template.components) return ''

      const bodyComponent = Array.isArray(template.components)
        ? template.components.find(c => c.type === 'BODY')
        : null

      if (!bodyComponent) return ''

      return bodyComponent.text || ''
    },
    selectTemplate(template) {
      this.selectedTemplate = template
      this.templateListModal = false
      this.templateEditModal = true

      // Extrair os parâmetros
      this.extractTemplateParameters()
    },
    extractTemplateParameters() {
      this.templateParameters = []
      this.templateParamValues = []

      if (!this.selectedTemplate || !this.selectedTemplate.components) return

      const components = Array.isArray(this.selectedTemplate.components)
        ? this.selectedTemplate.components
        : JSON.parse(this.selectedTemplate.components)

      // Se o formato for posicional ({{1}}, {{2}}, etc.)
      if (this.selectedTemplate.parameter_format === 'POSITIONAL') {
        // Encontrar todos os parâmetros do tipo {{N}}
        const bodyComponent = components.find(c => c.type === 'BODY')
        if (!bodyComponent || !bodyComponent.text) return

        const paramMatches = bodyComponent.text.match(/{{(\d+)}}/g) || []
        const params = paramMatches.map(match => {
          // Extrair o número do parâmetro
          const paramNumber = match.replace('{{', '').replace('}}', '')
          return {
            type: 'text',
            position: parseInt(paramNumber),
            example: this.getParameterExample(bodyComponent, paramNumber)
          }
        })

        // Ordenar parâmetros por posição e remover duplicados
        const uniqueParams = [...new Map(params.map(p => [p.position, p])).values()]
        uniqueParams.sort((a, b) => a.position - b.position)

        this.templateParameters = uniqueParams
        this.templateParamValues = new Array(uniqueParams.length).fill('')
      } else {
        // Procurar parâmetros em todos os componentes
        components.forEach(component => {
          if (component.parameters) {
            component.parameters.forEach(param => {
              this.templateParameters.push(param)
              this.templateParamValues.push('')
            })
          }
        })
      }
    },
    getParameterExample(component, paramPosition) {
      if (!component || !component.example || !component.example.body_text) {
        return ''
      }

      try {
        // Tenta acessar o exemplo para esse parâmetro
        const examples = component.example.body_text
        if (examples && examples.length > 0 && examples[0].length >= paramPosition) {
          return examples[0][paramPosition - 1]
        }
      } catch (error) {
        console.error('Erro ao obter exemplo de parâmetro:', error)
      }

      return ''
    },
    getParameterHint(param, index) {
      if (param.example) {
        return `${this.$t('inputtemplate.exemplo')}: ${param.example}`
      }

      return `${this.$t('inputtemplate.parametro')} ${index + 1}`
    },
    getFormattedTemplateBody() {
      if (!this.selectedTemplate || !this.selectedTemplate.components) return ''

      const components = Array.isArray(this.selectedTemplate.components)
        ? this.selectedTemplate.components
        : JSON.parse(this.selectedTemplate.components)

      // Find the body component
      const bodyComponent = components.find(c => c.type === 'BODY')
      if (!bodyComponent || !bodyComponent.text) return ''

      let formattedText = bodyComponent.text

      // Replace parameters based on format type
      if (this.selectedTemplate.parameter_format === 'POSITIONAL') {
        // Replace {{1}}, {{2}}, etc. with the provided values
        this.templateParameters.forEach((param, index) => {
          const paramValue = this.templateParamValues[index] || ''
          // Escape special characters in the parameter marker for the RegExp
          const paramMarker = `\\{\\{${param.position}\\}\\}`
          const regex = new RegExp(paramMarker, 'g')

          formattedText = formattedText.replace(regex, paramValue)
        })
      } else {
        // For named parameters, replace {{parameter_name}} with values
        this.templateParameters.forEach((param, index) => {
          const paramValue = this.templateParamValues[index] || ''
          // Escape special characters in the parameter marker for the RegExp
          const paramMarker = `\\{\\{${param.parameter_name}\\}\\}`
          const regex = new RegExp(paramMarker, 'g')

          formattedText = formattedText.replace(regex, paramValue)
        })
      }

      return formattedText
    },
    async sendTemplate() {
      if (!this.selectedTemplate) return

      this.sendingTemplate = true

      try {
        // Preparar os dados do template conforme formato necessário
        const templateData = {
          name: this.selectedTemplate.name,
          language: { code: this.selectedTemplate.language || 'pt_BR' },
          components: []
        }

        const components = Array.isArray(this.selectedTemplate.components)
          ? this.selectedTemplate.components
          : JSON.parse(this.selectedTemplate.components)

        // Processar componentes do template
        components.forEach(component => {
          const templateComponent = {
            type: component.type.toLowerCase(),
            parameters: []
          }

          // Para botões, adicionar sub_type e index se existirem
          if (component.type === 'BUTTONS' && component.buttons) {
            component.buttons.forEach((button, index) => {
              templateComponent.sub_type = button.type.toLowerCase()
              templateComponent.index = index.toString()
            })
          }

          // Adicionar parâmetros conforme formato
          if (this.selectedTemplate.parameter_format === 'POSITIONAL') {
            // Formato posicional (parâmetros são números)
            if (component.type === 'BODY') {
              this.templateParameters.forEach((param, index) => {
                if (this.templateParamValues[index]) {
                  templateComponent.parameters.push({
                    type: 'text',
                    text: this.templateParamValues[index]
                  })
                }
              })
            }
          } else {
            // Formato nomeado (parâmetros têm nomes)
            if (component.parameters) {
              component.parameters.forEach((param, index) => {
                if (this.templateParamValues[index]) {
                  templateComponent.parameters.push({
                    type: param.type,
                    parameter_name: param.parameter_name,
                    text: this.templateParamValues[index]
                  })
                }
              })
            }
          }

          // Se for cabeçalho com imagem, adicionar a imagem
          if (component.type === 'HEADER' && component.format === 'IMAGE' && this.templateHeaderImage) {
            templateComponent.parameters.push({
              type: 'image',
              image: {
                link: '' // Link will be set by the backend after upload
              }
            })
          }

          // Adicionar componente à lista se tiver parâmetros ou for um componente sem parâmetros (ex: texto simples)
          if (templateComponent.parameters.length > 0 || component.type === 'BODY') {
            templateData.components.push(templateComponent)
          }
        })

        const body = this.getFormattedTemplateBody(true)

        const idFront = uid()

        // Use FormData to handle file uploads
        const formData = new FormData()
        formData.append('idFront', idFront)
        formData.append('body', body)
        formData.append('dataJson', JSON.stringify(templateData))

        // Add file if exists
        if (this.templateHeaderImage) {
          formData.append('templateHeaderImage', this.templateHeaderImage)
        }

        // Enviar o template com o FormData
        await EnviarMensagemTemplate(this.ticketFocado.id, formData)

        // Fechar os modais e limpar os dados
        this.templateEditModal = false
        this.selectedTemplate = null
        this.templateParameters = []
        this.templateParamValues = []
        this.templateHeaderImage = null

        this.$q.notify({
          message: this.$t('inputtemplate.enviartemplatesucesso'),
          type: 'positive'
        })
      } catch (error) {
        console.error('Erro ao enviar template:', error)
        this.$q.notify({
          message: this.$t('inputtemplate.erroenviartemplate'),
          caption: error.message,
          type: 'negative'
        })
      } finally {
        this.sendingTemplate = false
      }
    }
  },
  mounted () {
    this.$root.$on('mensagem-chat:focar-input-mensagem', () => this.$refs.inputEnvioMensagem.focus())
    const self = this
    window.addEventListener('paste', self.handleInputPaste)
    this.listarConfiguracoes()
    this.userProfile = localStorage.getItem('profile')
    if (![null, undefined].includes(LocalStorage.getItem('sign'))) {
      this.handleSign(LocalStorage.getItem('sign'))
    }
  },
  beforeDestroy () {
    const self = this
    window.removeEventListener('paste', self.handleInputPaste)
  },
  destroyed () {
    this.$root.$off('mensagem-chat:focar-input-mensagem')
  }
}
</script>

<style lang="sass" scoped>
@media (max-width: 850px)
  .inputEnvioMensagem,
  .PickerFileMessage
    width: 150px

@media (min-width: 851px), (max-width: 1360px)
  .inputEnvioMensagem,
  .PickerFileMessage
    width: 200px !important

.emoji-picker
  width: 100%

@media (min-width: 600px)
  .emoji-picker
    width: 50vw

</style>
