// --- START OF FILE QueueController.ts ---

import type { Request, Response } from "express";
import * as Yup from "yup";

import AppError from "../errors/AppError"; // Assuming path
import CreateQueueService from "../services/QueueServices/CreateQueueService"; // Assuming path
import ListQueueService from "../services/QueueServices/ListQueueService"; // Assuming path
import DeleteQueueService from "../services/QueueServices/DeleteQueueService"; // Assuming path
import UpdateQueueService from "../services/QueueServices/UpdateQueueService"; // Assuming path
import ListUserQueueService from "../services/QueueServices/ListUserQueueService"; // Assuming path

interface StoreBody {
  queue: string; // Assuming 'queue' is the name/identifier
  // Add other potential fields like color, greetingMessage, etc.
}

interface UpdateBody extends StoreBody {
  isActive: boolean;
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const queueData = { ...req.body } as StoreBody;
  queueData.userId = req.user.id; // Associate with the user creating it
  queueData.tenantId = tenantId; // Assign tenant ID

  const schema = Yup.object().shape({
    queue: Yup.string().required(), // Assuming 'queue' is the primary field
    userId: Yup.number().required(),
    tenantId: Yup.number().required()
    // Add validation for other fields if needed
  });

  try {
    await schema.validate(queueData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const queue = await CreateQueueService(queueData);
  return res.status(201).json(queue);
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const queues = await ListQueueService({ tenantId });
  return res.status(200).json(queues);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const queueData = { ...req.body } as UpdateBody;
  queueData.userId = req.user.id; // Include user ID, maybe for logging or ownership check
  queueData.tenantId = tenantId; // Ensure tenant ID is set

  const schema = Yup.object().shape({
    queue: Yup.string().required(), // Or optional() if name change isn't always required
    isActive: Yup.boolean().required(),
    userId: Yup.number().required()
    // tenantId is implicit
  });

  try {
    await schema.validate(queueData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const { queueId } = req.params;
  const updatedQueue = await UpdateQueueService({
    queueData: queueData, // Pass the validated data
    queueId: queueId // Pass the ID from params (convert to number if needed by service)
  });
  return res.status(200).json(updatedQueue);
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const { queueId } = req.params;

  await DeleteQueueService({ id: queueId, tenantId }); // Pass ID and tenantId
  return res.status(200).json({ message: "Cola eliminada" }); // Traducido "Queue deleted"
};

export const listUserQueues = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId } = req.user;
  const userQueues = await ListUserQueueService({ tenantId, userId });
  return res.status(200).json(userQueues);
};

// --- END OF FILE QueueController.ts ---
