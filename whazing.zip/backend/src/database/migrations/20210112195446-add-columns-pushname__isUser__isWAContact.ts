import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Propiedades comunes para las nuevas columnas booleanas
    const booleanColumnProps = {
      type: DataTypes.BOOLEAN,
      allowNull: true, // Permite nulos
      defaultValue: null
    };

    return Promise.all([
      // Añade la columna 'pushname' (nombre mostrado en WhatsApp) a 'Contacts'
      queryInterface.addColumn("Contacts", "pushname", {
        type: DataTypes.STRING,
        allowNull: true, // Permite nulos
        defaultValue: null
      }),
      // Añade la columna 'isUser' (indica si el contacto es un usuario del sistema) a 'Contacts'
      queryInterface.addColumn("Contacts", "isUser", booleanColumnProps),
      // Añade la columna 'isWAContact' (indica si es un contacto de WhatsApp) a 'Contacts'
      queryInterface.addColumn("Contacts", "isWAContact", booleanColumnProps)
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina las columnas añadidas
    return Promise.all([
      queryInterface.removeColumn("Contacts", "pushname"),
      queryInterface.removeColumn("Contacts", "isUser"),
      queryInterface.removeColumn("Contacts", "isWAContact")
    ]);
  }
};
