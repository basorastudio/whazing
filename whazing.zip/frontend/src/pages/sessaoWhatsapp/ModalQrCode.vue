<template>
  <q-dialog :value="abrirModalQR" @hide="fecharModalQrModal" persistent>
    <q-card class="container-rounded-10">
      <!-- Header -->
      <q-card-section class="q-pb-sm">
        <div class="row items-center justify-between">
          <div class="text-h6 font-family-main">Lea el QRCode o use Código de emparejamiento</div>
          <q-btn round flat color="negative" icon="eva-close" @click="fecharModalQrModal" />
        </div>
      </q-card-section>

      <!-- QR Code Section -->
      <q-card-section class="q-py-sm text-center">
        <div class="qr-container q-mb-sm" :style="$q.dark.isActive ? 'background: white !important' : ''">
          <QrcodeVue v-if="cQrcode" :value="cQrcode" :size="250" level="H" />
        </div>

        <!-- Pairing Code -->
        <div v-if="cParingCode" class="pairing-code q-py-sm" :style="$q.dark.isActive ? 'background: #000 !important' : ''">
          <div class="text-caption q-mb-xs">Código de emparejamiento:</div>
          <div class="text-weight-bold">{{ formatPairingCode(cParingCode) }}</div>
        </div>
        <div v-else class="text-caption">
          ESPERANDO LA LECTURA DEL QRCODE...
        </div>
      </q-card-section>

      <!-- Footer -->
      <q-card-section class="q-pt-none">
        <div class="text-caption q-mb-sm">Si tiene problemas para conectarse, solicite un nuevo QRCode</div>
        <div class="row justify-center">
          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
            label="Nuevo QR Code"
            @click="solicitarQrCode"
            icon="mdi-qrcode" />
        </div>
      </q-card-section>
    </q-card>
  </q-dialog>
</template>

<script>

import QrcodeVue from 'qrcode.vue'

export default {
  name: 'ModalQrCode',
  components: {
    QrcodeVue
  },
  props: {
    abrirModalQR: {
      type: Boolean,
      default: false
    },
    channel: {
      type: Object,
      default: () => ({
        id: null,
        qrcode: ''
      })
    }
  },
  watch: {
    channel: {
      handler (v) {
        if (this.channel.status === 'CONNECTED') {
          this.fecharModalQrModal()
        }
      },
      deep: true
    }
  },
  computed: {
    cQrcode () {
      return this.channel.qrcode
    },
    cParingCode () {
      return this.channel.pairingCode
    }
  },
  methods: {
    formatPairingCode(code) {
      // Añade espacios cada 4 caracteres para mejor legibilidad
      return code?.match(/.{1,4}/g)?.join('-') || code
    },
    solicitarQrCode () {
      this.$emit('gerar-novo-qrcode', this.channel)
      this.fecharModalQrModal()
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    },
    fecharModalQrModal () {
      this.$emit('update:abrirModalQR', false)
    }
  }
}
</script>

<style lang="scss" scoped>
.qr-container {
  padding: 1rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  display: inline-block;
}

.pairing-code {
  background: #f5f5f5;
  border-radius: 4px;
  padding: 0.5rem;
  margin: 0 1rem;
}

.text-caption {
  font-size: 0.875rem;
}
</style>
