export const easyFlowMixin = {
  data () {
    return {
      jsplumbSetting: {
        // Anclas dinámicas, posición adaptable
        Anchors: ['Top', 'TopCenter', 'TopRight', 'TopLeft', 'Right', 'RightMiddle', 'Bottom', 'BottomCenter', 'BottomRight', 'BottomLeft', 'Left', 'LeftMiddle'],
        // ID del contenedor
        Container: 'efContainer',
        // Estilo de la conexión, línea recta o curva, opciones: StateMachine, Flowchart, Bezier, Straight
        Connector: ['Bezier', { curviness: 100 }],
        // El mouse no puede arrastrar para eliminar la línea
        ConnectionsDetachable: false,
        // Al borrar la línea, no se eliminan los nodos
        DeleteEndpointsOnDetach: false,
        /**
         * Tipo de puntos finales en ambos extremos de la conexión: circular
         * radius: Radio del círculo, cuanto mayor, mayor el círculo
         */
        // Endpoint: ['Dot', {radius: 5, cssClass: 'ef-dot', hoverClass: 'ef-dot-hover'}],
        /**
         * Tipo de puntos finales en ambos extremos de la conexión: rectangular
         * height: Altura del rectángulo
         * width: Ancho del rectángulo
         */
        // Endpoint: ['Rectangle', {height: 20, width: 20, cssClass: 'ef-rectangle', hoverClass: 'ef-rectangle-hover'}],
        /**
         * Punto final de la imagen
         */
        // Endpoint: ['Image', {src: 'https://www.easyicon.net/api/resizeApi.php?id=1181776&size=32', cssClass: 'ef-img', hoverClass: 'ef-img-hover'}],
        /**
         * Punto final en blanco
         */
        Endpoint: ['Blank', { Overlays: '' }],
        // Endpoints: [['Dot', {radius: 5, cssClass: 'ef-dot', hoverClass: 'ef-dot-hover'}], ['Rectangle', {height: 20, width: 20, cssClass: 'ef-rectangle', hoverClass: 'ef-rectangle-hover'}]],
        /**
         * Estilo de los puntos finales de la conexión
         * fill: Valor de color, por ejemplo: #12aabb, no se muestra si está vacío
         * outlineWidth: Ancho del borde
         */
        EndpointStyle: { fill: '#1879ffa1', outlineWidth: 1 },
        // Habilitar el registro interno de jsPlumb
        LogEnabled: true,
        /**
         * Estilo de la conexión
         */
        PaintStyle: {
          // Color de la línea
          stroke: '#5c67f2',
          // Grosor de la línea, cuanto mayor el valor, más gruesa
          strokeWidth: 1,
          // Establece el color del borde, por defecto es transparente, de modo que no se ve; sirve para ampliar el área de clic (ver: https://blog.csdn.net/roymno2/article/details/72717101)
          outlineStroke: 'transparent',
          // Ancho del borde de la línea, cuanto mayor el valor, mayor el área de clic
          outlineWidth: 10
        },
        DragOptions: { cursor: 'pointer', zIndex: 2000 },
        /**
         * Superposiciones. Referencia: https://www.jianshu.com/p/d9e9918fd928
         */
        Overlays: [
          // Flecha superpuesta
          ['Arrow', {
            // Ancho de la base de la flecha
            width: 10,
            // Distancia de la base a la punta de la flecha
            length: 8,
            // Posición, se recomienda usar entre 0 y 1
            location: 1,
            // Dirección, por defecto es 1 (hacia adelante), opción -1 (hacia atrás)
            direction: 1,
            // Ángulo de plegado, es decir, el ángulo de la aleta; por defecto 0.623, y si es 1 forma un triángulo equilátero
            foldback: 0.623
          }],
          // ['Diamond', {
          //     events: {
          //         dblclick: function (diamondOverlay, originalEvent) {
          //             console.log('double click on diamond overlay for : ' + diamondOverlay.component)
          //         }
          //     }
          // }],
          ['Label', {
            label: '',
            location: 0.1,
            cssClass: 'aLabel'
          }]
        ],
        // Modo de renderización: svg, canvas
        RenderMode: 'svg',
        // Estilo de la línea al pasar el mouse por encima
        HoverPaintStyle: { stroke: '#5c67f2', strokeWidth: 1 },
        // Efecto al pasar sobre el ancla
        // EndpointHoverStyle: {fill: 'red'}
        // Ámbito, solo se pueden conectar los puntos con el mismo scope
        Scope: 'jsPlumb_DefaultScope'
      },
      /**
       * Parámetros de conexión
       */
      jsplumbConnectOptions: {
        isSource: true,
        isTarget: true,
        // Ancla dinámica, ofrece 4 direcciones: Continuous, AutoDefault
        anchor: 'Continuous',
        // Establece el estilo de la etiqueta en la línea
        labelStyle: {
          cssClass: 'flowLabel'
        },
        // Se modificó el código fuente de jsPlumb, soporta etiqueta vacía con estilo personalizado
        emptyLabelStyle: {
          cssClass: 'emptyFlowLabel'
        }
      },
      /**
       * Parámetros de configuración del origen
       */
      jsplumbSourceOptions: {
        // Establece la clase para arrastrar; al pasar el ratón sobre el elemento, se activa la conexión
        filter: '.flow-node-drag',
        filterExclude: false,
        anchor: 'Continuous',
        // Permitir que se conecte a sí mismo
        allowLoopback: true,
        maxConnections: -1,
        onMaxConnections: function (info, e) {
          console.log(`超过了最大值连线: ${info.maxConnections}`)
        }
      },
      // Referencia: https://www.cnblogs.com/mq0036/p/7942139.html
      jsplumbSourceOptions2: {
        // Establece la clase para arrastrar; al pasar el ratón sobre el elemento, se activa la conexión
        filter: '.flow-node-drag',
        filterExclude: false,
        // Permitir que se conecte a sí mismo
        allowLoopback: true,
        connector: ['Flowchart', { curviness: 50 }],
        connectorStyle: {
          // Color de la línea
          stroke: 'red',
          // Grosor de la línea, cuanto mayor el valor, más gruesa
          strokeWidth: 1,
          // Establece el color del borde, por defecto es transparente, de modo que no se ve; sirve para ampliar el área de clic (ver: https://blog.csdn.net/roymno2/article/details/72717101)
          outlineStroke: 'transparent',
          // Ancho del borde de la línea, cuanto mayor el valor, mayor el área de clic
          outlineWidth: 10
        },
        connectorHoverStyle: { stroke: 'red', strokeWidth: 2 }
      },
      jsplumbTargetOptions: {
        // Establece la clase para arrastrar; al pasar el ratón sobre el elemento, se activa la conexión
        filter: '.flow-node-drag',
        filterExclude: false,
        // Permitir que se conecte a sí mismo
        anchor: 'Continuous',
        allowLoopback: true,
        dropOptions: { hoverClass: 'ef-drop-hover' }
      }
    }
  }
}
