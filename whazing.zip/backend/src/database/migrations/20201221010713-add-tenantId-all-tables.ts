import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Define las propiedades de la columna tenantId
    const tenantIdColumn = {
      type: DataTypes.INTEGER,
      references: {
        model: 'Tenants', // Referencia a la tabla Tenants
        key: 'id',
      },
      onUpdate: 'CASCADE',
      onDelete: 'restrict', // No permite eliminar un Tenant si tiene registros asociados
      allowNull: false, // No permite nulos
      defaultValue: 1, // Valor predeterminado 1 (posiblemente para tenants existentes antes de la multi-tenancy)
    };

    return Promise.all([
      queryInterface.addColumn('Users', 'tenantId', tenantIdColumn),
      queryInterface.addColumn('Contacts', 'tenantId', tenantIdColumn),
      queryInterface.addColumn('Tickets', 'tenantId', tenantIdColumn),
      queryInterface.addColumn('Whatsapps', 'tenantId', tenantIdColumn),
      queryInterface.addColumn('Settings', 'tenantId', tenantIdColumn),
      queryInterface.addColumn('Queues', 'tenantId', tenantIdColumn),
      queryInterface.addColumn('AutoReply', 'tenantId', tenantIdColumn),
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      queryInterface.removeColumn('Users', 'tenantId'),
      queryInterface.removeColumn('Contacts', 'tenantId'),
      queryInterface.removeColumn('Tickets', 'tenantId'),
      queryInterface.removeColumn('Whatsapps', 'tenantId'),
      queryInterface.removeColumn('Settings', 'tenantId'),
      queryInterface.removeColumn('Queues', 'tenantId'),
      queryInterface.removeColumn('AutoReply', 'tenantId'),
    ]);
  }
};