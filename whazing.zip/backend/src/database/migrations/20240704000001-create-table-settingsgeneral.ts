import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'SettingsGeneral' table
    await queryInterface.createTable(
      "SettingsGeneral", // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false
        },
        key: {
          type: DataTypes.STRING,
          allowNull: false
          // Consider adding unique: true if keys should be unique
        },
        value: {
          type: DataTypes.TEXT, // TEXT allows for longer setting values
          allowNull: false
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        }
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'SettingsGeneral' table
    await queryInterface.dropTable("SettingsGeneral");
  }
};

export = migration;
