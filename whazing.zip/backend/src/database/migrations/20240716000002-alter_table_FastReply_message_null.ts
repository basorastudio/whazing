import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Change the 'message' column in 'FastReply' to allow NULL values
    await queryInterface.changeColumn(
      'FastReply', // Table name
      'message',   // Column name to change
      {
        type: DataTypes.TEXT, // Keep the type as TEXT
        allowNull: true,      // Change allowNull to true
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Revert the 'message' column in 'FastReply' to NOT allow NULL values
    // Note: This might fail if there are actual NULL values in the column.
    // A production migration might need to handle existing NULLs first (e.g., update to empty string).
    await queryInterface.changeColumn(
      'FastReply', // Table name
      'message',   // Column name to change
      {
        type: DataTypes.TEXT, // Keep the type as TEXT
        allowNull: false,     // Change allowNull back to false
      }
    );
  }
};

export = migration;