import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'transcriptionResponder' column to the 'Whatsapps' table
    // Flag to enable/disable transcription replies (likely in individual chats).
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "transcriptionResponder", // New column name
      {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false // Original had false
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'transcriptionResponder' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      "Whatsapps", // Table name
      "transcriptionResponder" // Column name to remove
    );
  }
};

export = migration;
