import { Response } from "express"; // Assuming Express response object

export const SendRefreshToken = (res: Response, token: string): void => {
  res.cookie(
    "jrt", // Cookie name (kept original 'jrt')
    token,
    {
      httpOnly: true // Cookie is not accessible via client-side script
      // secure: process.env.NODE_ENV === 'production', // Send only over HTTPS in production
      // sameSite: 'lax', // Or 'strict' or 'none' depending on requirements
      // path: '/', // Cookie is valid for the entire site
      // maxAge: 1000 * 60 * 60 * 24 * 7 // Example: 7 days expiration
    }
  );
};

export default SendRefreshToken;
