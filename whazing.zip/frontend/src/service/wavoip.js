import request from 'src/service/request'

export function CriarLogWavoip (data) {
  return request({
    url: '/logWavoip/',
    method: 'post',
    data
  })
}

export function ListarLogsWavoip (params) {
  return request({
    url: '/logWavoip/',
    method: 'get',
    params
  })
}
