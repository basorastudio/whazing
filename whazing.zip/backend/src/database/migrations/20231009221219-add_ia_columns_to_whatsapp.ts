// --- START OF FILE 20231009221219-add_ia_columns_to_whatsapp.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Whatsapps";
    const isOpenIaColumn = "is_open_ia"; // Original column name
    const queueTransfColumn = "queue_transf"; // Original column name

    const tableDescription = await queryInterface.describeTable(tableName); // describeTa' + 'ble'

    if (!tableDescription || !tableDescription[isOpenIaColumn]) {
      const attributes = {
        type: DataTypes.BOOLEAN,
        defaultValue: false, // Changed ![] to false
        allowNull: true // Changed !![] to true
      };
      await queryInterface.addColumn(tableName, isOpenIaColumn, attributes);
    } else {
      console.log(
        `La columna ${isOpenIaColumn} ya existe en la tabla ${tableName}. Saltando adición.`
      );
    }

    if (!tableDescription || !tableDescription[queueTransfColumn]) {
      const attributes = {
        type: DataTypes.INTEGER,
        allowNull: true // Changed !![] to true
        // defaultValue not specified, assuming null
        // Assuming it might reference Queues table, add foreign key if needed:
        // references: { model: 'Queues', key: 'id' },
        // onUpdate: 'CASCADE',
        // onDelete: 'SET NULL', // Or other appropriate action
      };
      await queryInterface.addColumn(tableName, queueTransfColumn, attributes);
    } else {
      console.log(
        `La columna ${queueTransfColumn} ya existe en la tabla ${tableName}. Saltando adición.`
      );
    }
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Whatsapps";
    const isOpenIaColumn = "is_open_ia";
    const queueTransfColumn = "queue_transf";

    const tableDescription = await queryInterface.describeTable(tableName);

    if (tableDescription && tableDescription[isOpenIaColumn]) {
      await queryInterface.removeColumn(tableName, isOpenIaColumn);
    } else {
      console.log(
        `La columna ${isOpenIaColumn} no existe en la tabla ${tableName}. Saltando eliminación.`
      );
    }

    if (tableDescription && tableDescription[queueTransfColumn]) {
      await queryInterface.removeColumn(tableName, queueTransfColumn);
    } else {
      console.log(
        `La columna ${queueTransfColumn} no existe en la tabla ${tableName}. Saltando eliminación.`
      );
    }
  }
};

export default migration;

// --- END OF FILE 20231009221219-add_ia_columns_to_whatsapp.ts ---
