'use strict';

import { logger } from "../utils/logger";
import Message from "../models/Message";
import Ticket from "../models/Ticket";
import Whatsapp from "../models/Whatsapp";
import Contact from "../models/Contact";
import socketEmit from "../helpers/socketEmit";
import axios from "axios";
import AppError from "../errors/AppError"; // Asumiendo que tienes un archivo para errores personalizados

// Opciones para el trabajo de la cola (ejemplo con Bull)
const jobOptions = {
    attempts: 3, // Número máximo de reintentos
    backoff: { type: 'fixed' as 'fixed', delay: 60000 } // Retraso fijo de 60 segundos
};

const queueOptions = {
    removeOnComplete: true, // Elimina el trabajo al completar
    // removeOnFail: false, // Mantener si falla para inspección
    jobId: "sendMessageWWebJS", // Podría ser dinámico
    ...jobOptions
};

interface WWebJSData {
    wabaMediaId: string; // ID del mensaje de WABA usado como referencia
    tenantId: number; // ID del tenant
    // Otros datos necesarios pueden ir aquí
}

export default {
    key: "sendMessageWWebJS", // Clave única para este tipo de trabajo
    options: queueOptions,

    async handle({ data }: { data: WWebJSData }): Promise<void> {
        const { wabaMediaId, tenantId } = data; // Asumiendo que tenantId viene en data

        logger.info("=== INICIANDO JOB sendMessageWWebJS ===");
        logger.info(` Data recebida no banco de dados com erro: Status: ${wabaMediaId}`);

        try {
            // Buscar el mensaje original por el ID de WABA (wabaMediaId)
            const message = await Message.findOne({
                where: { id: wabaMediaId }, // Asumiendo wabaMediaId es el ID único del mensaje
                include: [
                    {
                        model: Ticket,
                        as: 'ticket', // Alias definido en la asociación del modelo
                        include: [{ model: Whatsapp, as: 'whatsapp' }] // Incluir WhatsApp asociado al Ticket
                    }
                ]
            });

            if (!message) {
                logger.info("ERRO: Mensagem não encontrada no banco de dados!");
                return; // No se puede procesar si el mensaje no existe
            }

            if (!message.ticket) {
                logger.info("ERRO: Ticket não encontrado para a mensagem!");
                return; // Necesita el ticket para obtener info de contacto y WhatsApp
            }

            if (!message.ticket.contactId) {
                logger.info("ERRO: Contato não encontrado no ticket!");
                return; // Necesita el ID de contacto
            }

            const contact = await Contact.findByPk(message.ticket.contactId);
            if (!contact) {
                 logger.info(`ERRO: O contato não encontrado para o ticket: ${message.ticketId}`);
                 return;
            }

            if (!message.ticket.whatsapp) {
                 logger.info("ERRO: WhatsApp não encontrado para o ticket!");
                 return;
            }

             // Verificar si las credenciales de la API están configuradas
            if (
                 message.ticket.whatsapp.status === "CONNECTED" &&
                 message.ticket.whatsapp.urlapiwwjs &&
                 message.ticket.whatsapp.apikeyapiwwjs
            ) {
                const urlApi = message.ticket.whatsapp.urlapiwwjs;
                const apiKey = message.ticket.whatsapp.apikeyapiwwjs;
                const contactNumber = contact.number; // Número del contacto

                // URL completa para enviar mensajes de texto
                const sendTextUrl = `${urlApi}/client/sendMessage/${message.ticket.whatsappId}`;

                // Datos para la API WWebJS
                let payload: any = {
                     chatId: `${contactNumber}@c.us`, // Formato estándar para WWebJS
                     contentType: message.mediaType || 'chat', // Tipo de contenido
                     content: message.body || '', // Cuerpo del mensaje
                };

                // Añadir media si existe
                if (message.mediaUrl && (message.mediaType && message.mediaType !== 'chat')) {
                    payload = {
                         ...payload,
                         media: {
                              mimetype: message.mediaType, // Usar mediaType como mimetype
                              url: message.mediaUrl,
                              filename: message.mediaName || `media_${Date.now()}`, // Nombre de archivo
                         },
                         options: {
                             caption: message.body || '', // Usar body como caption
                         }
                    };
                     // Usar la URL para enviar media si es diferente
                    // sendMediaUrl = `${urlApi}/client/sendMedia/${message.ticket.whatsappId}`;
                    // urlToUse = sendMediaUrl;
                }
                 // else {
                 //     urlToUse = sendTextUrl;
                 // }

                try {
                    const headers = { 'x-api-key': apiKey };
                    const response = await axios.post(sendTextUrl, payload, { headers }); // Siempre POST para texto/media ahora

                    if (response.status === 200 && response.data.success) {
                         // Actualizar ACK del mensaje en la base de datos
                        const newAck = 3; // ACK para mensaje enviado/recibido por el destinatario (ejemplo)
                        await message.update({
                             ack: newAck,
                             dataJson: JSON.stringify(response.data) // Guardar respuesta de la API
                        });

                        // Emitir evento de socket para actualizar UI
                        socketEmit({
                             tenantId: message.tenantId,
                             type: 'chat:ack', // Evento específico para ACK
                             payload: message // Enviar mensaje actualizado
                        });

                         logger.info(` Resposta com sucesso: Status: ${response.status}, Success: ${response.data.success}, Mensagem: ${response.data.message || 'Sem mensagem'}`);
                    } else {
                         logger.info(` Resposta com erro: Status: ${response.status}, Success: ${response.data.success}, Mensagem: ${response.data.message || 'Sem mensagem'}`);
                         // Podrías querer lanzar un error aquí para reintentar si la respuesta no fue exitosa
                         // throw new Error(`API WWebJS respondió con status ${response.status}`);
                    }

                } catch (axiosError: any) {
                     logger.error(` ERRO NA REQUISIÇÃO AXIOS: ${axiosError.message}`);
                     if (axiosError.response) {
                          logger.error(` Status da resposta: ${axiosError.response.status}`);
                          logger.error(` Dados da resposta: ${JSON.stringify(axiosError.response.data)}`);
                     }
                     throw axiosError; // Re-lanzar para reintentos de Bull
                }

            } else {
                 logger.info(` ERRO: WhatsApp não está conectado ou API WWebJS não configurada. Status: ${message.ticket.whatsapp.status}, APIKey presente: ${!!message.ticket.whatsapp.apikeyapiwwjs}, URL presente: ${!!message.ticket.whatsapp.urlapiwwjs}`);
                 // No lanzar error aquí, ya que es un problema de configuración/estado, no transitorio
            }

        } catch (err: any) {
            logger.error(`Error enviar message WWebJS: ${err.message}`);
             // Capturar la excepción con Sentry
            Sentry.captureException(err);
            throw err; // Re-lanzar para que Bull maneje los reintentos/fallo
        }

        logger.info("=== FIM DO JOB sendMessageWWebJS ===");
    }
};