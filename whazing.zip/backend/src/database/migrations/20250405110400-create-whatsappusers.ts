import { QueryInterface, DataTypes, Sequelize } from "sequelize"; // Added Sequelize
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "WhatsappUsers";
    // Create the 'WhatsappUsers' join table
    await queryInterface.createTable(tableName, {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      whatsappId: {
        type: DataTypes.INTEGER,
        references: { model: "Whatsapps", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE", // If Whatsapp is deleted, remove association
        allowNull: false
      },
      userId: {
        type: DataTypes.INTEGER,
        references: { model: "Users", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE", // If User is deleted, remove association
        allowNull: false
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn("NOW") // Use DB default timestamp
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn("NOW") // Use DB default timestamp
      }
    });

    // Add a unique constraint/index on the combination of whatsappId and userId
    await queryInterface.addIndex(tableName, ["whatsappId", "userId"], {
      unique: true,
      name: "unique_whatsapp_user" // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'WhatsappUsers' table (indexes are dropped automatically)
    await queryInterface.dropTable("WhatsappUsers");
  }
};

export = migration;
