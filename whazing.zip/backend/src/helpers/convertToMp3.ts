// Original: convertToMp3.js
// Deobfuscated, converted to TS, and translated

'use strict';

import { Worker, isMainThread, parentPort, workerData } from 'worker_threads';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegStatic from 'ffmpeg-static'; // Usar el path desde ffmpeg-static
import fs from 'fs';
import path from 'path';

// Configura la ruta del ejecutable de ffmpeg
if (ffmpegStatic) {
    ffmpeg.setFfmpegPath(ffmpegStatic);
} else {
    console.error("ffmpeg-static path not found. Conversion might fail.");
}


// Define el tipo para los datos pasados al worker
interface WorkerData {
    inputFile: string;
    outputFile: string;
}

// Define el tipo para los mensajes enviados desde el worker
type WorkerMessage =
  | { type: 'progress'; data: number }
  | { type: 'complete' }
  | { type: 'error'; error: string };

// Función principal de conversión (puede ser llamada por el worker o el hilo principal)
async function convertFileToMp3(inputFile: string, outputFile: string): Promise<void> {
    // Verifica si el archivo de entrada existe
    if (!fs.existsSync(inputFile)) {
        // Traducido: Archivo de entrada no encontrado
        const errorMsg = `Input file not found: ${inputFile}`;
         if (parentPort) {
             parentPort.postMessage({ type: 'error', error: errorMsg } as WorkerMessage);
         }
        throw new Error(errorMsg);
    }

     // Verifica si el formato de entrada es soportado (ogg o mp4)
    const inputFileExtension = path.extname(inputFile).toLowerCase();
    if (!['.ogg', '.mp4'].includes(inputFileExtension)) {
        // Traducido: Formato de archivo de entrada no soportado. Use .ogg o .mp4
        const errorMsg = `Input file format not supported. Use .ogg or .mp4: ${inputFileExtension}`;
         if (parentPort) {
             parentPort.postMessage({ type: 'error', error: errorMsg } as WorkerMessage);
         }
        throw new Error(errorMsg);
    }


    return new Promise((resolve, reject) => {
        ffmpeg(inputFile)
            .toFormat('mp3') // Especifica formato de salida mp3
            .audioBitrate(128) // Establece bitrate de audio (ej. 128k)
            .on('progress', (progress: { percent?: number }) => {
                if (progress.percent && parentPort) {
                    parentPort.postMessage({ type: 'progress', data: Math.round(progress.percent) } as WorkerMessage);
                }
            })
            .on('end', () => {
                if (parentPort) {
                    parentPort.postMessage({ type: 'complete' } as WorkerMessage);
                }
                resolve();
            })
            .on('error', (err: Error) => {
                 // Traducido: Error desconocido en la conversión
                const errorMessage = err instanceof Error ? err.message : 'Unknown conversion error';
                console.error("Error during conversion:", errorMessage);
                if (parentPort) {
                    parentPort.postMessage({ type: 'error', error: errorMessage } as WorkerMessage);
                }
                reject(new Error(errorMessage));
            })
            .save(outputFile); // Guarda el archivo de salida
    });
}


// Función exportada que maneja la lógica del worker
export async function convertToMp3(inputFile: string): Promise<string> {

    // Verifica si el archivo de entrada existe
    if (!fs.existsSync(inputFile)) {
         // Traducido: Archivo de entrada no encontrado
        console.error(`Input file not found: ${inputFile}`);
        throw new Error('Input file not found.');
    }

    // Verifica si el formato de entrada es soportado (ogg o mp4)
    const inputFileExtension = path.extname(inputFile).toLowerCase();
    if (!['.ogg', '.mp4'].includes(inputFileExtension)) {
         // Traducido: Formato de archivo de entrada no soportado. Use .ogg o .mp4
        console.error(`Input file format not supported. Use .ogg or .mp4: ${inputFileExtension}`);
        throw new Error('Input file format not supported. Use .ogg or .mp4.');
    }

    // Genera el nombre del archivo de salida
    const outputFile = inputFile.replace(/\.(ogg|mp4)$/i, '.mp3');

    if (isMainThread) {
        // Si está en el hilo principal, crea un worker
        return new Promise((resolve, reject) => {
            const worker = new Worker(__filename, {
                workerData: { inputFile, outputFile } as WorkerData
            });

            worker.on('message', (message: WorkerMessage) => {
                switch (message.type) {
                    case 'complete':
                        resolve(outputFile); // Resuelve con la ruta del archivo de salida
                        break;
                    case 'error':
                         // Traducido: Error en el Worker
                        reject(new Error(`Worker error: ${message.error}`));
                        break;
                    case 'progress':
                        // Opcional: Manejar el progreso si es necesario en el hilo principal
                        // console.log(`Conversion progress: ${message.data}%`);
                        break;
                }
            });

            worker.on('error', (err) => {
                 // Traducido: Error fatal en el Worker
                reject(new Error(`Fatal worker error: ${err.message}`));
            });

            worker.on('exit', (code) => {
                if (code !== 0) {
                     // Traducido: Worker parado con código
                    reject(new Error(`Worker stopped with exit code ${code}`));
                }
            });
        });
    } else {
         // Si está en el worker thread, ejecuta la conversión directamente
         // Nota: El código original no tenía lógica explícita aquí para devolver
         // el path desde el worker, se asumirá que el worker solo comunica estado.
         // El hilo principal resolverá la promesa basado en mensajes.
        try {
            const { inputFile: workerInput, outputFile: workerOutput } = workerData as WorkerData;
            await convertFileToMp3(workerInput, workerOutput);
             // El mensaje 'complete' se envía desde convertFileToMp3
        } catch (error: any) {
            console.error("Error in worker:", error);
             // El mensaje 'error' se envía desde convertFileToMp3
        }
        // No retornar explícitamente aquí, la comunicación es vía mensajes
        return Promise.resolve(outputFile); // Devolver algo para satisfacer tipo (aunque no se use)
    }
}


// Ejecuta la conversión si este script se corre como worker
if (!isMainThread) {
    const { inputFile: workerInput, outputFile: workerOutput } = workerData as WorkerData;
    convertFileToMp3(workerInput, workerOutput)
        .then(() => {
            // 'complete' message is sent inside convertFileToMp3
            // console.log("Worker finished successfully.");
        })
        .catch(error => {
            console.error("Worker conversion failed:", error);
             // 'error' message is sent inside convertFileToMp3
             // process.exit(1); // Consider exiting with error code
        });
}