import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'media' column to the 'FastReply' table
    await queryInterface.addColumn(
      'FastReply', // Table name
      'media',     // New column name
      {
        type: DataTypes.TEXT, // TEXT allows for longer media URLs or potentially base64 data
        allowNull: true,      // Allow null values
        defaultValue: '',      // Default is an empty string
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'media' column from the 'FastReply' table
    await queryInterface.removeColumn(
      'FastReply', // Table name
      'media'      // Column name to remove
    );
  }
};

export = migration;