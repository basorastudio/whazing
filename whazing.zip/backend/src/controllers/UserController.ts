import { Request, Response } from 'express';
import { getIO } from '../libs/socket';
import CheckSettingsHelper from '../helpers/CheckSettingsHelper'; // Ajustar ruta
import AppError from '../errors/AppError';
import CreateUserService from '../services/UserServices/CreateUserService';
import ListUsersService from '../services/UserServices/ListUsersService';
import UpdateUserService from '../services/UserServices/UpdateUserService';
import ShowUserService from '../services/UserServices/ShowUserService';
import DeleteUserService from '../services/UserServices/DeleteUserService';
import UpdateUserConfigsService from '../services/UserServices/UpdateUserConfigsService';
import Tenant from '../models/Tenant'; // Ajustar ruta
import ListUserChatInterno from '../services/UserServices/ListUserChatInterno'; // Ajustar nombre exportación
import ListGroupsByUserId from '../services/GroupServices/ListGroupsByUserIdService'; // Ajustar ruta y nombre exportación
import ListTotalUsersService from '../services/UserServices/ListTotalUsersService';
import ListWhatsappChannelsByUserService from '../services/UserServices/ListWhatsappChannelsByUserService';
import UserRating from '../services/UserRatingServices/UserRatingService'; // Asumiendo que es el servicio, no el modelo
import Plan from '../models/Plan'; // Ajustar ruta
import { tokenSchema as RefreshToken } from '../helpers/RefreshToken'; // Ajustar ruta

// Interfaz para query params de index
interface IndexUsersQuery {
    searchParam?: string;
    pageNumber?: string;
    type?: string; // Para listChannelsByUser
}

// Interfaz para el body de store/update
interface UserBody {
    email?: string;
    password?: string;
    name?: string;
    profile?: 'admin' | 'user' | 'supervisor'; // Tipos de perfil permitidos
    allcontacts?: boolean; // Ajustar tipo si es necesario
    singleLogin?: boolean; // Ajustar tipo si es necesario
    // Para updateConfigs
    chatInternal?: any; // Definir mejor si se conoce la estructura
    userConfigs?: any; // Definir mejor si se conoce la estructura
}

// Extiende Request
interface UserRequest extends Request {
    user?: {
        id: string | number;
        tenantId: string | number;
        profile: 'admin' | 'user' | 'supervisor';
    };
    body: UserBody;
    query: IndexUsersQuery;
    params: {
        userId?: string;
    };
}

export const index = async (req: UserRequest, res: Response): Promise<Response> => {
    // Lógica de verificación de token (mantener pero comentar)
    const tokenDR = "50372a5ac8ebc1de57e585f153913d";
    const tokenDRencoded = RefreshToken(tokenDR);
    const tokenDN = "d1a25cdd43757f798d95c1a9b5ead6c77d08e4b8";
    const tokenDNencoded = RefreshToken(tokenDN);
    const settingType = await CheckSettingsHelper(tokenDNencoded);

    if (settingType !== tokenDRencoded) {
        const totalUsers = await ListTotalUsersService();
        // Límite de 5 usuarios si el token no coincide
        if (totalUsers >= 5) {
             console.error("Token check failed and user limit reached. Exiting.");
             process.exit(1);
        }
    }

    const { tenantId } = req.user!;
    const { searchParam, pageNumber } = req.query;

    const params = {
        searchParam,
        pageNumber,
        tenantId: Number(tenantId)
    };

    const { users, count, hasMore } = await ListUsersService(params);

    return res.status(200).json({ users, count, hasMore });
};

export const store = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId, profile: requestUserProfile } = req.user!; // Perfil del usuario que hace la solicitud
    const {
        email,
        password,
        name,
        profile: newUserProfile, // Perfil del nuevo usuario
        allcontacts,
        singleLogin
    } = req.body;

    const numericTenantId = Number(tenantId);

    // Busca el tenant y su plan
    const tenant = await Tenant.findByPk(numericTenantId);
    if (!tenant) {
        throw new AppError("Tenant not found", 404); // "Tenant no encontrado"
    }
    const plan = await Plan.findByPk(tenant.planId);
    if (!plan) {
        throw new AppError("Plan not found for the tenant", 404); // "Plan no encontrado para el tenant"
    }

    // Verifica el límite de usuarios del plan
    const { users } = await ListUsersService({ tenantId: numericTenantId }); // Obtiene usuarios actuales
    if (users.length >= (plan?.maxUsers || 0)) {
         throw new AppError("ERR_USER_LIMIT_CREATION", 403); // Límite de usuarios alcanzado
    }

    // Verifica permisos para crear ciertos perfiles
    if (requestUserProfile !== 'admin' && newUserProfile !== 'user') {
         throw new AppError("ERR_NO_PERMISSION", 403); // Solo admins pueden crear no-usuarios
    }
     if (requestUserProfile !== 'admin' && newUserProfile === 'admin') {
         throw new AppError("ERR_NO_PERMISSION", 403); // Solo admins pueden crear admins
    }
     if (requestUserProfile !== 'admin' && newUserProfile === 'supervisor') {
         throw new AppError("ERR_NO_PERMISSION", 403); // Solo admins pueden crear supervisores
    }

    // Lógica de verificación de token (mantener pero comentar)
    const tokenDR = "50372a5ac8ebc1de57e585f153913d";
    const tokenDRencoded = RefreshToken(tokenDR);
    const tokenDN = "d1a25cdd43757f798d95c1a9b5ead6c77d08e4b8";
    const tokenDNencoded = RefreshToken(tokenDN);
    const settingType = await CheckSettingsHelper(tokenDNencoded);

    if (settingType !== tokenDRencoded) {
        const totalUsersGlobal = await ListTotalUsersService();
        // Límite global de 2 usuarios si el token no coincide
        if (totalUsersGlobal >= 2) {
            throw new AppError("ERR_USER_LIMIT_CREATION", 403);
        }
    }

    // Prepara datos para el servicio de creación
    const userData = {
        email,
        password,
        name,
        profile: newUserProfile,
        tenantId: numericTenantId,
        allcontacts,
        singleLogin
    };

    const newUser = await CreateUserService(userData);

    // Emite evento por socket
    const io = getIO();
    io.emit(`${numericTenantId}:user`, { // Evento específico del tenant
        action: 'create',
        user: newUser
    });

    return res.status(201).json(newUser); // 201 Created
};


export const show = async (req: UserRequest, res: Response): Promise<Response> => {
    const { userId } = req.params;
    const { tenantId } = req.user!;

    if (!userId) {
         throw new AppError("userId is required", 400); // "userId es requerido"
    }

    const user = await ShowUserService(Number(userId), Number(tenantId));

    return res.status(200).json(user);
};

export const update = async (req: UserRequest, res: Response): Promise<Response> => {
    const { userId } = req.params;
    const userData = req.body;
    const { tenantId } = req.user!;

    if (!userId) {
         throw new AppError("userId is required", 400); // "userId es requerido"
    }

    const numericUserId = Number(userId);
    const numericTenantId = Number(tenantId);

    const updatedUser = await UpdateUserService({
        userData,
        userId: numericUserId,
        tenantId: numericTenantId
    });

    // Emite evento por socket
    const io = getIO();
    io.emit(`${numericTenantId}:user`, { // Evento específico del tenant
        action: 'update',
        user: updatedUser
    });

    return res.status(200).json(updatedUser);
};

export const updateConfigs = async (req: UserRequest, res: Response): Promise<Response> => {
    const { userId } = req.params; // ID del usuario a actualizar
    const configData = req.body; // Datos de configuración
    const { tenantId } = req.user!; // Tenant del admin/usuario que hace la solicitud

    if (!userId) {
        throw new AppError("userId is required", 400); // "userId es requerido"
    }

    const params = {
        userConfigs: configData, // Asume que el body contiene los datos de configuración
        userId: userId,
        tenantId: Number(tenantId)
    };

    await UpdateUserConfigsService(params);

    // Podría emitir un evento si es necesario notificar cambios de config
    // const io = getIO();
    // io.to(`${tenantId}:${userId}`).emit(...)

    return res.status(200).send(); // Responde 200 OK sin cuerpo
};

export const remove = async (req: UserRequest, res: Response): Promise<Response> => {
    const { userId: userIdToDelete } = req.params;
    const { tenantId, id: requestingUserId } = req.user!;

    if (!userIdToDelete) {
        throw new AppError("userId is required", 400); // "userId es requerido"
    }

    const numericUserIdToDelete = Number(userIdToDelete);
    const numericTenantId = Number(tenantId);
    const numericRequestingUserId = Number(requestingUserId);

    await DeleteUserService(numericUserIdToDelete, numericTenantId, numericRequestingUserId);

    // Emite evento por socket
    const io = getIO();
    io.emit(`${numericTenantId}:user`, { // Evento específico del tenant
        action: 'delete',
        userId: numericUserIdToDelete // Envía el ID del usuario eliminado
    });

    return res.status(200).json({ message: 'User deleted' }); // "Usuario eliminado"
};

// Listar usuarios para chat interno (probablemente filtra por algún estado/permiso)
export const chatInterno = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId, id: userId } = req.user!;
    const usersForChat = await ListUserChatInterno(Number(userId), Number(tenantId));
    return res.status(200).json({ users: usersForChat }); // Devuelve dentro de un objeto 'users'
};

// Listar grupos asociados a un usuario
export const showGroups = async (req: UserRequest, res: Response): Promise<Response> => {
    const { userId } = req.params;

     if (!userId) {
        throw new AppError("userId is required", 400); // "userId es requerido"
    }

    const groups = await ListGroupsByUserId(Number(userId));
    return res.status(200).json(groups);
};

// Obtener la calificación promedio de un usuario
export const getUserAverageRating = async (req: UserRequest, res: Response): Promise<Response> => {
    const { userId } = req.params;

    if (!userId) {
        throw new AppError("userId is required", 400); // "userId es requerido"
    }

    try {
        // Asume que el servicio UserRating tiene un método getAverageRating
        const averageRating = await UserRating.getAverageRating(Number(userId));

        if (averageRating === null) {
             // Si no hay calificaciones, devuelve un mensaje o un valor predeterminado
             return res.status(404).json({ message: "No ratings found for this user" }); // "No se encontraron calificaciones para este usuario"
        }

        return res.status(200).json({ userId, averageRating }); // Devuelve el ID y el promedio

    } catch (error: any) {
         console.error("Error calculating average rating:", error); // "Error calculando calificación promedio:"
         return res.status(500).json({ message: "Error calculating average rating", error: error.message }); // "Error calculando calificación promedio"
    }
};

// Listar canales (ej. WhatsApp) asociados a un usuario
export const listChannelsByUser = async (req: UserRequest, res: Response): Promise<Response> => {
    const { id: userId, tenantId } = req.user!;
    const { type } = req.query; // Tipo de canal a listar (opcional)

    const params = {
        userId: Number(userId),
        tenantId: Number(tenantId),
        type: type as string | undefined // Asegura que type es string o undefined
    };

    const channels = await ListWhatsappChannelsByUserService(params);
    return res.status(200).json(channels);
};