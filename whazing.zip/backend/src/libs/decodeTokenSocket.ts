import { verify, JwtPayload, Secret } from "jsonwebtoken";
import authConfig from "../config/auth"; // Adjust path as needed
import { logger } from "../utils/logger"; // Adjust path as needed

interface DecodedTokenResult {
  isValid: boolean;
  data: JwtPayload | { id: string; profile: string; tenantId: number | string }; // Define structure of decoded data
}

/**
 * Decodes and verifies a JWT token for socket authentication.
 * @param token - The JWT token string.
 * @returns An object containing validation status and decoded data.
 */
const decode = (token: string | undefined | null): DecodedTokenResult => {
  // Default result for invalid/missing token
  const defaultResult: DecodedTokenResult = {
    isValid: false,
    data: { id: "", profile: "", tenantId: 0 }
  };

  if (!token) {
    return defaultResult;
  }

  try {
    // Verify the token using the secret from auth config
    const decoded = verify(token, authConfig.secret as Secret) as JwtPayload & {
      id: string;
      profile: string;
      tenantId: number | string;
    };

    // Extract necessary data
    const { id, profile, tenantId } = decoded;

    // Return success state with extracted data
    return {
      isValid: true,
      data: { id, profile, tenantId }
    };
  } catch (error: any) {
    // Log the error but return the default invalid result
    logger.error("Error verifying socket token:", error);
    return defaultResult;
  }
};

export default decode; // Export the function directly
