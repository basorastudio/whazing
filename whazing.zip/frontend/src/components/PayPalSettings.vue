<template>
  <div class="paypal-settings q-pa-md">
    <div class="text-h6 q-mb-md">Configuración de PayPal</div>
    <q-form @submit="saveSettings" class="q-gutter-md">
      <q-toggle
        v-model="settings.sandbox"
        label="Modo Sandbox"
        color="primary"
      />

      <q-input
        v-model="settings.clientId"
        label="Client ID"
        :type="showSecrets ? 'text' : 'password'"
        outlined
        :rules="[val => !!val || 'Client ID es requerido']"
      />

      <q-input
        v-model="settings.clientSecret"
        label="Client Secret"
        :type="showSecrets ? 'text' : 'password'"
        outlined
        :rules="[val => !!val || 'Client Secret es requerido']"
      />

      <q-input
        v-model="settings.webhookId"
        label="Webhook ID"
        :type="showSecrets ? 'text' : 'password'"
        outlined
        :rules="[val => !!val || 'Webhook ID es requerido']"
      />

      <div class="row items-center q-gutter-sm">
        <q-btn
          flat
          dense
          :icon="showSecrets ? 'visibility_off' : 'visibility'"
          @click="showSecrets = !showSecrets"
          class="self-end"
        />

        <q-space />

        <q-btn
          type="submit"
          color="primary"
          label="Guardar"
          :loading="saving"
        />
      </div>
    </q-form>
  </div>
</template>

<script>
import { ref } from 'vue';
import { useQuasar } from 'quasar';
import { api } from '../service/api';

export default {
  name: 'PayPalSettings',

  setup() {
    const $q = useQuasar();
    const settings = ref({
      sandbox: false,
      clientId: '',
      clientSecret: '',
      webhookId: ''
    });
    const showSecrets = ref(false);
    const saving = ref(false);

    const loadSettings = async () => {
      try {
        const { data } = await api.get('/paypal/settings');
        settings.value = {
          sandbox: data.sandbox,
          clientId: data.clientId,
          clientSecret: data.clientSecret,
          webhookId: data.webhookId
        };
      } catch (error) {
        console.error('Error al cargar la configuración:', error);
        $q.notify({
          type: 'negative',
          message: 'Error al cargar la configuración de PayPal'
        });
      }
    };

    const saveSettings = async () => {
      saving.value = true;
      try {
        await api.post('/paypal/settings', settings.value);
        $q.notify({
          type: 'positive',
          message: 'Configuración guardada exitosamente'
        });
      } catch (error) {
        console.error('Error al guardar la configuración:', error);
        $q.notify({
          type: 'negative',
          message: 'Error al guardar la configuración de PayPal'
        });
      } finally {
        saving.value = false;
      }
    };

    // Cargar configuración al montar el componente
    loadSettings();

    return {
      settings,
      showSecrets,
      saving,
      saveSettings
    };
  }
};
</script>

<style scoped>
.paypal-settings {
  max-width: 600px;
  margin: 0 auto;
}
</style>