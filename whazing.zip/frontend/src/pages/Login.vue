<template>
  <div class="container">
    <div class="login-section" :class="$q.dark.isActive ? 'bg-black' : ''">
      <q-layout class="full-width">
        <q-page-container>
          <q-page class="flex justify-center items-center">
            <q-ajax-bar
              position="top"
              class="color-light2"
              size="5px"
            />
            <div class="login-content">
              <div class="text-primary">
                <div class="text-h6 color-light1">¡Bienvenido!</div>
                <div>
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                    v-model="form.email"
                    placeholder="sucorreo@email.com"
                    @blur="$v.form.email.$touch"
                    :error="$v.form.email.$error"
                    error-message="Debe ser un email válido."
                    outlined
                    @keypress.enter="fazerLogin"
                  >
                    <template v-slot:prepend>
                      <q-icon
                        name="mdi-email-outline"
                        class="cursor-pointer color-light1"
                      />
                    </template>
                  </q-input>

                  <q-input
                    rounded
                    outlined
                    v-model="form.password"
                    :type="isPwd ? 'password' : 'text'"
                    @keypress.enter="fazerLogin"
                  >
                    <template v-slot:prepend>
                      <q-icon
                        name="mdi-shield-key-outline"
                        class="cursor-pointer color-light1"
                      />
                    </template>
                    <template v-slot:append>
                      <q-icon
                        :name="isPwd ? 'visibility_off' : 'visibility'"
                        class="cursor-pointer color-light1"
                        @click="isPwd = !isPwd"
                      />
                    </template>
                  </q-input>
              <q-btn v-if="habilitasmtpEnabled" flat color="info" no-caps dense class="q-px-sm color-light1" label="Olvidé mi contraseña" @click="modalEsqueciSenha = true" />
                </div>
              <q-btn v-if="allowSignupEnabled" flat color="info" no-caps dense class="q-px-sm color-light1" label="¡Regístrese ahora mismo!" @click="redirecionarParaCadastro" />
                <q-btn
                  class="q-mr-sm q-my-lg generate-button btn-rounded-50"
                  style="width: 150px"
                  :loading="loading"
                  @click="fazerLogin"
                >
                  Entrar
                  <span slot="loading">
                    <q-spinner-puff class="on-left" />Entrando...
                  </span>
                </q-btn>
              </div>
            </div>
          </q-page>
        </q-page-container>
      </q-layout>
    </div>

<!-- Modal de Recuperación de Contraseña -->
<q-dialog v-model="modalEsqueciSenha" persistent>
  <q-card class="q-pa-md" style="max-width: 400px; margin: auto;">
    <q-card-section>
      <div class="row items-center">
        <div class="col text-h6 text-center">Recuperar Contraseña</div>
        <q-btn dense flat round icon="close" @click="modalEsqueciSenha = false" class="modal-close-btn col-auto" />
      </div>
    </q-card-section>
    <q-card-section>
      <q-form @submit.prevent="enviarEmail" class="flex flex-center column">
        <q-input
          rounded
          clearable
          v-model="emailRedefinicao"
          placeholder="sucorreo@email.com"
          @blur="$v.form.email.$touch"
          :error="$v.form.email.$error"
          error-message="Debe ser un email válido."
          outlined
          class="full-width"
        >
          <template v-slot:prepend>
            <q-icon
              name="mdi-email-outline"
              class="cursor-pointer color-light1"
            />
          </template>
        </q-input>
        <q-btn class="q-my-lg generate-button btn-rounded-50" style="width: 150px" type="submit">
          Enviar Email
        </q-btn>
      </q-form>
      <div v-if="showAdditionalFields" class="flex flex-center column">
        <q-input
          rounded
          class="q-mb-md full-width"
          clearable
          v-model="codigoVerificacao"
          label="Código de Verificación"
          outlined
        >
          <template v-slot:prepend>
            <q-icon
              name="mdi-keyboard"
              class="cursor-pointer color-light1"
            />
          </template>
        </q-input>
        <q-input
          rounded
          outlined
          v-model="novaSenha"
          :type="isPwd ? 'password' : 'text'"
          label="Nueva Contraseña"
          class="q-mb-md full-width"
        >
          <template v-slot:prepend>
            <q-icon
              name="mdi-shield-key-outline"
              class="cursor-pointer color-light1"
            />
          </template>
          <template v-slot:append>
            <q-icon
              :name="isPwd ? 'visibility_off' : 'visibility'"
              class="cursor-pointer color-light1"
              @click="isPwd = !isPwd"
            />
          </template>
        </q-input>
        <q-input
          rounded
          outlined
          v-model="confirmarNovaSenha"
          :type="isPwd ? 'password' : 'text'"
          label="Confirmar Nueva Contraseña"
          class="q-mb-md full-width"
        >
          <template v-slot:prepend>
            <q-icon
              name="mdi-shield-key-outline"
              class="cursor-pointer color-light1"
            />
          </template>
          <template v-slot:append>
            <q-icon
              :name="isPwd ? 'visibility_off' : 'visibility'"
              class="cursor-pointer color-light1"
              @click="isPwd = !isPwd"
            />
          </template>
        </q-input>
        <q-btn class="q-my-lg generate-button btn-rounded-50" style="width: 150px" @click="redefinirSenha">
          Restablecer Contraseña
        </q-btn>
      </div>
    </q-card-section>
  </q-card>
</q-dialog>

    <q-btn
      v-if="whatsappNumber"
      fab
      icon="mdi-whatsapp"
      class="whatsapp-float"
      color="green"
      round
      @click="abrirWhatsApp"
    >
      <q-tooltip>
        ¡Solicitar soporte!
      </q-tooltip>
    </q-btn>
  </div>
</template>

<script>
import { required, email } from 'vuelidate/lib/validators'
import { enviarEmailRedefinicao, redefinirSenha } from 'src/service/redifinirsenhas'
import { ListarConfiguracaoPublica, ListarCores } from 'src/service/configuracoesgeneral'

export default {
  name: 'Login',
  data () {
    return {
      modalEsqueciSenha: false,
      emailRedefinicao: '',
      codigoVerificacao: '',
      novaSenha: '',
      confirmarNovaSenha: '',
      showAdditionalFields: false,
      form: {
        email: null,
        password: null
      },
      contasCliente: {},
      isPwd: true,
      loading: false,
      allowSignupEnabled: false,
      habilitasmtpEnabled: false,
      whatsappNumber: null
    }
  },
  validations: {
    form: {
      email: { required, email },
      password: { required }
    },
    emailRedefinicao: { required, email },
    codigoVerificacao: { required },
    novaSenha: { required },
    confirmarNovaSenha: { required }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores devueltos por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    generateMediaUrl() {
      return `${process.env.URL_API}/public/logos/login.png`
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.allowSignupEnabled = configurations.allowSignup === 'enabled'
        this.habilitasmtpEnabled = configurations.habilitasmtp === 'enabled'
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Error al buscar configuraciones:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Ol%C3%A1%21+Quiero+conocer+mejor+el+sistema`
        window.open(url, '_blank') // Abre WhatsApp en una nueva pestaña
      }
    },
    redirecionarParaCadastro() {
      this.$router.push('/signup')
    },
    fazerLogin () {
      this.$v.form.$touch()
      if (this.$v.form.$error) {
        this.$q.notify('Ingrese usuario y contraseña correctamente.')
        return
      }
      this.loading = true
      this.$store.dispatch('UserLogin', this.form)
        .then(data => {
          this.loading = false
        })
        .catch(err => {
          console.error('exStore', err)
          this.loading = false
        })
    },
    clear () {
      this.form.email = ''
      this.form.password = ''
      this.$v.form.$reset()
    },
    enviarEmail() {
      if (this.$v.emailRedefinicao.$invalid) {
        this.$v.emailRedefinicao.$touch()
        return
      }
      enviarEmailRedefinicao(this.emailRedefinicao)
        .then(response => {
          if (response.data.status === 404) {
            this.$q.notify({
              type: 'negative',
              message: 'Email no encontrado'
            })
          } else {
            this.$q.notify({
              type: 'positive',
              message: '¡Email enviado con éxito!'
            })
            this.showAdditionalFields = true
          }
        })
        .catch(err => {
          console.log('API Error:', err)
          this.$q.notify({
            type: 'negative',
            message: 'Error al enviar email'
          })
        })
    },
    redefinirSenha() {
      if (this.novaSenha !== this.confirmarNovaSenha) {
        this.$q.notify({
          type: 'negative',
          message: 'Las contraseñas no coinciden'
        })
        return
      }
      redefinirSenha(this.emailRedefinicao, this.codigoVerificacao, this.novaSenha)
        .then(() => {
          this.$q.notify({
            type: 'positive',
            message: 'Contraseña restablecida con éxito.'
          })
          this.modalEsqueciSenha = false
          this.showAdditionalFields = false
        })
        .catch(err => {
          console.log('API Error:', err)
          this.$q.notify({
            type: 'negative',
            message: 'Error al restablecer contraseña'
          })
        })
    }
  },
  mounted() {
    this.loadColors()
    this.fetchConfigurations()
  }
}
</script>

<style scoped>
.container {
  display: flex;
  height: 100vh;
  width: 100vw;
  justify-content: center;
  align-items: center;
}

.login-section {
  width: 400px;
  height: 50vh;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  background-color: white;
  border-radius: 10px
}

.full-width {
  width: 100%;
}

.login-content {
  text-align: center;
}

.video-container {
  display: flex;
  justify-content: flex-end;
  width: 55%;
}

.logo-image {
  height: auto;
  max-width: 100%;
}

.fixed-layout {
  width: 45%;
}

.whatsapp-float {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 1000;
  border-radius: 50%; /* Deja el contorno redondeado */
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s;
}

.whatsapp-float:hover {
  transform: scale(1.1);
}

</style>
