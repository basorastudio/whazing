<template>
  <!-- ...existing code... -->
          <q-tooltip>
            {{ $t('tooltips.saveChanges') }}
          </q-tooltip>
  <!-- ...existing code... -->
          <q-tooltip>
            {{ $t('tooltips.close') }}
          </q-tooltip>
  <!-- ...existing code... -->
          <q-tooltip>
            {{ $t('tooltips.edit') }}
          </q-tooltip>
  <!-- ...existing code... -->
          <q-tooltip>
            {{ $t('tooltips.delete') }}
          </q-tooltip>
  <!-- ...existing code... -->
        <template v-slot:no-data>
          <div class="full-width row flex-center text-accent q-gutter-sm">
            <q-icon size="2em" name="sentiment_dissatisfied" />
            {{ $t('messages.noDataAvailable') }}
          </div>
        </template>
  <!-- ...existing code... -->
</template>

<script>
export default {
  methods: {
    // ...existing code...
    loadConfig() {
      try {
        // ...existing code...
      } catch (error) {
        console.error(this.$t('errors.loadConfigError'), error);
      }
    },
    saveConfig() {
      try {
        // ...existing code...
      } catch (error) {
        console.error(this.$t('errors.saveConfigError'), error);
      }
    },
    // ...existing code...
  }
};
</script>