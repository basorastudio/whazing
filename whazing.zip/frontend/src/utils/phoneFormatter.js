class FormatMask {
  setPhoneFormatMask(phoneToFormat) {
    if (!phoneToFormat || phoneToFormat.length < 10) {
      return
    }

    const number = ('' + phoneToFormat).replace(/\D/g, '')

    if (number.length === 10) {
      // Formato para República Dominicana: +1 (XXX) XXX-XXXX
      const phoneNumberFormatted = number.match(/^(\d{3})(\d{3})(\d{4})$/)
      return (
        '+1 (' +
        phoneNumberFormatted[1] +
        ') ' +
        phoneNumberFormatted[2] +
        '-' +
        phoneNumberFormatted[3]
      )
    } else if (number.length === 11 && number.startsWith('1')) {
      // Si incluye el código de país
      const phoneNumberFormatted = number.match(/^(\d{1})(\d{3})(\d{3})(\d{4})$/)
      return (
        '+' +
        phoneNumberFormatted[1] +
        ' (' +
        phoneNumberFormatted[2] +
        ') ' +
        phoneNumberFormatted[3] +
        '-' +
        phoneNumberFormatted[4]
      )
    }

    return null
  }

  removeMask(number) {
    const filterNumber = number.replace(/\D/g, '')
    return filterNumber
  }

  maskPhonePattern(phoneNumber) {
    // Patrón para República Dominicana
    return '+1 (XXX) XXX-XXXX'
  }
}

export { FormatMask }

const formatSerializedId = (serializedId) => {
  const formatMask = new FormatMask()
  const number = serializedId?.replace('@c.us', '')

  return formatMask.setPhoneFormatMask(number)?.replace('+1', '🇩🇴')
}

export default formatSerializedId
