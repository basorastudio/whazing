// --- START OF FILE 20231015160653-create_table_message_interno.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'InternalMessages'; // 'InternalMe' + 'ssage' -> Pluralized
        const tableDefinition = {
            id: {
                type: DataTypes.BIGINT, // Original BIGINT
                primaryKey: true,
                autoIncrement: true, // 'autoIncrem' + 'ent'
                allowNull: false
            },
            text: {
                type: DataTypes.TEXT, // Original TEXT
                allowNull: false // Changed ![] to false
            },
            read: {
                type: DataTypes.BOOLEAN,
                allowNull: false, // Changed ![] to false
                defaultValue: false // Changed ![] to false
            },
            mediaType: {
                type: DataTypes.STRING // Original STRING
                 // allowNull defaults to true
            },
            mediaUrl: {
                type: DataTypes.STRING // Original STRING
                 // allowNull defaults to true
            },
            senderId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'Users', // Original 'Users'
                    key: 'id'
                },
                onUpdate: 'CASCADE', // Original 'CASCADE'
                onDelete: 'SET NULL' // Original 'SET NULL'
                 // allowNull defaults to true, matching onDelete SET NULL
            },
            receiverId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'Users', // Original 'Users'
                    key: 'id'
                },
                onUpdate: 'CASCADE', // Original 'CASCADE'
                onDelete: 'SET NULL' // Original 'SET NULL'
                 // allowNull defaults to true, matching onDelete SET NULL
            },
            groupId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'Groups', // Original 'Groups'
                    key: 'id'
                },
                onUpdate: 'CASCADE', // Original 'CASCADE'
                onDelete: 'CASCADE' // Original 'CASCADE'
                 // allowNull defaults to true
                 // Consider allowNull: false if a message must belong to a group or sender/receiver
            },
            tenantId: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'Tenants', // Original 'Tenants'
                    key: 'id'
                },
                onUpdate: 'CASCADE', // Original 'CASCADE'
                onDelete: 'CASCADE', // Original 'CASCADE'
                allowNull: false, // Changed ![] to false
                defaultValue: 1 // Original default 0x1 -> 1
            },
            timestamp: { // Original column name
                type: DataTypes.BIGINT, // Original BIGINT
                allowNull: false // Changed ![] to false
                 // Consider using DATE type instead of BIGINT for timestamps unless specific reason
                 // type: DataTypes.DATE
            },
            createdAt: {
                type: DataTypes.DATE, // Derived from original math
                allowNull: false
            },
            updatedAt: {
                type: DataTypes.DATE, // Derived from original math
                allowNull: false
            }
        };
        await queryInterface.createTable(tableName, tableDefinition);
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'InternalMessages'; // 'InternalMe' + 'ssage' -> Pluralized
        await queryInterface.dropTable(tableName);
    }
};

export default migration;

// --- END OF FILE 20231015160653-create_table_message_interno.ts ---