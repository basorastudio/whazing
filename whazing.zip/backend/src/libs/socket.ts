import { Server as SocketIOServer, Socket } from 'socket.io';
import { createAdapter as createRedisAdapter } from '@socket.io/redis-adapter';
import { createClient as createRedisClient } from 'redis';
import http from 'http'; // Assuming http server is passed

import AppError from '../errors/AppError'; // Adjust path as needed
import decodeTokenSocket from './decodeTokenSocket'; // Adjust path as needed
import { logger } from '../utils/logger'; // Adjust path as needed
import User from '../models/User'; // Adjust path as needed
import { chat as ChatController } from '../controllers/socket/Chat'; // Adjust path and ensure Chat exports 'register'

// Define types
interface AuthData {
    token?: string;
    // Add other potential auth data
}

interface SocketHandshake extends Socket['handshake'] {
    auth: AuthData;
}

interface AuthenticatedSocket extends Socket {
    handshake: SocketHandshake;
    // Attach decoded user data directly to the socket after authentication
    user?: {
        id: string | number;
        profile: string;
        tenantId: string | number;
        // Add other relevant user properties
    };
}

let io: SocketIOServer;

export const initIO = (httpServer: http.Server): SocketIOServer => {
    const frontendUrl = process.env.FRONTEND_URL;
    const allowedOrigins = frontendUrl?.split(',') || ['*']; // Allow all if not specified

    io = new SocketIOServer(httpServer, {
        cors: {
            origin: allowedOrigins, // Use configured origins
            // credentials: true, // Uncomment if needed
        },
        // pingInterval: 30000, // Example: Send pings every 30 seconds
        // pingTimeout: 15000, // Example: Disconnect if no pong after 15 seconds
        connectTimeout: 45000, // Example: 45 seconds connection timeout
        // allowUpgrades: true, // Default is true
        transports: ["websocket", "polling"], // Allow both transports
    });

    // Configure Redis Adapter if Redis variables are set
    const redisHost = process.env.IO_REDIS_SERVER || 'localhost';
    const redisPort = Number(process.env.IO_REDIS_PORT) || 6379;
    const redisPassword = process.env.IO_REDIS_PASSWORD;
    const redisDb = Number(process.env.IO_REDIS_DB_SESSION) || 3; // Default DB 3?
    const redisUser = process.env.IO_REDIS_USERNAME; // For Redis 6+ ACL

    let redisConnectionString = 'redis://';
    if (redisUser && redisPassword) {
        redisConnectionString += `${redisUser}:${redisPassword}@`;
    } else if (redisPassword) {
        redisConnectionString += `:${redisPassword}@`;
    }
    redisConnectionString += `${redisHost}:${redisPort}/${redisDb}`;


    if (process.env.IO_REDIS_SERVER) {
        logger.info(`Attempting to connect Redis adapter: ${redisHost}:${redisPort}`);
         const pubClient = createRedisClient({ url: redisConnectionString });
         const subClient = pubClient.duplicate(); // Create subscriber client

        Promise.all([pubClient.connect(), subClient.connect()])
            .then(() => {
                io.adapter(createRedisAdapter(pubClient, subClient));
                logger.info('Redis adapter connected successfully.');
            })
            .catch((err) => {
                logger.error('Error connecting Redis adapter:', err);
                // Proceed without adapter if connection fails? Or throw error?
            });
         pubClient.on('error', (err) => logger.error('Redis PubClient Error', err));
         subClient.on('error', (err) => logger.error('Redis SubClient Error', err));
    } else {
         logger.warn('Redis adapter not initialized (IO_REDIS_SERVER not set).');
    }


    // Socket.IO Authentication Middleware
    io.use(async (socket: Socket, next) => {
        try {
            const token = (socket.handshake as SocketHandshake).auth?.token;
            const decoded = decodeTokenSocket(token); // Use your decode function

            if (decoded.isValid) {
                // Attach decoded user data to the socket handshake for access in handlers
                (socket.handshake as SocketHandshake).auth = {
                    ...(socket.handshake as SocketHandshake).auth, // Keep existing auth data if any
                    ...decoded.data, // Add decoded user info
                    id: String(decoded.data.id), // Ensure ID is string
                    tenantId: String(decoded.data.tenantId) // Ensure tenantId is string
                };

                // Fetch user details from database for verification and attaching full user object
                 const user = await User.findByPk(decoded.data.id, {
                     attributes: ["id", "name", "email", "profile", "tenantId", "isOnline", "lastSeen"] // Select necessary fields
                 });

                 if (!user) {
                      logger.warn(`User with ID ${decoded.data.id} not found in database during socket auth.`);
                      return next(new AppError('User not found.', 404)); // Use AppError or specific Socket.IO error
                 }

                 // Attach the verified user object to the socket itself
                 (socket as AuthenticatedSocket).user = user.toJSON(); // Attach plain user object

                return next(); // Authentication successful
            }
            return next(new Error('Authentication error')); // Invalid token
        } catch (err: any) {
            logger.error('Authentication middleware error verifying user.', err);
            return next(new Error('Authentication error')); // General error during auth
        }
    });

    // Connection Event Handler
    io.on('connection', (socket: Socket) => {
        const authenticatedSocket = socket as AuthenticatedSocket; // Cast to access user property

        // Log successful connection with user details
         if (authenticatedSocket.user) {
              logger.info(`Client connected: ${authenticatedSocket.id} | User: ${authenticatedSocket.user.name} (ID: ${authenticatedSocket.user.id}) | Tenant: ${authenticatedSocket.user.tenantId}`);

             // Join tenant-specific room
              const tenantRoom = authenticatedSocket.user.tenantId.toString();
              socket.join(tenantRoom);
              logger.info(`Socket ${socket.id} joined room ${tenantRoom}`);


             // Join notification channel (might be tenant-specific or global)
              const notificationChannel = `${authenticatedSocket.user.tenantId}:notification`;
              socket.join(notificationChannel);
              logger.info(`Socket ${socket.id} joined notification channel ${notificationChannel}`);

              // Join specific user room (for direct messages if needed)
               const userRoom = `${authenticatedSocket.user.tenantId}:${authenticatedSocket.user.id}`;
               socket.join(userRoom);
               logger.info(`Socket ${socket.id} joined user room ${userRoom}`);


              // Register chat event handlers for this socket
             ChatController.register(authenticatedSocket);

             // Handle joining specific ticket/queue/chat rooms upon client request
             socket.on(':joinTicketChannel', (ticketId: string | number) => {
                  const roomName = `tenant-${authenticatedSocket.user?.tenantId}:ticket:${ticketId}`;
                  socket.join(roomName);
                   logger.info(`Socket ${socket.id} joined ticket channel ${roomName}`);
              });
              socket.on(':joinQueueChannel', (queueId: string | number) => {
                  const roomName = `tenant-${authenticatedSocket.user?.tenantId}:queue:${queueId}`;
                  socket.join(roomName);
                   logger.info(`Socket ${socket.id} joined queue channel ${roomName}`);
              });
               socket.on(':joinChatBox', (chatId: string | number) => { // Example for direct user chat
                    const roomName = `tenant-${authenticatedSocket.user?.tenantId}:chat:${chatId}`;
                    socket.join(roomName);
                     logger.info(`Socket ${socket.id} joined chatbox channel ${roomName}`);
               });
               socket.on(':joinNotificationChannel', () => { // Let client explicitly join general notification if needed
                   const roomName = `tenant-${authenticatedSocket.user?.tenantId}:notification`;
                   socket.join(roomName);
                    logger.info(`Socket ${socket.id} re-joined notification channel ${roomName}`);
               });
               socket.on(':updateStatusUser', async (statusData: { userId: string | number, status: 'online' | 'offline' | 'idle' }) => {
                    // Handle status updates received from client (e.g., user went idle)
                     if (authenticatedSocket.user?.id === statusData.userId) { // Basic validation
                          // Update user status in your application state/database
                          // Example: Update User model and emit via ChatController
                           logger.info(`Received status update for user ${statusData.userId}: ${statusData.status}`);
                          // await User.update({ status: statusData.status }, { where: { id: statusData.userId }});
                          // ChatController.events.onSetUserStatus(authenticatedSocket, statusData.status); // Example call if handler exists
                     }
                });



         } else {
              logger.warn(`Socket ${socket.id} connected but has no authenticated user attached.`);
              socket.disconnect(true); // Disconnect unauthenticated sockets
         }


        // Disconnect Event Handler
        socket.on('disconnect', (reason: string) => {
            logger.info(`Client disconnected: ${socket.id}. Reason: ${reason}`);
            // ChatController handles internal state cleanup on disconnect
        });

        // Error Event Handler
        socket.on('error', (err: Error) => {
            logger.error(`Socket error on ${socket.id}:`, err);
        });

    });

    return io;
};


/**
 * Retrieves the initialized Socket.IO server instance.
 * @returns The SocketIOServer instance.
 * @throws {AppError} If the IO instance has not been initialized.
 */
export const getIO = (): SocketIOServer => {
    if (!io) {
        throw new AppError('Socket IO not initialized');
    }
    return io;
};