import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna isDeleted a la tabla Messages
    return queryInterface.addColumn('Messages', 'isDeleted', { // Nombre de columna preservado
      type: DataTypes.BOOLEAN,
      allowNull: false, // Asume que no puede ser nulo
      defaultValue: false // Por defecto, los mensajes no están eliminados
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna isDeleted
    return queryInterface.removeColumn('Messages', 'isDeleted');
  }
};