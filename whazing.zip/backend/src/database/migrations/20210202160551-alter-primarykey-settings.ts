import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Modifica la columna 'key' en la tabla 'Settings'
    return Promise.all([
      queryInterface.changeColumn('Settings', 'key', {
        type: DataTypes.STRING,
        allowNull: false, // No permite nulos
        primaryKey: false, // Ya no es clave primaria
        unique: false // Ya no es única (esto podría ser un error si antes era única)
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Revierte los cambios en la columna 'key'
    return Promise.all([
      queryInterface.changeColumn('Settings', 'key', {
        type: DataTypes.STRING,
        allowNull: true, // Vuelve a permitir nulos
        primaryKey: true, // Vuelve a ser clave primaria
        unique: true // Vuelve a ser única
      })
    ]);
  }
};