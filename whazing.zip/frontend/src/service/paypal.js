import request from 'src/service/request'

export function initializePayPalPayment(data) {
  return request({
    url: '/paypal/create-payment',
    method: 'post',
    data
  })
}

export function capturePayPalPayment(paymentId, payerId) {
  return request({
    url: '/paypal/capture-payment',
    method: 'post',
    data: { paymentId, payerId }
  })
}

export function getPayPalConfig() {
  return request({
    url: '/paypal/config',
    method: 'get'
  })
}