// Este archivo será utilizado con el modo "InjectManifest" en quasar.conf.js

import { precacheAndRoute } from 'workbox-precaching'
import { clientsClaim, setCacheNameDetails, skipWaiting } from 'workbox-core'
import { registerRoute } from 'workbox-routing'
import { CacheFirst } from 'workbox-strategies'

// Configuración de nombres para las cachés
setCacheNameDetails({
  prefix: 'pwa',
  suffix: 'v1',
  precache: 'precache',
  runtime: 'runtime'
})

// Activando control inmediato del service worker
clientsClaim()
skipWaiting()

// Pre-caché de archivos esenciales
precacheAndRoute(self.__WB_MANIFEST)

// Estrategia de caché para archivos de imagen
registerRoute(
  ({ request }) => request.destination === 'image',
  new CacheFirst({
    cacheName: 'images-cache'
  })
)

// Evento para notificaciones push
self.addEventListener('push', (event) => {
  if (event.data) {
    const payload = event.data.json()
    const title = payload.title || 'Nueva notificación'
    const options = {
      body: payload.body || 'Tienes un nuevo mensaje.',
      icon: payload.icon || '/public/whatsapp-logo.png',
      badge: payload.badge || '/public/whatsapp-logo.png',
      data: {
        url: payload.url || '/' // URL para abrir al hacer clic
      }
    }

    event.waitUntil(
      self.registration.showNotification(title, options)
    )
  }
})

// Evento para clic en notificaciones
self.addEventListener('notificationclick', (event) => {
  event.notification.close()

  // Garantiza que hay una URL antes de intentar abrir
  const targetUrl = event.notification.data?.url
  if (targetUrl) {
  }
})
