<template>
  <div>
    <q-table flat
      bordered
      square
      hide-bottom
      class="contact-table container-rounded-10 my-sticky-dynamic q-ma-lg"
      :data="ajudas"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]">
      <template v-slot:top-left>
        <div>

          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-help q-pr-sm" />
            Ayuda
          </h2>

          <div class="row flex-gap-1">
            <q-input
              style="width: 300px"
              filled
              dense
              class="contact-search col-grow"
              debounce="500"
              v-model="urlajuda"
              placeholder="URL de ayuda para iframe, si está completa los videos no aparecen"
              @input="atualizarConfiguracao('urlajuda')"
            >
              <template v-slot:prepend>
                <q-icon name="mdi-web" />
              </template>
            </q-input>
            <q-btn
              class="generate-button btn-rounded-50"
              :class="{'generate-button-dark': $q.dark.isActive}"
              icon="eva-plus-outline"
              label="Añadir"
              @click="ajudaEdicao = {}; modalAjuda = true"
            />
          </div>

        </div>

      </template>
              <template v-slot:body-cell-acoes="props">
                <q-td class="text-center">
                  <q-btn class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" flat round icon="eva-edit-outline" @click="editarAjuda(props.row)" />
                  <q-btn class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" flat round icon="eva-trash-outline" @click="deletarAjuda(props.row)" />
                </q-td>
              </template>
            </q-table>
            <ModalAjuda :modalAjuda.sync="modalAjuda" :ajudaEdicao.sync="ajudaEdicao" @modal-ajuda:criada="ajudaCriada"
            @modal-ajuda:editada="ajudaEditada" />
  </div>
</template>

<script>
import { ListarHelpList, DeleteHelp } from '../../../service/help'
import ModalAjuda from './ModalAjuda'
import { AlterarConfiguracaoGeneral, ListarConfiguracoesGeneral } from 'src/service/configuracoesgeneral'
export default {
  name: 'Ayudas',
  components: {
    ModalAjuda
  },
  data() {
    return {
      tab: 'ajuda',
      ajudaEdicao: {},
      modalAjuda: false,
      ajudas: [],
      urlajuda: '',
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'title', label: 'Título', field: 'title', align: 'left' },
        { name: 'description', label: 'Descripción', field: 'description', align: 'center' },
        { name: 'video', label: 'Video', field: 'video', align: 'center' },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoesGeneral()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        const value = el.value
        this.$data[el.key] = value
      })
    },
    async listarAjuda() {
      const { data } = await ListarHelpList()
      this.ajudas = data
    },
    editarAjuda(ajuda) {
      this.ajudaEdicao = { ...ajuda }
      this.modalAjuda = true
    },
    ajudaCriada(ajuda) {
      const newAjuda = [...this.ajudas]
      newAjuda.push(ajuda)
      this.ajudas = [...newAjuda]
    },
    ajudaEditada(ajuda) {
      const newAjuda = [...this.ajudas]
      const idx = newAjuda.findIndex(f => f.id === ajuda.id)
      if (idx > -1) {
        newAjuda[idx] = ajuda
      }
      this.ajudas = [...newAjuda]
    },
    async atualizarConfiguracao(key) {
      const params = {
        key,
        value: this.$data[key]
      }
      try {
        await AlterarConfiguracaoGeneral(params)
        this.$q.notify({
          type: 'positive',
          message: '¡Configuración modificada!',
          progress: true,
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (error) {
        console.error('error - AlterarConfiguracao', error)
        this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
        this.$notificarErro('¡Ha ocurrido un error!', error)
      }
    },
    deletarAjuda(ajuda) {
      this.$q.dialog({
        title: '¡¡Atención!!',
        message: `¿Realmente desea eliminar la Ayuda "${ajuda.title}"?`,
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeleteHelp(ajuda.id) // Aquí pasamos solo el ID
          .then(res => {
            let newAjuda = [...this.ajudas]
            newAjuda = newAjuda.filter(f => f.id !== ajuda.id)

            this.ajudas = [...newAjuda]
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: `¡Ayuda ${ajuda.title} eliminada!`,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .catch(error => {
            this.$q.notify({
              type: 'negative',
              progress: true,
              position: 'top',
              message: `Error al eliminar la ayuda: ${error.message}`,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .finally(() => {
            this.loading = false
          })
      })
    }
  },
  mounted() {
    this.listarConfiguracoes()
    this.listarAjuda()
  }
}
</script>

<style lang="scss" scoped></style>
