<template>
  <div>
    <div class="container-border q-ma-lg q-pb-md container-rounded-10">
        <!-- Muestra solo el iframe dentro del contenedor -->
        <div v-if="urlajuda" style="width: 100%; height: calc(100vh - 75px); display: flex; justify-content: center; align-items: center;">
          <iframe
            width="100%"
            height="100%"
            :src="urlajuda"
            frameborder="0"
            allowfullscreen
            referrerpolicy="strict-origin-when-cross-origin"
            style="border: none; display: block;"
          ></iframe>
        </div>

      <div v-else>
        <!-- Muestra el diseño estándar con videos cuando urlajuda no tiene valor -->
        <q-card-section>
          <h2 :class="$q.dark.isActive ? 'color-dark3' : ''">
            <q-icon name="eva-list-outline q-pr-sm" />
            Documentación / Instrucciones de Uso
          </h2>
          <q-btn flat
                 class="generate-button btn-rounded-50"
                 :class="{'generate-button-dark' : $q.dark.isActive}"
                 v-if="whatsappNumber"
                 icon="mdi-whatsapp"
                 label="Llamar Soporte"
                 @click="abrirWhatsApp"
          />
        </q-card-section>

        <div class="q-pa-md row q-gutter-md q-col-gutter-md">
          <div v-for="ajuda in ajudas" :key="ajuda.id" class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
            <q-card @click="abrirModal(ajuda)">
              <q-card-section>
                <img
                  :src="`https://img.youtube.com/vi/${ajuda.video}/hqdefault.jpg`"
                  class="video-thumbnail"
                  :alt="ajuda.title"
                />
                <div class="text-h6">{{ ajuda.title }}</div>
                <div class="text-subtitle2">{{ ajuda.description }}</div>
              </q-card-section>
            </q-card>
          </div>
        </div>

        <q-dialog v-model="modalVisivel" persistent>
          <q-card style="width: 100%; position: relative;">
            <q-btn icon="close" @click="modalVisivel = false" style="position: absolute; top: 0; right: 0; z-index: 10;"></q-btn>
            <q-card-section>
              <iframe
                width="100%"
                height="335px"
                :src="modalVideoUrl"
                title="YouTube video player"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerpolicy="strict-origin-when-cross-origin"
                allowfullscreen
              ></iframe>
            </q-card-section>
          </q-card>
        </q-dialog>
      </div>
    </div>
  </div>
</template>

<script>
import { ListarHelpList } from 'src/service/help'
import { ListarCores, ListarConfiguracaoPublica } from 'src/service/configuracoesgeneral'

export default {
  name: 'Ajuda',
  data() {
    return {
      ajudas: [],
      modalVisivel: false,
      modalVideoUrl: '',
      urlajuda: null,
      whatsappNumber: null
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        const response = await ListarCores()
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    async listarAjuda() {
      try {
        const { data } = await ListarHelpList()
        this.ajudas = data
      } catch (error) {
        console.error('Error al cargar ayudas:', error)
      }
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.urlajuda = configurations.urlajuda || null
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Error al buscar configuraciones:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=¡Hola%21+tengo+algunas+dudas`
        window.open(url, '_blank') // Abre WhatsApp en una nueva pestaña
      }
    },
    abrirModal(ajuda) {
      this.modalVideoUrl = `https://www.youtube.com/embed/${ajuda.video}`
      this.modalVisivel = true
    }
  },
  mounted() {
    this.loadColors()
    this.listarAjuda()
    this.fetchConfigurations() // Cargar la URL de ayuda
  }
}
</script>

<style scoped>
.video-thumbnail {
  width: 100%;
  height: auto;
}
</style>
