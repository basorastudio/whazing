import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    return queryInterface.createTable("Queues", {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      queue: {
        // Nombre de la cola/departamento
        type: DataTypes.STRING,
        allowNull: false
      },
      userId: {
        // Usuario propietario/administrador de la cola
        type: DataTypes.INTEGER,
        references: {
          model: "Users",
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL" // Si se elimina el usuario, userId se establece en NULL
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    return queryInterface.dropTable("Queues");
  }
};
