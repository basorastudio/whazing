<template>
  <q-dialog persistent :value="modalPlano" @hide="fecharModal" @show="abrirModal">
    <q-card class="container-rounded-10 modal-container q-pa-lg">

      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ planoEdicao.id ? 'Editar' : 'Crear' }} Plano
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <div class="container-border container-rounded-10">

      <q-card-section class="row flex-gap-1 q-col-gutter-sm">
        <div class="text-h6 font-family-main">
          Informaciones
        </div>
        <div class="flex-gap-1 full-width row q-col-gutter-sm">
          <div class="full-width">
            <c-input rounded outlined v-model="plano.name" label="Nombre del Plan" />
          </div>
          <div class="full-width">
            <c-input rounded outlined v-model="plano.maxUsers" type="number" label="Máx. Usuarios" />
          </div>
          <div class="full-width">
            <c-input rounded outlined v-model="plano.maxConnections" type="number" label="Máx. Conexiones" />
          </div>
          <div class="full-width">
            <c-input rounded outlined v-model="plano.value" type="number" label="Valor" />
          </div>
          <div class="full-width">
        <q-checkbox
          v-model="plano.isPublic"
          label="Público"
        />
            <q-checkbox
              v-model="plano.group"
              label="Grupos"
            />
            <q-checkbox
              v-model="plano.campaign"
              label="Campañas"
            />
            <q-checkbox
              v-model="plano.integrations"
              label="Integraciones"
            />
          </div>
        </div>
      </q-card-section>
      </div>
      <q-card-actions align="right">
        <q-btn
          label="Cancelar"
          class="q-px-md q-mr-sm btn-rounded-50"
          color="negative"
          v-close-popup
        />
        <q-btn
          label="Guardar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          icon="eva-save-outline"
          @click="handlePlano"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { AlterarPlano, CriarPlano } from '../../../service/plans'
export default {
  name: 'ModalPlano',
  props: {
    modalPlano: {
      type: Boolean,
      default: false
    },
    planoEdicao: {
      type: Object,
      default: () => {
        return { id: null }
      }
    }
  },
  data() {
    return {
      plano: {
        id: null,
        name: null,
        maxUsers: null,
        maxConnections: null,
        value: null,
        isPublic: true,
        group: true,
        campaign: true,
        integrations: true
      }
    }
  },
  methods: {
    resetarPlano() {
      this.plano = {
        id: null,
        name: null,
        maxUsers: null,
        maxConnections: null,
        value: null,
        isPublic: true,
        group: true,
        campaign: true,
        integrations: true
      }
    },
    fecharModal() {
      this.resetarPlano()
      this.$emit('update:planoEdicao', { id: null })
      this.$emit('update:modalPlano', false)
    },
    abrirModal() {
      if (this.planoEdicao.id) {
        this.plano = { ...this.planoEdicao }
      } else {
        this.resetarPlano()
      }
    },
    async handlePlano() {
      try {
        this.loading = true

        if (!this.plano.name) {
          this.$q.notify({ type: 'negative', message: 'El campo Nombre es obligatorio!' })
          this.loading = false
          return
        }

        if (!this.plano.maxUsers || !Number.isInteger(Number(this.plano.maxUsers))) {
          this.$q.notify({ type: 'negative', message: 'El campo Máx. Usuarios debe ser un número entero!' })
          this.loading = false
          return
        }

        if (!this.plano.maxConnections || !Number.isInteger(Number(this.plano.maxConnections))) {
          this.$q.notify({ type: 'negative', message: 'El campo Máx. Conexiones debe ser un número entero!' })
          this.loading = false
          return
        }

        if (!this.plano.value) {
          this.$q.notify({ type: 'negative', message: 'El campo Valor es obligatorio!' })
          this.loading = false
          return
        }

        const valor = this.plano.value.toString().replace(',', '.')
        if (isNaN(valor) || Number(valor) <= 0) {
          this.$q.notify({ type: 'negative', message: 'El campo Valor debe ser un número válido!' })
          this.loading = false
          return
        }

        this.plano.value = parseFloat(valor).toFixed(2)

        let data
        if (this.plano.id) {
          ({ data } = await AlterarPlano(this.plano))
          this.$emit('modal-plano:editada', data)
          this.$q.notify({ type: 'info', message: 'Plan editado!' })
        } else {
          ({ data } = await CriarPlano(this.plano))
          this.$emit('modal-plano:criada', data)
          this.$q.notify({ type: 'positive', message: 'Plan creado!' })
        }

        this.loading = false
        this.$emit('reload-planos')
        this.fecharModal()
      } catch (error) {
        console.error(error)
        this.$notificarErro('¡Ocurrió un error!', error)
        this.loading = false
      }
    }
  }

}
</script>

<style lang="scss" scoped></style>
