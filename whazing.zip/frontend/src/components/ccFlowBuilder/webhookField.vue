<template>
  <div>
    <q-card flat
      class="q-pa-sm q-pb-md">
      <q-card-section class="q-pa-none">
        <div class="text-subtitle2 q-mb-sm">
          {{ $t('ccFlowBuilder.addwebhook') }}
        </div>
        <div class="flex flex-inline full-width items-center">
          <div class="flex flex-inline text-left"
            style="width: 40px">
            <q-btn round
              flat
              dense>
              <q-icon size="2em"
                      class="color-light1"
                      :class="$q.dark.isActive ? ('color-dark1') : ''"
                name="mdi-variable" />
              <q-tooltip>
                {{ $t('general.variaveis') }}
              </q-tooltip>
              <q-menu touch-position>
                <q-list dense
                  style="min-width: 100px">
                  <q-item v-for="variavel in variaveis"
                    :key="variavel.label"
                    clickable
                    @click="onInsertSelectVariable(variavel.value)"
                    v-close-popup>
                    <q-item-section>{{ variavel.label }}</q-item-section>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>
          </div>
          <textarea ref="inputEnvioMensagem"
            style="min-height: 10vh; max-height: 30vh; flex: auto"
            class="q-pa-sm bg-white"
            :placeholder="$t('ccFlowBuilder.addwebhook')"
            autogrow
            dense
            outlined
            @input="(v) => $attrs.element.data.webhook = v.target.value"
            :value="$attrs.element.data.webhook">
          </textarea>
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>

export default {
  name: 'WebhookField',
  data () {
    return {
      variaveis: [
        { label: this.$t('variaveis.nomeCompleto'), value: '{{name}}' },
        { label: this.$t('variaveis.nome'), value: '{{firstName}}' },
        { label: this.$t('variaveis.saudacaoPT'), value: '{{greeting}}' },
        { label: this.$t('variaveis.saudacaoEN'), value: '{{greetingEn}}' },
        { label: this.$t('variaveis.saudacaoES'), value: '{{greetingEs}}' },
        { label: this.$t('variaveis.protocol'), value: '{{protocol}}' },
        { label: this.$t('variaveis.telefone'), value: '{{phoneNumber}}' },
        { label: this.$t('variaveis.email'), value: '{{email}}' },
        { label: this.$t('variaveis.ticket_id'), value: '{{ticket_id}}' },
        { label: this.$t('variaveis.hora'), value: '{{hour}}' },
        { label: this.$t('variaveis.data'), value: '{{date}}' },
        { label: this.$t('variaveis.queue'), value: '{{fila}}' },
        { label: this.$t('variaveis.user'), value: '{{user}}' },
        { label: this.$t('variaveis.userEmail'), value: '{{userEmail}}' }
      ]
    }
  },
  methods: {
    onInsertSelectVariable (variable) {
      console.log('onInsertSelectVariable', variable)
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!variable) {
        return
      }
      // insert:
      self.txtContent = this.$attrs.element.data.webhook
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.$attrs.element.data.webhook = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
