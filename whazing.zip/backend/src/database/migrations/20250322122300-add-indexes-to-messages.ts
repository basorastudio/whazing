"use strict";
import { QueryInterface } from "sequelize";

export default {
  up: async (queryInterface: QueryInterface) => {
    // Índice para búsquedas por tenantId y ticketId
    await queryInterface.addIndex("Messages", ["tenantId", "ticketId"], {
      name: "idx_messages_tenantid_ticketid"
    }); // nombre claro del índice

    // Índice para búsquedas por whatsappId y tenantId
    await queryInterface.addIndex("Messages", ["whatsappId", "tenantId"], {
      name: "idx_messages_whatsappid_tenantid"
    }); // nombre claro del índice

    // Índice para búsquedas por contactId y tenantId
    await queryInterface.addIndex("Messages", ["contactId", "tenantId"], {
      name: "idx_messages_contactid_tenantid"
    }); // nombre claro del índice
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeIndex(
      "Messages",
      "idx_messages_tenantid_ticketid"
    );
    await queryInterface.removeIndex(
      "Messages",
      "idx_messages_whatsappid_tenantid"
    );
    await queryInterface.removeIndex(
      "Messages",
      "idx_messages_contactid_tenantid"
    );
  }
};
