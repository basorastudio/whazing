<template>
  <div v-if="!canAccessPage">
    <q-banner dense inline-actions class="bg-red text-white">
      <template v-slot:avatar>
        <q-icon name="warning" />
      </template>
      {{ $t('campanhas.acessoNegado') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               v-if="whatsappNumber"
               icon="mdi-whatsapp"
               :label="$t('campanhas.chamarSuporte')"
               @click="abrirWhatsApp"
        />
      </template>
    </q-banner>
  </div>
  <div v-else-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-table
      flat
      bordered
      square
      hide-bottom
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      :data="campanhasComCalculos"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
    >
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
          {{ $t('campanhas.titulo') }}
        </h2>
        <div>
        <q-btn
          class="color-light1"
          :class="$q.dark.isActive ? ('color-dark1') : ''"
          icon="refresh"
          outline
          @click="listarCampanhas"
          >
        <q-tooltip>
          {{ $t('campanhas.atualizarListagem') }}
        </q-tooltip>
        </q-btn>
        <q-btn
          class="generate-button btn-rounded-50"
          :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline"
          :label="$t('campanhas.adicionar')"
          @click="campanhaEdicao = {}; modalCampanha = true"
        />
        </div>
        </div>

      </template>
      <template v-slot:body-cell-color="props">
        <q-td class="text-center">
          <div
            class="q-pa-sm rounded-borders"
            :style="`background: ${props.row.color}`"
          >
            {{ props.row.color }}
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon
            size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
        flat
        round
        icon="mdi-account-details-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="contatosCampanha(props.row)"
      >
        <q-tooltip>
          {{ $t('campanhas.listacontatos') }}
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        v-if="['pending', 'canceled'].includes(props.row.status)"
        icon="mdi-calendar-clock"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="iniciarCampanha(props.row)"
      >
        <q-tooltip>
          {{ $t('campanhas.programarenvio') }}
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        v-if="['scheduled', 'processing'].includes(props.row.status)"
        icon="mdi-close-box-multiple"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="cancelarCampanha(props.row)"
      >
        <q-tooltip>
          {{ $t('campanhas.cancelarcampanha') }}
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        icon="eva-edit-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="editarCampanha(props.row)"
      >
        <q-tooltip>
          {{ $t('campanhas.editarCampanha') }}
        </q-tooltip>
      </q-btn>
      <q-btn
        flat
        round
        icon="eva-trash-outline"
        class="color-light1"
        :class="$q.dark.isActive ? ('color-dark1') : ''"
        @click="deletarCampanha(props.row)"
      >
        <q-tooltip>
          {{ $t('campanhas.excluirCampanha') }}
        </q-tooltip>
      </q-btn>
    </q-td>
      </template>
    </q-table>
    <ModalCampanha
      v-if="modalCampanha"
      :modalCampanha.sync="modalCampanha"
      :campanhaEdicao.sync="campanhaEdicao"
      @modal-campanha:criada="campanhaCriada"
      @modal-campanha:editada="campanhaEditada"
    />

    <q-dialog v-model="showWarningModal" persistent>
      <q-card>
        <q-card-section>
          <div class="text-h6">{{ $t('campanhas.avisoImportante') }}</div>
          <div class="text-body1 q-mt-md">
            <!-- Risco de Banimento -->
            <q-banner class="bg-orange-8 text-white q-mb-md" dense rounded>
              <q-icon name="warning" size="md" class="q-mr-sm" />
              <div class="text-subtitle1 text-bold">{{ $t('campanhas.riscoBanimento') }}</div>
              <div class="text-body2">
                {{ $t('campanhas.monitoramentoEnvio') }}
              </div>
            </q-banner>

            <!-- Política de Spam -->
            <q-banner class="bg-red-8 text-white q-mb-md" dense rounded>
              <q-icon name="error" size="md" class="q-mr-sm" />
              <div class="text-subtitle1 text-bold">{{ $t('campanhas.politicaSpam') }}</div>
              <div class="text-body2">
                {{ $t('campanhas.proibicaoDisparos') }}
              </div>
            </q-banner>

            <!-- Alerta de Denúncias -->
            <q-banner class="bg-red-10 text-white" dense rounded>
              <q-icon name="priority_high" size="md" class="q-mr-sm" />
              <div class="text-subtitle1 text-bold">{{ $t('campanhas.alertaDenuncias') }}</div>
              <div class="text-body2">
                {{ $t('campanhas.riscoBloqueio') }}
              </div>
            </q-banner>
          </div>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat :label="$t('general.cancelar')" color="negative" @click="cancelNavigation" />
          <q-btn flat :label="$t('campanhas.estouCiente')" color="positive" @click="confirmNavigation" />
        </q-card-actions>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
import { CancelarCampanha, DeletarCampanha, IniciarCampanha, ListarCampanhas } from 'src/service/campanhas'
import { MostrarPlano } from 'src/service/empresas'
import ModalCampanha from './ModalCampanha'
import { format, parseISO, startOfDay } from 'date-fns'
import { ListarConfiguracaoPublica } from 'src/service/configuracoesgeneral'

export default {
  name: 'Campanhas',
  components: {
    ModalCampanha
  },
  data () {
    return {
      userProfile: 'user',
      showWarningModal: false,
      canAccessPage: false,
      campanhaEdicao: {},
      modalCampanha: false,
      whatsappNumber: null,
      campanhas: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'name', label: this.$t('campanhas.campanha'), field: 'name', align: 'left' },
        { name: 'start', label: this.$t('campanhas.inicio'), field: 'start', align: 'center', format: (v) => format(parseISO(v), 'dd/MM/yyyy HH:mm') },
        {
          name: 'status',
          label: this.$t('general.status'),
          field: 'status',
          align: 'center',
          format: (v) => v ? this.status[v] : ''
        },
        { name: 'contactsCount', label: this.$t('campanhas.qtdcontatos'), field: 'contactsCount', align: 'center' },
        { name: 'pendentesEnvio', label: this.$t('campanhas.aenviar'), field: 'pendentesEnvio', align: 'center' },
        { name: 'pendentesEntrega', label: this.$t('campanhas.aentregar'), field: 'pendentesEntrega', align: 'center' },
        { name: 'recebidas', label: this.$t('campanhas.recebidas'), field: 'recebidas', align: 'center' },
        { name: 'lidas', label: this.$t('campanhas.lidas'), field: 'lidas', align: 'center' },
        { name: 'acoes', label: this.$t('general.actions'), field: 'acoes', align: 'center' }
      ],
      status: {
        pending: this.$t('campanhas.statusPendente'),
        scheduled: this.$t('campanhas.statusProgramada'),
        processing: this.$t('campanhas.statusProcessando'),
        canceled: this.$t('campanhas.statusCancelada'),
        finished: this.$t('campanhas.statusFinalizada')
      }
    }
  },
  computed: {
    campanhasComCalculos() {
      return this.campanhas.map(campanha => ({
        ...campanha,
        pendentesEnvio: Math.max(
          0,
          campanha.contactsCount -
          (campanha.pendentesEntrega || 0) -
          (campanha.recebidas || 0) -
          (campanha.lidas || 0)
        )
      }))
    }
  },
  methods: {
    cancelNavigation() {
      this.showWarningModal = false
      this.$router.push({ name: 'home-dashboard' })
    },
    confirmNavigation() {
      localStorage.setItem('showWarningModalCampanhas', false)
      this.showWarningModal = false
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configurações:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const message = encodeURIComponent(this.$t('campanhas.whatsapp'))
        const url = `https://wa.me/${this.whatsappNumber}?text=${message}`
        window.open(url, '_blank')
      }
    },
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.campaign !== false
      } catch (error) {
        console.error('Erro ao carregar o plano:', error)
      }
    },
    async listarCampanhas () {
      const { data } = await ListarCampanhas()
      this.campanhas = data
    },
    isValidDate (v) {
      return startOfDay(new Date(parseISO(v))).getTime() >= startOfDay(new Date()).getTime()
    },
    campanhaCriada (campanha) {
      this.listarCampanhas()
    },
    campanhaEditada (campanha) {
      this.listarCampanhas()
    },
    editarCampanha (campanha) {
      if (campanha.status !== 'pending' && campanha.status !== 'canceled') {
        this.$notificarErro(this.$t('campanhas.erroStatusEdicao'))
      }
      this.campanhaEdicao = {
        ...campanha,
        start: campanha.start,
        end: campanha.start
      }
      this.modalCampanha = true
    },
    deletarCampanha (campanha) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('campanhas.confirmarDelecaoCampanha', { name: campanha.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarCampanha(campanha)
          .then(res => {
            let newCampanhas = [...this.campanhas]
            newCampanhas = newCampanhas.filter(f => f.id !== campanha.id)
            this.campanhas = [...newCampanhas]
            this.$notificarSucesso(this.$t('campanhas.campanhaExcluida', { name: campanha.name }))
          })
        this.loading = false
      })
    },
    contatosCampanha (campanha) {
      this.$router.push({
        name: 'contatos-campanha',
        params: {
          campanhaId: campanha.id,
          campanha
        }
      })
    },
    cancelarCampanha (campanha) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('campanhas.confirmarCancelamentoCampanha', { name: campanha.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        CancelarCampanha(campanha.id)
          .then(res => {
            this.$notificarSucesso(this.$t('campanhas.campanhaCancelada'))
            this.listarCampanhas()
          }).catch(err => {
            this.$notificarErro(this.$t('campanhas.erroCancelarCampanha'), err)
          })
      })
    },
    iniciarCampanha (campanha) {
      if (!this.isValidDate(campanha.start)) {
        this.$notificarErro(this.$t('campanhas.erroDataInvalida'))
      }

      if (campanha.contactsCount == 0) {
        this.$notificarErro(this.$t('campanhas.erroSemContatos'))
      }

      if (campanha.status !== 'pending' && campanha.status !== 'canceled') {
        this.$notificarErro(this.$t('general.erroStatusProgramacao'))
      }

      IniciarCampanha(campanha.id).then(res => {
        this.$notificarSucesso(this.$t('campanhas.campanhainiciada'))
        this.listarCampanhas()
      }).catch(err => {
        this.$notificarErro(this.$t('campanhas.campanhanaoiniciada'), err)
      })
    }
  },
  mounted () {
    this.fetchConfigurations()
    this.listarPlano()
    this.listarCampanhas()
    this.userProfile = localStorage.getItem('profile')
    const showModalCampanha = JSON.parse(localStorage.getItem('showWarningModalCampanhas'))
    this.showWarningModal = !(!showModalCampanha && showModalCampanha !== null)
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px
</style>
