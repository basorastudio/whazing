import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  AutoIncrement
} from "sequelize-typescript";
import Tenant from "./Tenant";

@Table({ tableName: "Invoices" }) // Explicit table name
class Invoices extends Model<Invoices> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  detail: string; // Assuming 'detail' is the column name

  @Column
  status: string;

  @Column
  value: number; // Assuming numeric value

  @Column
  dueDate: string; // Assuming string, use Date if appropriate

  @Column
  txId: string;

  @Column
  payGw: string; // Payment Gateway identifier

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @Column
  payGwData: string; // Assuming string, maybe JSONB?

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;
}

export default Invoices;