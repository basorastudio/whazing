import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'queue' (probablemente de tipo INTEGER simple)
    await queryInterface.removeColumn('Tickets', 'queue');
    // Añade la columna 'queue' de nuevo, pero ahora como clave foránea a 'Queues'
    await queryInterface.addColumn('Tickets', 'queue', {
      type: DataTypes.INTEGER,
      references: {
        model: 'Queues', // Referencia a la tabla Queues
        key: 'id'
      },
      onUpdate: 'CASCADE',
      onDelete: 'restrict', // No permite eliminar una Queue si hay Tickets asociados
      defaultValue: null,
      allowNull: true
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'queue' (que es una clave foránea)
    await queryInterface.removeColumn('Tickets', 'queue');
    // Vuelve a añadir la columna 'queue' como INTEGER simple
    await queryInterface.addColumn('Tickets', 'queue', {
      type: DataTypes.INTEGER,
      defaultValue: null,
      allowNull: true
    });
  }
};