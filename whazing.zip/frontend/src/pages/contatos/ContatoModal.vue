<template>
  <q-dialog
    @show="fetchContact"
    @hide="$emit('update:modalContato', false)"
    :value="modalContato"
    persistent
  >
    <q-card class="q-pa-md modal-container container-rounded-10">

      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ contactId ? 'Editar Contacto' : 'Agregar Contacto' }}
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <div class="row flex-gap-1" style="gap: 1vh">
        <div class="full-width container-border container-rounded-10 q-ml-lg q-mr-lg">
        <q-card-section class="q-py-sm text-bold font-family-main">
        Datos del Contacto
      </q-card-section>

      <q-card-section class="row q-col-gutter-md">
        <c-input
          class="col-12"
          rounded
          outlined
          v-model="contato.name"
          :validator="$v.contato.name"
          @blur="$v.contato.name.$touch"
          label="Nombre"
        />
        <vue-tel-input
          class="col-12"
          rounded
          outlined
          :default-country="'br'"
          :preferred-countries="['br']"
          :auto-format="true"
        label="Número"
        :only-country="false"
        hint="El número de celular debe contener 9 dígitos y estar precedido por el DDI y DDD."
          v-model="contato.number"></vue-tel-input>
        <c-input
          class="col-12"
          outlined
          rounded
          :validator="$v.contato.email"
          @blur="$v.contato.email.$touch"
          v-model="contato.email"
          label="Correo"
        />
        <q-checkbox
          v-model="contato.disableBot"
          label="Desactivar BOT Interno"
        />
        <q-checkbox
          v-model="contato.disableCampaign"
          label="Desactivar Campaña"
        />
        <q-checkbox
          v-model="contato.disableKanban"
          label="Desactivar CRM"
        />
        <q-checkbox
          v-model="contato.ignore"
          label="Ignorar contacto"
        />
      </q-card-section>
      </div>

        <div class="full-width container-border container-rounded-10 q-ml-lg q-mr-lg">

          <q-card-section>
            <q-card
              class="bg-white q-mt-sm btn-rounded"
              bordered
              flat
            >
              <q-card-section class="font-family-main text-bold q-pb-none">
                CRM
                <q-separator />
              </q-card-section>
              <q-card-section class="q-pa-none">

                <c-input
                  class="col-12"
                  rounded
                  outlined
                  v-model="contato.kanbanPrice"
                  label="Valor en pauta($)"
                />

                <q-select
                  square
                  borderless
                  v-model="contato.kanbanId"
                  :options="kanbans"
                  use-chips
                  option-value="id"
                  option-label="name"
                  emit-value
                  map-options
                  dropdown-icon="add"
                  class="col-12"
                  @input="updateKanban"
                >
                  <!-- Plantillas para la lista de opciones -->
                  <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                    <q-item
                      v-bind="itemProps"
                      v-on="itemEvents"
                    >
                      <q-item-section avatar>
                        <!-- Muestra el color asociado al kanban -->
                        <div
                          :style="{ backgroundColor: opt.color, width: '24px', height: '24px', borderRadius: '50%' }"
                          title="Cor asociada"
                        ></div>
                      </q-item-section>
                      <q-item-section>
                        <!-- Muestra el nombre correctamente con fuente estilizada -->
                        <q-item-label class="text-bold">{{ opt.name }}</q-item-label>
                      </q-item-section>
                      <q-item-section side>
                        <q-checkbox
                          :value="selected"
                          @input="toggleOption(opt)"
                        />
                      </q-item-section>
                    </q-item>
                  </template>

                  <!-- Plantillas para el chip (opción seleccionada) -->
                  <template v-slot:selected-item="{ opt, remove }">
                    <div class="row items-center">
                      <!-- Color al lado del nombre en el chip -->
                      <div
                        :style="{ backgroundColor: opt.color, width: '16px', height: '16px', borderRadius: '50%', marginRight: '8px' }"
                      ></div>
                      <span class="text-body1">{{ opt.name }}</span>
                      <!-- Botón para desmarcar -->
                      <q-icon
                        name="close"
                        size="sm"
                        class="q-ml-xs cursor-pointer text-negative"
                        @click.stop="clearKanban(remove)"
                      />
                    </div>
                  </template>
                </q-select>

              </q-card-section>
            </q-card>
          </q-card-section>

        <q-card-section>
        <q-card
          class="bg-white q-mt-sm btn-rounded"
          bordered
          flat
        >
          <q-card-section class="font-family-main text-bold q-pb-none">
            Cartera
            <q-separator />
          </q-card-section>
          <q-card-section class="q-pa-none">
            <q-select
              square
              borderless
              v-model="contato.wallets"
              multiple
              :max-values="1"
              :options="usuarios"
              use-chips
              option-value="id"
              option-label="name"
              emit-value
              map-options
              dropdown-icon="add"
              class="col-12"
            >
              <!-- templates para opciones del q-select -->
              <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                <q-item
                  v-bind="itemProps"
                  v-on="itemEvents"
                >
                  <q-item-section>
                    <q-item-label v-html="opt.name"></q-item-label>
                  </q-item-section>
                  <q-item-section side>
                    <q-checkbox
                      :value="selected"
                      @input="toggleOption(opt)"
                    />
                  </q-item-section>
                </q-item>
              </template>
              <template v-slot:selected-item="{ opt }">
                <q-chip
                  dense
                  square
                  color="white"
                  text-color="primary"
                  class="q-ma-xs row col-12 text-body1"
                >
                  {{ opt.name }}
                </q-chip>
              </template>
              <template v-slot:no-option="{ itemProps, itemEvents }">
                <q-item
                  v-bind="itemProps"
                  v-on="itemEvents"
                >
                  <q-item-section>
                    <q-item-label class="text-negative text-bold">
                      ¡Ups... No hay carteras disponibles!
                    </q-item-label>
                  </q-item-section>
                </q-item>
              </template>
            </q-select>
          </q-card-section>
        </q-card>
      </q-card-section>
      <q-card-section>
        <q-card
          class="bg-white q-mt-sm btn-rounded"
          bordered
          flat
        >

          <q-card-section class="font-family-main text-bold q-pb-none">
            Etiqueta
            <q-separator />
          </q-card-section>
          <q-card-section class="q-pa-none">
            <q-select
              square
              borderless
              v-model="contato.tags"
              multiple
              :options="etiquetas"
              use-chips
              option-value="id"
              option-label="tag"
              emit-value
              map-options
              dropdown-icon="add"
              class="col-12"
            >
              <!-- plantillas para opciones del q-select -->
              <template v-slot:option="{ itemProps, itemEvents, opt, selected, toggleOption }">
                <q-item
                  v-bind="itemProps"
                  v-on="itemEvents"
                >
                  <q-item-section>
                    <q-item-label v-html="opt.tag"></q-item-label>
                  </q-item-section>
                  <q-item-section side>
                    <q-checkbox
                      :value="selected"
                      @input="toggleOption(opt)"
                    />
                  </q-item-section>
                </q-item>
              </template>
              <template v-slot:selected-item="{ opt }">
                <q-chip
                  dense
                  square
                  color="white"
                  text-color="primary"
                  class="q-ma-xs row col-12 text-body1"
                >
                  <q-icon :style="{ color: opt.color }" name="mdi-pound-box-outline" size="28px" class="q-mr-sm" />
                  {{ opt.tag }}
                </q-chip>
              </template>
              <template v-slot:no-option="{ itemProps, itemEvents }">
                <q-item
                  v-bind="itemProps"
                  v-on="itemEvents"
                >
                  <q-item-section>
                    <q-item-label class="text-negative text-bold">
                      ¡Ups... No hay etiquetas disponibles!
                    </q-item-label>
                  </q-item-section>
                </q-item>
              </template>
            </q-select>
          </q-card-section>
        </q-card>
      </q-card-section>
      </div>

      <div class="full-width container-border container-rounded-10 q-ml-lg q-mr-lg">
        <q-card-section class="font-family-main q-py-sm text-bold">
        Información adicional
      </q-card-section>

      <q-card-section class="row q-col-gutter-md justify-center">
        <template v-for="(extraInfo, index) in contato.extraInfo">
          <div :key="index" class="col-12 row justify-center q-col-gutter-sm">
            <q-input
              class="col-12 col-md-6"
              outlined
              v-model="extraInfo.name"
              label="Descripción"
            />
            <q-input
              class="col-12 col-md-6"
              outlined
              label="Información"
              v-model="extraInfo.value"
            />
            <div class="col q-pt-md">
              <q-btn
                :key="index"
                icon="delete"
                round
                flat
                color="negative"
                @click="removeExtraInfo(index)"
              />
            </div>
          </div>
        </template>
        <div class="col-12">
          <q-btn
            class="full-width color-light1"
            :class="{'full-width color-dark1' : $q.dark.isActive}"
            outline
            label="Agregar Información"
            @click="contato.extraInfo.push({ name: null, value: null })"
          />
        </div>
      </q-card-section>
      </div>
        <div class="full-width container-border container-rounded-10 q-ml-lg q-mr-lg">
          <q-card-section class="font-family-main q-py-sm text-bold">
            Anotaciones
          </q-card-section>
        <q-card-section class="row q-col-gutter-md justify-center">
            <div class="q-mt-sm">
              <div v-if="anotacoes.length > 0" class="q-mt-sm">
                <q-list>
                  <q-item
                    v-for="(anotacao, index) in anotacoes"
                    :key="index"
                    class="q-mb-sm"
                  >
                    <q-item-section>
                      <q-item-label
                        class="text-caption"
                        style="white-space: pre-wrap; word-wrap: break-word;"
                      >
                        {{ anotacao.note }}
                      </q-item-label>
                      <q-item-label caption class="text-caption">
                        Por: {{ anotacao.user.name }}
                      </q-item-label>
                      <q-item-label caption class="text-caption">
                        Creado en: {{ formatarData(anotacao.createdAt) }}
                      </q-item-label>
                      <q-item-label caption class="text-caption">
                        TicketID:
                        <a :href="getTicketUrl(anotacao.ticketId)">{{ anotacao.ticketId }}</a>
                      </q-item-label>
                    </q-item-section>

                    <!-- Botón eliminar (visible solo para admin) -->
                    <q-item-section side v-if="userProfile === 'admin'">
                      <q-btn
                        flat
                        dense
                        icon="mdi-delete"
                        @click="excluirAnotacao(anotacao.id, index)"
                        class="color-light1"
                        :class="$q.dark.isActive ? ('color-dark1') : ''"
                        title="Eliminar anotación"
                      />
                    </q-item-section>
                  </q-item>
                </q-list>
              </div>
              <p v-else class="text-caption">No hay anotaciones registradas.</p>
            </div>
          </q-card-section>
      </div>
      </div>

      <q-card-actions align="right" class="q-mt-lg">
        <q-btn class="q-px-md btn-rounded-50" label="Cancelar" color="negative" v-close-popup />
        <q-btn class="q-ml-lg q-px-md btn-rounded-50" icon="eva-save-outline" label="Guardar" color="primary" @click="saveContact" />
      </q-card-actions>
    </q-card>
  </q-dialog>

</template>

<script>
import { required, email, minLength, maxLength } from 'vuelidate/lib/validators'
import { ListarNotesContact, DeletarNote } from 'src/service/ticketnote'
import { ObterContato, CriarContato, EditarContato, EditarEtiquetasContato } from 'src/service/contatos'
import { ListarUsuarios } from 'src/service/user'
import { ListarEtiquetas } from 'src/service/etiquetas'
import { ListarKanbans, AlterarContactKanban2 } from 'src/service/kanban'
import { VueTelInput } from 'vue-tel-input'
export default {
  name: 'ContatoModal',
  components: {
    VueTelInput
  },
  props: {
    modalContato: {
      type: Boolean,
      default: false
    },
    contactId: {
      type: Number,
      default: null
    }
  },
  data () {
    return {
      userProfile: 'user',
      contato: {
        name: null,
        number: '+1',
        email: '',
        extraInfo: [],
        wallets: [],
        tags: [],
        disableBot: false,
        disableCampaign: false,
        disableKanban: false,
        ignore: false,
        kanbanId: null
      },
      anotacoes: [],
      usuarios: [],
      kanbans: [],
      etiquetas: []
    }
  },
  validations: {
    contato: {
      name: { required, minLength: minLength(3), maxLength: maxLength(50) },
      email: { email },
      number: { required, minLength: minLength(8) }
    }
  },
  methods: {
    async carregarAnotacoes(contactId) {
      try {
        const response = await ListarNotesContact(contactId)
        this.anotacoes = response.data
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: 'Ocurrió un error al cargar las anotaciones.'
        })
        console.error('Error al cargar anotaciones:', error)
      }
    },
    formatarData(data) {
      return new Date(data).toLocaleString()
    },
    async excluirAnotacao(id, index) {
      this.$q.dialog({
        title: '¡Atención!',
        message: '¿Realmente desea eliminar la anotación?',
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        // Só executa a exclusão quando o usuario clicar em "Sim"
        this.loading = true

        DeletarNote({ id })
          .then(() => {
            // Remove a anotação da lista localmente após exclusão bem-sucedida
            this.anotacoes.splice(index, 1)

            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: '¡Anotación eliminada!',
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .catch((error) => {
            console.error('Error al eliminar anotación:', error)

            this.$q.notify({
              type: 'negative',
              message: 'Error al eliminar anotación.'
            })
          })
          .finally(() => {
            this.loading = false // Para a loading state
          })
      })
    },
    clearKanban() {
      this.contato.kanbanId = null // Limpa o valor do kanbanId no modelo
      this.updateKanban(0) // Envia a atualização para o backend com valor 0
    },
    async updateKanban(newKanbanId) {
      try {
        const response = await AlterarContactKanban2({
          contactId: this.contato.id, // ID do contato
          kanbanId: newKanbanId || 0 // Novo valor do kanbanId ou 0 para desmarcar
        })
        this.$q.notify({
          type: 'info',
          progress: true,
          position: 'top',
          textColor: 'black',
          message: '¡CRM actualizado con éxito!',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        console.log('CRM actualizado con éxito:', response)
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          progress: true,
          position: 'top',
          message: 'Error al actualizar el CRM',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        console.error('Error al actualizar el Kanban:', error)
      }
    },
    async fetchContact () {
      try {
        await this.listarUsuarios()
        await this.getKanbans()
        if (!this.contactId) return
        const { data } = await ObterContato(this.contactId)
        await this.carregarAnotacoes(this.contactId)
        this.contato = data
        this.contato.number = `+${data.number}`
      } catch (error) {
        console.error(error)
        this.$notificarErro('¡Ocurrió un error!', error)
      }
    },
    removeExtraInfo (index) {
      const newData = { ...this.contato }
      newData.extraInfo.splice(index, 1)
      this.contato = { ...newData }
    },
    async saveContact() {
      this.$v.contato.$touch()
      if (this.$v.contato.$error) {
        return this.$q.notify({
          type: 'warning',
          progress: true,
          position: 'top',
          message: '¡Ops! Verifique los errores...',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      }

      const contato = {
        ...this.contato,
        number: this.contato.number.replace(/\D/g, '')
      }

      try {
        if (this.contactId) {
          const { data } = await EditarContato(this.contactId, contato)
          await EditarEtiquetasContato(this.contactId, [...this.contato.tags])
          this.$emit('contatoModal:contato-editado', data)
          this.$q.notify({
            type: 'info',
            progress: true,
            position: 'top',
            textColor: 'black',
            message: '¡Contacto editado!',
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else {
          const { data } = await CriarContato(contato)
          this.$q.notify({
            type: 'positive',
            progress: true,
            position: 'top',
            message: '¡Contacto creado!',
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
          this.$emit('contatoModal:contato-criado', data)
        }
        this.$emit('update:modalContato', false)
      } catch (error) {
        console.error('Erro capturado: ', error)

        // Verificar se o erro é "NOT_FOUND_WHATSAPP_CONNECTED" ou "CONTACT_NOT_FOUND"
        if (error.data && error.data.error === 'NOT_FOUND_WHATSAPP_CONNECTED') {
          this.$q.notify({
            type: 'negative',
            progress: true,
            position: 'top',
            message: 'No encontramos WhatsApp Conectado',
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else if (error.data && error.data.error === 'CONTACT_NOT_FOUND') {
          this.$q.notify({
            type: 'negative',
            progress: true,
            position: 'top',
            message: 'No encontramos WhatsApp en el número que intentó registrar',
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } else {
          this.$notificarErro('Ocurrió un error al crear el contacto', error)
        }
      }
    },
    getTicketUrl(ticketId) {
      const route = this.$router.resolve({ path: `/atendimento/${ticketId}` })
      return route.href
    },
    async listarUsuarios () {
      try {
        const { data } = await ListarUsuarios()
        this.usuarios = data.users
      } catch (error) {
        console.error(error)
        this.$notificarErro('Problema al cargar usuarios', error)
      }
    },
    async getKanbans() {
      const { data } = await ListarKanbans()
      this.kanbans = data
    },
    async listarEtiquetas() {
      try {
        const { data } = await ListarEtiquetas(true)
        this.etiquetas = data
      } catch (error) {
        console.error(error)
        this.$notificarErro('Problema al cargar etiquetas', error)
      }
    }
    // async tagSelecionada(tags) {
    //   await EditarEtiquetasContato(this.contactId, [...tags])
    // },
  },
  beforeMount() {
    this.listarEtiquetas()
    this.userProfile = localStorage.getItem('profile')
  },
  destroyed () {
    this.$v.contato.$reset()
  }
}
</script>

<style src="vue-tel-input/dist/vue-tel-input.css"></style>
