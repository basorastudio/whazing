import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert help URL setting into 'SettingsGeneral'
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('urlajuda', '', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted help URL setting
    await queryInterface.bulkDelete(
      'SettingsGeneral', // Adjust schema if needed
      {
        key: ['urlajuda']
      }
    );
  }
};

export = migration;