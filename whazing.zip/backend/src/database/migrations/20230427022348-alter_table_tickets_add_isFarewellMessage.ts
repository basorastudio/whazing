// --- START OF FILE 20230427022348-alter_table_tickets_add_isFarewellMessage.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Tickets";
    const columnName = "isFarewellMessage"; // 'isFarewell' + 'Message'
    const attributes = {
      type: DataTypes.BOOLEAN,
      allowNull: false, // Changed ![] to false
      defaultValue: false // Changed ![] to false
    };
    await queryInterface.addColumn(tableName, columnName, attributes);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Tickets";
    const columnName = "isFarewellMessage"; // 'isFarewell' + 'Message'
    await queryInterface.removeColumn(tableName, columnName);
  }
};

export default migration;
// --- END OF FILE 20230427022348-alter_table_tickets_add_isFarewellMessage.ts ---
