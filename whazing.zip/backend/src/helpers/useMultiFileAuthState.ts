import {
    AuthenticationCreds,
    AuthenticationState,
    SignalDataTypeMap,
    initAuthCreds,
    BufferJSON
} from '@adiwajshing/baileys'; // Assuming Baileys path
import { cacheLayer } from '../libs/cache'; // Assuming cacheLayer path
import { logger } from '../utils/logger'; // Assuming logger path

interface Session {
    id: string | number;
}

/**
 * Makes saveCreds safe concurrently
 */
function makeSaveCreds(cacheId: string) {
    let task = Promise.resolve();
    const saveCreds = async (creds: Partial<AuthenticationCreds>, type: 'creds' | string = 'creds') => {
        // Guarda la tarea para asegurar la ejecución secuencial
        task = task.then(async () => {
             logger.debug(`useMultiFileAuthState (writeData ${type})`);
            try {
                await cacheLayer.set(
                    `sessions:${cacheId}:${type}`, // Changed key structure slightly for clarity
                    JSON.stringify(creds, BufferJSON.replacer)
                );
            } catch (error: any) {
                logger.error({ error }, `useMultiFileAuthState (writeData error ${type})`);
                 logger.error(`writeData error: ${error?.message}`);
                 logger.error(`stack: ${error?.stack}`);
            }
        }).catch(error => {
             logger.error({ error }, `useMultiFileAuthState (saveCreds error ${type})`);
             logger.error(`saveCreds error: ${error?.message}`);
             logger.error(`stack: ${error?.stack}`);
        });
        await task;
    };
    return saveCreds;
}

export const useMultiFileAuthState = async (
    session: Session
): Promise<{ state: AuthenticationState; saveCreds: () => Promise<void> }> => {

    const cacheId = String(session.id); // Ensure cacheId is a string

    const writeData = async (data: any, file: string) => {
        logger.debug(`useMultiFileAuthState (writeData ${file})`);
        try {
            await cacheLayer.set(
                `sessions:${cacheId}:${file}`,
                JSON.stringify(data, BufferJSON.replacer)
            );
        } catch (error: any) {
             logger.error(`writeData ${file} error: ${error?.message}`);
             logger.error(`stack: ${error?.stack}`);
            // Consider re-throwing or handling differently
        }
    };

    const readData = async <T>(file: string): Promise<T | null> => {
         logger.debug(`useMultiFileAuthState (readData ${file})`);
        try {
            const data = await cacheLayer.get(`sessions:${cacheId}:${file}`);
            if (data) {
                return JSON.parse(data, BufferJSON.reviver);
            }
            return null;
        } catch (error: any) {
             logger.error(`Read data ${file} error: ${error?.message}`);
             logger.error(`stack: ${error?.stack}`);
            return null;
        }
    };

    const removeData = async (file: string) => {
         logger.debug(`useMultiFileAuthState (removeData ${file})`);
        try {
            await cacheLayer.del(`sessions:${cacheId}:${file}`);
        } catch (error: any) {
             logger.error(`removeData ${file} error: ${error?.message}`);
             logger.error(`stack: ${error?.stack}`);
        }
    };

    // Load creds from cache
    const creds: AuthenticationCreds = await readData<AuthenticationCreds>('creds') || initAuthCreds();

    const internalSaveCreds = makeSaveCreds(cacheId); // Use the concurrent-safe saver

    return {
        state: {
            creds,
            keys: {
                get: async <T extends keyof SignalDataTypeMap>(type: T, ids: string[]): Promise<{ [key: string]: SignalDataTypeMap[typeof type] }> => {
                    const data: { [key: string]: SignalDataTypeMap[typeof type] } = {};
                    await Promise.all(
                        ids.map(async (id) => {
                            let value = await readData<SignalDataTypeMap[typeof type]>(`${type}-${id}`);
                            if (type === 'app-state-sync-key' && value) {
                                // Baileys expects specific format for app-state-sync-key
                                value = proto.AppStateSyncKeyData.fromObject(value) as SignalDataTypeMap[typeof type];
                             }
                            data[id] = value!; // Using non-null assertion, handle null case if necessary
                        })
                    );
                     logger.debug(`useMultiFileAuthState (get ${type}) -> ${Object.keys(data).length} keys retrieved`);
                    return data;
                },
                set: async (data: Partial<{ [key in keyof SignalDataTypeMap]: { [key: string]: SignalDataTypeMap[key] } }>) => {
                     logger.debug(`useMultiFileAuthState (set) -> ${Object.keys(data).length} key types to set`);
                    const tasks: Promise<void>[] = [];
                    for (const category in data) {
                        for (const id in data[category as keyof typeof data]) {
                            const value = data[category as keyof typeof data]?.[id];
                            const file = `${category}-${id}`;
                            tasks.push(value ? writeData(value, file) : removeData(file));
                        }
                    }
                    await Promise.all(tasks);
                },
            },
        },
        saveCreds: () => internalSaveCreds(creds, 'creds') // Save the main creds file
    };
};