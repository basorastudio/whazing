import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'ratingMessage' column to the 'Whatsapps' table
    // Stores the message text sent for requesting a rating.
    await queryInterface.addColumn(
      'Whatsapps',       // Table name
      'ratingMessage',   // New column name
      {
        type: DataTypes.TEXT, // TEXT for potentially long messages
        // allowNull defaults to true
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'ratingMessage' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps',       // Table name
      'ratingMessage'    // Column name to remove
    );
  }
};

export = migration;