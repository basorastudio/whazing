import { QueryInterface, DataTypes, Sequelize } from "sequelize"; // Added Sequelize
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "WhatsappTemplates";
    // Create the 'WhatsappTemplates' table
    await queryInterface.createTable(tableName, {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      name: {
        // Template name
        type: DataTypes.STRING,
        allowNull: false
      },
      parameter_format: {
        // Format of parameters (e.g., JSON string, specific format)
        type: DataTypes.STRING, // Consider TEXT or JSONB if complex
        allowNull: true
      },
      components: {
        // Template components (likely JSON)
        type: DataTypes.JSONB, // Use JSONB for PostgreSQL, JSON or TEXT otherwise
        allowNull: true
      },
      language: {
        // Language code (e.g., 'en_US', 'pt_BR')
        type: DataTypes.STRING,
        allowNull: true
      },
      status: {
        // Template status (e.g., 'APPROVED', 'PENDING', 'REJECTED')
        type: DataTypes.STRING,
        allowNull: true
      },
      category: {
        // Template category (e.g., 'MARKETING', 'UTILITY')
        type: DataTypes.STRING,
        allowNull: true
      },
      sub_category: {
        // Optional sub-category
        type: DataTypes.STRING,
        allowNull: true
      },
      template_id: {
        // ID provided by WhatsApp/Meta
        type: DataTypes.STRING,
        allowNull: true
      },
      whatsappId: {
        type: DataTypes.INTEGER,
        references: { model: "Whatsapps", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE", // Delete templates if connection is deleted
        allowNull: false // Template must belong to a connection (changed from original logic which had no explicit nullability)
      },
      tenantId: {
        type: DataTypes.INTEGER,
        references: { model: "Tenants", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE", // Delete templates if tenant is deleted
        allowNull: false // Template must belong to a tenant
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE,
        defaultValue: Sequelize.fn("NOW")
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE,
        defaultValue: Sequelize.fn("NOW")
      }
    });

    // Add indexes for common lookups
    await queryInterface.addIndex(tableName, ["tenantId"]);
    await queryInterface.addIndex(tableName, ["whatsappId"]);
    await queryInterface.addIndex(tableName, ["tenantId", "whatsappId"]); // Composite
    await queryInterface.addIndex(tableName, ["template_id"]); // If searching by Meta ID
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'WhatsappTemplates' table
    await queryInterface.dropTable("WhatsappTemplates");
  }
};

export = migration;
