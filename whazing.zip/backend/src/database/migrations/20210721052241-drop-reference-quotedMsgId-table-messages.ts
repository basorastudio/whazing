import { QueryInterface, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la restricción de clave foránea para 'quotedMsgId'
    // El nombre 'Messages_quotedMsgId_fkey' es una convención común.
    const dropConstraintQuery = 'ALTER TABLE public."Messages" DROP CONSTRAINT "Messages_quotedMsgId_fkey";';
    return Promise.all([
        queryInterface.sequelize.query(dropConstraintQuery)
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Vuelve a añadir la restricción de clave foránea para 'quotedMsgId'
    const addConstraintQuery = `
        ALTER TABLE public."Messages"
        ADD CONSTRAINT "Messages_quotedMsgId_fkey"
        FOREIGN KEY ("quotedMsgId")
        REFERENCES "Messages"(id)
        ON UPDATE CASCADE
        ON DELETE SET NULL;
    `;
    return Promise.all([
        queryInterface.sequelize.query(addConstraintQuery)
    ]);
  }
};