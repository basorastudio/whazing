import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'channel' a la tabla 'Tickets'
    return Promise.all([
      queryInterface.addColumn('Tickets', 'channel', {
        type: DataTypes.STRING,
        allowNull: true, // Permite nulos
        defaultValue: 'whatsapp' // Valor predeterminado 'whatsapp'
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'channel' de la tabla 'Tickets'
    return Promise.all([
      queryInterface.removeColumn('Tickets', 'channel')
    ]);
  }
};