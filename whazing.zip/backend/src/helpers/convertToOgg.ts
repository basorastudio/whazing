// Original: convertToOgg.js
// Deobfuscated, converted to TS, and translated

'use strict';

import { Worker, isMainThread, parentPort, workerData } from 'worker_threads';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegStatic from 'ffmpeg-static'; // Usar el path desde ffmpeg-static
import fs from 'fs';
import path from 'path';

// Configura la ruta del ejecutable de ffmpeg
if (ffmpegStatic) {
    ffmpeg.setFfmpegPath(ffmpegStatic);
} else {
    console.error("ffmpeg-static path not found. Conversion might fail.");
}


// Define el tipo para los datos pasados al worker
interface WorkerData {
    inputFile: string;
    outputFile: string;
}

// Define el tipo para los mensajes enviados desde el worker
type WorkerMessage =
  | { type: 'progress'; data: number }
  | { type: 'complete'; outputFile: string } // Incluir outputFile en complete
  | { type: 'error'; error: string };


// Función principal de conversión (puede ser llamada por el worker o el hilo principal)
async function convertFileToOgg(inputFile: string, outputFile: string): Promise<void> {
     // Verifica si el archivo de entrada existe
    if (!fs.existsSync(inputFile)) {
         // Traducido: Archivo de entrada no encontrado
        const errorMsg = `Input file not found: ${inputFile}`;
         if (parentPort) {
             parentPort.postMessage({ type: 'error', error: errorMsg } as WorkerMessage);
         }
        throw new Error(errorMsg);
    }

     // Verifica si el formato de entrada es soportado (mp3 o mp4)
    const inputFileExtension = path.extname(inputFile).toLowerCase();
    if (!['.mp3', '.mp4'].includes(inputFileExtension)) {
         // Traducido: Formato de archivo de entrada no soportado. Use .mp3 o .mp4
        const errorMsg = `Input file format not supported. Use .mp3 or .mp4: ${inputFileExtension}`;
         if (parentPort) {
             parentPort.postMessage({ type: 'error', error: errorMsg } as WorkerMessage);
         }
        throw new Error(errorMsg);
    }

    return new Promise((resolve, reject) => {
        ffmpeg(inputFile)
            .outputFormat('ogg') // Especifica formato de salida ogg
            .audioCodec('libopus') // Usa el códec opus para ogg
            .audioChannels(1) // Establece canales de audio a mono
            .audioBitrate('16k') // Establece bitrate de audio (ej. 16k)
             // Opción para evitar timestamps negativos, puede no ser necesario
            .outputOptions('-avoid_negative_ts make_zero')
            .noVideo() // Asegura que no se procese video
            .on('progress', (progress: { percent?: number }) => {
                if (progress.percent && parentPort) {
                    parentPort.postMessage({ type: 'progress', data: Math.round(progress.percent) } as WorkerMessage);
                }
            })
            .on('end', () => {
                if (parentPort) {
                    // Enviar la ruta del archivo de salida en el mensaje 'complete'
                    parentPort.postMessage({ type: 'complete', outputFile } as WorkerMessage);
                }
                resolve();
            })
            .on('error', (err: Error) => {
                 // Traducido: Error desconocido en la conversión
                const errorMessage = err instanceof Error ? err.message : 'Unknown conversion error';
                console.error("Error during conversion:", errorMessage);
                if (parentPort) {
                    parentPort.postMessage({ type: 'error', error: errorMessage } as WorkerMessage);
                }
                reject(new Error(errorMessage));
            })
            .save(outputFile); // Guarda el archivo de salida
    });
}


// Función exportada que maneja la lógica del worker
export async function convertToOgg(inputFile: string): Promise<string> {

     // Verifica si el archivo de entrada existe
    if (!fs.existsSync(inputFile)) {
         // Traducido: Archivo de entrada no encontrado
        console.error(`Input file not found: ${inputFile}`);
        throw new Error('Input file not found.');
    }

     // Verifica si el formato de entrada es soportado (mp3 o mp4)
    const inputFileExtension = path.extname(inputFile).toLowerCase();
    if (!['.mp3', '.mp4'].includes(inputFileExtension)) {
         // Traducido: Formato de archivo de entrada no soportado. Use .mp3 o .mp4
        console.error(`Input file format not supported. Use .mp3 or .mp4: ${inputFileExtension}`);
        throw new Error('Input file format not supported. Use .mp3 or .mp4.');
    }

     // Genera el nombre del archivo de salida
    const outputFile = inputFile.replace(/\.(mp3|mp4)$/i, '.ogg');

    if (isMainThread) {
         // Si está en el hilo principal, crea un worker
        return new Promise((resolve, reject) => {
            const worker = new Worker(__filename, {
                workerData: { inputFile, outputFile } as WorkerData
            });

            worker.on('message', (message: WorkerMessage) => {
                switch (message.type) {
                    case 'complete':
                        resolve(message.outputFile); // Resuelve con la ruta del archivo de salida
                        break;
                    case 'error':
                         // Traducido: Error en el Worker
                        reject(new Error(`Worker error: ${message.error}`));
                        break;
                    case 'progress':
                         // Opcional: Manejar el progreso
                        break;
                }
            });

            worker.on('error', (err) => {
                 // Traducido: Error fatal en el Worker
                reject(new Error(`Fatal worker error: ${err.message}`));
            });

            worker.on('exit', (code) => {
                if (code !== 0) {
                     // Traducido: Worker parado con código
                    reject(new Error(`Worker stopped with exit code ${code}`));
                }
            });
        });
    } else {
         // Si está en el worker thread, ejecuta la conversión
        try {
            const { inputFile: workerInput, outputFile: workerOutput } = workerData as WorkerData;
            await convertFileToOgg(workerInput, workerOutput);
             // 'complete' message is sent inside convertFileToOgg
        } catch (error: any) {
            console.error("Error in worker:", error);
             // 'error' message is sent inside convertFileToOgg
        }
         // No retornar explícitamente aquí, la comunicación es vía mensajes
        return Promise.resolve(outputFile); // Devolver algo para satisfacer tipo
    }
}

// Ejecuta la conversión si este script se corre como worker
if (!isMainThread) {
    const { inputFile: workerInput, outputFile: workerOutput } = workerData as WorkerData;
    convertFileToOgg(workerInput, workerOutput)
        .then(() => {
            // console.log("Worker finished successfully.");
        })
        .catch(error => {
            console.error("Worker conversion failed:", error);
            // process.exit(1);
        });
}