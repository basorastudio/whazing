import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'isForwarded' column to the 'Messages' table
    await queryInterface.addColumn(
      'Messages',    // Table name
      'isForwarded', // New column name
      {
        type: DataTypes.BOOLEAN,
        defaultValue: false, // Default to false
        // allowNull defaults to true, but defaultValue implies it might be intended as non-null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'isForwarded' column from the 'Messages' table
    await queryInterface.removeColumn(
      'Messages',    // Table name
      'isForwarded'  // Column name to remove
    );
  }
};

export = migration;