// --- START OF FILE AppError.ts ---

/**
 * Represents a custom application error.
 */
class AppError {
  /**
   * The error message.
   * @type {string}
   */
  public message: string;

  /**
   * The HTTP status code associated with the error.
   * Defaults to 400 (Bad Request).
   * @type {number}
   */
  public statusCode: number;

  /**
   * Creates an instance of AppError.
   * @param {string} message - The error message.
   * @param {number} [statusCode=400] - The HTTP status code.
   */
  constructor(message: string, statusCode: number = 400) {
    this.message = message;
    this.statusCode = statusCode;
  }
}

export default AppError;

// --- END OF FILE AppError.ts ---