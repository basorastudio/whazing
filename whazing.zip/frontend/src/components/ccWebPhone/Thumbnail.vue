<template>
  <div :class="['thumbnail', { 'is-rounded': variant === 'circle' }]">
    <q-avatar :size="size" class="thumbnail-avatar">
      <img
        v-if="src"
        :src="src"
        @error="onImgError"
        style="object-fit: scale-down; background-color: darkcyan"
      />
      <q-icon v-else name="account_circle" class="thumbnail-icon" size="100%" />
    </q-avatar>
    <div class="thumbnail-info">
      <div class="thumbnail-username">{{ username }}</div>
      <!-- <q-badge
        v-if="status"
        :color="statusColor"
        class="status-badge absolute-top-right"
        label=""
      /> -->
    </div>
  </div>
</template>

<script>
export default {
  name: 'Thumbnail',
  props: {
    src: {
      type: String,
      default: ''
    },
    username: {
      type: String,
      default: 'User'
    },
    size: {
      type: String,
      default: '40px'
    },
    status: {
      type: String,
      default: ''
    },
    variant: {
      type: String,
      default: 'circle'
    }
  },
  data() {
    return {
      // Define any data properties if needed
    }
  },
  computed: {
    statusColor() {
      switch (this.status) {
        case 'online':
          return 'green'
        case 'busy':
          return 'orange'
        case 'offline':
          return 'grey'
        default:
          return 'transparent'
      }
    }
  },
  methods: {
    onImgError(event) {
      event.target.src = 'user-profile-avatar.png'
    }
  }
}
</script>

<style scoped>
.thumbnail {
  display: flex;
  align-items: center;
  position: relative;
}

.thumbnail-avatar {
  margin-right: 8px;
}

.thumbnail-info {
  display: flex;
  flex-direction: column;
}

.thumbnail-username {
  font-weight: bold;
}

.status-badge {
  position: absolute;
  top: 0;
  right: 0;
}
</style>
