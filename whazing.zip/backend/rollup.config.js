const { rollup } = require('rollup');

const inputOptions = {
  input: 'dist/server.js', // Path to your project's entry file
};

const outputOptions = {
  file: 'dist/bundle.js', // Output bundled file
  format: 'iife', // Bundle format (e.g., IIFE for browser usage)
};

async function build() {
  // Bundle files using Rollup
  const bundle = await rollup(inputOptions);
  await bundle.write(outputOptions);
}

build();


