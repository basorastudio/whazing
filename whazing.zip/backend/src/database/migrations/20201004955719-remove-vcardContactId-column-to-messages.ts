import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna vcardContactId de la tabla Messages (si existe)
    // Es seguro ejecutar removeColumn aunque no exista (Sequelize lo maneja)
    // o se puede añadir una verificación con describeTable si es necesario.
    return queryInterface.removeColumn('Messages', 'vcardContactId');
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Vuelve a añadir la columna vcardContactId (reversión de la migración)
    return queryInterface.addColumn('Messages', 'vcardContactId', {
      type: DataTypes.INTEGER,
      references: {
        model: 'Contacts', // Asumiendo que referenciaba a Contacts
        key: 'id'
      },
      onUpdate: 'CASCADE',
      onDelete: 'CASCADE', // O la política original si era diferente
      allowNull: true // Asumiendo que podía ser nulo
    });
  }
};