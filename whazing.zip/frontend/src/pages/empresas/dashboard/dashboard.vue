<template>
  <div class="flex justify-center" style="width: 100%;">
      <q-card class="dashboard-container-cards">
      <q-card-section class="dashboard-cards q-pa-md q-mb-sm">
        <div class="row justify-center ">

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3': $q.dark.isActive}"
              class="my-card full-height"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.versaoSistema') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ versionStatus.currentVersion }}
                    </p>
                    <p class="my-card-text text-caption" v-if="versionStatus.status === 'updated'">
                      {{ $t('dashboardsaas.sistemaAtualizado') }}
                    </p>
                    <p class="my-card-text text-caption" v-else>
                      {{ $t('dashboardsaas.novaVersaoDisponivel') }}: {{ versionStatus.newVersion }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon
                      :name="premium ? 'mdi-crown' : 'mdi-information'"
                      size="xl"
                      :color="premium ? 'gold' : '#2f2f2f'"
                      class="my-card-content"
                    />
                    <p class="my-card-text text-caption my-card-content">
                      {{ premium ? $t('dashboardsaas.versaoPremium') : $t('dashboardsaas.versaoFree') }}
                    </p>
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.empresasCadastradas') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ quantidadeTenants }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-office-building" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                    <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.empresasAtivas') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ quantidadeTenantsActive }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-office-building-plus" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.empresasInativas') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ quantidadeTenants - quantidadeTenantsActive }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-office-building-remove" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.totalUsuarios') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ quantidadeUsuarios }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="mdi-account-multiple" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.totalContatos') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ contatos }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="eva-people-outline" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.totalTickets') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ tickets }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="mdi-ticket-outline" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.totalMensagens') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ mensagem }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="mdi-forum-outline" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">{{ $t('dashboardsaas.totalConexoes') }}</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ whatsapp }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="mdi-whatsapp" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
        </div>
      </q-card-section>
    </q-card>

    <!-- Modal de Termos de Uso para usuários não premium -->
    <q-dialog v-model="mostrarTermosModal" persistent>
      <q-card style="width: 700px; max-width: 90vw;">
        <q-card-section class="bg-primary text-white">
          <div class="text-h6">Termos de Uso</div>
        </q-card-section>

        <q-card-section class="q-pa-md" style="max-height: 70vh; overflow-y: auto;">
          <div class="text-weight-bold q-mb-md">Termos de Uso</div>

          <div class="text-weight-bold">1. Aceitação dos Termos</div>
          <p>Ao utilizar este software, você concorda com os termos e condições estabelecidos abaixo. Caso não concorde com estes termos, por favor, não utilize o software. O uso contínuo do software indica sua aceitação dos termos.</p>

          <div class="text-weight-bold">2. Validador de Licença</div>
          <p>Nosso sistema inclui um validador de licença que coleta informações específicas para verificar a legitimidade da sua instalação. As informações coletadas incluem o endereço IP da instalação, a URL associada e a versão do software em uso. Essas informações são necessárias para garantir que a licença esteja em conformidade com os termos de uso do software.</p>

          <div class="text-weight-bold">3. Versões do Software</div>
          <p>O software está disponível em duas versões: Grátis e Premium.</p>

          <p>- <span class="text-weight-bold">Versão Grátis</span>: Esta versão do software é oferecida gratuitamente. No entanto, ela possui limitações de uso, incluindo o máximo de 10 usuários, 2 canais, e suporte exclusivamente ao canal WhatsApp. A versão grátis é fornecida <span class="text-weight-bold">sem qualquer garantia de suporte, atualizações ou personalização</span>.</p>

          <p class="text-negative text-weight-bold q-pa-sm bg-grey-2">- Proibição de Whitelabel: É terminantemente proibida a modificação da interface do sistema, incluindo remoção ou substituição de logotipos, textos ou qualquer outra referência à marca Whazing. O descumprimento desta regra pode constituir violação de direitos autorais e de propriedade intelectual, sujeitando o usuário às medidas legais cabíveis, inclusive ações judiciais e indenização por danos.</p>

          <p>- <span class="text-weight-bold">Versão Premium</span>: A versão premium do software não possui os limites da versão grátis. A sua utilização está condicionada ao pagamento da taxa de licença, conforme os termos estabelecidos no contrato de licença. Nessa versão, o suporte, atualizações e eventuais customizações estão disponíveis de acordo com o plano contratado.</p>

          <div class="text-weight-bold">4. Propriedade Intelectual e Medidas Legais</div>
          <p>Todo o conteúdo, código-fonte, identidade visual, logotipo, marca e demais elementos que compõem o software são de propriedade exclusiva da empresa desenvolvedora e estão protegidos pelas leis de direitos autorais, propriedade intelectual e tratados internacionais aplicáveis.</p>
          <p><span class="text-negative text-weight-bold">É expressamente proibido copiar, distribuir, modificar, praticar engenharia reversa, piratear ou violar de qualquer forma a licença de uso deste software.</span></p>
          <p>Qualquer tentativa de burlar o sistema de licenciamento, remover referências à marca <span class="text-weight-bold">Whazing</span>, ou distribuir versões não autorizadas será considerada violação grave e resultará na responsabilização legal do infrator, incluindo a adoção de medidas judiciais, reparação de danos, perdas e indenizações cabíveis, além de outras sanções civis e penais previstas em lei.</p>

          <div class="text-weight-bold">5. Uso Responsável e Conformidade Legal</div>
          <p>Ao utilizar este software, você concorda em usá-lo de maneira responsável e em conformidade com todas as leis e regulamentações aplicáveis, incluindo as leis de proteção de dados e privacidade vigentes no Brasil. Você também concorda que o uso do software está condicionado à aceitação destes termos. Caso não concorde, deve cessar imediatamente o uso do software.</p>

          <div class="text-weight-bold">6. Limitação de Responsabilidade</div>
          <p>A empresa desenvolvedora deste software não se responsabiliza por quaisquer danos diretos ou indiretos decorrentes do uso do software. O usuário é o único responsável por assegurar que o uso do software esteja de acordo com as leis e regulamentos aplicáveis.</p>

          <div class="text-weight-bold">7. Alterações nos Termos</div>
          <p>Reservamo-nos o direito de modificar estes termos a qualquer momento, sem aviso prévio. É sua responsabilidade revisar periodicamente os termos de uso para se manter informado sobre quaisquer alterações. O uso contínuo do software após a publicação de alterações significa que você aceita e concorda com as modificações.</p>

          <div class="text-weight-bold">8. Aceitação dos Termos</div>
          <p>O uso do software só é permitido se você aceitar integralmente estes termos. Caso não aceite qualquer parte destes termos, não utilize o software.</p>
        </q-card-section>

        <q-card-actions align="right" class="bg-white text-primary">
          <q-btn flat label="Recusar" color="negative" @click="recusarTermos" />
          <q-btn flat label="Aceitar" color="primary" @click="aceitarTermos" />
        </q-card-actions>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
import { getQuantidadeTenants, getQuantidadeTenantsActive, getMesagem, getWhatsapp, getContact, getTicket, GetVersion } from 'src/service/dashboardEmpresas'
import { getQuantidadeUsuarios } from 'src/service/user'

import { Listarp } from 'src/service/configuracoesgeneral'

export default {
  data () {
    return {
      quantidadeTenants: 0,
      quantidadeUsuarios: 0,
      quantidadeTenantsActive: 0,
      mensagem: 0,
      whatsapp: 0,
      contatos: 0,
      tickets: 0,
      premium: true,
      versionStatus: {
        status: '',
        message: '',
        currentVersion: '',
        newVersion: ''
      },
      mostrarTermosModal: false,
      termosAceitos: false
    }
  },
  methods: {
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    async loadVersion() {
      try {
        const response = await GetVersion()
        const { status, message, currentVersion, newVersion } = response.data
        this.versionStatus = {
          status: status,
          message: message,
          currentVersion: currentVersion,
          newVersion: newVersion || ''
        }
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    aceitarTermos() {
      this.termosAceitos = true
      this.mostrarTermosModal = false
      localStorage.setItem('termosAceitos', 'true')

      this.$q.notify({
        type: 'positive',
        message: 'Termos aceitos com sucesso!',
        progress: true,
        actions: [{
          icon: 'close',
          round: true,
          color: 'white'
        }]
      })
    },
    recusarTermos() {
      this.mostrarTermosModal = false

      this.$q.notify({
        type: 'warning',
        message: 'Você precisa aceitar os termos para utilizar as funcionalidades do sistema.',
        progress: true,
        actions: [{
          icon: 'close',
          round: true,
          color: 'white'
        }]
      })

      this.efetuarLogout()
    },
    async efetuarLogout () {
      try {
        localStorage.removeItem('token')
        localStorage.removeItem('username')
        localStorage.removeItem('profile')
        localStorage.removeItem('userId')
        localStorage.removeItem('queues')
        localStorage.removeItem('usuario')
        localStorage.removeItem('filtrosAtendimento')

        this.$router.go({ name: 'login', replace: true })
      } catch (error) {
        this.$notificarErro('Não foi possível realizar logout', error)
      }
    },
    async verificarTermos() {
      const termosAceitosAntes = localStorage.getItem('termosAceitos') === 'true'

      await this.loadVersionp()

      if (!this.premium && !termosAceitosAntes) {
        this.mostrarTermosModal = true
      }
    }
  },
  mounted () {
    this.verificarTermos()
    this.loadVersion()
    getQuantidadeTenants().then(quantidade => {
      this.quantidadeTenants = quantidade
    })
    getQuantidadeUsuarios().then(response => {
      this.quantidadeUsuarios = response.data.totalUsers
    }).catch(error => {
      console.error('Erro ao obter quantidade de usuários:', error)
    })
    getQuantidadeTenantsActive().then(quantidade => {
      this.quantidadeTenantsActive = quantidade
    })
    getMesagem().then(quantidade => {
      this.mensagem = quantidade.count
    })
    getContact().then(quantidade => {
      this.contatos = quantidade.count
    })
    getTicket().then(quantidade => {
      this.tickets = quantidade.count
    })
    getWhatsapp().then(quantidade => {
      this.whatsapp = quantidade
    }
    )
  }
}
</script>

<style scoped>
</style>
