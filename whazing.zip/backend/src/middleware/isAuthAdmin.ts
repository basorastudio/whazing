/**
 * Middleware para autenticar administradores específicos basados en un dominio de email
 * definido en variables de entorno y usando un token JWT en el header Authorization.
 */
import { Response, NextFunction } from "express";
import { verify } from "jsonwebtoken";
import AppError from "../errors/AppError";
import authConfig from "../config/auth";
import User from "../models/User";
import { AuthRequest } from "./interfaces/AuthRequest"; // Importa la interfaz

interface TokenPayload {
  id: string | number;
  profile: string;
  tenantId: string | number;
  iat: number;
  exp: number;
}

const isAuthAdmin = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  const authHeader = req.headers.authorization;
  const adminDomain = process.env.ADMIN_DOMAIN; // Obtiene el dominio admin de las variables de entorno

  // Verifica si el header Authorization existe
  if (!authHeader) {
    throw new AppError("Token no proporcionado.", 401); // 401 Unauthorized
  }

  // Verifica si el dominio de administrador está definido en el entorno
  if (!adminDomain) {
    console.error("Error: ADMIN_DOMAIN no está definido en las variables de entorno.");
    // El mensaje original era "No existen dominios admin definidos"
    throw new AppError("No existen dominios admin definidos.", 500); // Error de configuración del servidor
  }

  // Divide el header ("Bearer TOKEN_AQUI")
  const [, token] = authHeader.split(" ");

  try {
    // Verifica el token JWT
    const decoded = verify(token, authConfig.secret);
    const { id, profile, tenantId } = decoded as TokenPayload;

    // Busca al usuario en la base de datos para verificar su email
    // Asume que el modelo User tiene una propiedad 'email'
    const user = await User.findByPk(id);

    // Verifica si el usuario existe y si su email pertenece al dominio admin permitido
    // El original usaba `indexOf(adminDomain) > -1`, lo cual es un poco laxo (podría coincidir en cualquier parte).
    // Es más seguro usar `endsWith` para verificar si el email termina con `@dominioadmin.com`.
    // Ajusta la lógica según necesites (ej. `@${adminDomain}` si solo guardas el dominio).
    if (!user || !user.email || !user.email.endsWith(`@${adminDomain}`)) {
       // El mensaje original era "No es admin del dominio admin"
      throw new AppError(`No es administrador del dominio ${adminDomain}`, 403); // 403 Forbidden
    }

    // Si la verificación del token y del dominio del email es exitosa,
    // adjunta la información del usuario al objeto request
    req.user = {
      id,
      profile, // Podrías verificar si profile es 'admin' aquí también si es necesario
      tenantId,
      email: user.email
    };

    // Pasa al siguiente middleware/controlador
    return next();

  } catch (err) {
     // Manejo de errores
      if (err instanceof AppError) {
          // Si ya es un AppError (lanzado desde la validación de dominio)
          throw err;
      } else if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
          // Si es un error de verificación de JWT
          // El mensaje original era "Token inválido o no Admin" - separaremos los casos
          throw new AppError("Token inválido o expirado.", 401); // 401 Unauthorized
      } else {
          // Otros errores inesperados
          console.error("Error inesperado en middleware isAuthAdmin:", err);
          throw new AppError("Error interno del servidor durante la autenticación.", 500);
      }
  }
};

export default isAuthAdmin; // Exportación default