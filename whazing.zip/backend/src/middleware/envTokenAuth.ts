/**
 * Middleware para autenticar solicitudes basado en un token proporcionado
 * en el cuerpo (body) o en los parámetros de consulta (query), comparándolo
 * con un token esperado definido en las variables de entorno.
 */
import { Response, NextFunction } from "express";
import AppError from "../errors/AppError";
import { AuthRequest } from "./interfaces/AuthRequest"; // Importa la interfaz

const envTokenAuth = (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): void => {
  // Obtiene el token esperado de la variable de entorno
  const expectedToken = process.env.ENV_TOKEN;

  // Lanza un error si el token esperado no está configurado en el entorno (Error del Servidor)
  if (!expectedToken) {
      console.error("Error: ENV_TOKEN no está definido en las variables de entorno.");
      throw new AppError("Error de configuración del servidor.", 500);
  }

  // Intenta obtener el token de los parámetros de consulta (query) o del cuerpo (body)
  const tokenFromQuery = req.query.token as string | undefined;
  const tokenFromBody = req.body.token as string | undefined;

  let providedToken: string | undefined = undefined;

  if (tokenFromBody) {
      providedToken = tokenFromBody;
  } else if (tokenFromQuery) {
      providedToken = tokenFromQuery;
  }

  // Compara el token proporcionado con el esperado
  if (providedToken && providedToken === expectedToken) {
      // Si coinciden, permite continuar
      return next();
  }

  // Si no se proporcionó token o no coincide, lanza un error (Unauthorized)
  // El mensaje original era "Token inválido", podríamos usar ese o ser más específicos.
  throw new AppError("Token inválido o faltante.", 401); // 401 Unauthorized
};

export default envTokenAuth; // Exportación default