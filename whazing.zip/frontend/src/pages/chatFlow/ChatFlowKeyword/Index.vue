<template>
  <div>
    <q-banner v-if="!premium" dense inline-actions class="bg-amber-8 text-white q-mb-md">
      <template v-slot:avatar>
        <q-icon name="star" />
      </template>
      {{ $t('general.msgRecursoPremium') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               icon="mdi-whatsapp"
               :label="$t('general.linkobterpremium')"
               @click="abrirWhatsApp3"
        />
      </template>
    </q-banner>

    <q-card-section v-if="!premium">
      <div class="row items-center justify-around q-col-gutter-md">
        <!-- Texto -->
        <div class="col-xs-12 col-sm-6 text-left">
          <div class="text-h6">
            {{ $t('dashboard.supportPlatform') }}
          </div>
          <div class="text-body q-mt-sm">
            {{ $t('dashboard.donationMessage') }}
          </div>
        </div>
        <!-- Imagem -->
        <div class="col-xs-12 col-sm-4 text-center">
          <img src="https://raw.githubusercontent.com/cleitonme/Whazing-SaaS/main/donate.jpg"
               alt="QR Code para doação via Pix"
               class="donation-image">
        </div>
      </div>
      <!-- Ícones de redes sociais -->
      <div class="row justify-center q-mt-md">
        <div class="social-icons">
          <q-btn round color="green" icon="mdi-whatsapp" size="md" class="q-mx-xs"
                 type="a" href="https://grupo.whazing.com.br/" target="_blank">
            <q-tooltip>Nosso Grupo de WhatsApp</q-tooltip>
          </q-btn>
          <q-btn round color="primary" icon="mdi-web" size="md" class="q-mx-xs"
                 type="a" href="https://www.whazing.com.br" target="_blank">
            <q-tooltip>Nosso Site</q-tooltip>
          </q-btn>
        </div>
      </div>
    </q-card-section>
    <div class="row">
      <div class="col">
        <q-table
          square
          flat
          bordered
          class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
          :class="{
    'full-height': $q.screen.lt.sm
  }"
          hide-bottom
          :data="listachatFlowKeyword"
          :columns="columns"
          :loading="loading"
          row-key="id"
          :pagination.sync="pagination"
          :rows-per-page-options="[0]"
        >
          <template v-slot:top-left>
            <div>
              <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
                <q-icon name="mdi-robot-outline q-pr-sm" />
                {{ $t('chatbotkeyword.titulo') }}
              </h2>
              <q-btn
                class="generate-button btn-rounded-50"
                :class="{'generate-button-dark' : $q.dark.isActive}"
                icon="eva-plus-outline"
                :label="$t('chatbot.add')"
                @click="keywordSelecionado = {}; modalChatFlowKeyword = true"
              />
              <q-btn flat
                     class="generate-button btn-rounded-50"
                     :class="{'generate-button-dark' : $q.dark.isActive}"
                     v-if="whatsappNumber"
                     icon="mdi-whatsapp"
                     :label="$t('chatbot.callSupport')"
                     @click="abrirWhatsApp"
              />
            </div>

          </template>
          <template v-slot:body-cell-chatFlowId="props">
            <q-td>
              {{ getChatFlowName(props.value) }}
            </q-td>
          </template>
          <template v-slot:body-cell-whatsappId="props">
            <q-td>
              {{ getWhatsappName(props.value) }}
            </q-td>
          </template>
          <template v-slot:body-cell-isActive="props">
            <q-td class="text-center">
              <q-icon
                size="16px"
                :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                :color="props.value ? 'positive' : 'negative'"
                class=""
              />
              <span class="q-mx-xs text-bold">
              {{ props.value ? $t('chatbot.active') : $t('chatbot.inactive') }}
              </span>
            </q-td>
          </template>
          <template v-slot:body-cell-acoes="props">
            <q-td class="text-center">
              <q-btn
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                icon="eva-edit-outline"
                flat
                round
                @click="editKeyword(props.row)"
              >
                <q-tooltip>
                  {{ $t('chatbot.edit') }}
                </q-tooltip>
              </q-btn>
              <q-btn
                icon="eva-trash-outline"
                flat
                round
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                @click="deletarFluxo(props.row)"
                v-if="userProfile === 'admin'"
              >
                <q-tooltip>
                  {{ $t('chatbot.delete') }}
                </q-tooltip>
              </q-btn>
            </q-td>
          </template>

        </q-table>
      </div>
    </div>

    <ModalChatFlowKeyword
      :modalChatFlowKeyword.sync="modalChatFlowKeyword"
      :keywordEdicao.sync="keywordSelecionado"
      @keyword:criada="novoKeywordCriado"
      @keyword:atualizada="keywordEditado"
    />

    <q-dialog v-model="confirmDelete" persistent>
      <q-card style="min-width: 350px">
        <q-card-section>
          <div class="text-h6">{{ $t('chatbotkeyword.deletar') }}</div>
          <div>{{ keywordSelecionado.keyword }}</div>
        </q-card-section>
        <q-card-actions align="right" class="text-primary">
          <q-btn
            :label="$t('general.no')"
            v-close-popup
            class="q-mr-md"
            color="primary"
          />
          <q-btn :label="$t('general.yes')" color="negative" v-close-popup @click="confirmDeleteFoo()" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import { DeletarChatFlowKeyword, ListarChatFlow, ListarChatFlowKeyword } from 'src/service/chatFlow'
import { ListarConfiguracaoPublica, Listarp } from 'src/service/configuracoesgeneral'
import ModalChatFlowKeyword from './ModalChatFlowKeyword.vue'
import { mapGetters } from 'vuex'

export default {
  name: 'ChatFlowIndex',
  components: { ModalChatFlowKeyword },
  data () {
    return {
      userProfile: 'user',
      confirmDelete: false,
      listachatFlowKeyword: [],
      listachatFlow: [],
      modalChatFlowKeyword: false,
      whatsappNumber: null,
      premium: true,
      keywordSelecionado: {},
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        searchParam: null,
        hasMore: true
      },
      loading: false,
      columns: [
        { name: 'keyword', label: this.$t('chatbotkeyword.keyword'), field: 'keyword', align: 'left' },
        { name: 'chatFlowId', label: this.$t('chatbotkeyword.fluxo'), field: 'chatFlowId', align: 'left' },
        { name: 'whatsappId', label: this.$t('chatbotkeyword.whatsapp'), field: 'whatsappId', align: 'left' },
        { name: 'isActive', label: this.$t('chatbot.status'), field: 'isActive', align: 'center' },
        { name: 'acoes', label: this.$t('chatbot.actions'), field: 'acoes', align: 'center' }
      ]
    }
  },
  computed: {
    ...mapGetters([
      'whatsapps'
    ])
  },
  methods: {
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configurações:', error)
      }
    },
    getChatFlowName(chatFlowId) {
      if (!chatFlowId || !this.listachatFlow) return '-'
      const chatFlow = this.listachatFlow.find(flow => flow.id === chatFlowId)
      return chatFlow ? chatFlow.name : chatFlowId
    },
    novoKeywordCriado(keyword) {
      const lista = [...this.listachatFlowKeyword]
      lista.push(keyword)
      this.listachatFlowKeyword = lista
    },
    keywordEditado(keyword) {
      const lista = [...this.listachatFlowKeyword.filter(k => k.id !== keyword.id)]
      lista.push(keyword)
      this.listachatFlowKeyword = lista
    },
    editKeyword(keyword) {
      this.keywordSelecionado = keyword
      this.modalChatFlowKeyword = true
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const message = encodeURIComponent(this.$t('chatbot.whatsapp'))
        const url = `https://wa.me/${this.whatsappNumber}?text=${message}`
        window.open(url, '_blank')
      }
    },
    abrirWhatsApp3() {
      const message = encodeURIComponent(this.$t('general.obterpremium'))
      const url = `https://wa.me/554899416725?text=${message}`
      window.open(url, '_blank')
    },
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    getWhatsappName(whatsappId) {
      if (!whatsappId || !this.whatsapps) return '-'
      const whatsapp = this.whatsapps.find(w => w.id === whatsappId)
      return whatsapp ? whatsapp.name : whatsappId
    },
    async listarChatFlowKeyword () {
      const { data } = await ListarChatFlowKeyword()
      this.listachatFlowKeyword = data.chatFlowKeyword
    },
    editFlow (flow) {
      this.chatFlowSelecionado = flow
      this.modalChatFlow = true
    },
    deletarFluxo (flow) {
      this.chatFlowSelecionado = flow
      this.confirmDelete = true
    },
    async confirmDeleteFoo (flow) {
      await DeletarChatFlowKeyword(this.chatFlowSelecionado)
      await this.listarChatFlowKeyword()
    },
    async listarChatFlow () {
      const { data } = await ListarChatFlow()
      this.listachatFlow = data.chatFlow
    }
  },
  async mounted () {
    this.userProfile = localStorage.getItem('profile')
    this.fetchConfigurations()
    await this.listarChatFlowKeyword()
    await this.listarChatFlow()
    await this.loadVersionp()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px
</style>
