// --- START OF FILE MessageController.ts ---

import type { Request, Response } from 'express';
import AppError from '../errors/AppError'; // Assuming path
import DeleteMessageSystem from '../services/MessageServices/DeleteMessageSystem'; // Assuming path
import SetTicketMessagesAsRead from '../helpers/SetTicketMessagesAsRead'; // Assuming path
import Message from '../models/Message'; // Assuming path
import Ticket from '../models/Ticket'; // Assuming path
import Setting from '../models/Setting'; // Assuming path
import CreateForwardMessageService from '../services/WbotServices/CreateForwardMessageService'; // Assuming path
import CreateMessageSystemService from '../services/MessageServices/CreateMessageSystemService'; // Assuming path
import ListMessagesServicePDF from '../services/MessageServices/ListMessagesServicePDF'; // Assuming path
import ListMessagesService from '../services/MessageServices/ListMessagesService'; // Assuming path
import ShowTicketService from '../services/TicketServices/ShowTicketService'; // Assuming path
import { logger } from '../utils/logger'; // Assuming path
import EditWhatsAppMessage from '../services/WbotServices/EditWhatsAppMessage'; // Assuming path
import SendWhatsAppReaction from '../services/WbotServices/SendWhatsAppReaction'; // Assuming path
import CheckSettingsHelper from '../helpers/CheckSettingsHelper'; // Assuming path
import { RefreshToken } from '../helpers/RefreshToken'; // Assuming path
import socketEmit from '../helpers/socketEmit'; // Assuming path
import SendHubReaction from '../services/WbotNotificame/SendHubReaction'; // Assuming path

interface IndexQuery {
    pageNumber?: string;
}

interface IndexPDFQuery extends IndexQuery {
    audits?: string; // Assuming 'audits' is a query param for PDF
}

interface StoreBody {
    body: string; // Can be an array stringified, or single message
    fromMe?: boolean; // Optional, defaults might be applied in service
    read?: boolean; // Optional
    quotedMsgId?: string; // Optional
    scheduleDate?: string; // Optional, expects date string
    sendType?: string; // Optional
    status?: string; // Optional
    idFront?: string; // Optional
    mediaType?: string; // Optional, if sending media info directly
    mediaUrl?: string; // Optional
    mediaName?: string; // Optional
}

interface EditBody {
    body: string;
}

interface ForwardBody {
    messages: Message[]; // Array of message objects to forward
    contact: any; // Define a proper Contact type/interface if available
}

interface ReactionBody {
    messageId: string;
    ticketId: string; // Added based on usage
    reaction: string;
}

interface CheckWindowParams {
    ticketId: string;
}


export const index = async (req: Request, res: Response): Promise<Response> => {
    const { ticketId } = req.params;
    const { pageNumber } = req.query as IndexQuery;
    const { tenantId } = req.user;
    const userId = req.user.id;

    const {
        count,
        messages,
        messagesOffLine,
        ticket,
        hasMore
    } = await ListMessagesService({
        pageNumber,
        ticketId,
        tenantId,
        userId // Pass userId for potential permission checks in service
    });

    let setMessagesAsRead = false;
    // Logic for setting messages as read based on user profile and settings
    if (req.user.profile === 'user') {
        if (ticket.status === 'open') {
             await SetTicketMessagesAsRead(ticket);
             setMessagesAsRead = true;
        }
    } else {
        // Check setting for non-user profiles
        const setting = await Setting.findOne({
            where: { key: 'auditMode', tenantId }
        });
        if (setting?.value !== 'enabled') {
            // Check token validation (similar logic as in PWA controller)
             const tokeniz = 'd1a25cdd43'; // Example token key
             const tokenValid = await RefreshToken(tokeniz);
             const tokenizCor = '870a1e69ab'; // Example token key
             const tokenValidCor = await RefreshToken(tokenizCor);
             const checkCor = await CheckSettingsHelper(tokenValidCor); // Check the validation result

             if (checkCor !== tokenValid) { // If tokens DON'T match
                if (ticket.status === 'open') {
                    await SetTicketMessagesAsRead(ticket);
                    setMessagesAsRead = true;
                }
             }
        }
    }
    // Emit socket event if messages were potentially marked as read
    if (!setMessagesAsRead) {
         // Original logic had an emission here even if not marked as read.
         // Keeping it, but might need review based on intended functionality.
         socketEmit({
             tenantId: ticket.tenantId,
             type: 'ticket:update', // Event type
             payload: ticket // Payload
         });
     }


    return res.json({ count, messages, messagesOffLine, ticket, hasMore });
};

export const indexPDF = async (req: Request, res: Response): Promise<Response> => {
    const { ticketId } = req.params;
    const auditsParam = String(req.query.audits); // Ensure it's treated as string
    const { pageNumber } = req.query as IndexPDFQuery;
    const { tenantId } = req.user;
    const userId = req.user.id;

    const {
        count,
        messages,
        messagesOffLine,
        ticket,
        hasMore
    } = await ListMessagesServicePDF({
        pageNumber,
        ticketId,
        tenantId,
        userId,
        audits: auditsParam // Pass the audits parameter
    });

    return res.json({ count, messages, messagesOffLine, ticket, hasMore });
};

// Assuming this is meant to count all messages globally or per tenant?
// Adjust service call/logic if it needs tenantId or other filters.
export const ListCountMensagens = async (req: Request, res: Response): Promise<Response> => {
    try {
        const count = await Message.count(); // Simple global count
        return res.json({ count });
    } catch (error: any) {
        console.error("Erro ao contar as mensagens.", error); // Traducido
        // Differentiate error types if possible
        if (error instanceof AppError) {
             return res.status(error.statusCode).json({ error: error.message });
        }
        return res.status(500).json({ error: 'Erro ao contar as mensagens.' }); // Traducido
    }
};


export const store = async (req: Request, res: Response): Promise<Response> => {
    const { ticketId } = req.params;
    const userId = Number(req.user.id);
    const tenantId = Number(req.user.tenantId);
    const messageData = req.body as StoreBody;
    const medias = req.files as Express.Multer.File[] | undefined; // Type for uploaded files

    const ticket = await ShowTicketService({ id: ticketId, tenantId });

    try {
        // Mark messages as read for the ticket before sending a new one
        await SetTicketMessagesAsRead(ticket);
    } catch (err) {
        // Log error but proceed with sending message
        console.error("Erro ao definir mensagens como lidas:", err); // Traducido
    }

    try {
        if (messageData.scheduleDate) {
            // Handle scheduled message creation
            const msg = {
                body: messageData.body,
                fromMe: true, // Scheduled messages are always fromMe
                read: true,
                quotedMsgId: messageData.quotedMsgId,
            };
            await CreateMessageSystemService({
                msg: msg,
                tenantId: tenantId,
                medias: medias, // Pass medias if schedule service supports them
                ticket: ticket,
                userId: userId,
                scheduleDate: new Date(messageData.scheduleDate),
                sendType: messageData.sendType || 'schedule',
                status: 'scheduled', // Or appropriate status for scheduled
                idFront: messageData.idFront
            });
        } else if (medias && medias.length > 0) {
            // Handle messages with media
            await Promise.all(medias.map(async (media, index) => {
                 const msg = {
                     fromMe: true, // Assuming messages sent via API are fromMe
                     body: Array.isArray(messageData.body) ? messageData.body[index] : messageData.body, // Handle array of bodies or single body
                     idFront: Array.isArray(messageData.idFront) ? messageData.idFront[index] : messageData.idFront, // Handle array of IDs or single ID
                     read: true,
                     quotedMsgId: messageData.quotedMsgId,
                 };
                await CreateMessageSystemService({
                    msg: msg,
                    tenantId: tenantId,
                    medias: [media], // Send one media per message creation call
                    ticket: ticket,
                    userId: userId,
                    scheduleDate: messageData.scheduleDate ? new Date(Array.isArray(messageData.scheduleDate) ? messageData.scheduleDate[index] : messageData.scheduleDate) : undefined, // Handle array of schedule dates
                    sendType: messageData.sendType || 'chat', // Default sendType
                    status: 'pending', // Default status
                    idFront: msg.idFront, // Pass the correct idFront
                });
            }));
        } else {
            // Handle simple text message
            const msg = {
                body: messageData.body,
                fromMe: true,
                read: true,
                quotedMsgId: messageData.quotedMsgId,
            };
            await CreateMessageSystemService({
                msg: msg,
                tenantId: tenantId,
                medias: medias, // Pass empty or undefined
                ticket: ticket,
                userId: userId,
                scheduleDate: messageData.scheduleDate ? new Date(messageData.scheduleDate) : undefined,
                sendType: messageData.sendType || 'chat',
                status: 'pending',
                idFront: messageData.idFront
            });
        }
    } catch (err) {
        // Log the error but don't necessarily throw, maybe just return 500?
        // The original code just logged and continued.
        console.error("Erro ao tentar Criar Mensagem:", err); // Traducido
    }

    return res.send(); // Original code just sends empty response on success/completion
};


export const edit = async (req: Request, res: Response): Promise<Response> => {
    const { messageId } = req.params;
    const { tenantId } = req.user;
    const tenant = Number(tenantId);
    const { body } = req.body as EditBody;

    try {
        const { ticketId, message } = await EditWhatsAppMessage({
            messageId,
            tenantId: tenant,
            body
        });
        // Optionally emit socket event or return updated message
        return res.send(); // Original code sends empty response
    } catch (err: any) {
        // Specific check for AppError with ERR_EDITING_WAPP_MSG code
        if (err instanceof AppError && err.message === 'ERR_EDITING_WAPP_MSG') {
            return res.status(400).json({ error: err.message }); // Return 400 Bad Request
        }
        // Rethrow other errors or handle them
        logger.error(`Error editing message ${messageId}: ${err.message}`); // Log other errors
        throw err; // Let global error handler catch it or return 500
    }
};


export const remove = async (req: Request, res: Response): Promise<Response> => {
    const { messageId } = req.params;
    const { tenantId } = req.user;
    const userId = req.user.id; // Get user ID for the service

    try {
        await DeleteMessageSystem(userId, messageId, tenantId);
        return res.send(); // Send empty success response
    } catch (error: any) {
        logger.error("ERR_DELETE_SYSTEM_MSG G: ", error); // Keep original log format
        throw new AppError("ERR_DELETE_SYSTEM_MSG"); // Keep original error code
    }
};

export const forward = async (req: Request, res: Response): Promise<Response> => {
    const { messages, contact } = req.body as ForwardBody;
    const { user } = req; // Get user from request (added by auth middleware)

    for (const message of messages) {
        await CreateForwardMessageService({
            userId: Number(user.id),
            tenantId: Number(user.tenantId),
            message,
            contact,
            ticketIdOrigin: message.ticketId // Pass the original ticket ID
        });
    }
    return res.send(); // Send empty success response
};


export const addReaction = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { messageId, reaction } = req.body as ReactionBody;
        const { ticketId } = req.params; // Assuming ticketId is in params now
        const { id: userId } = req.user; // User who is reacting

        // Fetch the ticket with contact information included
        const ticket = await Ticket.findByPk(ticketId, {
             include: ["contact"]
         });

         if (!ticket) {
             throw new AppError("Ticket no encontrado", 404); // Traducido
         }


        let reactionResult: any; // To store result from either service

        // Determine which service to call based on ticket channel
        if (ticket.channel === 'whatsapp') {
            reactionResult = await SendWhatsAppReaction({
                 messageId,
                 ticket,
                 reactionType: reaction
             });
        } else if (ticket.channel === 'hub_whatsapp') { // Assuming 'hub_whatsapp' is the channel name
             reactionResult = await SendHubReaction({
                 messageId,
                 ticket,
                 reactionType: reaction
             });
        } else {
            throw new AppError(`Reacciones no soportadas para el canal: ${ticket.channel}`, 400); // Traducido
        }


        return res.status(200).json({
            message: 'Reacción adicionada con suceso!', // Traducido
            reactionResponse: reactionResult, // Send back the result from the service
            reaction: reaction // Also send back the applied reaction
        });

    } catch (error: any) {
        console.error("Erro ao adicionar reação:", error); // Traducido
        if (error instanceof AppError) {
            return res.status(error.statusCode).json({ error: error.message });
        }
        return res.status(500).json({
             error: 'Erro ao adicionar reação', // Traducido
             details: error.message // Include details for debugging
        });
    }
};


export const checkMessageWindow = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { ticketId } = req.params as CheckWindowParams;
        const { tenantId } = req.user;

        if (!ticketId || isNaN(parseInt(ticketId))) {
            return res.status(400).json({ error: 'Valid ticketId is required' }); // Keep original
        }

        const lastMessage = await Message.findOne({
            where: {
                ticketId: parseInt(ticketId),
                fromMe: false, // Look for last message *from contact*
                tenantId: tenantId
            },
            order: [['createdAt', 'DESC']] // Get the latest one
        });

        if (!lastMessage) {
            // No message from contact yet, window is effectively open? Or closed?
            // Depending on business logic, you might consider this open or needing an initial message.
            // Returning false (window closed) seems safer if interaction is needed.
             return res.status(200).json({ isWithin24Hours: false, lastMessageTimestamp: null });
        }

        const lastMessageTimestamp = lastMessage.createdAt;
        const now = new Date();
        const diffHours = (now.getTime() - lastMessageTimestamp.getTime()) / (1000 * 60 * 60);

        const isWithin24Hours = diffHours < 24;

        return res.status(200).json({ isWithin24Hours, lastMessageTimestamp });

    } catch (error: any) {
        console.error("Error checking message window:", error); // Keep original
        if (error instanceof Error) { // Check if it's a standard Error
            return res.status(500).json({ error: 'Error checking message window', details: error.message }); // Keep original
        }
        return res.status(500).json({ error: 'Error checking message window', details: 'Unknown error' }); // Keep original
    }
};


// --- END OF FILE MessageController.ts ---