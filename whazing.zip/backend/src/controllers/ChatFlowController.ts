import { Request, Response } from 'express';
import CreateChatFlowService from '../services/ChatFlowServices/CreateChatFlowService';
import ListChatFlowService from '../services/ChatFlowServices/ListChatFlowService';
import UpdateChatFlowService from '../services/ChatFlowServices/UpdateChatFlowService';
import DeleteChatFlowService from '../services/ChatFlowServices/DeleteChatFlowService';
import ListChatFlowKeywordService from '../services/ChatFlowServices/ListChatFlowKeywordService';
import DeleteChatFlowKeywordService from '../services/ChatFlowServices/DeleteChatFlowKeywordService';
import CreateChatFlowKeywordService from '../services/ChatFlowServices/CreateChatFlowKeywordService';
import UpdateChatFlowKeywordService from '../services/ChatFlowServices/UpdateChatFlowKeywordService';

// Interface for ChatFlow data structure (adjust based on actual structure)
interface ChatFlowData {
  flow: any; // Define a more specific type for the flow structure if possible
  name: string;
  isActive?: boolean;
  userId?: number;
  tenantId: number;
  celularTeste?: string; // Assuming 'celularTeste' maps to this
  acceptAudio?: boolean; // Assuming 'AcceptAudio' maps to this
  acceptVideo?: boolean; // Assuming 'AcceptVideo' maps to this
  acceptDocument?: boolean; // Assuming 'AcceptDoc' maps to this
  acceptDonwload?: boolean;
  acceptMedia?: boolean;
  acceptLocation?: boolean;
  acceptVcard?: boolean;
}

interface ChatFlowKeywordData {
    keyword: string;
    isActive?: boolean;
    tenantId: number;
    chatFlowId: number;
    userId: number;
}


export const store = async (req: Request, res: Response): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  const flowData: Omit<ChatFlowData, 'tenantId' | 'userId'> = { ...req.body }; // Exclude fields set below

  const serviceData: ChatFlowData = {
    flow: flowData.flow,
    name: flowData.name,
    isActive: true, // Default to active on creation?
    userId: Number(req.user.id),
    tenantId: tenantId,
    celularTeste: flowData.celularTeste,
    acceptAudio: flowData.acceptAudio,
    acceptVideo: flowData.acceptVideo,
    acceptDocument: flowData.acceptDocument,
    acceptDonwload: flowData.acceptDonwload,
    acceptMedia: flowData.acceptMedia,
    acceptLocation: flowData.acceptLocation,
    acceptVcard: flowData.acceptVcard
  };

  const chatFlow = await CreateChatFlowService(serviceData);

  return res.status(201).json(chatFlow); // 201 Created
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const listData = { tenantId: Number(tenantId) };
  const chatFlows = await ListChatFlowService(listData);
  return res.status(200).json(chatFlows);
};

export const update = async (req: Request, res: Response): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  const flowDataUpdate: Partial<ChatFlowData> = { ...req.body }; // Partial as not all fields might be updated
  const { chatFlowId } = req.params;

  const serviceData = {
    chatFlowData: { // Nest the data as expected by UpdateChatFlowService
        flow: flowDataUpdate.flow,
        name: flowDataUpdate.name,
        isActive: flowDataUpdate.isActive,
        // userId should likely not be updated here, maybe creation user?
        celularTeste: flowDataUpdate.celularTeste,
        acceptAudio: flowDataUpdate.acceptAudio,
        acceptVideo: flowDataUpdate.acceptVideo,
        acceptDocument: flowDataUpdate.acceptDocument,
        acceptDonwload: flowDataUpdate.acceptDonwload,
        acceptMedia: flowDataUpdate.acceptMedia,
        acceptLocation: flowDataUpdate.acceptLocation,
        acceptVcard: flowDataUpdate.acceptVcard
    },
    chatFlowId: parseInt(chatFlowId, 10),
    tenantId: tenantId,
    // userId: Number(req.user.id) // Pass userId if service needs it for validation/logging
  };

  const chatFlow = await UpdateChatFlowService(serviceData);

  return res.status(200).json(chatFlow);
};

export const remove = async (req: Request, res: Response): Promise<Response> => {
  const { chatFlowId } = req.params;
  const { tenantId } = req.user;

  const deleteData = {
    id: parseInt(chatFlowId, 10),
    tenantId: Number(tenantId),
  };

  await DeleteChatFlowService(deleteData);

  return res.status(200).json({ message: 'ChatFlow eliminado' });
};

export const indexkeyword = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const listData = { tenantId: Number(tenantId) };
  const keywords = await ListChatFlowKeywordService(listData);
  return res.status(200).json(keywords);
};

export const removekeyword = async (req: Request, res: Response): Promise<Response> => {
  const { chatFlowId } = req.params; // Assuming this is the keyword ID, rename param if needed
  const { tenantId } = req.user;

  const deleteData = {
    id: parseInt(chatFlowId, 10), // Use the correct ID (keyword ID)
    tenantId: Number(tenantId),
  };

  await DeleteChatFlowKeywordService(deleteData);

  return res.status(200).json({ message: 'ChatFlow Keyword eliminado' });
};

export const storekeyword = async (req: Request, res: Response): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  const keywordData: Omit<ChatFlowKeywordData, 'tenantId' | 'userId'> = req.body;

  const serviceData: ChatFlowKeywordData = {
    keyword: keywordData.keyword,
    isActive: true, // Default to active?
    tenantId: tenantId,
    chatFlowId: keywordData.chatFlowId, // Ensure chatFlowId is passed in body
    userId: Number(req.user.id),
  };

  const newKeyword = await CreateChatFlowKeywordService(serviceData);

  return res.status(201).json(newKeyword); // 201 Created
};

export const updatekeyword = async (req: Request, res: Response): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  const keywordUpdateData: Partial<ChatFlowKeywordData> = req.body;
  const { id } = req.params; // Assuming this is the keyword ID

  const serviceData = {
    chatFlowData: { // Service might expect nested data
      keyword: keywordUpdateData.keyword,
      isActive: keywordUpdateData.isActive,
      chatFlowId: keywordUpdateData.chatFlowId,
      userId: keywordUpdateData.userId // Allow updating associated user? Be careful.
    },
    id: parseInt(id, 10), // Keyword ID
    tenantId: tenantId,
  };

  const updatedKeyword = await UpdateChatFlowKeywordService(serviceData);

  return res.status(200).json(updatedKeyword);
};