<template>
  <div>
    <q-table
      flat
      bordered
      square
      hide-bottom
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      title="Tareas"
      :data="tarefas"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="eva-list-outline" />
            Tareas
          </h2>
          <div class="row flex-gap-col-1">
            <q-input
              :class="{
                'order-last q-mt-md': $q.screen.width < 500
              }"
              class="contact-search"
              style="width: 300px"
              filled
              dense
              debounce="500"
              v-model="filter"
              clearable
              placeholder="Localizar"
              @input="filtrarTarefa"
            >
              <template v-slot:prepend>
                <q-icon name="search" />
              </template>
            </q-input>
            <q-select
              v-model="params.status"
              :options="statusOptions"
              option-value="value"
              option-label="label"
              label="Filtrar por Estado"
              @input="listarTarefas"
              class="contact-search"
              style="width: 300px"
              filled
              dense
              clearable
              debounce="500"
            />
            <q-btn
              icon="eva-plus-outline"
              label="Añadir"
              class="generate-button btn-rounded-50"
              :class="{'generate-button-dark' : $q.dark.isActive}"
              @click="tarefaEdicao = {}; modalTarefa = true"
            />
          </div>
        </div>
      </template>
      <template v-slot:body-cell-color="props">
        <q-td class="text-center">
          <div
            class="q-pa-sm rounded-borders"
            :style="`background: ${props.row.color}`"
          >
            {{ props.row.color }}
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon
            size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-eye-outline"
            @click="visualizarTarefa(props.row)"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              Ver detalles de la tarea
            </q-tooltip>
          </q-btn>

          <q-btn
            flat
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            round
            icon="mdi-check-circle-outline"
            @click="concluirTarefa(props.row)"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              Haga clic para completar la tarea
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="mdi-content-copy"
            @click="duplicarTarefa(props.row)"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              Haga clic para duplicar la tarea
            </q-tooltip>
          </q-btn>
          <q-btn
            v-if="userProfile === 'admin' || userProfile === 'supervisor'"
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-edit-outline"
            @click="editarTarefa(props.row)"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              Haga clic para editar la tarea
            </q-tooltip>
          </q-btn>
          <q-btn
            v-if="userProfile === 'admin' || userProfile === 'supervisor'"
            flat
            round
            icon="eva-trash-outline"
            @click="deletarTarefa(props.row)"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
          >
            <q-tooltip
              anchor="top middle"
              self="bottom middle"
              :offset="[0, 10]"
            >
              Haga clic para eliminar la tarea
            </q-tooltip>
          </q-btn>
        </q-td>
      </template>
    </q-table>
    <ModalTarefa
      :modalTarefa.sync="modalTarefa"
      :tarefaEdicao.sync="tarefaEdicao"
      @modal-tarefa:criada="tarefaCriada"
      @modal-tarefa:editada="tarefaEditada"
    />

    <q-dialog v-model="modalVisualizacao">
      <q-card style="width: 700px; max-width: 80vw;">
        <q-card-section class="row items-center">
          <div class="text-h6">Detalles de la Tarea</div>
          <q-space />
          <q-btn
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="close" flat round dense v-close-popup />
        </q-card-section>

        <q-card-section>
          <div class="q-gutter-y-md">
            <div>
              <div class="text-subtitle2">Tarea</div>
              <div>{{ tarefaSelecionada.name }}</div>
            </div>

            <div>
              <div class="text-subtitle2">Descripción</div>
              <div>{{ tarefaSelecionada.description }}</div>
            </div>

            <div>
              <div class="text-subtitle2">Estado</div>
              <div>
                  {{ formatStatus(tarefaSelecionada.status) }}
              </div>
            </div>

            <div>
              <div class="text-subtitle2">Fecha y Hora Límite</div>
              <div>{{ formatDate(tarefaSelecionada.limitDate) }}</div>
            </div>

            <div>
              <div class="text-subtitle2">Prioridad</div>
              <div>
                  {{ formatPriority(tarefaSelecionada.priority) }}
              </div>
            </div>

            <div>
              <div class="text-subtitle2">Comentarios</div>
              <div>
                {{ tarefaSelecionada.comments }}
              </div>
            </div>
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
import { DeletarTarefa, ListarTarefas, AlterarTarefa, CriarTarefa } from 'src/service/tarefas'
import ModalTarefa from './ModalTarefa'
import { ListarCores } from 'src/service/configuracoesgeneral'
export default {
  name: 'Tarefas',
  components: {
    ModalTarefa
  },
  data () {
    return {
      userProfile: 'user',
      modalVisualizacao: false,
      tarefaSelecionada: {},
      statusOptions: [
        { label: '⚠️ En Retraso', value: 'delayed' },
        { label: '🕒 En Progreso', value: 'pending' },
        { label: '🎉 Completada', value: 'finished' }
      ],
      params: {
        status: '',
        searchParam: ''
      },
      filter: null,
      tarefaEdicao: {},
      modalTarefa: false,
      tarefas: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'status', label: 'Estado', field: 'status', align: 'left', format: (val) => this.formatStatus(val) },
        { name: 'name', label: 'Tarea', field: 'name', align: 'left' },
        { name: 'description', label: 'Descripción', field: 'description', align: 'left', format: (val) => this.formatComments(val) },
        { name: 'limitDate', label: 'Fecha y Hora Límite', field: 'limitDate', align: 'left', format: (val) => this.formatDate(val) },
        { name: 'owner', label: 'Responsable', field: 'owner', align: 'left' },
        { name: 'priority', label: 'Prioridad', field: 'priority', align: 'left', format: (val) => this.formatPriority(val) },
        { name: 'comments', label: 'Comentarios', field: 'comments', align: 'left', format: (val) => this.formatComments(val) },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores devueltos por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    visualizarTarefa (tarefa) {
      this.tarefaSelecionada = { ...tarefa }
      this.modalVisualizacao = true
    },
    async listarTarefas() {
      this.params.status = this.params.status && this.params.status.value ? this.params.status.value : null

      const { data } = await ListarTarefas({ status: this.params.status })

      let tarefas = []
      if (this.userProfile === 'admin' || this.userProfile === 'supervisor') {
        tarefas = data
      } else {
        tarefas = data.filter((e) => e.owner === localStorage.getItem('username'))
      }

      const statusOrder = { delayed: 1, pending: 2, finished: 3 }
      const priorityOrder = { high: 1, medium: 2, low: 3, none: 4 }

      tarefas.sort((a, b) => {
        if (a.status === 'finished' && b.status !== 'finished') {
          return 1
        }
        if (a.status !== 'finished' && b.status === 'finished') {
          return -1
        }

        const dateA = new Date(a.limitDate)
        const dateB = new Date(b.limitDate)

        if (dateA.getTime() !== dateB.getTime()) {
          return dateA - dateB
        }

        const statusComparison = statusOrder[a.status] - statusOrder[b.status]
        if (statusComparison !== 0) return statusComparison

        return priorityOrder[a.priority] - priorityOrder[b.priority]
      })

      this.tarefas = tarefas
    },
    async listarTarefasFiltro() {
      this.loading = true
      const response = await ListarTarefas()
      const tarefas = response.data
      try {
        const searchTerm = this.params.searchParam.toLowerCase()
        const tarefasFiltradas = tarefas.filter(tarefa => {
          const tarefaAsString = JSON.stringify(tarefa).toLowerCase()
          return tarefaAsString.includes(searchTerm)
        })
        this.LOAD_TAREFAS(tarefasFiltradas)
      } catch (e) {
        this.tarefas = response.data
      }
      this.loading = false
    },

    filtrarTarefa(data) {
      this.tarefas = []
      this.params.searchParam = data
      this.loading = true
      this.listarTarefasFiltro()
      this.loading = false
    },

    LOAD_TAREFAS(tarefasFiltradas) {
      this.tarefas = tarefasFiltradas
    },

    formatComments(comment) {
      if (comment && comment.length > 30) {
        return comment.substring(0, 30) + '...'
      }
      return comment
    },

    formatStatus(value) {
      const statusMap = {
        delayed: '⚠️ En Retraso',
        pending: '🕒 En Progreso',
        finished: '🎉 Completada'
      }
      return statusMap[value] || value
    },

    formatPriority(value) {
      const priorityMap = {
        high: '⏰ Urgente',
        medium: '⌛ Plazo Moderado',
        low: '🕗 Poca Urgencia',
        none: '🕰️ Sin Prisa'
      }
      return priorityMap[value] || value
    },

    formatDate(dateString) {
      const date = new Date(dateString)
      const day = date.getDate().toString().padStart(2, '0')
      const month = (date.getMonth() + 1).toString().padStart(2, '0')
      const year = date.getFullYear()
      const hours = date.getHours().toString().padStart(2, '0')
      const minutes = date.getMinutes().toString().padStart(2, '0')
      return `${day}-${month}-${year} ${hours}:${minutes}`
    },

    tarefaCriada(tarefa) {
      const newTarefas = [...this.tarefas]
      newTarefas.push(tarefa)
      this.tarefas = [...newTarefas]
    },

    tarefaEditada(tarefa) {
      const newTarefas = [...this.tarefas]
      const idx = newTarefas.findIndex(f => f.id === tarefa.id)
      if (idx > -1) {
        newTarefas[idx] = tarefa
      }
      this.tarefas = [...newTarefas]
    },

    editarTarefa(tarefa) {
      this.tarefaEdicao = { ...tarefa }
      this.modalTarefa = true
    },

    async concluirTarefa(tarefa) {
      this.loading = true
      try {
        const tarefaAtualizada = {
          ...tarefa,
          status: 'finished'
        }
        const { data } = await AlterarTarefa(tarefaAtualizada)
        this.$emit('modal-tarefa:editada', data)
        this.$q.notify({
          type: 'info',
          progress: true,
          position: 'top',
          textColor: 'black',
          message: '¡Tarea finalizada!',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        window.location.reload()
      } catch (error) {
        console.error(error)
      }
      this.loading = false
    },

    async duplicarTarefa(tarefa) {
      this.loading = true
      try {
        const tarefaAtualizada = {
          ...tarefa
        }
        const { data } = await CriarTarefa(tarefaAtualizada)
        this.$emit('modal-tarefa:criada', data)
        this.$q.notify({
          type: 'info',
          progress: true,
          position: 'top',
          textColor: 'black',
          message: '¡Tarea duplicada!',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
        window.location.reload()
      } catch (error) {
        console.error(error)
      }
      this.loading = false
    },

    async checarAtrasadas() {
      try {
        const { data } = await ListarTarefas()
        let tarefasAtualizadas = false
        const atualizacoes = data.map(async (tarefa) => {
          // Comparación directa de fechas en zona horaria local del usuario
          const limitDate = new Date(tarefa.limitDate)
          const hoje = new Date()
          
          if ((limitDate < hoje && tarefa.status !== 'finished')) {
            const tarefaAtualizada = {
              ...tarefa,
              status: 'delayed'
            }
            await AlterarTarefa(tarefaAtualizada)
            tarefasAtualizadas = true
          }
        })
        await Promise.all(atualizacoes)
        if (tarefasAtualizadas) {
          // Opcional: Actualizar la interfaz sin recargar completamente
          await this.listarTarefas()
        }
      } catch (error) {
        console.error('Error al verificar tareas atrasadas:', error)
      }
    },

    deletarTarefa(tarefa) {
      this.$q.dialog({
        title: '¡Atención!',
        message: `¿Realmente desea eliminar la Tarea "${tarefa.name}"?`,
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarTarefa(tarefa)
          .then(res => {
            let newTarefas = [...this.tarefas]
            newTarefas = newTarefas.filter(f => f.id !== tarefa.id)
            this.tarefas = [...newTarefas]
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: `Tarea ${tarefa.name} eliminada!`,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
        this.loading = false
      })
    }
  },
  mounted () {
    this.loadColors()
    this.listarTarefas()
    this.checarAtrasadas()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

</style>
