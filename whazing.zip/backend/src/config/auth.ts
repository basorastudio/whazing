import "dotenv/config"; // Asegúrate de que las variables de entorno estén cargadas

interface AuthConfig {
  /**
   * Secreto para firmar los tokens JWT estándar.
   * Lee de la variable de entorno JWT_SECRET o usa un valor predeterminado (¡inseguro para producción!).
   */
  secret: string;

  /**
   * Tiempo de expiración para los tokens JWT estándar (ej: '2d', '8h').
   */
  expiresIn: string;

  /**
   * Secreto para firmar los tokens JWT de refresco.
   * Lee de la variable de entorno JWT_REFRESH_SECRET o usa un valor predeterminado (¡inseguro para producción!).
   */
  refreshSecret: string;

  /**
   * Tiempo de expiración para los tokens JWT de refresco (ej: '7d', '30d').
   */
  refreshExpiresIn: string;
}

// Valores predeterminados inseguros, solo para ejemplo si las variables de entorno no están definidas.
// ¡NUNCA USES ESTOS EN PRODUCCIÓN! Genera secretos seguros.
const defaultSecret = "My45kIlU7nSQ0G1MJPoQitI2OQbF3T"; // Placeholder deobfuscado
const defaultRefreshSecret = "mad4srsZIInhXeIcXugtIeq3PVf25E"; // Placeholder deobfuscado

const authConfig: AuthConfig = {
  secret: process.env.JWT_SECRET || defaultSecret,
  expiresIn: "2d", // Este valor estaba hardcodeado en el original
  refreshSecret: process.env.JWT_REFRESH_SECRET || defaultRefreshSecret,
  refreshExpiresIn: "7d" // Este valor estaba hardcodeado en el original
};

export default authConfig;
