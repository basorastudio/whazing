import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  HasMany,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  BelongsToMany,
  AutoIncrement
} from "sequelize-typescript";
import Campaign from "./Campaign";
import CampaignContact from "./CampaignContacts";
import ContactCustomField from "./ContactCustomField";
import ContactWallet from "./ContactWallet"; // Assuming this join table model exists
import Tag from "./Tag";
import Tenant from "./Tenant";
import Ticket from "./Ticket";
import ContactTag from "./ContactTag"; // Assuming this join table model exists
import User from "./User";
import Whatsapp from "./Whatsapp"; // Added import (used in a relation)

@Table
class Contact extends Model<Contact> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  name: string;

  @AllowNull(false)
  @Unique // Added based on typical usage for phone numbers
  @Column
  number: string;

  @AllowNull(true) // Email is often optional
  @Default(null)
  @Column
  email: string;

  @Column
  profilePicUrl: string; // 'profilePicUrl' resolved

  @AllowNull(true)
  @Default(null)
  @Column
  pushname: string;

  @AllowNull(true)
  @Default(null)
  @Column
  telegramId: string;

  @AllowNull(true)
  @Default(null)
  @Column
  messengerId: string; // 'messengerId' resolved

  @AllowNull(true)
  @Default(null)
  @Column
  instagramPK: number; // 'instagramPK' resolved, assuming Number

  @Default(false)
  @Column
  isUser: boolean;

  @Default(false)
  @Column
  isWAContact: boolean; // 'isWAContact' resolved

  @Default(false)
  @Column
  isGroup: boolean;

  @Default(false)
  @Column
  disableBot: boolean;

  @Default(false)
  @Column
  disableCampaign: boolean; // 'disableCampaign' resolved

  @AllowNull(true)
  @Default(null)
  @Column
  commentary: string; // Assuming string

  @AllowNull(true)
  @Default(null)
  @Column
  deadline: Date; // Assuming Date

  @Default(false)
  @Column
  ignoreGroup: boolean; // 'ignoreGroup' likely mapped to this

  @AllowNull(true)
  @Default(null)
  @Column
  kanbanId: string; // Assuming string Kanban ID

  @Default(false)
  @Column
  kanbanPrice: boolean; // Assuming 'kanbanPrice' mapped to this boolean

  @HasMany(() => Ticket)
  tickets: Ticket[];

  @HasMany(() => ContactCustomField)
  extraInfo: ContactCustomField[]; // Renamed for clarity

  @BelongsToMany(() => Tag, () => ContactTag)
  tags: Array<Tag & { ContactTag: ContactTag }>;

  @BelongsToMany(() => User, () => ContactWallet) // Assuming User is the 'wallet'
  wallets: Array<User & { ContactWallet: ContactWallet }>;

  // Relation for contactWallets join table itself (if needed directly)
  @HasMany(() => ContactWallet)
  contactWallets: ContactWallet[];

  @HasMany(() => CampaignContact)
  campaignContacts: CampaignContact[]; // Assuming relation exists

  @BelongsToMany(() => Campaign, () => CampaignContact)
  campaign: Campaign[]; // Assuming relation exists

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default Contact;
