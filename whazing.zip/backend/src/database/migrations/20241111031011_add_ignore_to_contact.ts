import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'ignore' column to the 'Contacts' table
    // Flag to ignore this contact for certain operations (e.g., campaigns, bots).
    await queryInterface.addColumn(
      'Contacts', // Table name
      'ignore',   // New column name
      {
        type: DataTypes.BOOLEAN,
        allowNull: false,    // Cannot be null
        defaultValue: false, // Default to not ignored
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'ignore' column from the 'Contacts' table
    await queryInterface.removeColumn(
      'Contacts', // Table name
      'ignore'    // Column name to remove
    );
  }
};

export = migration;