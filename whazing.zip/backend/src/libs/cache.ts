import { default as Redis } from 'ioredis';
import * as crypto from 'crypto';

const redis = new Redis({
    port: Number(process.env.IO_REDIS_PORT),
    host: process.env.IO_REDIS_SERVER,
    db: Number(process.env.IO_REDIS_DB_SESSION) || 0, // Default DB 0
    password: process.env.IO_REDIS_PASSWORD || undefined
});

/**
 * Encrypts parameters to be used as part of a cache key.
 * @param params - The parameters to encrypt.
 * @returns A base64 encoded SHA256 hash of the stringified parameters.
 */
function encryptParams(params: any): string {
    const paramsString = JSON.stringify(params);
    return crypto.createHash('sha256').update(paramsString).digest('base64');
}

/**
 * Sets a value in the cache using a base key and encrypted parameters.
 * @param baseKey - The base key prefix.
 * @param params - The parameters to include in the key (will be encrypted).
 * @param value - The value to store (will be stringified).
 * @param mode - Redis SET mode (e.g., 'EX' for expire).
 * @param duration - Duration for expiration (if mode is 'EX').
 * @returns Promise resolving with the result of the Redis SET command.
 */
export function setFromParams(
    baseKey: string,
    params: any,
    value: any,
    mode?: 'EX' | 'PX' | 'NX' | 'XX' | 'KEEPTTL', // Add other valid modes if needed
    duration?: number
): Promise<string | null> {
    const encryptedKey = `${baseKey}:${encryptParams(params)}`;
    if (mode !== undefined && duration !== undefined) {
        return set(encryptedKey, value, mode, duration);
    }
    return set(encryptedKey, value);
}

/**
 * Gets a value from the cache using a base key and encrypted parameters.
 * @param baseKey - The base key prefix.
 * @param params - The parameters used to create the key.
 * @returns Promise resolving with the retrieved value (parsed if JSON) or null.
 */
export async function getFromParams(baseKey: string, params: any): Promise<any | null> {
    const encryptedKey = `${baseKey}:${encryptParams(params)}`;
    return get(encryptedKey);
}

/**
 * Deletes a value from the cache using a base key and encrypted parameters.
 * @param baseKey - The base key prefix.
 * @param params - The parameters used to create the key.
 * @returns Promise resolving with the number of keys deleted.
 */
export function delFromParams(baseKey: string, params: any): Promise<number> {
    const encryptedKey = `${baseKey}:${encryptParams(params)}`;
    return del(encryptedKey);
}

/**
 * Sets a value in Redis.
 * @param key - The key to set.
 * @param value - The value to store (will be stringified).
 * @param mode - Optional Redis SET mode (e.g., 'EX').
 * @param duration - Optional duration for expiration.
 * @returns Promise resolving with the result of the Redis SET command.
 */
export function set(
    key: string,
    value: any,
    mode?: 'EX' | 'PX' | 'NX' | 'XX' | 'KEEPTTL',
    duration?: number
): Promise<string | null> {
    const valueString = JSON.stringify(value);
    if (mode !== undefined && duration !== undefined) {
        // Type assertion needed as ioredis types might not fully cover dynamic args
        return redis.set(key, valueString, mode as any, duration);
    }
    return redis.set(key, valueString);
}

/**
 * Gets a value from Redis by key.
 * @param key - The key to retrieve.
 * @returns Promise resolving with the value (parsed if JSON) or null.
 */
export async function get(key: string): Promise<any | null> {
    const value = await redis.get(key);
    if (value) {
        try {
            // Attempt to parse JSON, return raw string if parsing fails
            return JSON.parse(value);
        } catch (e) {
            return value;
        }
    }
    return null;
}

/**
 * Gets all keys matching a pattern from Redis.
 * @param pattern - The pattern to match (e.g., 'someprefix:*').
 * @returns Promise resolving with an array of matching keys.
 */
export function getKeys(pattern: string): Promise<string[]> {
    return redis.keys(pattern);
}

/**
 * Deletes one or more keys from Redis.
 * @param keys - A single key or an array of keys to delete.
 * @returns Promise resolving with the number of keys deleted.
 */
export function del(keys: string | string[]): Promise<number> {
    // ioredis del accepts string[] directly
    return redis.del(keys);
}

/**
 * Deletes all keys matching a given pattern.
 * Use with caution, especially in production.
 * @param pattern - The pattern to match keys for deletion.
 * @returns Promise resolving when deletion is complete.
 */
export async function delFromPattern(pattern: string): Promise<void> {
    const keys = await getKeys(pattern);
    // console.log(`Deleting keys matching pattern: ${pattern}`, keys);
    if (keys.length > 0) {
        await del(keys);
        // console.log(`Deleted ${keys.length} keys.`);
    } else {
         // console.log(`No keys found matching pattern: ${pattern}`);
    }
}

// Exporting the layer object similar to the original structure
export const cacheLayer = {
    set,
    setFromParams,
    get,
    getFromParams,
    getKeys,
    del,
    delFromParams,
    delFromPattern
};