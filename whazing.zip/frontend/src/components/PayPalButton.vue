<template>
  <div class="paypal-button-container">
    <div ref="paypalButtonContainer"></div>
  </div>
</template>

<script>
import paypalService from '../service/paypal';

export default {
  name: 'PayPalButton',
  props: {
    amount: {
      type: [Number, String],
      required: true
    },
    currency: {
      type: String,
      default: 'USD'
    },
    description: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      paypalLoaded: false
    };
  },
  async mounted() {
    try {
      const clientId = await paypalService.getClientId();
      await this.loadPayPalScript(clientId);
      this.initializePayPalButton();
    } catch (error) {
      console.error('Error al cargar PayPal:', error);
      this.$q.notify({
        type: 'negative',
        message: 'Error al cargar el botón de PayPal'
      });
    }
  },
  methods: {
    loadPayPalScript(clientId) {
      return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=${this.currency}`;
        script.onload = () => {
          this.paypalLoaded = true;
          resolve();
        };
        script.onerror = () => reject(new Error('Error al cargar el script de PayPal'));
        document.body.appendChild(script);
      });
    },
    initializePayPalButton() {
      if (!window.paypal) return;

      window.paypal.Buttons({
        createOrder: async () => {
          try {
            const order = await paypalService.createOrder(
              this.amount,
              this.currency,
              this.description
            );
            return order.id;
          } catch (error) {
            console.error('Error al crear la orden:', error);
            throw error;
          }
        },
        onApprove: async (data) => {
          try {
            const details = await paypalService.capturePayment(data.orderID);
            this.$emit('payment-success', details);
            this.$q.notify({
              type: 'positive',
              message: 'Pago completado con éxito'
            });
          } catch (error) {
            console.error('Error al capturar el pago:', error);
            this.$emit('payment-error', error);
            this.$q.notify({
              type: 'negative',
              message: 'Error al procesar el pago'
            });
          }
        },
        onError: (error) => {
          console.error('Error en PayPal:', error);
          this.$emit('payment-error', error);
          this.$q.notify({
            type: 'negative',
            message: 'Error en el proceso de pago'
          });
        }
      }).render(this.$refs.paypalButtonContainer);
    }
  }
};
</script>

<style scoped>
.paypal-button-container {
  width: 100%;
  max-width: 500px;
  margin: 0 auto;
}
</style>