// --- START OF FILE 20240216222307-add_AcceptKanban_ChatFlow.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  // Parameters e, f are queryInterface, Sequelize respectively based on usage
  up: async (
    queryInterface: QueryInterface,
    Sequelize: typeof SequelizeLib
  ): Promise<void> => {
    const tableName = "ChatFlow";
    const columnName = "AcceptKanban"; // 'AcceptKanb' + 'an'
    const attributes = {
      type: DataTypes.BOOLEAN, // Original BOOLEAN
      allowNull: false, // Changed ![] to false
      defaultValue: true // Changed !![] to true
    };
    await Promise.all([
      queryInterface.addColumn(tableName, columnName, attributes)
    ]);
  },

  // Parameters e, f are queryInterface, Sequelize respectively
  down: async (
    queryInterface: QueryInterface,
    Sequelize: typeof SequelizeLib
  ): Promise<void> => {
    const tableName = "ChatFlow";
    const columnName = "AcceptKanban"; // 'AcceptKanb' + 'an'
    // Original down migration seemed to repeat the 'up' logic by mistake.
    // Corrected to remove the column.
    await Promise.all([
      queryInterface.removeColumn(tableName, columnName)
      // Original code mistakenly tried to add the column again in 'down':
      // queryInterface.addColumn(h[r(0x1cd)], h[r(0x1dd)], j)
    ]);
  }
};

// Need to import SequelizeLib if used in function signature
import type { Sequelize as SequelizeLib } from "sequelize";

export default migration;

// --- END OF FILE 20240216222307-add_AcceptKanban_ChatFlow.ts ---
