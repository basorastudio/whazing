import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Propiedades comunes para las nuevas columnas
    const commonProps = {
      type: DataTypes.STRING,
      allowNull: true, // Permite nulos
      defaultValue: null
    };

    return Promise.all([
      // Añade la columna 'instagramUser' a 'Whatsapps'
      queryInterface.addColumn("Whatsapps", "instagramUser", commonProps),
      // Añade la columna 'instagramKey' a 'Whatsapps'
      queryInterface.addColumn("Whatsapps", "instagramKey", commonProps)
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina las columnas añadidas
    return Promise.all([
      queryInterface.removeColumn("Whatsapps", "instagramUser"),
      queryInterface.removeColumn("Whatsapps", "instagramKey")
    ]);
  }
};
