import path from "path";
import multer, { StorageEngine } from "multer";
import { format } from "date-fns";
import { Request } from "express"; // Necesario para tipar 'req' en filename

/**
 * Configuración para subida de archivos genéricos usando Multer.
 * Los archivos se guardan en la carpeta 'public'.
 * El nombre del archivo se sanitiza y se le añade un timestamp.
 */

// Resuelve la ruta a la carpeta pública relativa al directorio actual del archivo
const publicFolder = path.resolve(__dirname, "..", "..", "public");

interface UploadConfig {
  /**
   * Directorio donde se guardarán los archivos subidos.
   */
  directory: string;
  /**
   * Configuración de almacenamiento de Multer (diskStorage).
   */
  storage: StorageEngine;
}

const uploadConfig: UploadConfig = {
  directory: publicFolder,
  storage: multer.diskStorage({
    destination: publicFolder,
    filename(
      req: Request,
      file: Express.Multer.File,
      callback: (error: Error | null, filename: string) => void
    ) {
      let finalFilename: string;
      const fileOriginalNameLower = file.originalname?.toLowerCase() || "";

      // Comprueba si el archivo es XML (lógica específica del código original)
      if (fileOriginalNameLower.endsWith(".xml")) {
        finalFilename = file.originalname; // Mantiene el nombre original para XML
      } else {
        // Para otros tipos de archivo: sanitiza y añade timestamp
        const fileExtension = path.extname(file.originalname);
        const baseName = file.originalname
          .replace(fileExtension, "") // Quita la extensión
          .replace(/#/g, "") // Quita #
          .replace(/&/g, ""); // Quita &
        // Considera añadir más sanitización (ej: quitar espacios, caracteres especiales)

        const timestamp = format(new Date(), "ddMMyyyyHHmmssSSS"); // Formato de timestamp del original
        finalFilename = `${baseName}_${timestamp}${fileExtension}`;
      }

      return callback(null, finalFilename);
    }
  })
  // Podrías añadir fileFilter aquí si necesitas validar tipos de archivo, tamaño, etc.
  // fileFilter: (req, file, cb) => { ... }
};

export default uploadConfig;
