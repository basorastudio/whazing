import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'type' a la tabla 'Whatsapps'
    return queryInterface.addColumn('Whatsapps', 'type', {
      type: DataTypes.STRING,
      allowNull: false, // No permite nulos
      defaultValue: 'w' // Valor predeterminado 'w' (probablemente para whatsapp)
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'type' de la tabla 'Whatsapps'
    return queryInterface.removeColumn('Whatsapps', 'type');
  }
};