import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'Tickets';
    // Add composite index on [userId, status]
    await queryInterface.addIndex(tableName, ['userId', 'status'], {
      name: 'idx_tickets_userid_status', // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'Tickets';
    // Remove the index
    await queryInterface.removeIndex(tableName, 'idx_tickets_userid_status');
  }
};

export = migration;