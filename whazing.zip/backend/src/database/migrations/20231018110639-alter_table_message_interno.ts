// --- START OF FILE 20231018110639-alter_table_message_interno.ts ---

import { QueryInterface, DataTypes, Sequelize } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "InternalMessages";

    // Change senderId to allow null and set onDelete to SET NULL
    await queryInterface.changeColumn(tableName, "senderId", {
      type: DataTypes.INTEGER,
      references: { model: "Users", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL", // Keep message if sender user is deleted
      allowNull: true
    });

    // Change receiverId to allow null and set onDelete to SET NULL
    await queryInterface.changeColumn(tableName, "receiverId", {
      type: DataTypes.INTEGER,
      references: { model: "Users", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL", // Keep message if receiver user is deleted
      allowNull: true
    });

    // Change groupId to allow null and set onDelete to SET NULL
    await queryInterface.changeColumn(tableName, "groupId", {
      type: DataTypes.INTEGER,
      references: { model: "Groups", key: "id" }, // Assuming 'Groups' table exists
      onUpdate: "CASCADE",
      onDelete: "SET NULL", // Keep message if group is deleted
      allowNull: true
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Reverting these changes means setting allowNull back to false and onDelete to CASCADE.
    // !! IMPORTANT !! Reverting allowNull to false might fail if there are existing rows with NULL values.
    // Consider data cleanup before running the down migration or handle potential errors.

    const tableName = "InternalMessages";
    const revertOptions = (modelName: string) => ({
      type: DataTypes.INTEGER,
      references: { model: modelName, key: "id" },
      onUpdate: "CASCADE",
      onDelete: "CASCADE", // Revert back from SET NULL
      allowNull: false // Revert back from true (potential data issue)
    });

    // Revert senderId
    try {
      await queryInterface.changeColumn(
        tableName,
        "senderId",
        revertOptions("Users")
      );
    } catch (error) {
      console.error(
        `Error al revertir la columna senderId: ${(error as Error).message}. Verifique valores NULL.`
      );
      // throw error; // Uncomment to stop migration on error
    }

    // Revert receiverId
    try {
      await queryInterface.changeColumn(
        tableName,
        "receiverId",
        revertOptions("Users")
      );
    } catch (error) {
      console.error(
        `Error al revertir la columna receiverId: ${(error as Error).message}. Verifique valores NULL.`
      );
      // throw error;
    }

    // Revert groupId
    try {
      await queryInterface.changeColumn(
        tableName,
        "groupId",
        revertOptions("Groups")
      ); // Assuming 'Groups'
    } catch (error) {
      console.error(
        `Error al revertir la columna groupId: ${(error as Error).message}. Verifique valores NULL.`
      );
      // throw error;
    }
  }
};

export default migration;

// --- END OF FILE 20231018110639-alter_table_message_interno.ts ---
