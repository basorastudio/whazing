import { QueryInterface, DataTypes, Sequelize } from 'sequelize';
import { messageBusinessHours } from '../../utils/defaultConstants'; // Asume que la ruta y exportación son correctas

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'messageBusinessHours' (TEXT) a la tabla 'Tenants'
    return queryInterface.addColumn('Tenants', 'messageBusinessHours', {
      type: DataTypes.TEXT,
      allowNull: true, // Permite nulos
      defaultValue: messageBusinessHours // Usa el valor predeterminado importado
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'messageBusinessHours' de la tabla 'Tenants'
    return queryInterface.removeColumn('Tenants', 'messageBusinessHours');
  }
};