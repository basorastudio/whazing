import {
  Table,
  Column,
  Model,
  PrimaryKey,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  Unique, // Added for name uniqueness
  AutoIncrement
} from "sequelize-typescript";

@Table
class Plan extends Model<Plan> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Unique // Plans usually have unique names
  @AllowNull(false)
  @Column
  name: string;

  @Column
  maxUsers: number; // Assuming numeric

  @Column
  maxConnections: number; // 'maxConnections' resolved, assuming numeric

  @Column
  value: number; // Assuming numeric value

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @Default(true)
  @Column
  isPublic: boolean;

  @Default(true)
  @Column
  campaign: boolean;

  @Default(true)
  @Column
  group: boolean;

  @Default(true)
  @Column
  integrations: boolean; // 'integrations' resolved
}

export default Plan;
