import { QueryInterface, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Ejecuta una consulta SQL para crear la extensión 'uuid-ossp' si no existe.
    // Esta extensión es necesaria para generar UUIDs en PostgreSQL.
    const createExtensionQuery = 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp";';
    return Promise.all([
        queryInterface.sequelize.query(createExtensionQuery)
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // No hay una acción 'down' explícita para eliminar la extensión,
    // ya que podría ser utilizada por otras partes de la aplicación.
    // Eliminarla podría causar problemas.
    // Si se requiere una acción down, sería:
    // const dropExtensionQuery = 'DROP EXTENSION IF EXISTS "uuid-ossp";';
    // return Promise.all([queryInterface.sequelize.query(dropExtensionQuery)]);
    return Promise.resolve(); // No hacer nada en el rollback por defecto
  }
};