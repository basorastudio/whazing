<template>
  <div class="container">
    <div class="login-section"  :class="$q.dark.isActive ? 'bg-black' : ''">
      <q-layout class="full-width">
        <q-page-container>
          <q-page class="flex justify-center items-center">
            <q-ajax-bar
              position="top"
              class="color-light2"
              size="5px"
            />
            <div class="login-content">
              <q-img
                :src="generateMediaUrl()"
                spinner-color="white"
                class="logo-image q-mb-lg q-px-md"
                style="max-width: 100%"
              />
              <q-separator spaced />
              <div class="text-primary">
                <div>
              <!-- Nome da Empresa -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                    v-model="form.nomeEmpresa"
                    :placeholder="$t('signup.companyName')"
                    outlined
              >
                <!-- Ícone para Nome da Empresa -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-domain"
                    class="cursor-pointer color-light1"
                  />
                </template>
              </q-input>

              <!-- para exibir campo cnpj tire essa linha
                  <q-input
                    rounded
                    :color="$q.dark.isActive ? 'white ' : 'black'"
                    class="q-mb-md"
                    clearable
                mask="##.###.###/####-##"
                v-model="form.cnpj"
                placeholder="CNPJ"
                outlined
              >

                <template v-slot:prepend>
                  <q-icon
                    name="mdi-numeric-0-box-outline"
                    class="cursor-pointer"
                    color="primary"
                  />
                </template>
              </q-input>
              para exibir campo cnpj tire essa linha -->
              <!-- whatsapp -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                mask="(##)#####-####"
                v-model="form.whatsapp"
                    :placeholder="$t('signup.whatsapp')"
                outlined
              >
                <!-- Ícone para whatsapp -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-whatsapp"
                    class="cursor-pointer color-light1"
                  />
                </template>
              </q-input>

              <!-- nomeResponsavel -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                v-model="form.nomeResponsavel"
                    :placeholder="$t('signup.responsibleName')"
                outlined
              >
                <!-- Ícone para nomeResponsavel -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-account-star"
                    class="cursor-pointer color-light1"
                  />
                </template>
              </q-input>

              <!-- email -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                v-model="form.email"
                    :placeholder="$t('signup.email')"
                :error="$v.form.email.$error"
                    :error-message="$t('validation.invalidEmail')"
                outlined
              >
                <!-- Ícone para email -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-email-outline"
                    class="cursor-pointer color-light1"
                  />
                </template>
              </q-input>

              <!-- senha -->
                  <q-input
                    rounded
                    class="q-mb-md"
                    clearable
                    :placeholder="$t('signup.password')"
                v-model="form.password"
                :type="isPwd ? 'password' : 'text'"
                @keypress.enter="fazerLogin"
                outlined
              >
                <!-- Ícone para senha -->
                <template v-slot:prepend>
                  <q-icon
                    name="mdi-shield-key-outline"
                    class="cursor-pointer color-light1"
                  />
                </template>
                <template v-slot:append>
                  <q-icon
                    :name="isPwd ? 'visibility_off' : 'visibility'"
                    class="cursor-pointer color-light1"
                    @click="isPwd = !isPwd"
                  />
                </template>
              </q-input>

              <!-- Plano (seleção) -->
              <q-select
                rounded
                class="q-mb-md"
                clearable
                v-model="form.plano"
                :options="options"
                :label="$t('signup.plan')"
                outlined
              />
            </div>
              <q-btn
                class="q-mr-sm q-my-lg generate-button btn-rounded-50 color-light2"
                style="width: 150px"
                :loading="loading"
                @click="handleTenant"
              >
                {{ $t('signup.register') }}
              </q-btn>

            <q-btn
              flat
              color="info"
              no-caps
              dense
              class="q-px-sm color-light1"
              :label="$t('signup.haveAccount')"
              @click="redirecionarParaLogin"
            />
              </div>
            </div>
          </q-page>
        </q-page-container>
      </q-layout>
    </div>

    <q-btn
      v-if="whatsappNumber"
      fab
      icon="mdi-whatsapp"
      class="whatsapp-float"
      color="green"
      round
      @click="abrirWhatsApp"
    >
      <q-tooltip>
        {{ $t('support.requestSupport') }}
      </q-tooltip>
    </q-btn>
  </div>
</template>

<script>
import { required, email, minLength } from 'vuelidate/lib/validators'
import { listPlanosPublic } from 'src/service/plans'
import { CriarTeste } from 'src/service/empresas'
import { ListarConfiguracaoPublica, ListarCores } from 'src/service/configuracoesgeneral'

export default {
  name: 'Signup',
  data() {
    return {
      isPwd: true,
      loading: false,
      form: {
        nomeEmpresa: '',
        cnpj: '',
        whatsapp: '',
        nomeResponsavel: '',
        email: '',
        password: '',
        plano: null,
        whatsappNumber: null
      },
      planos: []
    }
  },
  computed: {
    options() {
      return this.formattedPlanos()
    }
  },
  validations: {
    form: {
      email: { required, email },
      password: { required, minLength: minLength(6) },
      nomeEmpresa: { required },
      whatsapp: { required },
      nomeResponsavel: { required },
      plano: { required }
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configurações:', error)
      }
    },
    generateMediaUrl() {
      return `${process.env.URL_API}/public/logos/signup.png`
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const message = encodeURIComponent(this.$t('signup.support'))
        const url = `https://wa.me/${this.whatsappNumber}?text=${message}`
        window.open(url, '_blank')
      }
    },
    async fetchPlanData() {
      try {
        const response = await listPlanosPublic()
        this.planos = response.data
      } catch (error) {
        console.error('Error fetching plan data:', error)
      }
    },
    formattedPlanos() {
      return this.planos.map(plan => ({
        label: this.$t('signup.planFormat', {
          name: plan.name,
          maxUsers: plan.maxUsers,
          maxConnections: plan.maxConnections,
          value: plan.value.toFixed(2).replace('.', ',')
        }),
        value: plan.id,
        maxUsers: plan.maxUsers,
        maxConnections: plan.maxConnections
      }))
    },
    redirecionarParaLogin() {
      this.$router.push('/login')
    },
    async handleTenant() {
      if (this.$v.form.$invalid) {
        this.$v.$touch()
        this.$q.notify(this.$t('validation.fillAllData'))
        return
      }
      const data = {
        name: this.form.nomeResponsavel,
        email: this.form.email,
        password: this.form.password,
        tenantName: this.form.nomeEmpresa,
        cnpj: this.form.cnpj,
        phone: this.form.whatsapp,
        plano: this.form.plano
      }

      this.loading = true

      try {
        await CriarTeste(data)
        this.$q.notify({
          type: 'positive',
          message: this.$t('signup.testSuccess'),
          position: 'top',
          progress: true,
          actions: [{ icon: 'close', round: true, color: 'white' }]
        })
        // Redireciona para a página de login após o sucesso
        this.redirecionarParaLogin()
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: this.$t('signup.testError'),
          position: 'top',
          progress: true,
          actions: [{ icon: 'close', round: true, color: 'white' }]
        })
        console.error('Error creating tenant:', error)
      } finally {
        this.loading = false
      }
    },
    clear() {
      this.form.email = ''
      this.form.password = ''
      this.$v.form.$reset()
    }
  },
  mounted() {
    this.loadColors()
    this.fetchConfigurations()
    this.fetchPlanData()
  }
}
</script>

<style scoped>
.container {
  display: flex;
  height: 150vh;
  width: 100vw;
  justify-content: center;
  align-items: center;
}

.login-section {
  width: 400px;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  background-color: white;
  border-radius: 10px
}

.full-width {
  width: 100%;
}

.login-content {
  text-align: center;
}

.video-container {
  display: flex;
  justify-content: flex-end;
  width: 55%;
}

.logo-image {
  height: auto;
  max-width: 100%;
}

.fixed-layout {
  width: 45%;
}

.whatsapp-float {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 1000;
  border-radius: 50%; /* Deixa o contorno arredondado */
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
  transition: transform 0.3s;
}

.whatsapp-float:hover {
  transform: scale(1.1);
}

</style>
