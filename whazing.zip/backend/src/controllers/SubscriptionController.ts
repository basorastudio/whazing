import { Request, Response } from "express";
import * as Yup from "yup";
import AppError from "../errors/AppError"; // Asumiendo que AppError es una exportación por defecto
import {
  createSubscription as createSubscriptionService,
  webhook as webhookService
} from "../services/PaymentGatewayServices/PaymentGatewayServices"; // Ajustar ruta según sea necesario

interface SubscriptionRequestBody {
  price?: number; // Hacer opcional o asegurar que siempre venga
  // otras propiedades que puedan venir en el body...
}

// Esquema de validación para la creación
const createSubscriptionSchema = Yup.object().shape({
  price: Yup.string().required() // El original usaba string, mantenemos por ahora
});

// Esquema de validación para webhook (si es necesario, generalmente no se valida externamente)
// const webhookSchema = Yup.object().shape({ ... });

export const createSubscription = async (
  req: Request,
  res: Response
): Promise<Response | void> => {
  // void si no siempre retorna
  const body: SubscriptionRequestBody = req.body;

  // Validación con Yup
  try {
    await createSubscriptionSchema.validate(body);
  } catch (err: any) {
    // Usar any o Yup.ValidationError
    throw new AppError(err.message || "Validation fails", 400); // "Fallo en la validación"
  }

  // Llama al servicio correspondiente (la lógica está dentro del servicio)
  // El servicio original no usa el body directamente, puede que use req o req.user?
  // Revisar el servicio PaymentGatewayServices_1[aj(0x16c) + ak(0x1b9) + aj(0x1db)])(d, e);
  // Indica que pasa req (d) y res (e) al servicio.
  // Esta práctica (pasar req/res a servicios) no es ideal, pero se mantiene por fidelidad.
  return await createSubscriptionService(req, res);
};

export const webhook = async (
  req: Request,
  res: Response
): Promise<Response | void> => {
  // Llama al servicio correspondiente
  // Similar al anterior, pasa req y res al servicio.
  return await webhookService(req, res);
};
