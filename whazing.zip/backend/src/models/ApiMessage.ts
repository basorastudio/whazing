import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull
} from "sequelize-typescript";
import { v4 as uuidv4 } from "uuid";
import Tenant from "./Tenant";
import Whatsapp from "./Whatsapp"; // Assuming API messages relate to a Whatsapp session

// @Table decorator was missing in the original deobfuscated code, adding it.
@Table
class ApiMessage extends Model<ApiMessage> {
  @PrimaryKey
  @Default(uuidv4)
  @Column(DataType.UUID)
  id: string;

  @ForeignKey(() => Whatsapp) // Assuming relates to Whatsapp via sessionId
  @Column
  sessionId: number;

  @BelongsTo(() => Whatsapp) // Relation name
  session: Whatsapp;

  @Default(0)
  @Column
  ack: number;

  @Column
  messageId: string;

  @Column(DataType.TEXT)
  body: string;

  @AllowNull(true)
  @Column
  mediaName: string;

  @Column
  mediaUrl: string;

  @Column
  externalKey: string; // 'externalKey' resolved

  @Default(null)
  @AllowNull(true)
  @Column(DataType.INTEGER) // Assuming timestamp is numeric
  timestamp: number;

  @Default(null)
  @AllowNull(true)
  @Column(DataType.JSONB) // Assuming JSONB for metadata
  messageWA: object;

  @Default(null)
  @AllowNull(true)
  @Column(DataType.JSONB) // Assuming JSONB for metadata
  apiConfig: object;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;
}

export default ApiMessage;
