import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'userId' a la tabla 'Messages' como clave foránea a 'Users'
    return queryInterface.addColumn('Messages', 'userId', {
      type: DataTypes.INTEGER,
      references: {
        model: 'Users', // Referencia a la tabla Users
        key: 'id'
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL', // Si el usuario se elimina, userId se establece en NULL
      allowNull: true,
      defaultValue: null
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'userId' de la tabla 'Messages'
    return queryInterface.removeColumn('Messages', 'userId');
  }
};