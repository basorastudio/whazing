// --- START OF FILE FastReplyController.ts ---

import { Request, Response } from "express";
import * as Yup from "yup";
import AppError from "../errors/AppError"; // Asumiendo la ruta correcta
import CreateFastReplyService from "../services/FastReplyServices/CreateFastReplyService";
import ListFastReplyService from "../services/FastReplyServices/ListFastReplyService";
import DeleteFastReplyService from "../services/FastReplyServices/DeleteFastReplyService";
import UpdateFastReplyService from "../services/FastReplyServices/UpdateFastReplyService";
import ListFastReplyServiceAll from "../services/FastReplyServices/ListFastReplyServiceAll";
import { logger } from "../utils/logger"; // Asumiendo la ruta correcta

// Interfaces
interface RequestUser {
  tenantId: string | number;
  id: string | number; // userId
}

// Tipado para req.file (Multer)
interface MulterFile {
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  size: number;
  destination: string;
  filename: string;
  path: string;
  buffer: Buffer;
}

interface StoreRequestBody {
  key: string;
  message: string; // Asumiendo que message existe
  // otras propiedades si existen...
}

interface StoreRequest extends Request {
  user: RequestUser;
  body: StoreRequestBody;
  file?: MulterFile; // Hacer el archivo opcional
}

interface IndexRequest extends Request {
  user: RequestUser;
}

interface UpdateRequestBody {
  key: string;
  message: string; // Asumiendo que message existe
  // otras propiedades si existen...
}

interface UpdateRequestParams {
  fastReplyId: string;
}

interface UpdateRequest extends Request {
  user: RequestUser;
  body: UpdateRequestBody;
  params: UpdateRequestParams;
  file?: MulterFile; // Hacer el archivo opcional
}

interface DeleteRequestParams {
  fastReplyId: string;
}

interface DeleteRequest extends Request {
  user: RequestUser;
  params: DeleteRequestParams;
}

const fastReplySchema = Yup.object().shape({
  key: Yup.string().required("La clave es obligatoria."), // Traducido
  message: Yup.string(), // Asumiendo que message puede ser opcional o validado en otro lugar
  userId: Yup.number().required("El ID de usuario es obligatorio."), // Traducido
  tenantId: Yup.number().required("El ID del inquilino es obligatorio.") // Traducido
});

/**
 * @description Crea una nueva respuesta rápida.
 * @param {StoreRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const store = async (
  req: StoreRequest,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const userId = req.user.id; // userId
  const fastReplyData = { ...req.body };
  const media = req.file; // Acceder a req.file en lugar de req.files

  fastReplyData.userId = userId;
  fastReplyData.tenantId = tenantId;
  fastReplyData.mediaPath = media ? media.filename : undefined; // Usar mediaPath o similar

  try {
    // Se necesita asegurar que los tipos coincidan con el schema, especialmente tenantId y userId
    const dataToValidate = {
      ...fastReplyData,
      userId: Number(userId),
      tenantId: Number(tenantId)
    };
    await fastReplySchema.validate(dataToValidate);
  } catch (err: any) {
    // Captura errores de validación de Yup
    throw new AppError(err.message);
  }

  try {
    // Asegurar que los datos pasados al servicio tengan el tipo correcto si es necesario
    const fastReply = await CreateFastReplyService({
      ...fastReplyData,
      userId: Number(userId),
      tenantId: Number(tenantId)
    });

    return res.status(201).json(fastReply); // HTTP 201 Created
  } catch (error) {
    logger.error("Error creando respuesta rápida:", error); // Traducido
    // Considerar lanzar un AppError más específico si es posible
    throw new AppError("Error creando respuesta rápida"); // Traducido
  }
};

/**
 * @description Lista las respuestas rápidas para el usuario.
 * @param {IndexRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const index = async (
  req: IndexRequest,
  res: Response
): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  const userId = Number(req.user.id);

  const listParams = {
    tenantId: tenantId,
    userId: userId
  };

  const fastReplies = await ListFastReplyService(listParams);

  return res.status(200).json(fastReplies); // HTTP 200 OK
};

/**
 * @description Lista todas las respuestas rápidas (basado en permisos, posiblemente).
 * @param {IndexRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const listFastReplyAll = async (
  req: IndexRequest,
  res: Response
): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  const userId = Number(req.user.id);

  const listParams = {
    tenantId: tenantId,
    userId: userId
  };
  const fastReplies = await ListFastReplyServiceAll(listParams);

  return res.status(200).json(fastReplies); // HTTP 200 OK
};

/**
 * @description Actualiza una respuesta rápida existente.
 * @param {UpdateRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const update = async (
  req: UpdateRequest,
  res: Response
): Promise<Response> => {
  const { tenantId } = req.user;
  const userId = req.user.id;
  const fastReplyData = { ...req.body };
  const media = req.file;
  const { fastReplyId } = req.params;

  fastReplyData.userId = userId;
  fastReplyData.tenantId = tenantId;
  fastReplyData.mediaPath = media ? media.filename : undefined; // Usar mediaPath o similar

  // Validar solo los campos presentes en la actualización si es necesario
  const updateSchema = Yup.object().shape({
    key: Yup.string(),
    message: Yup.string(),
    userId: Yup.number().required("El ID de usuario es obligatorio."), // Traducido
    tenantId: Yup.number().required("El ID del inquilino es obligatorio.") // Traducido
  });

  try {
    const dataToValidate = {
      ...fastReplyData,
      userId: Number(userId),
      tenantId: Number(tenantId)
    };
    await updateSchema.validate(dataToValidate);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const updateParams = {
    fastReplyData: {
      ...fastReplyData,
      userId: Number(userId),
      tenantId: Number(tenantId)
    },
    fastReplyId: fastReplyId
  };

  const fastReply = await UpdateFastReplyService(updateParams);

  return res.status(200).json(fastReply); // HTTP 200 OK
};

/**
 * @description Elimina una respuesta rápida.
 * @param {DeleteRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const remove = async (
  req: DeleteRequest,
  res: Response
): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  // const userId = Number(req.user.id); // userId parece no usarse en el servicio original
  const { fastReplyId } = req.params;

  try {
    const deleteParams = {
      id: fastReplyId,
      tenantId: tenantId
      // userId: userId // Incluir si el servicio lo requiere
    };
    await DeleteFastReplyService(deleteParams);
    return res.status(200).json({ message: "Respuesta rápida eliminada" }); // HTTP 200 OK - Traducido
  } catch (error) {
    logger.error("Error eliminando respuesta rápida:", error); // Traducido
    throw new AppError("Error eliminando respuesta rápida"); // Traducido
  }
};

// --- END OF FILE FastReplyController.ts ---
