'use strict';
import { QueryInterface } from 'sequelize';

export default {
    up: async (queryInterface: QueryInterface) => {
        // Inserta un registro de tenant predeterminado con horarios de atención configurados
        return queryInterface.sequelize.query(`
      INSERT INTO public."Tenants"(status, name, "businessHours", "planId", "dueDate") VALUES
      ('active', 'Empresa 01', '[{"day": 0, "hr1": "08:00", "hr2": "12:00", "hr3": "14:00", "hr4": "18:00", "type": "O", "label": "Domingo"}, {"day": 1, "hr1": "08:00", "hr2": "12:00", "hr3": "14:00", "hr4": "18:00", "type": "O", "label": "Lunes"}, {"day": 2, "hr1": "08:00", "hr2": "12:00", "hr3": "14:00", "hr4": "18:00", "type": "O", "label": "Martes"}, {"day": 3, "hr1": "08:00", "hr2": "12:00", "hr3": "14:00", "hr4": "18:00", "type": "O", "label": "Miércoles"}, {"day": 4, "hr1": "08:00", "hr2": "12:00", "hr3": "14:00", "hr4": "18:00", "type": "O", "label": "Jueves"}, {"day": 5, "hr1": "08:00", "hr2": "12:00", "hr3": "14:00", "hr4": "18:00", "type": "O", "label": "Viernes"}, {"day": 6, "hr1": "08:00", "hr2": "12:00", "hr3": "14:00", "hr4": "18:00", "type": "O", "label": "Sábado"}]', '1', '2099-03-14 04:00:00+01');
      INSERT INTO public."Plans"("id", name, "messageBusinessHours", "maxUsers", "maxConnections", "value", "isPublic", "group", "campaign", "integrations", "createdAt", "updatedAt", "useWhatsapp", "useFacebook", "useInstagram", "useCampaigns", "useSchedules", "useInternalChat", "useExternalApi") VALUES
      ('1', 'Plano 1', '¡Hola! Fantástico recibir tu contacto. En este momento estamos ausentes, pero priorizaremos tu atención y no podremos responder. Volveremos pronto. Agradecemos mucho tu atención.', '99', '99', '99.000' , 'false', 'true', 'true', 'true', '2021-03-10 17:28:29.000', '2021-03-10 17:28:29.000', NULL, 'true', 'true', 'true', 'true', 'true', 'true');
    `);
    },

    down: async (queryInterface: QueryInterface) => {
        // Elimina todos los registros de la tabla Tenants (¡cuidado en producción!)
        return queryInterface.bulkDelete('Tenants', {});
    }
};