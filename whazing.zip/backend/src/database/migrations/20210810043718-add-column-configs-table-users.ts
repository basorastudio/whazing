import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'configs' (JSON) a la tabla 'Users'
    return Promise.all([
      queryInterface.addColumn("Users", "configs", {
        type: DataTypes.JSON,
        allowNull: true, // Permite nulos
        defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'configs' de la tabla 'Users'
    return Promise.all([queryInterface.removeColumn("Users", "configs")]);
  }
};
