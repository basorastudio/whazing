"use strict";
import { QueryInterface } from "sequelize";

export default {
  up: async (queryInterface: QueryInterface) => {
    // Índice para búsquedas por contactId y status
    // Nota: 'tenantId' no estaba en los campos originales, pero usualmente se incluye.
    // Manteniendo los campos exactos del código ofuscado:
    return queryInterface.addIndex(
      "Tickets",
      [
        "contactId",
        "status"
        // 'tenantId' // <- Considerar añadir tenantId si las búsquedas siempre filtran por tenant
      ],
      { name: "idx_tickets_contactid_status" }
    ); // nombre claro del índice
  },

  down: async (queryInterface: QueryInterface) => {
    return queryInterface.removeIndex(
      "Tickets",
      "idx_tickets_contactid_status"
    );
  }
};
