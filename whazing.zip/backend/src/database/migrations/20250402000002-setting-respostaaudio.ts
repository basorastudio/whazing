import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert audio response prefix/suffix settings into 'SettingsGeneral'
    // Translated Portuguese placeholders like '🤖 Mensagem automática 🤖' and '🔊 Transcrição: 🔊'
    const topoValue = '🤖 Mensaje automático 🤖';
    const rodapeValue = '🔊 Transcripción: 🔊';
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('toporespostaaudio', '${topoValue.replace(/'/g, "''")}', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('rodapepostaaudio', '${rodapeValue.replace(/'/g, "''")}', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `); // Escaping single quotes
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted audio response settings
    await queryInterface.bulkDelete(
      'SettingsGeneral', // Adjust schema if needed
      {
        key: ['toporespostaaudio', 'rodapepostaaudio']
      }
    );
  }
};

export = migration;