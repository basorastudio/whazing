declare namespace NodeJS {
  interface Global {
    _loopDb: any;
    rabbitWhatsapp: any;
  }
}
