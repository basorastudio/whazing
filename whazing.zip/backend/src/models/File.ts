import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import User from "./User";
import Tenant from "./Tenant";
import Group from "./Group"; // Assuming relation to Group

@Table({ tableName: "InternalMessages" }) // Explicit table name
class InternalMessage extends Model<InternalMessage> {
  // Getters preserved
  get mediaName(): string | null {
    return this.getDataValue("mediaName");
  }

  get mediaUrl(): string | null {
    const filename = this.getDataValue("mediaUrl");
    if (filename) {
      const { BACKEND_URL, PROXY_PORT } = process.env;
      return `${BACKEND_URL}:${PROXY_PORT}/public/${filename}`;
    }
    return null;
  }

  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column(DataType.TEXT) // Use TEXT for message body
  text: string;

  @Column
  timestamp: number; // Assuming numeric timestamp

  @Column
  read: boolean;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @ForeignKey(() => User)
  @Column
  senderId: number;

  @BelongsTo(() => User, "senderId") // Explicit FK
  sender: User;

  @ForeignKey(() => User)
  @AllowNull(true)
  @Column
  receiverId: number;

  @BelongsTo(() => User, "receiverId") // Explicit FK
  receiver: User;

  @ForeignKey(() => Group)
  @AllowNull(true)
  @Column
  groupId: number;

  @BelongsTo(() => Group)
  group: Group;

  // Virtual Fields handled by getters
  @Column(DataType.VIRTUAL)
  mediaName: string | null;

  @Column(DataType.VIRTUAL)
  mediaUrl: string | null;

  @Column
  mediaType: string; // Store filename/path in this column

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;
}

export default InternalMessage;
