import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'email' column to the 'Tenants' table
    await queryInterface.addColumn(
      "Tenants", // Table name
      "email", // New column name
      {
        type: DataTypes.STRING, // Data type
        allowNull: true, // Allow null values
        defaultValue: "" // Default value is an empty string
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'email' column from the 'Tenants' table
    await queryInterface.removeColumn(
      "Tenants", // Table name
      "email" // Column name to remove
    );
  }
};

export = migration;
