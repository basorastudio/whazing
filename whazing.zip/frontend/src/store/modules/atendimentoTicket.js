import { ConsultarDadosTicket, LocalizarMensagens } from 'src/service/tickets'
import { Notify } from 'quasar'
import $router from 'src/router'
import { orderBy } from 'lodash'
import { parseISO } from 'date-fns'

const orderMessages = (messages) => {
  const newMessages = orderBy(messages, (obj) => parseISO(obj.timestamp || obj.createdAt), ['asc'])
  return [...newMessages]
}

const orderTickets = (tickets) => {
  const newTickes = orderBy(tickets, (obj) => parseISO(obj.lastMessageAt || obj.updatedAt), ['asc'])
  return [...newTickes]
}

const checkTicketFilter = (ticket) => {
  const filtroPadrao = {
    searchParam: '',
    pageNumber: 1,
    status: ['open', 'pending'],
    showAll: false,
    count: null,
    queuesIds: [],
    tagsIds: [],
    withUnreadMessages: false,
    isNotAssignedUser: false,
    includeNotQueueDefined: true,
    useradmId: [],
    whatsappIds: []
    // date: new Date(),
  }

  const NotViewTicketsChatBot = () => {
    const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))
    const conf = configuracoes?.find(c => c.key === 'NotViewTicketsChatBot')
    return (conf?.value === 'enabled')
  }

  const DirectTicketsToWallets = () => {
    const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))
    const conf = configuracoes?.find(c => c.key === 'DirectTicketsToWallets')
    return (conf?.value === 'enabled')
  }

  const isNotViewAssignedTickets = () => {
    const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))
    const conf = configuracoes?.find(c => c.key === 'NotViewAssignedTickets')
    return (conf?.value === 'enabled')
  }
  const filtros = JSON.parse(localStorage.getItem('filtrosAtendimento')) || filtroPadrao
  const filasSelecionadas = filtros.queuesIds
  const usuario = JSON.parse(localStorage.getItem('usuario'))
  const UserQueues = JSON.parse(localStorage.getItem('queues'))
  const filasCadastradas = JSON.parse(localStorage.getItem('filasCadastradas') || '[]')
  const profile = localStorage.getItem('profile')
  const isAdminShowAll = (profile === 'admin' || profile === 'supervisor') && filtros.showAll
  const isQueuesTenantExists = filasCadastradas.length > 0

  const userId = usuario?.userId || +localStorage.getItem('userId')

  // verificar si la cola del ticket está filtrada
  if (isQueuesTenantExists && filtros?.queuesIds.length) {
    const isQueue = filtros.queuesIds.findIndex(q => ticket.queueId === q)
    if (isQueue == -1) {
      console.log('colas filtradas y diferentes a la del ticket', ticket.queueId)
      return false
    }
  }

  // filtro etiqueta
  if (filtros.tagsIds?.length > 0) {
    const contactTags = ticket?.contact?.tags || []
    if (!contactTags.length) {
      return false
    }
    const hasMatchingTag = contactTags.some(tag => filtros.tagsIds.includes(tag?.id))
    if (!hasMatchingTag) {
      return false
    }
  }

  // Verificar si es admin y si está solicitando mostrar todos
  if (isAdminShowAll) {
    // si el estado del ticket whatsappid
    if (filtros?.whatsappIds?.length > 0 && ticket?.whatsappId !== undefined &&
      !filtros.whatsappIds.includes(ticket.whatsappId)) {
      return false
    }

    // si el estado del ticket userid 
    if (filtros?.useradmId?.length > 0 && ticket?.userId !== undefined &&
      !filtros.useradmId.includes(ticket.userId)) {
      return false
    }

    return true
  }

  // si el estado del ticket es diferente del estado filtrado, retornar false
  if (filtros.status.length > 0 && !filtros.status.includes(ticket.status)) {
    console.log('Estado ticket', filtros.status, ticket.status)
    return false
  }

  // si el ticket es un grupo, todos pueden verificarlo
  if (ticket.isGroup) {
    if (isQueuesTenantExists) {
      const isQueueUser = UserQueues.findIndex(q => ticket.queueId === q.id)
      if (isQueueUser !== -1) {
        console.log('Cola del ticket grupo habilitada para el Usuario', ticket.queueId)
        return true
      } else {
        console.log('Usuario no tiene acceso a la cola grupo', ticket.queueId)
        return false
      }
    }
  }

  // verificar si ya es un ticket del usuario
  if (ticket?.userId == userId) {
    if (filasSelecionadas.length > 0) {
      if (filasSelecionadas.includes(ticket.queueId)) return true
      return false
    }
    return true
  }

  // No visualizar tickets aún con el Chatbot
  // siempre que no exista usuario o cola definida
  if (NotViewTicketsChatBot() && ticket.chatFlowId) {
    if (!ticket?.userId && !ticket.queueId) {
      console.log('NotViewTicketsChatBot y el ticket está sin usuario y cola definida')
      return false
    }
  }

  // Si el ticket no tiene cola definida, verificar el filtro
  // permite visualizar tickets sin colas definidas es falso.
  // if (isQueuesTenantExists && !ticket.queueId && !filtros.includeNotQueueDefined) {
  //   console.log('filtros.includeNotQueueDefined', ticket.queueId, !filtros.includeNotQueueDefined)
  //   return false
  // }

  let isValid = true

  // verificar si el usuario tiene cola habilitada
  if (isQueuesTenantExists) {
    const isQueueUser = UserQueues.findIndex(q => ticket.queueId === q.id)
    if (isQueueUser !== -1) {
      console.log('Cola del ticket habilitada para el Usuario', ticket.queueId)
      isValid = true
    } else {
      console.log('Usuario no tiene acceso a la cola', ticket.queueId)
      return false
    }
  }

  // si configuración para cartera activa: verificar si ya es un ticket de la cartera del usuario
  if (DirectTicketsToWallets() && (ticket?.contact?.wallets?.length || 0) > 0) {
    const idx = ticket?.contact?.wallets.findIndex(w => w.id == userId)
    if (idx !== -1) {
      console.log('Ticket de la cartera del usuario')
      return true
    }
    console.log('DirectTicketsToWallets: Ticket no pertenece a la cartera del usuario', ticket)
    return false
  }

  // verificar si el parámetro para no permitir visualizar
  // tickets asignados a otros usuarios está activo
  if (isNotViewAssignedTickets() && profile !== 'supervisorfila' && (ticket?.userId || userId) !== userId) {
    // console.log('isNotViewAssignedTickets y ticket no es del usuario', ticket?.userId, userId)
    // si usuario no está asignado, permitir visualizar
    if (!ticket?.userId) {
      return true
    }
    return false
  }

  // verificar si filtro solo tickets no asignados (isNotAssingned) activo
  if (filtros.isNotAssignedUser) {
    console.log('isNotAssignedUser activo para mostrar solo tickets no asignados', filtros.isNotAssignedUser, !ticket.userId)
    return filtros.isNotAssignedUser && !ticket.userId
  }

  return isValid
}

const atendimentoTicket = {
  state: {
    chatTicketDisponivel: false,
    tickets: [],
    ticketsLocalizadosBusca: [],
    ticketFocado: {
      contacts: {
        tags: [],
        wallets: [],
        extraInfo: []
      }
    },
    hasMore: false,
    contatos: [],
    mensagens: [],
    notificacaoTicket: 0
  },
  mutations: {
    // OK
    SET_HAS_MORE (state, payload) {
      state.hasMore = payload
    },
    // OK
    LOAD_TICKETS (state, payload) {
      const newTickets = orderTickets(payload)
      newTickets.forEach(ticket => {
        const ticketIndex = state.tickets.findIndex(t => t.id === ticket.id)
        if (ticketIndex !== -1) {
          state.tickets[ticketIndex] = ticket
          if (ticket.unreadMessages > 0) {
            state.tickets.unshift(state.tickets.splice(ticketIndex, 1)[0])
          }
        } else {
          if (checkTicketFilter(ticket)) {
            state.tickets.push(ticket)
          }
        }
      })
    },
    RESET_TICKETS (state) {
      state.hasMore = true
      state.tickets = []
    },
    RESET_UNREAD (state, payload) {
      const tickets = [...state.tickets]
      const ticketId = payload.ticketId
      const ticketIndex = tickets.findIndex(t => t.id === ticketId)
      if (ticketIndex !== -1) {
        tickets[ticketIndex] = payload
        tickets[ticketIndex].unreadMessages = 0
      }
      state.ticket = tickets
    },
    // OK
    UPDATE_TICKET (state, payload) {
      const ticketIndex = state.tickets.findIndex(t => t.id === payload.id)
      if (ticketIndex !== -1) {
        // actualizar ticket si se encuentra
        const tickets = [...state.tickets]
        tickets[ticketIndex] = {
          ...tickets[ticketIndex],
          ...payload,
          // ajustar información debido a los cambios en el front
          username: payload?.user?.name || payload?.username || tickets[ticketIndex].username,
          profilePicUrl: payload?.contact?.profilePicUrl || payload?.profilePicUrl || tickets[ticketIndex].profilePicUrl,
          name: payload?.contact?.name || payload?.name || tickets[ticketIndex].name
        }
        state.tickets = tickets.filter(t => checkTicketFilter(t))

        // actualizar si es ticket enfocado
        if (state.ticketFocado.id == payload.id) {
          state.ticketFocado = {
            ...state.ticketFocado,
            ...payload
            // conservar la información del contacto
            // contact: state.ticketFocado.contact
          }
        }
      } else {
        const tickets = [...state.tickets]
        tickets.unshift({
          ...payload,
          // ajustar información debido a los cambios en el front
          username: payload?.user?.name || payload?.username,
          profilePicUrl: payload?.contact?.profilePicUrl || payload?.profilePicUrl,
          name: payload?.contact?.name || payload?.name
        })
        state.tickets = tickets.filter(t => checkTicketFilter(t))
      }
    },

    DELETE_TICKET (state, payload) {
      const ticketId = payload
      const ticketIndex = state.tickets.findIndex(t => t.id === ticketId)
      if (ticketIndex !== -1) {
        state.tickets.splice(ticketIndex, 1)
      }
      // return state.tickets
    },

    // UPDATE_TICKET_MESSAGES_COUNT (state, payload) {

    //   const { ticket, searchParam } = payload
    //   const ticketIndex = state.tickets.findIndex(t => t.id === ticket.id)
    //   if (ticketIndex !== -1) {
    //     state.tickets[ticketIndex] = ticket
    //     state.tickets.unshift(state.tickets.splice(ticketIndex, 1)[0])
    //   } else if (!searchParam) {
    //     state.tickets.unshift(ticket)
    //   }
    //   // return state.tickets
    // },

    UPDATE_TICKET_FOCADO_CONTACT (state, payload) {
      state.ticketFocado.contact = payload
    },
    UPDATE_CONTACT (state, payload) {
      if (state.ticketFocado.contactId == payload.id) {
        state.ticketFocado.contact = payload
      }
      const ticketIndex = state.tickets.findIndex(t => t.contactId === payload.id)
      if (ticketIndex !== -1) {
        const tickets = [...state.tickets]
        tickets[ticketIndex].contact = payload
        tickets[ticketIndex].name = payload.name
        tickets[ticketIndex].profilePicUrl = payload.profilePicUrl
        state.tickets = tickets
      }
    },
    // OK
    TICKET_FOCADO (state, payload) {
      const params = {
        ...payload,
        status: payload.status == 'pending' ? 'open' : payload.status
      }
      state.ticketFocado = params
      // return state.ticketFocado
    },
    // OK
    LOAD_INITIAL_MESSAGES (state, payload) {
      const { messages, messagesOffLine } = payload
      state.mensagens = []
      const newMessages = orderMessages([...messages, ...messagesOffLine])
      state.mensagens = newMessages
    },
    // OK
    LOAD_MORE_MESSAGES (state, payload) {
      const { messages, messagesOffLine } = payload
      const arrayMessages = [...messages, ...messagesOffLine]
      const newMessages = []
      arrayMessages.forEach((message, index) => {
        const messageIndex = state.mensagens.findIndex(m => m.id === message.id)
        if (messageIndex !== -1) {
          state.mensagens[messageIndex] = message
          arrayMessages.splice(index, 1)
        } else {
          newMessages.push(message)
        }
      })
      const messagesOrdered = orderMessages(newMessages)
      state.mensagens = [...messagesOrdered, ...state.mensagens]
    },
    // OK
    UPDATE_MESSAGES (state, payload) {
      // Si el ticket no es el enfocado, no actualizar.
      if (state.ticketFocado.id === payload.ticket.id) {
        const messageIndex = state.mensagens.findIndex(m => m.id === payload.id)
        const mensagens = [...state.mensagens]
        if (messageIndex !== -1) {
          mensagens[messageIndex] = payload
        } else {
          mensagens.push(payload)
        }
        state.mensagens = mensagens
        if (payload.scheduleDate && payload.status == 'pending') {
          const idxScheduledMessages = state.ticketFocado.scheduledMessages.findIndex(m => m.id === payload.id)
          if (idxScheduledMessages === -1) {
            state.ticketFocado.scheduledMessages.push(payload)
          }
        }
      } else {
        const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))

        // Verifica si existe la configuración 'groupnotification'
        const confGroupNotification = configuracoes?.find(c => c.key === 'groupnotification')

        // Si el valor de 'groupnotification' es 'disabled' y data.ticket.isGroup es true, no muestra notificación
        if (confGroupNotification?.value === 'disabled' && payload.ticket?.isGroup) {
          return // Sale de la función sin mostrar la notificación
        }

        if (!payload.fromMe && payload.ticket.status !== 'closed') {
          state.notificacaoTicket += 1
        }
      }

      const TicketIndexUpdate = state.tickets.findIndex(t => t.id == payload.ticket.id)
      if (TicketIndexUpdate !== -1) {
        let tickets = [...state.tickets]
        const unreadMessages = state.ticketFocado.id == payload.ticket.id ? 0 : payload.ticket.unreadMessages
        tickets[TicketIndexUpdate] = {
          ...state.tickets[TicketIndexUpdate],
          answered: payload.ticket.answered,
          unreadMessages,
          lastMessage: payload.mediaName || payload.body,
          lastMessageAt: payload.ticket.lastMessageAt
        }
        tickets = orderTickets(tickets)
        state.tickets = tickets
      }
    },
    // OK
    UPDATE_MESSAGE_STATUS (state, payload) {
      // Si el ticket no es el enfocado, no actualizar.
      if (state.ticketFocado.id != payload.ticket.id) {
        return
      }
      const messageIndex = state.mensagens.findIndex(m => m.id === payload.id)
      const mensagens = [...state.mensagens]
      if (messageIndex !== -1) {
        mensagens[messageIndex] = payload
        state.mensagens = mensagens
      }

      const ticketIndex = state.tickets.findIndex(m => m.id === payload.ticket.id)
      if (ticketIndex !== -1) {
        state.tickets[ticketIndex].lastMessage = payload.ticket.lastMessage
        state.tickets[ticketIndex].lastMessageAt = payload.ticket.lastMessageAt
        state.tickets[ticketIndex].updatedAt = payload.ticket.updatedAt
      }
      state.tickets = orderTickets(state.tickets)
      // Si existen mensajes programados en el ticket enfocado,
      // gestionar la actualización de los mensajes eliminados.
      if (state.ticketFocado?.scheduledMessages) {
        const scheduledMessages = [...state.ticketFocado.scheduledMessages]
        const scheduled = scheduledMessages.filter(m => m.id != payload.id)
        state.ticketFocado.scheduledMessages = scheduled
      }
    },
    UPDATE_MESSAGE(state, payload) {
      // Si el ticket no es el enfocado, no actualizar.
      if (state.ticketFocado.id != payload.ticketId) {
        return
      }

      state.mensagens = state.mensagens.map((m) => {
        if (m.id == payload.id) {
          return { ...m, ...payload }
        }

        return m
      })

      if (state.ticketFocado?.scheduledMessages) {
        state.ticketFocado.scheduledMessages = state.ticketFocado.scheduledMessages.map((m) => {
          if (m.id == payload.id) {
            return { ...m, ...payload }
          }

          return m
        })
      }
    },
    // OK
    RESET_MESSAGE (state) {
      state.mensagens = []
      // return state.mensagens
    }
  },
  actions: {
    async LocalizarMensagensTicket ({ commit, dispatch }, params) {
      const mensagens = await LocalizarMensagens(params)
      // commit('TICKET_FOCADO', mensagens.data.ticket)
      commit('SET_HAS_MORE', mensagens.data.hasMore)
      // commit('UPDATE_TICKET_CONTACT', mensagens.data.ticket.contact)
      if (params.pageNumber === 1) {
        commit('LOAD_INITIAL_MESSAGES', mensagens.data)
      } else {
        commit('LOAD_MORE_MESSAGES', mensagens.data)
      }
    },
    async AbrirChatMensagens ({ commit, dispatch }, data) {
      try {
        await commit('TICKET_FOCADO', {})
        await commit('RESET_MESSAGE')
        const ticket = await ConsultarDadosTicket(data)
        await commit('TICKET_FOCADO', ticket.data)
        // commit('SET_HAS_MORE', true)
        const params = {
          ticketId: data.id,
          pageNumber: 1
        }
        await dispatch('LocalizarMensagensTicket', params)

        await $router.push({ name: 'chat', params, query: { t: new Date().getTime() } })
      } catch (error) {
        // posteriormente es necesario investigar el motivo por el que está generando error
        if (!error) return
        const errorMsg = error?.response?.data?.error
        if (errorMsg) {
          Notify.create({
            type: 'negative',
            message: error.response.data.error,
            progress: true,
            position: 'top'
          })
        } else {
          Notify.create({
            type: 'negative', 
            message: `Ups... Ocurrió un problema no identificado. ${JSON.stringify(error)}`,
            progress: true,
            position: 'top'
          })
        }
      }
    }
  }
}

export default atendimentoTicket
