import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'reactions' column to the 'Messages' table
    await queryInterface.addColumn(
      'Messages',  // Table name
      'reactions', // New column name
      {
        type: DataTypes.JSON,  // JSON type for storing reaction data
        allowNull: true,       // Allow null values
        defaultValue: [],      // Default value is an empty array (as indicated by original code)
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'reactions' column from the 'Messages' table
    await queryInterface.removeColumn(
      'Messages',  // Table name
      'reactions'  // Column name to remove
    );
  }
};

export = migration;