import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla 'LogTickets' para registrar eventos/logs de tickets
    return queryInterface.createTable('LogTickets', {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      userId: {
        type: DataTypes.INTEGER,
        references: { model: 'Users', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Si se elimina el usuario, se elimina el log
        allowNull: true, // Permite nulos (¿logs de sistema?)
        defaultValue: null
      },
      ticketId: {
        type: DataTypes.INTEGER,
        references: { model: 'Tickets', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Si se elimina el ticket, se elimina el log
        allowNull: false
      },
      queueId: {
        type: DataTypes.INTEGER,
        references: { model: 'Queues', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Si se elimina la cola, se elimina el log
        defaultValue: null,
        allowNull: true
      },
      type: { // Tipo de log (ej: 'create', 'transfer', 'close')
        type: DataTypes.STRING,
        allowNull: false
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la tabla 'LogTickets'
    return queryInterface.dropTable('LogTickets');
  }
};