// Original: authState.js
// Deobfuscated, converted to TS, and translated

"use strict";

import {
  AuthenticationCreds,
  AuthenticationState,
  BufferJSON,
  initAuthCreds,
  proto,
  SignalKeyStoreWithTransaction
} from "@whiskeysockets/baileys";
import { Pool, PoolClient } from "pg"; // Importar tipos específicos de pg
import { logger } from "../utils/logger"; // Asumiendo exportación nombrada

// Interfaz para la configuración de la Pool de PostgreSQL
interface PoolConfig {
  user?: string;
  host?: string;
  database?: string;
  password?: string;
  port?: number;
}

// Interfaz para el objeto 'd' pasado a authState
interface AuthStateParams {
  id: number | string; // Asumiendo que id puede ser número o string
  session?: string | null; // Asumiendo que session puede ser string o null
  update: (data: { session: string }) => Promise<any>; // Asumiendo que update devuelve una Promise
}

// Configuración de la Pool
const poolConfig: PoolConfig = {
  user: process.env.POSTGRES_USER || "postgres",
  host: process.env.POSTGRES_HOST || "localhost",
  database: process.env.POSTGRES_DB || "whazing",
  password: process.env.POSTGRES_PASSWORD || "postgres",
  port: parseInt(process.env.DB_PORT || "5432", 10) || 5432
};

const pool = new Pool(poolConfig);

// Función principal authState
export const authState = async (
  d: AuthStateParams
): Promise<{ state: AuthenticationState; saveState: () => Promise<void> }> => {
  let creds: AuthenticationCreds;
  const whatsappId = d.id; // Usar whatsappId en lugar de g

  // Función para escribir datos en la base de datos
  const writeData = async (
    type: string,
    key: string,
    data: any
  ): Promise<void> => {
    logger.debug(
      `Storing keys of type ${type} key: ${key} for whatsappId: ${whatsappId}`
    );
    const client: PoolClient = await pool.connect();
    try {
      // La consulta SQL de inserción/actualización
      await client.query(
        `INSERT INTO "BaileysKeys" ("whatsappId", "type", "key", "value")
         VALUES ($1, $2, $3, $4)
         ON CONFLICT ("whatsappId", "type", "key")
         DO UPDATE SET "value" = EXCLUDED.value`,
        [whatsappId, type, key, JSON.stringify(data)]
      );
    } finally {
      client.release();
    }
  };

  // Función para leer datos de la base de datos
  const readData = async (type: string, key: string): Promise<any | null> => {
    const client: PoolClient = await pool.connect();
    try {
      const result = await client.query(
        `SELECT "value" FROM "BaileysKeys" WHERE "whatsappId" = $1 AND "type" = $2 AND "key" = $3`,
        [whatsappId, type, key]
      );
      if (result.rowCount > 0) {
        return JSON.parse(result.rows[0].value);
      }
      return null;
    } finally {
      client.release();
    }
  };

  // Función para eliminar datos de la base de datos
  const removeData = async (type: string, key: string): Promise<void> => {
    logger.debug(
      { type, key },
      `Deleting key ${key} of type ${type} for whatsappId: ${whatsappId}`
    );
    const client: PoolClient = await pool.connect();
    try {
      await client.query(
        `DELETE FROM "BaileysKeys" WHERE "whatsappId" = $1 AND "type" = $2 AND "key" = $3`,
        [whatsappId, type, key]
      );
    } finally {
      client.release();
    }
  };

  // Función para guardar el estado (creds)
  const saveState = async (): Promise<void> => {
    try {
      const sessionData = {
        creds: creds,
        keys: {} // Las claves se manejan por separado, no se serializan aquí directamente
      };
      // Utilizar replacer de BufferJSON para serializar correctamente los Buffers
      await d.update({
        session: JSON.stringify(sessionData, BufferJSON.replacer, 2)
      });
    } catch (error) {
      logger.error("Error saving auth state:", error);
    }
  };

  // Carga inicial de credenciales
  if (d.session && d.session !== null) {
    // Utilizar reviver de BufferJSON para deserializar correctamente los Buffers
    const parsedSession = JSON.parse(d.session, BufferJSON.reviver);
    creds = parsedSession.creds;
    const legacyKeys = parsedSession.keys || {}; // Datos de claves de sesión antigua

    // Migración de claves de formato antiguo si existen
    if (Object.keys(legacyKeys).length > 0) {
      logger.info(
        `Starting conversion of keys of type ${typeof legacyKeys} to new format for whatsappId: ${whatsappId}`
      );
      const keyTypesMap: { [key: string]: string } = {
        preKeys: "pre-key",
        senderKeys: "sender-key",
        appStateSyncKeys: "app-state-sync-key",
        appStateVersions: "app-state-version",
        senderKeyMemory: "sender-key-memory",
        sessions: "session"
      };

      for await (const legacyType of Object.keys(legacyKeys)) {
        const newType = keyTypesMap[legacyType];
        if (newType) {
          logger.debug(`Converting ${legacyType} to ${newType}`);
          for await (const keyId of Object.keys(legacyKeys[legacyType])) {
            await writeData(newType, keyId, legacyKeys[legacyType][keyId]);
          }
        } else {
          logger.warn(`Unknown legacy key type: ${legacyType}`);
        }
      }
      logger.info(
        `Finished conversion for whatsappId: ${whatsappId}. Saving updated state without old keys.`
      );
      // Guardar el estado sin las claves antiguas después de la migración
      await saveState(); // saveState ahora solo guarda 'creds'
    }
  } else {
    creds = initAuthCreds();
  }

  return {
    state: {
      creds,
      keys: {
        // Implementación del SignalKeyStore
        get: async (type, ids) => {
          const data: { [key: string]: any } = {};
          for await (const id of ids) {
            try {
              let value = await readData(type, id);
              // Deserializar datos específicos si es necesario
              if (type === "app-state-sync-key" && value) {
                value = proto.Message.AppStateSyncKeyData.fromObject(value);
              }
              data[id] = value;
            } catch (error) {
              logger.error(
                `Error fetching key ${id} of type ${type} for whatsappId: ${whatsappId}`
              );
              logger.error(`Error: ${error.message}`);
              logger.error(`Stack: ${error.stack}`);
              data[id] = null; // O manejar el error como se prefiera
            }
          }
          return data;
        },
        set: async data => {
          const tasks: Promise<void>[] = [];
          for (const type in data) {
            for (const id in data[type]) {
              const value = data[type][id];
              const task = value
                ? writeData(type, id, value)
                : removeData(type, id);
              tasks.push(task);
            }
          }
          await Promise.all(tasks);
        }
      } as SignalKeyStoreWithTransaction // Asegurar que cumple la interfaz
    },
    saveState // Cambiado de saveCreds a saveState
  };
};
