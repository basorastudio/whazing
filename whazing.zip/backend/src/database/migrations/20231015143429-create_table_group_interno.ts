// --- START OF FILE 20231015143429-create_table_group_interno.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Groups"; // Table name from original code
    const tableDefinition = {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true, // 'autoIncrem' + 'ent'
        allowNull: false
      },
      group: {
        // Column name from original code
        type: DataTypes.STRING,
        allowNull: false // Changed ![] to false
        // Consider adding unique: true if group names should be unique per user/tenant
      },
      userId: {
        // Column name from original code
        type: DataTypes.INTEGER,
        references: {
          model: "Users", // Original 'Users'
          key: "id"
        },
        onUpdate: "CASCADE", // Original 'CASCADE'
        onDelete: "SET NULL" // Original 'SET NULL'
        // allowNull defaults to true, which matches the onDelete: 'SET NULL' behavior
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
      // Note: The original migration included a tenantId reference based on the file name pattern,
      // but the code itself didn't add it here. It's added in a separate migration.
    };
    await queryInterface.createTable(tableName, tableDefinition);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Groups";
    await queryInterface.dropTable(tableName);
  }
};

export default migration;

// --- END OF FILE 20231015143429-create_table_group_interno.ts ---
