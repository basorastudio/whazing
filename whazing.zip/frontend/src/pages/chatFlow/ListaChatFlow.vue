<template>
  <div>
    <div class="row">
      <div class="col">
        <q-table
          square
          flat
          bordered
          class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
          :class="{
    'full-height': $q.screen.lt.sm
  }"
          hide-bottom
          :data="listachatFlow"
          :columns="columns"
          :loading="loading"
          row-key="id"
          :pagination.sync="pagination"
          :rows-per-page-options="[0]"
        >
          <template v-slot:top-left>
            <div>
              <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
                <q-icon name="mdi-robot-outline q-pr-sm" />
                Flujos
              </h2>
              <q-btn
                class="generate-button btn-rounded-50"
                :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="eva-plus-outline"
              label="Agregar"
              @click="chatFlowSelecionado = {}; modalChatFlow = true"
            />
              <q-btn
                class="generate-button btn-rounded-50"
                :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="mdi-import"
              label="Importar"
              @click="modalImportFlow = true"
            />
              <q-btn flat
                     class="generate-button btn-rounded-50"
                     :class="{'generate-button-dark' : $q.dark.isActive}"
                     v-if="whatsappNumber"
                     icon="mdi-whatsapp"
                     label="Llamar Soporte"
                     @click="abrirWhatsApp"
              />
            </div>

          </template>
          <template v-slot:body-cell-isActive="props">
            <q-td class="text-center">
              <q-icon
                size="16px"
                :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                :color="props.value ? 'positive' : 'negative'"
                class=""
              />
              <span class="q-mx-xs text-bold"> {{ props.value ? 'Activo' : 'Inactivo' }} </span>
            </q-td>
          </template>
          <template v-slot:body-cell-AcceptTransfer="props">
            <q-td class="text-center">
              <q-icon
                size="16px"
                :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                :color="props.value ? 'positive' : 'negative'"
                class=""
              />
              <span class="q-mx-xs text-bold"> {{ props.value ? 'Activo' : 'Inactivo' }} </span>
            </q-td>
          </template>
          <template v-slot:body-cell-acoes="props">
            <q-td class="text-center">
              <q-btn
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                icon="eva-edit-outline"
                flat
                round
                @click="editFlow(props.row)"
              >
                <q-tooltip>
                  Editar información
                </q-tooltip>
              </q-btn>
              <q-btn
                icon="mdi-sitemap"
                flat
                round
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                @click="abrirFluxo(props.row)"
              >
                <q-tooltip>
                  Abrir Flujo
                </q-tooltip>
              </q-btn>
              <q-btn
                icon="eva-trash-outline"
                flat
                round
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                @click="deletarFluxo(props.row)"
              >
                <q-tooltip>
                  Eliminar
                </q-tooltip>
              </q-btn>
            </q-td>
          </template>

        </q-table>
      </div>
    </div>
    <ModalChatFlow
      :modalChatFlow.sync="modalChatFlow"
      :chatFlowEdicao.sync="chatFlowSelecionado"
      @chatFlow:criada="novoFluxoCriado"
      @chatFlow:editado="fluxoEditado"
    />
    <ModalImportFlow
      :modalImportFlow.sync="modalImportFlow"
      @chatFlow:criada="novoFluxoCriado"
    />
    <q-dialog v-model="confirmDelete" persistent>
      <q-card style="min-width: 350px">
        <q-card-section>
          <div class="text-h6">¿Está seguro de que desea eliminar este flujo?</div>
          <div>{{ chatFlowSelecionado.name }}</div>
        </q-card-section>
        <q-card-actions align="right" class="text-primary">
          <q-btn
            label="Cancelar"
            v-close-popup
            class="q-mr-md"
            color="primary"
          />
          <q-btn label="Eliminar" color="negative" v-close-popup @click="confirmDeleteFoo()" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import { ListarFilas } from 'src/service/filas'
import { ListarChatFlow, DeletarChatFlow } from 'src/service/chatFlow'
import { ListarUsuarios } from 'src/service/user'
import { ListarConfiguracaoPublica, ListarCores } from 'src/service/configuracoesgeneral'
import ModalChatFlow from './ModalChatFlow.vue'
import ModalImportFlow from './ModalImportFlow.vue'

export default {
  name: 'ChatFlowIndex',
  components: { ModalChatFlow, ModalImportFlow },
  data () {
    return {
      confirmDelete: false,
      listachatFlow: [],
      modalChatFlow: false,
      modalImportFlow: false,
      whatsappNumber: null,
      chatFlowSelecionado: {},
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        searchParam: null,
        hasMore: true
      },
      loading: false,
      columns: [
        { name: 'name', label: 'Nombre', field: 'name', align: 'left' },
        { name: 'isActive', label: 'Estado', field: 'isActive', align: 'center' },
        { name: 'AcceptTransfer', label: 'Disp. Transferencia', field: 'AcceptTransfer', align: 'center' },
        { name: 'celularTeste', label: 'Celular Prueba', field: 'celularTeste', align: 'center' },
        { name: 'acoes', label: '', field: 'acoes', align: 'center' }
      ],
      filas: [],
      usuarios: []
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores devueltos por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Error al buscar configuraciones:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Ol%C3%A1%21+tenho+duvidas+bot`
        window.open(url, '_blank') // Abre WhatsApp en una nueva pestaña
      }
    },
    async listarChatFlow () {
      const { data } = await ListarChatFlow()
      this.listachatFlow = data.chatFlow
    },
    async listarFilas () {
      const { data } = await ListarFilas({ isActive: true })
      this.filas = data.filter(q => q.isActive)
    },
    async listarUsuarios () {
      const { data } = await ListarUsuarios(this.params)
      this.usuarios = data.users
    },
    novoFluxoCriado (flow) {
      const lista = [...this.listachatFlow]
      lista.push(flow)
      this.listachatFlow = lista
    },
    fluxoEditado (flow) {
      const lista = [...this.listachatFlow.filter(f => f.id !== flow.id)]
      lista.push(flow)
      this.listachatFlow = lista
    },
    editFlow (flow) {
      this.chatFlowSelecionado = flow
      this.modalChatFlow = true
    },
    async abrirFluxo (flow) {
      await this.$store.commit('SET_FLOW_DATA', {
        usuarios: this.usuarios,
        filas: this.filas,
        flow
      })
      this.$router.push({ name: 'chat-flow-builder' })
    },
    deletarFluxo (flow) {
      this.chatFlowSelecionado = flow
      this.confirmDelete = true
    },
    async confirmDeleteFoo (flow) {
      await DeletarChatFlow(this.chatFlowSelecionado)
      await this.listarChatFlow()
    }
  },
  async mounted () {
    this.loadColors()
    this.fetchConfigurations()
    await this.listarChatFlow()
    await this.listarFilas()
    await this.listarUsuarios()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px
</style>
