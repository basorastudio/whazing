import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Cambia el tipo de la columna 'profilePicUrl' a TEXT en 'Contacts'
    return queryInterface.changeColumn('Contacts', 'profilePicUrl', {
      type: DataTypes.TEXT, // Cambia a TEXT
      allowNull: true, // Mantiene allowNull como true (basado en el 'down')
      defaultValue: null // Mantiene defaultValue como null (basado en el 'down')
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Revierte el cambio de tipo de la columna 'profilePicUrl' a STRING
    return queryInterface.changeColumn('Contacts', 'profilePicUrl', {
      type: DataTypes.STRING, // Vuelve a STRING
      allowNull: true, // Asume que era true
      defaultValue: '' // Vuelve al default '' (basado en el 'down' original)
                       // !! Confirmar si este era el default original
    });
  }
};