import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'BaileysKeys' table
    // Stores session/authentication keys for Baileys WhatsApp connections.
    await queryInterface.createTable(
      "BaileysKeys", // Table name
      {
        whatsappId: {
          // Foreign key and part of composite primary key
          type: DataTypes.INTEGER,
          primaryKey: true,
          allowNull: false,
          references: {
            model: "Whatsapps", // References the WhatsApp connection
            key: "id"
          },
          onUpdate: "CASCADE",
          onDelete: "CASCADE" // If WhatsApp connection is deleted, delete its keys
        },
        type: {
          // e.g., 'creds', 'pre-key', 'session', etc. Part of composite primary key
          type: DataTypes.STRING,
          primaryKey: true,
          allowNull: false
        },
        key: {
          // The specific ID within the type (e.g., pre-key ID). Part of composite primary key
          type: DataTypes.STRING,
          primaryKey: true,
          allowNull: false
        },
        value: {
          // The actual key data
          type: DataTypes.TEXT, // TEXT to store potentially large key data
          allowNull: false
        }
        // No createdAt/updatedAt in the original definition
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'BaileysKeys' table
    await queryInterface.dropTable("BaileysKeys");
  }
};

export = migration;
