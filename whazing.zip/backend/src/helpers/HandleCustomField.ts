import ContactCustomField from '../models/ContactCustomField'; // Assuming model path

const HandleCustomField = async (
    contactId: number | string,
    fieldName: string,
    value: string | number | boolean | null // Allow different value types
): Promise<void> => {
    try {
        if (!fieldName || typeof fieldName !== 'string') {
            throw new Error('El campo customizado: nombre es inválido o está vacío.');
        }

        // Find existing custom field
        const customField = await ContactCustomField.findOne({
            where: {
                contactId: contactId,
                name: fieldName
            }
        });

        if (customField) {
            // Update if exists
            await customField.update({ value: String(value) }); // Ensure value is stored as string if needed by DB
        } else {
            // Create if not exists
            await ContactCustomField.create({
                contactId: contactId,
                name: fieldName,
                value: String(value) // Ensure value is stored as string if needed by DB
            });
        }
    } catch (error: any) {
        console.error(`Error al procesar el campo customizado: ${fieldName}`, error.message);
        // Decide whether to re-throw or handle
        throw error; // Re-throw the original error for higher-level handling
    }
};

export default HandleCustomField;