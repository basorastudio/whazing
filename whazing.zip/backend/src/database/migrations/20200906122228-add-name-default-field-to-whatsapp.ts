import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna 'default' a la tabla Whatsapps
    // NOTA: 'default' es una palabra reservada en SQL. Sequelize maneja esto,
    // pero puede ser problemático en consultas SQL manuales.
    // La migración 20200919124112 renombra esta columna a 'isDefault'.
    return queryInterface.addColumn('Whatsapps', 'default', { // Nombre de columna preservado
      type: DataTypes.BOOLEAN,
      allowNull: false, // Asume que no puede ser nulo
      defaultValue: false
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna 'default'
    return queryInterface.removeColumn('Whatsapps', 'default');
  }
};