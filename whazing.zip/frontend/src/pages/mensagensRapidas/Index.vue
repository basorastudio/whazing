<template>
  <div>
    <q-table
      flat
      bordered
      square
      hide-bottom
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      :data="mensagensRapidas"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
    >
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-reply-all-outline" />
            {{ $t('quickMessages.title') }}
          </h2>
          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline"
            :label="$t('general.addButton')"
          @click="mensagemRapidaEmEdicao = {}; modalMensagemRapida = true"
        />
        </div>

      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon
            size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-message="props">
        <q-td :props="props" style="white-space: pre-wrap; word-wrap: break-word;">
          {{ props.row.message.length > 100 ? props.row.message.slice(0, 100) + '...' : props.row.message }}
        </q-td>
      </template>
      <template v-slot:body-cell-media="props">
        <q-td :props="props">
          <span v-if="props.row.media">
            <a :href="generateMediaUrl(props.row.media)" target="_blank" style="text-decoration: underline; cursor: pointer;">
              {{ $t('general.open_file') }}
            </a>
          </span>
          <span v-else>
            {{ $t('general.no_file') }}
          </span>
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-edit-outline"
            @click="editarMensagem(props.row)"
          />
          <q-btn
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-trash-outline"
            @click="deletarMensagem(props.row)"
          />
        </q-td>
      </template>
    </q-table>
    <ModalMensagemRapida
      :modalMensagemRapida.sync="modalMensagemRapida"
      :mensagemRapidaEmEdicao.sync="mensagemRapidaEmEdicao"
      @mensagemRapida:criada="mensagemCriada"
      @mensagemRapida:editada="mensagemEditada"
    />
  </div>
</template>

<script>
import ModalMensagemRapida from './ModalMensagemRapida'
import { ListarMensagensRapidasAll, DeletarMensagemRapida } from 'src/service/mensagensRapidas'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  name: 'MensagensRapidas',
  components: { ModalMensagemRapida },
  data () {
    return {
      loading: false,
      mensagensRapidas: [],
      modalMensagemRapida: false,
      mensagemRapidaEmEdicao: {},
      columns: [
        { name: 'id', label: this.$t('general.id'), field: 'id', align: 'left' },
        { name: 'key', label: this.$t('quickMessages.table.columns.key'), field: 'key', align: 'left' },
        { name: 'message', label: this.$t('general.message'), field: 'message', align: 'left' },
        { name: 'media', label: this.$t('general.file'), field: 'media', align: 'left' },
        { name: 'acoes', label: this.$t('general.actions'), field: 'acoes', align: 'center' }
      ],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      }
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    generateMediaUrl(mediaFileName) {
      return `${process.env.URL_API}/public/${mediaFileName}`
    },
    async listarMensagensRapidas () {
      const { data } = await ListarMensagensRapidasAll()
      this.mensagensRapidas = data
    },
    mensagemCriada (mensagem) {
      this.mensagensRapidas.unshift(mensagem)
    },
    mensagemEditada (mensagem) {
      const newMensagens = [...this.mensagensRapidas]
      const idx = newMensagens.findIndex(m => m.id === mensagem.id)
      if (idx > -1) {
        newMensagens[idx] = mensagem
      }
      this.mensagensRapidas = [...newMensagens]
      // console.log(this.mensagensRapidas)
      // console.log('mensagemEditada')
    },
    editarMensagem (mensagem) {
      this.mensagemRapidaEmEdicao = { ...mensagem }
      this.modalMensagemRapida = true
    },
    deletarMensagem (mensagem) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('quickMessages.modal.deleteConfirm.message', { key: mensagem.key }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarMensagemRapida(mensagem)
          .then(res => {
            let newMensagens = [...this.mensagensRapidas]
            newMensagens = newMensagens.filter(m => m.id !== mensagem.id)

            this.mensagensRapidas = [...newMensagens]
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: this.$t('quickMessages.notifications.deleteSuccess'),
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
        this.loading = false
      })
    }
  },
  mounted () {
    this.loadColors()
    this.listarMensagensRapidas()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

</style>
