import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      // Elimina la columna 'action' de la tabla 'StepsReply'
      queryInterface.removeColumn("StepsReply", "action"),
      // Elimina la columna 'stepOrder' de la tabla 'StepsReply'
      queryInterface.removeColumn("StepsReply", "stepOrder")
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Vuelve a añadir las columnas 'action' y 'stepOrder'
    const actionColumn = {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0
    };
    const stepOrderColumn = {
      type: DataTypes.INTEGER,
      allowNull: false
    };
    return Promise.all([
      queryInterface.addColumn("StepsReply", "action", actionColumn),
      queryInterface.addColumn("StepsReply", "stepOrder", stepOrderColumn)
    ]);
  }
};
