<template>
  <div>
    <q-table flat
      bordered
      square
      hide-bottom
      class="contact-table container-rounded-10 my-sticky-dynamic q-ma-lg"
      :data="planos"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]">
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-currency-usd q-pr-sm" />
            {{ $t('planos.titulo') }}
          </h2>
          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline"
            :label="$t('planos.adicionar')"
          @click="planoEdicao = {}; modalPlano = true" />
        </div>

      </template>

              <template v-slot:body-cell-value="props">
                <q-td class="text-center">
          R$ {{ props.value.toFixed(2).replace('.', ',') }}
                </q-td>
              </template>

              <template v-slot:body-cell-isPublic="props">
                <q-td class="text-center">
                  <q-icon size="24px" :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                    :color="props.value ? 'positive' : 'negative'" />
                </q-td>
              </template>
      <template v-slot:body-cell-group="props">
        <q-td class="text-center">
          <q-icon size="24px" :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                  :color="props.value ? 'positive' : 'negative'" />
        </q-td>
      </template>
      <template v-slot:body-cell-campaign="props">
        <q-td class="text-center">
          <q-icon size="24px" :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                  :color="props.value ? 'positive' : 'negative'" />
        </q-td>
      </template>
      <template v-slot:body-cell-integrations="props">
        <q-td class="text-center">
          <q-icon size="24px" :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                  :color="props.value ? 'positive' : 'negative'" />
        </q-td>
      </template>
              <template v-slot:body-cell-acoes="props">
                <q-td class="text-center">
                  <q-btn class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" flat round icon="eva-edit-outline" @click="editarPlano(props.row)" />
                  <q-btn class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" flat round icon="eva-trash-outline" @click="deletarPlano(props.row)" />
                </q-td>
              </template>
            </q-table>
    <ModalPlano
      :modalPlano.sync="modalPlano"
      :planoEdicao.sync="planoEdicao"
      @modal-plano:criada="planoCriada"
      @modal-plano:editada="planoEditada"
      @reload-planos="listarPlanos"
    />
  </div>
</template>

<script>
import { listarplanos, Deletarplano } from '../../../service/plans'
import ModalPlano from './ModalPlano'
export default {
  name: 'Planos',
  components: {
    ModalPlano
  },
  data() {
    return {
      tab: 'planos',
      planoEdicao: {},
      modalPlano: false,
      planos: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'name', label: this.$t('planos.nome_plano'), field: 'name', align: 'left' },
        { name: 'maxUsers', label: this.$t('planos.max_usuarios'), field: 'maxUsers', align: 'center' },
        { name: 'maxConnections', label: this.$t('planos.max_conexoes'), field: 'maxConnections', align: 'center' },
        { name: 'value', label: this.$t('planos.valor'), field: 'value', align: 'center' },
        { name: 'isPublic', label: this.$t('planos.publico'), field: 'isPublic', align: 'center' },
        { name: 'group', label: this.$t('planos.grupos'), field: 'group', align: 'center' },
        { name: 'campaign', label: this.$t('planos.campanhas'), field: 'campaign', align: 'center' },
        { name: 'integrations', label: this.$t('planos.integracoes'), field: 'integrations', align: 'center' },
        { name: 'acoes', label: this.$t('planos.acoes'), field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async listarPlanos() {
      const { data } = await listarplanos()
      this.planos = data.filter(plano => plano.id !== 1)
    },
    editarPlano(plano) {
      this.planoEdicao = { ...plano }
      this.modalPlano = true
    },
    planoCriada(plano) {
      const newPlanos = [...this.planos]
      newPlanos.push(plano)
      this.planos = [...newPlanos]
    },
    planoEditada(plano) {
      const newPlanos = [...this.planos]
      const idx = newPlanos.findIndex(f => f.id === plano.id)
      if (idx > -1) {
        newPlanos[idx] = plano
      }
      this.planos = [...newPlanos]
    },
    deletarPlano(plano) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('planos.confirmar_deletar', { name: plano.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        Deletarplano(plano)
          .then(res => {
            let newPlanos = [...this.planos]
            newPlanos = newPlanos.filter(f => f.id !== plano.id)

            this.planos = [...newPlanos]
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: this.$t('planos.plano_deletado', { name: plano.name }),
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
        this.loading = false
      })
    }
  },
  mounted() {
    this.listarPlanos()
  }
}
</script>

<style lang="scss" scoped></style>
