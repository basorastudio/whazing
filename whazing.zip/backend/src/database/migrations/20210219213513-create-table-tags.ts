import { QueryInterface, DataTypes, Sequelize } from 'sequelize'; // Added Sequelize for fn
import { Migration } from 'sequelize'; // Added Migration type

const migration: Migration = { // Defined type
  up: (queryInterface: QueryInterface): Promise<void> => { // Return type Promise<void>
    // Crea la tabla 'Tags'
    // Using createTable directly, removed Promise.all wrapper as it's one operation
    return queryInterface.createTable('Tags', {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      tag: { // Nombre de la etiqueta
        type: DataTypes.STRING,
        allowNull: false
      },
      isActive: { // Indica si la etiqueta está activa
        type: DataTypes.BOOLEAN,
        defaultValue: true, // Valor predeterminado es true
        allowNull: false
      },
      color: { // Color asociado a la etiqueta
        type: DataTypes.STRING,
        allowNull: false
      },
      userId: {
        type: DataTypes.INTEGER,
        references: { model: 'Users', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
        allowNull: true // Allow null because onDelete is SET NULL
      },
      tenantId: {
        type: DataTypes.INTEGER,
        references: { model: 'Tenants', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
        allowNull: false,
        // defaultValue: 1 // defaultValue on FK can be problematic, removed unless strictly needed
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn('NOW') // Use DB function for default
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: Sequelize.fn('NOW') // Use DB function for default
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => { // Return type Promise<void>
    // Elimina la tabla 'Tags'
    // Using dropTable directly, removed Promise.all wrapper
    return queryInterface.dropTable('Tags');
  }
};

export = migration; // Use export = for consistency with other migrations