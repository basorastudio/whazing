import { QueryInterface, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Copia el valor de la columna 'id' a la columna 'messageId' en la tabla 'Messages'
    const updateQuery = 'UPDATE "Messages" set "messageId" = "id";';
    return Promise.all([
        queryInterface.sequelize.query(updateQuery)
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Establece la columna 'messageId' a null en la tabla 'Messages'
    const updateQuery = 'UPDATE "Messages" set "messageId" = null;';
    return Promise.all([
        queryInterface.sequelize.query(updateQuery)
    ]);
  }
};