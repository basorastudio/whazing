"use strict";
import { QueryInterface } from "sequelize";

export default {
  up: async (queryInterface: QueryInterface) => {
    // Inserta un usuario administrador predeterminado
    return queryInterface.sequelize.query(`
      INSERT INTO public."Users" (name,email,"passwordHash","createdAt","updatedAt",profile,"tokenVersion","lastLogin","lastLogout","isOnline",configs,"lastOnline","tenantId","isRemoveNotAssignedUser", "isNotQueueDefine","status") VALUES
      ('Administrador','admin@admin.com','$2a$08$/wEAiRlWTPY/EQ/P7MCOIbjcp.Czfe1CqCPZLiCcLkfGcnzxCQprgYeFry','2022-11-04 17:14:32.711','2022-11-04 17:14:32.711','admin',0,'2022-11-03 01:35:12.607','2022-08-07 17:28:29.060',true,'{"filtroAtendimentos":{"searchParam":"","pageNum":1,"status":["open"],"showAll":true,"count":null,"queuesIds":[],"withUnreadMessages":false,"isNotAssignedUser":false},"isDark":false}','2022-11-04 17:14:32.832',1,false,true,'offline');
    `);
  },

  down: async (queryInterface: QueryInterface) => {
    // Elimina todos los registros de la tabla Users (¡cuidado en producción!)
    return queryInterface.bulkDelete("Users", {});
  }
};
