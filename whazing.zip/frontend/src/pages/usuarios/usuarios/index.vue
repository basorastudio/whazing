<template>
  <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-table
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{'full-height': $q.screen.lt.sm}"
      :data="usuarios"
      title="Usuários"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>

          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-account-group-outline q-pr-sm" />
            {{ $t('usuarios.usuarios') }}
          </h2>

          <div class="row flex-gap-1">
            <q-input
          style="width: 300px"
          filled
          dense
          class="contact-search col-grow"
          debounce="500"
          v-model="filter"
          clearable
          :placeholder="$t('usuarios.localize')"
          @input="filtrarUsuario"
        >
          <template v-slot:prepend>
            <q-icon name="search" />
          </template>
        </q-input>
        <q-btn
          class="generate-button btn-rounded-50"
          :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline "
          :label="$t('usuarios.adicionar')"
          @click="usuarioSelecionado = {}; modalUsuario = true"
        />
          </div>

        </div>

      </template>
      <template v-slot:body-cell-isOnline="props">
        <q-td class="text-center">
          <!-- Bolinha indicando o status -->
          <div
            :style="{
        width: '12px',
        height: '12px',
        borderRadius: '50%',
        display: 'inline-block',
        backgroundColor: props.value ? 'green' : 'red',
      }"
          ></div>
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            flat
            round
            icon="mdi-cellphone-wireless"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="gerirCanaisUsuario(props.row)"
          >
            <q-tooltip>
              {{ $t('usuarios.gestaoCanais') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            icon="mdi-phone"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="gerirWavoipUsuario(props.row)"
          >
            <q-tooltip>
              {{ $t('usuarios.gestaoChamadas') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            icon="mdi-arrow-decision-outline"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="gerirFilasUsuario(props.row)"
          >
            <q-tooltip>
              {{ $t('usuarios.gestaoFilas') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            icon="eva-edit-outline"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="editarUsuario(props.row)"
          />
          <q-btn
            v-if="userProfile === 'admin'"
            flat
            round
            icon="eva-trash-outline"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="deletarUsuario(props.row)"
          />
        </q-td>
      </template>
      <template v-slot:pagination="{ pagination }">
        {{ usuarios.length }}/{{ pagination.rowsNumber }}
      </template>
    </q-table>
    <ModalUsuario
      :modalUsuario.sync="modalUsuario"
      @modalUsuario:usuario-editado="UPDATE_USUARIO"
      @modalUsuario:usuario-criado="usuarioCriado"
      :usuarioEdicao.sync="usuarioSelecionado"
    />
    <ModalFilaUsuario
      :modalFilaUsuario.sync="modalFilaUsuario"
      :usuarioSelecionado.sync="usuarioSelecionado"
      :filas="filas"
      @modalFilaUsuario:sucesso="UPDATE_USUARIO"
    />
    <ModalCanalUsuario
      :modalCanalUsuario.sync="modalCanalUsuario"
      :usuarioSelecionado.sync="usuarioSelecionado"
      @modalCanalUsuario:sucesso="UPDATE_USUARIO"
    />

    <modalWavoipUsuario
      :modalWavoipUsuario.sync="modalWavoipUsuario"
      :usuarioSelecionado.sync="usuarioSelecionado"
      @modalWavoipUsuario:sucesso="UPDATE_USUARIO"
    />

  </div>
</template>

<script>
import { ListarUsuarios, DeleteUsuario } from 'src/service/user'
import { ListarFilas } from 'src/service/filas'
import ModalUsuario from './ModalUsuario'
import ModalFilaUsuario from './ModalFilaUsuario'
import ModalCanalUsuario from './ModalCanalUsuario'
import ModalWavoipUsuario from './ModalWavoipUsuario'

export default {
  name: 'IndexUsuarios',
  components: { ModalUsuario, ModalFilaUsuario, ModalCanalUsuario, ModalWavoipUsuario },
  data () {
    return {
      userProfile: 'user',
      usuarios: [],
      usuarioSelecionado: {},
      modalFilaUsuario: false,
      modalCanalUsuario: false,
      modalWavoipUsuario: false,
      filas: [],
      optionsProfile: [
        { value: 'user', label: this.$t('usuarios.profiles.user') },
        { value: 'admin', label: this.$t('usuarios.profiles.admin') },
        { value: 'supervisorfila', label: this.$t('usuarios.profiles.supervisorfila') },
        { value: 'supervisor', label: this.$t('usuarios.profiles.supervisor') }
      ],
      modalUsuario: false,
      filter: null,
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        searchParam: null,
        hasMore: true
      },
      loading: false,
      columns: [
        { name: 'isOnline', label: this.$t('usuarios.labelHashtag'), field: 'isOnline', align: 'center' },
        { name: 'id', label: this.$t('usuarios.labelId'), field: 'id', align: 'left' },
        { name: 'name', label: this.$t('usuarios.labelNome'), field: 'name', align: 'left' },
        { name: 'email', label: this.$t('usuarios.labelEmail'), field: 'email', align: 'left' },
        {
          name: 'queues',
          label: this.$t('usuarios.labelFilas'),
          field: 'queues',
          align: 'left',
          format: (v) => !v ? '' : v.map(f => f.queue).join(', '),
          classes: 'ellipsis',
          style: 'max-width: 400px;'
        },
        {
          name: 'whatsapps',
          label: this.$t('usuarios.labelCanais'),
          field: 'whatsapps',
          align: 'left',
          format: (v) => !v ? '' : v.map(w => w.name).join(', '),
          classes: 'ellipsis',
          style: 'max-width: 400px;'
        },
        {
          name: 'wavoipUsers',
          label: this.$t('usuarios.labelWavoip'),
          field: 'wavoipUsers',
          align: 'left',
          format: (v) => !v || v.length === 0 ? '' : v.map(w => w.whatsapp?.name).join(', '),
          classes: 'ellipsis',
          style: 'max-width: 400px;'
        },
        { name: 'profile', label: this.$t('usuarios.labelPerfil'), field: 'profile', align: 'left', format: (v) => this.optionsProfile.find(o => o.value == v).label },
        { name: 'acoes', label: this.$t('usuarios.labelAcoes'), field: 'acoes', align: 'center' }
      ]
    }
  },
  computed: {
    isAuthorizedUser() {
      return this.userProfile === 'admin' || this.userProfile === 'supervisor'
    }
  },
  methods: {
    LOAD_USUARIOS(users) {
      const newUsers = []
      users.forEach(user => {
        const userIndex = this.usuarios.findIndex(c => c.id === user.id)
        if (userIndex !== -1) {
          this.usuarios[userIndex] = user
        } else {
          newUsers.push(user)
        }
      })
      this.usuarios = [...this.usuarios, ...newUsers]
    },
    UPDATE_USUARIO (usuario) {
      let newUsuarios = [...this.usuarios]
      const usuarioIndex = newUsuarios.findIndex(c => c.id === usuario.id)
      if (usuarioIndex !== -1) {
        newUsuarios[usuarioIndex] = usuario
      } else {
        newUsuarios = [usuario, ...newUsuarios]
      }
      this.usuarios = [...newUsuarios]
    },
    DELETE_USUARIO (userId) {
      const newObj = [...this.usuarios.filter(u => u.id !== userId)]
      this.usuarios = [...newObj]
    },
    gerirCanaisUsuario (usuario) {
      this.usuarioSelecionado = usuario
      this.modalCanalUsuario = true
    },
    gerirWavoipUsuario (usuario) {
      this.usuarioSelecionado = usuario
      this.modalWavoipUsuario = true
    },
    async listarUsuarios () {
      this.loading = true
      try {
        const response = await ListarUsuarios(this.params)

        if (response.data && Array.isArray(response.data.users)) {
          // Reset usuarios array when loading first page
          if (this.params.pageNumber === 1) {
            this.usuarios = []
          }

          let newUsers = response.data.users

          // Filter out admin users if current user is supervisor
          if (this.userProfile === 'supervisor') {
            newUsers = newUsers.filter(user => user.profile !== 'admin')
          }

          // Update usuarios array
          this.usuarios = [...this.usuarios, ...newUsers]

          // Update pagination
          this.pagination.rowsNumber = this.userProfile === 'supervisor'
            ? response.data.users.filter(user => user.profile !== 'admin').length
            : response.data.count || 0

          this.pagination.hasMore = response.data.hasMore
        } else {
          console.error('Resposta da API não está no formato esperado:', response.data)
        }
      } catch (error) {
        console.error(this.$t('usuarios.erros'), error)
      } finally {
        this.loading = false
      }
    },
    filtrarUsuario (data) {
      this.usuarios = []
      this.params.pageNumber = 1
      this.params.searchParam = data
      this.listarUsuarios()
    },
    onScroll({ to, ref, ...all }) {
      if (!this.loading && this.params.hasMore && to >= (this.usuarios.length - 10)) {
        this.loading = true
        this.params.pageNumber++
        this.listarUsuarios()
      }
    },
    usuarioCriado (usuario) {
      const obj = [...this.usuarios]
      obj.push(usuario)
      this.usuarios = [...obj]
    },
    editarUsuario (usuario) {
      this.usuarioSelecionado = usuario
      this.modalUsuario = true
    },
    deletarUsuario (usuario) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('usuarios.confirmacaoDeletar', { name: usuario.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeleteUsuario(usuario.id)
          .then(res => {
            this.DELETE_USUARIO(usuario.id)
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: this.$t('usuarios.sucessoDeletar', { name: usuario.name }),
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
          .catch(error => {
            console.error(error)
            this.$notificarErro(this.$t('usuarios.erros'), error)
          })
        this.loading = false
      })
    },
    async listarFilas () {
      const { data } = await ListarFilas()
      this.filas = data
    },
    gerirFilasUsuario (usuario) {
      this.usuarioSelecionado = usuario
      this.modalFilaUsuario = true
    }
  },
  async created() {
    this.userProfile = localStorage.getItem('profile') || 'user'
  },
  async mounted() {
    if (this.isAuthorizedUser) {
      await Promise.all([
        this.listarFilas(),
        this.listarUsuarios()
      ])
    }
  }
}
</script>

<style lang="sass" >
.my-sticky-dynamic
  /* height or max-height is important */
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th /* bg color is important for th; just specify one */
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1
  /* this will be the loading indicator */
  thead tr:last-child th
    /* height of all previous header rows */
    top: 63px
  thead tr:first-child th
    top: 0

.heightChat
  height: calc(100vh - 50px)
  .q-table__top
    padding: 8px

#tabela-contatos-atendimento
  thead
    th
      height: 55px

.blur-effect
  filter: blur(0px)
</style>
