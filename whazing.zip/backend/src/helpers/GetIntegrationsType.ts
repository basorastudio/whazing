// Original: GetIntegrationsType.js
// Deobfuscated, converted to TS, and translated

'use strict';

import QueueIntegrations from '../models/QueueIntegrations'; // Asumiendo exportación predeterminada
import { RefreshToken } from './RefreshToken'; // Asumiendo exportación nombrada
import CheckSettingsHelper from './CheckSettingsHelper'; // Asumiendo exportación predeterminada

// Tipos inferidos
interface QueueIntegrationsInstance {
    id: number;
    type: string; // Asumiendo que type es string (ej: 'typebot', 'dialogflow')
    // otras propiedades...
}


const GetIntegrationsType = async (integrationId: number | string): Promise<string | null> => {

    // Tokens y llaves de configuración (ajustar nombres según sea necesario)
    const tokenCheckSetting = RefreshToken('90a6acde49'); // Token para verificar alguna configuración
    const tokenAllowIntegration = RefreshToken('d1a25cdd43'); // Token para verificar si la integración está permitida/habilitada
    const settingAllowIntegration = await CheckSettingsHelper(tokenAllowIntegration); // Verificar configuración de permiso

    // Si la configuración no coincide (ej: integración deshabilitada), retornar null
    if (settingAllowIntegration !== tokenCheckSetting) {
        console.warn("Integrations check failed or disabled.");
        return null;
    }

    try {
        const integration = await QueueIntegrations.findOne({
            where: { id: integrationId }
        }) as QueueIntegrationsInstance | null; // Castear tipo

        // Si se encuentra la integración, retornar su tipo
        if (integration) {
            return integration.type;
        }
        // Si no, retornar null
        return null;

    } catch (error) {
         // Traducido: Error al obtener el tipo de integración
        console.error('Error al obtener el tipo de integración:', error);
         // Traducido: Error al buscar integración
        throw new Error('Erro ao buscar integração.');
    }
};

export default GetIntegrationsType;