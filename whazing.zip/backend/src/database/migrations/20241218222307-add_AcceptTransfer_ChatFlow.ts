import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'AcceptTransfer' column to the 'ChatFlow' table
    // Flag indicating if this chat flow step accepts transfers.
    await queryInterface.addColumn(
      'ChatFlow',       // Table name
      'AcceptTransfer', // New column name (Note: Capitalization kept from original)
      {
        type: DataTypes.BOOLEAN,
        allowNull: false,   // Cannot be null
        defaultValue: true, // Default to accepting transfers (Original was true)
      }
    );
     // Original code wrapped this in Promise.all, unnecessary here.
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'AcceptTransfer' column from the 'ChatFlow' table
    await queryInterface.removeColumn(
      'ChatFlow',       // Table name
      'AcceptTransfer'  // Column name to remove
       // Original code wrapped the remove operation in Promise.all and passed the column definition again, which is incorrect for removeColumn. Corrected here.
    );
  }
};

export = migration;