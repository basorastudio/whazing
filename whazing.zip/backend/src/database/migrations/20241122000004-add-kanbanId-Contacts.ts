import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

// Exporting the migration object directly as 'exports.default' was in original deobfuscated code
const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'kanbanId' column to the 'Contacts' table
    // Links a contact to a specific Kanban column/stage.
    await queryInterface.addColumn(
      "Contacts", // Table name
      "kanbanId", // New column name
      {
        type: DataTypes.INTEGER,
        allowNull: true, // Allow null (contact might not be in Kanban)
        defaultValue: null
        // Consider adding references: { model: 'Kanbans', key: 'id' }, onDelete: 'SET NULL' if a foreign key is intended
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'kanbanId' column from the 'Contacts' table
    await queryInterface.removeColumn(
      "Contacts", // Table name
      "kanbanId" // Column name to remove
    );
  }
};

export = migration; // Using standard export for consistency
