import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'tenantId' column to the 'KanbanOrders' table as a foreign key
    await queryInterface.addColumn(
      'KanbanOrders', // Table name
      'tenantId',     // New column name
      {
        type: DataTypes.INTEGER,
        allowNull: false, // Cannot be null
        references: {
          model: 'Tenants', // References Tenants table
          key: 'id',
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Delete orders if Tenant is deleted
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'tenantId' column from the 'KanbanOrders' table
    await queryInterface.removeColumn(
      'KanbanOrders', // Table name
      'tenantId'      // Column name to remove
    );
  }
};

export = migration;