import { QueryInterface, DataTypes, Sequelize } from 'sequelize'; // Added Sequelize
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'Schedules' table for scheduled messages/actions
    await queryInterface.createTable(
      'Schedules', // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
          allowNull: false,
        },
        body: { // Message body
          type: DataTypes.TEXT,
          allowNull: true,
        },
        sendAt: { // Scheduled time to send
          type: DataTypes.DATE,
          allowNull: true,
        },
        sentAt: { // Actual time sent (null if not sent yet)
          type: DataTypes.DATE,
          allowNull: true,
        },
        contactId: {
          type: DataTypes.INTEGER,
          references: { model: 'Contacts', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL', // Keep schedule even if contact is deleted?
        },
        ticketId: {
          type: DataTypes.INTEGER,
          references: { model: 'Tickets', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL', // Keep schedule even if ticket is deleted?
        },
        userId: { // User who scheduled it
          type: DataTypes.INTEGER,
          references: { model: 'Users', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL',
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: { model: 'Tenants', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL', // Or CASCADE?
        },
        whatsappId: { // Connection to use for sending
          type: DataTypes.INTEGER,
          references: { model: 'Whatsapps', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL', // Or CASCADE?
        },
        status: { // Status (e.g., 'pending', 'sent', 'failed')
          type: DataTypes.STRING,
          allowNull: true,
        },
        mediaPath: { // Path to scheduled media
          type: DataTypes.STRING,
          allowNull: true,
        },
        mediaName: { // Original name of scheduled media
          type: DataTypes.STRING,
          allowNull: true,
        },
        Tunel: { // Unclear purpose, kept from original. 'Tunnel'? Boolean flag?
          type: DataTypes.BOOLEAN,
          defaultValue: false,
          allowNull: false,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'),
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'),
        },
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'Schedules' table
    await queryInterface.dropTable('Schedules');
  }
};

export = migration;