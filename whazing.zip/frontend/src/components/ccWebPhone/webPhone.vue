<template>
  <div
    v-show="isOpen"
    class="webphone-container-ios absolute-top-left flex flex-center z-top"
    :key="keyWebPhone"
  >
    <q-page-sticky position="top-right" :offset="fabPos">
      <div class="relative-position" v-touch-pan.prevent.mouse="moveCall">
        <div class="close-btn-container">
          <q-btn round flat color="neutral" icon="close" @click="handleClose" />
        </div>

        <div class="cwebphone">
          <div class="webphone-ios">
            <div class="status-text">
              {{ callInfo.status !== "accept" ? $t('wavoipdiscador.status') + callStatus : formattedDuration }}
            </div>

            <Thumbnail
              v-if="username && callInfo.status !== 'offer'"
              :src="getProfilePicture"
              :username="username"
              size="40px"
              status="online"
              variant="circle"
              class="user-thumbnail"
            />

            <div
              class="webphone-details q-pa-xs"
              v-if="callInfo.status === 'offer'"
            >
              <div class="phone-number" v-if="shouldShowTelInput">{{ callInfo.phone }}</div>
              <div v-if="callInfo.tag" class="tag-text">
                {{ callInfo.tag.substring(0, 20) }}
              </div>
              <div class="button-container">
                <q-btn
                  class="accept-call-btn"
                  round
                  @click="doAcceptCall"
                  color="positive"
                  :disable="isCallEndDisabled"
                  icon="phone_in_talk"
                >
                  <q-tooltip>{{ $t('wavoipdiscador.aceitar') }}</q-tooltip>
                </q-btn>
                <q-btn
                  class="reject-call-btn"
                  round
                  :disable="isCallEndDisabled"
                  @click="doRejectCall"
                  color="negative"
                  icon="cancel"
                >
                  <q-tooltip>{{ $t('wavoipdiscador.rejeitar') }}</q-tooltip>
                </q-btn>
              </div>
            </div>

            <div v-else>
              <div class="input-container">
                <div class="phone-number" v-if="phoneNumber && shouldShowTelInput">{{ formatId(phoneNumber) }}</div>
              </div>

              <div class="action-buttons q-my-md">
                <q-btn
                  round
                  @click="call"
                  :color="callInfo.status == 'accept' ? 'grey' : 'green'"
                  icon="call"
                  class="call-btn"
                  :disable="!phoneNumber || callInfo.status == 'accept'"
                >
                  <q-tooltip>{{ $t('wavoipdiscador.chamar') }}</q-tooltip>
                </q-btn>
                <q-btn
                  round
                  @click="hangUp"
                  color="negative"
                  icon="call_end"
                  class="end-call-btn"
                  :disable="isCallEndDisabled"
                >
                  <q-tooltip>{{ $t('wavoipdiscador.desligar') }}</q-tooltip>
                </q-btn>
                <q-btn
                  round
                  @click="isMuted ? unMute() : mute()"
                  :icon="isMuted ? 'volume_off' : 'volume_up'"
                  class="mute-btn"
                  :disable="callInfo.status !== 'accept'"
                >
                  <q-tooltip>{{ isMuted ? $t('wavoipdiscador.desmutar') : $t('wavoipdiscador.mutar') }}</q-tooltip>
                </q-btn>
              </div>

            </div>
          </div>
        </div>
      </div>
    </q-page-sticky>
  </div>
</template>

<script>
import { ListarWavoipUsuario } from 'src/service/user'
import { CriarLogWavoip } from 'src/service/wavoip'
import Thumbnail from './Thumbnail.vue'
import { mapGetters, mapMutations } from 'vuex'
import SoundCalling from 'src/assets/sounds/calling.mp3'
import SoundRinging from 'src/assets/sounds/ring.mp3'
import formatSerializedId from 'src/utils/phoneFormatter'

export default {
  name: 'cWebPhone',
  components: { Thumbnail },
  props: {
    openWebPhone: { type: Boolean, required: true },
    pWebPhoneNumber: { type: String, default: () => '' },
    pticketId: { type: [Number, String], required: false },
    pcontactId: { type: [Number, String], required: false },
    pcontactName: { type: String, required: false, default: () => '' },
    pprofile_picture: { type: String, required: false, default: () => '' }
  },
  data() {
    return {
      userProfile: 'user',
      HideNumber: null,
      keyWebPhone: 0,
      callingSound: null,
      ringSound: null,
      phoneNumber: this.pWebPhoneNumber,
      isOpen: this.openWebPhone,
      elapsedTime: 0,
      timer: null,
      isMuted: false,
      draggingFab: false,
      fabPos: [18, 180],
      keyPressData: { key: null, count: 0, lastPressTime: 0 }
    }
  },
  computed: {
    ...mapGetters({
      uiFlags: 'webphone/getUIFlags',
      callInfo: 'webphone/getCallInfo',
      inboxes: 'whatsapps',
      wavoip: 'webphone/getWavoip'
    }),
    cWhatsapps() {
      return this.inboxes || []
    },
    shouldShowTelInput() {
      return this.userProfile === 'admin' ||
        this.userProfile === 'supervisor' ||
        !this.HideNumber
    },
    username() {
      return (
        this.callInfo.tag ||
        this.callInfo.contact_name ||
        this.callInfo.phone ||
        ''
      )
    },
    getProfilePicture() {
      return (
        this.callInfo.profile_picture ||
        this.pprofile_picture ||
        'user-profile-avatar.png'
      )
    },
    callStatus() {
      switch (this.callInfo.status) {
        case 'outcoming_calling':
          return this.$t('wavoipdiscador.ligando')
        case 'offer':
          return this.$t('wavoipdiscador.chamando')
        case 'call-start':
          return this.$t('wavoipdiscador.ligando')
        case 'terminate':
          return this.$t('wavoipdiscador.finalizada')
        default:
          return this.$t('wavoipdiscador.nao_identificado')
      }
    },
    isCallEndDisabled() {
      return [
        'terminate',
        'reject',
        'accept_elsewhere',
        'reject_elsewhere'
      ].includes(this.callInfo.status)
    },
    formattedDuration() {
      const totalSeconds = this.elapsedTime
      const hours = Math.floor(totalSeconds / 3600)
      const minutes = Math.floor((totalSeconds % 3600) / 60)
      const seconds = totalSeconds % 60
      return [
        hours > 0 ? String(hours).padStart(2, '0') : '00',
        String(minutes).padStart(2, '0'),
        String(seconds).padStart(2, '0')
      ].join(':')
    }
  },
  watch: {
    // uiFlags(newUiIFlags) {
    //   // console.log("newUiIFlags", newUiIFlags);
    //   this.isOpen = newUiIFlags.isOpen;
    // },
    uiFlags: {
      handler: function (newUiIFlags) {
        this.isOpen = newUiIFlags.isOpen
      },
      deep: true
    },
    callInfo(newCallInfo, oldCallInfo) {
      this.phoneNumber = newCallInfo.phone
      const status = newCallInfo.status
      const oldStatus = oldCallInfo.status

      localStorage.setItem('wavo_call_info', JSON.stringify(newCallInfo))

      if (status === oldStatus) {
        return
      }
      // console.log('status', status)
      if (status === 'accept') {
        this.startTimer()
        CriarLogWavoip(this.callInfo)
      } else if (status === 'terminate') {
        this.stopTimer()
        CriarLogWavoip(this.callInfo)
        this.handleCloseNotify()
      }
      if (status === 'outcoming_calling') {
        CriarLogWavoip(this.callInfo)
        this.playCalling()
      } else {
        this.stopCalling()
      }
      if (status === 'offer') {
        this.handlerPlayAudio()
      } else {
        this.stopRinging()
      }
    },
    async inboxes(newInboxes) {
      for (const inbox of newInboxes) {
        if (inbox.wavoip) {
          try {
            const response = await ListarWavoipUsuario(inbox.id)

            if (response.data.result === true) {
              this.startWavoip(inbox.name, inbox.wavoip)
            }
          } catch (error) {
            console.error('Error fetching Wavoip user:', error)
          }
        }
      }
    },
    pWebPhoneNumber(newValue) {
      this.phoneNumber = newValue
    },
    openWebPhone(newValue) {
      this.isOpen = newValue
    },
    $route: {
      handler(newPath, oldPath) {
        setTimeout(() => {
          // Reset states or handle the route change
          let pos
          const strPos = localStorage.getItem('webphone_position')
          if (strPos) {
            try {
              pos = JSON.parse(strPos)
            } catch (e) {
              pos = [18, 180]
            }
          } else pos = [18, 180]
          this.fabPos = pos
        }, 2000)
      },
      immediate: true
    }
  },
  methods: {
    ...mapMutations('webphone', ['SET_WEBPHONE_CALL']),
    handlerPlayAudio() {
      const options = {
        body: this.$t('wavoipdiscador.novochamada'),
        icon: this.callInfo.picture_profile
      }
      const notification = new Notification(
        this.$t('wavoipdiscador.mensagem_de', { contact: this.callInfo.tag || this.callInfo.phone }),
        options
      )

      notification.onclick = (e) => {
        this.isOpen = true
        this.playRinging()
      }
    },

    doAcceptCall() {
      this.$store.dispatch('webphone/acceptCall')
    },
    doRejectCall() {
      this.stopRinging()
      this.$store.dispatch('webphone/rejectCall')
    },
    formatId(id) {
      const formattedId = formatSerializedId(id)
      return formattedId
    },
    startTimer() {
      if (this.timer) {
        clearInterval(this.timer)
      }
      const startDate = this.$store.state.webphone.call.active_start_date
      this.timer = setInterval(() => {
        const now = new Date()
        this.elapsedTime = Math.floor((now - startDate) / 1000)
      }, 1000)
    },
    stopTimer() {
      clearInterval(this.timer)
      this.timer = null
      this.elapsedTime = 0
    },
    playCalling() {
      this.callingSound = new Audio(SoundCalling)
      this.callingSound.loop = true
      this.callingSound.play()
    },
    stopCalling() {
      if (this.callingSound) {
        this.callingSound.pause()
        this.callingSound.currentTime = 0
      }
    },
    playRinging() {
      this.ringSound = new Audio(SoundRinging)
      this.ringSound.loop = true
      this.ringSound.play()
    },
    stopRinging() {
      if (this.ringSound) {
        this.ringSound.pause()
        this.ringSound.currentTime = 0
      }
    },

    async hangUp() {
      // console.log(`Chamada para ${this.phoneNumber} terminada.`);
      if (this.callInfo.status === 'offer') {
        this.$store.dispatch('webphone/rejectCall')
      } else this.$store.dispatch('webphone/endCall')
    },
    moveCall(ev) {
      this.draggingFab = ev.isFirst !== true && ev.isFinal !== true

      this.fabPos = [this.fabPos[0] - ev.delta.x, this.fabPos[1] + ev.delta.y]
      localStorage.setItem('webphone_position', JSON.stringify(this.fabPos))
    },
    startWavoip(inboxName, token) {
      if (token.includes(',')) {
        const tokens = token.split(',').map(t => t.trim()).filter(t => t)

        tokens.forEach(singleToken => {
          this.$store.dispatch('webphone/startWavoip', {
            token: singleToken,
            inboxName
          })
        })
      } else {
        this.$store.dispatch('webphone/startWavoip', {
          token,
          inboxName
        })
      }
    },
    handleClose() {
      this.$emit('update:modelValue', false)
      this.isOpen = false
      this.$store.dispatch('webphone/updateWebphoneVisible', { isOpen: false })
    },
    handleCloseNotify() {
      this.$emit('update:modelValue', false)
      this.isOpen = false
      this.$store.dispatch('webphone/updateWebphoneVisible', { isOpen: false })

      this.$q.notify({
        type: 'warn',
        progress: true,
        position: 'top',
        actions: [{
          icon: 'close',
          round: true,
          color: 'white'
        }],
        message: this.$t('wavoipdiscador.finalizada'),
        timeout: 10000
      })
    },
    async call() {
      const phone = this.phoneNumber
      const contactId = this.pcontactId || ''
      const contactName = this.pcontactName || ''
      const profilePicture = this.pprofile_picture || ''
      const ticketId = this.pticketId

      const availableTokens = Object.keys(this.$store.getters['webphone/getWavoip'])

      if (availableTokens.length === 0) {
        this.$q.notify({
          type: 'warn',
          message: this.$t('wavoipdiscador.erroefetuando'),
          actions: [{ icon: 'close', round: true, color: 'white' }]
        })
        return
      }

      let notificationShown = false

      let callSuccessful = false

      for (let i = 0; i < availableTokens.length && !callSuccessful; i++) {
        const token = availableTokens[i]
        try {
          await this.$store.dispatch('webphone/outcomingCall', {
            contact_id: contactId,
            contact_name: contactName,
            profile_picture: profilePicture,
            phone: phone,
            ticket_id: ticketId,
            token: token,
            freezeToken: true
          })

          callSuccessful = true
          console.log('Chamada bem-sucedida com token')

          localStorage.setItem('last_successful_token', token)

          break
        } catch (error) {
          console.log(`Call with token ${token} failed:`, error)

          if (i === availableTokens.length - 1 && !callSuccessful && !notificationShown) {
            notificationShown = true

            // Determina qual mensagem de erro mostrar
            if (error.message === 'Numero não existe') {
              this.$q.notify({
                type: 'warn',
                position: 'top',
                message: this.$t('wavoipdiscador.numeronaoexiste'),
                actions: [{ icon: 'close', round: true, color: 'white' }]
              })
            } else if (error.message.includes('Linha ocupada')) {
              this.$q.notify({
                type: 'warn',
                position: 'top',
                message: this.$t('wavoipdiscador.linhaocupada'),
                actions: [{ icon: 'close', round: true, color: 'white' }]
              })
            } else if (error.message === 'Limite de ligações atingido') {
              this.$q.notify({
                type: 'warn',
                position: 'top',
                message: this.$t('wavoipdiscador.limiteatingido'),
                actions: [{ icon: 'close', round: true, color: 'white' }]
              })
            } else {
              this.$q.notify({
                type: 'warn',
                position: 'top',
                message: this.$t('wavoipdiscador.erroefetuando'),
                actions: [{ icon: 'close', round: true, color: 'white' }]
              })
            }
          }
        }
      }
    },
    async mute() {
      try {
        await this.$store.dispatch('webphone/mute', {
          token: this.callInfo.id
        })
      } catch (error) {
        console.error('[*] - Error to mute', error)
      }
    },

    async unMute() {
      try {
        await this.$store.dispatch('webphone/unMute', {
          token: this.callInfo.id
        })
      } catch (error) {
        console.error('[*] - Error to mute', error)
      }
    },
    useSound(sound) {
      const audio = new Audio(sound)
      audio.loop = false
      return audio
    },
    async listarConfiguracoes() {
      const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))
      const HideNumberConfig = configuracoes?.find(c => c.key === 'HideNumber')
      if (HideNumberConfig) {
        this.HideNumber = HideNumberConfig.value === 'enabled'
      }
    }
  },
  created() {},
  mounted() {
    this.userProfile = localStorage.getItem('profile')
    this.listarConfiguracoes()
    let pos
    const strPos = localStorage.getItem('webphone_position')
    if (strPos) {
      try {
        pos = JSON.parse(strPos)
      } catch (e) {
        pos = [18, 180]
      }
    } else pos = [18, 180]
    this.fabPos = pos

    window.onbeforeunload = (event) => {
      event.preventDefault()
      event.stopImmediatePropagation()
      event.returnValue = true
      localStorage.setItem('wavo_call_info', JSON.stringify(this.callInfo))
    }

    const locWavo = localStorage.getItem('wavo_call_info')
    const wavoInfo = JSON.parse(
      !locWavo || locWavo == 'undefined' ? '{}' : locWavo
    )
    if (wavoInfo?.id) {
      // wavoStore.call = { ...wavoStore.call, ...wavoInfo };
      this.SET_WEBPHONE_CALL(wavoInfo)

      if (['offer', 'accept'].includes(wavoInfo.call?.status)) {
        this.isOpen = false
        this.$store.dispatch('webphone/updateWebphoneVisible', {
          isOpen: true
        })
      }
    }
  },
  beforeDestroy() {
    window.onbeforeunload = null
    // Cleanup logic if needed
  }
}
</script>

<style lang="scss" scoped>

.cwebphone {
  text-align: center;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    "Helvetica Neue", Arial, sans-serif;
  color: #2c3e50;
}

.webphone-ios {
  width: 350px;
  margin: 0 auto;
  border: none;
  border-radius: 20px;
  padding: 15px;
  background: #f2f2f7; /* iOS light mode background */
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.header .title {
  font-weight: 600;
  margin-bottom: 20px;
}

.status-text {
  margin: 10px 0;
  color: #636366; /* iOS gray text */
  font-size: 14px;
}

.user-thumbnail {
  margin: 10px 0;
}

.webphone-details {
  margin-top: 15px;
}

.phone-number {
  font-weight: bold;
  color: #1c1c1e;
  font-size: 16px;
}

.tag-text {
  font-size: 14px;
  color: #3a3a3c;
}

.button-container {
  display: flex;
  justify-content: space-around;
  margin-top: 10px;
}

.accept-call-btn,
.reject-call-btn {
  width: 60px;
  height: 60px;
  font-size: 18px;
}

.input-container {
  position: relative;
  margin-top: 15px;
}

.phone-input {
  width: 100%;
  padding: 12px;
  border-radius: 12px;
  border: 1px solid #ddd;
  font-size: 16px;
  background-color: #fefefe;
  box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
}

.clear-icon {
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
  cursor: pointer;
  color: #ff9500; /* Warning Orange */
}

.action-buttons {
  display: flex;
  justify-content: center;
  gap: 15px;
}

.call-btn {
  background-color: #34c759; /* iOS Green */
}

.end-call-btn {
  background-color: #ff3b30; /* iOS Red */
}

.call-btn[disabled] {
  background-color: #8e8e93; /* Gray for Disabled */
}

.keypad {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 10px;
}

.keypad-button {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background-color: #fff;
  color: #007aff; /* iOS Blue */
  border: 2px solid #007aff;
  font-size: 18px;
  transition: background-color 0.2s, color 0.2s;
}

.keypad-button:hover {
  background-color: #007aff;
  color: #fff;
}

.keypad-button-content {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.keypad-number {
  font-weight: bold;
}

.keypad-letters {
  font-size: 12px;
}

.close-btn-container {
  position: absolute;
  top: 10px;
  right: 10px;
}

@media (max-width: 420px) {
  .webphone-ios {
    width: 90%;
  }

  .keypad-button {
    width: 48px;
    height: 48px;
  }
}
</style>

<style lang="sass" scoped>
.cblink-web
  animation: blink 3s linear infinite

.cweb-opacity
  opacity: 1

@keyframes blink
 0%
  opacity: 0
  background: red
 50%
  opacity: .5
  background: blue
 100%
  opacity: 1
  background: green
</style>
