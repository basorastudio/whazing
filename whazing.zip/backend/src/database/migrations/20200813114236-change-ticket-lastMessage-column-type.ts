import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Cambia el tipo de la columna lastMessage a TEXT
    return queryInterface.changeColumn("Tickets", "lastMessage", {
      type: DataTypes.TEXT
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Revierte el cambio, volviendo al tipo STRING (tipo original)
    return queryInterface.changeColumn("Tickets", "lastMessage", {
      type: DataTypes.STRING
    });
  }
};
