<template>
  <q-dialog persistent :value="modalPlanPersonalizado" @hide="fecharModal" @show="abrirModal">
    <q-card class="container-rounded-10 modal-container q-pa-lg">
      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          Crear Plan Personalizado
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <div class="container-border container-rounded-10">
        <q-card-section class="row flex-gap-1 q-col-gutter-sm">
          <div class="text-h6 font-family-main">
            Personaliza tu Plan
          </div>
          <div class="flex-gap-1 full-width row q-col-gutter-sm">
            <div class="full-width">
              <c-input rounded outlined v-model="planPersonalizado.name" label="Nombre del Plan" />
            </div>
            
            <!-- Usuarios -->
            <div class="full-width">
              <q-slider
                v-model="planPersonalizado.maxUsers"
                :min="1"
                :max="50"
                label
                label-always
                color="primary"
                @change="calcularPrecio"
              >
                <template v-slot:label>
                  <div class="text-center">
                    Usuarios Máximos: {{ planPersonalizado.maxUsers }}
                  </div>
                </template>
              </q-slider>
            </div>

            <!-- Conexiones -->
            <div class="full-width">
              <q-slider
                v-model="planPersonalizado.maxConnections"
                :min="1"
                :max="20"
                label
                label-always
                color="primary"
                @change="calcularPrecio"
              >
                <template v-slot:label>
                  <div class="text-center">
                    Conexiones Máximas: {{ planPersonalizado.maxConnections }}
                  </div>
                </template>
              </q-slider>
            </div>

            <!-- Características -->
            <div class="full-width q-pa-md">
              <div class="text-subtitle1 q-mb-sm">Características Adicionales:</div>
              <div class="row q-gutter-sm">
                <q-checkbox
                  v-model="planPersonalizado.group"
                  label="Grupos"
                  @update:model-value="calcularPrecio"
                />
                <q-checkbox
                  v-model="planPersonalizado.campaign"
                  label="Campañas"
                  @update:model-value="calcularPrecio"
                />
                <q-checkbox
                  v-model="planPersonalizado.integrations"
                  label="Integraciones"
                  @update:model-value="calcularPrecio"
                />
              </div>
            </div>

            <!-- Precio Calculado -->
            <div class="full-width q-pa-md text-center">
              <div class="text-h5 text-primary">
                Precio Estimado: RD$ {{ precioFormateado }}
              </div>
              <div class="text-caption q-mt-sm">
                El precio se calcula en base a las características seleccionadas
              </div>
            </div>
          </div>
        </q-card-section>
      </div>

      <q-card-actions align="right">
        <q-btn
          label="Cancelar"
          class="q-px-md q-mr-sm btn-rounded-50"
          color="negative"
          v-close-popup
        />
        <q-btn
          label="Crear Plan"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          icon="eva-save-outline"
          @click="handlePlanPersonalizado"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { CriarPlano } from '../../../service/plans'

export default {
  name: 'PlanPersonalizado',
  props: {
    modalPlanPersonalizado: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      planPersonalizado: {
        name: null,
        maxUsers: 1,
        maxConnections: 1,
        value: 0,
        isPublic: false,
        group: false,
        campaign: false,
        integrations: false
      },
      precios: {
        baseUsuario: 50,      // Precio por usuario
        baseConexion: 100,     // Precio por conexión
        grupo: 200,            // Precio por tener grupos
        campana: 300,          // Precio por tener campañas
        integracion: 400       // Precio por tener integraciones
      }
    }
  },
  computed: {
    precioFormateado() {
      return this.planPersonalizado.value.toFixed(2).replace('.', ',')
    }
  },
  methods: {
    calcularPrecio() {
      let precioTotal = 0

      // Calcular precio por usuarios
      precioTotal += this.planPersonalizado.maxUsers * this.precios.baseUsuario

      // Calcular precio por conexiones
      precioTotal += this.planPersonalizado.maxConnections * this.precios.baseConexion

      // Agregar precios por características adicionales
      if (this.planPersonalizado.group) precioTotal += this.precios.grupo
      if (this.planPersonalizado.campaign) precioTotal += this.precios.campana
      if (this.planPersonalizado.integrations) precioTotal += this.precios.integracion

      this.planPersonalizado.value = precioTotal
    },
    async handlePlanPersonalizado() {
      try {
        await CriarPlano(this.planPersonalizado)
        this.$q.notify({
          type: 'positive',
          message: 'Plan personalizado creado con éxito'
        })
        this.$emit('hide')
        this.$emit('planoCreated')
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: 'Error al crear el plan personalizado'
        })
      }
    },
    fecharModal() {
      this.$emit('hide')
    },
    abrirModal() {
      this.planPersonalizado = {
        name: null,
        maxUsers: 1,
        maxConnections: 1,
        value: 0,
        isPublic: false,
        group: false,
        campaign: false,
        integrations: false
      }
      this.calcularPrecio()
    }
  }
}
</script>