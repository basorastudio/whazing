import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert informative settings into the 'SettingsGeneral' table
    // Translated 'O sistema passara por manutenção dia' to Spanish.
    // Using raw query for multiple inserts. Table name might need schema prefix.
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('textinformative', 'El sistema pasará por mantenimiento día', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('colorinformative', '#f50000', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('informative', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted settings from 'SettingsGeneral' table
    await queryInterface.bulkDelete(
      "SettingsGeneral", // Adjust schema if needed
      {
        key: ["textinformative", "colorinformative", "informative"] // Delete rows with these keys
      }
    );
  }
};

export = migration;
