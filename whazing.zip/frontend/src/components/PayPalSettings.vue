<template>
  <div class="paypal-settings q-pa-md">
    <q-card class="settings-card">
      <q-card-section>
        <div class="text-h6 q-mb-md">Configuración de PayPal</div>
        <q-form @submit="saveSettings" class="q-gutter-md">
          <div class="row q-col-gutter-md">
            <div class="col-12">
              <q-toggle
                v-model="settings.sandbox"
                label="Modo Sandbox"
                color="primary"
                class="q-mb-md"
              >
                <q-tooltip>Habilitar modo de pruebas de PayPal</q-tooltip>
              </q-toggle>
            </div>

            <div class="col-12">
              <q-input
                v-model="settings.clientId"
                label="Client ID"
                :type="showSecrets ? 'text' : 'password'"
                outlined
                :rules="[val => !!val || 'Client ID es requerido']"
                lazy-rules
                class="settings-input"
              >
                <template v-slot:append>
                  <q-icon
                    :name="showSecrets ? 'visibility_off' : 'visibility'"
                    class="cursor-pointer"
                    @click="showSecrets = !showSecrets"
                  />
                </template>
                <q-tooltip>ID de cliente proporcionado por PayPal</q-tooltip>
              </q-input>
            </div>

            <div class="col-12">
              <q-input
                v-model="settings.clientSecret"
                label="Client Secret"
                :type="showSecrets ? 'text' : 'password'"
                outlined
                :rules="[val => !!val || 'Client Secret es requerido']"
                lazy-rules
                class="settings-input"
              >
                <template v-slot:append>
                  <q-icon
                    :name="showSecrets ? 'visibility_off' : 'visibility'"
                    class="cursor-pointer"
                    @click="showSecrets = !showSecrets"
                  />
                </template>
                <q-tooltip>Clave secreta proporcionada por PayPal</q-tooltip>
              </q-input>
            </div>

            <div class="col-12">
              <q-input
                v-model="settings.webhookId"
                label="Webhook ID"
                :type="showSecrets ? 'text' : 'password'"
                outlined
                :rules="[val => !!val || 'Webhook ID es requerido']"
                lazy-rules
                class="settings-input"
              >
                <template v-slot:append>
                  <q-icon
                    :name="showSecrets ? 'visibility_off' : 'visibility'"
                    class="cursor-pointer"
                    @click="showSecrets = !showSecrets"
                  />
                </template>
                <q-tooltip>ID del Webhook para notificaciones de PayPal</q-tooltip>
              </q-input>
            </div>

            <div class="col-12">
              <q-input
                v-model="settings.webhookUrl"
                label="URL del Webhook"
                outlined
                readonly
                class="settings-input"
              >
                <template v-slot:append>
                  <q-btn
                    flat
                    round
                    icon="content_copy"
                    @click="copyWebhookUrl"
                  >
                    <q-tooltip>Copiar URL</q-tooltip>
                  </q-btn>
                </template>
                <q-tooltip>URL para recibir notificaciones de PayPal. Mantenga esta URL actualizada y segura.</q-tooltip>
              </q-input>
            </div>

            <div class="col-12">
              <q-toggle
                v-model="settings.allowCardPayments"
                label="Aceptar pagos con tarjeta"
                color="primary"
                class="q-mb-md"
              >
                <q-tooltip>Permitir pagos con tarjeta sin cuenta de PayPal</q-tooltip>
              </q-toggle>
            </div>
            <div class="col-12">
              <div class="text-subtitle2 q-mb-sm">Tipos de Eventos</div>
              <q-option-group
                v-model="settings.eventTypes"
                :options="eventTypeOptions"
                type="checkbox"
                class="event-types-group"
              />
            </div>
          </div>

          <div class="row justify-end q-mt-md">
            <q-btn
              type="submit"
              color="primary"
              label="Guardar"
              :loading="saving"
              icon="save"
            />
          </div>
        </q-form>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
import { api } from '../service/api';

export default {
  name: 'PayPalSettings',

  data() {
    return {
      settings: {
        sandbox: false,
        clientId: '',
        clientSecret: '',
        webhookId: '',
        webhookUrl: '',
        eventTypes: ['all'],
        allowCardPayments: true
      },
      showSecrets: false,
      saving: false,
      eventTypeOptions: [
        { label: 'Todos los Eventos', value: 'all', description: 'Suscribirse a todos los eventos futuros' },
        { label: 'Pago', value: 'checkout', description: 'Eventos relacionados con pagos' },
        { label: 'Disputa del Cliente', value: 'customer_dispute', description: 'Eventos de disputas y reclamos' },
        { label: 'Pagos y Desembolsos', value: 'payments_payouts', description: 'Eventos de procesamiento de pagos' },
        { label: 'Reembolsos', value: 'refunds', description: 'Eventos de reembolsos de pagos' }
      ]
    };
  },

  created() {
    this.loadSettings();
  },

  methods: {
    async loadSettings() {
      try {
        const { data } = await api.get('/paypal/settings');
        this.settings = {
          sandbox: data.sandbox,
          clientId: data.clientId,
          clientSecret: data.clientSecret,
          webhookId: data.webhookId
        };
      } catch (error) {
        console.error('Error al cargar la configuración:', error);
        this.$q.notify({
          type: 'negative',
          message: 'Error al cargar la configuración de PayPal',
          position: 'top',
          timeout: 3000
        });
      }
    },

    async saveSettings() {
      this.saving = true;
      try {
        await api.post('/paypal/settings', this.settings);
        this.$q.notify({
          type: 'positive',
          message: 'Configuración guardada exitosamente',
          position: 'top',
          timeout: 3000,
          icon: 'check_circle'
        });
      } catch (error) {
        console.error('Error al guardar la configuración:', error);
        this.$q.notify({
          type: 'negative',
          message: 'Error al guardar la configuración de PayPal',
          position: 'top',
          timeout: 3000,
          icon: 'error'
        });
      } finally {
        this.saving = false;
      }
    },

    async copyWebhookUrl() {
      try {
        await navigator.clipboard.writeText(this.settings.webhookUrl);
        this.$q.notify({
          type: 'positive',
          message: 'URL copiada al portapapeles',
          position: 'top',
          timeout: 2000
        });
      } catch (error) {
        console.error('Error al copiar URL:', error);
        this.$q.notify({
          type: 'negative',
          message: 'Error al copiar URL',
          position: 'top',
          timeout: 2000
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.paypal-settings {
  max-width: 800px;
  margin: 0 auto;

  .settings-card {
    border-radius: 8px;
    box-shadow: 0 1px 5px rgba(0, 0, 0, 0.2);
  }

  .settings-input {
    .q-field__control {
      height: 56px;
    }
  }

  .q-toggle {
    .q-toggle__label {
      font-size: 16px;
    }
  }

  .event-types-group {
    max-height: 400px;
    overflow-y: auto;
    padding-right: 16px;

    .q-option-group {
      gap: 8px;
    }
  }
}
</style>