import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'lastSeen' column to the 'Users' table
    await queryInterface.addColumn(
      "Users", // Table name
      "lastSeen", // New column name
      {
        type: DataTypes.DATE,
        allowNull: true // Allow null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'lastSeen' column from the 'Users' table
    await queryInterface.removeColumn(
      "Users", // Table name
      "lastSeen" // Column name to remove
    );
  }
};

export = migration;
