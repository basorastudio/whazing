import { Request, Response } from 'express';
import { getIO } from '../libs/socket'; // Asumiendo ruta correcta
import AppError from '../errors/AppError';
import UpdateSettingService from '../services/SettingServices/UpdateSettingService';
import ListSettingsService from '../services/SettingServices/ListSettingsService';
import GetAllPublicSettingsService from '../services/SettingServices/GetAllPublicSettingsService';

interface UserRequest extends Request {
    user?: {
        id: string | number;
        profile: string;
        // otras propiedades del usuario si existen
    };
}

interface UpdateSettingBody {
    value: string; // o any, dependiendo de lo que pueda ser
    key: string;
}

export const index = async (req: Request, res: Response): Promise<Response> => {
    const settings = await ListSettingsService();
    return res.status(200).json(settings);
};

export const update = async (req: UserRequest, res: Response): Promise<Response> => {
    // Verifica si el usuario es administrador
    if (req.user?.profile !== 'admin') {
        throw new AppError('ERR_NO_PERMISSION', 403); // "ERR_SIN_PERMISO"
    }

    const { value, key }: UpdateSettingBody = req.body;

    const settingData = { key, value };
    const setting = await UpdateSettingService(settingData);

    // Emite evento a través de socket.io
    const io = getIO();
    // Asegurar que la emisión es correcta, el original tenía `emit('tenantId:settings', ...)`
    // Si 'tenantId' es variable, necesitaría obtenerse (ej. req.user.tenantId)
    // Asumiendo que es un canal general 'settings' por ahora.
    io.emit('settings', { // Ajustar el nombre del evento si es necesario
        action: 'update',
        setting: setting
    });

    return res.status(200).json(setting);
};

export const publicShow = async (req: Request, res: Response): Promise<Response> => {
    const publicSettings = await GetAllPublicSettingsService();
    return res.status(200).json(publicSettings);
};