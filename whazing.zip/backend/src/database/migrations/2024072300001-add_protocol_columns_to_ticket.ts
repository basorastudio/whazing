import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: async (queryInterface: QueryInterface, sequelize: Sequelize) => {
    await queryInterface.addColumn("Tickets", "protocol", {
      type: DataTypes.STRING,
      allowNull: true // Permitir nulos, ya que se está añadiendo a una tabla existente
      // defaultValue: null // Opcional: explícitamente establecer el valor por defecto
    });
  },

  down: async (queryInterface: QueryInterface, sequelize: Sequelize) => {
    await queryInterface.removeColumn("Tickets", "protocol");
  }
};
