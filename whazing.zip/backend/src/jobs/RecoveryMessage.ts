import { getWbot } from "../libs/wbot";
import { BufferJSON, proto } from "@whiskeysockets/baileys"; // Assuming Baileys types
import { handleMessage as handleMessageListener } from "../services/WbotServices/wbotMessageListener"; // Renamed to avoid conflict
import Message from "../models/Message"; // Assuming default export
import { FindOptions, WhereOptions } from "sequelize";

// Define interfaces for the data structures
interface RecoveryData {
  message: proto.IWebMessageInfo;
  whatsappId: number;
  isImported?: boolean;
  tenantId: number | string; // Likely needed if Message model uses it
}

interface Job {
  data: RecoveryData;
  attemptsMade?: number;
}

interface BackoffOptions {
  type: string;
  delay: number;
}

interface HandleOptions {
  delay: number;
  attempts: number;
  removeOnComplete: boolean;
  removeOnFail: boolean;
  backoff: BackoffOptions;
}

const backoffOptions: BackoffOptions = {
  type: "fixed",
  delay: 30000 // 0x7530
};

const handleOptions: HandleOptions = {
  delay: 600, // 0x258
  attempts: 5,
  removeOnComplete: true,
  removeOnFail: false, // Original: ![]
  backoff: backoffOptions
};

// Constants
const MAX_CHECK_ATTEMPTS = 5; // From original code (i variable)
const CHECK_RETRY_DELAY = 20000; // From original code (await new Promise timeout)

export const RecoveryMessage = {
  key: "RecoveryMessage",
  options: handleOptions,
  async handle({ data, attemptsMade = 0 }: Job): Promise<boolean> {
    const logPrefix = "RecoveryMessage";
    const { message: messageData, whatsappId, isImported, tenantId } = data; // Extract tenantId

    if (!messageData?.key?.id) {
      console.error(`${logPrefix}: Error fatal - Mensaje sin ID de clave.`);
      return false; // Cannot proceed without message ID
    }

    const messageKey = messageData.key;
    const messageId = messageKey.id;
    console.log(
      `${logPrefix}: Iniciando recuperación para mensaje: ${messageId}`
    );

    try {
      const wbot = getWbot(whatsappId);

      // Helper function to check if message exists in DB
      const checkMessageExists = async (): Promise<boolean> => {
        const where: WhereOptions = {
          messageId: messageId,
          tenantId: tenantId, // Add tenantId to the check
          whatsappId: whatsappId // Add whatsappId
        };
        const findOptions: FindOptions = { where };
        const existingMessageCount = await Message.count(findOptions);
        return existingMessageCount > 0;
      };

      // Helper function to retry an async operation
      const retryOperation = async (
        operationName: string,
        operationFn: () => Promise<any>,
        maxAttempts: number = MAX_CHECK_ATTEMPTS,
        delay: number = CHECK_RETRY_DELAY
      ): Promise<boolean> => {
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
          console.log(
            `${logPrefix}: ${operationName}: Intento ${attempt}/${maxAttempts}`
          );
          try {
            await operationFn();
            console.log(
              `${logPrefix}: ${operationName}: Intento ${attempt} exitoso.`
            );
            if (await checkMessageExists()) {
              console.log(
                `${logPrefix}: Mensaje ${messageId} encontrado en la base de datos después de ${operationName}.`
              );
              return true; // Success, message found
            }
            console.log(
              `${logPrefix}: Mensaje ${messageId} NO encontrado después de ${operationName} intento ${attempt}.`
            );
          } catch (error: any) {
            console.error(
              `${logPrefix}: ${operationName}: Error en intento ${attempt}:`,
              error?.message
            );
          }
          if (attempt < maxAttempts) {
            await new Promise(resolve => setTimeout(resolve, delay));
          }
        }
        console.log(
          `${logPrefix}: ${operationName}: No se encontró el mensaje ${messageId} después de ${maxAttempts} intentos.`
        );
        return false; // Failed to find message after retries
      };

      // --- Recovery Strategy ---

      // Strategy 1: Use messageStubParameters (reviver) - If available
      const messageStubParameters = messageData.messageStubParameters;
      if (messageStubParameters && messageStubParameters.length > 0) {
        console.log(
          `${logPrefix}: Intentando recuperación usando messageStubParameters.`
        );
        const found = await retryOperation(
          "ParseAndFetchWithMessageStubParameters",
          async () => {
            // The original BufferJSON.parse might be specific to how Baileys handles these stubs.
            // This requires understanding Baileys internals or finding the equivalent operation.
            // Assuming 'reviver' is needed for parsing complex objects within the JSON string.
            // This part is highly dependent on the actual content of messageStubParameters.
            const parsedParams = JSON.parse(
              messageStubParameters[0],
              BufferJSON.reviver
            );
            // Assuming parsedParams contain necessary info for fetchMessagesFromWA
            // This is speculative based on the original code's structure
            await wbot.fetchMessagesFromWA(
              messageKey.remoteJid!,
              1,
              parsedParams
            ); // Example: Fetch 1 message using parsed params
          }
        );
        if (found) return true;
      }

      // Strategy 2: Use requestPlaceholder (fetchMessagesFromWA) - Generic fetch
      console.log(
        `${logPrefix}: Intentando recuperación usando requestPlaceholder (fetchMessagesFromWA).`
      );
      const foundWithPlaceholder = await retryOperation(
        "FetchWithRequestPlaceholder",
        async () => {
          await wbot.fetchMessagesFromWA(messageKey.remoteJid!, 1, messageKey); // Fetch using the message key itself
        }
      );
      if (foundWithPlaceholder) return true;

      // Strategy 3: Use fetchMessageHistory (fetchMessageHistory) - History fetch
      console.log(
        `${logPrefix}: Intentando recuperación usando fetchMessageHistory.`
      );
      const foundWithHistory = await retryOperation(
        "FetchWithMessageHistory",
        async () => {
          await wbot.fetchMessageHistory(messageKey.remoteJid!, 10, messageKey); // Fetch recent history around the key
        }
      );
      if (foundWithHistory) return true;

      // Strategy 4: Fallback to standard message handling
      console.log(
        `${logPrefix}: Ningún método de recuperación encontró el mensaje ${messageId}. Procediendo con el manejo estándar.`
      );
      await handleMessageListener(wbot, messageData, whatsappId, isImported);
      return true; // Consider standard handling a success in terms of job completion
    } catch (error: any) {
      console.error(
        `${logPrefix}: Error fatal durante la recuperación del mensaje ${messageId}:`,
        error
      );
      // Optionally log detailed error or send to Sentry
      // Sentry.captureException(error, { extra: { messageId, whatsappId, tenantId, jobAttempts: attemptsMade } });
      return false; // Indicate failure
    }
  }
};
