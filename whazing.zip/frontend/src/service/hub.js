import request from 'src/service/request'

export function AdicionarHub (data) {
  return request({
    url: '/hub-channel/',
    method: 'post',
    data
  })
}

export function ListarHub () {
  return request({
    url: '/hub-channel/',
    method: 'get'
  })
}

export function SincronizarTemplates (whatsappId) {
  return request({
    url: `/hub-message/synctemplate/${whatsappId}`,
    method: 'get'
  })
}

export function ListarCategoriasTemplates (whatsappId) {
  return request({
    url: `/hub-message/templatecategories/${whatsappId}`,
    method: 'get'
  })
}

export function ListarTemplates (whatsappId, category) {
  return request({
    url: `/hub-message/templateby-category/${whatsappId}/${category}`,
    method: 'get'
  })
}

export function EnviarMensagemTemplate (ticketId, templateData) {
  return request({
    url: `/hub-message/templatesend/${ticketId}`,
    method: 'post',
    data: templateData
  })
}
