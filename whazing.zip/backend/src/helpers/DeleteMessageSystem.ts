// Original: DeleteMessageSystem.js
// Deobfuscated, converted to TS, and translated

'use strict';

import { differenceInHours, parseJSON } from 'date-fns';
import Message from '../models/Message';
import Ticket from '../models/Ticket';
import { getTbot } from '../libs/tbot'; // Asumiendo exportación nombrada
import AppError from '../errors/AppError';
import { getIO } from '../libs/socket'; // Asumiendo exportación nombrada
import { getWbot } from '../libs/wbot'; // Asumiendo exportación nombrada
import { WAMessage, WASocket } from '@whiskeysockets/baileys'; // Importar tipos de Baileys
import { Telegraf } from 'telegraf'; // Importar tipo Telegraf

// Tipos inferidos para modelos
interface MessageInstance extends Message {
  ticket?: TicketInstance;
  contact?: ContactInstance; // Asumiendo que puede tener contacto
}

interface TicketInstance extends Ticket {
  contact?: ContactInstance;
  whatsapp?: WhatsappInstance; // Asumiendo que puede tener whatsapp
}

interface ContactInstance {
    id: number;
    number: string;
    // otras propiedades...
}

interface WhatsappInstance {
    id: number;
    // otras propiedades...
}

const DeleteMessageSystem = async (
  messageId: string,
  channel?: string, // Canal es opcional ya que se usa el del ticket
  tenantId?: number | string // Hacer tenantId opcional
): Promise<void> => {

  const message = await Message.findOne({
    where: { id: messageId, tenantId: tenantId },
    include: [
      {
        model: Ticket,
        as: 'ticket',
        include: ['contact', 'whatsapp'] // Incluir whatsapp
      }
    ]
  }) as MessageInstance | null; // Castear tipo

  if (!message) {
     // Traducido: No se encontró mensaje con este ID.
    throw new AppError('No message found with this ID.');
  }

  const { ticket } = message;

  if (!ticket) {
      // Esto no debería ocurrir si la relación está bien definida, pero por si acaso
      throw new AppError('Ticket associated with the message not found.');
  }


  // Verificar si el mensaje puede ser borrado (ej: dentro de 2 horas) - Lógica Baileys
  if (ticket.channel === 'whatsapp') { // Solo aplicar la lógica de tiempo para WhatsApp (Baileys)
    const diffHours = differenceInHours(new Date(), parseJSON(message?.createdAt));
    if (diffHours > 2) {
       // Traducido: Error: No se puede eliminar el mensaje después de 2 horas de ser enviado
      console.log(`Error: Cannot delete message after 2 hours of being sent`);
      throw new AppError(`Cannot delete message after 2 hours of being sent`);
    }
  }


  // Si messageId es null y el estado es pendiente (mensaje programado no enviado?)
  if (message.messageId === null && message.status === 'pending') {
    await message.destroy();
     // Traducido: Mensaje programado eliminado de la base de datos.
    console.log(`Scheduled message deleted from the database.`);
    return;
  }

  // Lógica específica por canal
  if (ticket.channel === 'whatsapp' && message.messageId) {
      if (!ticket.whatsappId) {
           throw new AppError('WhatsApp ID not found on the ticket.');
      }
      const wbot = getWbot(ticket.whatsappId) as WASocket; // Castear a WASocket
      const messageToDelete = JSON.parse(message.dataJson) as WAMessage; // Parsear y castear

       if (messageToDelete.key && messageToDelete.key.remoteJid) {
            await wbot.sendMessage(messageToDelete.key.remoteJid, { delete: messageToDelete.key });
       } else {
            console.warn("Could not delete message from WhatsApp: key or remoteJid missing in dataJson");
       }


  } else if (ticket.channel === 'telegram' && message.messageId) {
       if (!ticket.whatsappId) { // Asumiendo que whatsappId guarda el ID de la conexión de Telegram
           throw new AppError('Telegram connection ID not found on the ticket.');
       }
       const tbot = getTbot(ticket.whatsappId) as Telegraf<any>; // Castear a Telegraf
       if (ticket.contact?.number && message.messageId) {
            await tbot.telegram.deleteMessage(ticket.contact.number, +message.messageId);
       } else {
           console.warn("Could not delete message from Telegram: contact number or messageId missing");
       }

  } else if (ticket.channel === 'instagram') {
    // Lógica para Instagram (si es necesario)
    console.warn('Instagram delete functionality not implemented.');
  } else if (ticket.channel === 'messenger') {
    // Lógica para Messenger (si es necesario)
    console.warn('Messenger delete functionality not implemented.');
  }

  // Actualizar el mensaje en la base de datos como eliminado
  await message.update({ isDeleted: true });

  const io = getIO();
  // Emitir evento de socket para actualizar la UI
  io.to(`tenant:${tenantId}:ticket:${ticket.id}`)
    .emit(`tenant:${tenantId}:appMessage`, { // Evento consistente
      action: 'update', // O 'delete' si prefieres
      message: message,
      ticket: ticket,
      contact: ticket.contact
  });

  // Emitir también al canal general del tenant si es necesario
  io.to(`tenant:${tenantId}:messages`)
      .emit(`tenant:${tenantId}:appMessage`, {
          action: 'update', // O 'delete'
          message: message,
          ticket: ticket,
          contact: ticket.contact
      });

};

export default DeleteMessageSystem;