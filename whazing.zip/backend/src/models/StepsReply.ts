import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  HasMany, // Added for relation
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import User from "./User";
import AutoReply from "./AutoReply";
import StepsReplyAction from "./StepsReplyAction"; // Assuming relation exists

@Table({ freezeTableName: true })
class StepsReply extends Model<StepsReply> {
  @PrimaryKey
  @AutoIncrement // Assuming AutoIncrement
  @Column
  id: number; // Assuming numeric ID

  @Column(DataType.TEXT)
  reply: string;

  @Default(false)
  @Column(DataType.BOOLEAN)
  initialStep: boolean; // 'initialStep' resolved

  @ForeignKey(() => AutoReply)
  @Column
  idAutoReply: number; // 'idAutoReply' resolved, assuming FK to AutoReply

  @BelongsTo(() => AutoReply, "idAutoReply") // Specify FK
  autoReply: AutoReply;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @HasMany(() => StepsReplyAction) // Assuming relation exists
  stepsReplyAction: StepsReplyAction[]; // 'stepsReplyAction' resolved
}

export default StepsReply;