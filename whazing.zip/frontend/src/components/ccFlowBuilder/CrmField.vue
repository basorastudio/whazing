<template>
  <div>
    <q-card flat
            class="q-pa-sm q-pb-md">
      <q-card-section class="q-pa-none">
        <div class="text-subtitle2 q-mb-sm">
          {{ $t('ccFlowBuilder.addcrm') }}
        </div>
        <div class="flex flex-inline full-width items-center">
          <div class="flex flex-inline text-left"
               style="width: 40px">
          </div>
          <q-select
            ref="inputEnvioMensagem"
            style="height: 10vh; flex: auto"
            square
            borderless
            :value="$attrs.element.data.crm"
            class="q-pa-sm bg-white"
            autogrow
            dense
            outlined
            emit-value
            @input="(v) => $attrs.element.data.crm = v"
            :options="kanbans.map(crm => ({label: crm.name, value: crm.id}))"
          />
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
import { ListarKanbans } from 'src/service/kanban'

export default {
  name: 'CrmField',
  data () {
    return {
      kanbans: []
    }
  },
  mounted() {
    this.listarKanbans()
  },
  methods: {
    async listarKanbans () {
      const { data } = await ListarKanbans({ showAll: true })
      this.kanbans = data
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
