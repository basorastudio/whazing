import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import User from "./User";
import StepsReply from "./StepsReply";
import Queue from "./Queue";

@Table({ freezeTableName: true })
class StepsReplyAction extends Model<StepsReplyAction> { // Renamed class
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number; // Assuming numeric ID

  @ForeignKey(() => StepsReply)
  @Column
  stepReplyId: number; // 'stepReplyId' resolved, assuming FK to StepsReply

  @BelongsTo(() => StepsReply, "stepReplyId") // Specify FK
  stepsReply: StepsReply; // Relation name

  @Column(DataType.TEXT)
  words: string; // Assuming TEXT for potentially multiple words

  @AllowNull(true)
  @Default(null)
  @Column(DataType.INTEGER) // Assuming numeric ID for next step
  nextStepId: number | null;

  @ForeignKey(() => StepsReply) // Self-referencing FK for next step
  @Column
  idNextStep: number | null; // Alternative FK name? Check schema

  @BelongsTo(() => StepsReply, 'nextStepId') // Or use 'idNextStep' if correct
  nextStep: StepsReply | null;

  @Column
  action: number; // Assuming numeric action code

  @ForeignKey(() => User)
  @Column
  userIdDestination: number | null; // 'userIdDestination' resolved, nullable

  @BelongsTo(() => User, "userIdDestination") // Explicit FK
  userDestination: User | null; // 'userDestination' resolved

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @ForeignKey(() => Queue)
  @Column(DataType.INTEGER) // Assuming integer queue ID
  queueId: number | null;

  @BelongsTo(() => Queue)
  queue: Queue | null;

  @AllowNull(true) // Added based on likely usage
  @Default(null)
  @Column(DataType.STRING) // Added based on likely usage
  replyDefinition: string; // 'replyDefinition' resolved

}

export default StepsReplyAction; // Exporting renamed class