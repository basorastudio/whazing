import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'oficial' column to the 'Campaigns' table
    // Flag indicating if the campaign uses an official WhatsApp API connection.
    await queryInterface.addColumn(
      "Campaigns", // Table name
      "oficial", // New column name
      {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false // Original had false
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'oficial' column from the 'Campaigns' table
    await queryInterface.removeColumn(
      "Campaigns", // Table name
      "oficial" // Column name to remove
    );
  }
};

export = migration;
