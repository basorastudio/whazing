<template>
  <q-dialog
    title="Ayuda"
    v-model="dialogVisible"
    width="70%"
    customClass="flowHelp"
  >
    <el-tabs tab-position="left">
      <el-tab-pane label="Cómo añadir">
        <el-divider content-position="left">Cómo añadir</el-divider>
        <div>Mantenga presionado el ratón y arrastre el componente desde la izquierda hasta el lienzo central, luego suelte el ratón</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo eliminar">
        <el-divider content-position="left">Eliminación de página</el-divider>
        <div>
          Haga clic en el nodo que desea eliminar, luego haga clic en el ícono de eliminar en la esquina superior izquierda
        </div>
        <el-divider content-position="left">Eliminar a través del código</el-divider>
        <pre>this.deleteNode(nodeId)</pre>
      </el-tab-pane>
      <el-tab-pane label="Cómo mover">
        <el-divider content-position="left">Cómo mover</el-divider>
        <div>Mueva el ratón al nodo, cuando el cursor cambie al ícono de arrastrar, presione el ratón y muévalo a una nueva posición, luego suéltelo</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo conectar líneas">
        <el-divider content-position="left">Cómo conectar líneas</el-divider>
        <div>Mueva el ratón al ícono del lado izquierdo del nodo, cuando el cursor cambie a +, presione el ratón y muévalo a otro nodo, luego suéltelo</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo añadir condiciones">
        <el-divider content-position="left">Cómo añadir condiciones</el-divider>
        <div>Haga clic en la línea de conexión en el lienzo, aparecerá un formulario en el lado derecho de la página, ingrese la nueva condición y haga clic en [Guardar]</div>
      </el-tab-pane>
      <el-tab-pane label="Cómo realizar el almacenamiento en interacción con el backend">
        <el-divider content-position="left">Cómo realizar el almacenamiento en interacción con el backend</el-divider>
        <div>Referencia: https://gitee.com/xiaoka2017/easy-flow-sdk</div>
      </el-tab-pane>
    </el-tabs>
  </q-dialog>
</template>

<script>
export default {
  data () {
    return {
      dialogVisible: false
    }
  },
  components: {},
  methods: {
    init () {
      this.dialogVisible = true
    }
  }
}
</script>

<style>
.flowHelp {
  height: 80%;
}
</style>
