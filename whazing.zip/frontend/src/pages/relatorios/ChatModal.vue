<template>
  <q-dialog v-model="showModal" persistent>
    <q-card :style="modalStyle">

      <!-- Historial de mensajes -->
      <q-card-section class="chat-history" id="modal-content">
        <!-- Información del contacto en la parte superior -->
        <q-card-section>
          <div class="contact-info">
            <strong>Ticket:</strong> {{ ticketId }}<br />
          </div>
        </q-card-section>

        <!-- Botón para cargar más mensajes en la parte superior, si hasMore es true -->
        <div v-if="hasMore" class="load-more-container">
          <q-btn label="Cargando" @click="carregarMensagens(ticketId, pageNumber + 1)" />
        </div>

        <div v-if="mensagens.length" class="messages-container">
          <div
            v-for="mensagem in mensagensOrdenadas"
            :key="mensagem.id"
            class="chat-message"
            :class="{
  'from-me': mensagem.fromMe && mensagem.mediaType !== 'note',
  'from-them': !mensagem.fromMe && mensagem.mediaType !== 'note',
  'note-highlight': mensagem.mediaType === 'note'
}"

          >
            <div class="message-meta">
              <q-icon class="q-ma-xs"
                      name="mdi-calendar"
                      size="18px"
                      :class="{
                  'text-primary': mensagem.scheduleDate && mensagem.status === 'pending',
                  'text-positive': !['pending', 'canceled'].includes(mensagem.status)
                }"
                      v-if="mensagem.scheduleDate">
                <q-tooltip content-class="bg-secondary text-grey-8">
                  <div class="row col">
                    Mensaje programado
                  </div>
                  <div class="row col"
                       v-if="mensagem.isDeleted">
                    <q-chip color="red-3"
                            icon="mdi-trash-can-outline">
                      Envío cancelado: {{ formatarData(mensagem.updatedAt, 'dd/MM/yyyy') }}
                    </q-chip>
                  </div>
                  <div class="row col">
                    <q-chip color="blue-1"
                            icon="mdi-calendar-import">
                      Enviado en: {{ formatarData(mensagem.createdAt, 'dd/MM/yyyy HH:mm') }}
                    </q-chip>
                  </div>
                  <div class="row col">
                    <q-chip color="blue-1"
                            icon="mdi-calendar-start">
                      Programado en: {{ formatarData(mensagem.scheduleDate, 'dd/MM/yyyy HH:mm') }}
                    </q-chip>
                  </div>
                </q-tooltip>
              </q-icon>
              <div v-if="mensagem.sendType && mensagem.sendType.startsWith('user:')" class="bot-message">
                <q-icon name="mdi-account" size="18px" class="q-mr-xs" color="white"/>
                <span class="bot-label">{{ mensagem.sendType.replace('user: ', '') }}</span>
              </div>
              <div v-if="mensagem.sendType === 'Campaign'" class="bot-message">
                <q-icon name="mdi-bullhorn" size="18px" class="q-mr-xs" color="white"/>
                <span class="bot-label">Campaña</span>
              </div>
              <div v-if="mensagem.sendType === 'bot'" class="bot-message">
                <q-icon name="mdi-robot" size="18px" class="q-mr-xs" color="white"/>
                <span class="bot-label">BOT</span>
              </div>
              <div v-if="mensagem.sendType === 'typebot'" class="bot-message">
                <q-icon name="mdi-robot" size="18px" class="q-mr-xs" color="white"/>
                <span class="bot-label">TypeBot</span>
              </div>
              <div v-if="mensagem.sendType === 'openai'" class="bot-message">
                <q-icon name="mdi-robot" size="18px" class="q-mr-xs" color="white"/>
                <span class="bot-label">ChatGPT</span>
              </div>
              <div v-if="mensagem.sendType === 'groq'" class="bot-message">
                <q-icon name="mdi-robot" size="18px" class="q-mr-xs" color="white"/>
                <span class="bot-label">Groq</span>
              </div>
              <div v-if="mensagem.sendType === 'deepseek'" class="bot-message">
                <q-icon name="mdi-robot" size="18px" class="q-mr-xs" color="white"/>
                <span class="bot-label">DeepSeek</span>
              </div>
              <div v-if="mensagem.sendType === 'API'" class="bot-message">
                <q-icon name="mdi-api" size="18px" class="q-mr-xs" color="white"/>
              </div>
              <div v-if="mensagem.isForwarded" class="forwarded-message">
                <i class="fa fa-share"></i>
                Mensaje reenviado
              </div>&nbsp;&nbsp;
              <span>{{ formatarData(mensagem.createdAt) }}</span>
            </div>
            <div class="message-body">
              <template v-if=" mensagem.mediaType === 'audio' ">
                <div style="width: 330px; heigth: 300px">
                  <audio class="q-mt-md full-width"
                         controls
                         ref="audioMessage"
                         controlsList="download playbackrate volume">
                    <source :src=" mensagem.mediaUrl "
                            type="audio/mp3" />
                  </audio>
                </div>
              </template>
              <template v-if=" mensagem.mediaType === 'contactMessage' ">
                <div style="min-width: 250px;">
                  <ContatoCard
                    :mensagem="mensagem"
                    @openContactModal="openContactModal"
                  />
                  <ContatoModal
                    :value="modalContato"
                    :contact="currentContact"
                    @close="closeModal"
                    @saveContact="saveContact"
                  />
                </div>
              </template>
              <template v-if="mensagem.mediaType === 'locationMessage'">
                <q-img
                  @click="openGoogleMaps(mensagem.body)"
                  :src="getMapThumbnail(mensagem.body)"
                  spinner-color="primary"
                  height="150px"
                  width="330px"
                  class="q-mt-md"
                  style="cursor: pointer"
                />
              </template>
              <template v-if="mensagem.mediaType === 'liveLocationMessage'">
                <q-img
                  @click="openGoogleMaps(mensagem.body)"
                  :src="getMapThumbnail(mensagem.body)"
                  spinner-color="primary"
                  height="150px"
                  width="330px"
                  class="q-mt-md"
                  style="cursor: pointer"
                />
                <div style="color: red;">*Todavía no es posible mostrar la ubicación en tiempo real en este dispositivo. Abra WhatsApp en su celular para verlo correctamente.</div>
              </template>
              <template v-if="mensagem.mediaType === 'interactiveMessage'">
                <div style="color: red;">*No es posible mostrar este mensaje en este dispositivo. Abra WhatsApp en su celular para ver el mensaje.</div>
              </template>
              <template v-if="mensagem.mediaType === 'pollCreationMessageV3'">
                <div style="color: red;">*No es posible mostrar este mensaje en este dispositivo. Abra WhatsApp en su celular para ver el mensaje.</div>
              </template>
              <template v-if="mensagem.mediaType === 'productMessage'">
                <div style="color: red;">*No es posible mostrar este mensaje en este dispositivo. Abra WhatsApp en su celular para ver el mensaje.</div>
              </template>
              <template v-if="mensagem.mediaType === 'note'">
                <div v-html="formatarNota(mensagem.body)"></div>
              </template>
              <template v-if="mensagem.mediaType === 'image'">
                <div style="position: relative; width: 100%; max-width: 200px; overflow: hidden;">
                  <img @click="urlMedia = mensagem.mediaUrl; abrirModalImagem = true"
                       :src="mensagem.mediaUrl"
                       style="width: 100%; height: auto; object-fit: contain; cursor: pointer; display: block;"
                       class="q-mt-md" />
                </div>
                <VueEasyLightbox moveDisabled
                                 :visible="abrirModalImagem"
                                 :imgs="urlMedia"
                                 :index="mensagem.ticketId || 1"
                                 @hide="abrirModalImagem = false" />
              </template>
              <template v-if="mensagem.mediaType === 'video'">
                <div style="position: relative; width: 100%; max-width: 330px; height: auto;">
                  <video :src="mensagem.mediaUrl"
                         controls
                         ref="videoElement"
                         style="width: 100%; height: auto; object-fit: contain; border-radius: 8px; max-height: 400px;">
                  </video>
                </div>
              </template>
              <template v-if="mensagem.mediaType === 'buttonsMessage'">
                <div style="margin-top:20px" v-html="formatarBotaoWhatsapp(mensagem.body)"></div>
              </template>
              <template v-if="mensagem.mediaType === 'listMessage'">
                <div style="margin-top:20px" v-html="formatarBotaoWhatsapp(mensagem.body)"></div>
              </template>
              <template v-if=" !['audio', 'vcard', 'image', 'video'].includes(mensagem.mediaType) && mensagem.mediaUrl ">
                <div class="text-center full-width hide-scrollbar no-scroll">
                  <iframe v-if=" isPDF(mensagem.mediaUrl) "
                          frameBorder="0"
                          scrolling="no"
                          style="
                    width: 330px;
                    height: 150px;
                    overflow-y: hidden;
                    -ms-overflow-y: hidden;
                  "
                          class="no-scroll hide-scrollbar"
                          :src=" mensagem.mediaUrl "
                          id="frame-pdf">
                    Descargue el PDF
                    <!-- alt : <a href="mensagem.mediaUrl"></a> -->
                  </iframe>
                  <q-btn type="a"
                         :color=" $q.dark.isActive ? '' : 'grey-3' "
                         no-wrap
                         no-caps
                         stack
                         dense
                         class="q-mt-sm text-center text-black btn-rounded  text-grey-9 ellipsis no-print"
                         download
                         :target=" isPDF(mensagem.mediaUrl) ? '_blank' : '' "
                         :href=" mensagem.mediaUrl ">
                    <q-tooltip v-if=" mensagem.mediaUrl "
                               content-class="text-bold">
                      Descargar: {{ formatMediaName(mensagem.mediaName) }}
                    </q-tooltip>
                    <div class="row items-center q-ma-xs ">
                      <div class="ellipsis col-grow q-pr-sm"
                           style="max-width: 290px">
                        {{ formatMediaName(mensagem.mediaName) }}
                      </div>
                      <q-icon name="mdi-download" />
                    </div>
                  </q-btn>
                </div>
              </template>
              <div v-linkified
                   v-if=" !['note', 'listMessage', 'buttonsMessage', 'productMessage', 'contactMessage', 'locationMessage', 'liveLocationMessage', 'interactiveMessage', 'pollCreationMessageV3'].includes(mensagem.mediaType) "
                   :class=" { 'q-mt-sm': mensagem.mediaType !== 'chat' } "
                   class="q-message-container row items-end no-wrap">
                <div v-html=" formatarMensagemWhatsapp(mensagem.body) ">
                </div>
              </div>
            </div>
          </div>
        </div>
        <div v-else>
          <p>Cargando.</p>
        </div>
      </q-card-section>

      <!-- Botón para cerrar el chat -->
      <q-card-actions align="right">
        <q-btn icon="print" label="Imprimir" class="q-mr-sm" color="black" @click="imprimirModal" />
        <q-btn label="Cerrar" color="negative" @click="closeModal" />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { LocalizarMensagensPDF } from 'src/service/tickets'
import mixinCommon from '../atendimento/mixinCommon'
import ContatoCard from '../atendimento/ContatoCard.vue'
import ContatoModal from '../atendimento/ContatoModal.vue'
import VueEasyLightbox from 'vue-easy-lightbox'
export default {
  mixins: [mixinCommon],
  props: {
    ticketId: {
      type: [String, Number],
      required: true
    }
  },
  data () {
    return {
      showModal: true,
      mensagens: [],
      pageNumber: 1,
      hasMore: true,
      abrirModalImagem: false
    }
  },
  computed: {
    modalStyle () {
      return {
        minWidth: '70vw',
        maxWidth: '70vw',
        minHeight: '60vh',
        maxHeight: '80vh'
      }
    },
    // Ordena los mensajes por fecha (del más antiguo al más reciente)
    mensagensOrdenadas () {
      return this.mensagens.slice().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
    }
  },
  components: {
    VueEasyLightbox,
    ContatoCard,
    ContatoModal
  },
  methods: {
    imprimirModal() {
      const modalContent = document.getElementById('modal-content')
      if (!modalContent) {
        console.error('Error: No se pudo localizar el contenido del modal.')
        return
      }

      // Clonar el contenido del modal para manipulación
      const clonedContent = modalContent.cloneNode(true)

      // Reemplazar medios por marcadores
      const mediaElements = clonedContent.querySelectorAll('audio, video, img, iframe')
      mediaElements.forEach(element => {
        const placeholder = document.createElement('div')
        placeholder.style.fontStyle = 'italic'
        placeholder.style.color = '#666'

        if (element.tagName === 'AUDIO') {
          placeholder.textContent = '[Audio no visible en la impresión]'
        } else if (element.tagName === 'VIDEO') {
          placeholder.textContent = '[Video no visible en la impresión]'
        } else if (element.tagName === 'IMG') {
          placeholder.textContent = '[Imagen no visible en la impresión]'
        } else if (element.tagName === 'IFRAME') {
          placeholder.textContent = '[Documento no visible en la impresión]'
        }

        element.parentNode.replaceChild(placeholder, element)
      })

      // Crear una nueva ventana de impresión
      const printWindow = window.open('', '_blank', 'width=800,height=600')
      if (printWindow) {
        printWindow.document.write(`
      <html>
        <head>
          <title>Imprimir</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              margin: 20px;
            }
            .message-body {
              padding: 10px;
              border-radius: 8px;
              max-width: 100%;
              word-wrap: break-word;
            }
            .chat-history {
              max-height: auto;
              overflow-y: visible;
            }
            .chat-message {
              padding: 10px;
              border-radius: 10px;
              max-width: 100%;
              margin-bottom: 10px;
            }
            .from-me {
              background-color: #007bff;
              color: white;
            }
            .from-them {
              background-color: #f1f1f1;
              color: black;
            }
            .note-highlight {
              background-color: #fff200;
              color: black;
            }
            .message-meta {
              font-size: 0.8em;
              margin-bottom: 5px;
            }
            @media print {
  .no-print {
    display: none !important;
  }
}
          </style>
        </head>
        <body>
          ${clonedContent.outerHTML}
        </body>
      </html>
    `)
        printWindow.document.close()
        printWindow.focus()
        printWindow.print()
        printWindow.close()
      } else {
        console.error('Error al abrir la ventana de impresión.')
      }
    },
    getMapThumbnail(body) {
      const [thumbnail] = body.split('|')
      return thumbnail
    },
    openGoogleMaps(body) {
      const [, mapLink] = body.split('|')
      window.open(mapLink, '_blank')
    },
    isPDF (url) {
      if (!url) return false
      const split = url.split('.')
      const ext = split[split.length - 1]
      return ext === 'pdf'
    },
    removePort (url) {
      if (!url) return url
      return url.replace(/:443/, '')
    },
    async carregarMensagens (ticketId, pageNumber = 1) {
      try {
        // Bucle para paginar hasta que no haya más páginas (hasMore == false)
        while (this.hasMore) {
          const { data } = await LocalizarMensagensPDF({ ticketId: String(ticketId), pageNumber })

          if (data && data.messages.length > 0) {
            // Filtrar solo los mensajes con el ticketId correcto
            const mensagensFiltradas = data.messages.filter(m => m.ticketId === Number(ticketId))

            // Si encontró algún mensaje, agrega al array de mensajes
            if (mensagensFiltradas.length > 0) {
              this.mensagens = [...this.mensagens, ...mensagensFiltradas]
            }
          }

          // Actualizar el estado de hasMore e incrementar el pageNumber
          this.hasMore = data.hasMore

          // Incrementar el pageNumber independientemente de si se encontraron mensajes o no
          pageNumber++

          // En caso de no tener más páginas para cargar
          if (!this.hasMore) {
            break
          }
        }
      } catch (error) {
        console.error('Error al cargar mensajes:', error)
      }
    },
    formatarData (data) {
      return new Date(data).toLocaleString()
    },
    closeModal () {
      this.showModal = false
      this.$emit('close')
    }
  },
  mounted () {
    this.carregarMensagens(this.ticketId)
  }
}
</script>

<style scoped>
.message-body {
  padding: 10px;
  border-radius: 8px;
  max-width: 100%;
  word-wrap: break-word;
}

.image-container {
  margin-top: 10px;
  text-align: center;
}

.message-media {
  max-width: 100%;
  border-radius: 8px;
  margin-top: 5px;
}
/* Ajustes visuales generales */
.q-dialog {
  min-width: 70vw;
  max-width: 70vw;
  min-height: 60vh;
  max-height: 80vh;
}

.contact-info {
  font-size: 1.2em;
  margin-bottom: 10px;
}

/* Estilos para el historial de mensajes */
.chat-history {
  display: flex;
  flex-direction: column;
  max-height: 60vh;
  overflow-y: auto;
}

/* Container de los mensajes */
.messages-container {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

/* Estilos para mensajes */
.chat-message {
  padding: 10px;
  border-radius: 10px;
  max-width: 60%;
  word-wrap: break-word;
  font-size: 1em;
}

/* Mensajes enviados por el usuario (derecha) */
.from-me {
  background-color: #007bff;
  color: white;
  align-self: flex-end;
}

/* Mensajes enviados por el cliente (izquierda) */
.from-them {
  background-color: #f1f1f1;
  color: black;
  align-self: flex-start;
}

.note-highlight {
  background-color: #fff200;
  color: black;
  align-self: flex-end;
}

/* Metadatos del mensaje (remitente y fecha) */
.message-meta {
  display: flex;
  justify-content: space-between;
  font-size: 0.8em;
  margin-bottom: 5px;
}

.bot-message {
  display: flex;
  align-items: center;
  font-size: 12px;
  color: #ffffff;
  margin-bottom: 4px;

  .bot-label {
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
}

/* Cuerpo del mensaje */
.message-body {
  font-size: 1em;
  white-space: pre-wrap;
  word-break: break-word;
}

/* Botón de cargar más mensajes */
.load-more-container {
  display: flex;
  justify-content: center;
  margin-bottom: 10px;
}

/* Ajustes para el botón de cerrar */
.q-card-actions {
  margin-top: 10px;
}
</style>
