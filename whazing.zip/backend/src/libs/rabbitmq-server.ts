import {
  Channel,
  Connection,
  connect as amqpConnect,
  Message as AMQPMessage
} from "amqplib";
import { logger } from "../utils/logger"; // Adjust path as needed
import { sleepRandomTime } from "../utils/sleepRandomTime"; // Adjust path as needed

/**
 * Represents a RabbitMQ server connection and channel.
 * Provides methods for publishing and consuming messages.
 */
class RabbitmqServer {
  private conn: Connection | null = null;
  private channel: Channel | null = null;
  private uri: string;

  /**
   * Creates an instance of RabbitmqServer.
   * @param uri - The RabbitMQ connection string (e.g., 'amqp://user:pass@host:port').
   */
  constructor(uri: string) {
    this.uri = uri;
  }

  /**
   * Establishes the connection to RabbitMQ and creates a channel.
   * Asserts necessary exchanges if they don't exist.
   */
  async start(): Promise<void> {
    try {
      this.conn = await amqpConnect(this.uri);
      if (!this.conn) {
        // Add null check for connection
        throw new Error("Failed to establish RabbitMQ connection.");
      }
      this.channel = await this.conn.createChannel();
      if (!this.channel) {
        // Add null check for channel
        await this.conn.close(); // Close connection if channel creation failed
        throw new Error("Failed to create RabbitMQ channel.");
      }
      logger.info("RabbitMQ connected and channel created successfully.");

      // Example: Assert exchanges if needed (adjust names and types)
      await this.channel.assertExchange("whatsapp", "direct", {
        durable: true
      });
      await this.channel.assertExchange("messenger", "direct", {
        durable: true
      });
      await this.channel.assertExchange("waba360", "direct", { durable: true }); // Example for waba360
      logger.info("RabbitMQ exchanges asserted.");
    } catch (error) {
      logger.error("Error starting RabbitMQ connection:", error);
      // Optional: Implement retry logic here or throw to handle upstream
      throw error; // Re-throw the error after logging
    }
  }

  /**
   * Publishes a message directly to a specified queue.
   * @param queue - The name of the queue.
   * @param message - The message content (will be converted to a Buffer).
   * @returns Boolean indicating if the message was sent successfully.
   */
  async publishInQueue(queue: string, message: string): Promise<boolean> {
    if (!this.channel) {
      logger.error(
        "Cannot publish in queue: RabbitMQ channel is not available."
      );
      return false;
    }
    try {
      await this.channel.assertQueue(queue, { durable: true });
      return this.channel.sendToQueue(queue, Buffer.from(message), {
        persistent: true
      });
    } catch (error) {
      logger.error(`Error publishing to queue ${queue}:`, error);
      return false;
    }
  }

  /**
   * Publishes a message to a specified exchange with a routing key.
   * @param exchange - The name of the exchange.
   * @param routingKey - The routing key for the message.
   * @param message - The message content (will be converted to a Buffer).
   * @returns Boolean indicating if the message was published successfully.
   */
  async publishInExchange(
    exchange: string,
    routingKey: string,
    message: string
  ): Promise<boolean> {
    if (!this.channel) {
      logger.error(
        "Cannot publish to exchange: RabbitMQ channel is not available."
      );
      return false;
    }
    try {
      // Exchange should ideally be asserted during start()
      return this.channel.publish(exchange, routingKey, Buffer.from(message), {
        persistent: true
      });
    } catch (error) {
      logger.error(
        `Error publishing to exchange ${exchange} with key ${routingKey}:`,
        error
      );
      return false;
    }
  }

  /**
   * Consumes messages from a specified queue, processing them with a callback.
   * Includes random sleep time before ack/nack and basic error handling.
   * @param queue - The name of the queue to consume from.
   * @param callback - The function to process each message. Should return true on success, false on failure.
   */
  async consumeWhatsapp(
    queue: string,
    callback: (message: AMQPMessage | null) => Promise<boolean>
  ): Promise<void> {
    if (!this.channel) {
      logger.error(
        `Cannot consume from queue ${queue}: RabbitMQ channel is not available.`
      );
      return;
    }
    try {
      await this.channel.prefetch(1, false); // Process one message at a time
      await this.channel.assertQueue(queue, { durable: true });
      logger.info(`Waiting for messages in queue: ${queue}`);

      this.channel.consume(queue, async message => {
        if (!message) {
          logger.warn(`Received null message from queue ${queue}`);
          return; // Ignore null messages
        }

        try {
          const success = await callback(message); // Process the message

          // Random sleep before ack/nack to simulate processing time variance
          await sleepRandomTime({
            minMilliseconds: Number(process.env.MIN_SLEEP_INTERVAL || 100), // Default 100ms
            maxMilliseconds: Number(process.env.MAX_SLEEP_INTERVAL || 1000) // Default 1000ms
          });

          if (success) {
            this.channel?.ack(message); // Acknowledge successful processing
            // logger.debug(`Message acknowledged from queue ${queue}: ${message.content.toString()}`);
          } else {
            logger.warn(
              `Nacking message from queue ${queue} due to processing failure.`
            );
            this.channel?.nack(message, false, true); // Nack and requeue (or false to discard)
          }
        } catch (error) {
          logger.error(`Error processing message from queue ${queue}:`, error);
          try {
            // Ensure channel still exists before nacking
            this.channel?.nack(message, false, true); // Nack and requeue on error
          } catch (nackError) {
            logger.error(
              `Error nacking message after processing error in queue ${queue}:`,
              nackError
            );
          }
        }
      });
    } catch (error) {
      logger.error(`Error setting up consumer for queue ${queue}:`, error);
    }
  }

  /**
   * Generic consume method (similar to consumeWhatsapp but kept separate as in original).
   * @param queue - The queue name.
   * @param callback - The processing callback.
   */
  async consume(
    queue: string,
    callback: (message: AMQPMessage | null) => Promise<boolean>
  ): Promise<void> {
    if (!this.channel) {
      logger.error(
        `Cannot consume from queue ${queue}: RabbitMQ channel is not available.`
      );
      return;
    }
    try {
      await this.channel.assertQueue(queue, { durable: true });
      logger.info(`Waiting for messages in queue: ${queue}`);

      this.channel.consume(queue, async message => {
        if (!message) {
          logger.warn(`Received null message from queue ${queue}`);
          return;
        }
        try {
          const success = await callback(message);
          if (success) {
            this.channel?.ack(message);
          } else {
            logger.warn(
              `Nacking message from queue ${queue} (generic consumer).`
            );
            this.channel?.nack(message, false, true);
          }
        } catch (error) {
          logger.error(
            `Error processing message in generic consumer for queue ${queue}:`,
            error
          );
          try {
            this.channel?.nack(message, false, true);
          } catch (nackError) {
            logger.error(
              `Error nacking message after processing error in generic consumer for queue ${queue}:`,
              nackError
            );
          }
        }
      });
    } catch (error) {
      logger.error(
        `Error setting up generic consumer for queue ${queue}:`,
        error
      );
    }
  }
}

export default RabbitmqServer;
