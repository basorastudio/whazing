import { FindOptions } from 'sequelize'; // Asumiendo Sequelize
import AppError from '../errors/AppError'; // Asumiendo AppError path
import Whatsapp from '../models/Whatsapp'; // Asumiendo Whatsapp model path

const GetDefaultWhatsApp = async (tenantId: number | string, whatsappId?: number | string): Promise<Whatsapp> => {

    const whereOptions: any = {
        tenantId: tenantId
    };

    if (whatsappId) {
        whereOptions.id = whatsappId;
    } else {
        // Si no se proporciona whatsappId, busca el predeterminado (asumiendo que 'isDefault' es un booleano en el modelo)
        // O podrías buscar por status si 'isDefault' no existe
        whereOptions.status = 'CONNECTED'; // O busca por whereOptions.isDefault = true;
    }

    const findOptions: FindOptions = {
        where: whereOptions
    };

    const defaultWhatsapp = await Whatsapp.findOne(findOptions);

    if (!defaultWhatsapp) {
        // Ajusta el mensaje de error si la búsqueda fue por ID específico vs. predeterminado
        const errorMessage = whatsappId
            ? `ERR_WAPP_NOT_FOUND_ID ${whatsappId}` // Error específico si se buscó por ID
            : 'ERR_NO_DEFAULT_WAPP_FOUND'; // Error genérico si se buscó el predeterminado
        throw new AppError(errorMessage, 404);
    }

    return defaultWhatsapp;
};

export default GetDefaultWhatsApp;