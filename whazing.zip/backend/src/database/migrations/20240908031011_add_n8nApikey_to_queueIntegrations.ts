import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

// Exporting the migration object directly as 'exports.default' was in original deobfuscated code
const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'n8nApiKey' column to the 'QueueIntegrations' table
    await queryInterface.addColumn(
      'QueueIntegrations', // Table name
      'n8nApiKey',         // New column name
      {
        type: DataTypes.STRING,
        allowNull: true, // Allow null values
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'n8nApiKey' column from the 'QueueIntegrations' table
    await queryInterface.removeColumn(
      'QueueIntegrations', // Table name
      'n8nApiKey'          // Column name to remove
    );
  }
};

export = migration; // Using standard export for consistency