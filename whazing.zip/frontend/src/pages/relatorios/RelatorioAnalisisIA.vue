<template>
  <div>
    <div class="q-pa-md">
      <div class="row q-col-gutter-md">
        <div class="col-12">
          <q-card class="my-card">
            <q-card-section>
              <div class="text-h6">Análisis de Tickets con IA</div>
              <div class="text-subtitle2">Utiliza inteligencia artificial para analizar patrones y tendencias en tus tickets</div>
            </q-card-section>

            <q-card-section>
              <div class="row q-col-gutter-md">
                <div class="col-12 col-md-3">
                  <q-input
                    v-model="filtros.startDate"
                    filled
                    type="date"
                    label="Fecha inicial"
                  />
                </div>
                <div class="col-12 col-md-3">
                  <q-input
                    v-model="filtros.endDate"
                    filled
                    type="date"
                    label="Fecha final"
                  />
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    v-model="filtros.status"
                    :options="statusOptions"
                    filled
                    label="Estado"
                    clearable
                  />
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    v-model="filtros.queuesIds"
                    :options="queueOptions"
                    filled
                    label="Colas"
                    multiple
                    use-chips
                    clearable
                  />
                </div>
              </div>
              <div class="row q-mt-md">
                <div class="col-12">
                  <q-btn
                    color="primary"
                    label="Generar análisis"
                    @click="generarAnalisis"
                    :loading="loading"
                  />
                </div>
              </div>
            </q-card-section>
          </q-card>
        </div>

        <div class="col-12" v-if="resultado">
          <q-card class="my-card">
            <q-card-section>
              <div class="text-h6">Estadísticas generales</div>
            </q-card-section>

            <q-card-section>
              <div class="row q-col-gutter-md">
                <div class="col-12 col-md-3">
                  <q-card class="bg-primary text-white">
                    <q-card-section>
                      <div class="text-h6">Total de tickets</div>
                      <div class="text-h4">{{ resultado.statistics.totalTickets }}</div>
                    </q-card-section>
                  </q-card>
                </div>
                <div class="col-12 col-md-3">
                  <q-card class="bg-secondary text-white">
                    <q-card-section>
                      <div class="text-h6">Tiempo promedio de respuesta</div>
                      <div class="text-h4">{{ formatTime(resultado.statistics.avgResponseTime) }}</div>
                    </q-card-section>
                  </q-card>
                </div>
                <div class="col-12 col-md-6">
                  <q-card>
                    <q-card-section>
                      <div class="text-h6">Tickets por estado</div>
                      <div class="row q-col-gutter-sm">
                        <div 
                          v-for="(value, key) in resultado.statistics.ticketsByStatus" 
                          :key="key"
                          class="col-6 col-md-3"
                        >
                          <q-chip :color="getStatusColor(key)" text-color="white">
                            {{ key }}: {{ value }}
                          </q-chip>
                        </div>
                      </div>
                    </q-card-section>
                  </q-card>
                </div>
              </div>
            </q-card-section>

            <q-card-section>
              <div class="text-h6">Análisis de IA</div>
              <q-card class="q-mt-md">
                <q-card-section>
                  <div class="text-body1" v-html="formatAnalysis(resultado.aiAnalysis)"></div>
                </q-card-section>
              </q-card>
            </q-card-section>
          </q-card>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ListarFilas } from 'src/service/filas'
import { GetAITicketAnalysis } from 'src/service/estatisticas'

export default {
  name: 'RelatorioAnalisisIA',
  data () {
    return {
      filtros: {
        startDate: this.getDefaultStartDate(),
        endDate: this.getDefaultEndDate(),
        status: null,
        queuesIds: []
      },
      statusOptions: [
        { label: 'Abierto', value: 'open' },
        { label: 'Pendiente', value: 'pending' },
        { label: 'Cerrado', value: 'closed' }
      ],
      queueOptions: [],
      loading: false,
      resultado: null
    }
  },
  mounted () {
    this.cargarColas()
  },
  methods: {
    getDefaultStartDate () {
      const date = new Date()
      date.setDate(date.getDate() - 30)
      return date.toISOString().split('T')[0]
    },
    getDefaultEndDate () {
      const date = new Date()
      return date.toISOString().split('T')[0]
    },
    async cargarColas () {
      try {
        const { data } = await ListarFilas()
        this.queueOptions = data.map(queue => ({
          label: queue.name,
          value: queue.id
        }))
      } catch (error) {
        this.$q.notify({
          message: 'Error al cargar las colas',
          color: 'negative'
        })
      }
    },
    async generarAnalisis () {
      this.loading = true
      try {
        const params = {
          startDate: this.filtros.startDate ? new Date(this.filtros.startDate).toISOString() : undefined,
          endDate: this.filtros.endDate ? new Date(this.filtros.endDate + 'T23:59:59').toISOString() : undefined,
          status: this.filtros.status,
          queuesIds: this.filtros.queuesIds.length > 0 ? JSON.stringify(this.filtros.queuesIds) : undefined
        }

        const { data } = await GetAITicketAnalysis(params)
        this.resultado = data
      } catch (error) {
        console.error(error)
        this.$q.notify({
          message: 'Error al generar el análisis',
          color: 'negative'
        })
      } finally {
        this.loading = false
      }
    },
    formatTime (seconds) {
      if (!seconds) return '0s'
      
      const minutes = Math.floor(seconds / 60)
      const remainingSeconds = Math.floor(seconds % 60)
      
      if (minutes === 0) {
        return `${remainingSeconds}s`
      } else {
        return `${minutes}m ${remainingSeconds}s`
      }
    },
    getStatusColor (status) {
      const colors = {
        open: 'green',
        pending: 'orange',
        closed: 'blue'
      }
      return colors[status] || 'grey'
    },
    formatAnalysis (text) {
      if (!text) return ''
      
      // Convertir saltos de línea a <br>
      let formatted = text.replace(/\n/g, '<br>')
      
      // Convertir encabezados markdown a HTML
      formatted = formatted.replace(/#{1,6}\s+([^\n]+)/g, (match, title) => {
        const level = match.trim().indexOf(' ')
        return `<h${level} class="q-mt-md q-mb-sm">${title}</h${level}>`
      })
      
      // Convertir listas markdown a HTML
      formatted = formatted.replace(/^\s*[-*]\s+(.+)$/gm, '<li>$1</li>')
      formatted = formatted.replace(/<\/li>\s*<li>/g, '</li><li>')
      formatted = formatted.replace(/(<li>.+<\/li>)/gs, '<ul>$1</ul>')
      
      // Convertir texto en negrita
      formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      
      return formatted
    }
  }
}
</script>

<style scoped>
.my-card {
  width: 100%;
}
</style>