import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'autoReplyId' a la tabla 'Tickets'
    return queryInterface.addColumn("Tickets", "autoReplyId", {
      type: DataTypes.INTEGER,
      defaultValue: null,
      allowNull: true
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'autoReplyId' de la tabla 'Tickets'
    return queryInterface.removeColumn("Tickets", "autoReplyId");
  }
};
