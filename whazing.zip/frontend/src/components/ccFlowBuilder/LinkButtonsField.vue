<template>
  <div>
    <q-card flat class="q-pa-sm q-pb-md">
      <q-card-section class="q-pa-none">
        <div class="text-subtitle2 q-mb-sm">
          {{ $t('ccFlowBuilder.addlinkbutton') }}
        </div>
        <!-- Header field -->
        <div class="q-mb-md">
          <q-input
            dense
            outlined
            required
            v-model="$attrs.element.data.header"
            :label="$t('ccFlowBuilder.header')"
          />
        </div>

        <!-- Body field -->
        <div class="q-mb-md">
          <textarea
            style="min-height: 5vh; max-height: 15vh; width: 100%"
            class="q-pa-sm bg-white"
            :placeholder="$t('ccFlowBuilder.body')"
            autogrow
            dense
            outlined
            required
            @input="(v) => $attrs.element.data.body = v.target.value"
            :value="$attrs.element.data.body">
          </textarea>
        </div>

        <!-- Footer field -->
        <div class="q-mb-md">
          <q-input
            dense
            outlined
            required
            v-model="$attrs.element.data.footer"
            :label="$t('ccFlowBuilder.footer')"
          />
        </div>

        <!-- Link section -->
        <div class="q-mb-md">
          <div class="text-caption q-mb-xs">{{ $t('ccFlowBuilder.link') }}</div>

          <div class="row q-col-gutter-sm">
            <div class="col-12 q-mb-sm">
              <q-input
                dense
                outlined
                required
                v-model="$attrs.element.data.display_text"
                :label="$t('ccFlowBuilder.displayText')"
              />
            </div>
            <div class="col-12">
              <q-input
                dense
                outlined
                required
                v-model="$attrs.element.data.url"
                :label="$t('ccFlowBuilder.url')"
              />
            </div>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
export default {
  name: 'LinkButtonsField',
  data () {
    return {}
  },
  mounted () {
    // Initialize fields if they don't exist
    if (!this.$attrs.element.data.header) {
      this.$attrs.element.data.header = ''
    }
    if (!this.$attrs.element.data.body) {
      this.$attrs.element.data.body = ''
    }
    if (!this.$attrs.element.data.footer) {
      this.$attrs.element.data.footer = ''
    }
    if (!this.$attrs.element.data.display_text) {
      this.$attrs.element.data.display_text = ''
    }
    if (!this.$attrs.element.data.url) {
      this.$attrs.element.data.url = ''
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
