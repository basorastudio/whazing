import { QueryInterface, DataTypes } from 'sequelize'; // Added DataTypes
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Ensure 'key' and 'tenantId' combination is unique in 'Settings'
    // First, delete duplicate settings, keeping the one with the minimum internal 'ctid' (PostgreSQL specific)
    await queryInterface.sequelize.query(`
      DELETE FROM "Settings"
      WHERE ctid NOT IN (
          SELECT min(ctid)
          FROM "Settings"
          GROUP BY "key", "tenantId"
      );
    `);

    // Remove the old primary key (assuming it was just 'id')
    await queryInterface.removeColumn('Settings', 'id');

    // Add a composite unique constraint on 'key' and 'tenantId'
    await queryInterface.addConstraint('Settings', {
      fields: ['key', 'tenantId'],
      type: 'unique',
      name: 'unique_key_tenantId', // Explicit constraint name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Revert the changes: remove composite unique constraint, add back 'id' column
    await queryInterface.removeConstraint('Settings', 'unique_key_tenantId');

    // Add back the 'id' column as primary key
    await queryInterface.addColumn('Settings', 'id', {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      // allowNull defaults to false for primary keys usually handled by autoIncrement
    });
  }
};

export = migration;