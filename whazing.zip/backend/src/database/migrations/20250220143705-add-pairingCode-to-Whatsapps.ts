import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'pairingCode' column to the 'Whatsapps' table
    // Used for pairing WhatsApp Web/Multi-Device via code.
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "pairingCode", // New column name
      {
        type: DataTypes.STRING,
        defaultValue: null,
        allowNull: true // Allow null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'pairingCode' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      "Whatsapps", // Table name
      "pairingCode" // Column name to remove
    );
  }
};

export = migration;
