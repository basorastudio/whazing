import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'UserRatings' table
    await queryInterface.createTable(
      "UserRatings", // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false
        },
        ticketId: {
          type: DataTypes.INTEGER,
          references: {
            model: "Tickets", // Foreign key to Tickets
            key: "id"
          },
          onDelete: "SET NULL" // Allow rating to exist if ticket is deleted? Or CASCADE?
          // allowNull implicitly true due to onDelete SET NULL
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: {
            model: "Tenants", // Foreign key to Tenants
            key: "id"
          },
          onDelete: "SET NULL" // Allow rating to exist if tenant is deleted?
          // allowNull implicitly true due to onDelete SET NULL
        },
        userId: {
          type: DataTypes.INTEGER,
          references: {
            model: "Users", // Foreign key to Users
            key: "id"
          },
          onDelete: "SET NULL", // User who was rated?
          allowNull: true
        },
        contactId: {
          type: DataTypes.INTEGER,
          references: {
            model: "Contacts", // Foreign key to Contacts
            key: "id"
          },
          onDelete: "SET NULL", // Contact who gave the rating?
          allowNull: true
        },
        whatsappId: {
          type: DataTypes.INTEGER,
          references: {
            model: "Whatsapps", // Foreign key to Whatsapps connection used
            key: "id"
          },
          onDelete: "SET NULL",
          allowNull: true
        },
        rate: {
          type: DataTypes.INTEGER, // The rating value (e.g., 1-5)
          defaultValue: 0
          // allowNull defaults to true, but defaultValue suggests it might be intended as non-null
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: true // Original had true
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: true // Original had true
        }
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'UserRatings' table
    await queryInterface.dropTable("UserRatings");
  }
};

export = migration;
