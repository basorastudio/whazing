// --- START OF FILE GroupController.ts ---

import type { Request, Response } from 'express';
import * as Yup from 'yup';

import AppError from '../errors/AppError';
import CreateGroupService from '../services/GroupServices/CreateGroupService';
import ListGroupService from '../services/GroupServices/ListGroupService';
import UpdateGroupService from '../services/GroupServices/UpdateGroupService';
import DeleteGroupService from '../services/GroupServices/DeleteGroupService';
import ListUserGroupService from '../services/GroupServices/ListUserGroupService';
import FindUserByGroupService from '../services/UserServices/FindUserByGroupService'; // Assuming path
import UsersGroups from '../models/UsersGroups';

interface StoreBody {
    group: string;
    // Maybe other fields?
}

interface UpdateBody {
    group: string;
    isActive: boolean;
    // Maybe other fields?
}

interface StoreUserBody {
    groupId: number | string;
    userId: number | string;
}


export const store = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const groupData = { ...req.body } as StoreBody;
  groupData.userId = req.user.id; // Assign logged-in user ID
  groupData.tenantId = tenantId; // Assign tenant ID

  const schema = Yup.object().shape({
    group: Yup.string().required(),
    userId: Yup.number().required(),
    tenantId: Yup.number().required()
  });

  try {
    await schema.validate(groupData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const group = await CreateGroupService(groupData);
  return res.status(201).json(group);
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const groups = await ListGroupService({ tenantId });
  return res.status(200).json(groups);
};

export const update = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const groupData = { ...req.body } as UpdateBody;
  groupData.userId = req.user.id; // Ensure userId is associated
  groupData.tenantId = tenantId; // Ensure tenantId is correct

  const schema = Yup.object().shape({
    group: Yup.string().required(),
    isActive: Yup.boolean().required(),
    userId: Yup.number().required(),
    // tenantId is implicit
  });

  try {
    await schema.validate(groupData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const { groupId } = req.params;
  const updatedGroup = await UpdateGroupService({
    groupData: groupData,
    groupId: Number(groupId)
  });
  return res.status(200).json(updatedGroup);
};

export const remove = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const { groupId } = req.params;

  await DeleteGroupService({ id: Number(groupId), tenantId });
  return res.status(200).json({ message: 'Grupo eliminado' }); // Traducido
};

export const listUserGroups = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId, id: userId } = req.user;
  const userGroups = await ListUserGroupService({ tenantId, userId });
  return res.status(200).json(userGroups);
};

export const listUserbyGroup = async (req: Request, res: Response): Promise<Response> => {
    const { groupId } = req.params;
    const users = await FindUserByGroupService(Number(groupId));
    return res.status(200).json(users);
};

export const storeUser = async (req: Request, res: Response): Promise<Response> => {
    const { groupId, userId } = req.body as StoreUserBody;

    // Check if the association already exists
    let existingAssociation = await UsersGroups.findOne({
        where: { userId: Number(userId), groupId: Number(groupId) }
    });

    if (existingAssociation) {
        // Use a more specific error code/message if available
        throw new AppError('USER_GROUP_ALREADY_EXIST', 409); // Assuming 409 Conflict
    }

    // Create the association
    const newAssociation = await UsersGroups.create({
        userId: Number(userId),
        groupId: Number(groupId)
    });

    return res.status(201).json(newAssociation);
};

export const removeUser = async (req: Request, res: Response): Promise<Response> => {
    const { groupId, userId } = req.params; // Assuming they are in params

    const association = await UsersGroups.findOne({
        where: { userId: Number(userId), groupId: Number(groupId) }
    });

    if (!association) {
        // Using the potentially misspelled code from original, or correct if known
        throw new AppError('USER_GROUP_NOT_FOUND', 404); // Or 'USER_GRPUP_NOT_FOUND'
    }

    await association.destroy();
    // Return the deleted association data or just a success message
    // Returning the data might be useful for confirmation on the frontend
    return res.status(200).json(association);
    // Or: return res.status(204).send(); // No Content
};


// --- END OF FILE GroupController.ts ---