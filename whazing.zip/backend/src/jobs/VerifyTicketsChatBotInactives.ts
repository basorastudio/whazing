import FindUpdateTicketsInactiveChatBot from "../services/Tickets/FindUpdateTicketsInactiveChatBot"; // Assuming default export
import { logger } from "../utils/logger";

interface VerifyTicketsBackoffOptions {
  every: number; // milliseconds
}

interface VerifyTicketsOptions {
  removeOnComplete: boolean;
  removeOnFail: boolean;
  jobId: string;
  repeat: VerifyTicketsBackoffOptions;
}

const repeatOptions: VerifyTicketsBackoffOptions = {
  every: 900000 // (0x1e7e + 0x1 * 0x1d54 + -0x3bcd) * (...) * (...) = 1 * 30 * 30000 = 900000 ms (15 minutes)
};

const handleOptions: VerifyTicketsOptions = {
  removeOnComplete: true,
  removeOnFail: true,
  jobId: "VerifyTicketsChatBotInactives",
  repeat: repeatOptions
};

export const VerifyTicketsChatBotInactives = {
  key: "VerifyTicketsChatBotInactives",
  options: handleOptions,
  async handle(): Promise<void> {
    const logPrefix = "VerifyTicketsChatBotInactives";
    try {
      logger.info(`${logPrefix}: Iniciado`); // Original: VerifyTicketsChatBotInactives Iniciated
      await FindUpdateTicketsInactiveChatBot(); // Assuming it's a function to call
      logger.info(`${logPrefix}: Finalizado`); // Original: Finalized VerifyTicketsChatBotInactives
    } catch (error: any) {
      logger.error({
        message: `Error al procesar ${logPrefix}`, // Original: Error send messages
        error: error?.message, // Keep original error message if available
        originalError: error
      });
      // Convert error to generic Error for throwing if it's not already one
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error(String(error));
      }
    }
  }
};
