import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Propiedades comunes para las nuevas columnas
    const commonProps = {
      allowNull: true, // Permite nulos
      defaultValue: null
    };

    return Promise.all([
      // Añade la columna 'tokenAPI' (TEXT) a 'Whatsapps'
      queryInterface.addColumn("Whatsapps", "tokenAPI", {
        type: DataTypes.TEXT,
        ...commonProps
      }),
      // Añade la columna 'wabaBSP' (STRING) a 'Whatsapps'
      queryInterface.addColumn("Whatsapps", "wabaBSP", {
        type: DataTypes.STRING,
        ...commonProps
      }),
      // Añade la columna 'wabaKeyHook' (TEXT) a 'Whatsapps'
      queryInterface.addColumn("Whatsapps", "wabaKeyHook", {
        type: DataTypes.TEXT,
        ...commonProps
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina las columnas añadidas
    return Promise.all([
      queryInterface.removeColumn("Whatsapps", "tokenAPI"),
      queryInterface.removeColumn("Whatsapps", "wabaBSP"),
      queryInterface.removeColumn("Whatsapps", "wabaKeyHook")
    ]);
  }
};
