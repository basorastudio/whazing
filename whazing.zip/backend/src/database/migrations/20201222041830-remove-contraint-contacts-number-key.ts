import { QueryInterface, Sequelize } from 'sequelize';

export = {
  up: async (queryInterface: QueryInterface, sequelize: Sequelize): Promise<void> => {
    // Elimina la restricción 'Contacts_number_key' de la tabla 'Contacts'.
    // Esta restricción probablemente aseguraba que el campo 'number' fuera único.
    await queryInterface.removeConstraint('Contacts', 'Contacts_number_key');
  },

  down: async (queryInterface: QueryInterface, sequelize: Sequelize): Promise<void> => {
    // Vuelve a añadir la restricción 'Contacts_number_key' a la tabla 'Contacts'.
    await queryInterface.addConstraint('Contacts', {
      fields: ['number'], // El campo afectado por la restricción
      type: 'unique', // Tipo de restricción: única
      name: 'Contacts_number_key' // Nombre de la restricción
    });
  }
};