import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'queue' (probablemente la versión con referencia)
    await queryInterface.removeColumn("Tickets", "queue");
    // Añade la columna 'queueId' como clave foránea a 'Queues'
    await queryInterface.addColumn("Tickets", "queueId", {
      type: DataTypes.INTEGER,
      references: {
        model: "Queues", // Referencia a la tabla Queues
        key: "id"
      },
      onUpdate: "CASCADE",
      onDelete: "restrict", // No permite eliminar una Queue si hay Tickets asociados
      defaultValue: null,
      allowNull: true
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'queueId'
    await queryInterface.removeColumn("Tickets", "queueId");
    // Vuelve a añadir la columna 'queue' (como estaba antes de esta migración)
    await queryInterface.addColumn("Tickets", "queue", {
      type: DataTypes.INTEGER,
      defaultValue: null,
      allowNull: true
      // Nota: La referencia a 'Queues' se pierde aquí en el rollback
    });
  }
};
