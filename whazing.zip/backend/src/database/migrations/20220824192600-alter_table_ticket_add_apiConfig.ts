// --- START OF FILE 20220824192600-alter_table_ticket_add_apiConfig.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Tickets";
    const columnName = "apiConfig";
    const attributes = {
      type: DataTypes.JSONB,
      allowNull: true, // Changed !![] to true
      defaultValue: null
    };
    await Promise.all([
      queryInterface.addColumn(tableName, columnName, attributes)
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Tickets";
    const columnName = "apiConfig";
    await Promise.all([queryInterface.removeColumn(tableName, columnName)]);
  }
};

export default migration;

// --- END OF FILE 20220824192600-alter_table_ticket_add_apiConfig.ts ---
