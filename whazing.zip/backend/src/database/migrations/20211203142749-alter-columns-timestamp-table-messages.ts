import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Cambia el tipo de la columna 'timestamp' a BIGINT en 'Messages'
    return queryInterface.changeColumn('Messages', 'timestamp', {
      type: DataTypes.BIGINT, // Cambia a BIGINT
      allowNull: true, // Mantiene allowNull como true
      defaultValue: null // Mantiene defaultValue como null
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Revierte el cambio de tipo de 'timestamp' a INTEGER
    return queryInterface.changeColumn('Messages', 'timestamp', {
      type: DataTypes.INTEGER, // Vuelve a INTEGER
      allowNull: true,
      defaultValue: null
    });
  }
};