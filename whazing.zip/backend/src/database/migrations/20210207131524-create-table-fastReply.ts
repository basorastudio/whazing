import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla 'FastReply' para respuestas rápidas
    return queryInterface.createTable('FastReply', {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      key: { // Atajo o palabra clave para la respuesta rápida
        type: DataTypes.STRING,
        allowNull: false
      },
      message: { // Contenido de la respuesta rápida
        type: DataTypes.TEXT,
        allowNull: false
      },
      userId: {
        type: DataTypes.INTEGER,
        references: { model: 'Users', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      tenantId: {
        type: DataTypes.INTEGER,
        references: { model: 'Tenants', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Si el tenant se elimina, se eliminan las respuestas rápidas asociadas
        allowNull: false,
        defaultValue: 1
      },
      createdAt: {
        type: DataTypes.DATE(6),
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE(6),
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la tabla 'FastReply'
    return queryInterface.dropTable('FastReply');
  }
};