import { Request, Response } from "express";
import ApiwwjsService from "../services/ApiwwjsService/ApiwwjsService"; // Check path and name

// Define expected response structure for success
interface ApiResponseSuccess {
  success: true;
  // Add other expected properties based on ApiwwjsService methods
  status?: string;
  qrcode?: string;
  qrcodePng?: string;
  pairingCode?: string | null;
  message?: string;
  [key: string]: any; // Allow other properties
}

// Define expected response structure for error
interface ApiResponseError {
  success: false;
  error: string;
  details?: string; // Optional detailed error message
}

type ApiResponse = ApiResponseSuccess | ApiResponseError;

export const checkStatus = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { whatsappId } = req.params;
    const result = await ApiwwjsService.checkStatus(whatsappId);
    return res.status(200).json(result);
  } catch (error: any) {
    console.error("Error in checkStatus controller:", error);
    const response: ApiResponseError = {
      success: false,
      error: error.message || "Internal server error"
    };
    // Determine status code based on error type if possible
    const statusCode =
      error.name === "session_not_found" || error.message?.includes("not found")
        ? 404
        : 500;
    return res.status(statusCode).json(response);
  }
};

export const startSession = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { whatsappId } = req.params;
    // First check current status
    const currentStatus = await ApiwwjsService.checkStatus(whatsappId);

    // If already connected or pairing, maybe return current status instead of starting again?
    if (
      currentStatus.status === "CONNECTED" ||
      currentStatus.status === "PAIRING" ||
      currentStatus.status === "qrcode"
    ) {
      console.warn(
        `startSession called for already active session: ${whatsappId} (status: ${currentStatus.status})`
      );
      return res.status(200).json(currentStatus); // Return current status
      // Or throw an error: throw new Error("Session is already active or connecting.");
    }

    // If disconnected or initial state, proceed to start
    const result = await ApiwwjsService.startSession(whatsappId);
    return res.status(200).json(result);
  } catch (error: any) {
    console.error("Error in startSession controller:", error);
    const response: ApiResponseError = {
      success: false,
      error: error.message || "Internal server error"
    };
    const statusCode =
      error.name === "session_not_found" || error.message?.includes("not found")
        ? 404
        : 500;
    return res.status(statusCode).json(response);
  }
};

export const getQrCode = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { whatsappId } = req.params;
    const result = await ApiwwjsService.getQrCode(whatsappId);
    return res.status(200).json(result);
  } catch (error: any) {
    console.error("Error in getQrCode controller:", error);
    const response: ApiResponseError = {
      success: false,
      error: error.message || "Internal server error"
    };
    const statusCode =
      error.name === "session_not_found" || error.message?.includes("not found")
        ? 404
        : 500;
    return res.status(statusCode).json(response);
  }
};

export const terminateSession = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { whatsappId } = req.params;
    const result = await ApiwwjsService.terminateSession(whatsappId);
    return res.status(200).json(result);
  } catch (error: any) {
    console.error("Error in terminateSession controller:", error);
    const response: ApiResponseError = {
      success: false,
      error: error.message || "Internal server error"
    };
    const statusCode =
      error.name === "session_not_found" || error.message?.includes("not found")
        ? 404
        : 500;
    return res.status(statusCode).json(response);
  }
};
