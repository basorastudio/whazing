<template>

  <q-item
    v-if="!submenu"
    clickable
    v-ripple
    :active="routeName == cRouterName"
    active-class="bg-grey-1 text-grey-8 text-bold menu-link-active-item-top"
    @click=" () => !(routeName == cRouterName) ? $router.push({ name: routeName }) : ''"
    class="houverList menu-list-item full-width"
    :class="{'text-negative text-bolder': color === 'negative'}"
  >
    <q-item-section
      v-if="icon"
      avatar
    >
      <div class="icon-badge-container">
        <q-icon
          :name="color === 'negative' ? 'mdi-cellphone-nfc-off' : icon"
          size="sm"
        />
        <q-badge
          v-if="badge"
          color="red"
          class="absolute-fixed-badge"
        >
          {{ badge }}
        </q-badge>
      </div>
    </q-item-section>

    <q-item-section>
      <q-item-label class="menu-list-item-title">{{ title }}</q-item-label>
    </q-item-section>
    <q-tooltip v-if="!this.$q.screen.lt.md" anchor="center right" self="center left">
      <div class="menu-list-item-tooltip">
        {{ title }}
      </div>
    </q-tooltip>

  </q-item>

  <q-item
    v-else-if="menuType == 'configuracoes'"
    clickable
    v-ripple
    :active="routeName == cRouterName"
    active-class="bg-grey-1 text-grey-8 text-bold menu-link-active-item-top"
    class="houverList menu-list-item"
    :class="{'text-negative text-bolder': color === 'negative'}"
  >
    <q-item-section
      v-if="icon"
      avatar
    >
      <q-icon :name="color === 'negative' ? 'mdi-cellphone-nfc-off' : 'eva-settings-2'" size="sm"/>
    </q-item-section>
    <q-item-section>
      <q-item-label class="menu-list-item-title">{{ title }}</q-item-label>
    </q-item-section>

    <q-menu
      @mouseover="$root.$emit('submenu-mouseover')"
      @mouseout="$root.$emit('submenu-mouseout')"
      @click.stop="$root.$emit('submenu-mouseout')"
      fit
      anchor="bottom right"
      self="top middle"
      ref="menu"
    >
      <q-list>
        <q-item clickable
                @click=" () => !('sessoes' == cRouterName) ? $router.push({ name: 'sessoes' }) : ''">
          <q-item-section>Canais/API</q-item-section>
        </q-item>
        <q-item clickable v-if="userProfile === 'admin'"
                @click=" () => !('horarioAtendimento' == cRouterName) ? $router.push({ name: 'horarioAtendimento' }) : ''">
          <q-item-section>Horário de Atendimento</q-item-section>
        </q-item>
        <q-item clickable
                @click=" () => !('chat-flow' == cRouterName) ? $router.push({ name: 'chat-flow' }) : ''">
          <q-item-section>Chatbot</q-item-section>
        </q-item>
        <q-item clickable v-if="userProfile === 'admin'"
                @click=" () => !('configuracoes' == cRouterName) ? $router.push({ name: 'configuracoes' }) : ''">
          <q-item-section>Configurações</q-item-section>
        </q-item>

      </q-list>
    </q-menu>

    <q-tooltip v-if="!this.$q.screen.lt.md" anchor="center right" self="center left">
      <div class="menu-list-item-tooltip">
        Configurações
      </div>
    </q-tooltip>
  </q-item>

  <q-item
    v-else-if="menuType == 'cadastros'"
    clickable
    v-ripple
    :active="routeName == cRouterName"
    active-class="bg-grey-1 text-grey-8 text-bold menu-link-active-item-top"
    class="houverList menu-list-item"
    :class="{'text-negative text-bolder': color === 'negative'}"
  >
    <q-item-section
      v-if="icon"
      avatar
    >
      <q-icon :name="color === 'negative' ? 'mdi-cellphone-nfc-off' : 'eva-list'" size="sm"/>
    </q-item-section>
    <q-item-section>
      <q-item-label class="menu-list-item-title">{{ title }}</q-item-label>
    </q-item-section>
    <!--Mobile-->
    <q-menu
      @mouseover="$root.$emit('submenu-mouseover')"
      @mouseout="$root.$emit('submenu-mouseout')"
      @click.stop="$root.$emit('submenu-mouseout')"
      fit
      anchor="bottom right"
      self="top middle"
      ref="menu"
    >
      <q-list>
        <q-item clickable
                @click=" () => !('usuarios' == cRouterName) ? $router.push({ name: 'usuarios' }) : ''">
          <q-item-section>Usuários/Equipes</q-item-section>
        </q-item>
        <q-item clickable
                @click=" () => !('filas' == cRouterName) ? $router.push({ name: 'filas' }) : ''">
          <q-item-section>Filas/Integrações</q-item-section>
        </q-item>
        <q-item clickable
                @click=" () => !('etiquetas' == cRouterName) ? $router.push({ name: 'etiquetas' }) : ''">
          <q-item-section>Etiquetas</q-item-section>
        </q-item>
        <q-item clickable
                @click=" () => !('campanhas' == cRouterName) ? $router.push({ name: 'campanhas' }) : ''">
          <q-item-section>Campanha</q-item-section>
        </q-item>

      </q-list>
    </q-menu>

    <q-tooltip v-if="!this.$q.screen.lt.md" anchor="center right" self="center left">
      <div class="menu-list-item-tooltip">
        Cadastros
      </div>
    </q-tooltip>
  </q-item>

</template>

<script>
export default {
  name: 'EssentialLink',
  data() {
    return {
      menuAtivo: 'dashboard',
      userProfile: 'user'
    }
  },
  props: {
    title: {
      type: String,
      required: true
    },
    color: {
      type: String,
      default: ''
    },
    routeName: {
      type: String,
      default: 'dashboard'
    },
    icon: {
      type: String,
      default: ''
    },
    submenu: {
      type: Boolean,
      default: false
    },
    menuType: {
      type: String,
      default: ''
    },
    badge: {
      type: [Number, String],
      default: null
    }
  },
  computed: {
    cRouterName() {
      return this.$route.name
    },
    cRouterNameNew(route) {
      return route
    }
  },
  mounted() {
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>
<style lang="sass">

.icon-badge-container
  position: relative
  display: flex
  align-items: center
  justify-content: center

.absolute-fixed-badge
  position: absolute
  top: -8px
  right: -8px
  z-index: 2
  min-height: 18px
  min-width: 18px
  font-size: 12px
  display: flex
  align-items: center
  justify-content: center
  transform: none !important
  transition: none !important
</style>
