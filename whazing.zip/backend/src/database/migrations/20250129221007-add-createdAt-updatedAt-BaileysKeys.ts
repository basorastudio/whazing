import { QueryInterface, DataTypes, Sequelize, Literal } from "sequelize"; // Added Sequelize and Literal
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add createdAt and updatedAt columns to 'BaileysKeys' table
    await queryInterface.addColumn("BaileysKeys", "createdAt", {
      allowNull: false, // Cannot be null
      type: DataTypes.DATE,
      defaultValue: Sequelize.literal("CURRENT_TIMESTAMP") // Use database default
    });
    await queryInterface.addColumn("BaileysKeys", "updatedAt", {
      allowNull: false, // Cannot be null
      type: DataTypes.DATE,
      defaultValue: Sequelize.literal("CURRENT_TIMESTAMP") // Use database default
      // 'onUpdate' equivalent needs a trigger in some DBs, defaultValue handles creation
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove createdAt and updatedAt columns from 'BaileysKeys' table
    await queryInterface.removeColumn("BaileysKeys", "updatedAt");
    await queryInterface.removeColumn("BaileysKeys", "createdAt");
  }
};

export = migration;
