import { Request, Response } from "express";
import os from "os";
// Assuming types are available or using require if not. You might need to install @types/diskusage and @types/os-utils
// If types are not available, you might need to use 'any' or declare basic types.
import diskusage, { DiskUsage } from "diskusage";
import osu from "os-utils";

// Helper para obtener la dirección IP v4 principal
function getIpAddress(): string {
  const networkInterfaces = os.networkInterfaces();
  let ipAddress = "";
  for (const interfaceName of Object.keys(networkInterfaces)) {
    // Node.js types might define networkInterfaces[interfaceName] as potentially undefined
    const interfaces: os.NetworkInterfaceInfo[] | undefined =
      networkInterfaces[interfaceName];
    if (interfaces) {
      // Verifica si la interfaz existe
      for (const iface of interfaces) {
        // Busca la dirección IPv4 que no sea interna
        if (!iface.internal && iface.family === "IPv4") {
          ipAddress = iface.address;
          break; // Usa la primera encontrada
        }
      }
    }
    if (ipAddress) break; // Sale si ya encontró una
  }
  return ipAddress;
}

export const CheckServiceMessenger = async (
  req: Request,
  res: Response
): Promise<Response> => {
  // "Error al obtener información del servidor"
  const errorFetchingInfo = "Error al obtener información del servidor";

  try {
    // Información básica del OS
    // Using Record<string, any> for flexibility, but specific types could be defined
    const serverInfo: Record<string, any> = {
      Hostname: os.hostname(),
      // 'Dirección IP'
      "Dirección IP": getIpAddress(),
      // 'Sistema Operativo'
      "Sistema Operativo": os.type(),
      // Intenta obtener el modelo del primer CPU, si existe
      // 'Modelo del Servidor'
      "Modelo del Servidor": os.cpus()?.[0]?.model || "N/A",
      // 'Cantidad de CPUs'
      "Cantidad de CPUs": os.cpus()?.length || 0,
      // Memoria Total en GB
      "Total Memory": (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2) + " GB",
      // Memoria Libre en GB
      "Free Memory": (os.freemem() / (1024 * 1024 * 1024)).toFixed(2) + " GB",
      // Porcentaje de uso de memoria
      "Memory Usage Percentage": (
        (1 - os.freemem() / os.totalmem()) *
        100
      ).toFixed(2),
      // Tiempo activo en horas
      Uptime: (os.uptime() / 3600).toFixed(2) + " hours"
    };

    // Obtener uso de CPU (asíncrono)
    osu.cpuUsage(function (cpuUsage) {
      // 'Porcentaje de Uso de CPU'
      serverInfo["CPU Usage Percentage"] = (cpuUsage * 100).toFixed(2);

      try {
        // Obtener uso de disco (puede fallar si la ruta no existe o no hay permisos)
        // Usa '/' para el disco raíz en Linux/macOS, ajusta si es necesario para Windows ('C:')
        // diskusage.checkSync might not be ideal in an async controller, consider the async 'check' version
        // Using checkSync here for simplicity based on the original code structure
        const diskInfo: DiskUsage = diskusage.checkSync("/");

        const totalDiskGB = diskInfo.total / (1024 * 1024 * 1024);
        const freeDiskGB = diskInfo.available / (1024 * 1024 * 1024); // Use 'available' for user-usable space
        const usedDiskGB = totalDiskGB - freeDiskGB;
        // Calculate percentage based on 'available' space for a more realistic usage view
        const diskUsagePercentage = (usedDiskGB / totalDiskGB) * 100;

        // 'Espacio Total en Disco'
        serverInfo["Total Disk Space"] = totalDiskGB.toFixed(2) + " GB";
        // 'Espacio Libre en Disco' (Available to user)
        serverInfo["Free Disk Space"] = freeDiskGB.toFixed(2) + " GB";
        // 'Espacio Usado en Disco'
        serverInfo["Used Disk Space"] = usedDiskGB.toFixed(2) + " GB";
        // 'Porcentaje de Uso de Disco'
        serverInfo["Disk Usage Percentage"] = diskUsagePercentage.toFixed(2);
        // 'Hora del Servidor'
        serverInfo["Hora del Servidor"] = new Date().toLocaleString();

        // Envía la respuesta JSON con toda la información
        // Use return inside the callback to ensure response is sent correctly
        return res.status(200).json({ serverInfo });
      } catch (diskError: any) {
        // "Error al obtener uso de disco:"
        console.error("Error al obtener uso de disco:", diskError);
        serverInfo["Disk Usage"] = "Error fetching disk usage"; // Indica error específico
        // Envía la info parcial si falla el disco
        // Use return inside the callback
        return res.status(200).json({ serverInfo });
      }
    });
    // Important: Because osu.cpuUsage is asynchronous and we are returning inside its callback,
    // the outer function should not attempt to return a response here.
    // The response will be handled within the cpuUsage callback.
  } catch (error: any) {
    console.error(errorFetchingInfo, error); // Loguea el error completo
    // Responde con un error 500 si falla la obtención inicial de datos de OS
    return res.status(500).json({ error: errorFetchingInfo });
  }
  // This point might be unreachable if osu.cpuUsage callback always returns.
  // If osu.cpuUsage could potentially *not* call its callback (e.g., error),
  // you'd need more complex error handling (e.g., Promises, async/await with osu).
};
