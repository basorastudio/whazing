<template>
  <div>
    <q-table flat
      bordered
      square
      hide-bottom
             class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
             :class="{
    'full-height': $q.screen.lt.sm
  }"
      :data="financeiro"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]">
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-cash-multiple q-pr-sm" />
            Mensualidad / Factura
          </h2>
          <q-btn flat
                 class="generate-button btn-rounded-50"
                 :class="{'generate-button-dark' : $q.dark.isActive}"
                 v-if="whatsappNumber"
                 icon="mdi-whatsapp"
                 label="Contactar Soporte"
                 @click="abrirWhatsApp"
          />
        </div>

      </template>
      <template v-slot:body-cell-value="props">
        <q-td key="value" :props="props">
          R$ {{ props.row.value.toFixed(2).replace('.', ',') }}
        </q-td>
      </template>
      <template v-slot:body-cell-dueDate="props">
        <q-td key="dueDate" :props="props">
          {{ formatDate(props.row.dueDate) }}
        </q-td>
      </template>
      <template v-slot:body-cell-status="props">
        <q-td
          key="status"
          :props="props"
          :style="getStatusStyle(props.row.status, props.row.dueDate)"
        >
          {{ getStatusText(props.row.status, props.row.dueDate) }}
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            v-if="props.row.status !== 'paid'"
            color="primary"
            label="PAGAR"
            @click="GerarQRCODE(props.row)"
          />
        </q-td>
      </template>
    </q-table>

    <q-dialog v-model="showQRCodeModal" persistent>
    <q-card class="container-rounded-10">
      <q-card-section>
        <div class="text-h6 font-family-main text-center">
          Código QR de Pago
          <q-btn round
          flat
            class="q-ml-md float-right"
            color="negative"
            icon="eva-close"
            v-close-popup />
        </div>
      </q-card-section>
      <q-card-section class="text-center q-ma-lg container-rounded-10 container-border"
        :style="$q.dark.isActive ? 'background: white !important' : ''">
          <div>Escanee el código QR en la aplicación de su banco</div>
          <qrcode-vue :value="qrCodeValue" :size="200"></qrcode-vue>

      <q-card-section>
          <div>
            <q-input
              v-model="pixString"
              readonly
              filled
              class="q-ma-md"
              style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"
            />
          </div>
          <q-btn
            class="generate-button btn-rounded-50"
            label="Copiar código QR"
            @click="copiarPixString"
            icon="mdi-content-copy" />
        <div class="text-center q-mb-lg" style="font-size: 14px">Para finalizar, realice el pago escaneando o pegando el código Pix arriba :) </div>
        <div class="row col-12 justify-center">
        </div>
      </q-card-section>

      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import { ListarInvoices, CriarQRCODE } from 'src/service/financeiro'
import { ListarConfiguracaoPublica, ListarCores } from 'src/service/configuracoesgeneral'
import { format, parseISO, isBefore, addDays } from 'date-fns'
import QRCodeVue from 'qrcode.vue'

export default {
  name: 'Financeiro',
  components: {
    'qrcode-vue': QRCodeVue
  },
  data () {
    return {
      financeiro: [],
      whatsappNumber: null,
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      showQRCodeModal: false,
      qrCodeValue: '',
      pixString: '',
      UrlPagamentoOpen: '',
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'detail', label: 'Plano', field: 'detail', align: 'left' },
        { name: 'value', label: 'Valor', field: 'value', align: 'center' },
        { name: 'dueDate', label: 'Fecha Venc.', field: 'dueDate', align: 'center' },
        { name: 'status', label: 'Estado', field: 'status', align: 'center' },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores devueltos por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Error al buscar configuraciones:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Hola%21+Tengo+dudas+en+el+área+financiera`
        window.open(url, '_blank') // Abre WhatsApp en una nueva pestaña
      }
    },
    formatDate(date) {
      try {
        return format(parseISO(date), 'dd/MM/yyyy')
      } catch (error) {
        console.error('Formato de fecha inválido:', error)
        return date // Fallback a la fecha original si falla el parseo/formateo
      }
    },
    async listarFinanceiro () {
      const { data } = await ListarInvoices()
      this.financeiro = data
    },
    getStatusStyle(status, dueDate) {
      const currentDate = addDays(new Date(), -1)
      const parsedDueDate = parseISO(dueDate)
      if (status === 'paid') {
        return { backgroundColor: 'green', color: 'black', fontWeight: 'bold' }
      } else if (status === 'open') {
        if (isBefore(currentDate, parsedDueDate)) {
          return { backgroundColor: 'yellow', color: 'black', fontWeight: 'bold' }
        } else {
          return { backgroundColor: 'red', color: 'black', fontWeight: 'bold' }
        }
      }
      return {}
    },
    getStatusText(status, dueDate) {
      const currentDate = addDays(new Date(), -1)
      const parsedDueDate = parseISO(dueDate)
      if (status === 'paid') {
        return 'PAGADO'
      } else if (status === 'open') {
        if (isBefore(currentDate, parsedDueDate)) {
          return 'ABIERTO'
        } else {
          return 'VENCIDO'
        }
      }
      return status
    },
    async GerarQRCODE(row) {
      try {
        const response = await CriarQRCODE({
          firstName: '',
          lastName: '',
          address2: '',
          city: '',
          state: '',
          zipcode: '',
          country: '',
          useAddressForPaymentDetails: false,
          nameOnCard: '',
          cardNumber: '',
          cvv: '',
          price: row.value,
          invoiceId: row.id
        })

        if (response.data.urlPagamento) {
          this.UrlPagamentoOpen = response.data.urlPagamento

          // Mostrar mensaje de actualización antes de redirigir
          this.$q.notify({
            type: 'info',
            message: '¡Al realizar el pago, actualice la página!',
            timeout: 10000
          })

          const newWindow = window.open(this.UrlPagamentoOpen, '_blank')

          // Verificar si la nueva pestaña fue bloqueada por el navegador
          if (!newWindow || newWindow.closed || typeof newWindow.closed == 'undefined') {
            // Si la nueva pestaña fue bloqueada, redirigir la página actual
            window.location.href = this.UrlPagamentoOpen
          } else {
            // Si la nueva pestaña se abrió correctamente, mostrar un enlace de fallback
            this.$q.notify({
              type: 'info',
              message: 'Si la página de pago no se abrió, haga clic <a href="#" @click="abrirURLPagamento">aquí</a> para acceder.',
              html: true, // Permitir HTML en la notificación
              timeout: 10000 // Mantener la notificación visible por más tiempo
            })
          }
        } else if (response.data.qrcode) {
          // Si la respuesta contiene un código QR, mostrar el modal con el código QR
          this.qrCodeValue = response.data.qrcode.qrcode
          this.pixString = response.data.qrcode.qrcode
          this.showQRCodeModal = true
        } else {
          throw new Error('Respuesta inesperada del backend.')
        }
      } catch (error) {
        console.error('Error al procesar el pago:', error)
        this.$q.notify({
          type: 'negative',
          message: 'Error al procesar el pago. Intente nuevamente más tarde.'
        })
      }
    },
    abrirURLPagamento() {
      window.open(this.UrlPagamentoOpen, '_blank')
    },
    copiarPixString() {
      navigator.clipboard.writeText(this.pixString).then(() => {
        this.$q.notify({
          type: 'positive',
          message: '¡Código Pix copiado con éxito!'
        })
      }).catch((err) => {
        console.error('Error al copiar el código Pix:', err)
        this.$q.notify({
          type: 'negative',
          message: 'Error al copiar el código Pix.'
        })
      })
    }
  },
  mounted () {
    this.loadColors()
    this.fetchConfigurations()
    this.listarFinanceiro()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px
</style>
