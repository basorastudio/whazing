import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add feature flags ('group', 'campaign', 'integrations') to 'Plans' table
    await queryInterface.addColumn('Plans', 'group', {
      type: DataTypes.BOOLEAN,
      allowNull: false,    // Cannot be null
      defaultValue: true, // Default to enabled? (Original was true)
    });
    await queryInterface.addColumn('Plans', 'campaign', {
      type: DataTypes.BOOLEAN,
      allowNull: false,    // Cannot be null
      defaultValue: true, // Default to enabled? (Original was true)
    });
    await queryInterface.addColumn('Plans', 'integrations', {
      type: DataTypes.BOOLEAN,
      allowNull: false,    // Cannot be null
      defaultValue: true, // Default to enabled? (Original was true)
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added feature flag columns
    await queryInterface.removeColumn('Plans', 'integrations');
    await queryInterface.removeColumn('Plans', 'campaign');
    await queryInterface.removeColumn('Plans', 'group');
  }
};

export = migration;