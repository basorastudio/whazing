// Original: GetTicketWbotBaileys.js
// Deobfuscated, converted to TS, and translated

"use strict";

import GetDefaultWhatsApp from "./GetDefaultWhatsApp";
import { getWbot } from "../libs/wbot"; // Asumiendo exportación nombrada
import { WASocket } from "@whiskeysockets/baileys"; // Importar tipo de Baileys

// Tipos inferidos
interface TicketInstance {
  id: number;
  tenantId: number | string;
  whatsappId: number | null; // Puede ser null inicialmente
  whatsapp?: WhatsappInstance | null; // Relación opcional
  $set?: (key: string, value: any) => Promise<void>; // Para la actualización $set
  // otras propiedades...
}

interface WhatsappInstance {
  id: number;
  // otras propiedades...
}

const GetTicketWbot = async (ticket: TicketInstance): Promise<WASocket> => {
  // Si el ticket no tiene whatsappId, obtener el WhatsApp por defecto
  if (!ticket.whatsappId) {
    const defaultWhatsapp = await GetDefaultWhatsApp(ticket.tenantId);
    // Actualizar el ticket con el whatsappId obtenido
    // Usar $set si es un método disponible en tu ORM para actualizar sin guardar todo el objeto
    if (ticket.$set) {
      await ticket.$set("whatsapp", defaultWhatsapp);
      ticket.whatsappId = defaultWhatsapp.id; // Actualizar también en la instancia local
    } else {
      // Si no hay $set, necesitarías un método update o save
      console.warn(
        "Ticket instance doesn't have a $set method. whatsappId might not be persisted immediately."
      );
      ticket.whatsappId = defaultWhatsapp.id;
      // await ticket.save(); // o ticket.update({ whatsappId: defaultWhatsapp.id }); dependiendo del ORM
    }
  }

  // Obtener la instancia del bot de WhatsApp (Wbot) usando el whatsappId del ticket
  const wbot = getWbot(ticket.whatsappId as number); // Asegurar que whatsappId sea number

  return wbot as WASocket; // Castear al tipo esperado
};

export default GetTicketWbot;
