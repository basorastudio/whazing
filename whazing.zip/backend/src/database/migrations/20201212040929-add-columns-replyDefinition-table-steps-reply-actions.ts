import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'replyDefinition' (string) a la tabla 'StepsReplyActions'
    return Promise.all([
      queryInterface.addColumn("StepsReplyActions", "replyDefinition", {
        type: DataTypes.STRING,
        allowNull: true, // Permite nulos
        defaultValue: null // Valor predeterminado es null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'replyDefinition' de la tabla 'StepsReplyActions'
    return Promise.all([
      queryInterface.removeColumn("StepsReplyActions", "replyDefinition")
    ]);
  }
};
