import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla 'MessagesOffLine' para almacenar mensajes cuando no hay conexión
    return queryInterface.createTable("MessagesOffLine", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      body: {
        // Contenido del mensaje
        type: DataTypes.TEXT,
        allowNull: false
      },
      ack: {
        // Estado de confirmación (acknowledgment)
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      read: {
        // Indica si el mensaje fue leído
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      mediaType: {
        // Tipo de medio (ej: 'image', 'audio')
        type: DataTypes.STRING
      },
      mediaUrl: {
        // URL del medio adjunto
        type: DataTypes.STRING
      },
      userId: {
        type: DataTypes.INTEGER,
        references: { model: "Users", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "SET NULL"
      },
      ticketId: {
        type: DataTypes.INTEGER,
        references: { model: "Tickets", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE", // Si el ticket se elimina, se eliminan los mensajes offline asociados
        allowNull: false
      },
      fromMe: {
        // Indica si el mensaje fue enviado por el usuario del sistema
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      isDeleted: {
        // Indica si el mensaje fue eliminado
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      contactId: {
        type: DataTypes.INTEGER,
        references: { model: "Contacts", key: "id" },
        onUpdate: "CASCADE",
        onDelete: "CASCADE" // Si el contacto se elimina, se eliminan los mensajes offline asociados
      },
      quotedMsgId: {
        // ID del mensaje citado
        type: DataTypes.STRING,
        references: { model: "Messages", key: "id" }, // Referencia a la tabla Messages
        onUpdate: "CASCADE",
        onDelete: "SET NULL"
      },
      createdAt: {
        type: DataTypes.DATE(6),
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE(6),
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la tabla 'MessagesOffLine'
    return queryInterface.dropTable("MessagesOffLine");
  }
};
