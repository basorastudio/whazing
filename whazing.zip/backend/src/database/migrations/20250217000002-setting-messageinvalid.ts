import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert invalid message type warning setting into 'SettingsGeneral'
    // Translated the example message value from Portuguese to Spanish.
    const messageValue = `*Mensaje recibido no compatible con el sistema*:
Mensaje recibido del sistema, si es necesario, se puede obtener en la aplicación de WhatsApp.`;
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('messageinvalid', '${messageValue.replace(/'/g, "''")}', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `); // Escaping single quotes
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted invalid message type warning setting
    await queryInterface.bulkDelete(
      "SettingsGeneral", // Adjust schema if needed
      {
        key: ["messageinvalid"]
      }
    );
  }
};

export = migration;
