import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'recurrence' column to the 'Tenants' table
    await queryInterface.addColumn(
      "Tenants", // Table name
      "recurrence", // New column name
      {
        type: DataTypes.STRING, // Data type
        allowNull: true, // Allow null values
        defaultValue: "" // Default value is an empty string
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'recurrence' column from the 'Tenants' table
    await queryInterface.removeColumn(
      "Tenants", // Table name
      "recurrence" // Column name to remove
    );
  }
};

export = migration;
