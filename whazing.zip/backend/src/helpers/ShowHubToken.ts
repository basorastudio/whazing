import Setting from "../models/Setting"; // Assuming model path
import { RefreshToken2 as decryptToken } from "./RefreshToken"; // Use named import for decryption

const showHubToken = async (tenantId: number | string): Promise<string> => {
  const settingKey = "hubToken"; // The key used to store the token in Settings

  const setting = await Setting.findOne({
    where: {
      key: settingKey,
      tenantId: tenantId
    }
  });

  if (!setting?.value || typeof setting.value !== "string") {
    throw new Error(
      `Notificame Hub token no encontrado para el tenant ${tenantId}`
    );
  }

  // Decrypt the token before returning
  const decryptedToken = decryptToken(setting.value);

  return decryptedToken;
};

export default showHubToken;
