import HubMessageListener from "../services/WbotNotificame/HubMessageListener"; // Assuming default export after conversion

interface HandleMessageHubBackoffOptions {
  type: string;
  delay: number;
}

interface HandleMessageHubOptions {
  delay: number;
  attempts: number;
  removeOnComplete: boolean;
  removeOnFail: boolean;
  backoff: HandleMessageHubBackoffOptions;
}

interface JobData {
  message: any; // Define more specific type based on HubMessageListener input
  whatsapp: any; // Define more specific type based on HubMessageListener input
  medias?: any[]; // Define more specific type based on HubMessageListener input
}

interface Job {
  data: JobData;
  // Add other potential job properties like attemptsMade, id, etc. if needed by the queue system
}

const backoffOptions: HandleMessageHubBackoffOptions = {
  type: "fixed",
  delay: 180000 // 0x2bf20
};

const handleOptions: HandleMessageHubOptions = {
  delay: 600, // 0x258
  attempts: 10,
  removeOnComplete: true,
  removeOnFail: false, // Original: ![]
  backoff: backoffOptions
};

export const handleMessageHub = {
  key: "HandleMessageHub",
  options: handleOptions,
  async handle({ data }: Job): Promise<void> {
    try {
      const { message, whatsapp, medias } = data;
      // Assuming HubMessageListener has a static or default handle method
      await HubMessageListener.handle(message, whatsapp, medias);
    } catch (error: any) {
      console.error("Error handling Message Hub job:", error); // Logging error
      throw error; // Re-throw error for queue handler
    }
  }
};
