import { Request, Response } from "express";
import CreateChannelsService from "../services/WbotServices/WbotNoficame/CreateChannels"; // Adjusted path?
import { getIO } from "../libs/socket";
import ListChannelsService from "../services/WbotServices/WbotNoficame/ListChannels"; // Adjusted path?
import { SetChannelWebhook } from "../services/WbotServices/SetChannelWebhook";
import CheckSettingsHelper from "../helpers/CheckSettings";
import ListTotalWhatsAppService from "../services/WhatsappService/ListTotalWhatsAppService";
import AppError from "../errors/AppError";
import ListWhatsAppsService from "../services/WhatsappService/ListWhatsAppsService";
import Tenant from "../models/Tenant";
import Plan from "../models/Plan";
import { createRefreshToken } from "../helpers/RefreshToken"; // Assuming helper path

interface ChannelData {
  id: string | number;
  // Add other properties expected in the channels array
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { channels = [] }: { channels?: ChannelData[] } = req.body;
  const tenantId = Number(req.user.tenantId);

  // --- Security/Limit Checks ---
  const connectionsLimitTokenKey = "eubTI"; // Replace with actual key name if different
  const connectionsLimitTokenExpected = createRefreshToken(
    connectionsLimitTokenKey
  );
  const connectionsLimitTokenSetting = await CheckSettingsHelper(
    connectionsLimitTokenExpected
  );

  if (connectionsLimitTokenSetting !== connectionsLimitTokenExpected) {
    // Check total connections only if token doesn't match
    const totalConnections = await ListTotalWhatsAppService();
    console.log("Retrieved connections:", totalConnections); // Log for debugging
    if (totalConnections >= 1) {
      // Allow only 1 connection if token is wrong?
      throw new AppError("ERR_NO_PERMISSION_CONNECTIONS_LIMIT", 403); // More specific error
    }
  }

  // Check tenant's plan limits
  const currentConnections = await ListWhatsAppsService(tenantId);
  const tenant = await Tenant.findByPk(tenantId);
  if (!tenant) {
    throw new AppError("Tenant not found.", 404); // Should not happen if user is authenticated
  }
  const tenantPlan = await Plan.findByPk(tenant.planId);

  // Ensure plan exists and has connection limit defined
  if (!tenantPlan || typeof tenantPlan.maxConnections !== "number") {
    console.error(
      `Plan ${tenant.planId} for tenant ${tenantId} not found or maxConnections is not a number.`
    );
    throw new AppError("ERR_NO_PERMISSION_CONNECTIONS_LIMIT", 403); // Or a configuration error
  }

  if (currentConnections.length >= tenantPlan.maxConnections) {
    throw new AppError("ERR_NO_PERMISSION_CONNECTIONS_LIMIT", 403);
  }

  // --- Create Channels ---
  const serviceData = {
    tenantId: tenantId,
    channels: channels
  };

  const { whatsapps: createdChannels } =
    await CreateChannelsService(serviceData);

  // --- Set Webhooks and Emit Socket Events ---
  const io = getIO();
  createdChannels.forEach(whatsapp => {
    // Set webhook after a short delay (consider alternatives if delay is problematic)
    setTimeout(() => {
      SetChannelWebhook(whatsapp.id);
    }, 1000); // 1 second delay

    // Emit socket event
    io.to(tenantId.toString()).emit(`tenant-${tenantId}-whatsapp`, {
      // Standardize event name
      action: "update", // Or 'create' depending on frontend expectation
      whatsapp: whatsapp
    });
    // Emit to admin room as well if needed
    io.to("admin").emit(`tenant-${tenantId}-whatsapp`, {
      action: "update",
      whatsapp: whatsapp
    });
  });

  return res.status(201).json(createdChannels); // 201 Created
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  try {
    const channels = await ListChannelsService(Number(tenantId));
    return res.status(200).json(channels);
  } catch (error: any) {
    console.error("Error fetching channels:", error);
    return res
      .status(500)
      .json({ message: error.message || "Internal server error" });
  }
};
