<template>
  <div v-if="item.type === 'hub_whatsapp' && item.isApiwwjs">
    <div class="q-pt-md">
        <q-btn
          v-if="statusMessage === 'session_not_found'"
          class="generate-button btn-rounded-50"
          :class="{'generate-button-dark' : $q.dark.isActive}"
          :label="$t('canais.conectar')"
          @click="startSession"
          :loading="isLoading"
        />

        <q-btn
          v-if="statusMessage === 'session_not_connected'"
          class="generate-button btn-rounded-50"
          :class="{'generate-button-dark' : $q.dark.isActive}"
          :label="$t('canais.qrCodeWwjs')"
          @click="getQrCode"
          icon-right="mdi-qrcode-scan"
          :loading="isLoading"
        />

        <q-btn
          v-if="status === 'CONNECTED'"
          color="negative"
          :label="$t('canais.desconectarwwjs')"
          icon="eva-wifi-off-outline"
          @click="terminateSession"
          class="btn-rounded-50"
          :loading="isLoading"
        />
    </div>

    <!-- Modal para exibir o QR Code -->
    <q-dialog v-model="showQrModal">
      <q-card class="q-pa-md" style="width: 350px">
        <q-card-section class="text-center">
          <div class="text-h6">{{ $t('canais.escanearQrCode') }}</div>
          <div v-if="qrCode" class="q-mt-md">
            <!-- Usando QrcodeVue para gerar o QR code -->
            <qrcode-vue
              :value="processedQrCode"
              :size="280"
              level="H"
              render-as="canvas"
              class="mx-auto"
              ref="qrCodeComponent"
            ></qrcode-vue>
          </div>
          <div v-else-if="qrCodeError" class="q-mt-md text-negative">
            <q-icon name="mdi-alert-circle" size="50px" />
            <p>{{ qrCodeError }}</p>
          </div>
          <div v-else class="q-mt-md">
            <q-spinner color="primary" size="50px" />
          </div>
        </q-card-section>

        <q-card-actions align="center">
          <q-btn flat :label="$t('general.close')" color="primary" v-close-popup />
          <q-btn flat :label="$t('canais.atualizarQR')" icon="mdi-refresh" @click="getQrCode" :loading="isLoading" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import {
  CheckApiwwjsStatus,
  StartApiwwjsSession,
  GetApiwwjsQrCode,
  TerminateApiwwjsSession
} from 'src/service/apiwwjs'
import QrcodeVue from 'qrcode.vue'

export default {
  name: 'ItemApiwwjsStatus',
  components: {
    QrcodeVue
  },
  props: {
    item: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      status: 'DISCONNECTED',
      statusMessage: '',
      isLoading: false,
      showQrModal: false,
      qrCode: null,
      processedQrCode: null,
      qrCodeError: null,
      pollingInterval: null,
      retryCount: 0,
      maxRetries: 3
    }
  },
  methods: {
    async checkSessionStatus() {
      if (!this.item.isApiwwjs) return

      try {
        this.isLoading = true
        const response = await CheckApiwwjsStatus(this.item.id)

        // Armazenar a mensagem de status para decisões baseadas nela
        this.statusMessage = response.data.message

        if (response.data.success && response.data.state === 'CONNECTED') {
          this.status = 'CONNECTED'
        } else if (response.data.message === 'session_not_found') {
          this.status = 'DISCONNECTED'
        } else if (response.data.message === 'session_not_connected') {
          this.status = 'NEEDS_QRCODE'
        } else {
          this.status = 'DISCONNECTED'
        }
      } catch (error) {
        console.error('Error checking session status:', error)
        this.status = 'DISCONNECTED'
        this.statusMessage = 'error'
      } finally {
        this.isLoading = false
      }
    },

    async startSession() {
      // Só iniciar se o status for realmente session_not_found
      if (this.statusMessage !== 'session_not_found') {
        await this.checkSessionStatus()
        if (this.statusMessage !== 'session_not_found') return
      }

      try {
        this.isLoading = true
        this.status = 'CONNECTING'

        const response = await StartApiwwjsSession(this.item.id)

        if (response.data.success) {
          this.$q.notify({
            type: 'positive',
            message: this.$t('canais.sessaoIniciada')
          })

          // Verificar o status após iniciar a sessão
          await this.checkSessionStatus()

          // Se estiver esperando QR code
          if (this.statusMessage === 'session_not_connected') {
            this.getQrCode()
          }
        }
      } catch (error) {
        console.error('Error starting session:', error)
        this.status = 'DISCONNECTED'
        this.$q.notify({
          type: 'negative',
          message: this.$t('canais.erroIniciarSessao')
        })
      } finally {
        this.isLoading = false
      }
    },

    async getQrCode() {
      try {
        this.isLoading = true
        this.showQrModal = true
        this.qrCodeError = null
        this.qrCode = null
        this.processedQrCode = null

        const response = await GetApiwwjsQrCode(this.item.id)

        if (response.data.success && response.data.qr) {
          this.qrCode = response.data.qr
          this.status = 'NEEDS_QRCODE'

          // Processar o QR code dependendo do formato
          this.processQrCode(this.qrCode)

          // Iniciar um polling para verificar se o QR code foi escaneado
          this.startPolling()
          this.retryCount = 0
        } else {
          // Verificar mensagem específica de erro
          if (response.data.message === 'qr code not ready or already scanned') {
            this.qrCodeError = this.$t('canais.qrnaoestapronto')

            // Tentar novamente após um período se ainda não atingiu o limite de tentativas
            if (this.retryCount < this.maxRetries) {
              this.retryCount++
              setTimeout(() => this.getQrCode(), 3000)
            }
          } else {
            this.qrCodeError = this.$t('canais.erroObterQrCode')
            this.$q.notify({
              type: 'negative',
              message: this.$t('canais.erroObterQrCode')
            })
          }
        }
      } catch (error) {
        console.error('Error getting QR code:', error)
        this.qrCodeError = this.$t('canais.erroObterQrCode')
        this.$q.notify({
          type: 'negative',
          message: this.$t('canais.erroObterQrCode')
        })
      } finally {
        this.isLoading = false
      }
    },

    processQrCode(qrCode) {
      // Verificar o formato do QR code
      if (typeof qrCode === 'string') {
        // Se for uma string, usar diretamente
        this.processedQrCode = qrCode
      } else if (qrCode && typeof qrCode === 'object') {
        // Se for um objeto, transformar em string JSON
        this.processedQrCode = JSON.stringify(qrCode)
      } else {
        // Fallback para um valor padrão
        this.processedQrCode = ''
        this.qrCodeError = this.$t('canais.erroObterQrCode')
      }
    },
    async terminateSession() {
      try {
        this.isLoading = true

        const response = await TerminateApiwwjsSession(this.item.id)

        if (response.data.success) {
          this.status = 'DISCONNECTED'
          this.statusMessage = 'session_not_found'
          this.$q.notify({
            type: 'positive',
            message: this.$t('canais.sessaoEncerrada')
          })

          // Parar de verificar o status
          this.stopPolling()
        }
      } catch (error) {
        console.error('Error terminating session:', error)
        this.$q.notify({
          type: 'negative',
          message: this.$t('canais.erroEncerrarSessao')
        })
      } finally {
        this.isLoading = false
      }
    },

    startPolling() {
      // Parar polling anterior, se existir
      this.stopPolling()

      // Iniciar um novo intervalo de polling
      this.pollingInterval = setInterval(() => {
        this.checkSessionStatus().then(() => {
          // Se conectado, fechar o modal e parar de verificar
          if (this.status === 'CONNECTED') {
            this.showQrModal = false
            this.stopPolling()
            this.$q.notify({
              type: 'positive',
              message: this.$t('canais.conectadoComSucesso')
            })
          }
        })
      }, 5000) // Verificar a cada 5 segundos
    },

    stopPolling() {
      if (this.pollingInterval) {
        clearInterval(this.pollingInterval)
        this.pollingInterval = null
      }
    }
  },
  mounted() {
    // Verificar status inicial
    if (this.item.type === 'hub_whatsapp' && this.item.isApiwwjs) {
      this.checkSessionStatus()
    }
  },
  beforeDestroy() {
    // Garantir que o polling seja interrompido quando o componente for destruído
    this.stopPolling()
  }
}
</script>
