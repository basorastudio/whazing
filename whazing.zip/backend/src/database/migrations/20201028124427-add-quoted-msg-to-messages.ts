import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna quotedMsgId a la tabla Messages
    return queryInterface.addColumn("Messages", "quotedMsgId", {
      // Nombre de columna preservado
      type: DataTypes.STRING, // Asumiendo que es el ID del mensaje de WhatsApp
      references: {
        model: "Messages", // Auto-referencia a la misma tabla
        key: "id"
      },
      onUpdate: "CASCADE",
      onDelete: "SET NULL", // Si el mensaje citado se elimina, mantener la referencia como nula
      allowNull: true // Puede no haber mensaje citado
    });
    // Nota: La restricción de clave externa fue eliminada en la migración 20210721052241.
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna quotedMsgId
    return queryInterface.removeColumn("Messages", "quotedMsgId");
  }
};
