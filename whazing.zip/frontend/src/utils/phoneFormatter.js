class FormatMask {
  setPhoneFormatMask(phoneToFormat) {
    if (!phoneToFormat || phoneToFormat.length < 10) {
      return
    }

    const number = ('' + phoneToFormat).replace(/\D/g, '')

    // Dominican Republic format: +1 (809/829/849) XXX-XXXX
    if (number.length === 10) {
      const phoneNumberFormatted = number.match(/^(\d{3})(\d{3})(\d{4})$/)
      return (
        '+1' +
        ' (' +
        phoneNumberFormatted[1] +
        ') ' +
        phoneNumberFormatted[2] +
        '-' +
        phoneNumberFormatted[3]
      )
    } else if (number.length === 11 && number.startsWith('1')) {
      // If number includes country code (1)
      const phoneNumberFormatted = number.match(/^1(\d{3})(\d{3})(\d{4})$/)
      return (
        '+1' +
        ' (' +
        phoneNumberFormatted[1] +
        ') ' +
        phoneNumberFormatted[2] +
        '-' +
        phoneNumberFormatted[3]
      )
    }

    return null
  }

  removeMask(number) {
    const filterNumber = number.replace(/\D/g, '')
    return filterNumber
  }

  maskPhonePattern(phoneNumber) {
    return '+1 (999) 999-9999'
  }
}

export { FormatMask }

const formatSerializedId = (serializedId) => {
  const formatMask = new FormatMask()
  const number = serializedId?.replace('@c.us', '')

  return formatMask.setPhoneFormatMask(number)?.replace('+1', '🇩🇴')
}

export default formatSerializedId
