import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'unreadMessages' (INTEGER) a la tabla 'Tickets'
    return Promise.all([
      queryInterface.addColumn('Tickets', 'unreadMessages', {
        type: DataTypes.INTEGER
        // Nota: No define allowNull ni defaultValue, podría heredar defaults de la DB o ser NOT NULL
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'unreadMessages' de la tabla 'Tickets'
    return Promise.all([
      queryInterface.removeColumn('Tickets', 'unreadMessages')
    ]);
  }
};