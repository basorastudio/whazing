<template>
  <div class="mass-container container-rounded-10" :class="$q.dark.isActive ? ('text-white bg-grey-10') : 'container-border'">
    <q-list class="text-weight-medium"/>
    <q-item-label header :class="['text-bold text-h6 q-mb-lg', $q.dark.isActive ? 'text-color-dark' : 'text-black']">
      {{ $t('configuracaosaas.titulo') }}
    </q-item-label>

    <q-item-label caption class="q-mt-lg q-pl-sm">{{ $t('configuracaosaas.configuracao_teste.titulo') }}</q-item-label>
    <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.configuracao_teste.permitir_teste') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.configuracao_teste.descricao_permitir') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="allowSignup" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="allowSignup === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('allowSignup')" />
        </q-item-section>
      </q-item>
      <div class="row q-px-md" v-if="allowSignup === 'enabled'">
        <div class="col-12">
          <q-input v-model="timeTest" type="number" autogrow dense outlined
                   :label="$t('configuracaosaas.configuracao_teste.tempo_dias')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('timeTest')" />
        </div>
      </div>

      <div v-if="allowSignup === 'enabled'">
      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.configuracao_teste.habilitar_whatsapp') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.configuracao_teste.descricao_whatsapp') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="apienviarwhatsapp" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="apienviarwhatsapp === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('apienviarwhatsapp')" />
        </q-item-section>
      </q-item>

        <div class="col-12" v-if="apienviarwhatsapp === 'enabled'">
          <q-input v-model="apiendpoint" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.configuracao_teste.url_api')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('apiendpoint')" />
          <q-input v-model="apitoken" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.configuracao_teste.token')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('apitoken')" />
            <textarea ref="apimessage"
              style="min-height: 15vh; max-height: 15vh;"
              class="q-pa-sm bg-white full-width"
              :placeholder="$t('configuracaosaas.configuracao_teste.digite_mensagem')"
              autogrow
              dense
              outlined
              @input="atualizarConfiguracao('apimessage')"
              v-model="apimessage" />
          <q-btn round
            flat
            dense>
            <q-icon size="2em"
                    class="color-light1"
                    :class="$q.dark.isActive ? ('color-dark1') : ''"
              name="mdi-variable" />
            <q-tooltip>
              {{ $t('configuracaosaas.configuracao_teste.variaveis') }}
            </q-tooltip>
            <q-menu touch-position>
              <q-list dense
                style="min-width: 100px">
                <q-item v-for="variavel in variaveis"
                  :key="variavel.label"
                  clickable
                  @click="onInsertSelectVariable(variavel.value)"
                  v-close-popup>
                  <q-item-section>{{ variavel.label }}</q-item-section>
                </q-item>
              </q-list>
            </q-menu>
          </q-btn>
             <q-btn
                round
                flat
                class="q-ml-sm"
              >
              <q-icon
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                size="2em"
                name="mdi-emoticon-happy-outline"
              />
              <q-tooltip>
                {{ $t('configuracaosaas.configuracao_teste.emoji') }}
              </q-tooltip>
              <q-menu
                anchor="top right"
                self="bottom middle"
                :offset="[5, 40]"
              >
                <VEmojiPicker
                  style="width: 40vw"
                  :showSearch="true"
                  :emojisByRow="20"
                  :labelSearch="$t('configuracaosaas.configuracao_teste.localizar')"
                  lang="pt-BR"
                  @select="onInsertSelectEmoji"
                />
              </q-menu>
            </q-btn>
        </div>

        </div>

    <q-item-label caption class="q-mt-lg q-pl-sm">{{ $t('configuracaosaas.informativo.titulo') }}</q-item-label>
    <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.informativo.exibir') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.informativo.descricao') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="informative" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="informative === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('informative')" />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="informative === 'enabled'">
        <div class="col-12">
          <q-input v-model="textinformative" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.informativo.texto')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('textinformative')" />
        </div>
      </div>

      <div class="row q-px-md" v-if="informative === 'enabled'">
        <div class="col-12">
          <q-input
            :label="$t('configuracaosaas.informativo.cor_fundo')"
            autogrow dense outlined
            :style="`background: ${colorinformative}`"
            v-model="colorinformative"
            input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            :dark="false"
            @input="atualizarConfiguracao('colorinformative')"
          >
            <template v-slot:preappend></template>
            <template v-slot:append>
              <q-icon
                name="colorize"
                class="cursor-pointer"
                @click="openColorPicker = true"
              ></q-icon>
              <q-popup-proxy
                v-model="openColorPicker"
                transition-show="scale"
                transition-hide="scale"
              >
                <q-color
                  format-model="hex"
                  square
                  default-view="palette"
                  no-header
                  bordered
                  v-model="colorinformative"
                  @input="atualizarConfiguracao('colorinformative')"
                />
              </q-popup-proxy>
            </template>
          </q-input>
        </div>
      </div>

      <div class="row q-px-md" v-if="informative === 'enabled'">
        <div class="col-12">
          <q-input
            :label="$t('configuracaosaas.informativo.cor_texto')"
            autogrow dense outlined
            :style="`background: ${colorinformativetext}`"
            v-model="colorinformativetext"
            input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            :dark="false"
            @input="atualizarConfiguracao('colorinformativetext')"
          >
            <template v-slot:preappend></template>
            <template v-slot:append>
              <q-icon
                name="colorize"
                class="cursor-pointer"
                @click="openColorPicker2 = true"
              ></q-icon>
              <q-popup-proxy
                v-model="openColorPicker2"
                transition-show="scale"
                transition-hide="scale"
              >
                <q-color
                  format-model="hex"
                  square
                  default-view="palette"
                  no-header
                  bordered
                  v-model="colorinformativetext"
                  @input="atualizarConfiguracao('colorinformativetext')"
                />
              </q-popup-proxy>
            </template>
          </q-input>
        </div>
      </div>

    <q-item-label caption class="q-mt-lg q-pl-sm">{{ $t('configuracaosaas.pagamento.titulo') }}</q-item-label>
    <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.selecionar_gateway') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.pagamento.descricao_gateway') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-select style="width: 300px" outlined dense v-model="paymentGateway" :options="optionsPagamentosTypes" map-options
            emit-value option-value="value" option-label="label" @input="atualizarConfiguracao('paymentGateway')" />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="paymentGateway === 'efi'">
        <div class="col-12">
          <q-input v-model="efiClientId" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.efi.client_id')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('efiClientId')" />
          <q-input v-model="efiClientSecret" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.efi.client_secret')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('efiClientSecret')" />
          <q-input v-model="efiPixKey" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.efi.pix_key')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('efiPixKey')" />
      <!-- Campo de Upload -->
          <q-input v-model="efiCertFile" readonly type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.efi.certificado')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
             />
      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.efi.enviar_certificado') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <input type="file" @change="onFileChange" ref="fileInput" class="q-mt-md" />
        </q-item-section>
      </q-item>
        </div>
      </div>

      <div class="row q-px-md" v-if="paymentGateway === 'owen'">
        <div class="col-12">
          <q-input v-model="owenCnpj" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.owen.cnpj')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('owenCnpj')" />
          <q-input v-model="owenToken" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.owen.token')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('owenToken')" />
          <q-input v-model="owenSecretKey" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.owen.secret_key')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('owenSecretKey')" />
        </div>
      </div>

    <div class="row q-px-md" v-if="paymentGateway === 'stripe'">
      <div class="col-12">
        <q-input v-model="keyStripe" type="textarea" autogrow dense outlined
                 :label="$t('configuracaosaas.pagamento.stripe.chave_secreta')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                 @input="atualizarConfiguracao('keyStripe')" />
      </div>
    </div>

      <div class="row q-px-md" v-if="paymentGateway === 'mercadopago'">
        <div class="col-12">
          <q-input v-model="keyMp" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.mercadopago.access_token')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('keyMp')" />
      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.mercadopago.aceitar_pix') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.pagamento.mercadopago.descricao_pix') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="mp_pix" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="mp_pix === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('mp_pix')" />
        </q-item-section>
      </q-item>
      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.mercadopago.aceitar_boleto') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="mp_boleto" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="mp_boleto === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('mp_boleto')" />
        </q-item-section>
      </q-item>
      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.mercadopago.aceitar_cartao') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="mp_cartao" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="mp_cartao === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('mp_cartao')" />
        </q-item-section>
      </q-item>
      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.mercadopago.aceitar_debito') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="mp_debito" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="mp_debito === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('mp_debito')" />
        </q-item-section>
      </q-item>

        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.mercadopago.webhook.titulo') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.pagamento.mercadopago.webhook.notificacoes') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.pagamento.mercadopago.webhook.configurar') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.pagamento.mercadopago.webhook.modo_producao') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.pagamento.mercadopago.webhook.url_producao') }}</q-item-label>
          <q-input v-model="webhookUrl" readonly type="textarea" autogrow dense outlined
            input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
             />
          <q-item-label caption>{{ $t('configuracaosaas.pagamento.mercadopago.webhook.eventos') }}</q-item-label>
        </q-item-section>
        </div>
      </div>

      <div class="row q-px-md" v-if="paymentGateway === 'asaas'">
          <q-item-label>{{ $t('configuracaosaas.pagamento.asaas.instrucao') }}</q-item-label>
        <div class="col-12">
          <q-input v-model="keyAsaas" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.pagamento.asaas.chave_api')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('keyAsaas')" />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.asaas.formas_pagamento.titulo') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.pagamento.asaas.formas_pagamento.descricao') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-select style="width: 300px" outlined dense v-model="billingType_Asaas" :options="optionsAsaasBilling" map-options
            emit-value option-value="value" option-label="label" @input="atualizarConfiguracao('billingType_Asaas')" />
        </q-item-section>
      </q-item>

        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.pagamento.asaas.webhook.titulo') }}</q-item-label>
          <q-item-label :class="$q.dark.isActive ? 'text-white' : ''">
            {{ $t('configuracaosaas.pagamento.asaas.webhook.adicionar') }}</q-item-label>
          <q-item-label :class="$q.dark.isActive ? 'text-white' : ''">
            {{ $t('configuracaosaas.pagamento.asaas.webhook.ativo') }}</q-item-label>
          <q-item-label :class="$q.dark.isActive ? 'text-white' : ''">
            {{ $t('configuracaosaas.pagamento.asaas.webhook.url') }}</q-item-label>
          <q-input v-model="webhookUrl" readonly type="textarea" autogrow dense outlined
                   input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
             />
          <q-item-label :class="$q.dark.isActive ? 'text-white' : ''">
            {{ $t('configuracaosaas.pagamento.asaas.webhook.email') }}</q-item-label>
          <q-item-label :class="$q.dark.isActive ? 'text-white' : ''">
            {{ $t('configuracaosaas.pagamento.asaas.webhook.versao') }}</q-item-label>
          <q-item-label :class="$q.dark.isActive ? 'text-white' : ''">
            {{ $t('configuracaosaas.pagamento.asaas.webhook.fila') }}</q-item-label>
          <q-item-label :class="$q.dark.isActive ? 'text-white' : ''">
            {{ $t('configuracaosaas.pagamento.asaas.webhook.tipo_envio') }}</q-item-label>
          <q-item-label :class="$q.dark.isActive ? 'text-white' : ''">
            {{ $t('configuracaosaas.pagamento.asaas.webhook.eventos') }}</q-item-label>
        </q-item-section>
        </div>
      </div>

    <q-item-label caption class="q-mt-lg q-pl-sm">{{ $t('configuracaosaas.recuperacao_senha.titulo') }}</q-item-label>
    <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.recuperacao_senha.habilitar_email') }}</q-item-label>
          <q-item-label caption>{{ $t('configuracaosaas.recuperacao_senha.descricao_email') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="habilitasmtp" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="habilitasmtp === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('habilitasmtp')" />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="habilitasmtp === 'enabled'">
        <div class="col-12">
        <q-item-section>
          <q-item-label :class="$q.dark.isActive ? ('text-color-dark') : ''">{{ $t('configuracaosaas.recuperacao_senha.servidor_smtp') }}</q-item-label>
        </q-item-section>
          <q-input v-model="smtp" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.smtp')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('smtp')" />
          <q-input v-model="usuariosmtp" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.usuario')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('usuariosmtp')" />
          <q-input v-model="senhasmtp" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.senha')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('senhasmtp')" />
          <q-input v-model="fromemail" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.from')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('fromemail')" />
          <q-input v-model="portasmtp" type="number" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.porta')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('portasmtp')" />
      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.recuperacao_senha.ssl_tls') }}</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="smtpsecure" false-value="false" true-value="true" checked-icon="check"
            keep-color :color="smtpsecure === 'true' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('smtpsecure')" />
        </q-item-section>
      </q-item>

          <q-item-section>
            <q-item-label :class="$q.dark.isActive ? ('text-color-dark') : ''">{{ $t('configuracaosaas.recuperacao_senha.personalizacao.titulo') }}</q-item-label>
          </q-item-section>

          <q-input v-model="subjectemail" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.personalizacao.assunto')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                   @input="atualizarConfiguracao('subjectemail')" />
          <q-input v-model="emailtop" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.personalizacao.titulo_email')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                   @input="atualizarConfiguracao('emailtop')" />
          <q-input v-model="emaillinha2" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.personalizacao.linha1')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                   @input="atualizarConfiguracao('emaillinha2')" />
          <q-input v-model="emaillinha3" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.personalizacao.linha2')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                   @input="atualizarConfiguracao('emaillinha3')" />
          <q-input v-model="emaillinha4" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.personalizacao.linha3')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                   @input="atualizarConfiguracao('emaillinha4')" />
          <q-input v-model="emaillinha5" type="textarea" autogrow dense outlined
                   :label="$t('configuracaosaas.recuperacao_senha.personalizacao.linha4')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                   @input="atualizarConfiguracao('emaillinha5')" />
        </div>
      </div>

    <q-item-label caption class="q-mt-lg q-pl-sm">{{ $t('configuracaosaas.configuracoes_gerais.titulo') }}</q-item-label>
    <q-separator spaced />

    <div class="row q-px-md">
      <div class="col-12">
       <q-item-section>
        <q-item-section>
          <q-item-label>{{ $t('configuracaosaas.configuracoes_gerais.limite_arquivos') }}</q-item-label>
        </q-item-section>
          <q-input v-model="downloadLimit" type="number" autogrow dense outlined
                   :label="$t('configuracaosaas.configuracoes_gerais.limite_download')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('downloadLimit')"
            style="margin-bottom: 10px;"
          />
        </q-item-section>

            <q-input v-model="limitmessage" type="textarea" autogrow dense outlined
                     :label="$t('configuracaosaas.configuracoes_gerais.mensagens.arquivo_limite')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                     @input="atualizarConfiguracao('limitmessage')" />

        <q-input v-model="messageinvalid" type="textarea" autogrow dense outlined
                 :label="$t('configuracaosaas.configuracoes_gerais.mensagens.nao_compativel')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                 @input="atualizarConfiguracao('messageinvalid')" />

        <q-input v-model="errodownloadmedia" type="textarea" autogrow dense outlined
                 :label="$t('configuracaosaas.configuracoes_gerais.mensagens.erro_download')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                 @input="atualizarConfiguracao('errodownloadmedia')" />

        <q-input v-model="errotranscricao" type="textarea" autogrow dense outlined
                 :label="$t('configuracaosaas.configuracoes_gerais.mensagens.erro_transcricao')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                 @input="atualizarConfiguracao('errotranscricao')" />

        <q-input v-model="toporespostaaudio" type="textarea" autogrow dense outlined
                 :label="$t('configuracaosaas.configuracoes_gerais.mensagens.topo_resposta')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                 @input="atualizarConfiguracao('toporespostaaudio')" />

        <q-input v-model="respostaaudio" type="textarea" autogrow dense outlined
                 :label="$t('configuracaosaas.configuracoes_gerais.mensagens.fim_resposta')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                 @input="atualizarConfiguracao('respostaaudio')" />

      </div>
    </div>

  </div>
</template>

<script>
import { ListarConfiguracoesGeneral, AlterarConfiguracaoGeneral, enviarArquivoPrivado } from 'src/service/configuracoesgeneral'
import { VEmojiPicker } from 'v-emoji-picker'

export default {
  components: { VEmojiPicker },
  name: 'ConfiguracoesSaaS',
  data() {
    return {
      optionsPagamentosTypes: [
        { label: this.$t('configuracaosaas.pagamento.gateway.desativar'), value: 'disabled' },
        { label: this.$t('configuracaosaas.pagamento.gateway.mercadopago'), value: 'mercadopago' },
        { label: this.$t('configuracaosaas.pagamento.gateway.asaas'), value: 'asaas' },
        { label: this.$t('configuracaosaas.pagamento.gateway.efi'), value: 'efi' },
        { label: this.$t('configuracaosaas.pagamento.gateway.owen'), value: 'owen' },
        { label: this.$t('configuracaosaas.pagamento.gateway.stripe'), value: 'stripe' }
      ],
      optionsAsaasBilling: [
        { label: this.$t('configuracaosaas.pagamento.asaas.formas_pagamento.todos'), value: 'UNDEFINED' },
        { label: this.$t('configuracaosaas.pagamento.asaas.formas_pagamento.boleto_pix'), value: 'BOLETO' },
        { label: this.$t('configuracaosaas.pagamento.asaas.formas_pagamento.cartao'), value: 'CREDIT_CARD' },
        { label: this.$t('configuracaosaas.pagamento.asaas.formas_pagamento.pix'), value: 'PIX' }
      ],
      variaveis: [
        { label: this.$t('configuracaosaas.variaveis.nomeempresa'), value: '{{nomeempresa}}' },
        { label: this.$t('configuracaosaas.variaveis.nomeresponsavel'), value: '{{nomeresponsavel}}' },
        { label: this.$t('configuracaosaas.variaveis.email'), value: '{{email}}' },
        { label: this.$t('configuracaosaas.variaveis.senha'), value: '{{senha}}' }
      ],
      configuracoes: [],
      webhookUrl: '',
      allowSignup: null,
      apienviarwhatsapp: null,
      apiendpoint: '',
      apitoken: '',
      apiexternalKey: '',
      apimessage: '',
      timeTest: '',
      informative: null,
      limitmessage: null,
      messageinvalid: null,
      errodownloadmedia: null,
      paymentGateway: null,
      textinformative: '',
      colorinformative: '',
      colorinformativetext: '',
      openColorPicker: false,
      openColorPicker2: false,
      efiClientId: '',
      efiClientSecret: '',
      efiPixKey: '',
      owenCnpj: '',
      owenToken: '',
      owenSecretKey: '',
      efiCertFile: '',
      keyMp: '',
      keyAsaas: '',
      keyStripe: '',
      billingType_Asaas: '',
      mp_boleto: null,
      mp_pix: null,
      mp_cartao: null,
      mp_debito: null,
      smtp: '',
      usuariosmtp: '',
      senhasmtp: '',
      fromemail: '',
      portasmtp: '',
      smtpsecure: '',
      downloadLimit: '',
      subjectemail: '',
      emailtop: '',
      emaillinha2: '',
      emaillinha3: '',
      emaillinha4: '',
      emaillinha5: '',
      errotranscricao: '',
      respostaaudio: '',
      toporespostaaudio: '',
      title: '',
      filename: '',
      habilitasmtp: '',
      selectedFileType: null,
      fileAcceptType: '',
      whatsappnumber: null
    }
  },
  methods: {
    generateWebhookUrl() {
      return `${process.env.URL_API}/subscription/whazing/webhook/`
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.apimessage
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!emoji.data) {
        return
      }
      // insert:
      self.txtContent = this.apimessage
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.apimessage = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    onInsertSelectVariable (variable) {
      const self = this
      var tArea = this.$refs.apimessage
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!variable) {
        return
      }
      // insert:
      self.txtContent = this.apimessage
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.apimessage = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    },
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoesGeneral()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        const value = el.value
        this.$data[el.key] = value
      })
    },
    async atualizarConfiguracao(key) {
      const params = {
        key,
        value: this.$data[key]
      }
      try {
        await AlterarConfiguracaoGeneral(params)
        this.$q.notify({
          type: 'positive',
          message: this.$t('configuracaosaas.notificacoes.configuracao_alterada'),
          progress: true,
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (error) {
        console.error('error - AlterarConfiguracao', error)
        this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
        this.$notificarErro(this.$t('configuracaosaas.notificacoes.erro_alteracao'), error)
      }
    },
    async onFileChange(event) {
      const file = event.target.files[0]
      if (file) {
        try {
          await enviarArquivoPrivado(file)
          this.efiCertFile = file.name
          this.$q.notify({
            type: 'positive',
            message: this.$t('configuracaosaas.notificacoes.arquivo_sucesso'),
            progress: true,
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } catch (error) {
          console.error('Erro ao enviar arquivo', error)
          this.$q.notify({
            type: 'negative',
            message: this.$t('configuracaosaas.notificacoes.erro_arquivo'),
            progress: true,
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        }
      }
    }
  },
  async mounted() {
    await this.listarConfiguracoes()
    this.webhookUrl = this.generateWebhookUrl()
  }
}
</script>

<style scoped>
.file-upload-container {
  position: relative;
  display: inline-block;
}

.file-input {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
  cursor: pointer;
}

.file-upload-button {
  background-color: #007bff; /* Cor de fundo do botão no tema claro */
  color: #fff; /* Cor do texto do botão */
  border: none;
  border-radius: 12px; /* Arredondar os cantos do botão */
  padding: 8px 16px;
  cursor: pointer;
  font-size: 14px;
}

.file-upload-button:hover {
  background-color: #0056b3; /* Cor do botão ao passar o mouse */
}

.generate-button-dark {
  background-color: #28a745; /* Cor de fundo do botão no tema escuro */
}
</style>
