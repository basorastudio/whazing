
<template>
  <div>
    <q-card flat class="q-pa-sm q-pb-md">
      <q-card-section class="q-pa-none">
        <div class="text-subtitle2 q-mb-sm">
          {{ $t('ccFlowBuilder.addbutton') }}
        </div>
        <div class="q-mb-md">
          <textarea
            style="min-height: 5vh; max-height: 15vh; width: 100%"
            class="q-pa-sm bg-white"
            :placeholder="$t('ccFlowBuilder.digiteTituloBotoes')"
            autogrow
            dense
            outlined
            required
            @input="(v) => $attrs.element.data.text = v.target.value"
            :value="$attrs.element.data.text">
          </textarea>
        </div>

        <!-- Button list -->
        <div class="q-mb-md">
          <div class="text-caption q-mb-xs">{{ $t('ccFlowBuilder.botoes') }} ({{ $t('ccFlowBuilder.min2max3') }})</div>

          <div v-for="(button, index) in $attrs.element.data.buttons" :key="index" class="q-mb-sm">
            <div class="row q-col-gutter-sm items-center">
              <div class="col">
                <q-input
                  dense
                  outlined
                  required
                  v-model="button.title"
                  :label="$t('ccFlowBuilder.tituloBotao')"
                />
              </div>
              <div class="col-auto">
                <q-btn
                  flat
                  round
                  color="negative"
                  icon="mdi-delete"
                  @click="removeButton(index)"
                  :disable="$attrs.element.data.buttons.length <= 2"
                >
                  <q-tooltip>{{ $t('general.remover') }}</q-tooltip>
                </q-btn>
              </div>
            </div>
          </div>

          <!-- Add button control -->
          <div class="text-center q-mt-md">
            <q-btn
              outline
              class="q-mr-sm generate-button btn-rounded-50"
              :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="mdi-plus"
              :label="$t('ccFlowBuilder.adicionarBotao')"
              @click="addButton"
              :disable="$attrs.element.data.buttons.length >= 3"
            />
          </div>
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
export default {
  name: 'ButtonsField',
  data () {
    return {}
  },
  mounted () {
    if (!this.$attrs.element.data.buttons || !this.$attrs.element.data.buttons.length) {
      this.$attrs.element.data.buttons = [
        { id: 1, title: '' },
        { id: 2, title: '' }
      ]
    } else {
      this.reindexButtons()
    }

    if (!this.$attrs.element.data.text) {
      this.$attrs.element.data.text = ''
    }
  },
  methods: {
    addButton () {
      if (this.$attrs.element.data.buttons.length < 3) {
        const nextId = this.$attrs.element.data.buttons.length + 1
        this.$attrs.element.data.buttons.push({
          id: nextId,
          title: ''
        })
      }
    },
    removeButton (index) {
      if (this.$attrs.element.data.buttons.length > 2) {
        this.$attrs.element.data.buttons.splice(index, 1)
        this.reindexButtons()
      }
    },
    reindexButtons () {
      this.$attrs.element.data.buttons.forEach((button, index) => {
        button.id = index + 1
      })
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
