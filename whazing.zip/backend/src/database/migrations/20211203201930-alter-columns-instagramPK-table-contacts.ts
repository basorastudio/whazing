import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Cambia el tipo de la columna 'instagramPK' a BIGINT en 'Contacts'
    return Promise.all([
      queryInterface.changeColumn("Contacts", "instagramPK", {
        type: DataTypes.BIGINT, // Cambia a BIGINT
        allowNull: true, // Mantiene allowNull como true
        defaultValue: null // Mantiene defaultValue como null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Revierte el cambio de tipo de 'instagramPK' a INTEGER
    return Promise.all([
      queryInterface.changeColumn("Contacts", "instagramPK", {
        type: DataTypes.INTEGER, // Vuelve a INTEGER
        allowNull: true,
        defaultValue: null
      })
    ]);
  }
};
