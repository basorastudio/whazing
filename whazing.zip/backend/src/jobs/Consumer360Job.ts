import FindUpdateTicketsInactiveChatBot from '../services/Tickets/FindUpdateTicketsInactiveChatBot'; // Assuming default export
import { logger } from '../utils/logger';

interface Consumer360BackoffOptions {
    every: number; // milliseconds
}

interface Consumer360Options {
    removeOnComplete: boolean;
    removeOnFail: boolean;
    jobId: string;
    repeat: Consumer360BackoffOptions;
}

const repeatOptions: Consumer360BackoffOptions = {
    every: 900000 // (0xb96 + -0x808 + 0x389 * -0x1) * (...) * (...) = 1 * 30 * 30000 = 900000 ms (15 minutes)
};

const handleOptions: Consumer360Options = {
    removeOnComplete: true,
    removeOnFail: false, // Original: ![]
    jobId: 'Consumer360Job',
    repeat: repeatOptions
};

export const Consumer360Job = {
    key: 'Consumer360Job',
    options: handleOptions,
    async handle(): Promise<void> {
        const logPrefix = 'Consumer360Job';
        try {
            logger.info(`${logPrefix}: Iniciado`); // Original: Consumer360Job Initiated
            await FindUpdateTicketsInactiveChatBot(); // Assuming it's a function to call
            logger.info(`${logPrefix}: Finalizado`); // Original: Finalized Consumer360Job
        } catch (error: any) {
             logger.error({
                 message: `Error al procesar ${logPrefix}`, // Original: Error send messages
                 error: error?.message,
                 originalError: error
             });
             if (error instanceof Error) {
                throw error;
             } else {
                throw new Error(String(error));
             }
        }
    }
};