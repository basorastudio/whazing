import FindOrCreateTicketService from "../services/TicketServices/FindOrCreateTicketService";
import CreateMessageSystemService from "../services/MessageServices/CreateMessageSystemService";
import { getWbot } from "../libs/wbot";
import Contact from "../models/Contact";
import CreateContactService from "../services/ContactServices/CreateContactService";
import AppError from "../errors/AppError";
import ShowTicketService from "../services/TicketServices/ShowTicketService";
import socketEmit from "../helpers/socketEmit"; // Assuming default export
import Ticket from "../models/Ticket";
import Whatsapp from "../models/Whatsapp";
import { RefreshToken } from "../helpers/RefreshToken"; // Assuming named export
import CheckSettingsHelper from "../helpers/CheckSettingsHelper"; // Assuming default export
import { FindOptions, WhereOptions, Attributes } from "sequelize"; // Import necessary Sequelize types

// Define interfaces for the data structures
interface ApiMessagePayload {
  number: string; // Target number
  body?: string; // Message body (text)
  mediaUrl?: string; // URL for media
  mediaType?: string; // Mime type for media
  timestamp?: number; // Optional timestamp
  externalKey?: string; // Optional external key
  buttonText?: string; // For buttons
  buttonUrl?: string; // For buttons (cta_url)
  buttonType?: "cta_url" | "quick_reply" | "list" | "template"; // Example button types
  buttons?: any[]; // Array of button objects
  listBody?: string; // For list messages
  listButtonText?: string; // For list messages
  listSections?: any[]; // For list messages
  templateName?: string; // For template messages
  templateVariables?: Record<string, string>; // For template messages
  // Add other potential payload properties based on API capabilities
}

interface ApiJobData {
  sessionId: number; // Corresponds to whatsappId
  tenantId: number | string;
  payload: ApiMessagePayload;
  apiConfig?: any; // Optional API configuration details (e.g., specific endpoint, auth)
}

interface Job {
  data: ApiJobData;
}

interface HandleOptions {
  delay: number;
  attempts: number;
  removeOnComplete: boolean;
  removeOnFail: boolean;
  // backoff option was present but unused in the simplified version
}

// Default options from original code
const handleOptions: HandleOptions = {
  delay: 100, // 0x64
  attempts: 5,
  removeOnComplete: true,
  removeOnFail: false // Original: ![]
  // backoff: { type: 'fixed', delay: 5000 /* 0x1388 */ }
};

export const SendMessageAPI = {
  key: "SendMessageAPI",
  options: handleOptions,
  async handle({ data }: Job): Promise<void> {
    const { sessionId, tenantId, payload, apiConfig } = data;
    const whatsappId = sessionId; // Use sessionId as whatsappId

    const logPrefix = `SendMessageAPI::Tenant-${tenantId}::Session-${whatsappId}`;

    // 1. Get WhatsApp Connection Details
    const whereWhatsapp: WhereOptions = { id: whatsappId };
    const attributesWhatsapp: Attributes<Whatsapp> = ["channel"];
    const whatsapp = await Whatsapp.findOne({
      where: whereWhatsapp,
      attributes: attributesWhatsapp
    });

    if (!whatsapp) {
      throw new AppError(
        `ERR_WHATSAPP_NOT_FOUND: WhatsApp session ${whatsappId} not found.`,
        404
      );
    }

    // Use wbot only if channel is 'whatsapp' (Baileys/WWebJS)
    let wbotInstance: any = null;
    if (whatsapp.channel === "whatsapp") {
      try {
        wbotInstance = getWbot(whatsappId);
      } catch (err) {
        // Handle cases where wbot might not be ready or configured
        console.warn(
          `${logPrefix}: Could not get wbot instance for channel 'whatsapp'. API calls might fail if direct sending is expected.`
        );
      }
    }

    try {
      // 2. Sanitize and Find/Create Contact
      let targetNumber = payload.number;
      let isGroup = false;
      // Basic check for group JID format (adjust pattern if needed)
      if (
        targetNumber.includes("@g.us") ||
        targetNumber.includes("@grupo.us")
      ) {
        // Included @grupo.us based on deobfuscated string
        isGroup = true;
      } else if (
        whatsapp.channel === "whatsapp" &&
        targetNumber.includes("@s.whatsapp.net")
      ) {
        // It's a standard WhatsApp JID
        targetNumber = targetNumber.split("@")[0];
      }
      // Add more sanitization if needed (e.g., removing non-digits for standard numbers)

      const contactWhere: WhereOptions = { number: targetNumber, tenantId };
      let contact = await Contact.findOne({ where: contactWhere });

      if (!contact) {
        if (isGroup) {
          // Maybe handle group creation differently or throw error if groups aren't auto-created
          throw new AppError(
            `ERR_GROUP_CONTACT_NOT_FOUND: Group contact ${targetNumber} not found for tenant ${tenantId}.`,
            404
          );
        }
        console.log(
          `${logPrefix}: Contact ${targetNumber} not found, creating.`
        );
        contact = await CreateContactService({
          name: targetNumber, // Use number as name initially
          number: targetNumber,
          tenantId: tenantId
          // email: '', // Add other defaults if necessary
          // isGroup: isGroup // Add flag if your model supports it
        });
      }

      // 3. Find or Create Ticket
      const findOrCreateTicketOptions = {
        tenantId: tenantId,
        whatsappId: whatsappId,
        contactId: contact.id,
        channel: whatsapp.channel, // Pass the channel type
        groupContact: isGroup ? contact : undefined // Pass contact if it's a group
      };

      // Check for existing open/pending ticket
      const ticketWhere: WhereOptions = {
        contactId: contact.id,
        whatsappId: whatsappId,
        tenantId: tenantId,
        status: { [Op.or]: ["open", "pending"] } // Check for open or pending tickets
      };
      const ticketOrder: FindOptions["order"] = [["id", "DESC"]]; // Get the latest one
      let ticket = await Ticket.findOne({
        where: ticketWhere,
        order: ticketOrder
      });

      if (!ticket) {
        console.log(
          `${logPrefix}: No existing open/pending ticket found for contact ${contact.id}. Creating new ticket.`
        );
        ticket = await FindOrCreateTicketService(findOrCreateTicketOptions);

        // Emit event for new ticket only if it's truly new
        const newTicket = await ShowTicketService(ticket.id, tenantId); // Fetch full ticket data
        socketEmit({
          tenantId: tenantId,
          type: "ticket:update", // Consistent event name
          payload: newTicket
        });
      } else {
        console.log(
          `${logPrefix}: Using existing ticket ${ticket.id} for contact ${contact.id}.`
        );
        // Optionally update ticket status if needed (e.g., set to pending if closed)
        if (ticket.status === "closed") {
          console.log(`${logPrefix}: Reopening closed ticket ${ticket.id}.`);
          await ticket.update({ status: "pending", userId: null }); // Reopen and unassign
          // Fetch updated ticket data for emit
          const updatedTicket = await ShowTicketService(ticket.id, tenantId);
          socketEmit({
            tenantId: tenantId,
            type: "ticket:update",
            payload: updatedTicket
          });
        }
      }

      // 4. Prepare and Send Message via System Service
      // Construct message data based on payload
      const messageSysData: any = {
        body: payload.body || "", // Default to empty string if no body
        fromMe: true,
        read: true, // Mark API messages as read by default
        // Map other payload fields to Message model fields if necessary
        mediaUrl: payload.mediaUrl,
        mediaType: payload.mediaType,
        // timestamp: payload.timestamp ? Math.floor(payload.timestamp / 1000) : undefined, // Adjust timestamp if needed
        status: "pending", // Initial status before sending
        // Add other fields like quotedMsgId if applicable from payload
        dataJson: JSON.stringify(payload) // Store original payload if needed
      };

      // Add button/list/template specific data if present
      if (payload.buttonText) messageSysData.body = payload.buttonText; // Override body for simple button
      // Add more complex mapping for lists, interactive buttons, templates...

      // If media is present, set appropriate mediaType if not provided
      if (payload.mediaUrl && !payload.mediaType) {
        // Basic inference, might need a more robust method
        if (payload.mediaUrl.match(/\.(jpe?g|png|gif|webp)$/i))
          messageSysData.mediaType = "image";
        else if (payload.mediaUrl.match(/\.(mp4|avi|mov|wmv)$/i))
          messageSysData.mediaType = "video";
        else if (payload.mediaUrl.match(/\.(mp3|ogg|wav|aac)$/i))
          messageSysData.mediaType = "audio";
        else if (payload.mediaUrl.match(/\.(pdf|doc|docx|xls|xlsx|ppt|pptx)$/i))
          messageSysData.mediaType = "document";
        else messageSysData.mediaType = "chat"; // Default fallback
      }

      // Determine sendType (e.g., 'chat', 'media', 'button', 'list', 'template')
      let sendType = "chat";
      if (payload.mediaUrl)
        sendType = payload.mediaType || messageSysData.mediaType || "media"; // Default to 'media' if URL exists but type unknown
      if (payload.buttonType) sendType = payload.buttonType; // Use buttonType if provided
      // Add logic for list, template types...

      // 5. Create System Message (stores in DB and triggers sending via listener/queue)
      await CreateMessageSystemService({
        messageData: messageSysData,
        tenantId: tenantId,
        ticket: ticket,
        sendType: sendType, // Pass the determined type
        channel: whatsapp.channel // Pass the channel type
      });

      // 6. Optional: Update ticket status or timestamp
      await ticket.update({ lastMessageTimestamp: Date.now() }); // Example update
    } catch (error: any) {
      console.error(`${logPrefix}: Error handling SendMessageAPI job:`, error);
      // Add specific error handling (e.g., AppError checks)
      if (error instanceof AppError) {
        console.error(
          `${logPrefix}: AppError - ${error.message} (Code: ${error.statusCode})`
        );
      }
      // Log detailed error or send to Sentry
      // Sentry.captureException(error, { extra: { tenantId, sessionId, payload } });
      throw error; // Re-throw error for queue handler
    }
  }
};
