import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna name a la tabla Whatsapps
    return queryInterface.addColumn('Whatsapps', 'name', { // Nombre de columna preservado
      type: DataTypes.STRING,
      allowNull: true, // Permitir nulo inicialmente
      unique: true // Asegura que los nombres sean únicos
    });
    // La migración 20241019200100 cambia esta constraint de unicidad
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna name
    return queryInterface.removeColumn('Whatsapps', 'name');
  }
};