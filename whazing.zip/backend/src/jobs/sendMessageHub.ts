import SendMessagesSystemHub from "../services/WbotNotificame/SendMessagesSystemHub"; // Adjust import as needed
import { logger } from "../utils/logger";

// Define interfaces (can be shared/imported from SendMessages.ts or a types file)
interface MessageToSend {
  number: string;
  message?: string;
  options?: any;
  media?: {
    mimetype: string;
    url?: string;
    path?: string;
    filename?: string;
    caption?: string;
  };
  // Add other potential message properties
}

interface SendData {
  whatsappId: number | string; // Hub might use string IDs
  tenantId: number | string;
  messages: MessageToSend[];
}

interface Job {
  data: SendData;
}

interface HandleOptions {
  delay: number;
  priority: number;
  attempts: number;
  removeOnComplete: boolean;
  removeOnFail: boolean;
}

const handleOptions: HandleOptions = {
  delay: 10000, // 0x2710 ms
  priority: 1,
  attempts: 10, // Original: 0xa
  removeOnComplete: true,
  removeOnFail: false // Original: ![]
};

export const sendMessageHub = {
  // Exporting the job configuration
  key: "SendMessageHub",
  options: handleOptions,
  async handle({ data }: Job): Promise<void> {
    const logPrefix = "SendMessageHub Job";
    try {
      const { whatsappId, tenantId, messages } = data;

      if (!messages || messages.length === 0) {
        logger.warn(
          `${logPrefix}: No messages provided for WhatsApp ID ${whatsappId}, Tenant ${tenantId}. Skipping job.`
        );
        return;
      }

      // Call the service function responsible for sending via Hub
      await SendMessagesSystemHub(whatsappId, tenantId, messages);
      logger.info(
        `${logPrefix}: Job completed for WhatsApp ID ${whatsappId}, Tenant ${tenantId}. Messages sent: ${messages.length}`
      );
    } catch (error: any) {
      logger.error({
        message: `${logPrefix}: Error job`, // Original: Error in send Hub job
        whatsappId: data?.whatsappId,
        tenantId: data?.tenantId,
        error: error?.message,
        originalError: error
      });
      throw error; // Re-throw error for queue handler
    }
  }
};
