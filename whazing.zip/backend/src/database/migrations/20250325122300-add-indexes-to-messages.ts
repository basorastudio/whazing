'use strict';
import { QueryInterface } from 'sequelize';

export default {
    up: async (queryInterface: QueryInterface) => {
        // Índice para búsquedas por tenantId y messageId (quoted message?)
        await queryInterface.addIndex('Messages', [
            'tenantId',
            'messageId' // Asumiendo que este es el campo correcto, podría ser 'id' o 'quotedMsgId' dependiendo del contexto. El original usaba 'messageId'
        ], { name: 'idx_messages_tenantid_messageid' }); // nombre claro del índice

        // Índice para búsquedas por tenantId, whatsappId y fromMe
        await queryInterface.addIndex('Messages', [
            'tenantId',
            'whatsappId',
            'fromMe'
        ], { name: 'idx_messages_tenantid_whatsappid_fromMe' }); // nombre claro del índice
    },

    down: async (queryInterface: QueryInterface) => {
        await queryInterface.removeIndex('Messages', 'idx_messages_tenantid_messageid');
        await queryInterface.removeIndex('Messages', 'idx_messages_tenantid_whatsappid_fromMe');
    }
};