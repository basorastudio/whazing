declare module "asterisk-manager";
