import NodeCache from "node-cache";
import { getIO, fetchSockets } from "../libs/socket"; // Assuming socket lib path
import User from "../models/User"; // Assuming model path
import UsersQueue from "../models/UsersQueue"; // Assuming model path
import ListSettingsService from "../services/ListSettingsService"; // Assuming service path
import { logger } from "../utils/logger"; // Assuming logger path
import Setting from "../models/Setting"; // Assuming setting model path

// Define interfaces for better typing
interface SocketAuthData {
  id?: number | string;
  profile?: string;
  queues?: number[];
  // other auth properties
}

interface SocketData {
  auth: SocketAuthData;
  // other socket properties
}

interface EmitEventParams {
  tenantId: number | string;
  type: string;
  payload: any;
  queueId?: number | string | null; // Can be null or undefined
}

// Cache configuration
const cache = new NodeCache({ stdTTL: 300 }); // Cache for 5 minutes (300 seconds)

// Helper to clean data before caching (remove Sequelize metadata)
const cleanForCache = <T>(data: T): T => {
  if (Array.isArray(data)) {
    // If it's an array, map over it and clean each item
    return data.map(item =>
      item && typeof item.toJSON === "function" ? item.toJSON() : item
    ) as T;
  }
  if (data && typeof (data as any).toJSON === "function") {
    // If it has a toJSON method (like Sequelize models), use it
    return (data as any).toJSON() as T;
  }
  // Otherwise, return the data as is
  return data;
};

const emitEvent = async ({
  tenantId,
  type,
  payload,
  queueId
}: EmitEventParams): Promise<void> => {
  logger.debug(
    `EmitEvent - Iniciando emisión de evento - TenantId: ${tenantId}, Tipo: ${type}, QueueId: ${queueId || "N/A"}`
  );

  const io = getIO();
  let tenantChannel = `${tenantId}:`; // Base channel prefix

  // Adjust channel based on event type (ticket, contact, etc.)
  if (type.startsWith("ticket")) {
    tenantChannel = `${tenantId}:ticketList`;
    logger.debug(
      `EmitEvent - Canal cambiado a lista de tickets: ${tenantChannel}`
    );
  } else if (type.startsWith("contact")) {
    tenantChannel = `${tenantId}:contactList`;
    logger.debug(
      `EmitEvent - Canal cambiado a lista de contactos: ${tenantChannel}`
    );
  }
  // Add more conditions for other types if needed

  // Determine the target user ID, if any
  let targetUserId: number | string | undefined | null;
  if (type.startsWith("ticket")) {
    targetUserId = payload?.userId; // User assigned to the ticket
  } else if (type.startsWith("chat")) {
    targetUserId = payload?.userId; // User involved in the chat
  }
  // Add other conditions to extract target user ID based on event type

  let allowedUserIds: (number | string)[] = [];

  // 1. Fetch All Users for the Tenant (Cached)
  const tenantUsersCacheKey = `users:${tenantId}`;
  let tenantUsers = cache.get<User[]>(tenantUsersCacheKey);
  if (!tenantUsers) {
    logger.debug(
      `EmitEvent - Cache miss para usuarios del tenant ${tenantId}. Obteniendo de DB.`
    );
    const users = await User.findAll({
      where: { tenantId: tenantId },
      attributes: ["id", "profile", "tenantId"] // Include tenantId
    });
    tenantUsers = cleanForCache(users);
    cache.set(tenantUsersCacheKey, tenantUsers);
    logger.debug(
      `EmitEvent - Usuarios cacheados (${tenantUsers.length}) para tenant ${tenantId}`
    );
  } else {
    logger.debug(
      `EmitEvent - Cache hit para usuarios (${tenantUsers.length}) del tenant ${tenantId}`
    );
  }
  const allUserIdsInTenant = tenantUsers.map(user => user.id);

  // 2. Check Settings: NotViewAssignedTickets
  const settingsCacheKey = `settings:${tenantId}`;
  let settings = cache.get<Setting[]>(settingsCacheKey);
  if (!settings) {
    logger.debug(
      `EmitEvent - Cache miss para configuraciones del tenant ${tenantId}. Obteniendo de DB.`
    );
    const settingsList = await ListSettingsService(tenantId);
    settings = cleanForCache(settingsList);
    cache.set(settingsCacheKey, settings);
    logger.debug(
      `EmitEvent - Configuraciones cacheadas para tenant ${tenantId}`
    );
  } else {
    logger.debug(
      `EmitEvent - Cache hit para configuraciones del tenant ${tenantId}`
    );
  }

  // Find the specific setting value
  const notViewAssignedSetting =
    settings?.find(s => s.key === "NotViewAssignedTickets")?.value ===
    "enabled";
  logger.debug(
    `EmitEvent - Configuración NotViewAssignedTickets para tenant ${tenantId}: ${notViewAssignedSetting}`
  );

  // 3. Determine Allowed Users based on settings and event type
  if (type.startsWith("ticket") && notViewAssignedSetting && targetUserId) {
    // Setting enabled: Only emit to admins and the assigned user
    allowedUserIds = tenantUsers
      .filter(user => user.profile === "admin" || user.id === targetUserId)
      .map(user => user.id);
    logger.debug(
      `EmitEvent - Emisión restringida (NotViewAssignedTickets) a admins y usuario asignado (${targetUserId}). Usuarios permitidos: ${allowedUserIds.length}`
    );
  } else if (queueId) {
    // Event is related to a specific queue
    logger.debug(
      `EmitEvent - Evento para cola específica: ${queueId}. Determinando usuarios de la cola.`
    );
    const queueUsersCacheKey = `queueUsers:${queueId}`;
    let queueUsers = cache.get<UsersQueue[]>(queueUsersCacheKey);
    if (!queueUsers) {
      logger.debug(
        `EmitEvent - Cache miss para usuarios de la cola ${queueId}. Obteniendo de DB.`
      );
      const usersInQueue = await UsersQueue.findAll({
        where: { queueId: queueId },
        attributes: ["userId"] // Only need user IDs
      });
      queueUsers = cleanForCache(usersInQueue);
      cache.set(queueUsersCacheKey, queueUsers);
      logger.debug(
        `EmitEvent - Usuarios de cola cacheados (${queueUsers.length}) para cola ${queueId}`
      );
    } else {
      logger.debug(
        `EmitEvent - Cache hit para usuarios de cola (${queueUsers.length}) para cola ${queueId}`
      );
    }
    const userIdsInQueue = queueUsers.map(uq => uq.userId);

    // Combine queue users with all admins from the tenant
    const adminIds = tenantUsers
      .filter(user => user.profile === "admin")
      .map(user => user.id);
    allowedUserIds = [...new Set([...userIdsInQueue, ...adminIds])]; // Unique IDs
    logger.debug(
      `EmitEvent - Emisión a usuarios de la cola ${queueId} y admins. Usuarios permitidos: ${allowedUserIds.length}`
    );
  } else {
    // No specific queue or restriction setting applies, emit to all users in the tenant
    allowedUserIds = allUserIdsInTenant;
    logger.debug(
      `EmitEvent - Emisión a todos los usuarios (${allowedUserIds.length}) en el tenant ${tenantId}`
    );
  }

  // 4. Emit to Sockets of Allowed Users
  const sockets = await fetchSockets();
  let emittedCount = 0;

  if (!sockets || sockets.length === 0) {
    logger.warn(
      `EmitEvent - No hay sockets activos para emitir el evento para el tenant ${tenantId}`
    );
    return;
  }

  logger.debug(
    `EmitEvent - Verificando ${sockets.length} sockets activos para emitir al canal ${tenantChannel}`
  );

  sockets.forEach((socket: any) => {
    // Use 'any' for socket if type is unknown, or import specific Socket.IO type
    const socketData = socket.handshake?.auth as SocketAuthData | undefined; // Access auth data safely
    const socketUserId = socketData?.id;
    const socketTenantId = (socket as any).tenantId; // Assuming tenantId is stored directly on socket

    // Basic validation
    if (!socketUserId) {
      // logger.warn(`EmitEvent - Socket ${socket.id} no tiene ID de usuario en auth.`);
      return;
    }
    if (socketTenantId !== tenantId) {
      // logger.warn(`EmitEvent - Socket ${socket.id} (Usuario ${socketUserId}) no pertenece al tenant ${tenantId}.`);
      return;
    }

    // Check if this socket's user is in the allowed list
    if (
      allowedUserIds.includes(Number(socketUserId)) ||
      allowedUserIds.includes(String(socketUserId))
    ) {
      // Emit the event to this specific socket's room (tenantChannel)
      // Using socket.emit directly targets only that socket
      socket.emit(tenantChannel, {
        // Emit to the channel the socket is in
        action: type, // Use 'action' key as seems common
        payload: payload
      });
      emittedCount++;
      // logger.debug(`EmitEvent - Evento ${type} emitido al socket ${socket.id} (Usuario ${socketUserId})`);
    } else {
      // logger.debug(`EmitEvent - Socket ${socket.id} (Usuario ${socketUserId}) no está en la lista de permitidos para este evento.`);
    }
  });

  logger.info(
    `EmitEvent - Emisión de evento completada. Tipo: ${type}, Tenant: ${tenantId}, Emitido a: ${emittedCount} sockets.`
  );
};

// Invalidate User Cache (when user profile/queues change)
export const invalidateUserCache = (userId: number | string) => {
  const cacheKey = `users:${userId}`; // Assuming user-specific cache if needed, otherwise use tenant key
  logger.debug(`Invalidando caché para el usuario ${userId}`);
  // For now, we only cache tenant-wide users. If user details change,
  // invalidating the *tenant's* user cache is necessary.
  // Find the tenant ID for this user if possible, otherwise clear all tenant user caches (less efficient).
  // Example: Assuming you can get tenantId from userId:
  // const tenantId = findTenantForUser(userId);
  // if (tenantId) {
  //     const tenantUsersCacheKey = `users:${tenantId}`;
  //     logger.debug(`Invalidando caché de usuarios del tenant ${tenantId} debido a cambio en usuario ${userId}`);
  //     cache.del(tenantUsersCacheKey);
  // } else {
  logger.warn(
    `No se pudo determinar el tenant para invalidar el caché del usuario ${userId}. Considere invalidar todos los cachés de usuarios.`
  );
  // cache.flushAll(); // Drastic option
  // }
  // Also invalidate specific queue assignments if they change
  // cache.del(`queueUsers:*`); // Invalidate all queue caches or specific ones if known
};

// Invalidate Queue Cache (when queue membership changes)
export const invalidateQueueCache = (queueId: number | string) => {
  const cacheKey = `queueUsers:${queueId}`;
  logger.debug(`Invalidando caché para usuarios de la cola ${queueId}`);
  cache.del(cacheKey);
};

// Invalidate Settings Cache (when settings change)
export const invalidateSettingsCache = (tenantId: number | string) => {
  const cacheKey = `settings:${tenantId}`;
  logger.debug(
    `Invalidando caché de configuraciones para el tenant ${tenantId}`
  );
  cache.del(cacheKey);
};

export default emitEvent;
