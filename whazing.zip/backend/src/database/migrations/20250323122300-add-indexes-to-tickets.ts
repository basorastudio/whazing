"use strict";
import { QueryInterface } from "sequelize";

export default {
  up: async (queryInterface: QueryInterface) => {
    // Índice principal combinando tenant, estado y si es grupo
    await queryInterface.addIndex(
      "Tickets",
      ["tenantId", "status", "isGroup"],
      { name: "idx_tickets_main" }
    ); // nombre claro del índice

    // Índice para búsquedas relacionadas con whatsappId, tenant y estado
    await queryInterface.addIndex(
      "Tickets",
      ["whatsappId", "tenantId", "status"],
      { name: "idx_tickets_whatsapp_queue" }
    ); // nombre claro del índice

    // Índice para búsquedas relacionadas con cola (queue), estado y tenant
    await queryInterface.addIndex(
      "Tickets",
      ["queueId", "isGroup", "tenantId"],
      { name: "idx_tickets_user_queue" }
    ); // nombre claro del índice

    // Índice para búsquedas relacionadas con usuario, tenant y estado
    await queryInterface.addIndex("Tickets", ["userId", "tenantId", "status"], {
      name: "idx_tickets_contact_status"
    }); // nombre claro del índice (nombre original parecía incorrecto, ajustado a campos)
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeIndex("Tickets", "idx_tickets_main");
    await queryInterface.removeIndex("Tickets", "idx_tickets_whatsapp_queue");
    await queryInterface.removeIndex("Tickets", "idx_tickets_user_queue");
    await queryInterface.removeIndex("Tickets", "idx_tickets_contact_status");
  }
};
