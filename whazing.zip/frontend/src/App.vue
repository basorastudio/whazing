<template>
  <div id="q-app">
    <router-view />
  </div>
</template>
<script>
export default {
  name: 'App',
  data () {
    return {
      IDLE_TIMEOUT: 1800, // seconds
      idleSecondsCounter: 0
    }
  },
  methods: {
    CheckIdleTime () {
      this.idleSecondsCounter++
      if (this.idleSecondsCounter >= this.IDLE_TIMEOUT) {
        window.location.reload()
      }
    },
    bindEventListeners() {
      document.onclick = () => {
        this.idleSecondsCounter = 0
      }
      document.onmousemove = () => {
        this.idleSecondsCounter = 0
      }
      document.onkeypress = () => {
        this.idleSecondsCounter = 0
      }
    },
    notifyParentUrl() {
      // Notify parent window about current URL
      if (window.parent !== window) {
        window.parent.postMessage({ currentUrl: window.location.href }, 'https://multiagente.net')
      }
    }
  },
  watch: {
    '$route': {
      handler() {
        this.notifyParentUrl()
      },
      immediate: true
    }
  },
  beforeMount() {
    const usuario = JSON.parse(localStorage.getItem('usuario'))
    if (usuario?.configs?.isDark) {
      this.$q.dark.set(usuario?.configs?.isDark)
    }
    this.bindEventListeners()
    setInterval(this.CheckIdleTime, 1000)
    // Initial URL notification
    this.notifyParentUrl()
  }
}
</script>
