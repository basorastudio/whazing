<template>
  <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <div class="bg-white mass-container container-rounded-10">
      <div class="row col full-width q-pa-lg">
      <q-card
        flat
        bordered
        class="full-width"
      >
        <q-card-section class="text-h6 text-bold">
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-cellphone-wireless q-pr-sm" />
            Canales de Comunicación
          </h2>
          <div class="q-pa-sm">
            <q-btn flat
                   class="generate-button btn-rounded-50"
                   :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="eva-plus-outline"
              label="Añadir Canal"
              @click="modalWhatsapp = true"
              v-if="userProfile === 'admin'"
            />
            <q-btn flat
                   class="generate-button btn-rounded-50"
                   :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="mdi-restart"
              label="Reiniciar Conexiones"
              @click="reiniciarConexoes"
            />
            <q-btn
              class="generate-button btn-rounded-50"
              v-if="userProfile === 'admin'"
              :class="{'generate-button-dark' : $q.dark.isActive}"
                   icon="mdi-cog"
                   label="Token Hub"
                   @click="modalHub = true"
            />
            <q-btn flat
                   class="generate-button btn-rounded-50"
                   :class="{'generate-button-dark' : $q.dark.isActive}"
                   v-if="whatsappNumber"
                   icon="mdi-whatsapp"
                   label="Llamar a Soporte"
                   @click="abrirWhatsApp"
            />

          </div>
        </q-card-section>
      </q-card>
    </div>
    <div class="container-border q-ma-lg q-pb-md container-rounded-10">
      <q-card-section>
        <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
        <q-icon name="eva-list-outline q-pr-sm" />
        Listado
      </h2>
      </q-card-section>

      <div class="row full-width  q-px-md ">
      <template v-for="item in canais">
        <q-card
          flat
          bordered
          class="col-xs-12 col-sm-5 col-md-4 col-lg-3 "
          :key="item.id"
        >
          <q-item>
            <q-item-section avatar>
              <q-avatar>
                <q-icon
                  size="40px"
                  :name="`img:${item.type}-logo.png`"
                />
              </q-avatar>
            </q-item-section>
            <q-item-section>
              <q-item-label class="text-h6 text-bold">{{ item.name }}</q-item-label>
              <q-item-label class="text-h6 text-caption">
                {{ item.type }}
              </q-item-label>
            </q-item-section>
            <q-item-section side>
              <q-btn
                round
                flat
                dense
                icon="eva-edit-outline"
                @click="handleOpenModalWhatsapp(item)"
                v-if="userProfile === 'admin'"
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
              />
              <!-- <q-btn
            round
            flat
            dense
            icon="delete"
            @click="deleteWhatsapp(props.row)"
            v-if="$store.getters['isSuporte']"
          /> -->
            </q-item-section>
          </q-item>
          <q-separator />
          <q-card-section>
            <ItemStatusChannel :item="item" />
          </q-card-section>
          <q-card-section>
            <!-- <q-toggle v-if="item.type === 'whatsapp'" v-model="item.is_open_ia" label="Chat por IA"
              @input="handleSaveWhatsApp(item)" /> -->
            <q-select
              v-if="userProfile === 'admin'"
              rounded
              outlined
              dense
              label="ChatBot"
              v-model="item.chatFlowId"
              :options="listaChatFlow"
              map-options
              emit-value
              option-value="id"
              option-label="name"
              clearable
              @input="handleSaveWhatsApp(item)"
            />
          </q-card-section>
          <q-card-section>
            <q-select
              v-if="userProfile === 'admin'"
              rounded
              outlined
              dense
              label="Fila"
              v-model="item.queueId"
              :options="listaFila"
              map-options
              emit-value
              option-value="id"
              option-label="queue"
              clearable
              @input="handleSaveWhatsApp(item)"
            >
              <q-tooltip>
                Se asignará esta fila para nuevos tickets
              </q-tooltip>
            </q-select>
          </q-card-section>
          <q-card-section>
            <q-select
              v-if="userProfile === 'admin'"
              rounded
              outlined
              dense
              label="Usuario"
              v-model="item.userId"
              :options="listaUsuario"
              map-options
              emit-value
              option-value="id"
              option-label="name"
              clearable
              @input="handleSaveWhatsApp(item)"
              >
              <q-tooltip>
                Se asignará este usuario para nuevos tickets
              </q-tooltip>
            </q-select>
          </q-card-section>
          <q-card-section v-if="(item.status == 'DISCONNECTED' || item.status == 'qrcode') && item.type == 'whatsapp'">
            <q-checkbox
              v-model="item.importmessages"
              label="Importar mensajes al LEER QRCODE"
              @input="handleSaveWhatsApp(item)"
            />

            <!-- Contenido condicionalmente renderizado solo si importmessages es true -->
            <template v-if="item.importmessages">
              <q-card-section>
                <DatePick
                  rounded
                  dense
                  hide-bottom-space
                  outlined
                  stack-label
                  bottom-slots
                  label="Fecha de inicio de la importación"
                  v-model="item.importOldMessages"
                  @input="handleSaveWhatsApp(item)"
                />
              </q-card-section>

              <q-card-section>
                <DatePick
                  rounded
                  dense
                  hide-bottom-space
                  outlined
                  stack-label
                  bottom-slots
                  label="Fecha de término de la importación"
                  v-model="item.importRecentMessages"
                  @input="handleSaveWhatsApp(item)"
                />
              </q-card-section>

              <q-checkbox
                v-model="item.importOldMessagesGroups"
                label="Importar mensajes de GRUPO"
                @input="handleSaveWhatsApp(item)"
              />

              <q-checkbox
                v-model="item.closedTicketsPostImported"
                label="Cerrar tickets después de la importación"
                @input="handleSaveWhatsApp(item)"
              />
            </template>
          </q-card-section>
          <q-separator />
          <div v-if="item.pairingCode && item.type == 'whatsapp' && item.status == 'qrcode'"
               class="pairing-code-container q-py-md q-px-sm">
            <div class="row items-center justify-center">
              <q-icon name="mdi-cellphone"
                      size="24px"
                      class="q-mr-sm"
                      :class="$q.dark.isActive ? 'text-white' : 'color-light1'" />
              <div class="column">
                <div class="text-caption"
                     :class="$q.dark.isActive ? 'text-white' : 'text-grey-7'">Código de emparejamiento:</div>
                <div class="text-h6 text-weight-bold"
                     :class="$q.dark.isActive ? 'text-white' : 'color-light2'">
                {{ formatPairingCode(item.pairingCode) }}
                </div>
              </div>
            </div>
          </div>
          <q-separator />
          <q-card-actions
            class="q-gutter-md q-pa-sm q-pt-none"
            align="center"
          >
           <template v-if="item.type !== 'messenger'">

              <q-btn
                v-if="item.type == 'whatsapp' && item.status == 'qrcode'"
                label="QR Code"
                @click="handleOpenQrModal(item, 'btn-qrCode')"
                icon-right="mdi-qrcode-scan"
                :disable="!isAdmin"
                class="generate-button btn-rounded-50"
                :class="{'generate-button-dark' : $q.dark.isActive}"
              />

              <div v-if="item.status == 'DISCONNECTED'" class="q-gutter-sm">
                <q-btn
                  v-if="item.type != 'whatsapp'"
                  class="generate-button btn-rounded-50"
                  :class="{'generate-button-dark' : $q.dark.isActive}"
                  label="Conectar"
                  @click="handleStartWhatsAppSession(item.id)"
                />
                <q-btn
                  v-if="item.status == 'DISCONNECTED' && item.type == 'whatsapp'"
                  label="Nuevo QR Code"
                  @click="handleRequestNewQrCode(item, 'btn-qrCode')"
                  icon-right="mdi-qrcode-scan"
                  :disable="!isAdmin"
                  class="generate-button btn-rounded-50"
                  :class="{'generate-button-dark' : $q.dark.isActive}"
                />

              </div>

              <div v-if="item.status == 'OPENING'" class="row items-center q-gutter-sm flex flex-inline">
                <div class="text-bold">
                  Conectando
                </div>
                <q-spinner-radio color="positive" size="2em" />
                <q-separator vertical spaced="" />
              </div>

              <q-btn
                v-if="['OPENING', 'CONNECTED', 'PAIRING', 'TIMEOUT'].includes(item.status) && !item.type.includes('hub')"
                color="negative"
                label="Desconectar"
                icon="eva-wifi-off-outline"
                @click="handleDisconectWhatsSession(item.id)"
                :disable="!isAdmin"
                class="btn-rounded-50 q-mx-sm"
              />

            <q-btn
              v-if="userProfile === 'admin'"
              color="negative"
              icon="eva-trash-outline"
              @click="deleteWhatsapp(item)"
              :disable="!isAdmin"
              dense
              round
              flat
              class="absolute-bottom-right color-light1"
              :class="$q.dark.isActive ? ('color-dark1') : ''"
            >
             <q-tooltip>
                Eliminar conexión
              </q-tooltip>
            </q-btn>

           </template>
          </q-card-actions>

      </div>
      <ModalHub v-model="modalHub" />
      <ModalQrCode :abrirModalQR.sync="abrirModalQR" :channel="cDadosWhatsappSelecionado"
      @gerar-novo-qrcode="v => handleRequestNewQrCode(v, 'btn-qrCode')" />
    <ModalWhatsapp :modalWhatsapp.sync="modalWhatsapp" :whatsAppEdit.sync="whatsappSelecionado"
      @recarregar-lista="listarWhatsapps" />
    <q-inner-loading :showing="loading">
      <q-spinner-gears size="50px" color="primary" />
    </q-inner-loading>
  </div>
</template>

<script>

import { DeletarWhatsapp, DeleteWhatsappSession, StartWhatsappSession, ListarWhatsapps, RequestNewQrCode, UpdateWhatsapp, UpdateOpenIAWhatsapp, ReiniciarConexoes } from 'src/service/sessoesWhatsapp'
import { format, parseISO } from 'date-fns'
import pt from 'date-fns/locale/pt-BR/index'
import ModalQrCode from './ModalQrCode'
import ModalHub from './ModalHub'
import { mapGetters } from 'vuex'
import ModalWhatsapp from './ModalWhatsapp'
import ItemStatusChannel from './ItemStatusChannel'
import { ListarChatFlow } from 'src/service/chatFlow'
import { ListarFilas } from 'src/service/filas'
import { ListarUsuarios } from 'src/service/user'
import { ListarConfiguracaoPublica } from 'src/service/configuracoesgeneral'

const userLogado = JSON.parse(localStorage.getItem('usuario'))

export default {
  name: 'IndexSessoesWhatsapp',
  components: {
    ModalQrCode,
    ModalWhatsapp,
    ModalHub,
    ItemStatusChannel
  },
  data() {
    return {
      userProfile: 'user',
      loading: false,
      userLogado,
      isAdmin: false,
      abrirModalQR: false,
      modalWhatsapp: false,
      modalHub: false,
      whatsappNumber: null,
      whatsappSelecionado: {},
      listaChatFlow: [],
      listaFila: [],
      listaUsuario: [],
      pageNumber: 1,
      hasMore: true,
      whatsAppId: null,
      canais: [],
      objStatus: {
        qrcode: ''
      },
      columns: [
        {
          name: 'name',
          label: 'Nombre',
          field: 'name',
          align: 'left'
        },
        {
          name: 'status',
          label: 'Estado',
          field: 'status',
          align: 'center'
        },
        {
          name: 'session',
          label: 'Sesión',
          field: 'status',
          align: 'center'
        },
        {
          name: 'number',
          label: 'Número',
          field: 'number',
          align: 'center'
        },
        {
          name: 'updatedAt',
          label: 'Última Actualización',
          field: 'updatedAt',
          align: 'center',
          format: d => this.formatarData(d, 'dd/MM/yyyy HH:mm')
        },
        {
          name: 'isDefault',
          label: 'Predeterminado',
          field: 'isDefault',
          align: 'center'
        },
        {
          name: 'acoes',
          label: 'Acciones',
          field: 'acoes',
          align: 'center'
        }
      ],
      FB: {},
      FBscope: {},
      FBLoginOptions: {
        scope:
          'pages_manage_metadata,pages_messaging,instagram_basic,pages_show_list,pages_read_engagement,instagram_manage_messages'
      },
      FBPageList: [],
      fbSelectedPage: { name: null, id: null },
      fbPageName: '',
      fbUserToken: ''
    }
  },
  watch: {
    whatsapps: {
      handler() {
        this.canais = JSON.parse(JSON.stringify(this.whatsapps))
      },
      deep: true
    }
  },
  computed: {
    ...mapGetters(['whatsapps']),
    cFbAppId() {
      return process.env.FACEBOOK_APP_ID
    },
    cDadosWhatsappSelecionado() {
      const { id } = this.whatsappSelecionado
      return this.whatsapps.find(w => w.id === id)
    }
  },
  methods: {
    formatPairingCode(code) {
      // Adiciona espacios a cada 4 caracteres para mejor legibilidad
      return code?.match(/.{1,4}/g)?.join('-') || code
    },
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configuraciones:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const url = `https://wa.me/${this.whatsappNumber}?text=Ol%C3%A1%21+tenho+duvidas+conexão`
        window.open(url, '_blank')
      }
    },
    async reiniciarConexoes() {
      try {
        await ReiniciarConexoes()

        this.$q.notify({
          type: 'positive',
          message: '¡Conexiones reiniciadas con éxito!'
        })
      } catch (error) {
        this.$q.notify({
          type: 'negative',
          message: '¡Error al reiniciar conexiones!'
        })
        console.error(error)
      }
    },
    formatarData(data, formato) {
      return format(parseISO(data), formato, { locale: pt })
    },
    handleSdkInit({ FB }) {
      this.FB = FB
      // try login

      // this.FBscope = scope
    },
    async changeIaOption(whatsapp) {
      const data = { is_open_ia: whatsapp.is_open_ia, queurId: whatsapp.queue_transf }
      await UpdateOpenIAWhatsapp(whatsapp.id, data)
    },
    async buscaFilas() {
      const { data } = await ListarFilas()
      this.listaFila = data.filter(f => f.isActive)
    },
    async listarUsuario() {
      try {
        const { data } = await ListarUsuarios({ pageNumber: this.pageNumber })

        this.listaUsuario = [...this.listaUsuario, ...data.users]
        this.hasMore = data.hasMore

        // Se ainda houver mais usuários, incrementa a página e chama novamente
        if (this.hasMore) {
          this.pageNumber += 1
          this.listarUsuario()
        }
      } catch (error) {
        console.error('Erro ao carregar usuários:', error)
      }
    },
    handleOpenQrModal(channel) {
      this.whatsappSelecionado = channel
      this.abrirModalQR = true
    },
    handleOpenModalWhatsapp(whatsapp) {
      this.whatsappSelecionado = whatsapp
      this.modalWhatsapp = true
    },
    async handleDisconectWhatsSession(whatsAppId) {
      this.$q.dialog({
        title: '¡Atención! ¿Realmente desea desconectar? ',
        // message: 'Mensagens antigas não serão apagadas no whatsapp.',
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeleteWhatsappSession(whatsAppId).then(() => {
          const whatsapp = this.whatsapps.find(w => w.id === whatsAppId)
          this.$store.commit('UPDATE_WHATSAPPS', {
            ...whatsapp,
            status: 'DISCONNECTED'
          })
        }).finally(f => {
          this.loading = false
        })
      })
    },
    async handleStartWhatsAppSession(whatsAppId) {
      try {
        await StartWhatsappSession(whatsAppId)
      } catch (error) {
        console.error(error)
      }
    },

    async handleRequestNewQrCode(channel, origem) {
      if (channel.type === 'telegram' && !channel.tokenTelegram) {
        this.$notificarErro('Necessário informar o token para Telegram')
      }
      this.loading = true
      try {
        await RequestNewQrCode({ id: channel.id, isQrcode: true })
        setTimeout(() => {
          this.handleOpenQrModal(channel)
        }, 2000)
      } catch (error) {
        console.error(error)
      }
      this.loading = false
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    },
    async listarWhatsapps() {
      const { data } = await ListarWhatsapps()
      this.$store.commit('LOAD_WHATSAPPS', data)
    },
    async deleteWhatsapp(whatsapp) {
      this.$q.dialog({
        title: '¡Atención! ¿Realmente desea eliminar? ',
        message: 'No es una buena idea eliminar si ya ha generado atenciones para este whatsapp.',
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarWhatsapp(whatsapp.id).then(r => {
          this.$store.commit('DELETE_WHATSAPPS', whatsapp.id)
        }).finally(f => {
          this.loading = false
        })
      })
    },
    async listarChatFlow() {
      const { data } = await ListarChatFlow()
      this.listaChatFlow = data.chatFlow.filter(chat => chat.isActive)
    },
    async handleSaveWhatsApp(whatsapp) {
      try {
        if (whatsapp.importOldMessages && whatsapp.importRecentMessages) {
          const oldDate = new Date(whatsapp.importOldMessages)
          const recentDate = new Date(whatsapp.importRecentMessages)

          const timeDiff = recentDate - oldDate
          const dayDiff = timeDiff / (1000 * 3600 * 24)

          if (dayDiff > 30) {
            this.$q.notify({
              type: 'negative',
              position: 'top',
              message: 'El período entre las fechas no puede ser superior a 30 días.',
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
            return
          }
        }
        await UpdateWhatsapp(whatsapp.id, whatsapp)
        this.$q.notify({
          type: 'positive',
          progress: true,
          position: 'top',
          message: `¡Whatsapp ${whatsapp.id ? 'editado' : 'creado'} con éxito!`,
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (error) {
        console.error(error)
        return this.$q.notify({
          type: 'error',
          progress: true,
          position: 'top',
          message: '¡Ups! Verifique los errores... El nombre de la conexión no puede existir en la plataforma, es un identificador único.',
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      }
    },
    handleUpdateSession(session) {
      this.$store.commit('UPDATE_SESSION', session)
      this.atualizarPagina()
    },
    atualizarPagina() {
      location.reload()
    }
  },
  beforeDestroy() {
    this.$root.$off('UPDATE_SESSION', this.handleUpdateSession)
  },
  mounted() {
    this.fetchConfigurations()
    this.userProfile = localStorage.getItem('profile')
    this.isAdmin = localStorage.getItem('profile')
    this.buscaFilas()
    this.listarUsuario()
    this.listarWhatsapps()
    this.listarChatFlow()
    this.$root.$on('UPDATE_SESSION', this.handleUpdateSession)
  }
  // destroyed() {
  //   this.disconnectSocket()
  // }
}
</script>

<style lang="scss" scoped>
.pairing-code-container {
  background: rgba(25, 118, 210, 0.05);
  border: 1px solid rgba(25, 118, 210, 0.2);
  border-radius: 8px;
  margin: 8px 16px;
  transition: all 0.3s ease;

  &:hover {
    background: rgba(25, 118, 210, 0.1);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }
}
</style>
