// Original: addLogs.js
// Deobfuscated, converted to TS, and translated

'use strict';

import * as fsp from 'fs/promises';
import path from 'path';
import * as fs from 'fs';

interface AddLogsParams {
  fileName: string;
  text: string;
  forceNewFile?: boolean;
}

// Añade registros a un archivo
export async function addLogs({
  fileName,
  text,
  forceNewFile = false
}: AddLogsParams): Promise<void> {
  const logsDir = path.resolve(__dirname, '..', '..', 'logs');

  // Asegura que el directorio de logs exista
  try {
    if (!fs.existsSync(logsDir)) {
      fs.mkdirSync(logsDir);
    }
  } catch (err) {
    // Ignorar error si el directorio ya existe o hay problemas de permisos (se manejará más adelante)
    console.error("Error al crear directorio de logs:", err);
  }

  const logFilePath = path.resolve(logsDir, fileName);

  try {
    if (forceNewFile) {
      await fsp.writeFile(logFilePath, text + ' \n');
      // Traducido: Nuevo Archivo de log adicionado al log:
      console.log(`Nuevo Archivo de log ${logFilePath} adicionado al log: ${text}`);
    } else {
      await fsp.appendFile(logFilePath, text + ' \n');
       // Traducido: Texto adicionado al log:
      console.log(`Texto adicionado al archivo de log ${logFilePath}: ${text}`);
    }
  } catch (err: any) { // Especificar tipo 'any' para acceder a 'code'
    // Si el archivo no existe (ENOENT) y no se forzó uno nuevo, intenta crearlo.
    if (err.code === 'ENOENT' && !forceNewFile) {
      try {
        await fsp.writeFile(logFilePath, text + ' \n');
         // Traducido: Nuevo Archivo de log adicionado al log:
        console.log(`Nuevo Archivo de log ${logFilePath} adicionado al log: ${text}`);
      } catch (writeErr) {
         // Traducido: Error al manipular el archivo de log
        console.error('Error al manipular el archivo de log:', writeErr);
      }
    } else {
       // Traducido: Error al manipular el archivo de log
      console.error('Error al manipular el archivo de log:', err);
    }
  }
}