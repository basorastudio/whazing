import path from "path";
import { getWbot, emitWhatsAppSession } from "../libs/wbot"; // Assuming wbot path
import { delay as delayBaileys } from "@adiwajshing/baileys"; // Assuming Baileys path
import {
  transformFileName,
  getMessageOptions
} from "../services/SendMessagesSystemWbotBaileys"; // Assuming service path
import { logger } from "../utils/logger"; // Assuming logger path

// Define types for message data and Baileys message object or import them
interface MessageData {
  number: string;
  body: string;
  mediaPath?: string | null;
  fileName?: string | null; // Corresponds to original 'mediaName' or similar
  options?: any; // For extra Baileys options like quoted messages, buttons etc.
}

// Type for the returned message object from Baileys send function
// This might be proto.IWebMessageInfo or similar depending on Baileys version
type BaileysMessage = any;

export const SendMessage = async (
  whatsappId: number | string,
  messageData: MessageData
): Promise<BaileysMessage> => {
  try {
    const wbot = getWbot(Number(whatsappId)); // Ensure ID is number
    const recipientNumber = messageData.number;

    // Prepend zero-width space to body (original behavior)
    const body = "‎" + messageData.body;

    let sentMessage: BaileysMessage;

    if (messageData.mediaPath && messageData.fileName) {
      const publicFolderPath = path.join(__dirname, "..", "public"); // Adjust if 'public' is elsewhere
      const filePath = path.join(
        publicFolderPath,
        messageData.mediaPath,
        messageData.fileName
      ); // Construct full path

      logger.debug(`Intentando enviar medio: ${filePath} a ${recipientNumber}`);

      const transformedFileName = transformFileName(messageData.fileName);
      const messageOptions = await getMessageOptions(
        transformedFileName,
        filePath,
        body
      );

      if (messageOptions) {
        sentMessage = await wbot.sendMessage(
          recipientNumber,
          messageOptions,
          messageData.options
        ); // Pass additional options if provided
        logger.debug(`Mensaje con medio enviado a ${recipientNumber}`);
      } else {
        throw new Error(
          "No se pudieron generar las opciones del mensaje para el medio."
        );
      }
    } else {
      logger.debug(`Enviando mensaje de texto a ${recipientNumber}`);
      // Simulate typing presence
      await wbot.presenceSubscribe(recipientNumber);
      await delayBaileys(500); // Short delay
      await wbot.sendPresenceUpdate("composing", recipientNumber);
      await delayBaileys(1000); // Longer delay while "typing"
      await wbot.sendPresenceUpdate("paused", recipientNumber); // Clear typing state

      sentMessage = await wbot.sendMessage(
        recipientNumber,
        { text: body },
        messageData.options
      ); // Pass additional options if provided
      logger.debug(`Mensaje de texto enviado a ${recipientNumber}`);
    }

    // Emit event after sending
    // This function wasn't in the original provided snippet but seems implied by wbot.ts import
    // Adjust or remove if emitWhatsAppSession is not what you intend here
    emitWhatsAppSession(sentMessage); // Assuming this function takes the sent message

    return sentMessage;
  } catch (error: any) {
    logger.error(
      `Error al enviar mensaje a ${messageData.number} en WhatsApp ID ${whatsappId}: ${error?.message}`
    );
    // Optionally log the full error stack
    // logger.error(error);
    throw new Error(error.message || "Error al enviar el mensaje");
  }
};

export default SendMessage;
