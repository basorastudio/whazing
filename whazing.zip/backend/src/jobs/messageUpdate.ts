import Queue from "../libs/Queue";
import MarkDeleteWhatsAppMessage from "../services/WbotServices/MarkDeleteWhatsAppMessage"; // Adjust path as needed
import { getWbot } from "../libs/wbot";
import { proto } from "@whiskeysockets/baileys"; // Assuming Baileys types

// Define interfaces for the data structures
interface MessageUpdateData {
  wbotId: number; // Assuming wbotId is a number
  tenantId: number | string;
  messageUpdate: proto.IWebMessageInfo[]; // Array of Baileys messages
}

interface Job {
  data: MessageUpdateData;
}

interface QueueJobData {
  msg: proto.IWebMessageInfo;
  ack: number;
  whatsappId: number;
  jobId?: string; // Added jobId for queue
}

interface BackoffOptions {
  type: string;
  delay: number;
}

interface HandleOptions {
  delay: number;
  attempts: number;
  removeOnComplete: boolean;
  removeOnFail: boolean;
  backoff: BackoffOptions;
}

const backoffOptions: BackoffOptions = {
  type: "fixed",
  delay: 5000 // 0x1388
};

const handleOptions: HandleOptions = {
  delay: 10, // 0xa (Original had two different delays, using the smaller one)
  attempts: 10,
  removeOnComplete: true,
  removeOnFail: false, // Original: ![]
  backoff: backoffOptions
};

export const messageUpdate = {
  key: "messageUpdate",
  options: handleOptions,
  async handle({ data }: Job): Promise<void> {
    const { wbotId, tenantId, messageUpdate } = data;

    let wbotInstance;
    try {
      wbotInstance = getWbot(wbotId);
    } catch (error) {
      console.error(`Error getting Wbot instance for ID ${wbotId}:`, error);
      // Decide how to handle: throw, retry, or skip
      return; // Skipping for now if wbot doesn't exist
    }

    for (const update of messageUpdate) {
      if (!update.key?.remoteJid || !update.key?.id) {
        console.warn(
          `Skipping message update due to missing key information for tenant ${tenantId}, Wbot ${wbotId}`
        );
        continue;
      }

      try {
        // Original logic marked messages as read
        // wbotInstance.sendPresenceUpdate('available', update.key.remoteJid); // Example: Set presence
        // await wbotInstance.chatModify({ markRead: true, lastMessages: [update] }, update.key.remoteJid); // Example: Mark read
        // Original code had complex logic for specific statuses, simplifying here:

        const messageStatus = update.status;
        const remoteJid = update.key.remoteJid;
        const messageId = update.key.id;

        // Handle deleted messages (status 5)
        // The original code checked status 5 and called MarkDeleteWhatsAppMessage
        if (messageStatus === proto.WebMessageInfo.Status.SERVER_ACK) {
          // Using SERVER_ACK as stand-in for 5, adjust if Baileys uses different enum/value for delete
          if (remoteJid && messageId) {
            console.log(
              `Marking message ${messageId} in chat ${remoteJid} as deleted (status ${messageStatus}) for tenant ${tenantId}`
            );
            // Pass tenantId if the service requires it
            await MarkDeleteWhatsAppMessage(
              remoteJid,
              null,
              messageId,
              tenantId
            );
          }
        }

        // Handle ACK updates by queueing to handleMessageAckQueue
        // Original logic checked if status is a finite number
        if (Number.isFinite(messageStatus)) {
          const ackStatus = messageStatus as number; // Cast status to number

          // Queue the ACK update
          const queueData: QueueJobData = {
            msg: update,
            ack: ackStatus,
            whatsappId: wbotId, // Use wbotId as whatsappId for the ack queue
            jobId: `${wbotId}-handleMessageAck-${messageId}` // Unique Job ID
          };

          // The queue name was 'handleMessageAckQueue' concatenated with tenantId
          const queueName = `handleMessageAckQueue-${tenantId}`;
          await Queue.add(queueName, queueData);
          // console.log(`ACK update ${ackStatus} for message ${messageId} queued for tenant ${tenantId}`);
        } else {
          // console.log(`Skipping ACK queue for message ${messageId}, status: ${messageStatus}`);
        }
      } catch (error: any) {
        console.error(
          `Error processing message update for message ${update.key?.id} and tenant ${tenantId}:`,
          error
        );
        // Optionally, log to Sentry or re-throw
        // Sentry.captureException(error, { extra: { tenantId, wbotId, messageId: update.key?.id } });
        // If one update fails, should it stop others? Current loop continues.
      }
    }
  }
};
