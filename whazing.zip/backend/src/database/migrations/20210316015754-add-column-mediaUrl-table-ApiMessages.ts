import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Validación simple para verificar si es una URL
    const urlValidation = { isUrl: true };

    // Añade la columna 'mediaUrl' a la tabla 'ApiMessages'
    return queryInterface.addColumn("ApiMessages", "mediaUrl", {
      type: DataTypes.TEXT,
      allowNull: true, // Permite nulos
      defaultValue: null,
      validate: urlValidation // Aplica la validación de URL
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'mediaUrl' de la tabla 'ApiMessages'
    return queryInterface.removeColumn("ApiMessages", "mediaUrl");
  }
};
