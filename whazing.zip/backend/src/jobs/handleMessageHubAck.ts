import UpdateMessageAck from '../services/WbotNotificame/UpdateMessageAck'; // Assuming default export

interface MessageHubAckData {
    messageId: string; // or number if applicable
    wabaMediaId?: string; // Optional based on usage
    ack: number | string; // Ack status code
}

interface Job {
    data: MessageHubAckData;
}

interface BackoffOptions {
    type: string;
    delay: number;
}

interface HandleOptions {
    delay: number;
    attempts: number;
    removeOnComplete: boolean;
    removeOnFail: boolean;
    backoff: BackoffOptions;
}

const backoffOptions: BackoffOptions = {
    type: 'fixed',
    delay: 180000 // 0x2bf20
};

const handleOptions: HandleOptions = {
    delay: 600,         // 0x258
    attempts: 3,
    removeOnComplete: true,
    removeOnFail: true,
    backoff: backoffOptions
};

export const handleMessageHubAck = {
    key: 'handleMessageHubAck',
    options: handleOptions,
    async handle({ data }: Job): Promise<void> {
        try {
            const { messageId, wabaMediaId, ack } = data;
            // Ensure ack is a number
            const ackNumber = Number(ack);
            if (isNaN(ackNumber)) {
                console.error(`Invalid ACK value received: ${ack}`);
                throw new Error(`Invalid ACK value: ${ack}`);
            }
            await UpdateMessageAck(messageId, wabaMediaId, ackNumber);
        } catch (error: any) {
            console.error("Error handling Message Hub Ack job:", error);
            throw error; // Re-throw error for queue processing
        }
    }
};