'use strict';

import FindUpdateTicketsautoClose from "../services/TicketServices/FindUpdateTicketsautoClose";
import FindUpdateTicketsautoPending from "../services/TicketServices/FindUpdateTicketsautoPending"; // Servicio para tickets pendientes
import { logger } from "../utils/logger";
import AppError from "../errors/AppError"; // Asumiendo que tienes un archivo para errores personalizados
import * as Sentry from "@sentry/node"; // Import Sentry si lo usas para captura de errores

// Opciones para el trabajo de la cola (ejemplo con Bull)
const jobOptions = {
    // attempts: 3, // Ejemplo: Número de reintentos
    // backoff: { type: 'fixed', delay: 60000 } // Ejemplo: Retraso entre reintentos (60 seg)
};

const queueOptions = {
    removeOnComplete: true, // Elimina el trabajo al completar
    removeOnFail: true,     // Elimina el trabajo si falla
    jobId: "VerifyTicketsautoClose", // ID fijo para este trabajo recurrente
    repeat: { every: 60000 }, // Repetir cada 60 segundos (1 minuto)
    ...jobOptions
};

export default {
    key: "VerifyTicketsautoClose", // Clave única para este tipo de trabajo
    options: queueOptions,

    async handle(): Promise<void> {
        try {
            logger.info("Verify Tickets autoClose Iniciado");

            // Ejecutar el servicio para cerrar tickets inactivos
            await FindUpdateTicketsautoClose();

            // Ejecutar el servicio para marcar tickets como pendientes (si aplica)
            await FindUpdateTicketsautoPending();

            logger.info("Verify Tickets autoClose Finalizado");

        } catch (err: any) {
             // Capturar la excepción con Sentry si está configurado
             Sentry.captureException(err);

             logger.error("Error send message:", err.message); // Mensaje de error genérico traducido
             // Lanzar el error para que Bull pueda manejar los reintentos o marcar como fallido
             throw err; // Usa 'throw new AppError(err.message);' si prefieres tu clase de error
        }
    }
};