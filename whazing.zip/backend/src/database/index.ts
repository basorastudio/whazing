'use strict';

// Importaciones de módulos y tipos necesarios
import { Sequelize } from "sequelize-typescript";
import User from "../models/User";
import Setting from "../models/Setting";
import Contact from "../models/Contact";
import Ticket from "../models/Ticket";
import Whatsapp from "../models/Whatsapp";
import ContactCustomField from "../models/ContactCustomField";
import Message from "../models/Message";
import MessageOffLine from "../models/MessageOffLine";
import AutoReply from "../models/AutoReply";
import StepsReply from "../models/StepsReply";
import StepsReplyAction from "../models/StepsReplyAction";
import Queue from "../models/Queue";
import UsersQueues from "../models/UsersQueues";
import Tenant from "../models/Tenant";
import AutoReplyLogs from "../models/AutoReplyLogs";
import UserMessagesLog from "../models/UserMessagesLog";
import FastReply from "../models/FastReply";
import Tag from "../models/Tag";
import ContactWallet from "../models/ContactWallet";
import ContactTag from "../models/ContactTag";
import Campaign from "../models/Campaign";
import CampaignContacts from "../models/CampaignContacts";
import ApiConfig from "../models/ApiConfig";
import ApiMessage from "../models/ApiMessage";
import LogTicket from "../models/LogTicket";
import ChatFlow from "../models/ChatFlow";
import * as QueueJobs from "../libs/Queue"; // Importa todo desde Queue como QueueJobs
import { logger } from "../utils/logger";
import InternalMessage from "../models/InternalMessage";
import Group from "../models/Group";
import UsersGroups from "../models/UsersGroups";
import ReadMessageGroups from "../models/ReadMessageGroups";
import Baileys from "../models/Baileys";
import Plan from "../models/Plan";
import SettingsGeneral from "../models/SettingsGeneral";
import Help from "../models/Help";
import Invoices from "../models/Invoices";
import Tasks from "../models/Tasks";
import UserRating from "../models/UserRating";
import BaileysKeys from "../models/BaileysKeys";
import QueueIntegrations from "../models/QueueIntegrations";
import FarewellMessage from "../models/FarewellMessage";
import Kanban from "../models/Kanban";
import File from "../models/File";
import TicketNote from "../models/TicketNote";
import Schedule from "../models/Schedule";
import KanbanOrder from "../models/KanbanOrder";
import WhatsappUsers from "../models/WhatsappUsers";
import KeywordChatFlow from "../models/KeywordChatFlow";
import WhatsappTemplate from "../models/WhatsappTemplate";

// Importa la configuración de la base de datos (requiere que el archivo exporte en formato CommonJS o tenga habilitado esModuleInterop)
import dbConfig = require("../config/database");

// Crea la instancia de Sequelize
const sequelize = new Sequelize(dbConfig);

// Array con todos los modelos a registrar
const models = [
    User,
    Contact,
    Ticket,
    Message,
    MessageOffLine,
    Whatsapp,
    ContactCustomField,
    Setting,
    AutoReply,
    StepsReply,
    StepsReplyAction,
    Queue,
    UsersQueues,
    Tenant,
    AutoReplyLogs,
    UserMessagesLog,
    FastReply,
    Tag,
    Baileys,
    Plan,
    ContactWallet,
    ContactTag,
    Campaign,
    CampaignContacts,
    ApiConfig,
    ApiMessage,
    LogTicket,
    ChatFlow,
    InternalMessage,
    Group,
    UsersGroups,
    SettingsGeneral,
    ReadMessageGroups,
    Help,
    Invoices,
    Tasks,
    UserRating,
    BaileysKeys,
    QueueIntegrations,
    FarewellMessage,
    Kanban,
    File,
    TicketNote,
    Schedule,
    KanbanOrder,
    WhatsappUsers,
    KeywordChatFlow,
    WhatsappTemplate
];

// Añade los modelos a la instancia de Sequelize
sequelize.addModels(models);

// Hook que se ejecuta después de establecer la conexión a la base de datos
sequelize.afterConnect(() => {
    logger.info("BASE DE DATOS CONECTADA"); // Mensaje traducido

    // Añade trabajos a las colas (asumiendo que QueueJobs.default tiene un método 'add')
    // Los nombres de las colas se mantienen como en el código original
    QueueJobs.default.add("VerifyTicketsInactives", {});
    QueueJobs.default.add("VerifyTicketsautoClose", {});
    QueueJobs.default.add("VerifyOnlineUsers", {});
    QueueJobs.default.add("VerifySchedules", {});
    QueueJobs.default.add("InvoiceCreation", {});
    QueueJobs.default.add("VerifyTicketsChatBot", {});
});

// Hook que se ejecuta después de cerrar la conexión a la base de datos
sequelize.afterDisconnect(() => {
    logger.info("BASE DE DATOS DESCONECTADA"); // Mensaje traducido
});

// Exporta la instancia de Sequelize configurada
export default sequelize;