import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna isGroup a la tabla Contacts
    return queryInterface.addColumn("Contacts", "isGroup", {
      // Nombre de columna preservado
      type: DataTypes.BOOLEAN,
      allowNull: false, // Asume que no puede ser nulo
      defaultValue: false // Por defecto, un contacto no es un grupo
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna isGroup
    return queryInterface.removeColumn("Contacts", "isGroup");
  }
};
