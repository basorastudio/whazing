import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'isDeleted' a la tabla 'Whatsapps'
    return Promise.all([
      queryInterface.addColumn("Whatsapps", "isDeleted", {
        type: DataTypes.BOOLEAN,
        defaultValue: false // Valor predeterminado es false
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'isDeleted' de la tabla 'Whatsapps'
    return Promise.all([queryInterface.removeColumn("Whatsapps", "isDeleted")]);
  }
};
