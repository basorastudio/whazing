import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'order' column to the 'Kanbans' table
    // Used for sorting Kanban columns/stages.
    await queryInterface.addColumn(
      'Kanbans', // Table name
      'order',   // New column name
      {
        type: DataTypes.INTEGER,
        allowNull: true,    // Allow null
        defaultValue: null, // Default is null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'order' column from the 'Kanbans' table
    await queryInterface.removeColumn(
      'Kanbans', // Table name
      'order'    // Column name to remove
    );
  }
};

export = migration;