import { Request, Response } from "express";
import axios from "axios";

// Define expected structure for the external API response if known
interface AuthResponseData {
  token?: string; // Example property
  // Add other properties expected from the external API
  [key: string]: any; // Allow other properties
}

// Define expected structure for the external API error if known
interface AuthErrorData {
  message?: string;
  // Add other potential error properties
}

export const autenticar = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { username, password } = req.body;

  try {
    // IMPORTANT: Replace placeholder URL with the actual authentication endpoint
    const authUrl =
      process.env.AUTH_API_URL || "YOUR_EXTERNAL_AUTH_API_ENDPOINT"; // Get from environment variable or config

    if (authUrl === "YOUR_EXTERNAL_AUTH_API_ENDPOINT") {
      console.error("Authentication endpoint URL is not configured!");
      return res.status(500).json({
        error: "Error en la configuración del servidor de autenticación."
      });
    }

    const requestData = {
      // Adjust payload according to the external API's requirements
      client_id: process.env.USUARIO_API, // Assuming these map to client_id/secret
      client_secret: process.env.SENHA_API
      // Or maybe username/password directly?
      // username: username,
      // password: password,
      // grant_type: 'password' // Example grant type
    };

    const response = await axios.post<AuthResponseData>(authUrl, requestData);

    // Return the data received from the external API
    return res.status(response.status).json(response.data);
  } catch (error: any) {
    console.error("Error during authentication request:", error);
    const errorMessage = "Error en la autenticación";
    let statusCode = 500;

    // Extract status code and specific error message from Axios error if available
    if (axios.isAxiosError(error) && error.response) {
      statusCode = error.response.status;
      const errorData = error.response.data as AuthErrorData;
      // Use specific message from API if available, otherwise generic one
      return res
        .status(statusCode)
        .json({ error: errorData?.message || errorMessage });
    }

    // Fallback for non-Axios errors or errors without a response
    return res.status(statusCode).json({ error: errorMessage });
  }
};

// Note: The original code exports an object with the function.
// Standard ES module export is usually preferred:
// export { autenticar };
// However, to maintain the original structure:
const controller = {
  autenticar
};
export default controller; // or module.exports = controller; if using CommonJS target
