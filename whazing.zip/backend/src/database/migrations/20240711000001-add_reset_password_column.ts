import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'resetPassword' column to the 'Users' table
    await queryInterface.addColumn(
      "Users", // Table name
      "resetPassword", // New column name
      {
        type: DataTypes.STRING,
        allowNull: true, // Allow null values
        defaultValue: "" // Default is an empty string
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'resetPassword' column from the 'Users' table
    await queryInterface.removeColumn(
      "Users", // Table name
      "resetPassword" // Column name to remove
    );
  }
};

export = migration;
