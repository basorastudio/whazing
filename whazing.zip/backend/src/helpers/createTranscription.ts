// Original: createTranscription.js
// Deobfuscated, converted to TS, and translated

'use strict';

import Groq from 'groq-sdk'; // Importación por defecto
import fs from 'fs';
import { RefreshToken } from './RefreshToken'; // Asumiendo exportación nombrada
import CheckSettingsHelper from './CheckSettingsHelper'; // Asumiendo exportación predeterminada
import CheckSettingsGeneral from './CheckSettingsGeneral'; // Asumiendo exportación predeterminada

async function createTranscription(audioFilePath: string, apiKey: string): Promise<string> {
    // Tokens y llaves de configuración (ajustar según sea necesario)
    const tokenGroq = RefreshToken('90a6acde49'); // Asumiendo que esto obtiene la clave de API Groq de forma segura
    const tokenCheckSetting = RefreshToken('d1a25cdd43'); // Asumiendo que esto es para verificar alguna configuración
    const settingAllowTranscription = await CheckSettingsHelper(tokenCheckSetting); // Verifica si la transcripción está habilitada

    // Clave de configuración general para texto de error (ejemplo)
    const settingErrorTranscriptionKey = 'errorTranscriptionText';
    // Obtener texto de error de configuración general, con valor por defecto
    const defaultErrorText = 'errorTranscription'; // Texto por defecto si no se encuentra
    const errorText = await CheckSettingsGeneral(settingErrorTranscriptionKey, defaultErrorText);


    // Si la configuración no coincide con la clave esperada (ej: deshabilitado), retornar texto de error
    if (settingAllowTranscription !== tokenGroq) {
        // Traducido: Error al intentar transcribir: Configuración deshabilitada
        return errorText || 'Erro ao tentar transcrever: Configuração desabilitada'; // Usar texto de error configurado o uno por defecto
    }


    try {
        // Inicializar el cliente Groq con la clave API obtenida
        const groq = new Groq({ apiKey }); // Usar la apiKey pasada como argumento

        // Verificar si el archivo de audio existe
        if (!fs.existsSync(audioFilePath)) {
            // Traducido: Archivo de audio no encontrado
            throw new Error('Audio file not found');
        }

        // Crear la transcripción usando la API de Groq
        const transcription = await groq.audio.transcriptions.create({
            file: fs.createReadStream(audioFilePath),
            model: 'whisper-large-v3', // Modelo de Whisper a utilizar
            response_format: 'json', // Formato de respuesta deseado
            // language: 'pt', // Opcional: Especificar idioma si es necesario
            // temperature: 0.2 // Opcional: Ajustar temperatura
        });

        return transcription.text; // Devolver el texto transcrito

    } catch (error) {
        // Traducido: Error al intentar transcribir audio a texto
        console.error('Error al intentar transcribir audio a texto:', error);
         // Retornar el texto de error configurado o uno por defecto
        return errorText || 'Erro ao processar o áudio para texto.';
    }
}

export default createTranscription; // Exportación por defecto