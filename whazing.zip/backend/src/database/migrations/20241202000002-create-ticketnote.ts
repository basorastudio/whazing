import { QueryInterface, DataTypes, Sequelize } from 'sequelize'; // Added Sequelize
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'TicketNotes' table
    await queryInterface.createTable(
      'TicketNotes', // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
          allowNull: false,
        },
        note: { // The content of the note
          type: DataTypes.TEXT,
          allowNull: false,
        },
        userId: { // User who created the note
          type: DataTypes.INTEGER,
          allowNull: false,
          references: { model: 'Users', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL', // Keep note if user is deleted?
        },
        contactId: { // Optional: Contact the note might relate to
          type: DataTypes.INTEGER,
          allowNull: true,
          references: { model: 'Contacts', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL',
        },
        ticketId: { // Ticket the note belongs to
          type: DataTypes.INTEGER,
          allowNull: false,
          references: { model: 'Tickets', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE', // Delete note if ticket is deleted
        },
        tenantId: {
          type: DataTypes.INTEGER,
          allowNull: false,
          references: { model: 'Tenants', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'CASCADE', // Delete note if tenant is deleted
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'),
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
          defaultValue: Sequelize.fn('NOW'),
        },
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'TicketNotes' table
    await queryInterface.dropTable('TicketNotes');
  }
};

export = migration;