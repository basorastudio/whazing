import { default as SendMessageWhatsappCampaign } from './SendMessageWhatsappCampaign';
import { default as SendMessageAPI } from './SendMessageAPI';
import { default as VerifyTicketsChatBotInactives } from './VerifyTicketsChatBotInactives';
import { default as VerifyOnlineUsers } from './VerifyOnlineUsers';
import { default as InvoiceCreate } from './InvoiceCreate';
import { default as VerifyTicketsautoClose } from './VerifyTicketsautoClose';
import { default as handleMessageAckQueue } from './handleMessageAckQueue';
import { default as handleMessageQueue } from './handleMessageQueue';
import { default as sendMessageHub } from './sendMessageHub'; // Renamed from handle to sendMessageHub for clarity
import { default as sendMessageBaileys } from './sendMessageBaileys'; // Renamed from handle to sendMessageBaileys
import { default as messageUpsert } from './messageUpsert'; // Renamed from handle
import { default as messageUpdate } from './messageUpdate'; // Renamed from handle
import { default as VerifySchedules } from './VerifySchedules';
import { default as SendWebhook } from './SendWebhook';
import { default as RecoveryMessage } from './RecoveryMessage';
import { default as handleMessageHub } from './handleMessageHub'; // Renamed from handle
import { default as handleMessageHubAck } from './handleMessageHubAck'; // Renamed from handle
import { default as sendMessageWWebJS } from './sendMessageWWebJS'; // Renamed from handle

// Exporting all jobs for the queue processor
// Using original keys where possible, otherwise inferred names
export {
    SendMessageWhatsappCampaign,
    SendMessageAPI,
    VerifyTicketsChatBotInactives, // Key: VerifyTicketsChatBotInactives
    VerifyOnlineUsers,             // Key: VerifyOnlineUsers
    InvoiceCreate,                 // Key: InvoiceCreate
    VerifyTicketsautoClose,        // Key: VerifyTicketsautoClose
    handleMessageAckQueue,         // Key: handleMessageAckQueue (Original: handleMsgAckBaileys)
    handleMessageQueue,            // Key: HandleMessageQueue
    sendMessageHub,                // Key: SendMessageHub (Different from handleMessageHub)
    sendMessageBaileys,            // Key: SendMessageBaileys
    messageUpsert,                 // Key: messageUpsert
    messageUpdate,                 // Key: messageUpdate
    VerifySchedules,               // Key: VerifySchedules
    SendWebhook,                   // Key: SendWebhook
    RecoveryMessage,               // Key: RecoveryMessage
    handleMessageHub,              // Key: HandleMessageHub
    handleMessageHubAck,           // Key: handleMessageHubAck
    sendMessageWWebJS              // Key: SendMessageWWebJS
};

// It might be cleaner to export an array or map if the queue system prefers that:
/*
export const jobs = [
    SendMessageWhatsappCampaign,
    SendMessageAPI,
    VerifyTicketsChatBotInactives,
    VerifyOnlineUsers,
    InvoiceCreate,
    VerifyTicketsautoClose,
    handleMessageAckQueue,
    handleMessageQueue,
    sendMessageHub,
    sendMessageBaileys,
    messageUpsert,
    messageUpdate,
    VerifySchedules,
    SendWebhook,
    RecoveryMessage,
    handleMessageHub,
    handleMessageHubAck,
    sendMessageWWebJS
];
*/