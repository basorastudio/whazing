import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert payment-related settings into 'SettingsGeneral'
    // Assuming 'public."SettingsGeneral"' based on previous files
    // Values like 'efiClientId', 'efiClientSecret', 'efiPixKey' suggest EFI Pagamentos integration keys.
    // 'owenSecretKey', 'owenCnpj', 'owenToken' suggest another integration (Owen?).
    // 'paymentGateway' specifies the default gateway.
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('efiClientId', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('efiClientSecret', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('efiPixKey', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('efiCertFile', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('paymentGateway', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('owenSecretKey', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('owenCnpj', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('owenToken', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted payment settings
    await queryInterface.bulkDelete(
      'SettingsGeneral', // Adjust schema if needed
      {
        key: [
          'efiClientId',
          'efiClientSecret',
          'efiPixKey',
          'efiCertFile',
          'paymentGateway',
          'owenSecretKey',
          'owenCnpj',
          'owenToken'
        ]
      }
    );
  }
};

export = migration;