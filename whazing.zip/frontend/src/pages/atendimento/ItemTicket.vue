<template>
  <q-list separator
    style="max-width: 100%"
    class="q-px-sm q-py-none q-pt-sm">
    <q-item clickable
      style="height: 95px; max-width: 100%;"
      @click="abrirChatContato(ticket)"
      :style="`border-left: 6px solid ${borderColor[ticket.status]}; border-radius: 10px`"
      id="item-ticket-houve"
      class=" ticketBorder q-px-sm"
      :class="{
        'ticketBorderGrey': !$q.dark.isActive,
        'ticket-active-item': ticket.id === $store.getters['ticketFocado'].id,
        'ticketNotAnswered': ticket.answered == false && ticket.isGroup == false && ticket.status == 'open'
      }">
      <q-item-section avatar
        class="q-px-none">
        <q-btn flat
          @click="iniciarAtendimento(ticket)"
          push
          color="$cor2"
          dense
          round
          v-if="(ticket.status === 'pending' && !ticket.disableRespondHub) || (buscaTicket && ticket.status === 'pending' && !ticket.disableRespondHub)"
        >
          <q-badge v-if="ticket.unreadMessages && ticket.status !== 'closed'"
            style="border-radius: 10px;"
            class="text-center text-bold"
            floating
            dense
            text-color="white"
            color="red"
            :label="ticket.unreadMessages" />
          <q-avatar>
            <q-icon size="50px"
              name="mdi-account-arrow-right" />
          </q-avatar>
          <q-tooltip>
            Atender
          </q-tooltip>
        </q-btn>
        <q-avatar size="50px"
                  v-if="ticket.status !== 'pending'"
          class="relative-position">
          <q-badge v-if="ticket.unreadMessages"
            style="border-radius: 10px; z-index: 99"
            class="text-center text-bold"
            floating
            dense
            text-color="white"
            color="red"
            :label="ticket.unreadMessages" />
          <img :src="ticket.contact.profilePicUrl"
            onerror="this.style.display='none'"
            v-show="ticket.contact.profilePicUrl">
          <q-icon size="50px"
            name="mdi-account-circle"
            color="grey-8" />
        </q-avatar>

      </q-item-section>
      <q-item-section id="ListItemsTicket" >
        <q-item-label class="text-bold"
          lines="1">
          {{ truncatedMessage(!ticket.name ? ticket.contact.name : ticket.name, 22) }}
          <q-icon size="20px"
            :name="`img:${ticket.channel}-logo.png`" />
          <span class="absolute-top-right q-pr-xs">
            <q-badge dense
                     style="font-size: .7em; color-light3"
                     :style="$q.dark.isActive ? ('font-size: .7em; color-dark3') : ''"
                     transparent
                     square
                     color="color-light2"
                     :label="dataInWords(ticket.lastMessageAt, ticket.updatedAt)"
                     :key="recalcularHora" />
          </span>
        </q-item-label>
        <q-item-label lines="1"
          caption>
          {{ truncatedMessage(ticket.lastMessage, 20) }}
        </q-item-label>
        <q-item-label lines="1"
          caption>
          #{{ ticket.id }}
          <q-icon
            v-for="wallet in ticket.contact.wallets"
            :key="wallet.id"
            name="mdi-wallet"
            size="1.4em"
            class="q-mb-sm">
            <q-tooltip>
              {{ wallet.name }}
            </q-tooltip>
          </q-icon>
          <q-chip
          :style="chipStyle"
          dense
          square
          :label="chipLabel"
          size="11px"
          class="q-mr-md text-bold"
          />
          <q-icon
            v-for="tag in ticket.contact.tags"
            :key="tag.id"
            :style="{ color: tag.color }"
            name="mdi-tag"
            size="1.4em"
            class="q-mb-sm">
            <q-tooltip>
              {{ tag.tag }}
            </q-tooltip>
          </q-icon>
          <span class="absolute-bottom-right ">
            <q-icon v-if="ticket.status === 'closed'"
              name="mdi-check-circle-outline"
              color="positive"
              size="1.8em"
              class="q-mb-sm">
              <q-tooltip>
                Atención Resuelta
              </q-tooltip>
            </q-icon>
            <q-icon
              v-if="(ticket.stepAutoReplyId && ticket.autoReplyId && ticket.status === 'pending') || (ticket.chatFlowId && ticket.stepChatFlow && ticket.status === 'pending')"
              name="mdi-robot"
              color="primary"
              size="1.8em"
              class="q-mb-sm">
              <q-tooltip>
                ChatBot atendiendo
              </q-tooltip>
            </q-icon>
            <q-icon
              v-if="(ticket.typebotStatus && ticket.useIntegration && ticket.status === 'pending')"
              name="mdi-robot-outline"
              color="primary"
              size="1.8em"
              class="q-mb-sm">
              <q-tooltip>
                Typebot atendiendo
              </q-tooltip>
            </q-icon>
            <q-icon
              v-if="(ticket.IA && ticket.useIntegration && ticket.status === 'pending')"
              name="mdi-robot-happy"
              color="primary"
              size="1.8em"
              class="q-mb-sm">
              <q-tooltip>
                IA atendiendo
              </q-tooltip>
            </q-icon>
          </span>
        </q-item-label>
        <q-item-label class="row col items-center justify-between"
          caption>
          {{ truncatedMessage(ticket.user?.name || '', 17) }}
          <q-chip :style="{ backgroundColor: ticket.whatsapp.color, color: 'white' }"
            dense
            square
            :label="ticket.whatsapp && ticket.whatsapp.name
            ? (ticket.whatsapp.name.length > 8
            ? ticket.whatsapp.name.slice(0, 8) + '...'
            : ticket.whatsapp.name)
            : ''"
                  size="10px"
            class="q-mr-md text-bold" />
        </q-item-label>
        </q-item-section>
        <q-item-section avatar
        class="q-px-none">

<q-btn flat
          v-if="ticket.status === 'open' || (buscaTicket && ticket.status === 'open')"
          @click="atualizarStatusTicket2(ticket, 'closed')"
          push
          dense
          round
          class="btn-rounded"
          :class="{
          'color-dark2 bg-black': $q.dark.isActive,
          'tab-item': !$q.dark.isActive
          }">
          <q-avatar>
            <q-icon size="20px"
              name="eva-checkmark-circle-2-outline" />
          </q-avatar>
          <q-tooltip>
            Resolver
          </q-tooltip>
        </q-btn>

      </q-item-section>
    </q-item>
  </q-list>
</template>

<script>
import { formatDistance, parseJSON } from 'date-fns'
import es from 'date-fns/locale/es'
import mixinAtualizarStatusTicket from './mixinAtualizarStatusTicket'
import { outlinedAccountCircle } from '@quasar/extras/material-icons-outlined'

export default {
  name: 'ItemTicket',
  mixins: [mixinAtualizarStatusTicket],
  data () {
    return {
      isTicketModalOpen: false,
      currentTicket: {},
      walletsDoTicket: [],
      // colorName: null,
      outlinedAccountCircle,
      recalcularHora: 1,
      statusAbreviado: {
        open: 'A',
        pending: 'P',
        closed: 'R'
      },
      status: {
        open: 'Abierto',
        pending: 'Pendiente',
        closed: 'Resuelto'
      },
      color: {
        open: 'primary',
        pending: 'negative',
        closed: 'positive'
      },
      borderColor: {
        open: 'primary',
        pending: 'negative',
        closed: 'positive'
      }
    }
  },
  props: {
    ticket: {
      type: Object,
      default: () => {
      }
    },
    buscaTicket: {
      type: Boolean,
      default: false
    },
    filas: {
      type: Array,
      default: () => []
    },
    etiquetas: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    chipStyle() {
      return { backgroundColor: this.ticket.color || this.obterCorFila(this.ticket) || 'grey', color: 'white' }
    },
    chipLabel() {
      const label = this.obterNomeFila(this.ticket) || 'SIN COLA'
      return label.length > 15 ? label.slice(0, 12) + '...' : label
    }
  },
  methods: {
    truncatedMessage(message, maxLength) {
      if (!message) {
        return ''
      }
      if (message.length > maxLength) {
        return message.substring(0, maxLength) + '...'
      }
      return message
    },
    closeModal() {
      this.isTicketModalOpen = false
    },
    obterNomeFila (ticket) {
      try {
        const fila = this.filas.find(f => f.id === ticket.queueId)
        if (fila) {
          return fila.queue
        }
        return ''
      } catch (error) {
        return ''
      }
    },
    obterCorFila (ticket) {
      try {
        const fila = this.filas.find(f => f.id === ticket.queueId)
        if (fila) {
          return fila.color
        }
        return ''
      } catch (error) {
        return ''
      }
    },
    dataInWords (timestamp, updated) {
      let data = parseJSON(updated)
      if (timestamp) {
        data = new Date(Number(timestamp))
      }
      return formatDistance(data, new Date(), { locale: es })
    },
    abrirChatContato (ticket) {
      // caso esteja em um tamanho mobile, fechar a drawer dos contatos
      if (this.$q.screen.lt.md && ticket.status !== 'pending') {
        this.$root.$emit('infor-cabecalo-chat:acao-menu')
      }
      if (!((ticket.id !== this.$store.getters.ticketFocado.id || this.$route.name !== 'chat'))) return
      this.$store.commit('SET_HAS_MORE', true)
      this.$store.dispatch('AbrirChatMensagens', ticket)
    }
  },
  created () {
    setInterval(() => {
      this.recalcularHora++
    }, 20000)
  }
}
</script>

<style lang="sass">
img:after
  content: ""
  vertical-align: middle
  display: inline-block
  border-radius: 50%
  font-size: 48px
  position: absolute
  top: 0
  left: 0
  width: inherit
  height: inherit
  z-index: 10
  color: transparent

.ticket-active-item
  // border: 2px solid rgb(21, 120, 173)
  // border-left: 3px solid $light //rgb(21, 120, 173)
  border-radius: 0
  position: relative
  height: 100%
  background: $blue-1 //$active-item-ticket
  // background-color: #e6ebf5

#ListItemsTicket
  .q-item__label + .q-item__label
    margin-top: 1.5px

#item-ticket-houve:hover
  background: $blue-1 //$active-item-ticket
  transition: all .2s

.primary
  border-left: 3px solid $primary
.negative
  border-left: 3px solid $negative
.positive
  border-left: 3px solid $positive

.ticketNotAnswered
  border-left: 5px solid $warning !important

.ticketBorder
  border-left: 5px solid $grey-9

.ticketBorderGrey
  border-left: 5px solid $grey-4
</style>
