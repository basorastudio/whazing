import { Request, Response } from "express";
import StatisticsPerUsersService from "../../services/Statistics/StatisticsPerUsers";

// Define una interfaz para los query params
interface DateRangeQuery {
  startDate?: string;
  endDate?: string;
}

// Define una interfaz para los parámetros del servicio
interface StatisticsParams {
  startDate?: string;
  endDate?: string;
  tenantId: number;
}

/**
 * Controlador para obtener estadísticas por usuario.
 */
export const index = async (req: Request, res: Response): Promise<Response> => {
  // Asume que req.user contiene tenantId después de la autenticación
  // Añade validación o aserción de no nulo si es necesario
  const tenantId = req.user!.tenantId;
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: StatisticsParams = {
    startDate,
    endDate,
    tenantId
  };

  // Llama al servicio para obtener las estadísticas
  const statistics = await StatisticsPerUsersService(params);

  // Devuelve las estadísticas como JSON
  return res.json(statistics);

  // Considera añadir manejo de errores try...catch aquí también
  // try {
  //   const statistics = await StatisticsPerUsersService(params);
  //   return res.json(statistics);
  // } catch (error) {
  //   console.error("Error fetching statistics per user:", error);
  //   return res.status(500).json({ error: "Error al obtener las estadísticas por usuario" });
  // }
};
