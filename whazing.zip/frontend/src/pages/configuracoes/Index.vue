<template>
  <div class="mass-container container-rounded-10" :class="$q.dark.isActive ? 'text-color-dark bg-grey-10' : 'container-border'" v-if="userProfile === 'admin'">
    <q-list class="text-weight-medium">
      <q-item-label header :class="['text-bold text-h6 q-mb-lg', $q.dark.isActive ? 'text-color-dark' : 'text-black']">
        Configuraciones
      </q-item-label>
      <q-item-label caption class="q-mt-lg q-pl-sm">Módulo: Atención</q-item-label>
      <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Agrupar mensajes tickets diferentes</q-item-label>
          <q-item-label caption>Al activar esta opción todos los mensajes se mostrarán como si fueran del mismo ticket.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="GroupTicketsMessages" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="GroupTicketsMessages === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('GroupTicketsMessages')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Reabrir tickets anteriores (esta opción hace que las métricas tengan datos incorrectos)</q-item-label>
          <q-item-label caption>Con esta opción activada, si ya existe un ticket cerrado, se reabrirá en lugar de crear uno nuevo.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ReopenTicket" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="ReopenTicket === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('ReopenTicket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Visualizar solo mensajes de las colas a las que pertenece el usuario</q-item-label>
          <q-item-label caption>Al activar esta opción, los mensajes se separan por cola, los usuarios no pueden ver mensajes que no forman parte de su cola</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="MessagesforTicket" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="MessagesforTicket === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('MessagesforTicket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Administrador y Supervisores en modo auditoría</q-item-label>
          <q-item-label caption>Los tickets accedidos por el administrador o Supervisores no serán marcados como leídos</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="auditMode" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="auditMode === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('auditMode')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>No visualizar Tickets Privados ya atribuidos a otros usuarios</q-item-label>
          <q-item-label caption>Solamente el usuario responsable del ticket Privado y/o los administradores visualizarán la
            atención.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="NotViewAssignedTickets" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="NotViewAssignedTickets === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('NotViewAssignedTickets')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>No visualizar Tickets en el ChatBot</q-item-label>
          <q-item-label caption>Solamente los administradores podrán visualizar tickets que estén interactuando con el
            ChatBot.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="NotViewTicketsChatBot" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="NotViewTicketsChatBot === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('NotViewTicketsChatBot')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Habilitar guía de atención de Chatbots</q-item-label>
          <q-item-label caption> Habilitando esta opción será añadida una guía de atención exclusiva para los chatbots. </q-item-label>
        </q-item-section>

      <q-item-section avatar>
        <q-toggle
            v-model="chatbotLane"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="chatbotLane === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('chatbotLane')"
        />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Habilitar ocultar guía de atención sin tickets</q-item-label>
          <q-item-label caption>Habilitando esta opción solamente la guía de atención con tickets será visible.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="hidetab" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="hidetab === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('hidetab')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Mostrar estado de las conexiones en la pantalla de atención</q-item-label>
          <q-item-label caption>Habilitando esta opción en la parte inferior de la lista de atención se mostrarán las conexiones.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ExibirConexao" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="ExibirConexao === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('ExibirConexao')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Solamente los administradores pueden acceder a la lista de contactos</q-item-label>
          <q-item-label caption>Solamente los administradores visualizarán la lista de contactos en el sistema.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ContactAdmin" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="ContactAdmin === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('ContactAdmin')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Forzar atención vía Cartera</q-item-label>
          <q-item-label caption>En caso de que el contacto tenga una cartera vinculada, el sistema dirigirá la atención solamente
            para los dueños de la cartera de clientes.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="DirectTicketsToWallets" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="DirectTicketsToWallets === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('DirectTicketsToWallets')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Listar solamente los contactos de la cartera del Usuario</q-item-label>
          <q-item-label caption>Listará solamente los contactos de la cartera que estén vinculados al usuario</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userContactWallet" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="userContactWallet === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('userContactWallet')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Flujo activo para el Bot de atención</q-item-label>
          <q-item-label caption>Flujo a ser utilizado por el Bot para las nuevas atenciones</q-item-label>
        </q-item-section>
        <q-btn  @click="resetarFluxoAtivo"
            flat
            icon="mdi-replay"
            color="negative"
            class="bg-padrao btn-rounded" >
          <q-tooltip content-class="bg-negative text-bold">
            Resetear Flujo Chatbot
          </q-tooltip>
        </q-btn>
        <q-item-section avatar>
          <q-select style="width: 300px" outlined dense v-model="botTicketActive" :options="listaChatFlow" map-options
            emit-value option-value="id" option-label="name" @input="atualizarConfiguracao('botTicketActive')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="canAccessPage">
        <q-item-section>
          <q-item-label>Ignorar Mensajes de Grupo</q-item-label>
          <q-item-label caption>Habilitando esta opción el sistema no abrirá ticket para grupos</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="ignoreGroupMsg" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
            :color="ignoreGroupMsg === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
            @input="atualizarConfiguracao('ignoreGroupMsg')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="canAccessPage">
        <q-item-section>
          <q-item-label>Habilitar notificaciones de grupos</q-item-label>
          <q-item-label caption>Habilitando esta opción las notificaciones de mensajes de grupos aparecerán.</q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="groupnotification" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="groupnotification === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('groupnotification')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Ignorar Mensajes Enviados fuera de la aplicación</q-item-label>
          <q-item-label caption>Habilitando esta opción el sistema no descargará mensajes que envíes desde otras plataformas como wasender por ejemplo</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="IgnoreMessageExt" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
                    :color="IgnoreMessageExt === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
                    @input="atualizarConfiguracao('IgnoreMessageExt')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Rechazar llamadas en Whatsapp</q-item-label>
          <q-item-label caption>Cuando está activo, las llamadas de audio y video serán rechazadas,
            automáticamente.</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="rejectCalls" false-value="disabled" true-value="enabled" checked-icon="check" keep-color
            :color="rejectCalls === 'enabled' ? 'green' : 'negative'" size="md" unchecked-icon="clear"
            @input="atualizarConfiguracao('rejectCalls')" />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="rejectCalls === 'enabled'">
        <div class="col-12">
          <q-input v-model="callRejectMessage" type="textarea" autogrow dense outlined
            label="Mensaje al rechazar llamada:" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
            @input="atualizarConfiguracao('callRejectMessage')" />
        </div>
      </div>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Permitir que el usuario deshabilite la firma</q-item-label>
          <q-item-label caption>Los usuarios podrán desactivar la firma de los mensajes</q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userDisableSignature" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="userDisableSignature === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('userDisableSignature')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Usuarios pueden espiar ticket</q-item-label>
          <q-item-label caption>Desactivando esta opción solamente los administradores pueden ver mensajes antes de iniciar atención</q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="spyticket" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="spyticket === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('spyticket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Usuarios pueden reabrir ticket</q-item-label>
          <q-item-label caption>Desactivando esta opción solamente los administradores pueden reabrir tickets cerrados</q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="userReopenTicket" false-value="disabled" true-value="enabled" checked-icon="check"
            keep-color :color="userReopenTicket === 'enabled' ? 'green' : 'negative'" size="md"
            unchecked-icon="clear" @input="atualizarConfiguracao('userReopenTicket')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
<q-item-label>Si el agente tarda en responder, devolver tickets a Pendientes</q-item-label>
<q-item-label caption>En caso de que el agente tarde en responder el contacto, el ticket volverá automáticamente a los Tickets pendientes.</q-item-label>
        </q-item-section>

      <q-item-section avatar>
        <q-toggle
            v-model="autoPending"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="autoPending === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('autoPending')"
        />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="autoPending === 'enabled'">
        <div class="col-12">
          <q-input
              v-model="autoPendingTime"
              type="number"
              label="Tiempo en minutos para volver a Pendientes"
              dense
              outlined
              autogrow
              debounce="700"
              input-style="min-height: 6vh; max-height: 9vh;"
              @input="atualizarConfiguracao('autoPendingTime')"
            />
        </div>
      </div>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Máximo de veces que el mensaje de horario de atención debe ser enviado al cliente.</q-item-label>
            <q-item-label caption>Inserte aquí la cantidad de veces que el mensaje de ausencia puede ser enviado para cada atención...</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-input
              v-model="maxRetriesBusinessHours"
              type="number"
              dense
              outlined
              debounce="700"
              @input="atualizarConfiguracao('maxRetriesBusinessHours')"
              style="width: 300px"
            />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Cantidad de tickets abiertos que se cargarán en la pantalla de atención.</q-item-label>
          <q-item-label caption>Inserte aquí la cantidad de tickets que se cargarán en la pantalla de atención...</q-item-section>
        <q-item-section avatar>
          <q-input
            v-model="TicketsLimitOpen"
            type="number"
            dense
            outlined
            debounce="700"
            @input="atualizarConfiguracao('TicketsLimitOpen')"
            style="width: 300px"
          />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Cantidad de tickets pendientes que se cargarán en la pantalla de atención.</q-item-label>
          <q-item-label caption>Inserte aquí la cantidad de tickets que se cargarán en la pantalla de atención...</q-item-section>
        <q-item-section avatar>
          <q-input
            v-model="TicketsLimitPending"
            type="number"
            dense
            outlined
            debounce="700"
            @input="atualizarConfiguracao('TicketsLimitPending')"
            style="width: 300px"
          />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Cantidad de tickets cerrados que se cargarán en la pantalla de atención.</q-item-label>
            <q-item-label caption>Inserte aquí la cantidad de tickets que se cargarán en la pantalla de atención...</q-item-section>
        <q-item-section avatar>
          <q-input
              v-model="TicketsLimitClosed"
              type="number"
              dense
              outlined
              debounce="700"
              @input="atualizarConfiguracao('TicketsLimitClosed')"
              style="width: 300px"
            />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Lista de tickets cerrados mostrar solamente el último ticket del contacto</q-item-label>
          <q-item-label caption>Con esta opción activada en la lista de atención los tickets cerrados mostrarán solamente el último ticket del contacto</q-item-section>

        <q-item-section avatar>
          <q-toggle
            v-model="GroupClosedTicket"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="GroupClosedTicket === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('GroupClosedTicket')"
          />
        </q-item-section>
      </q-item>

      <q-item-label caption class="q-mt-lg q-pl-sm">Módulo: Integración</q-item-label>
      <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Habilitar integración vía iframe</q-item-label>
          <q-item-label caption>Permite integrar Whazing en otros sitios web mediante un iframe</q-item-label>
        </q-item-section>
        <q-item-section avatar>
          <q-toggle
            v-model="enableIframeEmbed"
            false-value="disabled"
            true-value="enabled"
            checked-icon="check"
            keep-color
            :color="enableIframeEmbed === 'enabled' ? 'green' : 'negative'"
            size="md"
            unchecked-icon="clear"
            @input="atualizarConfiguracao('enableIframeEmbed')"
          />
        </q-item-section>
      </q-item>

      <div class="row q-px-md" v-if="enableIframeEmbed === 'enabled'">
        <div class="col-12 q-mb-md">
          <q-input
            v-model="allowedDomain"
            type="text"
            label="Dominio autorizado (ejemplo: miempresa.com)"
            dense
            outlined
            debounce="700"
            @input="atualizarConfiguracao('allowedDomain')"
          />
        </div>
        <div class="col-12">
          <q-card class="bg-grey-2">
            <q-card-section>
              <div class="text-subtitle2">Código de integración</div>
              <q-input
                v-model="iframeCode"
                type="textarea"
                readonly
                :value="'<iframe\n  id="whazing-iframe"\n  src="' + window.location.origin + '/embedded"\n  style="width: 100%; border: none; min-height: 600px;"\n  allow="camera; microphone"\n></iframe>\n\n<script>\nwindow.addEventListener(\'message\', function(event) {\n  const iframe = document.getElementById(\'whazing-iframe\');\n  if (event.data.type === \'RESIZE\') {\n    iframe.style.height = event.data.height + \'px\';\n  }\n});\n</script>'"
              />
              <q-btn
                class="q-mt-sm"
                color="primary"
                label="Copiar código"
                icon="content_copy"
                @click="copyIframeCode"
              />
            </q-card-section>
          </q-card>
        </div>
      </div>

      <q-item-label caption class="q-mt-lg q-pl-sm">Módulo: CRM</q-item-label>
      <q-separator spaced />

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Compartir CRM entre todos los usuarios</q-item-label>
          <q-item-label caption>Con esta opción activada el CRM será el mismo para cualquier usuario.</q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanGlobal" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanGlobal === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanGlobal')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="KanbanGlobal === 'disabled'">
        <q-item-section>
          <q-item-label>Listar contactos de tickets sin usuarios en el CRM</q-item-label>
          <q-item-label caption>Con esta opción activada en caso de que exista un ticket sin usuario asignado se mostrará el contacto en el CRM.</q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanUserNull" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanUserNull === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanUserNull')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple>
        <q-item-section>
          <q-item-label>Listar contactos que el ticket esté cerrado</q-item-label>
          <q-item-label caption>Con esta opción desactivada no se mostrará el contacto en el CRM si el ticket está cerrado, solamente tickets abiertos o pendientes.</q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanTicketClosed" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanTicketClosed === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanTicketClosed')" />
        </q-item-section>
      </q-item>

      <q-item tag="label" v-ripple v-if="KanbanGlobal === 'disabled'">
        <q-item-section>
          <q-item-label>Separar lista de lane por usuario</q-item-label>
          <q-item-label caption>Con esta opción desactivada, todas las lanes son compartidas entre usuarios y solamente el admin puede crear, editar o borrar lanes.</q-item-section>
        <q-item-section avatar>
          <q-toggle v-model="KanbanforUser" false-value="disabled" true-value="enabled" checked-icon="check"
                    keep-color :color="KanbanforUser === 'enabled' ? 'green' : 'negative'" size="md"
                    unchecked-icon="clear" @input="atualizarConfiguracao('KanbanforUser')" />
        </q-item-section>
      </q-item>

    </q-list>

<q-separator spaced />
  </div>
</template>

<script>
import { ListarChatFlow } from 'src/service/chatFlow'
import { ListarConfiguracoes, AlterarConfiguracao } from 'src/service/configuracoes'
import { MostrarPlano } from 'src/service/empresas'
import { ListarCores } from 'src/service/configuracoesgeneral'
export default {
  name: 'IndexConfiguracoes',
  data() {
    return {
      userProfile: 'user',
      tempoOptions: [
        { value: '10', label: '10 minutos' },
        { value: '60', label: '1 hora' },
        { value: '1440', label: '1 día' },
        { value: '7200', label: '5 días' },
        { value: '14400', label: '10 días' }
      ],
      configuracoes: [],
      listaChatFlow: [],
      NotViewAssignedTickets: null,
      NotViewTicketsChatBot: null,
      ContactAdmin: null,
      DirectTicketsToWallets: null,
      botTicketActive: null,
      ignoreGroupMsg: null,
      userContactWallet: null,
      rejectCalls: null,
      userDisableSignature: null,
      sendGreetingAccepted: null,
      sendMsgTransfTicket: null,
      spyticket: null,
      userReopenTicket: null,
      universalCounter: null,
      chatbotLane: null,
      callRejectMessage: '',
      autoPendingTime: null,
      canAccessPage: false,
      autoPending: null,
      hidetab: null,
      maxRetriesBusinessHours: null,
      TicketsLimitOpen: null,
      TicketsLimitPending: null,
      TicketsLimitClosed: null,
      groupnotification: null,
      ReopenTicket: null,
      KanbanUserNull: null,
      KanbanTicketClosed: null,
      KanbanforUser: null,
      KanbanGlobal: null,
      IgnoreMessageExt: null,
      GroupTicketsMessages: null,
      MessagesforTicket: null,
      auditMode: null,
      GroupClosedTicket: null,
      ExibirConexao: null,
      enableIframeEmbed: null,
      allowedDomain: '',
      iframeCode: ''
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Llamada al backend
        const response = await ListarCores()

        // Desestructuración de los valores devueltos por la API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar los colores como variables CSS en :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.group !== false
      } catch (error) {
        console.error('Error al cargar el plan:', error)
      }
    },
    resetarFluxoAtivo() {
      this.botTicketActive = ''
      this.atualizarConfiguracao('botTicketActive')
    },
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoes()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        let value = el.value
        if (el.key === 'botTicketActive' && el.value) {
          value = +el.value
        }
        this.$data[el.key] = value
      })
    },
    async listarChatFlow() {
      const { data } = await ListarChatFlow()
      this.listaChatFlow = data.chatFlow
    },
    copyIframeCode() {
      const iframeCode = `<iframe
  id="whazing-iframe"
  src="${window.location.origin}/embedded"
  style="width: 100%; border: none; min-height: 600px;"
  allow="camera; microphone"
></iframe>

<script>
window.addEventListener('message', function(event) {
  const iframe = document.getElementById('whazing-iframe');
  if (event.data.type === 'RESIZE') {
    iframe.style.height = event.data.height + 'px';
  }
});
</script>`;
      navigator.clipboard.writeText(iframeCode)
      this.$q.notify({
        type: 'positive',
        message: '¡Código copiado al portapapeles!',
        progress: true,
        actions: [{ icon: 'close', round: true, color: 'white' }]
      })
    },
    async atualizarConfiguracao(key) {
      if (key === 'autoCloseTime') {
        const params = { key, value: this.$data[key].value }
        try {
          await AlterarConfiguracao(params)
          this.$q.notify({
            type: 'positive',
            message: '¡Configuración alterada!',
            progress: true,
            actions: [{ icon: 'close', round: true, color: 'white' }]
          })
        } catch (error) {
          console.error('error - AlterarConfiguracao', error)
          this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
          this.$notificarErro('¡Ocurrió un error!', error)
        }
      } else {
        const params = { key, value: this.$data[key] }
        try {
          await AlterarConfiguracao(params)
          this.$q.notify({
            type: 'positive',
            message: '¡Configuración alterada!',
            progress: true,
            actions: [{ icon: 'close', round: true, color: 'white' }]
          })
        } catch (error) {
          console.error('error - AlterarConfiguracao', error)
          this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
          this.$notificarErro('¡Ocurrió un error!', error)
        }
      }
    }
  },
  async mounted() {
    this.userProfile = localStorage.getItem('profile')
    this.loadColors()
    this.listarPlano()
    await this.listarConfiguracoes()
    await this.listarChatFlow()
  }
}
</script>

<style lang="scss" scoped></style>
