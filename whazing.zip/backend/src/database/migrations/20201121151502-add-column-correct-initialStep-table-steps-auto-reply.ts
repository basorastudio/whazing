import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'initialStep' de tipo BOOLEAN a la tabla 'StepsReply'
    return Promise.all([
      queryInterface.addColumn('StepsReply', 'initialStep', {
        type: DataTypes.BOOLEAN,
        defaultValue: false // Valor predeterminado es false
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'initialStep' de la tabla 'StepsReply'
    return queryInterface.removeColumn('StepsReply', 'initialStep');
  }
};