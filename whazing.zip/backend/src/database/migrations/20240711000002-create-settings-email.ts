import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert email/SMTP settings into 'SettingsGeneral'
    // Translated Portuguese placeholders like 'seuemail@dominio.com.br' and 'Senha <seuemail@dominio.com.br>'
    await queryInterface.sequelize.query(`
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('smtp', 'smtp.dominio.com.br', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('portasmtp', '587', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('smtpsecure', 'true', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('usuariosmtp', 'tuemail@dominio.com.br', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('senhasmtp', 'Contraseña <tuemail@dominio.com.br>', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
      INSERT INTO public."SettingsGeneral" ("key", value, "createdAt", "updatedAt") VALUES('fromemail', 'Recuperar Contraseña', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354');
    `);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the inserted email settings
    await queryInterface.bulkDelete(
      "SettingsGeneral", // Adjust schema if needed
      {
        key: [
          "smtp",
          "portasmtp",
          "smtpsecure",
          "usuariosmtp",
          "senhasmtp",
          "fromemail"
        ]
      }
    );
  }
};

export = migration;
