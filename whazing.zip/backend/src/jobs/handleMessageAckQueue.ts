import { handleMsgAck } from "../services/WbotServices/wbotMessageListener"; // Adjust import path/name as needed

// Define types for the data structure expected in the job
interface MessageAckData {
  msg: any; // Replace 'any' with the specific type for 'msg'
  chat: any; // Replace 'any' with the specific type for 'chat'
  whatsappId: number | string; // Assuming whatsappId is number or string
}

interface Job {
  data: MessageAckData;
  // Add other potential job properties
}

interface BackoffOptions {
  type: string;
  delay: number;
}

interface HandleOptions {
  delay: number;
  attempts: number;
  removeOnComplete: boolean;
  removeOnFail: boolean;
  backoff: BackoffOptions;
}

const backoffOptions: BackoffOptions = {
  type: "fixed",
  delay: 180000 // 0x2bf20
};

const handleOptions: HandleOptions = {
  delay: 500, // 0x1f4
  attempts: 3,
  removeOnComplete: true,
  removeOnFail: true,
  backoff: backoffOptions
};

export const handleMessageAckQueue = {
  key: "handleMessageAckQueue", // Original key was 'handleMsgAckBaileys'
  options: handleOptions,
  async handle({ data }: Job): Promise<void> {
    try {
      const { msg, chat, whatsappId } = data;
      // Assuming handleMsgAck is the correct function to call
      await handleMsgAck(msg, chat, whatsappId);
    } catch (error: any) {
      console.error("Error handling Message Ack job:", error);
      throw error; // Re-throw the error for queue processing
    }
  }
};
