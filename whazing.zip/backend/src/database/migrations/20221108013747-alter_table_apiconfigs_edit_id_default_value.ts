// --- START OF FILE 20221108013747-alter_table_apiconfigs_edit_id_default_value.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize, literal } from "sequelize"; // Added literal

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

// Helper function to determine the correct UUID generation function based on dialect
const getUuidFunction = (dialect: string): string => {
  // Note: gen_random_uuid() requires pgcrypto extension in PostgreSQL
  //       UUID() is standard in MySQL
  //       (other dialects might need different approaches)
  switch (dialect) {
    case "postgres":
      return "gen_random_uuid()"; // Common PostgreSQL function
    // Removed 'gen_random' + '_uuid()' as it seems less standard than gen_random_uuid()
    case "mysql":
      return "UUID()";
    case "sqlite":
      // SQLite does not have a built-in UUID function for default values easily.
      // You might need to handle this differently, perhaps in the model or application layer.
      // Returning a placeholder or throwing an error. For migration, often manual UUIDs are needed.
      console.warn(
        "SQLite does not support UUID default values directly in migrations like this."
      );
      return "(hex(randomblob(16)))"; // A common workaround, but generates a hex string, not true UUID type
    case "mssql":
      return "NEWID()"; // SQL Server function
    default:
      console.warn(
        `Unsupported dialect for UUID generation: ${dialect}. Falling back to gen_random_uuid().`
      );
      return "gen_random_uuid()"; // Fallback, might fail
  }
};

const migration: Migration = {
  up: async (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ): Promise<void> => {
    const tableName = "ApiConfigs";
    const columnName = "id";
    const dialect = queryInterface.sequelize.getDialect();
    const uuidFunction = getUuidFunction(dialect);

    // Check if literal function exists before using
    const defaultValueExpression = uuidFunction ? literal(uuidFunction) : null;

    if (!defaultValueExpression) {
      console.error(
        "Could not determine UUID generation function for the current dialect."
      );
      // Potentially throw an error or handle appropriately
      await Promise.all([
        queryInterface.changeColumn(tableName, columnName, {
          allowNull: false,
          primaryKey: true,
          type: DataTypes.UUID
          // No default value if function couldn't be determined
        })
      ]);
    } else {
      await Promise.all([
        queryInterface.changeColumn(tableName, columnName, {
          allowNull: false,
          primaryKey: true,
          type: DataTypes.UUID,
          defaultValue: defaultValueExpression
        })
      ]);
    }
  },

  down: async (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ): Promise<void> => {
    // Reverting might be complex. If the previous state didn't have a default UUID,
    // simply changing the column type back might suffice.
    // However, if it had a *different* default or no default, accurately reverting
    // requires knowing the *exact* previous state.
    // This example assumes reverting to the same state as 'up', which is often
    // sufficient if the migration failed or needs rollback soon after applying.
    // For robust down migrations, store the previous state or be more specific.

    const tableName = "ApiConfigs";
    const columnName = "id";
    const dialect = queryInterface.sequelize.getDialect();
    const uuidFunction = getUuidFunction(dialect);
    const defaultValueExpression = uuidFunction ? literal(uuidFunction) : null;

    if (!defaultValueExpression) {
      console.error(
        "Could not determine UUID generation function for the current dialect during rollback."
      );
      await Promise.all([
        queryInterface.changeColumn(tableName, columnName, {
          allowNull: false,
          primaryKey: true,
          type: DataTypes.UUID
          // No default value
        })
      ]);
    } else {
      // Assuming the previous state ALSO had this default value.
      // Adjust if the previous state was different (e.g., no default).
      await Promise.all([
        queryInterface.changeColumn(tableName, columnName, {
          allowNull: false,
          primaryKey: true,
          type: DataTypes.UUID,
          defaultValue: defaultValueExpression
        })
      ]);
    }
  }
};

export default migration;
// --- END OF FILE 20221108013747-alter_table_apiconfigs_edit_id_default_value.ts ---
