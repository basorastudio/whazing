import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'queueId' column to the 'Whatsapps' table as a foreign key
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "queueId", // New column name
      {
        type: DataTypes.INTEGER,
        references: {
          model: "Queues", // References the 'Queues' table
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL", // If the referenced Queue is deleted, set queueId to NULL
        allowNull: true, // Allow null because onDelete is SET NULL
        defaultValue: null // Default value is null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'queueId' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      "Whatsapps", // Table name
      "queueId" // Column name to remove
    );
  }
};

export = migration;
