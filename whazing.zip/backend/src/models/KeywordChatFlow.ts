import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  Index, // Added for Unique constraint handling
  AutoIncrement
} from "sequelize-typescript";
import ChatFlow from "./ChatFlow";
import Tenant from "./Tenant";
import Whatsapp from "./Whatsapp";

@Table({ freezeTableName: true })
class KeywordChatFlow extends Model<KeywordChatFlow> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @AllowNull(false)
  @Column(DataType.TEXT) // Use TEXT for potentially long keywords
  @Index // Add index if needed for performance
  keyword: string;

  @ForeignKey(() => ChatFlow)
  @AllowNull(false)
  @Column
  chatFlowId: number;

  @BelongsTo(() => ChatFlow)
  chatFlow: ChatFlow;

  @ForeignKey(() => Tenant)
  @AllowNull(false)
  @Column
  @Index // Add index if needed
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @ForeignKey(() => Whatsapp)
  @AllowNull(false)
  @Column
  @Index // Add index if needed
  whatsappId: number;

  @BelongsTo(() => Whatsapp)
  whatsapp: Whatsapp;

  @Default(true)
  @Column
  isActive: boolean;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;
}

export default KeywordChatFlow;
