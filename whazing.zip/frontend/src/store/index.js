import Vue from 'vue'
import Vuex from 'vuex'
import user from './modules/user'
import whatsapp from './modules/whatsapp'
import atendimentoTicket from './modules/atendimentoTicket'
import notifications from './modules/Notifications'
import chatFlow from './modules/chatFlow'
import usersApp from './modules/usersApp'
import empresa from './modules/empresa'
import getters from './getters'
// importar ejemplo desde './module-example'
import chatInterno from './modules/chatInterno'

Vue.use(Vuex)

/*
 * Si no se está construyendo con modo SSR, puedes
 * exportar directamente la instancia de Store;
 *
 * La función siguiente también puede ser asíncrona; usa
 * async/await o retorna una Promesa que se resuelva
 * con la instancia de Store.
 */

export default function (/* { ssrContext } */) {
  const Store = new Vuex.Store({
    getters,
    modules: {
      // ejemplo
      user,
      notifications,
      atendimentoTicket,
      whatsapp,
      chatFlow,
      usersApp,
      empresa,
      chatInterno
    },

    // habilitar modo estricto (¡agrega sobrecarga!)
    // solo para modo desarrollo
    strict: process.env.DEBUGGING
  })

  return Store
}
