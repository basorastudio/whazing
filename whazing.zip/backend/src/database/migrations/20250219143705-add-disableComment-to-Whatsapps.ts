import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'disableComment' column to the 'Whatsapps' table
    // Flag to disable comments (likely internal notes/comments) for this connection.
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "disableComment", // New column name
      {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false // Original had false
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'disableComment' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      "Whatsapps", // Table name
      "disableComment" // Column name to remove
    );
  }
};

export = migration;
