import { QueryInterface, Op } from "sequelize"; // Added Op
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Insert multiple color-related settings into 'SettingsGeneral'
    const settingsToInsert = [
      {
        key: "cor1",
        value: "#5E56F6FF",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        key: "cor2",
        value: "#5690F0FF",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        key: "textcor1",
        value: "#FFFFFFFF",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        key: "cor1dark",
        value: "#5E56F6FF",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        key: "cor2dark",
        value: "#5690F0FF",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        key: "textcor1dark",
        value: "#FFFFFFFF",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
    await queryInterface.bulkInsert("SettingsGeneral", settingsToInsert);
  },

  down: async (queryInterface: QueryInterface, Sequelize): Promise<void> => {
    // Added Sequelize for Op
    // Remove the inserted color settings
    const keysToRemove = [
      "cor1",
      "cor2",
      "textcor1",
      "cor1dark",
      "cor2dark",
      "textcor1dark"
    ];
    await queryInterface.bulkDelete(
      "SettingsGeneral", // Adjust schema if needed
      {
        key: {
          [Sequelize.Op.in]: keysToRemove // Use Op.in for deleting multiple keys
        }
      }
    );
  }
};

export = migration;
