import { Client as HubClient, MessageSubscription } from 'notificamehubsdk'; // Assuming SDK path/exports
import Whatsapp from '../models/Whatsapp'; // Assuming model path
import showHubToken from './ShowHubToken'; // Assuming path (use default export)
import { logger } from '../utils/logger'; // Assuming logger path

const setChannelWebhook = async (whatsappId: number | string): Promise<void> => {
    const whatsapp = await Whatsapp.findOne({
        where: { id: whatsappId }
    });

    if (!whatsapp) {
        throw new Error(`Whatsapp con id ${whatsappId} no encontrado`);
    }

    // Check if already connected? Or rely on ShowHubToken/SDK to handle errors?
    // if (whatsapp.status !== 'CONNECTED') {
    //     logger.warn(`Whatsapp ${whatsappId} no está conectado, no se puede establecer el webhook.`);
    //     return;
    // }

    try {
        const hubToken = await showHubToken(whatsapp.tenantId); // Fetch and decrypt token
        const hubClient = new HubClient(hubToken);

        const webhookUrl = `${process.env.BACKEND_URL}/hub-webhook/${whatsapp.number}`; // Construct webhook URL
        logger.info(`Estableciendo webhook para el canal ${whatsapp.number} en: ${webhookUrl}`);

        const subscriptionData: Partial<MessageSubscription> = {
            url: webhookUrl
            // Add other subscription options if needed, e.g., event types
        };

        const subscriptionOptions = { // Assuming channel identifier is passed here
            channel: whatsapp.number // Use 'number' as the channel identifier
        };

        // The SDK method might be different, adjust based on notificamehubsdk documentation
        // Assuming a method like createSubscription or updateSubscription exists
        await hubClient.createSubscription(subscriptionData, subscriptionOptions)
            .then((response: any) => { // Type the response if known
                logger.info(`Webhook suscrito con éxito para ${whatsapp.number}. Respuesta: ${JSON.stringify(response)}`);
            })
            .catch((error: any) => {
                 logger.error(`Error en la suscripción del Webhook para ${whatsapp.number}: ${error?.message || error}`);
                 // Propagate or handle the error appropriately
                 throw error; // Re-throw to indicate failure
            });

        // Update WhatsApp status in DB to indicate webhook is set (optional)
        // await Whatsapp.update(
        //     { status: 'CONNECTED_WEBHOOK' }, // Example status
        //     { where: { id: whatsappId } }
        // );
        logger.info(`Actualización del estado del webhook procesada para WhatsApp ID ${whatsappId}`);

    } catch (error: any) {
        logger.error(`Fallo al configurar el webhook para WhatsApp ID ${whatsappId}: ${error.message}`);
        // Handle error, maybe update status to indicate failure
        // await Whatsapp.update(
        //     { status: 'ERROR_WEBHOOK' }, // Example status
        //     { where: { id: whatsappId } }
        // );
        throw error; // Re-throw error
    }
};

export default setChannelWebhook;