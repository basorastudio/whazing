<template>
  <div>
    <q-table flat
      bordered
      square
      hide-bottom
      class="contact-table container-rounded-10 my-sticky-dynamic q-ma-lg"
      :data="planos"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]">
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-currency-usd q-pr-sm" />
            Planes
          </h2>
          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
          icon="eva-plus-outline"
          label="Agregar"
          @click="planoEdicao = {}; modalPlano = true" />
        </div>

      </template>

              <template v-slot:body-cell-value="props">
                <q-td class="text-center">
          R$ {{ props.value.toFixed(2).replace('.', ',') }}
                </q-td>
              </template>

              <template v-slot:body-cell-isPublic="props">
                <q-td class="text-center">
                  <q-icon size="24px" :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                    :color="props.value ? 'positive' : 'negative'" />
                </q-td>
              </template>
      <template v-slot:body-cell-group="props">
        <q-td class="text-center">
          <q-icon size="24px" :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                  :color="props.value ? 'positive' : 'negative'" />
        </q-td>
      </template>
      <template v-slot:body-cell-campaign="props">
        <q-td class="text-center">
          <q-icon size="24px" :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                  :color="props.value ? 'positive' : 'negative'" />
        </q-td>
      </template>
      <template v-slot:body-cell-integrations="props">
        <q-td class="text-center">
          <q-icon size="24px" :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                  :color="props.value ? 'positive' : 'negative'" />
        </q-td>
      </template>
              <template v-slot:body-cell-acoes="props">
                <q-td class="text-center">
                  <q-btn class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" flat round icon="eva-edit-outline" @click="editarPlano(props.row)" />
                  <q-btn class="color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" flat round icon="eva-trash-outline" @click="deletarPlano(props.row)" />
                </q-td>
              </template>
            </q-table>
    <ModalPlano
      :modalPlano.sync="modalPlano"
      :planoEdicao.sync="planoEdicao"
      @modal-plano:criada="planoCriada"
      @modal-plano:editada="planoEditada"
      @reload-planos="listarPlanos"
    />
  </div>
</template>

<script>
import { listarplanos, Deletarplano } from '../../../service/plans'
import ModalPlano from './ModalPlano'
export default {
  name: 'Planos',
  components: {
    ModalPlano
  },
  data() {
    return {
      tab: 'planos',
      planoEdicao: {},
      modalPlano: false,
      planos: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'name', label: 'Nombre', field: 'name', align: 'left' },
        { name: 'maxUsers', label: 'Máx. Usuarios', field: 'maxUsers', align: 'center' },
        { name: 'maxConnections', label: 'Máx. Conexiones', field: 'maxConnections', align: 'center' },
        { name: 'value', label: 'Valor', field: 'value', align: 'center' },
        { name: 'isPublic', label: 'Público', field: 'isPublic', align: 'center' },
        { name: 'group', label: 'Grupos', field: 'group', align: 'center' },
        { name: 'campaign', label: 'Campañas', field: 'campaign', align: 'center' },
        { name: 'integrations', label: 'Integraciones', field: 'integrations', align: 'center' },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async listarPlanos() {
      const { data } = await listarplanos()
      this.planos = data.filter(plano => plano.id !== 1)
    },
    editarPlano(plano) {
      this.planoEdicao = { ...plano }
      this.modalPlano = true
    },
    planoCriada(plano) {
      const newPlanos = [...this.planos]
      newPlanos.push(plano)
      this.planos = [...newPlanos]
    },
    planoEditada(plano) {
      const newPlanos = [...this.planos]
      const idx = newPlanos.findIndex(f => f.id === plano.id)
      if (idx > -1) {
        newPlanos[idx] = plano
      }
      this.planos = [...newPlanos]
    },
    deletarPlano(plano) {
      this.$q.dialog({
        title: '¡Atención!',
        message: `¿Realmente deseas eliminar el Plan "${plano.name}"?`,
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        Deletarplano(plano)
          .then(res => {
            let newPlanos = [...this.planos]
            newPlanos = newPlanos.filter(f => f.id !== plano.id)

            this.planos = [...newPlanos]
            this.$q.notify({
              type: 'positive',
              progress: true,
              position: 'top',
              message: `¡Plan ${plano.name} eliminado!`,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          })
        this.loading = false
      })
    }
  },
  mounted() {
    this.listarPlanos()
  }
}
</script>

<style lang="scss" scoped></style>
