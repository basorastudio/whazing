import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull
} from "sequelize-typescript";
import User from "./User";
import Tenant from "./Tenant";

@Table({ freezeTableName: true })
class ChatFlow extends Model<ChatFlow> {
  // Getter preserved
  get flow(): object {
    // Assuming 'flow' getter returns the 'data' property
    const data = this.getDataValue("data");
    if (data) {
      // Deep copy and potentially modify URLs (original logic)
      const dataCopy = JSON.parse(JSON.stringify(data)); // Simple deep copy
      for (const node of dataCopy?.nodeList || []) {
        // Added nullish check
        if (node?.type === "MediaField") {
          // Added nullish check
          for (const action of node?.data?.actions || []) {
            // Added nullish check
            if (action?.type === "Media" && action?.data?.mediaUrl) {
              const { BACKEND_URL, PROXY_PORT } = process.env;
              const filename = action.data.mediaUrl;
              // Store original filename before overwriting
              action.data.fileName = filename;
              // Construct full URL
              action.data.mediaUrl = `${BACKEND_URL}:${PROXY_PORT}/public/${filename}`;
            }
          }
        }
      }
      return dataCopy;
    }
    return {};
  }

  @PrimaryKey
  @Column
  id: string; // Assuming string ID based on usage

  @Column(DataType.STRING)
  name: string;

  @Default({}) // Default to empty object for JSON
  @AllowNull(false) // Explicitly disallow null based on default
  @Column(DataType.JSONB) // Use JSONB
  data: any; // Use 'any' or a specific interface for the flow data structure

  // Virtual field 'flow' - calculated by the getter above
  // No @Column decorator needed for virtual fields handled by getters
  flow: object;

  @Default(true)
  @Column
  isActive: boolean;

  @Default(false)
  @Column
  isDeleted: boolean;

  @Default(null)
  @Column(DataType.STRING)
  celularTeste: string; // 'celularTeste' resolved

  @Default(true)
  @Column
  AcceptAchmed: boolean; // Assuming 'AcceptKanban' mapped to this

  @Default(true)
  @Column
  AcceptRamal: boolean; // Assuming 'AcceptTransfer' mapped to this

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;
}

export default ChatFlow;
