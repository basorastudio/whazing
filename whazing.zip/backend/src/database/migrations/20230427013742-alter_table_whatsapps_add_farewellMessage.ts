// --- START OF FILE 20230427013742-alter_table_whatsapps_add_farewellMessage.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Whatsapps";
    const columnName = "farewellMessage"; // 'farewellMe' + 'ssage'
    // Original log message (Portuguese): Não foi possível adicionar coluna farewellMessage. Verifique se ela está presente no banco.
    const errorMessage =
      "No fue posible añadir la columna farewellMessage. Verifique si ya está presente en la base de datos.";

    try {
      const attributes = {
        type: DataTypes.TEXT,
        allowNull: true, // Changed !![] to true
        defaultValue: null
      };
      // Check if column exists before adding
      const tableDescription = await queryInterface.describeTable(tableName);
      if (!tableDescription[columnName]) {
        await queryInterface.addColumn(tableName, columnName, attributes);
      } else {
        console.log(
          `La columna ${columnName} ya existe en la tabla ${tableName}. Saltando adición.`
        ); // Added log
      }
    } catch (error) {
      console.error(errorMessage, error); // Using translated message
    }
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Whatsapps";
    const columnName = "farewellMessage"; // 'farewellMe' + 'ssage'
    // Original log message (Portuguese): Não foi deletar coluna farewellMessage. Verifique se ela está presente no banco.
    const errorMessage =
      "No fue posible eliminar la columna farewellMessage. Verifique si está presente en la base de datos."; // Translated message

    try {
      // Check if column exists before removing
      const tableDescription = await queryInterface.describeTable(tableName);
      if (tableDescription[columnName]) {
        await queryInterface.removeColumn(tableName, columnName);
      } else {
        console.log(
          `La columna ${columnName} no existe en la tabla ${tableName}. Saltando eliminación.`
        ); // Added log
      }
    } catch (error) {
      console.error(errorMessage, error); // Using translated message
    }
  }
};

export default migration;
// --- END OF FILE 20230427013742-alter_table_whatsapps_add_farewellMessage.ts ---
