import { Request, Response } from "express";
import * as Yup from "yup";
import AppError from "../errors/AppError";
import CreateStepsReplyActionService from "../services/StepsReplyActionsServices/CreateStepsReplyActionService"; // Ajustar ruta
import DeleteStepsReplyActionService from "../services/StepsReplyActionsServices/DeleteStepsReplyActionService"; // Ajustar ruta
import UpdateStepsReplyActionService from "../services/StepsReplyActionsServices/UpdateStepsReplyActionService"; // Ajustar ruta

interface StepsReplyActionBody {
  stepReplyId?: number | string; // ID de la respuesta padre
  words?: string; // Palabras clave (¿quizás un array?)
  action?: number | string; // Tipo de acción (¿quizás un enum/número?)
  queueId?: number | string; // ID de cola (si action es tipo cola)
  userId?: number | string; // ID de usuario (si action es tipo usuario)
  // otras propiedades según el tipo de acción
}

interface UserRequest extends Request {
  user?: {
    id: string | number;
    profile: string;
    // otras propiedades
  };
  body: StepsReplyActionBody;
  params: {
    stepsReplyActionId?: string; // ID para update y delete
  };
}

// Esquema de validación base (puede necesitar ser más complejo según 'action')
const stepsReplyActionSchema = Yup.object().shape({
  stepReplyId: Yup.number().required(),
  words: Yup.string().required(), // Ajustar si es array
  action: Yup.number().required(), // Ajustar si es string u otro tipo
  userId: Yup.number().required() // Añadido en el controlador original
  // Podrían añadirse validaciones condicionales para queueId, etc. usando .when()
});

export const store = async (
  req: UserRequest,
  res: Response
): Promise<Response> => {
  // Verifica si el usuario es administrador
  if (req.user?.profile !== "admin") {
    throw new AppError("ERR_NO_PERMISSION", 403); // "ERR_SIN_PERMISO"
  }

  const actionData = { ...req.body };
  // Añade userId al objeto de datos desde el usuario autenticado
  actionData.userId = req.user?.id;

  try {
    await stepsReplyActionSchema.validate(actionData);
  } catch (err: any) {
    throw new AppError(err.message || "Validation Error", 400); // "Error de Validación"
  }

  // Llama al servicio para crear
  const stepsReplyAction = await CreateStepsReplyActionService(actionData);

  return res.status(201).json(stepsReplyAction);
};

export const update = async (
  req: UserRequest,
  res: Response
): Promise<Response> => {
  // Verifica si el usuario es administrador
  if (req.user?.profile !== "admin") {
    throw new AppError("ERR_NO_PERMISSION", 403); // "ERR_SIN_PERMISO"
  }

  const actionData = { ...req.body };
  // Añade userId si es necesario para la lógica de actualización
  actionData.userId = req.user?.id;

  try {
    // Validar (usando el mismo esquema o uno específico de update)
    await stepsReplyActionSchema.validate(actionData);
  } catch (err: any) {
    throw new AppError(err.message || "Validation Error", 400); // "Error de Validación"
  }

  const { stepsReplyActionId } = req.params;
  if (!stepsReplyActionId) {
    throw new AppError("Missing stepsReplyActionId parameter", 400); // "Falta parámetro stepsReplyActionId"
  }

  const updateData = {
    stepsReplyActionData: actionData,
    stepsReplyActionId: stepsReplyActionId
  };

  // Llama al servicio para actualizar
  const stepsReplyAction = await UpdateStepsReplyActionService(updateData);

  return res.status(200).json(stepsReplyAction);
};

export const remove = async (
  req: UserRequest,
  res: Response
): Promise<Response> => {
  // Verifica si el usuario es administrador
  if (req.user?.profile !== "admin") {
    throw new AppError("ERR_NO_PERMISSION", 403); // "ERR_SIN_PERMISO"
  }

  const { stepsReplyActionId } = req.params;
  if (!stepsReplyActionId) {
    throw new AppError("Missing stepsReplyActionId parameter", 400); // "Falta parámetro stepsReplyActionId"
  }

  // Llama al servicio para eliminar
  await DeleteStepsReplyActionService(stepsReplyActionId);

  // Devuelve mensaje de éxito
  return res.status(200).json({ message: "Auto reply action deleted" }); // "Acción de respuesta automática eliminada"
};
