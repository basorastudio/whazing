import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'ContactWallets';
    // Add index on [walletId]
    await queryInterface.addIndex(tableName, ['walletId'], {
      name: 'idx_contactwallets_walletid', // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'ContactWallets';
    // Remove the index
    await queryInterface.removeIndex(tableName, 'idx_contactwallets_walletid');
  }
};

export = migration;