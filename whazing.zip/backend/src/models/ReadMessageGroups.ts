import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  AutoIncrement
} from "sequelize-typescript";
import InternalMessage from "./InternalMessage";
import UserGroup from "./UsersGroups"; // Assuming join table model UserGroup

@Table({ freezeTableName: true })
class ReadMessageGroups extends Model<ReadMessageGroups> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @ForeignKey(() => InternalMessage)
  @Column
  internalMessageId: number; // Assuming FK name

  @BelongsTo(() => InternalMessage)
  internalMessage: InternalMessage; // Relation name

  @ForeignKey(() => UserGroup) // Assuming FK to the UsersGroups join table
  @Column
  userGroupId: number; // Assuming FK name

  @BelongsTo(() => UserGroup) // Assuming relation to UsersGroups model
  userGroup: UserGroup; // Relation name

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default ReadMessageGroups;