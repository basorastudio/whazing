import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "BaileysKeys";
    // Add composite index on [whatsappId, type, key]
    // This should ideally match the composite primary key defined in the create table migration
    // for efficiency, but adding it separately if not already primary.
    await queryInterface.addIndex(tableName, ["whatsappId", "type", "key"], {
      name: "idx_baileyskeys_whatsappid_type_key" // Explicit index name
      // unique: true // If this combination should be unique (likely is if it's the PK)
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "BaileysKeys";
    // Remove the index
    await queryInterface.removeIndex(
      tableName,
      "idx_baileyskeys_whatsappid_type_key"
    );
  }
};

export = migration;
