import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import Tenant from "./Tenant";
import Contact from "./Contact";
import Ticket from "./Ticket";
import User from "./User";
import Whatsapp from "./Whatsapp";

@Table
class Schedule extends Model<Schedule> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column(DataType.TEXT) // Use TEXT for body
  body: string;

  @Column
  sendAt: Date; // Assuming Date

  @Column
  sentAt: Date; // Assuming Date

  @ForeignKey(() => Contact)
  @Column
  contactId: number;

  @ForeignKey(() => Ticket)
  @Column
  ticketId: number;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @Column(DataType.STRING) // Store filename/path
  mediaPath: string | null;

  @Column(DataType.STRING)
  mediaName: string | null;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @BelongsTo(() => Contact, "contactId")
  contact: Contact;

  @BelongsTo(() => Ticket)
  ticket: Ticket;

  @BelongsTo(() => User)
  user: User;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @ForeignKey(() => Whatsapp) // Added FK based on likely schema
  @AllowNull(true) // Assuming nullable
  @Default(null)
  @Column
  whatsappId: number | null;

  @BelongsTo(() => Whatsapp) // Added relation based on likely schema
  whatsapp: Whatsapp | null;

  @Default("pending") // Default status
  @Column(DataType.ENUM("pending", "sent", "failed")) // Assuming enum for status
  status: string;

  @Default(false)
  @Column
  Tunel: boolean; // Resolved name, assuming boolean
}

export default Schedule;
