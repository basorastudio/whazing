import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna profile a la tabla Users
    return queryInterface.addColumn('Users', 'profile', { // Nombre de columna preservado
      type: DataTypes.STRING,
      allowNull: false, // Asume que no puede ser nulo
      defaultValue: 'admin' // Valor por defecto 'admin'
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna profile
    return queryInterface.removeColumn('Users', 'profile');
  }
};