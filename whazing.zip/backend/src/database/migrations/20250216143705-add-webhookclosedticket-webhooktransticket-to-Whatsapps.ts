import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add webhook flags to 'Whatsapps' table
    await queryInterface.addColumn("Whatsapps", "webhookclosedticket", {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      allowNull: false // Original had false
    });
    await queryInterface.addColumn("Whatsapps", "webhooktransticket", {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      allowNull: false // Original had false
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added webhook flags
    await queryInterface.removeColumn("Whatsapps", "webhooktransticket");
    await queryInterface.removeColumn("Whatsapps", "webhookclosedticket");
  }
};

export = migration;
