<template>
  <q-dialog
    persistent
    :value="modalAgendamento"
    @hide="fecharModal"
    @show="abrirModal"
  >
    <q-card class="q-pa-md modal-container container-rounded-10" style="max-width: 600px;">
      <q-overlay v-if="loading" class="bg-primary">
        <q-spinner color="white" size="50px" />
      </q-overlay>

      <q-card-section class="row items-center justify-between q-my-sm q-px-none">
        <div class="text-h6 text-center font-family-main col">
          Crear Nueva Cita
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="q-pa-none">
        <div class="row q-my-md q-pa-lg container-border container-rounded-10">
          <div class="full-width text-h6 font-family-main q-mb-sm">Contacto</div>
          <div class="full-width">
            <q-select
              ref="selectAutoCompleteContato"
              autofocus
              square
              outlined
              filled
              hide-dropdown-icon
              :loading="loading"
              v-model="agendamento.contato"
              :options="contatos"
              input-debounce="700"
              @filter="localizarContato"
              use-input
              hide-selected
              fill-input
              option-label="name"
              option-value="id"
              label="Buscar Contacto"
              hint="Ingrese al menos dos letras para buscar el contacto."
            />
          </div>

          <div class="full-width text-h6 font-family-main q-mb-sm">WhatsApp</div>
          <div class="full-width">
            <q-select
              square
              outlined
              v-model="agendamento.whatsapp"
              :options="whatsappChannels"
              emit-value
              map-options
              option-value="id"
              option-label="name"
              label="Canal"
            />
          </div>
        </div>

        <div class="row items-center container-border container-rounded-10 q-pa-lg">
          <div class="text-h6 full-width font-family-main q-mb-sm">Mensaje</div>
          <div class="col-xs-3 col-sm-2 col-md-1">
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-emoticon-happy-outline" />
              <q-tooltip>Emoji</q-tooltip>
              <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                <VEmojiPicker
                  style="width: 40vw"
                  :showSearch="true"
                  :emojisByRow="20"
                  labelSearch="Buscar..."
                  lang="es"
                  @select="onInsertSelectEmoji"
                />
              </q-menu>
            </q-btn>
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-variable" />
              <q-tooltip>Variables</q-tooltip>
              <q-menu touch-position>
                <q-list dense style="min-width: 100px">
                  <q-item
                    v-for="variavel in variaveis"
                    :key="variavel.label"
                    clickable
                    @click="onInsertSelectVariable(variavel.value)"
                    v-close-popup
                  >
                    <q-item-section>{{ variavel.label }}</q-item-section>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>

          </div>
          <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm q-mt-sm">
            <textarea
              ref="inputEnvioMensagem"
              :disabled="audiogravado"
              style="min-height: 15vh; max-height: 15vh;"
              class="q-pa-sm bg-white full-width"
              placeholder="Escribe el mensaje"
              :value="agendamento.mensagem"
              @input="(v) => agendamento.mensagem = v.target.value"
            />
          </div>

          <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm q-mt-md row items-center">
            <!-- Microphone button -->
            <q-btn
              round
              flat
              :color="isRecordingAudio ? 'negative' : 'primary'"
              @click="handleAudioRecording"
              class="q-ml-sm color-light1"
              :class="$q.dark.isActive ? ('color-dark1') : ''"
            >
              <q-icon
                :name="isRecordingAudio ? 'stop' : 'mic'"
                size="2em"
              />
              <q-tooltip>
                {{ isRecordingAudio ? 'Detener Grabación' : 'Grabar Audio' }}
              </q-tooltip>
            </q-btn>
            <!-- File upload button - hidden while recording -->
            <q-file
              v-if="!isRecordingAudio"
              dense
              outlined
              v-model="agendamento.anexo"
              label="Adjuntar un archivo"
              filled
              class="col"
            />

            <!-- Recording Timer -->
            <RecordingTimer
              v-if="isRecordingAudio"
              class="q-ml-sm"
            />
          </div>

          <div class="full-width text-h6 font-family-main q-mb-sm q-mt-md">Fecha para Enviar</div>
          <div class="row q-col-gutter-md">
            <div class="col-xs-12 col-md-6">
              <q-select :options="schedule.options" v-model="schedule.selected" map-options outlined @input="onSelectSchedule" />
            </div>
            <div class="col-xs-12 col-md-6">
              <q-datetime-picker
                outlined
                stack-label
                label="Fecha/Hora de la Cita"
                mode="datetime"
                v-model="agendamento.dataParaEnviar"
                format24h
                :readonly="schedule.selected.value !== 'custom'"
              />
            </div>
            <div class="full-width">
              <q-checkbox v-model="agendamento.repetir" label="Repetir cita" />
              <q-select
                v-if="agendamento.repetir"
                :options="periodo.options"
                v-model="agendamento.periodo"
                map-options
                outlined
              />
              <q-input
                v-if="agendamento.repetir"
                outlined
                label="Número de repeticiones"
                type="number"
                v-model="agendamento.repeticao"
              />
            </div>
          </div>
        </div>
      </q-card-section>

      <q-card-actions align="right" class="q-mt-md">
        <q-btn label="Cancelar" color="negative" v-close-popup class="q-mr-md btn-rounded-50" />
        <q-btn
          :loading="loading"
          :disable="loading"
          label="Guardar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          @click="handleAgendamento"
          icon="eva-save-outline"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { CriarAgendamento } from 'src/service/agendamentos'
import { ListarContatos } from 'src/service/contatos'
import { add, format } from 'date-fns'
import { mapGetters } from 'vuex'
import { VEmojiPicker } from 'v-emoji-picker'

import RecordingTimer from '../atendimento/RecordingTimer'
import MicRecorder from 'mic-recorder-to-mp3'

const Mp3Recorder = new MicRecorder({
  bitRate: 128,
  encodeAfterRecord: true
})

export default {
  name: 'ModalAgendamento',
  components: { VEmojiPicker, RecordingTimer },
  props: {
    modalAgendamento: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isRecordingAudio: false,
      audioBlob: null,
      audiogravado: false,
      contatos: [],
      variaveis: [
        { label: 'Nombre Completo', value: '{{name}}' },
        { label: 'Nombre', value: '{{firstName}}' },
        { label: 'Saludo', value: '{{greeting}}' },
        { label: 'Teléfono', value: '{{phoneNumber}}' },
        { label: 'Email del Contacto', value: '{{email}}' },
        { label: 'Hora', value: '{{hour}}' },
        { label: 'Fecha', value: '{{date}}' }
      ],
      periodo: {
        selected: { label: 'Período', value: '' },
        options: [
          { label: 'Mensual', value: 'mensal' },
          { label: 'Semanal', value: 'semanal' },
          { label: 'Quincenal', value: 'quinzena' },
          { label: 'Bimestral', value: 'bimestral' }
        ]
      },
      schedule: {
        selected: { label: 'Personalizado', value: 'custom', func: null },
        options: [
          { label: 'Personalizado', value: 'custom', func: null },
          { label: 'En 30 minutos', value: '30_mins', func: () => add(new Date(), { minutes: 30 }) },
          { label: 'Mañana', value: 'amanha', func: () => add(new Date(), { days: 1 }) },
          { label: 'Próxima semana', value: 'prox_semana', func: () => add(new Date(), { weeks: 1 }) }
        ]
      },
      agendamento: {
        contato: '',
        whatsapp: '',
        mensagem: '',
        anexo: null,
        dataParaEnviar: '',
        repetir: false,
        repeticao: 1,
        periodo: null
      },
      loading: false
    }
  },
  computed: {
    ...mapGetters(['whatsapps']),
    whatsappChannels() {
      return this.whatsapps.filter(channel => channel.type === 'whatsapp')
    }
  },
  methods: {
    async handleAudioRecording () {
      if (!this.isRecordingAudio) {
        try {
          await navigator.mediaDevices.getUserMedia({ audio: true })
          await Mp3Recorder.start()
          this.isRecordingAudio = true
        } catch (error) {
          this.$q.notify({
            type: 'negative',
            message: 'Error al iniciar la grabación de audio'
          })
          this.isRecordingAudio = false
        }
      } else {
        try {
          const [, blob] = await Mp3Recorder.stop().getMp3()
          this.isRecordingAudio = false

          if (blob.size < 10000) {
            this.$q.notify({
              type: 'warning',
              message: 'Audio muy corto'
            })
            return
          }

          // Create file object for attachment
          const audioFile = new File([blob], `audio_${Date.now()}.mp3`, {
            type: 'audio/mp3'
          })

          // Set the audio file to agendamento.anexo
          this.agendamento.anexo = audioFile

          this.audiogravado = true

          this.$q.notify({
            type: 'positive',
            message: '¡Audio grabado con éxito!'
          })
        } catch (error) {
          this.$q.notify({
            type: 'negative',
            message: 'Error al finalizar la grabación de audio'
          })
        }
      }
    },
    async cancelRecording () {
      if (this.isRecordingAudio) {
        try {
          await Mp3Recorder.stop().getMp3()
          this.isRecordingAudio = false
        } catch (error) {
          console.error('Error al cancelar grabación:', error)
        }
      }
    },
    async localizarContato(search, update, abort) {
      if (search.length < 2) {
        if (this.contatos.length) update(() => { this.contatos = [...this.contatos] })
        abort()
        return
      }
      this.loading = true
      try {
        const { data } = await ListarContatos({ searchParam: search })
        update(() => { this.contatos = data.contacts || [] })
      } finally {
        this.loading = false
      }
    },
    onInsertSelectVariable (variable) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!variable) {
        return
      }
      // insert:
      self.txtContent = this.agendamento.mensagem
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.agendamento.mensagem = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      if (!emoji.data) {
        return
      }
      self.txtContent = this.agendamento.mensagem
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.agendamento.mensagem = self.txtContent
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    onSelectSchedule(newValue) {
      this.agendamento.dataParaEnviar = newValue.func ? format(newValue.func(), 'yyyy-MM-dd HH:mm') : null
    },
    fecharModal() {
      this.$emit('update:modalAgendamento', false)
    },
    abrirModal() {
      this.audiogravado = false
      this.agendamento = {
        contato: '',
        whatsapp: '',
        mensagem: '',
        anexo: null,
        dataParaEnviar: '',
        repetir: false,
        repeticao: 1,
        periodo: null
      }
    },
    async handleAgendamento() {
      const { contato, whatsapp, mensagem, dataParaEnviar, periodo, repetir, repeticao, anexo } = this.agendamento

      // Selecione apenas o id do contato e o value do período
      const contatoId = contato ? contato.id : null
      const periodoValue = periodo ? periodo.value : null

      if (!anexo && !mensagem) {
        this.$q.notify({ type: 'negative', message: 'Es necesario informar un mensaje cuando no hay adjunto.' })
        return
      }

      if (!contatoId || !whatsapp || !dataParaEnviar) {
        this.$q.notify({ type: 'negative', message: 'Complete todos los campos obligatorios.' })
        return
      }

      if (repetir && (isNaN(repeticao) || repeticao > 12)) {
        this.$q.notify({ type: 'negative', message: 'El campo repetición debe ser un número menor o igual a 12.' })
        return
      }

      this.loading = true
      try {
        const formData = new FormData()
        formData.append('repetir', repetir)
        formData.append('repeticao', repeticao)
        formData.append('contatoId', contatoId)
        formData.append('whatsapp', whatsapp)
        formData.append('mensagem', mensagem)
        formData.append('dataParaEnviar', dataParaEnviar)
        formData.append('medias', anexo)

        if (periodoValue) formData.append('periodo', periodoValue)

        // Envia os dados do agendamento para o backend
        await CriarAgendamento(formData)
        this.$q.notify({ type: 'positive', message: '¡Cita creada con éxito!' })
        window.location.reload()
        this.fecharModal()
      } catch (error) {
        console.error(error)
        this.$q.notify({ type: 'negative', message: 'Error al crear la cita.' })
      } finally {
        this.loading = false
      }
    }
  },
  beforeDestroy () {
    this.cancelRecording()
  }
}
</script>
