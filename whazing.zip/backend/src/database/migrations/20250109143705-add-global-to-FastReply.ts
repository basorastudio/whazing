import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'global' column to the 'FastReply' table
    // Indicates if a fast reply is globally available or user/tenant specific.
    await queryInterface.addColumn(
      'FastReply', // Table name
      'global',    // New column name
      {
        type: DataTypes.BOOLEAN,
        allowNull: false,    // Cannot be null
        defaultValue: false, // Default to not global
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'global' column from the 'FastReply' table
    await queryInterface.removeColumn(
      'FastReply', // Table name
      'global'     // Column name to remove
    );
  }
};

export = migration;