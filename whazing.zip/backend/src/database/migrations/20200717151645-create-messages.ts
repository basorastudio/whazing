import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    return queryInterface.createTable('Messages', {
      id: {
        type: DataTypes.STRING, // Probablemente un ID de mensaje de WhatsApp
        primaryKey: true,
        allowNull: false
      },
      body: {
        type: DataTypes.TEXT,
        allowNull: false
      },
      ack: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      read: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      mediaType: { // Nombre de columna preservado
        type: DataTypes.STRING
      },
      mediaUrl: { // Nombre de columna preservado
        type: DataTypes.STRING
      },
      // userId fue eliminado en otra migración (20200730153237)
      // userId: {
      //   type: DataTypes.INTEGER,
      //   references: { model: 'Users', key: 'id' },
      //   onUpdate: 'CASCADE',
      //   onDelete: 'SET NULL'
      // },
      ticketId: {
        type: DataTypes.INTEGER,
        references: {
          model: 'Tickets',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Un mensaje debe pertenecer a un ticket
        allowNull: false
      },
      createdAt: {
        type: DataTypes.DATE(6),
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE(6),
        allowNull: false
      }
      // fromMe, isDeleted, contactId, vcardContactId, quotedMsgId, timestamp fueron añadidos/modificados en otras migraciones
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    return queryInterface.dropTable('Messages');
  }
};