import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'IdQueue' column to the 'Messages' table as a foreign key
    await queryInterface.addColumn(
      "Messages", // Table name
      "IdQueue", // New column name (Note: unusual capitalization, kept from original)
      {
        type: DataTypes.INTEGER,
        references: {
          model: "Queues", // References the Queues table
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "RESTRICT", // Prevent deleting Queue if Messages reference it (original was 'restrict')
        allowNull: true, // Allow null
        defaultValue: null
      }
    );
    // Original code wrapped this in Promise.all, unnecessary here.
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'IdQueue' column from the 'Messages' table
    await queryInterface.removeColumn(
      "Messages", // Table name
      "IdQueue" // Column name to remove
      // Original code wrapped the remove operation in Promise.all and passed the column definition again, which is incorrect for removeColumn. Corrected here.
    );
  }
};

export = migration;
