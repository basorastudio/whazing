import { i18n } from 'src/boot/i18n'

const errors = [
  {
    error: 'ERR_SESSION_EXPIRED',
    description: i18n.t('erros.ERR_SESSION_EXPIRED_descricao'),
    detail: i18n.t('erros.ERR_SESSION_EXPIRED_detalhe')
  },
  {
    error: 'ERR_API_CONFIG_NOT_FOUND',
    description: i18n.t('erros.ERR_API_CONFIG_NOT_FOUND_descricao'),
    detail: i18n.t('erros.ERR_API_CONFIG_NOT_FOUND_detalhe')
  },
  {
    error: 'ERR_NO_CONTACT_FOUND',
    description: i18n.t('erros.ERR_NO_CONTACT_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_CONTACT_FOUND_detalhe')
  },
  {
    error: 'ERR_DUPLICATED_CONTACT',
    description: i18n.t('erros.ERR_DUPLICATED_CONTACT_descricao'),
    detail: i18n.t('erros.ERR_DUPLICATED_CONTACT_detalhe')
  },
  {
    error: 'ERR_CONTACT_TICKETS_REGISTERED',
    description: i18n.t('erros.ERR_CONTACT_TICKETS_REGISTERED_descricao'),
    detail: i18n.t('erros.ERR_CONTACT_TICKETS_REGISTERED_detalhe')
  },
  {
    error: 'ERR_CREATING_MESSAGE',
    description: i18n.t('erros.ERR_CREATING_MESSAGE_descricao'),
    detail: i18n.t('erros.ERR_CREATING_MESSAGE_detalhe')
  },
  {
    error: 'ERR_NO_TICKET_FOUND',
    description: i18n.t('erros.ERR_NO_TICKET_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_TICKET_FOUND_detalhe')
  },
  {
    error: 'ERR_AUTO_REPLY_RELATIONED_TICKET',
    description: i18n.t('erros.ERR_AUTO_REPLY_RELATIONED_TICKET_descricao'),
    detail: i18n.t('erros.ERR_AUTO_REPLY_RELATIONED_TICKET_detalhe')
  },
  {
    error: 'ERR_NO_AUTO_REPLY_FOUND',
    description: i18n.t('erros.ERR_NO_AUTO_REPLY_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_AUTO_REPLY_FOUND_detalhe')
  },
  {
    error: 'ERR_NO_STEP_AUTO_REPLY_FOUND',
    description: i18n.t('erros.ERR_NO_STEP_AUTO_REPLY_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_STEP_AUTO_REPLY_FOUND_detalhe')
  },
  {
    error: 'ERR_CAMPAIGN_CONTACTS_NOT_EXISTS_OR_NOT_ACESSIBLE',
    description: i18n.t('erros.ERR_CAMPAIGN_CONTACTS_NOT_EXISTS_OR_NOT_ACESSIBLE_descricao'),
    detail: i18n.t('erros.ERR_CAMPAIGN_CONTACTS_NOT_EXISTS_OR_NOT_ACESSIBLE_detalhe')
  },
  {
    error: 'ERR_CAMPAIGN_DATE',
    description: i18n.t('erros.ERR_CAMPAIGN_DATE_descricao'),
    detail: i18n.t('erros.ERR_CAMPAIGN_DATE_detalhe')
  },
  {
    error: 'ERROR_CAMPAIGN_NOT_EXISTS',
    description: i18n.t('erros.ERROR_CAMPAIGN_NOT_EXISTS_descricao'),
    detail: i18n.t('erros.ERROR_CAMPAIGN_NOT_EXISTS_detalhe')
  },
  {
    error: 'ERR_NO_CAMPAIGN_FOUND',
    description: i18n.t('erros.ERR_NO_CAMPAIGN_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_CAMPAIGN_FOUND_detalhe')
  },
  {
    error: 'ERR_NO_UPDATE_CAMPAIGN_NOT_IN_CANCELED_PENDING',
    description: i18n.t('erros.ERR_NO_UPDATE_CAMPAIGN_NOT_IN_CANCELED_PENDING_descricao'),
    detail: i18n.t('erros.ERR_NO_UPDATE_CAMPAIGN_NOT_IN_CANCELED_PENDING_detalhe')
  },
  {
    error: 'ERROR_CAMPAIGN_DATE_NOT_VALID',
    description: i18n.t('erros.ERROR_CAMPAIGN_DATE_NOT_VALID_descricao'),
    detail: i18n.t('erros.ERROR_CAMPAIGN_DATE_NOT_VALID_detalhe')
  },
  {
    error: 'ERR_NO_CAMPAIGN_CONTACTS_NOT_FOUND',
    description: i18n.t('erros.ERR_NO_CAMPAIGN_CONTACTS_NOT_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_CAMPAIGN_CONTACTS_NOT_FOUND_detalhe')
  },
  {
    error: 'ERR_CAMPAIGN_CONTACTS_NOT_EXISTS',
    description: i18n.t('erros.ERR_CAMPAIGN_CONTACTS_NOT_EXISTS_descricao'),
    detail: i18n.t('erros.ERR_CAMPAIGN_CONTACTS_NOT_EXISTS_detalhe')
  },
  {
    error: 'ERR_CAMPAIGN_CONTACTS',
    description: i18n.t('erros.ERR_CAMPAIGN_CONTACTS_descricao'),
    detail: i18n.t('erros.ERR_CAMPAIGN_CONTACTS_detalhe')
  },
  {
    error: 'ERR_NO_FAST_REPLY_FOUND',
    description: i18n.t('erros.ERR_NO_FAST_REPLY_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_FAST_REPLY_FOUND_detalhe')
  },
  {
    error: 'ERR_FAST_REPLY_EXISTS',
    description: i18n.t('erros.ERR_FAST_REPLY_EXISTS_descricao'),
    detail: i18n.t('erros.ERR_FAST_REPLY_EXISTS_detalhe')
  },
  {
    error: 'ERR_NO_QUEUE_FOUND',
    description: i18n.t('erros.ERR_NO_QUEUE_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_QUEUE_FOUND_detalhe')
  },
  {
    error: 'ERR_QUEUE_TICKET_EXISTS',
    description: i18n.t('erros.ERR_QUEUE_TICKET_EXISTS_descricao'),
    detail: i18n.t('erros.ERR_QUEUE_TICKET_EXISTS_detalhe')
  },
  {
    error: 'ERR_NO_TAG_FOUND',
    description: i18n.t('erros.ERR_NO_TAG_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_TAG_FOUND_detalhe')
  },
  {
    error: 'ERR_TAG_CONTACTS_EXISTS',
    description: i18n.t('erros.ERR_TAG_CONTACTS_EXISTS_descricao'),
    detail: i18n.t('erros.ERR_TAG_CONTACTS_EXISTS_detalhe')
  },
  {
    error: 'ERR_NO_SETTING_FOUND',
    description: i18n.t('erros.ERR_NO_SETTING_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_SETTING_FOUND_detalhe')
  },
  {
    error: 'ERR_NO_TENANT_FOUND',
    description: i18n.t('erros.ERR_NO_TENANT_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_TENANT_FOUND_detalhe')
  },
  {
    error: 'ERR_CREATING_TICKET',
    description: i18n.t('erros.ERR_CREATING_TICKET_descricao'),
    detail: i18n.t('erros.ERR_CREATING_TICKET_detalhe')
  },
  {
    error: 'ERR_NO_STATUS_SELECTED',
    description: i18n.t('erros.ERR_NO_STATUS_SELECTED_descricao'),
    detail: i18n.t('erros.ERR_NO_STATUS_SELECTED_detalhe')
  },
  {
    error: 'ERR_INVALID_CREDENTIALS',
    description: i18n.t('erros.ERR_INVALID_CREDENTIALS_descricao'),
    detail: i18n.t('erros.ERR_INVALID_CREDENTIALS_detalhe')
  },
  {
    error: 'ERR_NO_USER_FOUND',
    description: i18n.t('erros.ERR_NO_USER_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_USER_FOUND_detalhe')
  },
  {
    error: 'ERR_WAPP_INVALID_CONTACT',
    description: i18n.t('erros.ERR_WAPP_INVALID_CONTACT_descricao'),
    detail: i18n.t('erros.ERR_WAPP_INVALID_CONTACT_detalhe')
  },
  {
    error: 'ERR_WAPP_CHECK_CONTACT',
    description: i18n.t('erros.ERR_WAPP_CHECK_CONTACT_descricao'),
    detail: i18n.t('erros.ERR_WAPP_CHECK_CONTACT_detalhe')
  },
  {
    error: 'ERR_DELETE_WAPP_MSG',
    description: i18n.t('erros.ERR_DELETE_WAPP_MSG_descricao'),
    detail: i18n.t('erros.ERR_DELETE_WAPP_MSG_detalhe')
  },
  {
    error: 'ERR_SENDING_WAPP_MSG',
    description: i18n.t('erros.ERR_SENDING_WAPP_MSG_descricao'),
    detail: i18n.t('erros.ERR_SENDING_WAPP_MSG_detalhe')
  },
  {
    error: 'ERR_WAPP_NOT_INITIALIZED',
    description: i18n.t('erros.ERR_WAPP_NOT_INITIALIZED_descricao'),
    detail: i18n.t('erros.ERR_WAPP_NOT_INITIALIZED_detalhe')
  },
  {
    error: 'ERR_CONTACTS_NOT_EXISTS_WHATSAPP',
    description: i18n.t('erros.ERR_CONTACTS_NOT_EXISTS_WHATSAPP_descricao'),
    detail: i18n.t('erros.ERR_CONTACTS_NOT_EXISTS_WHATSAPP_detalhe')
  },
  {
    error: 'ERR_NO_WAPP_FOUND',
    description: i18n.t('erros.ERR_NO_WAPP_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_WAPP_FOUND_detalhe')
  },
  {
    error: 'ERR_OTHER_OPEN_TICKET',
    description: i18n.t('erros.ERR_OTHER_OPEN_TICKET_descricao'),
    detail: i18n.t('erros.ERR_OTHER_OPEN_TICKET_detalhe')
  },
  {
    error: 'ERR_NO_DEF_WAPP_FOUND',
    description: i18n.t('erros.ERR_NO_DEF_WAPP_FOUND_descricao'),
    detail: i18n.t('erros.ERR_NO_DEF_WAPP_FOUND_detalhe')
  },
  {
    error: 'ERR_FETCH_WAPP_MSG',
    description: i18n.t('erros.ERR_FETCH_WAPP_MSG_descricao'),
    detail: i18n.t('erros.ERR_FETCH_WAPP_MSG_detalhe')
  },
  {
    error: 'ERR_NO_PERMISSION',
    description: i18n.t('erros.ERR_NO_PERMISSION_descricao'),
    detail: i18n.t('erros.ERR_NO_PERMISSION_detalhe')
  }

]

export default errors
