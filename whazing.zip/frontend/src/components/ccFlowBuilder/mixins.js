export const easyFlowMixin = {
  data () {
    return {
      jsplumbSetting: {
        // anclajes dinámicos, posición adaptativa
        Anchors: ['Top', 'TopCenter', 'TopRight', 'TopLeft', 'Right', 'RightMiddle', 'Bottom', 'BottomCenter', 'BottomRight', 'BottomLeft', 'Left', 'LeftMiddle'],
        // ID del contenedor
        Container: 'efContainer',
        // estilo de las líneas de conexión, línea recta o curva, valores posibles: StateMachine、Flowchart，Bezier、Straight
        Connector: ['Bezier', { curviness: 100 }],
        // el ratón no puede arrastrar para eliminar líneas
        ConnectionsDetachable: false,
        // al eliminar líneas los puntos finales no se eliminan
        DeleteEndpointsOnDetach: false,
        /**
         * tipo de punto final circular para las conexiones
         * radius: radio del círculo, mayor valor = círculo más grande
         */
        /**
         * tipo de punto final rectangular para las conexiones
         * height: altura del rectángulo
         * width: ancho del rectángulo
         */
        /**
         * punto final de imagen
         */
        /**
         * punto final en blanco
         */
        Endpoint: ['Blank', { Overlays: '' }],
        /**
         * estilo de los puntos finales de conexión
         * fill: valor del color, ej: #12aabb, vacío no se muestra
         * outlineWidth: ancho del borde exterior
         */
        EndpointStyle: { fill: '#1879ffa1', outlineWidth: 1 },
        // habilitar el registro interno de jsPlumb
        LogEnabled: true,
        /**
         * estilo de las conexiones
         */
        PaintStyle: {
          // color de la línea
          stroke: '#5c67f2',
          // grosor de la línea, mayor valor = línea más gruesa
          strokeWidth: 1,
          // establecer color del borde exterior, por defecto transparente
          outlineStroke: 'transparent',
          // ancho del borde exterior, mayor valor = mayor área para hacer clic
          outlineWidth: 10
        },
        DragOptions: { cursor: 'pointer', zIndex: 2000 },
        /**
         * superposiciones
         */
        Overlays: [
          // superposición de flecha
          ['Arrow', {
            width: 10, // ancho de la cola de la flecha
            length: 8, // distancia de la cola a la punta
            location: 1, // posición, se recomienda entre 0~1
            direction: 1, // dirección, 1 por defecto (hacia adelante), -1 (hacia atrás)
            foldback: 0.623 // plegado, ángulo de las alas, 0.623 por defecto, 1 = triángulo equilátero
          }],
          ['Label', {
            label: '',
            location: 0.1,
            cssClass: 'aLabel'
          }]
        ],
        // modo de renderizado svg、canvas
        RenderMode: 'svg',
        // estilo al pasar el ratón sobre la línea
        HoverPaintStyle: { stroke: '#5c67f2', strokeWidth: 1 },
        Scope: 'jsPlumb_DefaultScope' // ámbito, solo se pueden conectar puntos con el mismo scope
      },
      /**
       * parámetros de conexión
       */
      jsplumbConnectOptions: {
        isSource: true,
        isTarget: true,
        // anclaje dinámico, proporciona 4 direcciones Continuous、AutoDefault
        anchor: 'Continuous',
        // establecer estilo de etiqueta en la línea
        labelStyle: {
          cssClass: 'flowLabel'
        },
        // modificado código fuente jsplumb, soporta etiqueta vacía con estilo personalizado
        emptyLabelStyle: {
          cssClass: 'emptyFlowLabel'
        }
      },
      /**
       * parámetros de configuración del punto de origen 
       */
      jsplumbSourceOptions: {
        // establecer clase que se puede arrastrar
        filter: '.flow-node-drag',
        filterExclude: false,
        anchor: 'Continuous',
        // permitir autoconexión
        allowLoopback: true,
        maxConnections: -1,
        onMaxConnections: function (info, e) {
          console.log(`Se superó el máximo de conexiones: ${info.maxConnections}`)
        }
      },
      // Referencia https://www.cnblogs.com/mq0036/p/7942139.html
      jsplumbSourceOptions2: {
        // establecer clase que se puede arrastrar, solo arrastrará cuando el mouse está sobre el DOM con esta clase
        filter: '.flow-node-drag',
        filterExclude: false,
        // anchor: 'Continuous',
        // permitir conexión con sí mismo
        allowLoopback: true,
        connector: ['Flowchart', { curviness: 50 }],
        connectorStyle: {
          // color de la línea
          stroke: 'red',
          // grosor de la línea, mayor valor = línea más gruesa
          strokeWidth: 1,
          // establecer color del borde exterior, por defecto transparente para ocultarlo, permite clic sin precisión exacta
          outlineStroke: 'transparent',
          // ancho del borde exterior, mayor valor = mayor área para hacer clic
          outlineWidth: 10
        },
        connectorHoverStyle: { stroke: 'red', strokeWidth: 2 }
      },
      jsplumbTargetOptions: {
        // establecer clase que se puede arrastrar, solo arrastrará cuando el mouse está sobre el DOM con esta clase
        filter: '.flow-node-drag',
        filterExclude: false,
        // permitir conexión con sí mismo
        anchor: 'Continuous',
        allowLoopback: true,
        dropOptions: { hoverClass: 'ef-drop-hover' }
      }
    }
  }
}
