import { Request, Response } from "express";
import Whatsapp from "../models/Whatsapp"; // Ajusta la ruta según tu estructura
import { logger } from "../utils/logger"; // Ajusta la ruta
import Queue from "../libs/Queue"; // Ajusta la ruta y asume exportación por defecto

// Define la estructura esperada del body
interface WebhookHubBody {
  number?: string; // Número de WhatsApp asociado
  message?: any; // Estructura del mensaje recibido
  medias?: any[]; // Array de medios adjuntos
  id?: string; // ID del mensaje o evento
  // Otras propiedades posibles
}

// Define la estructura esperada de los parámetros de ruta
interface WebhookHubParams {
  tenantId?: string; // ID del tenant
}

// Extiende la interfaz Request
interface WebhookHubRequest extends Request {
  body: WebhookHubBody;
  params: WebhookHubParams;
}

export const listen = async (
  req: WebhookHubRequest,
  res: Response
): Promise<Response> => {
  const logReceived = "Webhook received"; // "Webhook recibido"
  const logNotFound = "Whatsapp channel not found"; // "Canal de Whatsapp no encontrado"
  const queuePrefix = "SendMessage-"; // Prefijo para el nombre de la cola
  const messageHandlingSuffix = "-handleMessageHub-"; // Sufijo para el jobId

  logger.debug(logReceived); // Usa logger.debug para mensajes de depuración

  const { tenantId } = req.params;
  const { number } = req.body; // Número de la instancia/canal de WhatsApp
  const messageId = req.body?.id; // ID del mensaje recibido

  if (!number) {
    return res.status(400).json({ message: "Number parameter is missing" }); // "Falta el parámetro number"
  }
  if (!tenantId) {
    return res.status(400).json({ message: "TenantId parameter is missing" }); // "Falta el parámetro tenantId"
  }

  // Busca el canal de WhatsApp por número y tenantId
  const whatsappChannel = await Whatsapp.findOne({
    where: { number: number } // Asumiendo que 'number' identifica la instancia
    // Considera añadir tenantId al where si es multi-tenant por número
  });

  // Si no se encuentra el canal
  if (!whatsappChannel) {
    logger.warn(`${logNotFound}: ${number}`); // Log de advertencia
    return res.status(404).json({ message: logNotFound });
  }

  // Obtiene datos relevantes
  const channelTenantId = whatsappChannel.tenantId; // tenantId asociado al canal encontrado
  const channelId = whatsappChannel.id; // ID del canal
  const channelType = whatsappChannel.type; // Tipo de canal (e.g., 'whatsapp', 'telegram')

  // Valida que el tenantId del parámetro coincida con el del canal encontrado
  if (String(channelTenantId) !== tenantId) {
    logger.warn(
      `Tenant mismatch: Param Tenant ${tenantId}, Channel Tenant ${channelTenantId}`
    );
    return res.status(403).json({ message: "Tenant ID mismatch" }); // "Discrepancia de Tenant ID"
  }

  try {
    // Prepara los datos para la cola
    const jobData = {
      message: req.body, // Cuerpo completo de la solicitud
      whatsapp: whatsappChannel.toJSON(), // Convierte el modelo a objeto plano
      tenantId: channelTenantId, // Usa el tenantId del canal
      // jobId necesita ser único para el manejo de mensajes, combina ID de canal y mensaje
      jobId: channelId + messageHandlingSuffix + messageId
    };

    // Añade el trabajo a la cola específica del tipo de canal
    // Usa await si Queue.add devuelve una promesa y necesitas esperar
    await Queue.add(`${queuePrefix}${channelType}`, [jobData]); // Añade como un array con un solo elemento

    // Responde con éxito
    return res.status(200).json({ message: logReceived });
  } catch (error: any) {
    logger.error("Error adding job to queue:", error); // Log del error
    // Responde con error del servidor
    return res
      .status(500)
      .json({ message: "Failed to queue webhook data", error: error.message }); // "Fallo al encolar datos del webhook"
  }
};
