import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'ratingClosing' column to the 'Whatsapps' table
    // Stores the message text sent when closing a ticket after rating.
    await queryInterface.addColumn(
      'Whatsapps',       // Table name
      'ratingClosing',   // New column name
      {
        type: DataTypes.TEXT, // TEXT for potentially long messages
        // allowNull defaults to true
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'ratingClosing' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps',       // Table name
      'ratingClosing'    // Column name to remove
    );
  }
};

export = migration;