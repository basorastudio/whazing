// Original: GetIntegrationsID.js
// Deobfuscated, converted to TS, and translated

'use strict';

import Queue from '../models/Queue'; // Asumiendo exportación predeterminada

// Tipos inferidos para el modelo Queue
interface QueueInstance {
    id: number;
    integrationId?: number | string | null; // Asumiendo que puede ser number, string o null
    // otras propiedades...
}


const GetIntegrationsID = async (queueId: number | string): Promise<number | string | null> => {

    try {
        const queue = await Queue.findOne({
            where: { id: queueId }
        }) as QueueInstance | null; // Castear tipo

        // Si se encuentra la cola y tiene integrationId, retornarlo
        if (queue && queue.integrationId) {
            return queue.integrationId;
        }
        // Si no, retornar null
        return null;

    } catch (error) {
         // Traducido: Fila no tiene integración.
        console.error('Fila no tiene integración:', error);
        return null; // Retornar null en caso de error también
    }
};

export default GetIntegrationsID;