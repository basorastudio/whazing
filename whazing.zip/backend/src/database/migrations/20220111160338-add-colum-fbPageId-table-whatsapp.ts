// --- START OF FILE 20220111160338-add-colum-fbPageId-table-whatsapp.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Whatsapps'; // Assuming 'whatsapp' -> 'Whatsapps' for consistency
        const fbPageIdColumn = 'fbPageId';
        const fbObjectColumn = 'fbObject'; // Column name from original code

        const fbPageIdAttributes = {
            type: DataTypes.TEXT,
            allowNull: true, // Changed !![] to true
            defaultValue: null
        };
        const fbObjectAttributes = {
            type: DataTypes.JSONB, // Original code had JSONB
            allowNull: true, // Changed !![] to true
            defaultValue: null
        };

        await Promise.all([
            queryInterface.addColumn(tableName, fbPageIdColumn, fbPageIdAttributes),
            queryInterface.addColumn(tableName, fbObjectColumn, fbObjectAttributes)
        ]);
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Whatsapps'; // Assuming 'whatsapp' -> 'Whatsapps' for consistency
        const fbPageIdColumn = 'fbPageId';
        const fbObjectColumn = 'fbObject';

        await Promise.all([
            queryInterface.removeColumn(tableName, fbPageIdColumn),
            queryInterface.removeColumn(tableName, fbObjectColumn)
        ]);
    }
};

export default migration;
// --- END OF FILE 20220111160338-add-colum-fbPageId-table-whatsapp.ts ---