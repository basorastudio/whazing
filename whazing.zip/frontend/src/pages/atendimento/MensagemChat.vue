<template>
  <div class="q-pa-md">
    <transition-group appear
      enter-active-class="animated fadeIn"
      leave-active-class="animated fadeOut">
      <!-- Agrupar mensagens por ticketId -->
      <template v-for="(group, ticketId) in groupedMessages">
        <div v-bind:key="`ticket-${ticketId}`">
          <!-- Exibe o título do ticket -->
          <div class="ticket-title q-mb-md q-mt-md">
            {{ $t('mensagemchat.ticket') }} {{ ticketId }}
          </div>
          <template v-for="(mensagem, index) in group">
            <hr
              v-if="index === 0 || formatarData(mensagem.createdAt) !== formatarData(group[index - 1]?.createdAt)"
              :key="'hr-' + index"
              class="hr-text q-mt-lg q-mb-md"
              :data-content="formatarData(mensagem.createdAt)"
            />
        <template v-if="mensagens.length && index === mensagens.length - 1">
          <div :key="`ref-${mensagem.createdAt}`"
            ref="lastMessageRef"
            id="lastMessageRef"
            style="float: 'left', background: 'black', clear: 'both'" />
        </template>
        <div :key="`chat-message-${mensagem.id}`"
          :id="`chat-message-${mensagem.id}`" />
        <q-chat-message :key="mensagem.id"
          :stamp="dataInWords(mensagem.createdAt)"
          :sent="mensagem.fromMe"
          class="text-weight-medium"
          :bg-color="mensagem.mediaType === 'note'
          ? 'yellow'
          : (mensagem.fromMe
          ? ($q.dark.isActive ? 'green-2' : 'green-1')
          : ($q.dark.isActive ? 'blue-2' : 'blue-1'))"
                        :class="{ pulseIdentications: identificarMensagem == `chat-message-${mensagem.id}` }">
          <!-- :bg-color="mensagem.fromMe ? 'grey-2' : 'secondary' " -->
          <div style="min-width: 100px; max-width: 350px;"
            :style="mensagem.isDeleted ? 'color: rgba(0, 0, 0, 0.36) !important;' : ''">
            <q-checkbox v-if="ativarMultiEncaminhamento"
              :key="`cheked-chat-message-${mensagem.id}`"
              :class="{
                  'absolute-top-right checkbox-encaminhar-right': !mensagem.fromMe,
                  'absolute-top-left checkbox-encaminhar-left': mensagem.fromMe
                }"
              :ref="`box-chat-message-${mensagem.id}`"
              @click.native="verificarEncaminharMensagem(mensagem)"
              :value="false" />

            <q-icon class="q-ma-xs"
              name="mdi-calendar"
              size="18px"
              :class="{
                  'text-primary': mensagem.scheduleDate && mensagem.status === 'pending',
                  'text-positive': !['pending', 'canceled'].includes(mensagem.status)
                }"
              v-if="mensagem.scheduleDate">
              <q-tooltip content-class="bg-secondary text-grey-8">
                <div class="row col">
                  {{ $t('mensagemchat.scheduledmessage') }}
                </div>
                <div class="row col"
                  v-if="mensagem.isDeleted">
                  <q-chip color="red-3"
                    icon="mdi-trash-can-outline">
                    {{ $t('mensagemchat.submissioncanceled') }} {{ formatarData(mensagem.updatedAt, 'dd/MM/yyyy') }}
                  </q-chip>
                </div>
                <div class="row col">
                  <q-chip color="blue-1"
                    icon="mdi-calendar-import">
                    {{ $t('mensagemchat.senton') }} {{ formatarData(mensagem.createdAt, 'dd/MM/yyyy HH:mm') }}
                  </q-chip>
                </div>
                <div class="row col">
                  <q-chip color="blue-1"
                    icon="mdi-calendar-start">
                    {{ $t('mensagemchat.scheduledon') }} {{ formatarData(mensagem.scheduleDate, 'dd/MM/yyyy HH:mm') }}
                  </q-chip>
                </div>
              </q-tooltip>
            </q-icon>
            <div v-if="mensagem.sendType && mensagem.sendType.startsWith('user:')" class="bot-message">
              <q-icon name="mdi-account" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">{{ mensagem.sendType.replace('user: ', '') }}</span>
            </div>
            <div v-if="mensagem.sendType === 'Campaign'" class="bot-message">
              <q-icon name="mdi-bullhorn" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">{{ $t('mensagemchat.campaign') }}</span>
            </div>
            <div v-if="mensagem.sendType === 'bot'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">{{ $t('mensagemchat.bot') }}</span>
            </div>
            <div v-if="mensagem.sendType === 'typebot'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">{{ $t('mensagemchat.typebot') }}</span>
            </div>
            <div v-if="mensagem.sendType === 'openai'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">{{ $t('mensagemchat.ChatGPT') }}</span>
            </div>
            <div v-if="mensagem.sendType === 'groq'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">{{ $t('mensagemchat.Groq') }}</span>
            </div>
            <div v-if="mensagem.sendType === 'deepseek'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">{{ $t('mensagemchat.DeepSeek') }}</span>
            </div>
            <div v-if="mensagem.sendType === 'grokxai'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">Grok xAI</span>
            </div>
            <div v-if="mensagem.sendType === 'API'" class="bot-message">
              <q-icon name="mdi-api" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
            </div>
              <div v-if="mensagem.isForwarded" class="forwarded-message">
                <i class="fa fa-share"></i>
                {{ $t('mensagemchat.status.encaminhada') }}
              </div>
            <div v-if="mensagem.isDeleted"
              class="text-italic">
              {{ $t('mensagemchat.Messagedeletedin') }} {{ formatarData(mensagem.updatedAt, 'dd/MM/yyyy') }}.
            </div>
            <div v-if="isGroupLabel(mensagem)"
                 class="q-mb-sm"
                 style="display: flex; align-items: center; color: rgb(59 23 251); fontWeight: 500;">
              <q-avatar v-if="mensagem.contact && mensagem.contact.profilePicUrl"
                        size="40px"
                        class="q-mr-sm">
                <img :src="mensagem.contact.profilePicUrl" alt="Profile Picture">
              </q-avatar>
              {{ isGroupLabel(mensagem) }}
            </div>
            <div v-if="mensagem.quotedMsg" :class="{ textContentItem: !mensagem.isDeleted, textContentItemDeleted: mensagem.isDeleted }" @click="focarMensagem(mensagem.quotedMsg)">
              <MensagemRespondida
                style="max-width: 240px; max-height: 150px"
                class="row justify-center"
                :mensagem="mensagem.quotedMsg"
              />
            </div>
            <q-btn v-if="!mensagem.isDeleted && isShowOptions && mensagem.mediaType !== 'note'" class="absolute-top-right" dense flat ripple round icon="mdi-chevron-down">
              <q-menu square auto-close anchor="bottom left" self="top left">
                <q-list style="min-width: 100px">
                  <q-item v-if="mensagem.mediaType === 'comment' && ['hub_instagram'].includes(ticketFocado.channel)"
                          clickable
                          @click=" ResponderComentario(mensagem) ">
                    <q-item-section>Responder comentario</q-item-section>
                  </q-item>
                  <q-item v-if="!mensagem.fromMe && ticketFocado.isGroup"
                          clickable
                          @click="abrirTicketPrivado(mensagem)">
                    <q-item-section>{{ $t('mensagemchat.abrirTicketPrivado') }}</q-item-section>
                  </q-item>
                  <q-item v-if="['whatsapp', 'telegram', 'hub_whatsapp'].includes(ticketFocado.channel)"
                    clickable
                    @click=" citarMensagem(mensagem) ">
                    <q-item-section>{{ $t('mensagemchat.mensagens.responder') }}</q-item-section>
                  </q-item>
                  <q-item clickable v-if="['whatsapp', 'hub_whatsapp'].includes(ticketFocado.channel)"
                    @click=" encaminharMensagem(mensagem) ">
                    <q-item-section>{{ $t('mensagemchat.encaminhar') }}</q-item-section>
                  </q-item>
                  <q-item clickable v-if="['whatsapp', 'hub_whatsapp'].includes(ticketFocado.channel)"
                    @click=" marcarMensagensParaEncaminhar(mensagem) ">
                    <q-item-section>{{ $t('mensagemchat.mensagens.encaminharVarias') }}</q-item-section>
                  </q-item>

                  <q-item clickable @click="mensagemReacao = mensagem; modalEmojiOpen = true" v-if="ticketFocado.channel && ['whatsapp', 'hub_whatsapp'].includes(ticketFocado.channel)">
                    <q-item-section>{{ $t('mensagemchat.mensagens.reagir') }}</q-item-section>
                  </q-item>

                  <q-item
                    @click=" AbrirmodaleditarMensagem(mensagem) "
                    clickable
                    v-if="mensagem.fromMe && mensagem.mediaType === 'chat' && ticketFocado.channel === 'whatsapp'"
                    :disable=" !['whatsapp'].includes(ticketFocado.channel) "
                  >
                    <q-item-section>
                      <q-item-label>{{ $t('mensagemchat.mensagens.editar') }}</q-item-label>
                    </q-item-section>
                  </q-item>
                  <q-separator />
                  <q-item @click=" deletarMensagem(mensagem) "
                    clickable
                    v-if="mensagem.fromMe && ticketFocado.channel === 'whatsapp'">
                    <q-item-section>
                      <q-item-label>{{ $t('mensagemchat.mensagens.deletar') }}</q-item-label>
                    </q-item-section>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>
            <q-icon v-if="mensagem.fromMe && mensagem.mediaType !== 'note'"
                    class="absolute-bottom-right q-pr-xs q-pb-xs"
                    :name="ackIcons[mensagem.ack]"
                    size="1.2em"
                    :color="mensagem.ack >= 3 ? 'blue-12' : (mensagem.ack === -1 ? 'red' : '')" />
            <template v-if=" mensagem.mediaType === 'audio' ">
              <div style="width: 330px; heigth: 300px">
                <audio class="q-mt-md full-width"
                  controls
                  ref="audioMessage"
                  controlsList="download playbackrate volume">
                  <source :src=" mensagem.mediaUrl "
                    type="audio/mp3" />
                </audio>
              </div>
            </template>
            <template v-if=" mensagem.mediaType === 'contactMessage' ">
                <div style="min-width: 250px;">
                <ContatoCard
                :mensagem="mensagem"
                @openContactModal="openContactModal"
                />
                <ContatoModal
                :value="modalContato"
                :contact="currentContact"
                @close="closeModal"
                @saveContact="saveContact"
                />
                </div>
            </template>
            <template v-if="mensagem.mediaType === 'locationMessage'">
              <q-img
                @click="openGoogleMaps(mensagem.body)"
                src="../../assets/localizacao.png"
                spinner-color="primary"
                height="200px"
                width="200px"
                class="q-mt-md"
                style="cursor: pointer"
              />
              <div>{{ $t('mensagemchat.midia.localizacao') }}</div>
            </template>
            <template v-if="mensagem.mediaType === 'sendlocation'">
              <q-img
                @click="openGoogleMaps(mensagem.body)"
                src="../../assets/localizacao.png"
                spinner-color="primary"
                height="200px"
                width="200px"
                class="q-mt-md"
                style="cursor: pointer"
              />
              <div class="location-info q-mt-sm">
                <div class="text-weight-bold">{{ formatLocationName(mensagem.body) }}</div>
                <div class="text-caption">{{ formatLocationAddress(mensagem.body) }}</div>
              </div>
              <div>{{ $t('mensagemchat.midia.localizacao') }}</div>
            </template>
            <template v-if="mensagem.mediaType === 'liveLocationMessage'">
              <q-img
                @click="openGoogleMaps(mensagem.body)"
                src="../../assets/localizacao.png"
                spinner-color="primary"
                height="250px"
                width="250px"
                class="q-mt-md"
                style="cursor: pointer"
              />
            <div style="color: red;">{{ $t('mensagemchat.midia.indisponivel.localizacao') }}</div>
            </template>
            <template v-if="mensagem.mediaType === 'comment'">
              <div class="social-comment simple-comment"
                   :class="{'instagram-comment': formatarComentario(mensagem.dataJson).plataforma === 'instagram',
                'facebook-comment': formatarComentario(mensagem.dataJson).plataforma === 'facebook'}">

                <!-- Ícone da plataforma -->
                <div class="platform-icon">
                  <q-icon :name="formatarComentario(mensagem.dataJson).plataforma === 'instagram' ? 'mdi-instagram' : 'mdi-facebook'"
                          size="16px"
                          class="q-mr-xs" />
                </div>

                <!-- Nome do usuário em negrito -->
                <div class="comment-author">
                  <strong>{{ formatarComentario(mensagem.dataJson).plataforma === 'instagram' ? '@' : '' }}{{ formatarComentario(mensagem.dataJson).nomeUsuario }}</strong>
                </div>

                <!-- Texto do comentário -->
                <div class="comment-text">
                  {{ formatarComentario(mensagem.dataJson).textoComentario }}
                </div>

                <!-- Link para a publicação (se disponível) -->
                <a
                  v-if="formatarComentario(mensagem.dataJson).linkPublicacao"
                  :href="formatarComentario(mensagem.dataJson).linkPublicacao"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="publication-link"
                >
                  {{ formatarComentario(mensagem.dataJson).plataforma === 'instagram'
                  ? 'Ver publicação no Instagram'
                  : 'Ver publicação no Facebook' }}
                </a>
              </div>
            </template>
            <template v-if="mensagem.mediaType === 'interactiveMessage'">
              <div v-html=" formatarinteractiveMessage(mensagem.dataJson) "></div>
            </template>
            <template v-if="mensagem.mediaType === 'pollCreationMessageV2'">
              <div v-html=" formatarMensagemWhatsapp(mensagem.body) ">
              </div>
              <div style="color: red;">{{ $t('mensagemchat.midia.indisponivel.enquete') }}</div>
            </template>
            <template v-if="mensagem.mediaType === 'pollCreationMessageV3'">
              <div v-html=" formatarpollCreationMessage(mensagem.dataJson) ">
              </div>
            <div style="color: red;">{{ $t('mensagemchat.midia.indisponivel.enquete') }}</div>
            </template>
            <template v-if="mensagem.mediaType === 'note'">
              <div v-html="formatarNota(mensagem.body)"></div>
            </template>
            <template v-if="mensagem.mediaType === 'productMessage'">
              <div v-html=" formatarproductMessage(mensagem.dataJson) "></div>
            </template>
            <template v-if="mensagem.mediaType === 'eventMessage'">
              <div v-html=" formatarEventMessage(mensagem.dataJson) "></div>
            </template>
            <template v-if="mensagem.mediaType === 'sticker'">
              <div style="width: 200px; max-width: 200px; overflow: hidden;">
                <img
                  :src="mensagem.mediaUrl"
                  @click="urlMedia = mensagem.mediaUrl; abrirModalImagem = true"
                  style="width: 150px; height: 150px; object-fit: fill; cursor: pointer; display: block;"
                  class="q-mt-md" />
              </div>
              <VueEasyLightbox
                :visible="abrirModalImagem"
                :imgs="urlMedia"
                class="bg-transparent easy-lightbox-wrapper"
                :index="mensagem.ticketId || 1"
                @hide="abrirModalImagem = false" />
            </template>
            <template v-if="mensagem.mediaType === 'image'">
              <div style="width: 100%; max-width: 200px; overflow: hidden;">
                <img @click="urlMedia = mensagem.mediaUrl; abrirModalImagem = true"
                     :src="mensagem.mediaUrl"
                     style="width: 100%; height: auto; object-fit: contain; cursor: pointer; display: block;"
                     class="q-mt-md" />
              </div>
              <q-btn type="a"
                     :color=" $q.dark.isActive ? '' : 'grey-3' "
                     no-wrap
                     no-caps
                     stack
                     dense
                     class="q-mt-sm text-center text-black btn-rounded  text-grey-9 ellipsis"
                     download
                     @click="downloadMedia(mensagem.mediaUrl)"
              >
                <q-tooltip v-if=" mensagem.mediaUrl "
                           content-class="text-bold">
                  {{ $t('mensagemchat.midia.baixar') }} {{ formatMediaName(mensagem.mediaName) }}
                </q-tooltip>
                <div class="row items-center q-ma-xs ">
                  <div class="ellipsis col-grow q-pr-sm"
                       style="max-width: 290px">
                    {{ formatMediaName(mensagem.mediaName) }}
                  </div>
                  <q-icon name="mdi-download" />
                </div>
              </q-btn>
              <VueEasyLightbox
                               :visible="abrirModalImagem"
                               :imgs="urlMedia"
                               class="bg-transparent easy-lightbox-wrapper"
                               :index="mensagem.ticketId || 1"
                               @hide="abrirModalImagem = false" />
            </template>
            <template v-if="mensagem.mediaType === 'video'">
              <div style="width: 100%; max-width: 330px; overflow: hidden;">
                <video :src="mensagem.mediaUrl"
                       controls
                       ref="videoElement"
                       style="width: 100%; height: auto; object-fit: contain; border-radius: 8px; max-height: 400px;">
                </video>
              </div>
              <q-btn type="a"
                     :color=" $q.dark.isActive ? '' : 'grey-3' "
                     no-wrap
                     no-caps
                     stack
                     dense
                     class="q-mt-sm text-center text-black btn-rounded  text-grey-9 ellipsis"
                     download
                     @click="downloadMedia(mensagem.mediaUrl)"
              >
                <q-tooltip v-if=" mensagem.mediaUrl "
                           content-class="text-bold">
                  {{ $t('mensagemchat.midia.baixar') }} {{ formatMediaName(mensagem.mediaName) }}
                </q-tooltip>
                <div class="row items-center q-ma-xs ">
                  <div class="ellipsis col-grow q-pr-sm"
                       style="max-width: 290px">
                    {{ formatMediaName(mensagem.mediaName) }}
                  </div>
                  <q-icon name="mdi-download" />
                </div>
              </q-btn>
            </template>
            <template v-if="mensagem.mediaType === 'protocolMessage'">
              <div class="forwarded-message" v-html="formatarBotaoWhatsapp(mensagem.body)"></div>
            </template>
            <template v-if="mensagem.mediaType === 'buttonsMessage'">
              <div style="margin-top:20px" v-html="formatarBotaoWhatsapp(mensagem.body)"></div>
            </template>
            <template v-if="mensagem.mediaType === 'listMessage'">
              <div style="margin-top:20px" v-html="formatarBotaoWhatsapp(mensagem.body)"></div>
            </template>
            <template v-if="mensagem.mediaType === 'interactive'">
              <div style="margin-top:20px" v-html="formatarInteractiveWhatsapp(mensagem.dataJson)"></div>
            </template>
            <template v-if="mensagem.mediaType === 'templateoficial'">
              <div style="margin-top:20px" v-if="mensagem.body === 'templateoficial'" v-html="formatarTemplateWhatsapp(mensagem.dataJson)"></div>
              <div v-else style="margin-top:20px" v-html="formatarMensagemWhatsapp(mensagem.body)"></div>
            </template>
            <template v-if=" !['audio', 'vcard', 'image', 'video'].includes(mensagem.mediaType) && mensagem.mediaUrl ">
              <div class="text-center full-width hide-scrollbar no-scroll">
                <iframe v-if=" isPDF(mensagem.mediaUrl) "
                  frameBorder="0"
                  scrolling="no"
                  style="
                    width: 330px;
                    height: 150px;
                    overflow-y: hidden;
                    -ms-overflow-y: hidden;
                  "
                  class="no-scroll hide-scrollbar"
                  :src=" mensagem.mediaUrl "
                  id="frame-pdf">
                  {{ $t('mensagemchat.midia.baixarpdf') }}
                  <!-- alt : <a href="mensagem.mediaUrl"></a> -->
                </iframe>
                <q-btn type="a"
                  :color=" $q.dark.isActive ? '' : 'grey-3' "
                  no-wrap
                  no-caps
                  stack
                  dense
                  class="q-mt-sm text-center text-black btn-rounded  text-grey-9 ellipsis"
                  download
                  :target=" isPDF(mensagem.mediaUrl) ? '_blank' : '' "
                  :href=" mensagem.mediaUrl ">
                  <q-tooltip v-if=" mensagem.mediaUrl "
                    content-class="text-bold">
                    {{ $t('mensagemchat.midia.baixar') }} {{ formatMediaName(mensagem.mediaName) }}
                  </q-tooltip>
                  <div class="row items-center q-ma-xs ">
                    <div class="ellipsis col-grow q-pr-sm"
                      style="max-width: 290px">
                      {{ formatMediaName(mensagem.mediaName) }}
                    </div>
                    <q-icon name="mdi-download" />
                  </div>
                </q-btn>
              </div>
            </template>
            <div v-linkified
              v-if=" !['sticker', 'templateoficial', 'reactionMessage', 'note', 'protocolMessage', 'listMessage', 'buttonsMessage', 'productMessage', 'contactMessage', 'locationMessage', 'liveLocationMessage', 'interactiveMessage', 'pollCreationMessageV3', 'comment', 'eventMessage', 'interactive'].includes(mensagem.mediaType) "
                 :class="{'q-mt-sm': !['chat','extendedMessageText', 'conversation'].includes(mensagem.mediaType)}"
              class="q-message-container row items-end no-wrap">
              <div v-if="'canRead' in mensagem && !mensagem.canRead">
                <i>{{ $t('mensagemchat.status.semPermissao') }}</i>
              </div>
              <div v-if="mensagem.body && !mensagem.edited" v-html="formatarMensagemWhatsapp(mensagem.body)">
              </div>
            </div>
            <div v-if="mensagem.body && mensagem.edited">
              <div v-html="formatarMensagemWhatsapp(mensagem.body)"></div>
              <small class="text-grey">({{ $t('mensagemchat.status.editada') }}) {{ mensagem.edited }}</small>
            </div>
            <div v-if="mensagem.mediaType === 'reactionMessage'" class="reaction-container q-mt-xs">
              {{ mensagem.body }}
            </div>
          </div>
        </q-chat-message>
      </template>
    </transition-group>

<q-dialog v-model="modalEmojiOpen">
  <q-card>
    <q-card-section class="row q-gutter-sm">
      <!-- Exibe os 6 emojis principais -->
      <q-btn v-for="emoji in principaisEmojis" :key="emoji" flat @click="selectEmoji(emoji, mensagemReacao)">
        {{ emoji }}
      </q-btn>

      <!-- Botão circular com o ícone "+" -->
      <q-btn
        flat
        round
        icon="add"
        size="sm"
        class="q-ml-sm"
        @click="expandirEmojis = !expandirEmojis"
      />

      <!-- Exibe o restante dos emojis se expandirEmojis for verdadeiro -->
      <div v-if="expandirEmojis">
        <VEmojiPicker
          style="width: 40vw"
          :showSearch="true"
          :emojisByRow="calculateEmojisByRow()"
          labelSearch="Localizar..."
          lang="pt-BR"
          @select="onInsertSelectEmoji"
        />
      </div>
    </q-card-section>
  </q-card>
</q-dialog>

  <q-dialog v-model="showModaledit">
  <q-card class="q-pa-lg modal-container container-rounded-10">
    <q-card-section>
      <div class="text-h6">{{ $t('mensagemchat.mensagens.editar') }}</div>
    </q-card-section>
    <q-card-section>

      <q-input
        hide-bottom-space
        type="textarea"
        class="col-grow q-mx-xs text-grey-10 inputEnvioMensagem"
        bg-color="grey-2"
        color="grey-7"
        :placeholder="$t('inputmensagem.digitar_mensagem')"
        input-style="max-height: 30vh"
        autogrow
        rounded
        dense
        outlined
        autofocus
        v-model="mensagemAtual.body"
      >
      </q-input>
    </q-card-section>
    <q-card-actions align="right">
      <q-btn :label="$t('general.cancelar')" color="negative" v-close-popup />
      <q-btn :label="$t('general.salvar')" color="primary" @click="salvarMensagem" />
    </q-card-actions>
  </q-card>
</q-dialog>

    <q-dialog v-model="modalSelecionarCanal" persistent>
      <q-card class="q-pa-md" style="width: 500px">
        <q-card-section>
          <div class="text-h6">{{ $t('newticket.title') }}</div>
        </q-card-section>

        <q-card-section>
          <q-select
            square
            outlined
            v-model="canalSelecionado"
            :options="canaisUsuario"
            emit-value
            map-options
            option-value="id"
            option-label="name"
            :label="$t('newticket.canal')"
          />
        </q-card-section>

        <q-card-section>
          <q-select
            square
            outlined
            v-model="filaSelecionada"
            :options="cUserQueues"
            emit-value
            map-options
            option-value="id"
            option-label="queue"
            :label="$t('newticket.fila')"
          />
        </q-card-section>

        <q-card-section v-if="erro" class="text-negative text-caption q-mt-sm">
          {{ erro }}
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat
                 :label="$t('general.cancelar')"
                 color="negative"
                 v-close-popup
                 @click="fecharModalCanal" />
          <q-btn flat
                 :label="$t('general.salvar')"
                 color="primary"
                 @click="criarTicket" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <q-dialog v-model="modalResponderComentario">
      <q-card class="q-pa-md" style="min-width: 350px">
        <q-card-section>
          <div class="text-h6">{{ $t('respondercomentario.titulo') }}</div>
        </q-card-section>

        <q-card-section>
          <q-input
            v-model="respostaComentario"
            ref="respostaComentario"
            id="respostaComentario"
            type="textarea"
            filled
            autogrow
            :placeholder="$t('inputmensagem.digitar_mensagem')"
            class="q-mb-md"
            maxlength="1000"
          >
            <template v-slot:append>
              <q-btn flat dense icon="mdi-emoticon-happy-outline" :disable="cDisableActions" class="btn-rounded-cor1 q-mx-xs" :class="$q.dark.isActive ? ('btn-rounded-cor1-dark q-mx-xs') : ''">
                <q-tooltip content-class="text-bold">{{ $t('inputmensagem.emoji') }}</q-tooltip>
                <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                  <VEmojiPicker style="width: 40vw" :showSearch="true" emojisByRow="15" :labelSearch="$t('inputmensagem.localizar')" lang="pt-BR" @select="onInsertSelectEmojiComent" />
                </q-menu>
              </q-btn>
            </template>
          </q-input>

          <div v-if="respostaErro" class="text-negative q-mt-sm">
            {{ respostaErro }}
          </div>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat :label="$t('general.cancelar')" color="negative" v-close-popup @click="fecharModalResposta" />
          <q-btn flat :label="$t('inputmensagem.enviar')" color="primary" @click="enviarRespostaComentario" :loading="enviandoResposta" />
        </q-card-actions>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
import { ListarCanalUsuario } from 'src/service/user'
const UserQueues = JSON.parse(localStorage.getItem('queues'))
import { CriarTicketNew, DeletarMensagem, EditarMensagem, ReagirMensagem, EnviarRespostaComentarioInstagram } from 'src/service/tickets'
import mixinCommon from './mixinCommon'
import axios from 'axios'
import VueEasyLightbox from 'vue-easy-lightbox'
import MensagemRespondida from './MensagemRespondida'
import ContatoCard from './ContatoCard.vue'
import ContatoModal from './ContatoModal.vue'
import { VEmojiPicker } from 'v-emoji-picker'
const downloadImageCors = axios.create({
  baseURL: process.env.URL_API,
  timeout: 20000,
  headers: {
    responseType: 'blob'
  }
})
import { Base64 } from 'js-base64'
export default {
  name: 'MensagemChat',
  mixins: [mixinCommon],
  props: {
    mensagem: {
      type: Object,
      required: true
    },
    mensagens: {
      type: Array,
      default: () => []
    },
    mensagensParaEncaminhar: {
      type: Array,
      default: () => []
    },
    size: {
      type: [String, Number],
      default: '5'
    },
    isLineDate: {
      type: Boolean,
      default: true
    },
    isShowOptions: {
      type: Boolean,
      default: true
    },
    ativarMultiEncaminhamento: {
      type: Boolean,
      default: false
    },
    replyingMessage: {
      type: Object,
      default: () => { }
    }
  },
  data () {
    return {
      modalEmojiOpen: false,
      mensagemReacao: null,
      expandirEmojis: false,
      principaisEmojis: ['👍', '❤️', '😂', '😮', '😢', '👏'],
      mensagemAtual: { body: '' },
      showModaledit: false,
      modalContato: false,
      currentContact: {},
      abrirModalImagem: false,
      modalSelecionarCanal: false,
      canalSelecionado: null,
      filaSelecionada: null,
      canaisUsuario: [],
      contatoAtual: null,
      erro: null,
      loading: false,
      urlMedia: '',
      identificarMensagem: null,
      modalResponderComentario: false,
      comentarioAtual: null,
      respostaComentario: '',
      respostaErro: null,
      enviandoResposta: false,
      showEmojiPicker: false,
      ackIcons: {
        '-2': 'mdi-web',
        '-1': 'mdi-close',
        0: 'mdi-clock-outline',
        1: 'mdi-check',
        2: 'mdi-check-all',
        3: 'mdi-check-all',
        4: 'mdi-check-all'
      }
    }
  },
  components: {
    VueEasyLightbox,
    MensagemRespondida,
    ContatoCard,
    ContatoModal,
    VEmojiPicker
  },
  computed: {
    groupedMessages() {
      const groups = {}
      this.mensagens.forEach((mensagem) => {
        const ticketId = mensagem.ticketId
        if (!groups[ticketId]) {
          groups[ticketId] = []
        }
        groups[ticketId].push(mensagem)
      })

      return groups
    },
    cUserQueues () {
      return UserQueues
    }
  },
  methods: {
    onInsertSelectEmoji(emoji) {
      if (this.mensagemReacao) {
        const reactionData = {
          messageId: this.mensagemReacao.messageId,
          ticketId: this.mensagemReacao.ticketId,
          reaction: emoji.data
        }
        this.selectEmoji(reactionData.reaction, this.mensagemReacao)
      } else {
        console.error('Nenhuma mensagem foi selecionada para reação.')
      }
      this.modalEmojiOpen = false
    },
    onInsertSelectEmojiComent (emoji) {
      const self = this
      var tArea = this.$refs.respostaComentario.$refs.input
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value

      // filter:
      if (!emoji.data) {
        return
      }

      // insert:
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      // Atualiza o v-model
      this.respostaComentario = self.txtContent

      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    async selectEmoji(emoji, mensagem) {
      if (mensagem) {
        const reactionData = {
          messageId: mensagem.messageId,
          ticketId: mensagem.ticketId,
          reaction: emoji
        }
        await ReagirMensagem(reactionData)
        this.mensagem = null
      } else {
        console.error('Nenhuma mensagem foi selecionada para reação.')
      }
      this.modalEmojiOpen = false
    },
    calculateEmojisByRow() {
      const screenWidth = window.innerWidth
      if (screenWidth < 600) {
        return 5
      } else if (screenWidth >= 600 && screenWidth < 1200) {
        return 10
      } else {
        return 20
      }
    },
    async salvarMensagem () {
      try {
        const updatedMessage = await EditarMensagem({
          id: this.mensagemAtual.id,
          messageId: this.mensagemAtual.messageId,
          body: this.mensagemAtual.body
        })
        // console.log('Mensagem editada com sucesso')
        this.showModaledit = false
        this.atualizarMensagem(updatedMessage)
      } catch (error) {
        console.error('Erro ao editar a mensagem', error.message)
        this.$notificarErro(this.$t('mensagemchat.erros.editarMensagem'))
      }
    },
    atualizarMensagem (updatedMessage) {
      const index = this.mensagens.findIndex(mensagem => mensagem.id === updatedMessage.id)
      if (index !== -1) {
        this.mensagens.splice(index, 1, updatedMessage)
      }
    },
    AbrirmodaleditarMensagem (mensagem) {
      this.mensagemAtual = mensagem
      this.showModaledit = true
    },
    openContactModal (contact) {
      this.currentContact = contact
      this.modalContato = true
    },
    closeModal () {
      this.modalContato = false
    },
    ResponderComentario(mensagem) {
      this.comentarioAtual = mensagem
      this.respostaComentario = ''
      this.respostaErro = null
      this.modalResponderComentario = true
    },
    fecharModalResposta() {
      this.modalResponderComentario = false
      this.comentarioAtual = null
      this.respostaComentario = ''
      this.respostaErro = null
      this.showEmojiPicker = false
    },
    async enviarRespostaComentario() {
      if (!this.respostaComentario.trim()) {
        this.respostaErro = this.$t('respondercomentario.erro')
        return
      }

      this.enviandoResposta = true
      this.respostaErro = null

      try {
        const data = {
          body: this.respostaComentario,
          quotedMsgId: this.comentarioAtual.id,
          wabaMediaId: this.comentarioAtual.wabaMediaId
        }

        await EnviarRespostaComentarioInstagram(this.comentarioAtual.ticketId, data)

        this.$q.notify({
          message: this.$t('respondercomentario.sucesso'),
          type: 'positive',
          position: 'top'
        })

        this.fecharModalResposta()
      } catch (error) {
        console.error('Erro ao enviar resposta:', error)
        this.respostaErro = error.response?.data?.message || this.$t('respondercomentario.erroenviar')

        this.$q.notify({
          message: this.$t('respondercomentario.erroenviar'),
          type: 'negative',
          position: 'top'
        })
      } finally {
        this.enviandoResposta = false
      }
    },
    saveContact (contact) {
      // console.log('Contato salvo:', contact)
      // Aqui você pode adicionar a lógica para salvar o contato
    },
    getMapThumbnail(body) {
      const [thumbnail] = body.split('|')
      return thumbnail
    },
    formatLocationAddress(body) {
      try {
        const locationData = typeof body === 'string' ? JSON.parse(body) : body
        return locationData.address || ''
      } catch (e) {
        return ''
      }
    },
    openGoogleMaps(body) {
      try {
        const locationData = typeof body === 'string' ? JSON.parse(body) : body
        if (locationData.latitude && locationData.longitude) {
          const mapsUrl = `https://www.google.com/maps?q=${locationData.latitude},${locationData.longitude}`
          window.open(mapsUrl, '_blank')
        }
      } catch (e) {
        console.error('Error parsing location data:', e)
      }
    },
    formatLocationName(body) {
      try {
        const locationData = typeof body === 'string' ? JSON.parse(body) : body
        return locationData.name || this.$t('mensagemchat.midia.localizacao')
      } catch (e) {
        return this.$t('mensagemchat.midia.localizacao')
      }
    },
    verificarEncaminharMensagem (mensagem) {
      const mensagens = [...this.mensagensParaEncaminhar]
      const msgIdx = mensagens.findIndex(m => m.id === mensagem.id)
      if (msgIdx !== -1) {
        mensagens.splice(msgIdx, 1)
      } else {
        if (this.mensagensParaEncaminhar.length > 9) {
          this.$notificarErro(this.$t('mensagemchat.mensagens.maxEncaminhar'))
          return
        }
        mensagens.push(mensagem)
      }
      this.$refs[`box-chat-message-${mensagem.id}`][0].value = !this.$refs[`box-chat-message-${mensagem.id}`][0].value
      this.$emit('update:mensagensParaEncaminhar', mensagens)
    },
    marcarMensagensParaEncaminhar (mensagem) {
      this.$emit('update:mensagensParaEncaminhar', [])
      this.$emit('update:ativarMultiEncaminhamento', !this.ativarMultiEncaminhamento)
      // this.verificarEncaminharMensagem(mensagem)
    },
    isPDF (url) {
      if (!url) return false
      const split = url.split('.')
      const ext = split[split.length - 1]
      return ext === 'pdf'
    },
    isGroupLabel (mensagem) {
      try {
        return this.ticketFocado.isGroup ? mensagem.contact.name : ''
      } catch (error) {
        return ''
      }
    },
    // cUrlMediaCors () {
    //   return this.urlMedia
    // },
    returnCardContato (str) {
      // return btoa(str)
      return Base64.encode(str)
    },
    isDesactivatDelete (msg) {
      // if (msg) {
      //   return (differenceInMinutes(new Date(), new Date(+msg.timestamp)) > 5)
      // }
      return false
    },
    async buscarImageCors (imageUrl) {
      this.loading = true
      try {
        const { data, headers } = await downloadImageCors.get(imageUrl, {
          responseType: 'blob'
        })
        const url = window.URL.createObjectURL(
          new Blob([data], { type: headers['content-type'] })
        )
        this.urlMedia = url
        this.abrirModalImagem = true
      } catch (error) {
        this.$notificarErro(this.$t('mensagemchat.erros.generico'), error)
      }
      this.loading = false
    },
    citarMensagem (mensagem) {
      this.$emit('update:replyingMessage', mensagem)
      this.$root.$emit('mensagem-chat:focar-input-mensagem', mensagem)
    },
    encaminharMensagem (mensagem) {
      this.$emit('mensagem-chat:encaminhar-mensagem', mensagem)
    },
    deletarMensagem (mensagem) {
      if (this.isDesactivatDelete(mensagem)) {
        this.$notificarErro(this.$t('mensagemchat.erros.deletarMensagem'))
      }
      // const diffHoursDate = differenceInHours(
      //   new Date(),
      //   parseJSON(mensagem.createdAt)
      // )
      // if (diffHoursDate > 2) {
      //   // throw new AppError("No delete message afeter 2h sended");
      // }
      const data = { ...mensagem }
      this.$q.dialog({
        title: this.$t('mensagemchat.confirmacoes.deletarMensagem.titulo'),
        message: this.$t('mensagemchat.confirmacoes.deletarMensagem.descricao'),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarMensagem(data)
          .then(res => {
            this.loading = false
            mensagem.isDeleted = true
          })
          .catch(error => {
            this.loading = false
            console.error(error)
            this.$notificarErro(this.$t('mensagemchat.erros.deletarMensagem'), error)
          })
      }).onCancel(() => {
      })
    },
    async abrirTicketPrivado(mensagem) {
      if (!mensagem.contact || !mensagem.contact.id) return

      try {
        this.contatoAtual = mensagem.contact

        const { data } = await ListarCanalUsuario('whatsapp')
        this.canaisUsuario = data

        if (this.canaisUsuario.length === 0) {
          this.$q.notify({
            message: this.$t('newticket.noChannelsAvailable'),
            type: 'negative',
            position: 'top'
          })
          return
        }

        this.canalSelecionado = this.canaisUsuario.length > 0 ? this.canaisUsuario[0].id : null
        this.filaSelecionada = this.cUserQueues.length > 0 ? this.cUserQueues[0].id : null

        this.modalSelecionarCanal = true
      } catch (error) {
        this.$notificarErro(this.$t('newticket.loadChannels'), error)
      }
    },
    async criarTicket() {
      if (!this.canalSelecionado || !this.filaSelecionada) {
        this.erro = this.$t('newticket.errorselecionar')
        return
      }

      this.erro = null
      this.loading = true

      try {
        const { data: ticket } = await CriarTicketNew({
          contactId: this.contatoAtual.id,
          isActiveDemand: true,
          channel: 'whatsapp',
          channelId: this.canalSelecionado,
          queueId: this.filaSelecionada,
          status: 'open'
        })

        this.ticketFocado = ticket
        this.modalSelecionarCanal = false

        await this.$store.commit('SET_HAS_MORE', true)
        await this.$store.dispatch('AbrirChatMensagens', ticket)

        this.$q.notify({
          message: this.$t('contacts.newticket.ServiceStarted', { name: ticket.contact.name, ticketid: ticket.id }),
          type: 'positive',
          position: 'top',
          progress: true,
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })

        this.$router.push({ name: 'chat', params: { ticketId: ticket.id } })
      } catch (error) {
        this.loading = false
        console.log('error', error)
        const errorMessage = error?.data?.message || this.$t('general.Anunknownerrorhasoccurred')

        if (error.status === 409 && errorMessage === this.$t('general.Aticketalreadyexists')) {
          const ticketAtual = error.data?.ticket
          this.abrirAtendimentoExistente(this.contatoAtual, ticketAtual)
        } else {
          if (error.status === 409) {
            this.$q.dialog({
              title: this.$t('general.Attention'),
              message: `${errorMessage}`,
              ok: {
                label: this.$t('general.close'),
                color: 'primary',
                push: true
              },
              persistent: true
            })
            this.$q.notify({
              message: errorMessage,
              type: 'negative',
              position: 'top',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          }
        }
      } finally {
        this.loading = false
        this.fecharModalCanal()
      }
    },
    fecharModalCanal() {
      this.modalSelecionarCanal = false
      this.canalSelecionado = null
      this.filaSelecionada = null
      this.contatoAtual = null
      this.erro = null
    },
    abrirAtendimentoExistente (contato, ticket) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('contacts.newticket.ongoingservice', { name: contato.name, ticketid: ticket.id }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(async () => {
        try {
          this.abrirChatContato(ticket)
        } catch (error) {
          this.$notificarErro(
            this.$t('contacts.newticket.tokenerror'),
            error
          )
        }
      })
    },
    focarMensagem (mensagem) {
      const id = `chat-message-${mensagem.id}`
      this.identificarMensagem = id
      this.$nextTick(() => {
        const elem = document.getElementById(id)
        elem.scrollIntoView()
      })
      setTimeout(() => {
        this.identificarMensagem = null
      }, 5000)
    }
  },
  mounted () {
    this.scrollToBottom()
    window.addEventListener('resize', this.onResize)
    // this.$refs.audioMessage.forEach(element => {
    //   element.playbackRate = 2
    // })
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.onResize)
  },
  destroyed() {}
}
</script>

<style lang="scss">
.frame-pdf {
  overflow: hidden;
}

.bot-message {
  display: flex;
  align-items: center;
  font-size: 12px;
  color: #666;
  margin-bottom: 4px;

  .bot-label {
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
}

.ticket-title {
  font-size: 1.5rem;
  font-weight: bold;
  color: #333;
  border-bottom: 2px solid #ccc;
  padding-bottom: 0.5rem;
  margin-bottom: 1rem;
}

.quoted-container {
  display: flex;
  align-items: center; /* Alinha no centro verticalmente */
  justify-content: flex-start; /* Alinha corretamente */
  max-width: 240px;
  max-height: 150px;
  padding: 8px; /* Reduz espaço em branco */
  background-color: rgba(0, 0, 0, 0.05); /* Para visualizar */
  border-radius: 8px;
}

.reaction-container {
  font-size: 0.75rem;
  color: #606060;
  margin-top: 8px;
  padding: 2px 4px;
  border-radius: 4px;
  background-color: #f0f0f0;
  display: inline-block;
}

.checkbox-encaminhar-right {
  right: -35px;
  z-index: 99999;
}

.forwarded-message {
  font-style: italic;
  color: #4a4a4a;
  font-size: 12px;
  margin-bottom: 5px;
  display: flex;
  align-items: center;
}

.icon-forward {
  margin-right: 5px;
  font-size: 14px;
  color: #4a4a4a;
}

.checkbox-encaminhar-left {
  left: -35px;
  z-index: 99999;
}

.emoji-picker {
  width: 100%;
}

.q-message-container.row.items-end.no-wrap {
  padding: 0 30px 0 0 !important;
}

.comment-message {
  padding: 8px;
}

.new-comment {
  font-weight: bold;
  margin-bottom: 4px;
}

.comment-body {
  color: #666;
}

.whatsapp-payment {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 12px;
  margin: 8px 0;
  background-color: #f8f9fa;
  font-family: Arial, sans-serif;
}

.payment-header h3 {
  margin-top: 0;
  margin-bottom: 12px;
  color: #25D366;
  font-size: 16px;
}

.payment-details {
  padding: 8px 0;
}

.payment-items {
  margin-bottom: 10px;
}

.payment-item, .payment-subtotal, .payment-total {
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}

.payment-total {
  border-top: 1px solid #e0e0e0;
  padding-top: 8px;
  margin-top: 8px;
}

.payment-method {
  background-color: #e8f5e9;
  padding: 8px;
  border-radius: 4px;
  margin: 10px 0;
}

.payment-reference {
  font-size: 0.8em;
  color: #666;
  margin-top: 8px;
}

.payment-note {
  font-style: italic;
  color: #757575;
  margin-top: 10px;
  font-size: 0.85em;
}

.whatsapp-event {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 12px;
  margin: 8px 0;
  background-color: #f8f9fa;
  font-family: Arial, sans-serif;
}

.event-canceled {
  background-color: #ffebee;
  border-color: #ffcdd2;
}

.event-header h3 {
  margin-top: 0;
  margin-bottom: 12px;
  color: #25D366;
  font-size: 16px;
}

.event-canceled .event-header h3 {
  color: #f44336;
}

.event-details {
  padding: 8px 0;
}

.event-name {
  font-size: 18px;
  margin-bottom: 8px;
}

.event-description {
  margin-bottom: 12px;
  line-height: 1.4;
}

.event-time {
  background-color: #e8f5e9;
  padding: 8px;
  border-radius: 4px;
  margin: 10px 0;
}

.event-canceled .event-time {
  background-color: #ffebee;
  text-decoration: line-through;
}

.event-guests-info {
  font-size: 0.9em;
  color: #666;
  margin-top: 8px;
}

.event-note {
  font-style: italic;
  color: #757575;
  margin-top: 10px;
  font-size: 0.85em;
}

.whatsapp-product {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 0;
  margin: 8px 0;
  background-color: #f8f9fa;
  font-family: Arial, sans-serif;
  overflow: hidden;
}

.product-header {
  padding: 10px;
  background-color: #f0f7f4;
  border-bottom: 1px solid #e0e0e0;
}

.product-header h3 {
  margin: 0;
  color: #25D366;
  font-size: 16px;
}

.product-business {
  font-size: 12px;
  color: #666;
  margin-top: 3px;
}

.product-content {
  display: flex;
  flex-direction: column;
}

.product-image {
  width: 100%;
  height: auto;
  overflow: hidden;
  background-color: #f0f0f0;
  display: flex;
  justify-content: center;
}

.product-image img {
  width: 100%;
  height: auto;
  object-fit: cover;
}

.product-details {
  padding: 12px;
}

.product-title {
  font-size: 16px;
  margin-bottom: 8px;
  line-height: 1.3;
}

.product-price {
  font-size: 18px;
  font-weight: bold;
  color: #25D366;
  margin-bottom: 8px;
}

.product-id {
  color: #999;
  font-size: 11px;
}

.product-footer {
  padding: 8px 12px;
  background-color: #f0f7f4;
  border-top: 1px solid #e0e0e0;
  font-style: italic;
  color: #757575;
  font-size: 0.85em;
  text-align: center;
}

.emoji-container {
  margin-top: 10px;
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 10px;
}

@media (max-width: 600px) {
  .emoji-container {
    max-height: 200px;
    overflow-y: auto;
  }
}

.social-comment.simple-comment {
  padding: 10px;
  border-radius: 8px;
  margin-bottom: 10px;
}

.instagram-comment {
  background-color: #f9f9f9;
  border-left: 3px solid #E1306C; /* Cor do Instagram */
}

.facebook-comment {
  background-color: #f0f2f5;
  border-left: 3px solid #1877F2; /* Cor do Facebook */
}

.platform-icon {
  margin-bottom: 5px;
}

.instagram-comment .platform-icon {
  color: #E1306C;
}

.facebook-comment .platform-icon {
  color: #1877F2;
}

.comment-author {
  margin-bottom: 5px;
  color: #262626;
}

.comment-text {
  margin-bottom: 8px;
}

.publication-link {
  font-size: 12px;
  text-decoration: none;
}

.instagram-comment .publication-link {
  color: #0095f6;
}

.facebook-comment .publication-link {
  color: #1877F2;
}

.publication-link:hover {
  text-decoration: underline;
}

/* Versão para tema escuro */
.body--dark .social-comment.simple-comment {
  background-color: #262626;
}

.body--dark .instagram-comment {
  border-left: 3px solid #E1306C;
  background-color: #1e1e1e;
}

.body--dark .facebook-comment {
  border-left: 3px solid #1877F2;
  background-color: #1e1e1e;
}

.body--dark .comment-author {
  color: #f9f9f9;
}

.whatsapp-template {
  border: 1px solid #e5e5e5;
  border-radius: 8px;
  overflow: hidden;
  margin: 10px 0;
  background-color: #fff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.template-header {
  background-color: #f5f5f5;
  padding: 8px 12px;
  border-bottom: 1px solid #e5e5e5;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.template-badge {
  background-color: #25D366;
  color: white;
  border-radius: 12px;
  padding: 2px 8px;
  font-size: 12px;
  font-weight: bold;
}

.template-name {
  font-weight: bold;
  color: #444;
}

.template-content {
  padding: 12px;
}

.template-component {
  margin-bottom: 12px;
}

.template-component:last-child {
  margin-bottom: 0;
}

.header-text, .body-text {
  font-size: 14px;
  line-height: 1.5;
  margin: 6px 0;
}

.body-parameters {
  background-color: #f9f9f9;
  border-radius: 6px;
  padding: 8px 12px;
}

.body-parameter {
  margin: 6px 0;
  display: flex;
  flex-wrap: wrap;
}

.parameter-name {
  font-weight: bold;
  margin-right: 8px;
  color: #444;
}

.parameter-value {
  color: #25D366;
}

.whatsapp-button {
  display: inline-block;
  margin: 5px 0;
  padding: 8px 16px;
  background-color: #0084FF;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.whatsapp-button:hover {
  background-color: #0066CC;
}

.button-parameters {
  margin-top: 5px;
  font-size: 12px;
  color: #666;
}

.location-info {
  max-width: 200px;
  text-align: left;
  overflow: hidden;
  text-overflow: ellipsis;
}

</style>
