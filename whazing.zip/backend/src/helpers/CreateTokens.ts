// Original: CreateTokens.js
// Deobfuscated, converted to TS, and translated

"use strict";

import jwt from "jsonwebtoken";
import authConfig from "../config/auth"; // Asumiendo exportación predeterminada

// Interfaz para el payload del token de acceso
interface AccessTokenPayload {
  username: string;
  tenantId: number | string;
  loginDate: string; // La fecha se convierte a string ISO
  profile: string; // Asumiendo que profile es un string (ej: 'admin', 'user')
  id: number | string;
}

// Interfaz para el payload del token de refresco
interface RefreshTokenPayload {
  id: number | string;
  tokenVersion: number; // Asumiendo que tokenVersion es un número
  tenantId: number | string;
  loginDate: string;
}

// Interfaz para los datos del usuario (parámetros de entrada)
interface UserData {
  username: string;
  tenantId: number | string;
  lastLogin: Date; // Usar tipo Date
  profile: string;
  id: number | string;
  tokenVersion: number;
}

// Crea un token de acceso
export const createAccessToken = (user: UserData): string => {
  const { secret, expiresIn } = authConfig;

  const payload: AccessTokenPayload = {
    username: user.username,
    tenantId: user.tenantId,
    loginDate: user.lastLogin.toISOString(),
    profile: user.profile,
    id: user.id
  };

  return jwt.sign(payload, secret, { expiresIn });
};

// Crea un token de refresco
export const createRefreshToken = (user: UserData): string => {
  const { refreshSecret, refreshExpiresIn } = authConfig;

  const payload: RefreshTokenPayload = {
    id: user.id,
    tokenVersion: user.tokenVersion,
    tenantId: user.tenantId,
    loginDate: user.lastLogin.toISOString()
  };

  return jwt.sign(payload, refreshSecret, { expiresIn: refreshExpiresIn });
};
