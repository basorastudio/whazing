import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import Campaign from "./Campaign";
import Contact from "./Contact";
import Message from "./Message"; // Assuming relation to a specific sent message

// @Table decorator was missing, adding it.
@Table
class CampaignContact extends Model<CampaignContact> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Default(0)
  @Column
  ack: number;

  @Column(DataType.TEXT) // Use TEXT for potentially long messages
  body: string;

  @Column
  mediaName: string;

  @Column
  messageRandom: string; // 'messageRandom' resolved

  @AllowNull(true)
  @Default(null)
  @Column
  jobId: string; // Assuming string for Job ID

  @ForeignKey(() => Message) // Assuming relation to sent message
  @Column
  messageId: string; // Assuming string message ID

  @Column
  messageIdAPI: string; // 'messageId' might have resolved to this, check correctness

  @BelongsTo(() => Message, "messageId") // Specify FK if ambiguous
  message: Message;

  @ForeignKey(() => Campaign)
  @Column
  campaignId: number; // Assuming number campaign ID

  @BelongsTo(() => Campaign, "campaignId") // Specify FK
  campaign: Campaign;

  @ForeignKey(() => Contact)
  @Column
  contactId: number;

  @BelongsTo(() => Contact, "contactId") // Specify FK
  contact: Contact;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default CampaignContact;