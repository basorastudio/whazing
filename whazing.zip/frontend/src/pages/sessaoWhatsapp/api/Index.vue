<template>
  <div v-if="userProfile === 'admin'">
    <q-card class="container-border container-rounded-10 q-ma-lg">
      <q-card-section>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="mdi-call-split"></q-icon>
            Configuraciones API
          </h2>

          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
            icon="eva-plus-outline"
            label="Añadir"
            style="margin: 2px;"
            @click="apiEdicao = {}; modalApi = !modalApi;" />
        </div>
      </q-card-section>
      <q-card-section class="scroll"
        style="height: calc(100vh - 200px)">
        <q-item v-for="api in apis"
          :key="api.token"
          class="q-my-md container-rounded-10 container-border">

          <q-item-section top>
            <q-item-label class="text-bold text-h6 q-my-sm">
              Nombre: {{ api.name }}
              <div class="text-grey-8 q-gutter-xs float-right">
                <q-btn
                  class="color-light1"
                  :class="$q.dark.isActive ? ('color-dark1') : ''"
                  size="12px"
                  flat
                  dense
                  round
                  icon="mdi-content-copy"
                  @click="copy(api.token)">
                  <q-tooltip>
                    Copiar token
                  </q-tooltip>
                </q-btn>
                <q-btn
                  class="color-light1"
                  :class="$q.dark.isActive ? ('color-dark1') : ''"
                  size="12px"
                  flat
                  dense
                  round
                  icon="eva-edit-outline"
                  @click="editarAPI(api)">
                  <q-tooltip>
                    Editar Configuración
                  </q-tooltip>
                </q-btn>
                <q-btn
                  class="color-light1"
                  :class="$q.dark.isActive ? ('color-dark1') : ''"
                  size="12px"
                  flat
                  dense
                  round
                  icon="mdi-autorenew"
                  @click="gerarNovoToken(api)">
                  <q-tooltip>
                    Generar nuevo Token
                  </q-tooltip>
                </q-btn>

                <q-btn
                  class="color-light1"
                  :class="$q.dark.isActive ? ('color-dark1') : ''"
                  size="12px"
                  flat
                  dense
                  round
                  icon="eva-trash-outline"
                  @click="deletarApi(api)">
                  <q-tooltip>
                    Eliminar Configuración
                  </q-tooltip>
                </q-btn>
              </div>
            </q-item-label>
            <q-separator/>
            <q-item-label lines="4"
              style="word-break: break-all; padding-top: 10px">
              <p class="text-weight-medium text-nowrap q-pr-md blur-effect">
                <span class="text-bold">Url:
                </span>
                {{ montarUrlIntegração(api.id) }}
              </p>
            </q-item-label>
            <q-item-label style="word-break: break-all;">
              <p class="text-weight-medium text-nowrap q-pr-md blur-effect">
                <span class="text-bold">Token:
                </span>
                {{ api.token }}
              </p>
            </q-item-label>
            <q-item-label lines="1"
              class="q-mt-xs text-body2 text-weight-bold text-primary text-uppercase">
            </q-item-label>
            <q-item-label style="word-break: break-all;">
          <q-btn
            class="generate-button btn-rounded-50"
            :class="{'generate-button-dark' : $q.dark.isActive}"
            label="POSTMAN"
            style="margin: 2px;"
            @click="download" />
              <p class="text-weight-medium text-nowrap q-pr-md">
                <span class="text-bold">Descargue el archivo de postman verifique uso en el sitio
                </span>
                <a href="https://www.postman.com/" target="_blank">https://www.postman.com/</a>
              </p>
            </q-item-label>
            <q-item-label
              lines="1"
              class="q-mt-xs text-body2 text-weight-bold text-primary text-uppercase"
            >
            </q-item-label>
          </q-item-section>
        </q-item>

      </q-card-section>
    </q-card>

    <ModalApi :modalApi.sync="modalApi"
      :apiEdicao.sync="apiEdicao"
      @modal-api:criada="apiCriada"
      @modal-api:editada="apiEditada" />

    <q-dialog v-model="confirmDialog">
      <q-card>
        <q-card-section>
          <div class="text-h6">Confirmar Acción</div>
        </q-card-section>

        <q-card-section>
          {{ confirmMessage }}
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="Cancelar" color="primary" v-close-popup />
          <q-btn
            flat
            label="Confirmar"
            color="primary"
            @click="confirmarAccion"
            v-close-popup
          />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <q-card class="container-border container-rounded-10 q-ma-lg">
      <q-card-section>
        <div class="text-h6">Administración del Sistema</div>
      </q-card-section>

      <q-card-section>
        <q-tabs
          v-model="tab"
          class="text-primary"
          active-color="primary"
          indicator-color="primary"
          align="left"
          narrow-indicator
        >
          <q-tab name="tokens" label="Gestión de Tokens" />
          <q-tab name="endpoints" label="Documentación API" />
        </q-tabs>

        <q-tab-panels v-model="tab" animated>
          <q-tab-panel name="tokens">
            <div class="row q-col-gutter-md">
              <div class="col-12">
                <q-btn
                  color="primary"
                  label="Generar Nuevo Token"
                  @click="generarNuevoToken"
                  :loading="generandoToken"
                />
              </div>

              <div class="col-12" v-if="tokenActual">
                <q-card flat bordered>
                  <q-card-section>
                    <div class="text-subtitle2">Token Actual</div>
                    <q-input
                      v-model="tokenActual"
                      type="textarea"
                      readonly
                      filled
                      autogrow
                    />
                    <div class="row q-gutter-sm q-mt-sm">
                      <q-btn
                        flat
                        color="primary"
                        icon="content_copy"
                        label="Copiar"
                        @click="copiarToken"
                      />
                      <q-btn
                        flat
                        color="primary"
                        icon="refresh"
                        label="Renovar"
                        @click="renovarToken"
                        :loading="renovandoToken"
                      />
                    </div>
                  </q-card-section>
                </q-card>
              </div>
            </div>
          </q-tab-panel>

          <q-tab-panel name="endpoints">
            <div class="text-subtitle1 q-mb-md">Endpoints de Administración</div>
            <q-list bordered separator>
              <q-expansion-item
                group="endpoints"
                icon="post_add"
                label="Generar Token de Administrador"
                caption="POST /admin/token"
                header-class="text-primary"
              >
                <q-card>
                  <q-card-section>
                    <div class="text-subtitle2">Descripción</div>
                    <p>Genera un nuevo token de administrador para acceder a las APIs del sistema.</p>
                    
                    <div class="text-subtitle2">Respuesta</div>
                    <q-markup-table flat bordered>
                      <thead>
                        <tr>
                          <th class="text-left">Campo</th>
                          <th class="text-left">Tipo</th>
                          <th class="text-left">Descripción</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>token</td>
                          <td>string</td>
                          <td>Token de acceso generado</td>
                        </tr>
                      </tbody>
                    </q-markup-table>
                  </q-card-section>
                </q-card>
              </q-expansion-item>

              <q-expansion-item
                group="endpoints"
                icon="autorenew"
                label="Renovar Token de Administrador"
                caption="POST /admin/token/renew"
                header-class="text-primary"
              >
                <q-card>
                  <q-card-section>
                    <div class="text-subtitle2">Descripción</div>
                    <p>Renueva un token de administrador existente.</p>

                    <div class="text-subtitle2">Parámetros</div>
                    <q-markup-table flat bordered>
                      <thead>
                        <tr>
                          <th class="text-left">Campo</th>
                          <th class="text-left">Tipo</th>
                          <th class="text-left">Descripción</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>token</td>
                          <td>string</td>
                          <td>Token actual a renovar</td>
                        </tr>
                      </tbody>
                    </q-markup-table>

                    <div class="text-subtitle2 q-mt-md">Respuesta</div>
                    <q-markup-table flat bordered>
                      <thead>
                        <tr>
                          <th class="text-left">Campo</th>
                          <th class="text-left">Tipo</th>
                          <th class="text-left">Descripción</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>token</td>
                          <td>string</td>
                          <td>Nuevo token de acceso</td>
                        </tr>
                      </tbody>
                    </q-markup-table>
                  </q-card-section>
                </q-card>
              </q-expansion-item>
            </q-list>
          </q-tab-panel>
        </q-tab-panels>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
import { ListarAPIs, ApagarAPI, NovoTokenAPI } from 'src/service/api'
import { generarTokenAdmin, renovarTokenAdmin } from 'src/service/adminApi'
import { copyToClipboard, Notify } from 'quasar'
import ModalApi from './ModalApi'
export default {
  name: 'APIs',
  components: {
    ModalApi
  },
  data () {
    return {
      userProfile: 'user',
      apiEdicao: {},
      modalApi: false,
      apis: [],
      tab: 'tokens',
      tokenActual: null,
      generandoToken: false,
      renovandoToken: false,
      confirmDialog: false,
      confirmMessage: '',
      accionPendiente: null,
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'name', label: 'Nombre', field: 'name', align: 'left' },
        { name: 'token', label: 'Token', classes: 'ellipsis', style: 'max-width: 400px', field: 'token', align: 'left' },
        { name: 'isActive', label: 'Activo', field: 'isActive', align: 'center' },
        { name: 'acoes', label: 'Acciones', field: 'acoes', align: 'center' }
      ]
    }
  },
  computed: {
    cBaseUrlIntegração () {
      return `${process.env.URL_API}/v1/api/external`
    }
  },
  methods: {
    download () {
      const link = document.createElement('a')
      link.href = 'api-multiagente.json'
      link.download = 'api-multiagente.json'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    },
    montarUrlIntegração (id) {
      return `${this.cBaseUrlIntegração}/${id}`
    },
    copy (text) {
      copyToClipboard(text)
        .then(this.$notificarSucesso('Token copiado!'))
        .catch()
    },
    async listarAPIs () {
      const { data } = await ListarAPIs()
      this.apis = data.apis
    },
    async generarNuevoToken () {
      this.confirmMessage = '¿Está seguro que desea generar un nuevo token? El token anterior dejará de funcionar.'
      this.accionPendiente = 'generar'
      this.confirmDialog = true
    },
    async renovarToken () {
      this.confirmMessage = '¿Está seguro que desea renovar el token actual?'
      this.accionPendiente = 'renovar'
      this.confirmDialog = true
    },
    async confirmarAccion () {
      if (this.accionPendiente === 'generar') {
        await this.ejecutarGenerarToken()
      } else if (this.accionPendiente === 'renovar') {
        await this.ejecutarRenovarToken()
      }
      this.accionPendiente = null
    },
    async ejecutarGenerarToken () {
      try {
        this.generandoToken = true
        const response = await generarTokenAdmin()
        this.tokenActual = response.data.token
        Notify.create({
          type: 'positive',
          message: 'Token generado exitosamente'
        })
      } catch (error) {
        console.error('Error al generar token:', error)
        Notify.create({
          type: 'negative',
          message: 'Error al generar el token'
        })
      } finally {
        this.generandoToken = false
      }
    },
    async ejecutarRenovarToken () {
      if (!this.tokenActual) {
        Notify.create({
          type: 'warning',
          message: 'No hay token para renovar'
        })
        return
      }

      try {
        this.renovandoToken = true
        const response = await renovarTokenAdmin({ token: this.tokenActual })
        this.tokenActual = response.data.token
        Notify.create({
          type: 'positive',
          message: 'Token renovado exitosamente'
        })
      } catch (error) {
        console.error('Error al renovar token:', error)
        Notify.create({
          type: 'negative',
          message: 'Error al renovar el token'
        })
      } finally {
        this.renovandoToken = false
      }
    },
    copiarToken () {
      if (this.tokenActual) {
        navigator.clipboard.writeText(this.tokenActual)
        Notify.create({
          type: 'positive',
          message: 'Token copiado al portapapeles'
        })
      }
    },
    apiCriada (api) {
      const newApis = [...this.apis]
      newApis.push(api)
      this.apis = [...newApis]
    },
    apiEditada (api) {
      const newApis = [...this.apis]
      const idx = newApis.findIndex(f => f.id === api.id)
      if (idx > -1) {
        newApis[idx] = api
      }
      this.apis = [...newApis]
    },
    editarAPI (api) {
      this.apiEdicao = { ...api }
      this.modalApi = true
    },
    gerarNovoToken (api) {
      this.$q.dialog({
        title: '¡Atención!',
        message: `¿Realmente desea generar un nuevo token para "${api.name}"?
        Recuerde que las integraciones que utilizan el actual dejarán de funcionar
        hasta que actualice el token donde sea necesario.`,
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(async () => {
        try {
          const { data } = await NovoTokenAPI(api)
          this.apiEditada(data)
          this.$notificarSucesso('¡Token actualizado!')
        } catch (error) {
          this.$notificarErro(
            'No fue posible actualizar el token',
            error
          )
        }
      })
    },
    deletarApi (api) {
      this.$q.dialog({
        title: '¡Atención!',
        message: `¿Realmente desea eliminar "${api.name}"?`,
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        ApagarAPI(api)
          .then(res => {
            let newApis = [...this.apis]
            newApis = newApis.filter(a => a.id !== api.id)
            this.apis = [...newApis]
            this.$notificarSucesso(`¡${api.name} eliminada!`)
          })
          .catch(error => this.$notificarErro(`No fue posible eliminar ${api.name}`, error))
        this.loading = false
      })
    }

  },
  mounted () {
    this.userProfile = localStorage.getItem('profile')
    this.listarAPIs()
  }
}
</script>

<style lang="scss" scoped>
  .item-label {
    border-bottom: 1px solid #ccc; // Color del borde
    padding-bottom: 10px; // Espaciado debajo del contenido
    margin-bottom: 10px; // Espaciado debajo del borde

    &:last-child {
      border-bottom: none; // Elimina el borde del último elemento
    }
  }
  .blur-effect {
    filter: blur(0px)
  }
</style>
