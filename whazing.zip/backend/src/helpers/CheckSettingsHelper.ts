// Original: CheckSettingsHelper.js
// Deobfuscated, converted to TS, and translated

"use strict";

import Setting from "../models/Setting";
import AppError from "../errors/AppError";
import NodeCache from "node-cache"; // Importar directamente

// Opciones para la caché
const cacheOptions: NodeCache.Options = {
  stdTTL: 3600 // Tiempo de vida estándar en segundos (ej: 1 hora)
};

const cache = new NodeCache(cacheOptions);

const CheckSettingsHelper = async (
  key: string,
  defaultValue: string | null = null,
  tenantId?: number | string // Hacer tenantId opcional si no siempre se pasa
): Promise<string | null> => {
  const cacheKey = `setting_${tenantId || "default"}_${key}`; // Incluir tenantId en la clave si existe
  const cachedValue = cache.get<string>(cacheKey);

  // Si el valor está en caché, retornarlo
  if (cachedValue !== undefined) {
    return cachedValue;
  }

  // Si no está en caché, buscar en la base de datos
  const whereCondition: any = { key };
  if (tenantId) {
    whereCondition.tenantId = tenantId;
  } else {
    // Si no hay tenantId, podríamos buscar una configuración global (ej: tenantId=1 o null)
    // Ajusta esto según tu lógica para configuraciones globales
    // whereCondition.tenantId = 1; // Ejemplo
  }

  const setting = await Setting.findOne({ where: whereCondition });

  // Si no se encuentra y no hay valor por defecto, lanzar error
  if (!setting && !defaultValue) {
    // Traducido: ERR_NO_SETTING_FOUND - Error: Configuración no encontrada
    throw new AppError("ERR_NO_SETTING_FOUND", 404);
  }

  // Determinar el valor a retornar y cachear
  const valueToCache = setting?.value || defaultValue;

  // Cachear el valor si se encontró o si hay un valor por defecto
  if (valueToCache) {
    cache.set(cacheKey, valueToCache);
  }

  return valueToCache;
};

export default CheckSettingsHelper;
