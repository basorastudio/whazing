// --- START OF FILE 20211227160721-add-colum-isActive-table-whatsapps.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

// Define la interfaz para el objeto de migración si no existe una global
interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Whatsapps";
    const columnName = "isActive";
    const attributes = {
      type: DataTypes.BOOLEAN,
      allowNull: false, // Changed ![] to false
      defaultValue: true // Changed !![] to true
    };
    await Promise.all([
      queryInterface.addColumn(tableName, columnName, attributes)
    ]);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Whatsapps";
    const columnName = "isActive";
    await Promise.all([queryInterface.removeColumn(tableName, columnName)]);
  }
};

export default migration;

// --- END OF FILE 20211227160721-add-colum-isActive-table-whatsapps.ts ---
