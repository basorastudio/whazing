import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  HasMany,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AutoIncrement
} from "sequelize-typescript";
import Tenant from "./Tenant";
import User from "./User";
import QueueIntegrations from "./QueueIntegrations";
import Message from "./Message"; // Added for HasMany relation

@Table
class Queue extends Model<Queue> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  name: string; // Assuming 'queue' resolved to 'name'

  @Default(true)
  @Column
  isActive: boolean;

  @Column
  color: string;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @ForeignKey(() => QueueIntegrations)
  @Column
  queueIntegrationId: number; // Assuming 'queueIntegrations' resolved to this FK

  @BelongsTo(() => QueueIntegrations)
  queueIntegrations: QueueIntegrations;

  @HasMany(() => Message, 'IdQueue') // Specify FK if it's non-standard
  stepsReplyMessages: Message[]; // Renamed 'stepsReply' relation for clarity

}

export default Queue;