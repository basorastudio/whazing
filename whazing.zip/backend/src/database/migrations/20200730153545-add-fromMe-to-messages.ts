import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna fromMe a la tabla Messages
    return queryInterface.addColumn("Messages", "fromMe", {
      // Nombre de columna preservado
      type: DataTypes.BOOLEAN,
      allowNull: false, // O true si puede ser nulo inicialmente
      defaultValue: false
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna fromMe
    return queryInterface.removeColumn("Messages", "fromMe");
  }
};
