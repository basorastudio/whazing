import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add 'integrationId' foreign key to 'Queues' table
    await queryInterface.addColumn(
      "Queues", // Table name
      "integrationId", // New column name
      {
        type: DataTypes.INTEGER,
        references: {
          model: "QueueIntegrations", // References QueueIntegrations table
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL", // Allow Queue to exist if Integration is deleted
        allowNull: true, // Allow null
        defaultValue: null
      }
    );

    // Add 'integrationId' foreign key to 'Whatsapps' table (Original code added to both)
    await queryInterface.addColumn(
      "Whatsapps", // Table name
      "integrationId", // New column name
      {
        type: DataTypes.INTEGER,
        references: {
          model: "QueueIntegrations", // References QueueIntegrations table
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL", // Allow Whatsapp connection to exist if Integration is deleted
        allowNull: true, // Allow null
        defaultValue: null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove 'integrationId' from both tables
    await queryInterface.removeColumn("Whatsapps", "integrationId");
    await queryInterface.removeColumn("Queues", "integrationId");
  }
};

export = migration;
