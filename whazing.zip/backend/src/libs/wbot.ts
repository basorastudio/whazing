import * as Sentry from '@sentry/node';
import * as baileys from '@whiskeysockets/baileys';
import NodeCache from 'node-cache';
import { differenceInSeconds, parseISO } from 'date-fns';
import moment from 'moment';

import Whatsapp from '../../models/Whatsapp'; // Adjust path as needed
import Message from '../../models/Message'; // Adjust path as needed
import { logger } from '../../utils/logger'; // Adjust path as needed
import { useMultiFileAuthState } from '../../helpers/authState'; // Adjust path as needed
import AppError from '../../errors/AppError'; // Adjust path as needed
import { getIO } from '../../libs/socket'; // Adjust path as needed
import { StartWhatsAppSession } from '../../services/WbotServices/StartWhatsAppSession'; // Adjust path as needed
import DeleteBaileysService from '../../services/BaileysServices/DeleteBaileysService'; // Adjust path as needed
import { cacheLayer } from '../../helpers/cache'; // Adjust path as needed
import DeleteBaileysKeysService from '../../services/BaileysServices/DeleteBaileysKeysService'; // Adjust path as needed
import { SocksProxyAgent } from 'socks-proxy-agent';
import { VerifyContactBaileys } from '../../services/WbotServices/helpers/VerifyContactBaileys'; // Adjust path as needed
import { IsValidMsg } from '../../services/WbotServices/helpers/IsValidMsg'; // Adjust path as needed
import { addLogs } from '../../helpers/addLogs'; // Adjust path as needed
import ImportWhatsAppMessageService from '../../services/MessageServices/ImportWhatsAppMessageService'; // Adjust path as needed

// Define types/interfaces
type Session = baileys.WASocket & {
    id?: number;
    userDevicesCache?: NodeCache; // Add specific properties if needed
    groupCache?: NodeCache;
    msgRetryCounterCache?: NodeCache;
    shouldSyncHistoryMessage?: (msg: baileys.proto.IHistorySyncNotification) => boolean;
    markOnlineOnConnect?: boolean;
    generateHighQualityLinkPreview?: boolean;
    // Add other custom properties attached to the socket instance
};

interface ExtendedWAMessage extends baileys.proto.IWebMessageInfo {
    session?: string; // Session name or ID
}

// Sessions array to hold active connections
const sessions: Session[] = [];

// Cache for message retries and potentially other data
const msgRetryCounterCacheOptions = {
    stdTTL: (Number(process.env.CACHE_MSG_RETRY_COUNTER_TTL) || 60) * 60, // Default 1 hour
    checkperiod: Number(process.env.CACHE_MSG_RETRY_COUNTER_CHECK_PERIOD) || 60 * 60, // Default 1 hour
    useClones: false,
};
const msgRetryCounterCache = new NodeCache(msgRetryCounterCacheOptions);

// Map to track QR code generation retries
const retriesQrCodeMap = new Map<number, number>(); // Map whatsappId to retry count

/**
 * Retrieves the WhatsApp bot instance for a given ID.
 * @param whatsappId - The ID of the WhatsApp connection.
 * @returns The WASocket instance or undefined if not found.
 */
export const getWbot = (whatsappId: number): Session | undefined => {
    const sessionIndex = sessions.findIndex(s => s.id === whatsappId);
    if (sessionIndex === -1) {
        throw new AppError('ERR_WAPP_NOT_INITIALIZED');
    }
    return sessions[sessionIndex];
};

/**
 * Restarts a specific WhatsApp bot instance.
 * Deletes existing session files and re-initializes.
 * @param whatsappId - The ID of the WhatsApp connection to restart.
 * @param companyId - The tenant/company ID associated with the connection.
 */
export const restartWbot = async (whatsappId: number, companyId: number | string): Promise<void> => {
    logger.info(`Restarting Wbot session ${whatsappId} for tenant ${companyId}`);
    try {
        // Find and close existing session if it exists
        const sessionIndex = sessions.findIndex(s => s.id === whatsappId);
        if (sessionIndex !== -1) {
            try {
                sessions[sessionIndex].ws?.close(); // Gracefully close WebSocket
                sessions[sessionIndex].ev.removeAllListeners(); // Remove all event listeners
                logger.info(`Existing Wbot session ${whatsappId} WS closed and listeners removed.`);
            } catch (closeError) {
                logger.error(`Error closing existing session ${whatsappId}:`, closeError);
            }
            sessions.splice(sessionIndex, 1); // Remove from active sessions
        }

        // Clean up Baileys keys and cache
        await DeleteBaileysKeysService(whatsappId.toString());
        await cacheLayer.delFromPattern(`contacts:${whatsappId}:*`); // Clear contacts cache
        await cacheLayer.delFromPattern(`messages:${whatsappId}:*`); // Clear messages cache

        // Delay before re-initializing
        const delay = Number(process.env.DELAY_BEFORE_RESTART || 2000); // Default 2 seconds
        logger.info(`Waiting ${delay}ms before re-initializing session ${whatsappId}`);
        await new Promise(resolve => setTimeout(resolve, delay));

        logger.info(`Re-initializing Wbot session ${whatsappId}`);
        await exports.initWASocket(whatsappId); // Call initWASocket again

    } catch (error) {
        logger.error(`Error restarting Wbot session ${whatsappId}:`, error);
        // Optionally re-throw or handle differently
    }
};


/**
 * Removes a WhatsApp bot instance, cleans up session files, and notifies via Socket.IO.
 * @param whatsappId - The ID of the WhatsApp connection to remove.
 * @param isLogout - Whether the removal is due to a logout event (affects status update).
 */
export const removeWbot = async (whatsappId: number, isLogout = false): Promise<void> => {
    try {
        const sessionIndex = sessions.findIndex(s => s.id === whatsappId);
        if (sessionIndex !== -1) {
            const session = sessions[sessionIndex];

            if (isLogout) {
                // Attempt graceful logout if requested (might not always work)
                try {
                    await session.logout();
                    logger.info(`Wbot session ${whatsappId} logged out.`);
                } catch (logoutError) {
                    logger.error(`Error logging out Wbot session ${whatsappId}:`, logoutError);
                }
            }

            // Close WebSocket connection forcefully if needed
             if (session.ws?.readyState === WebSocket.OPEN) { // Check if ws exists and is open
                 try {
                      session.ws.close();
                      logger.info(`Wbot session ${whatsappId} WebSocket connection closed.`);
                 } catch (wsError) {
                      logger.error(`Error closing WebSocket for session ${whatsappId}:`, wsError);
                 }
             }


            session.ev.removeAllListeners(); // Remove listeners to prevent memory leaks
            sessions.splice(sessionIndex, 1); // Remove from active sessions
            logger.info(`Wbot session ${whatsappId} removed from active sessions.`);

            // Update database status to DISCONNECTED (unless it was a logout)
            const whatsapp = await Whatsapp.findByPk(whatsappId);
            if (whatsapp) {
                 const newStatus = isLogout ? 'LOGGEDOUT' : 'DISCONNECTED';
                 await whatsapp.update({ status: newStatus, session: '', qrcode: '' });
                 logger.info(`Wbot session ${whatsappId} status updated to ${newStatus} in database.`);

                 // Notify frontend via Socket.IO
                 const io = getIO();
                 io.to(whatsapp.tenantId.toString()).emit(`tenant-${whatsapp.tenantId}-whatsappSession`, {
                     action: 'update',
                     session: whatsapp
                 });
                 // Also notify the specific session room if needed
                 io.to(`whatsapp-${whatsappId}`).emit(`whatsapp-${whatsappId}-logout`);
            }

             // Clean up Baileys keys and cache regardless of logout status
             await DeleteBaileysKeysService(whatsappId.toString());
             await cacheLayer.delFromPattern(`contacts:${whatsappId}:*`);
             await cacheLayer.delFromPattern(`messages:${whatsappId}:*`);
             logger.info(`Baileys keys and cache cleared for session ${whatsappId}`);


        } else {
             logger.warn(`Attempted to remove non-existent Wbot session: ${whatsappId}`);
              // Still try to clean up database and keys if session object missing but DB record might exist
              await DeleteBaileysKeysService(whatsappId.toString());
              await cacheLayer.delFromPattern(`contacts:${whatsappId}:*`);
              await cacheLayer.delFromPattern(`messages:${whatsappId}:*`);
               const whatsapp = await Whatsapp.findByPk(whatsappId);
               if (whatsapp && whatsapp.status !== 'DISCONNECTED' && whatsapp.status !== 'LOGGEDOUT') {
                    await whatsapp.update({ status: 'DISCONNECTED', session: '', qrcode: '' });
                    logger.info(`Wbot session ${whatsappId} status forcibly set to DISCONNECTED in database.`);
                     const io = getIO();
                     io.to(whatsapp.tenantId.toString()).emit(`tenant-${whatsapp.tenantId}-whatsappSession`, {
                         action: 'update',
                         session: whatsapp
                     });
               }
        }
    } catch (err) {
        logger.error(`Error removing Wbot session ${whatsappId}: ${err}`);
    }
};
exports.removeWbot = removeWbot;


// Public session cache (consider if this is needed or if 'sessions' array suffices)
exports.sessions = {}; // Avoid direct export if 'sessions' array is the source of truth


// Default browser description for Baileys
const waDefaultVersion: [number, number, number] = [2, 2413, 1]; // Example version


/**
 * Fetches the current recommended WhatsApp Web version from the official source.
 * @returns Promise resolving with the version array (e.g., [2, 2413, 1]).
 */
const getProjectWAVersion = async (): Promise<[number, number, number]> => {
    const url = 'https://raw.githubusercontent.com/wppconnect-team/wa-version/main/waversion.json'; // URL for version info
    try {
        // Use axios or fetch for the request
        // const response = await axios.get(url);
        // return response.data.current_version; // Adjust based on actual JSON structure
        const response = await fetch(url);
        if (!response.ok) {
             throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        // Assuming the JSON looks like { "current_version": [2, 2413, 1] }
        if (Array.isArray(data.current_version) && data.current_version.length === 3) {
             logger.info(`Fetched WA version: ${data.current_version.join('.')}`);
             return data.current_version as [number, number, number];
        } else {
            throw new Error('Invalid version format received');
        }

    } catch (err) {
        logger.error('Error retrieving WA version:', err);
        // Fallback to default version on error
        logger.warn(`Using default WA version: ${waDefaultVersion.join('.')}`);
        return waDefaultVersion;
    }
};

/**
 * Compares two version arrays.
 * @param version1 - First version array (e.g., [2, 2413, 1]).
 * @param version2 - Second version array.
 * @returns The greater version array.
 */
function getGreaterVersion(version1: [number, number, number], version2: [number, number, number]): [number, number, number] {
    for (let i = 0; i < Math.max(version1.length, version2.length); i++) {
        const v1Part = version1[i] || 0;
        const v2Part = version2[i] || 0;
        if (v1Part > v2Part) return version1;
        if (v1Part < v2Part) return version2;
    }
    return version1; // Return first if equal
}

// Message Cache (consider if still needed with Baileys internal caching)
const msgCacheOptions = {
    stdTTL: Number(process.env.CACHE_MSG_TTL) || 60, // Default 60 seconds
    checkperiod: Number(process.env.CACHE_MSG_CHECK_PERIOD) || 120, // Default 120 seconds
    useClones: false
};
const msgCache = new NodeCache(msgCacheOptions);

// Export msg cache functions (consider simplifying or removing if Baileys handles it)
exports.msg = msg;
function msg() {
    return {
        /** Get message from cache or database */
        get: async (msgData: { id?: string; remoteJid?: string }): Promise<baileys.proto.IWebMessageInfo | undefined> => {
            const { id } = msgData;
            if (!id) return undefined;

            const cachedMsg = msgCache.get<string>(id);
            if (cachedMsg) {
                try {
                    const message = JSON.parse(cachedMsg);
                    // console.log("getMessage from cacheLayer", message?.key?.id, message);
                    return message?.message || undefined;
                } catch (error) {
                    logger.error("Error parsing cached message:", error);
                }
            }

            // Fallback to database if not in cache
            try {
                 const msgDb = await Message.findOne({ where: { messageId: id }, include: ['contact'] });
                 if (!msgDb?.dataJson) return undefined;
                 const message = JSON.parse(msgDb.dataJson);
                 // console.log('getMessage from database:', id, JSON.stringify(message));
                 // Add to cache after fetching from DB
                 msgCache.set(id, msgDb.dataJson);
                 return message?.message || undefined;
             } catch (error) {
                  logger.error(`Error fetching message ${id} from database:`, error);
             }

            return undefined;
        },
        /** Save message to cache */
        save: (message: baileys.proto.IWebMessageInfo): void => {
            const { id } = message.key;
            if (!id) return;
            const data = JSON.stringify({ message }); // Store the whole message object structure
            try {
                msgCache.set(id, data);
            } catch (error) {
                logger.error(error);
            }
        }
    };
}


/**
 * Initializes a new WASocket session using Baileys.
 * Handles authentication, event listeners, and session saving.
 * @param whatsapp - The WhatsApp connection record from the database.
 * @returns Promise resolving when the session is initialized.
 */
export const initWASocket = async (whatsapp: Whatsapp): Promise<void> => {
    return new Promise(async (resolve, reject) => {
        try {
            const io = getIO();
            const { id, name, tenantId } = whatsapp;
            const sessionName = whatsapp.name; // Use whatsapp name as session identifier?

            // Fetch current and recommended WA versions
            const projectWaVersion = await getProjectWAVersion();
            const currentWaVersion = (baileys as any).waVersion ? (baileys as any).waVersion.split('.') : waDefaultVersion; // Get internal Baileys version if available
            const greaterWaVersion = getGreaterVersion(projectWaVersion, currentWaVersion);

            logger.info(`Using WA version: ${greaterWaVersion.join('.')}`);
            logger.info(`Starting session ${sessionName} for whatsapp ${id} on tenant ${tenantId}`);

            let retries = 0;
            let connectionState: Partial<baileys.ConnectionState> = { connection: 'close' }; // Initial state
            let lastConnectionState: Partial<baileys.ConnectionState> | null = null; // Track previous state
            let isConnect = false; // Flag for initial connection

            const { state, saveState } = await useMultiFileAuthState(whatsapp); // Load or create auth state

            // Configure caches
             const msgRetryCounterCache = new NodeCache(msgRetryCounterCacheOptions);
             const userDevicesCache = new NodeCache({ stdTTL: 300, useClones: false }); // 5 min TTL for device cache
             const groupCache = new NodeCache({ stdTTL: 300, useClones: false }); // 5 min TTL for group metadata

            // Configure proxy if provided
            let agent: SocksProxyAgent | undefined;
            if (whatsapp.proxyUrl) {
                try {
                    agent = new SocksProxyAgent(whatsapp.proxyUrl);
                    logger.info('Using proxy connection for WhatsApp.');
                } catch (proxyError) {
                    logger.error('Invalid proxy URL format. Proceeding without proxy.', proxyError);
                }
            } else if (process.env.PROXY_URL) {
                try {
                     agent = new SocksProxyAgent(process.env.PROXY_URL);
                     logger.info('Using proxy connection from environment variable for WhatsApp.');
                 } catch (proxyError) {
                     logger.error('Invalid proxy URL format from environment variable. Proceeding without proxy.', proxyError);
                 }
            }

             // Configure logger for Baileys
             const loggerBaileys = logger.child({}); // Create child logger if needed
             loggerBaileys.level = process.env.BAILEYS_LOG_LEVEL || 'warn'; // Control Baileys log level

            // Configure retry options
            const maxMsgRetryCount = Number(process.env.MAX_MSG_RETRY_COUNT) || 3; // Default 3 retries
            const historySyncTimeoutMs = Number(process.env.HISTORY_SYNC_TIMEOUT) || 60000; // Default 60s

            const shouldSyncHistory = (msg: baileys.proto.IHistorySyncNotification): boolean => {
                const { syncType } = msg;
                 logger.info({ syncType: syncType?.toString() }, 'History Sync Notification');
                 // Example: Sync only recent or full syncs, ignore others
                 return syncType === baileys.proto.HistorySync.HistorySyncType.RECENT ||
                        syncType === baileys.proto.HistorySync.HistorySyncType.FULL;
            };


            // Create Baileys socket instance
            const sock: Session = baileys.default({
                logger: loggerBaileys,
                printQRInTerminal: false,
                browser: [sessionName || 'WhaZap-SaaS', 'Chrome', '4.0.0'],
                auth: {
                    creds: state.creds,
                    keys: baileys.makeCacheableSignalKeyStore(state.keys, loggerBaileys),
                },
                version: greaterWaVersion,
                defaultQueryTimeoutMs: 60000, // 60 seconds timeout
                agent,
                keepAliveIntervalMs: 10000, // 10 seconds keep alive
                mobile: false, // Use multi-device mode
                msgRetryCounterCache,
                shouldSyncHistoryMessage: shouldSyncHistory, // Control history sync
                emitOwnEvents: false, // Don't emit events for messages sent by this instance
                maxMsgRetryCount,
                placeholderResendCache,
                markOnlineOnConnect: false, // Control online presence indicator
                generateHighQualityLinkPreview: true,
                userDevicesCache,
                getMessage: msg().get, // Use custom message cache getter
                cachedGroupMetadata: async (jid: string): Promise<baileys.GroupMetadata | undefined> => {
                    logger.debug({ jid }, 'getMessage: getting group metadata');
                    const cached = groupCache.get<baileys.GroupMetadata>(jid);
                    if (!cached) {
                         logger.debug({ jid }, 'getMessage: group metadata not found in cache');
                         // Optionally fetch from DB or elsewhere here if needed as a fallback
                    }
                    return cached;
                },
                shouldIgnoreJid: (jid: string | null | undefined): boolean => {
                    if (typeof jid !== 'string') {
                        // logger.debug({ jid }, 'Ignoring Jid: not a string');
                        return true; // Ignore non-string JIDs
                    }
                    const isNewsletter = baileys.isJidNewsletter(jid);
                    const isGroup = baileys.isJidGroup(jid);
                    const endsWithGus = jid.endsWith('@g.us');
                    const endsWithBroadcast = jid.endsWith('@broadcast');

                     // Ignore specific JID types
                    return isNewsletter || endsWithBroadcast;
                    // Let group JIDs pass through for group event handling
                },
                 patchMessageBeforeSending: async (msg: baileys.proto.IMessage) => {
                      // Example: Modify timestamp if needed (be cautious with this)
                      // if (msg.messageTimestamp) {
                      //     msg.messageTimestamp = baileys.generateWAMessageFromContent
                      // }
                      // Example: Ensure device ID is set correctly based on user type
                      // const isGroup = msg.key?.remoteJid?.endsWith('@g.us');
                      // if (!msg.key?.fromMe && !isGroup) {
                      //      // Logic for setting sender device based on source
                      // }
                      // Ensure participant is set for group messages if needed
                      // if (isGroup && !msg.key?.participant && msg.key?.fromMe) {
                      //      msg.key.participant = sock.user?.id;
                      // }

                       // Ensure message type exists (fix for potential Baileys issue)
                        if (msg.message?.deviceSentMessage && !baileys.proto.Message.DeviceSentMessage.decode(msg.message.deviceSentMessage as Uint8Array).message) {
                            msg.message.deviceSentMessage.message = msg.message // Copy main message content
                        }
                         if (msg.message?.protocolMessage && !baileys.proto.Message.ProtocolMessage.decode(msg.message.protocolMessage as Uint8Array).type) {
                            // Default to a safe type or handle specific cases
                             msg.message.protocolMessage.type = baileys.proto.Message.ProtocolMessage.Type.REVOKE // Example
                         }

                      return msg;
                  },
                // transactionOpts: { maxCommitRetries: 10, delayBetweenTriesMs: 200 }
            });

            sock.id = id; // Assign whatsapp ID to the socket instance

            // Attach caches to the socket instance for potential external access/management
            sock.userDevicesCache = userDevicesCache;
            sock.groupCache = groupCache;
            sock.msgRetryCounterCache = msgRetryCounterCache;


            // --- Event Handlers ---
            sock.ev.on('creds.update', saveState);

            // Connection update handler
            sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr, receivedPendingNotifications }) => {
                logger.info({ connectionState: { connection, lastDisconnect, qr } }, `Connection update for session ${n} (ID: ${m})`);
                connectionState = { connection, lastDisconnect, qr };
                const sessionName = whatsapp.name;

                // Handle different connection states
                if (connection === 'close') {
                    const statusCode = (lastDisconnect?.error as any)?.output?.statusCode;
                    const shouldLogout = statusCode === baileys.DisconnectReason.loggedOut;
                    const isRestart = lastDisconnect?.error?.message === 'Restart Required';

                    logger.warn({ error: lastDisconnect?.error }, `Connection closed for session ${n}. Reason: ${baileys.DisconnectReason[statusCode] || 'Unknown'} (${statusCode}). Should Logout: ${shouldLogout}`);

                    // Handle specific disconnect reasons
                    if (shouldLogout || isRestart || statusCode === 440 || statusCode === 401) {
                         logger.warn(`Logging out session ${n} due to disconnect reason: ${statusCode}`);
                         // Clean up and notify immediately
                         await cacheLayer.delFromPattern(`contacts:${c.id}:*`);
                         await cacheLayer.delFromPattern(`messages:${c.id}:*`);
                         await DeleteBaileysKeysService(c.id.toString());
                         await DeleteBaileysService(c.id); // Remove DB record
                         io.to(c.tenantId.toString()).emit(`tenant-${c.tenantId}-whatsappSession`, { action: 'delete', session: { id: c.id } });
                         removeWbot(m, true); // Remove Wbot instance, triggering logout status update
                         return; // Stop further processing for this session
                    }


                    // Retry connection logic
                    if (d.vAKjE(retriesQrCodeMap.get(m), 3)) {
                         logger.error(`Max QR retries reached for session ${n}. Removing session.`);
                         await removeWbot(m, true); // Consider if this should be a logout or just remove
                         retriesQrCodeMap.delete(m);
                         return;
                    }

                    // Attempt reconnect with delay
                    const reconnectDelay = Number(process.env.RECONNECT_DELAY) || 5000;
                    logger.info(`Attempting to reconnect session ${n} in ${reconnectDelay}ms...`);
                     await new Promise(resolve => setTimeout(resolve, reconnectDelay));
                     if (connectionState?.connection !== 'open') { // Double check state before restarting
                          await StartWhatsAppSession(whatsapp);
                     } else {
                          logger.info(`Reconnection aborted for session ${n}, already connected.`);
                     }


                }

                if (connection === 'open') {
                     isConnect = true; // Mark initial connection successful
                     logger.info(`WhatsApp session ${n} connected successfully.`);
                     await whatsapp.update({ status: 'CONNECTED', qrcode: '', number: sock?.user?.id?.split('@')[0]?.split(':')[0] }); // Update DB status

                     io.to(whatsapp.tenantId.toString()).emit(`tenant-${whatsapp.tenantId}-whatsappSession`, {
                         action: 'update',
                         session: whatsapp
                     });
                     io.to(`whatsapp-${whatsapp.id}`).emit(`whatsapp-${whatsapp.id}-init`); // Notify specific channel

                     // Request pairing code after connection if needed (alternative to QR)
                     // const pairingCodeEnabled = await cacheLayer.get('pairingCodeEnabled'); // Example check
                     // if (pairingCodeEnabled) {
                     //     const code = await sock.requestPairingCode(whatsapp.number); // Ensure number is E.164
                     //     logger.info(`Pairing code requested for ${whatsapp.number}: ${code}`);
                     //     await whatsapp.update({ pairingCode: code });
                     //      io.to(whatsapp.tenantId.toString()).emit(`tenant-${whatsapp.tenantId}-whatsappSession`, {
                     //          action: 'update',
                     //          session: whatsapp
                     //      });
                     // }


                     // Import old messages if enabled (run in background)
                      const importOldMessages = await cacheLayer.get(`importOldMessages:${whatsapp.id}`);
                      const importRecentMessages = await cacheLayer.get(`importRecentMessages:${whatsapp.id}`);
                      if (importOldMessages === 'enabled' || importRecentMessages === 'enabled') {
                            logger.info(`Starting background message import for session ${n}`);
                            const method = importOldMessages === 'enabled' ? 'PROCESS_ALL' : 'PROCESS_RECENT';
                            const daysLimit = importOldMessages === 'enabled'
                               ? Number(process.env.IMPORT_OLD_MESSAGES_DAYS) || 30 // Default 30 days for old
                               : Number(process.env.IMPORT_RECENT_MESSAGES_DAYS) || 7; // Default 7 days for recent

                            ImportWhatsAppMessageService(whatsapp.id, method, daysLimit)
                               .then(() => logger.info(`Background message import finished for session ${n}`))
                               .catch(err => logger.error(`Background message import failed for session ${n}:`, err));
                            // Clear the flag after starting import
                            await cacheLayer.del(`importOldMessages:${whatsapp.id}`);
                            await cacheLayer.del(`importRecentMessages:${whatsapp.id}`);
                      }


                    // Send session ready event after a delay
                    const readyDelay = Number(process.env.READY_DELAY) || 3000; // Default 3 seconds
                    setTimeout(() => {
                        io.to(`whatsapp-${whatsapp.id}`).emit(`whatsapp-${whatsapp.id}-ready`, whatsapp);
                        logger.info(`Session ${n} ready event emitted.`);
                    }, readyDelay);

                     resolve(); // Resolve the main promise once connected
                }


                 if (connection === 'connecting') {
                      logger.info(`WhatsApp session ${n} is connecting...`);
                      // Optionally update status to CONNECTING in DB
                      // await whatsapp.update({ status: 'CONNECTING', qrcode: '', session: '' });
                      // io.to(whatsapp.tenantId.toString()).emit(`tenant-${whatsapp.tenantId}-whatsappSession`, {
                      //      action: 'update',
                      //      session: whatsapp
                      //  });
                 }

                 // Handle QR code generation
                if (qr !== undefined) {
                     if (retriesQrCodeMap.get(m) && retriesQrCodeMap.get(m)! >= 3) {
                         logger.error(`Max QR retries reached for session ${n}. Closing connection.`);
                         await whatsapp.update({ status: 'DISCONNECTED', qrcode: '' });
                         await removeWbot(m, true); // Force removal
                         retriesQrCodeMap.delete(m);
                         reject(new Error('Max QR code retries reached')); // Reject promise
                         return;
                     }
                     logger.info(`QR code generated for session ${n}. Attempt ${retriesQrCodeMap.get(m) || 0 + 1}`);
                     await whatsapp.update({ qrcode: qr, status: 'qrcode', number: '', pairingCode: '' }); // Clear pairing code on QR

                     // Emit QR code to frontend
                     const sessionQR = await Whatsapp.findByPk(m); // Fetch updated record
                     io.to(whatsapp.tenantId.toString()).emit(`tenant-${whatsapp.tenantId}-whatsappSession`, {
                         action: 'update',
                         session: sessionQR
                     });
                      io.to(`whatsapp-${whatsapp.id}`).emit(`whatsapp-${whatsapp.id}-qrCode`, { qr }); // Send to specific channel room

                     // Increment retry count
                     retriesQrCodeMap.set(m, (retriesQrCodeMap.get(m) || 0) + 1);
                 }

                lastConnectionState = { ...connectionState }; // Store current state

            });

            // History Sync Progress
            sock.ev.on('messaging-history.set', async ({ chats, contacts, messages, isLatest }) => {
                 logger.info(
                     `History Sync: ${chats.length} chats, ${contacts.length} contacts, ${messages.length} messages. IsLatest: ${isLatest}`
                 );
                 // Here you can process the synced data, e.g., save contacts, messages to your database
                 // Be mindful of performance, process in batches if necessary
            });

            // Other event listeners (messages, groups, presence, etc.)
            // These should likely be in separate handler files for better organization

            // Example: Messages Upsert Handler
            sock.ev.on('messages.upsert', async ({ messages, type }) => {
                // Import and call message handler function
                // await handleMessagesUpsert(sock, messages, type, whatsapp.tenantId);
                 logger.debug({ type, count: messages.length }, `Received ${messages.length} messages (upsert)`);
            });

            // Example: Group Update Handler
            sock.ev.on('groups.update', async (groupUpdates) => {
                 // Import and call group update handler function
                 // await handleGroupsUpdate(sock, groupUpdates, whatsapp.tenantId);
                 logger.debug({ count: groupUpdates.length }, `Received ${groupUpdates.length} group updates`);
                 groupUpdates.forEach(update => groupCache.set(update.id, update)); // Update cache
            });

             // Example: Group Participants Update Handler
             sock.ev.on('group-participants.update', async (update) => {
                  // Import and call participants update handler function
                   logger.debug({ update }, `Received group participants update`);
                   const currentMeta = groupCache.get<baileys.GroupMetadata>(update.id);
                   if (currentMeta) {
                        // Apply update to cached metadata (implement logic based on Baileys docs)
                        // Example: Add/remove participants
                        // groupCache.set(update.id, updatedMeta);
                   }
             });

             // Add more handlers as needed... (presence.update, contacts.update, etc.)


        });
    } catch (error) {
        Sentry.captureException(error);
        logger.error(error);
        reject(error); // Reject the main promise if initial setup fails
    }
};