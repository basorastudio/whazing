import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add 'useIntegration' flag column
    await queryInterface.addColumn(
      'Tickets',        // Table name
      'useIntegration', // New column name
      {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: true, // Original allowed null
      }
    );

    // Add 'integrationId' foreign key column
    await queryInterface.addColumn(
      'Tickets',       // Table name
      'integrationId', // New column name
      {
        type: DataTypes.INTEGER,
        references: {
          model: 'QueueIntegrations', // References the QueueIntegrations table
          key: 'id',
        },
        defaultValue: null,
        allowNull: true, // Allow null if no integration is used
        onUpdate: 'CASCADE', // Keep consistency if integration ID changes (though unlikely for PK)
        onDelete: 'SET NULL', // Keep ticket if integration is deleted
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added columns in reverse order
    await queryInterface.removeColumn('Tickets', 'integrationId');
    await queryInterface.removeColumn('Tickets', 'useIntegration');
     // Original code wrapped this in Promise.all, which is fine too.
  }
};

export = migration;