import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla 'ChatFlow' para definir flujos de chat
    return queryInterface.createTable('ChatFlow', {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      name: { // Nombre del flujo de chat
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: ''
      },
      flow: { // Definición del flujo (probablemente JSON)
        type: DataTypes.JSON,
        allowNull: false,
        defaultValue: {}
      },
      isActive: { // Indica si el flujo está activo
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      celularTeste: { // Número de celular para pruebas
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      userId: {
        type: DataTypes.INTEGER,
        references: { model: 'Users', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Si el usuario se elimina, se elimina el flujo
        allowNull: true, // Permite nulos (¿flujos de sistema?)
        defaultValue: null
      },
      tenantId: {
        type: DataTypes.INTEGER,
        references: { model: 'Tenants', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'restrict', // No permite eliminar Tenant si tiene flujos
        allowNull: false,
        defaultValue: 1
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la tabla 'ChatFlow'
    return queryInterface.dropTable('ChatFlow');
  }
};