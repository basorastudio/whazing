import { Request, Response } from 'express';
import * as Yup from 'yup';
import CreateAutoReplyService from '../services/AutoReplyServices/CreateAutoReplyService';
import AppError from '../errors/AppError';
import ListAutoReplyService from '../services/AutoReplyServices/ListAutoReplyService';
import UpdateAutoReplyService from '../services/AutoReplyServices/UpdateAutoReplyService';
import DeleteAutoReplyService from '../services/AutoReplyServices/DeleteAutoReplyService';

interface AutoReplyData {
  name: string;
  action: number; // Assuming action is a number based on validation
  tenantId: number | string; // tenantId can be string from req.user
  userId: number | string; // userId can be string from req.user
  // Add other fields from req.body if necessary
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;

  // Admin check - Assuming only admins can create auto-replies
  if (req.user.profile !== 'admin') {
    throw new AppError('ERR_NO_PERMISSION', 403);
  }

  const autoReplyData: Omit<AutoReplyData, 'tenantId' | 'userId'> = { ...req.body };
  const serviceData: AutoReplyData = {
      ...autoReplyData,
      tenantId: tenantId,
      userId: req.user.id // Assign the creator's ID
  }

  const schema = Yup.object().shape({
    name: Yup.string().required(),
    action: Yup.number().required(),
    tenantId: Yup.number().required(),
    userId: Yup.number().required(),
  });

  try {
    await schema.validate(serviceData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const autoReply = await CreateAutoReplyService(serviceData);

  return res.status(201).json(autoReply); // 201 Created
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user;
  const listData = { tenantId };
  const autoReplies = await ListAutoReplyService(listData);
  return res.status(200).json(autoReplies);
};

export const update = async (req: Request, res: Response): Promise<Response> => {
  // Admin check
  if (req.user.profile !== 'admin') {
    throw new AppError('ERR_NO_PERMISSION', 403);
  }

  const { tenantId } = req.user;
  const autoReplyUpdateData: Partial<AutoReplyData> = req.body; // Partial as not all fields might be updated
  const { autoReplyId } = req.params;

  const schema = Yup.object().shape({
    // Validate only fields that can be updated
    name: Yup.string(),
    action: Yup.number(),
    // userId should probably not be updated here
  });

  try {
    // Validate only the provided update data, not the whole structure
    await schema.validate(autoReplyUpdateData);
  } catch (err: any) {
    throw new AppError(err.message, 400);
  }

  const serviceData = {
    autoReplyData: autoReplyUpdateData, // Pass the partial update data
    autoReplyId: parseInt(autoReplyId, 10),
    tenantId: tenantId,
  };

  const autoReply = await UpdateAutoReplyService(serviceData);

  return res.status(200).json(autoReply);
};

export const remove = async (req: Request, res: Response): Promise<Response> => {
  // Admin check
  if (req.user.profile !== 'admin') {
    throw new AppError('ERR_NO_PERMISSION', 403);
  }

  const { tenantId } = req.user;
  const { autoReplyId } = req.params;

  const deleteData = {
    id: parseInt(autoReplyId, 10),
    tenantId: tenantId,
  };

  await DeleteAutoReplyService(deleteData);

  return res.status(200).json({ message: 'Auto reply eliminado' });
};