"use strict";

import { logger } from "../utils/logger";
import { Op } from "sequelize";
import * as Sentry from "@sentry/node";
import Schedule from "../models/Schedule";
import moment from "moment"; // Usa 'moment-timezone' si necesitas zonas horarias específicas
import Contact from "../models/Contact";
import Ticket from "../models/Ticket";
import User from "../models/User";
import FindOrCreateTicketService from "../services/TicketServices/FindOrCreateTicketService";
import ShowTicketService from "../services/TicketServices/ShowTicketService";
import socketEmit from "../helpers/socketEmit";
import CreateMessageSystemService from "../services/MessageServices/CreateMessageSystemService";
import Mustache from "../helpers/Mustache";
import Whatsapp from "../models/Whatsapp";
import { RefreshToken } from "../helpers/RefreshToken";
import CheckSettingsHelper from "../helpers/CheckSettingsHelper";
import { schedule } from "node-cron"; // Asumiendo que usas node-cron, ajusta si es otra librería

// Opciones para el trabajo de la cola (ejemplo con Bull)
const jobOptions = {
  // attempts: 3, // Ejemplo: Número de reintentos
  // backoff: { type: 'fixed', delay: 60000 } // Ejemplo: Retraso entre reintentos (60 seg)
};

const queueOptions = {
  removeOnComplete: true, // Elimina el trabajo al completar
  removeOnFail: true, // Elimina el trabajo si falla
  jobId: "VerifySchedules"
  // repeat: { every: 60000 }, // Ejemplo: Repetir cada 60 segundos
};

export default {
  key: "VerifySchedules", // Clave única para este tipo de trabajo
  options: queueOptions,

  async handle(): Promise<void> {
    const keyCheckMsgIsGroup = "CheckMsgIsGroup"; // Clave para la configuración
    const keyScheduleId = "scheduleId"; // Clave para la configuración (ejemplo)
    const keySendGreeting = "sendGreeting"; // Clave para la configuración (ejemplo)

    try {
      const { count, rows: schedules } = await Schedule.findAndCountAll({
        where: {
          status: "PENDENTE", // Estado pendiente
          sentAt: null,
          sendAt: { [Op.lt]: moment().toDate() } // Fecha de envío menor que ahora
        },
        include: [
          { model: Contact, as: "contact" },
          { model: User, attributes: ["name"] } // Incluir solo el nombre del usuario
        ]
      });

      if (count > 0) {
        schedules.map(async (schedule: Schedule) => {
          // Encuentra o crea el ticket asociado
          let ticket: Ticket | null = await Ticket.findOne({
            where: {
              contactId: schedule.contactId,
              tenantId: schedule.tenantId,
              status: { [Op.ne]: "closed" } // Que no esté cerrado
            },
            order: [["id", "DESC"]] // Ordenar por ID descendente
          });

          // Si no existe ticket o está cerrado, intenta crear uno nuevo
          if (!ticket) {
            const whatsapp: Whatsapp | null = await Whatsapp.findOne({
              where: { id: schedule.whatsappId },
              attributes: ["id"] // Solo necesitamos el ID
            });

            if (!whatsapp) {
              logger.warn(
                `Whatsapp con ID ${schedule.whatsappId} no encontrado para el schedule ${schedule.id}`
              );
              return; // No se puede continuar sin WhatsApp
            }

            ticket = await FindOrCreateTicketService({
              contactId: schedule.contactId,
              whatsappId: schedule.whatsappId,
              unreadMessages: 0,
              tenantId: schedule.tenantId,
              groupContact: undefined, // O el valor correspondiente si es grupo
              channel: whatsapp.channel || "whatsapp" // Canal predeterminado
            });
            await ticket.update({ status: "pending" }); // Marcar como pendiente

            // Emitir evento de socket para nuevo ticket
            const ticketToSend = await ShowTicketService({
              id: ticket.id,
              tenantId: schedule.tenantId
            });
            socketEmit({
              tenantId: schedule.tenantId,
              type: "ticket:update",
              payload: ticketToSend
            });
          }

          // Mostrar detalles del ticket actual
          const ticketToShow = await ShowTicketService({
            id: ticket.id,
            tenantId: schedule.tenantId
          });

          // Renderizar mensaje usando Mustache si es necesario
          let body = await Mustache(
            schedule.body,
            schedule.contact,
            ticketToShow
          );

          // Verificar configuraciones (ejemplos, adaptar a tus claves reales)
          const tokenCheckMsgIsGroup = RefreshToken(keyCheckMsgIsGroup);
          const tokenScheduleId = RefreshToken(keyScheduleId); // Ejemplo
          const tokenSendGreeting = RefreshToken(keySendGreeting); // Ejemplo

          const settingCheckMsgIsGroup =
            await CheckSettingsHelper(tokenCheckMsgIsGroup);
          // const settingScheduleId = await CheckSettingsHelper(tokenScheduleId);
          // const settingSendGreeting = await CheckSettingsHelper(tokenSendGreeting);

          // Ejemplo de lógica condicional basada en configuraciones
          if (settingCheckMsgIsGroup === tokenSendGreeting) {
            // Adaptar lógica
            const footer = RefreshToken("footer"); // Ejemplo
            body += "\n\n" + footer;
          }

          // Construir la ruta del medio si existe
          const mediaPath =
            schedule.mediaPath && schedule.mediaName
              ? `${schedule.mediaPath}/${schedule.mediaName}`
              : null;

          // Crear mensaje del sistema para el agendamiento
          const messageData = {
            body: body,
            fromMe: true, // Mensaje enviado por el sistema/bot
            mediaPath: mediaPath,
            // Define el 'channel' basado en la lógica de tu aplicación
            // Puede venir del ticket, del whatsapp, o ser fijo si es solo para whatsapp
            channel:
              ticketToShow.channel || schedule.whatsapp?.channel || "whatsapp",
            tenantId: ticketToShow.tenantId
          };

          await CreateMessageSystemService({
            msg: messageData,
            tenantId: ticketToShow.tenantId,
            ticket: ticketToShow, // Pasar el objeto ticket completo
            scheduleId: schedule.id // Asociar el ID del schedule al mensaje
            // Aquí podrías agregar lógica para enviar realmente el mensaje a través de la API correspondiente
          });

          // Actualizar el estado del agendamiento
          await schedule.update({
            sentAt: moment().toDate(),
            status: "ENVIADA" // Estado enviado
          });

          logger.info(`Agendamiento enviado para: ${schedule.contact.name}`);
        });
      }
    } catch (err: any) {
      Sentry.captureException(err); // Capturar excepción con Sentry
      logger.error("VerifySchedules: error", err.message);
      throw err; // Re-lanzar el error para que el job falle
    }
  }
};
