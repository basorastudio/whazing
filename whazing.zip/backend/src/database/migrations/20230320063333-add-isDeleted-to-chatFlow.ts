// --- START OF FILE 20230320063333-add-isDeleted-to-chatFlow.ts ---

"use strict";
import { QueryInterface, DataTypes, Sequelize } from "sequelize";

interface Migration {
  up: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
  down: (
    queryInterface: QueryInterface,
    sequelize: typeof Sequelize
  ) => Promise<void>;
}

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "ChatFlow"; // Table name from original code
    const columnName = "isDeleted";
    const attributes = {
      type: DataTypes.BOOLEAN,
      defaultValue: false // Changed ![] to false
      // allowNull defaults to true if not specified, assuming that's acceptable
    };
    await queryInterface.addColumn(tableName, columnName, attributes);
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "ChatFlow";
    const columnName = "isDeleted";
    await queryInterface.removeColumn(tableName, columnName);
  }
};

export default migration;

// --- END OF FILE 20230320063333-add-isDeleted-to-chatFlow.ts ---
