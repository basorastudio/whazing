import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'nextStep' a la tabla 'StepsReplyActions'
    return queryInterface.addColumn('StepsReplyActions', 'nextStep', {
      type: DataTypes.INTEGER,
      references: {
        model: 'StepsReply', // Referencia a la tabla StepsReply
        key: 'id'
      },
      onUpdate: 'CASCADE',
      onDelete: 'CASCADE', // Si se elimina el StepsReply referenciado, también se elimina esta acción
      defaultValue: null,
      allowNull: true
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'nextStep' de la tabla 'StepsReplyActions'
    return queryInterface.removeColumn('StepsReplyActions', 'nextStep');
  }
};