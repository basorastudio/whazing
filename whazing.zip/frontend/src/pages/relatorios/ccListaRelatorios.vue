<template>
  <div class="row q-col-gutter-xl">
    <div v-if="userProfile === 'admin' || userProfile === 'supervisor'">
      <div class="row items-center q-mb-md">
        <h2 :class="$q.dark.isActive ? 'color-dark3' : ''">
          <q-icon name="mdi-message-bulleted-off" class="q-pr-sm" />
          Informes
        </h2>
      </div>

      <q-card class="q-ma-sm" style="height: auto; min-height: calc(100vh - 135px)">
        <q-card-section>
          <div class="row q-col-gutter-lg">
            <div v-for="menu in cRelatorios"
                 :key="menu.name"
                 class="col-12 col-sm-6 col-md-3">
              <template>
                <q-item
                  clickable
                  v-ripple
                  @click="goTo(menu.name)"
                  :class="[
      'report-card shadow-2 full-width',
      $q.dark.isActive ? 'bg-dark' : 'bg-white'
    ]"
                  style="border-left: solid var(--q-cor1) 4px">
                  <q-item-section class="q-pa-md">
                    <q-item-label :class="$q.dark.isActive ? 'text-grey-4' : 'text-grey-8'">{{ menu.titulo }}</q-item-label>
                    <q-item-label caption :class="$q.dark.isActive ? 'text-grey-4' : 'text-grey-8'">
                      {{ menu.objetivo }}
                    </q-item-label>
                  </q-item-section>
                </q-item>
              </template>
            </div>
          </div>
        </q-card-section>
      </q-card>
    </div>
  </div>
</template>

<script>
import relatorios from './relatorios.json'
import { ListarCores } from 'src/service/configuracoesgeneral'
export default {
  name: 'ccListaRelatorios',
  computed: {
    cRelatorios () {
      return relatorios
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    async goTo(route) {
      this.$router.push({ name: route })
    }
  },
  data () {
    return {
      userProfile: 'user'
    }
  },
  mounted() {
    this.loadColors()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.report-card
  padding: 16px
  min-height: 120px
  margin-bottom: 12px
  transition: all 0.3s ease

  &:hover
    transform: translateY(-2px)
    box-shadow: 0 4px 8px rgba(0,0,0,0.2) !important

  .q-item-label.text-primary
    font-size: 1.2rem
    margin-bottom: 8px
    font-weight: 500
    line-height: 1.2

  .q-item-label.caption
    font-size: 1rem
    line-height: 1.3
</style>
