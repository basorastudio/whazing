import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Añade la columna contactId a la tabla Messages
    return queryInterface.addColumn("Messages", "contactId", {
      // Nombre de columna preservado
      type: DataTypes.INTEGER,
      references: {
        model: "Contacts", // Referencia a la tabla Contacts
        key: "id"
      },
      onUpdate: "CASCADE",
      onDelete: "CASCADE", // Si se elimina el contacto, se eliminan sus mensajes (o SET NULL si se prefiere)
      allowNull: true // Puede ser nulo si el mensaje no está directamente asociado a un contacto (ej. mensajes de sistema?)
      // Revisar lógica de negocio para confirmar si debe ser false.
    });
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la columna contactId
    return queryInterface.removeColumn("Messages", "contactId");
  }
};
