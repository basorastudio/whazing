import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add fields related to an "Apiwwjs" integration to 'Whatsapps'
    await queryInterface.addColumn('Whatsapps', 'isApiwwjs', {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      allowNull: false, // Original had false
    });
    await queryInterface.addColumn('Whatsapps', 'urlapiwwjs', {
      type: DataTypes.TEXT,
      defaultValue: null,
      allowNull: true, // Original allowed null
    });
    await queryInterface.addColumn('Whatsapps', 'apikeyapiwwjs', {
      type: DataTypes.TEXT,
      defaultValue: null,
      allowNull: true, // Original allowed null
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added fields
    await queryInterface.removeColumn('Whatsapps', 'apikeyapiwwjs');
    await queryInterface.removeColumn('Whatsapps', 'urlapiwwjs');
    await queryInterface.removeColumn('Whatsapps', 'isApiwwjs');
  }
};

export = migration;