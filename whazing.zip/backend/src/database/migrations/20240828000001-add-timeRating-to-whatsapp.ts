import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Check if the 'timeRating' column already exists before adding
    const tableInfo = await queryInterface.describeTable('Whatsapps');
    if (!tableInfo || !tableInfo['timeRating']) {
      // Add the 'timeRating' column to the 'Whatsapps' table
      // Defines a time limit (likely in minutes or seconds) for ratings.
      await queryInterface.addColumn(
        'Whatsapps',  // Table name
        'timeRating', // New column name
        {
          type: DataTypes.INTEGER,
          defaultValue: 5,     // Default value is 5
          allowNull: true,    // Allow null
        }
      );
    }
    // If the column exists, do nothing (idempotency)
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'timeRating' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps',  // Table name
      'timeRating'  // Column name to remove
    );
  }
};

export = migration;