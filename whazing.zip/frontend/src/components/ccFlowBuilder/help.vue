<template>
  <q-dialog
    v-model="dialogVisible"
    maximized
    persistent
    class="help-dialog"
  >
    <div class="modal-backdrop" @click.self="dialogVisible = false">
      <div class="modal-content" :class="{ 'dark-mode': $q.dark.isActive }">
        <div class="modal-header">
          <h2 :class="$q.dark.isActive ? 'color-dark3' : ''">Guia de Configuração do Chatbot</h2>
          <q-btn
            icon="close"
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? 'color-dark1' : ''"
            @click="dialogVisible = false"
          />
        </div>

        <div class="modal-body">
          <!-- Menu de navegação lateral -->
          <div class="sidebar" :class="{ 'dark-mode': $q.dark.isActive }">
            <div
              v-for="(tab, index) in tabs"
              :key="index"
              class="tab-button"
              :class="{
                active: currentTab === index,
                'dark-mode': $q.dark.isActive
              }"
              @click="currentTab = index"
            >
              {{ tab.label }}
            </div>
          </div>

          <!-- Conteúdo da tab selecionada -->
          <div class="content-area">
            <div class="scrollable-content">
              <!-- Elementos Básicos -->
              <div v-if="currentTab === 0">
                <h3 :class="$q.dark.isActive ? 'color-dark3' : ''">Elementos Básicos de Configuração</h3>
                <div class="help-section">
                  <div class="item-list">
                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>1. Enviar Mensagem</strong>
                      <ul>
                        <li>Permite inserir o texto que será enviado ao cliente</li>
                        <li>Suporta o uso de variáveis (consulte a seção de variáveis)</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>2. Enviar Documentos e Arquivos</strong>
                      <ul>
                        <li>Funcionalidade para envio de arquivos diversos</li>
                        <li>Suporta documentos, vídeos, áudios e outros tipos</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>3. Adicionar Delay</strong>
                      <ul>
                        <li>Configure o intervalo de tempo entre mensagens</li>
                        <li>Importante para garantir sequência correta</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>4. Adicionar Tag</strong>
                      <ul>
                        <li>Permite marcar o contato com etiqueta específica</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>5. Adicionar Webhook (GET)</strong>
                      <ul>
                        <li>Integração com sistemas externos</li>
                        <li>Envio de informações capturadas no atendimento</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Ordem das Interações -->
              <div v-if="currentTab === 1">
                <h3 :class="$q.dark.isActive ? 'color-dark3' : ''">Ordem das Interações</h3>
                <div class="help-section">
                  <div class="info-box" :class="{ 'dark-mode': $q.dark.isActive }">
                    <h4>Importante:</h4>
                    <ul>
                      <li>Os números indicam a sequência exata de execução</li>
                      <li>Use sempre delay entre múltiplas mensagens</li>
                      <li>A ordem de execução segue a numeração configurada</li>
                    </ul>
                  </div>
                </div>
              </div>

              <!-- Condições -->
              <div v-if="currentTab === 2">
                <h3 :class="$q.dark.isActive ? 'color-dark3' : ''">Configuração de Condições</h3>
                <div class="help-section">
                  <h4>Tipos de Condições (por prioridade):</h4>

                  <div class="item-list">
                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>1. Dentro/Fora do Horário</strong>
                      <ul>
                        <li>Funciona apenas na etapa "Boas vindas!"</li>
                        <li>Posicionamento: Início das condições</li>
                        <li>Dentro do Horário: Ativa no horário comercial</li>
                        <li>Fora do Horário: Ativa fora do horário comercial</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>2. Respostas Exatas</strong>
                      <ul>
                        <li>Exemplo: "1" ou "01"</li>
                        <li>Requer resposta idêntica ao configurado</li>
                        <li>Não aceita variações como "quero 1"</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>3. Contém Exato</strong>
                      <ul>
                        <li>Busca palavras específicas na frase</li>
                        <li>Exemplo: "quero comprar" em "Eu quero comprar um tênis"</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>4. Contém</strong>
                      <ul>
                        <li>Reconhece partes de palavras</li>
                        <li>Exemplo: "compra" encontra "comprando"</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>5. Qualquer Resposta</strong>
                      <ul>
                        <li>Posicionamento: Sempre por último</li>
                        <li>Captura respostas não previstas</li>
                      </ul>
                    </div>

                    <div class="warning-box" :class="{ 'dark-mode': $q.dark.isActive }">
                      <h4>Respostas Inesperadas</h4>
                      <p>Mensagem padrão quando nenhuma condição é atendida:</p>
                      <pre>"Desculpe! Não entendi sua resposta. Vamos tentar novamente! Escolha uma opção válida."</pre>
                      <p><em>Esta mensagem pode ser personalizada nas configurações</em></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </q-dialog>
</template>

<script>
export default {
  name: 'HelpDialog',
  data () {
    return {
      dialogVisible: false,
      currentTab: 0,
      tabs: [
        { label: 'Elementos Básicos' },
        { label: 'Ordem das Interações' },
        { label: 'Condições' }
      ]
    }
  },
  methods: {
    init () {
      this.dialogVisible = true
    }
  }
}
</script>

<style scoped>
.help-dialog {
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background: white;
  border-radius: 8px;
  width: 90%;
  max-width: 1200px;
  height: 90vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  color: #333;
}

.modal-content.dark-mode {
  background: #1d1d1d;
  color: white;
}

.modal-header {
  padding: 16px 24px;
  border-bottom: 1px solid #eee;
  background: inherit;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h2 {
  color: #333;
}

.modal-content.dark-mode .modal-header h2 {
  color: white;
}

.modal-body {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.sidebar {
  width: 200px;
  border-right: 1px solid #eee;
  background: #f8f9fa;
  padding: 16px 0;
}

.sidebar.dark-mode {
  background: #2d2d2d;
  border-right-color: #333;
}

.tab-button {
  padding: 12px 24px;
  cursor: pointer;
  transition: all 0.3s;
  color: #333;
}

.tab-button.dark-mode {
  color: white;
}

.tab-button:hover {
  background: #ecf5ff;
}

.tab-button.dark-mode:hover {
  background: #3d3d3d;
}

.tab-button.active {
  background: var(--q-cor2);
  color: white !important;
}

.tab-button.active.dark-mode {
  background: var(--q-cor1);
}

.content-area {
  flex: 1;
  overflow: hidden;
}

.scrollable-content {
  height: 100%;
  overflow-y: auto;
  padding: 24px;
}

.help-section {
  margin-bottom: 30px;
}

h3 {
  color: #333;
}

.dark-mode h3 {
  color: white;
}

h4 {
  color: #333;
}

.dark-mode h4 {
  color: white;
}

.item-list {
  display: grid;
  gap: 20px;
}

.help-item {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid var(--q-cor1);
}

.help-item.dark-mode {
  background: #2d2d2d;
  border-left-color: var(--q-cor1);
}

.help-item strong {
  color: #333;
}

.help-item.dark-mode strong {
  color: white;
}

.info-box {
  background: #ecf5ff;
  padding: 20px;
  border-radius: 8px;
  border: 1px solid #d9ecff;
  margin: 20px 0;
}

.info-box.dark-mode {
  background: #2d2d2d;
  border-color: #333;
}

.warning-box {
  background: #fff9f2;
  padding: 20px;
  border-radius: 8px;
  border: 1px solid #faecd8;
  margin-top: 30px;
}

.warning-box.dark-mode {
  background: #2d2d2d;
  border-color: #333;
}

.warning-box pre {
  background: #fff;
  padding: 15px;
  border-radius: 4px;
  margin: 10px 0;
  border: 1px solid #faecd8;
  color: #333;
}

.warning-box.dark-mode pre {
  background: #1d1d1d;
  border-color: #333;
  color: white;
}

ul {
  margin: 0;
  padding-left: 20px;
}

li {
  margin: 8px 0;
  color: #333;
}

.dark-mode li {
  color: white;
}

@media (max-width: 768px) {
  .modal-content {
    width: 95%;
    height: 95vh;
  }

  .sidebar {
    width: 150px;
  }

  .tab-button {
    padding: 12px 16px;
  }

  .scrollable-content {
    padding: 16px;
  }

  .help-item {
    padding: 16px;
  }
}
</style>
