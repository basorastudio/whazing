"use strict";

import User from "../models/User";
import { logger } from "../utils/logger";
import { getIO } from "../libs/socket";
import AppError from "../errors/AppError"; // Asumiendo que tienes un archivo para errores personalizados
import db from "../database"; // Importa la instancia de sequelize
import { QueryTypes } from "sequelize";
import * as Sentry from "@sentry/node";

// Opciones para el trabajo de la cola (ejemplo con Bull)
const jobOptions = {
  // attempts: 3, // Ejemplo: Número de reintentos
  // backoff: { type: 'fixed', delay: 60000 } // Ejemplo: Retraso entre reintentos (60 seg)
};

const queueOptions = {
  removeOnComplete: true, // Elimina el trabajo al completar
  removeOnFail: true, // Elimina el trabajo si falla
  jobId: "VerifyOnlineUsers"
  // repeat: { every: 60000 }, // Ejemplo: Repetir cada 60 segundos
};

export default {
  key: "VerifyOnlineUsers", // Clave única para este tipo de trabajo
  options: queueOptions,

  async handle(): Promise<void> {
    try {
      logger.info("VerifyOnlineUsers Iniciado");

      // Query SQL para encontrar usuarios cuya última actividad fue hace más de 5 minutos y están marcados como online
      // Adaptar la sintaxis del intervalo según tu dialecto SQL (PostgreSQL aquí)
      const query = `
                SELECT id
                FROM "Users"
                WHERE "lastSeen" < now() - '5 minutes'::interval
                  AND "isOnline" = true;
            `;

      const usersToUpdate: { id: number }[] = await db.query(query, {
        type: QueryTypes.SELECT
      });

      for (const userData of usersToUpdate) {
        try {
          const user = await User.findByPk(userData.id);
          if (user) {
            await user.update({ isOnline: false });
            logger.info(`Usuario pasado para offline: ${userData.id}`);
          }
        } catch (e: any) {
          // Capturar error específico de actualización de usuario pero continuar con los demás
          Sentry.captureException(e);
          logger.error(
            `Error actualizando usuario ${userData.id} a offline: ${e.message}`
          );
        }
      }

      // Emitir evento de socket para actualizar el estado de los usuarios en el frontend
      const io = getIO();
      io.emit("user:update", {}); // Puedes enviar datos más específicos si es necesario

      logger.info("VerifyOnlineUsers Finalizado");
    } catch (err: any) {
      Sentry.captureException(err); // Capturar excepción con Sentry
      logger.error("Error VerifyOnlineUsers:", err.message);
      throw err; // Re-lanzar el error para que el job falle
    }
  }
};
