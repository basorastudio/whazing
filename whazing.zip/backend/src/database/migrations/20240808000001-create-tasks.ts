import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Create the 'Tasks' table
    await queryInterface.createTable(
      "Tasks", // Table name
      {
        id: {
          type: DataTypes.INTEGER,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false
        },
        name: {
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        description: {
          type: DataTypes.STRING, // Consider TEXT if descriptions can be long
          allowNull: true,
          defaultValue: null
        },
        limitDate: {
          type: DataTypes.DATE,
          allowNull: true,
          defaultValue: null
        },
        owner: {
          type: DataTypes.DATE, // Seems incorrect, owner likely User ID (INTEGER)? Kept as DATE based on original. Review needed.
          allowNull: true,
          defaultValue: null
        },
        status: {
          type: DataTypes.ENUM("pending", "finished", "delayed"), // ENUM for defined statuses
          allowNull: true,
          defaultValue: null // Default is null
        },
        priority: {
          type: DataTypes.ENUM("low", "medium", "high", "none"), // ENUM for defined priorities
          allowNull: true,
          defaultValue: null // Default is null
        },
        comments: {
          type: DataTypes.STRING, // Consider TEXT if comments can be long
          allowNull: true,
          defaultValue: null
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: {
            model: "Tenants", // Foreign key to Tenants
            key: "id"
          },
          onUpdate: "CASCADE",
          onDelete: "SET NULL", // Allow tasks to exist without tenant? Or should be CASCADE? Kept SET NULL from original.
          allowNull: true // Should likely be false if linked to tenant is mandatory
        },
        userId: {
          type: DataTypes.INTEGER,
          references: {
            model: "Users", // Foreign key to Users
            key: "id"
          },
          onUpdate: "CASCADE",
          onDelete: "SET NULL", // Allow tasks to exist without user? Or should be CASCADE? Kept SET NULL from original.
          allowNull: true // Should likely be false if user assignment is mandatory
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        }
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Drop the 'Tasks' table
    await queryInterface.dropTable("Tasks");
  }
};

export = migration;
