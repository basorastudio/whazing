import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'status' (STRING) a 'Users'
    return Promise.all([
      queryInterface.addColumn('Users', 'status', {
        type: DataTypes.STRING,
        allowNull: false, // No permite nulos
        defaultValue: 'offline' // Valor predeterminado 'offline'
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'status' de 'Users'
    return Promise.all([
      queryInterface.removeColumn('Users', 'status')
    ]);
  }
};