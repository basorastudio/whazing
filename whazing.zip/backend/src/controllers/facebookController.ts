// --- START OF FILE FarewellMessageController.ts ---

import { Request, Response } from "express";
import ListFarewellMessageService from "../services/FarewellMessageServices/ListFarewellMessageService"; // Ajustado
import CreateFarewellMessageService from "../services/FarewellMessageServices/CreateFarewellMessageService"; // Ajustado
import DeleteFarewellMessageService from "../services/FarewellMessageServices/DeleteFarewellMessageService"; // Ajustado
import ListFarewellMessageServiceAll from "../services/FarewellMessageServices/ListFarewellMessageServiceAll"; // Ajustado
import UpdateFarewellMessageService from "../services/FarewellMessageServices/UpdateFarewellMessageService"; // Ajustado

// Interfaces para tipado
interface RequestUser {
  tenantId: string | number;
  id: string | number; // Asumiendo que id es el userId
}

interface ListRequest extends Request {
  user: RequestUser;
}

interface CreateRequestBody {
  message: string;
  global: boolean;
}

interface CreateRequest extends Request {
  user: RequestUser;
  body: CreateRequestBody;
}

interface DeleteRequestParams {
  id: string;
}

interface DeleteRequest extends Request {
  params: DeleteRequestParams;
  user: RequestUser;
}

interface UpdateRequestBody {
  message: string;
  global: boolean;
}

interface UpdateRequestParams {
  id: string;
}

interface UpdateRequest extends Request {
  params: UpdateRequestParams;
  user: RequestUser;
  body: UpdateRequestBody;
}

/**
 * @description Lista los mensajes de despedida para el usuario actual.
 * @param {ListRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const listFarewellMessages = async (
  req: ListRequest,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId } = req.user;
  const listParams = {
    tenantId: tenantId,
    userId: userId
  };

  const { farewellMessages } = await ListFarewellMessageService(listParams);

  return res.json({ farewellMessages });
};

/**
 * @description Lista todos los mensajes de despedida (posiblemente globales o con permisos diferentes).
 * @param {ListRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const listFarewellMessagesAll = async (
  req: ListRequest,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId } = req.user;
  const listParams = {
    tenantId: tenantId,
    userId: userId
  };

  const { farewellMessages } = await ListFarewellMessageServiceAll(listParams);

  return res.json({ farewellMessages });
};

/**
 * @description Crea un nuevo mensaje de despedida.
 * @param {CreateRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const createFarewellMessage = async (
  req: CreateRequest,
  res: Response
): Promise<Response> => {
  const tenantId = Number(req.user.tenantId);
  const userId = Number(req.user.id);
  const { message, global } = req.body;

  const createData = {
    message: message,
    global: global,
    tenantId: tenantId,
    userId: userId
  };

  const farewellMessage = await CreateFarewellMessageService(createData);

  return res.status(201).json(farewellMessage); // HTTP 201 Created
};

/**
 * @description Elimina un mensaje de despedida.
 * @param {DeleteRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const remove = async (
  req: DeleteRequest,
  res: Response
): Promise<Response> => {
  const { id } = req.params;
  const { tenantId, id: userId } = req.user;

  const deleteParams = {
    id: id,
    tenantId: tenantId,
    userId: userId
  };

  await DeleteFarewellMessageService(deleteParams);

  return res.status(204).send(); // HTTP 204 No Content
};

/**
 * @description Actualiza un mensaje de despedida existente.
 * @param {UpdateRequest} req - Objeto de solicitud de Express.
 * @param {Response} res - Objeto de respuesta de Express.
 * @returns {Promise<Response>} - Promesa que resuelve con la respuesta JSON.
 */
export const updateFarewellMessage = async (
  req: UpdateRequest,
  res: Response
): Promise<Response> => {
  const { id } = req.params;
  const { tenantId, id: userId } = req.user;
  const { message, global } = req.body;

  try {
    const updateData = {
      id: id,
      tenantId: tenantId,
      userId: userId,
      message: message,
      global: global
    };
    const farewellMessage = await UpdateFarewellMessageService(updateData);
    return res.status(200).json(farewellMessage); // HTTP 200 OK
  } catch (error: any) {
    // Es mejor manejar el error específico si es posible (ej. AppError)
    // Aquí asumimos un error genérico o uno que tiene una propiedad 'message'
    const errorMessage =
      error instanceof Error
        ? error.message
        : "Error desconocido al actualizar";
    return res.status(500).json({ error: errorMessage }); // HTTP 500 Internal Server Error
  }
};

// --- END OF FILE FarewellMessageController.ts ---
