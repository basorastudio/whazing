"use strict";
import { QueryInterface } from "sequelize";

export default {
  up: async (queryInterface: QueryInterface) => {
    // Índice para búsquedas por tenantId
    await queryInterface.addIndex("Users", ["tenantId"], {
      name: "idx_users_tenant_id"
    }); // nombre claro del índice
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeIndex("Users", "idx_users_tenant_id");
  }
};
