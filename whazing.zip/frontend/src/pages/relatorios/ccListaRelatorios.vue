<template>
  <div v-if="userProfile === 'admin'">
    <q-card class="q-ma-sm q-pa-sm q-card q-ma-md" square style="height: calc(100vh - 280px)">
      <h2 class="text-h6 q-px-sm" :class="{ 'text-color-dark': $q.dark.isActive }">
          Relatório Geral
      </h2>
      <q-card-section class="row wrap justify-start items-center content-center q-pa-sm q-mb-md">
        <q-list v-for="menu in cRelatorios" :key="menu.name" class="q-pa-md items-center">
          <q-item style="min-width: 340px; max-width: 340px; width: 340px;
            min-height: 90px; height: 90px; max-height: 90px;
            border-left: solid #3E72AF 3px
            " class="shadow-1 q-px-sm items-start" clickable v-ripple @click="goTo(menu.name)">
            <q-item-section>
              <q-item-label class="text-primary">{{ menu.titulo }}</q-item-label>
              <q-item-label caption>{{ menu.objetivo }}</q-item-label>
            </q-item-section>
          </q-item>
        </q-list>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
import relatorios from './relatorios.json'
import { ListarCores } from 'src/service/configuracoesgeneral'
export default {
  name: 'ccListaRelatorios',
  computed: {
    cRelatorios () {
      return relatorios
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    },
    async goTo(route) {
      this.$router.push({ name: route })
    }
  },
  data () {
    return {
      userProfile: 'user'
    }
  },
  mounted() {
    this.loadColors()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="scss" scoped>
</style>
