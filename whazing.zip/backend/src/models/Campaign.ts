import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  HasMany,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AfterFind,
  AutoIncrement
} from "sequelize-typescript";
import CampaignContact from "./CampaignContacts"; // Assuming relation exists
import Tenant from "./Tenant";
import User from "./User";
import Whatsapp from "./Whatsapp";

@Table
class Campaign extends Model<Campaign> {
  // Hook preserved
  @AfterFind
  static async updateInstances(instances: Campaign[] | Campaign) {
    if (!Array.isArray(instances)) {
      // If it's a single instance, wrap it in an array for consistent processing
      // or handle it directly if preferred.
      // This example processes it as if it were always an array.
      instances = [instances];
    }

    // Process each instance
    const processedInstances = await Promise.all(
      instances.map(async instance => {
        // Check conditions (pending, processing, canceled, finished)
        if (
          !["pending", "processing", "canceled", "finished"].includes(
            instance.status
          )
        ) {
          // Calculate counts
          const contactsCount = +instance.dataValues.contactsCount || 0;
          const deliveredCount = +instance.dataValues.deliveredCount || 0;
          const receivedCount = +instance.dataValues.receivedCount || 0;
          const readCount = +instance.dataValues.readCount || 0;
          const errorsCount = +instance.dataValues.errorsCount || 0;

          const totalProcessed =
            deliveredCount + receivedCount + readCount + errorsCount;

          // Update status to 'finished' if all contacts are processed
          if (
            instance.status === "scheduled" &&
            totalProcessed >= contactsCount
          ) {
            instance.status = "finished";
            await instance.update({ status: "finished" });
          }
          // Update status to 'processing' if some are processed but not all
          else if (totalProcessed > 0 && totalProcessed < contactsCount) {
            instance.status = "processing";
            await instance.update({ status: "processing" });
          }
        }
        return instance; // Return the (potentially modified) instance
      })
    );
    // The hook doesn't need to return the instances, modification happens in place or via update.
    // If returning a single instance was intended when input is single, adjust logic.
    // return Array.isArray(instances) ? processedInstances : processedInstances[0]; // Example return
  }

  // Getter preserved
  get mediaUrl(): string | null {
    const filename = this.getDataValue("mediaUrl"); // mediaUrl stores the filename
    if (filename && filename !== "null" && filename !== "") {
      // Added empty string check
      const { BACKEND_URL, PROXY_PORT } = process.env;
      // Construct the full URL
      return `${BACKEND_URL}:${PROXY_PORT}/public/${filename}`;
    }
    return null;
  }

  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  name: string;

  @Column
  start: Date; // Assuming 'start' is a Date

  @Default("pending")
  @Column(
    DataType.ENUM("pending", "scheduled", "processing", "canceled", "finished")
  )
  status: string;

  @Column
  message1: string;

  @Column
  message2: string;

  @Column
  message3: string;

  @Column(DataType.STRING) // Store filename or path
  mediaUrl: string | null; // Getter provides full URL

  @Column
  mediaType: string;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @ForeignKey(() => Whatsapp) // Assuming relation to Whatsapp (session)
  @Column
  sessionId: number;

  @BelongsTo(() => Whatsapp) // Relation name might differ
  session: Whatsapp; // Relation name might differ

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @HasMany(() => CampaignContact)
  contactsCount: CampaignContact[]; // Renamed from campaignContacts for clarity if desired

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @Column
  delay: number; // Assuming number

  @Default(false)
  @Column(DataType.BOOLEAN)
  isOficial: boolean; // 'oficial' resolved
}

export default Campaign;
