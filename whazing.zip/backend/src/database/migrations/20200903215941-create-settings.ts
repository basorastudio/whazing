import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export default {
  up: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Crea la tabla Settings
    return queryInterface.createTable('Settings', {
      key: { // Nombre de columna preservado
        type: DataTypes.STRING,
        primaryKey: true, // Haciendo 'key' la clave primaria
        allowNull: false
      },
      value: { // Nombre de columna preservado
        type: DataTypes.TEXT,
        allowNull: false
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });
    // La migración 20210202163058 elimina esta clave primaria
    // y 20211212200504 añade una columna 'id' como PK.
  },

  down: (queryInterface: QueryInterface, sequelize: Sequelize) => {
    // Elimina la tabla Settings
    return queryInterface.dropTable('Settings');
  }
};