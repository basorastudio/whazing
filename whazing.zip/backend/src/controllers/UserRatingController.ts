import { Request, Response } from "express";
import UserRatingService from "../services/UserRatingServices/UserRatingsService2"; // Ajusta el nombre del import si es necesario

// Interfaz para los parámetros de consulta
interface RatingQuery {
  userId?: string;
  whatsappId?: string;
  startDate?: string;
  endDate?: string;
  pageNumber?: string;
}

// Extiende Request
interface RatingRequest extends Request {
  user?: {
    tenantId: string | number;
    // otras propiedades del usuario si son relevantes
  };
  query: RatingQuery;
}

// Listar calificaciones con filtros
export const index = async (
  req: RatingRequest,
  res: Response
): Promise<Response> => {
  const { userId, whatsappId, startDate, endDate, pageNumber } = req.query;
  const { tenantId } = req.user!; // Obtiene tenantId del usuario autenticado

  const filters = {
    tenantId: Number(tenantId),
    // Convierte IDs a número si existen, si no, undefined
    userId: userId ? parseInt(userId, 10) : undefined,
    whatsappId: whatsappId ? parseInt(whatsappId, 10) : undefined,
    // Convierte fechas a objeto Date si existen, si no, undefined
    startDate: startDate ? new Date(startDate) : undefined,
    endDate: endDate ? new Date(endDate) : undefined
  };

  // Convierte pageNumber a número, por defecto 1 si no se proporciona o es inválido
  const currentPage = parseInt(pageNumber || "1", 10) || 1;

  // Llama al servicio con los filtros y la paginación
  const { records, count, hasMore } = await UserRatingService.listRatings(
    filters.tenantId,
    filters.userId,
    filters.whatsappId,
    filters.startDate,
    filters.endDate,
    currentPage // Pasa el número de página
  );

  return res.status(200).json({ records, count, hasMore });
};

// Calcular la calificación promedio con filtros
export const average = async (
  req: RatingRequest,
  res: Response
): Promise<Response> => {
  const { userId, whatsappId, startDate, endDate } = req.query;
  const { tenantId } = req.user!;

  const filters = {
    tenantId: Number(tenantId),
    userId: userId ? parseInt(userId, 10) : undefined,
    whatsappId: whatsappId ? parseInt(whatsappId, 10) : undefined,
    startDate: startDate ? new Date(startDate) : undefined,
    endDate: endDate ? new Date(endDate) : undefined
  };

  // Llama al servicio para obtener el promedio
  const averageRating = await UserRatingService.getAverage(
    filters.tenantId,
    filters.userId,
    filters.whatsappId,
    filters.startDate,
    filters.endDate
  );

  // Devuelve el resultado (el servicio ya debería manejar el caso sin calificaciones)
  return res.status(200).json(averageRating); // El servicio devuelve un objeto { average: number | null }
};
