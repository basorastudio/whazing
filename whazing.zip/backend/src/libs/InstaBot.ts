import { IgApiClient, IgLoginBadPasswordError, IgLoginInvalidUserError, IgLoginTwoFactorRequiredError, IgCheckpointError } from 'instagram-private-api';
import { IgApiClientMQTT, RealtimeClient } from 'instagram-mqtt';
import AppError from '../errors/AppError'; // Adjust path as needed
import { logger } from '../utils/logger'; // Adjust path as needed

interface Session {
    id: number | string; // Or just number/string depending on usage
    // Add other properties if the session object holds more than just the client
    ig: IgApiClientMQTT; // Holds the Instagram client
    listener?: RealtimeClient; // Holds the MQTT listener if active
}

const sessions: Session[] = [];

/**
 * Initializes an Instagram bot client for a given WhatsApp/Instagram session.
 * Handles login, state saving/loading, and MQTT connection setup.
 * @param sessionData - The session object containing credentials and ID.
 * @param retries - Number of connection retries allowed.
 * @returns Promise resolving with the initialized IgApiClientMQTT instance.
 */
export const initInstaBot = async (
    sessionData: { id: number | string; instagramUser?: string; instagramKey?: string; instagramSession?: string },
    retries = 3 // Default retries
): Promise<IgApiClientMQTT> => {
    let attempt = 0;
    while (attempt < retries) {
        try {
            let loadedState: any;
            let currentUser: any; // To store logged-in user info

            const username = sessionData.instagramUser; // Ensure '@' is not included if library handles it
            const password = sessionData.instagramKey;

            if (!username || !password) {
                throw new Error('Not credentials'); // Credenciales no proporcionadas
            }

            // Load saved session state if available
            if (sessionData.instagramSession) {
                try {
                    loadedState = JSON.parse(sessionData.instagramSession);
                } catch (parseError) {
                    logger.warn(`Failed to parse Instagram session state for ${sessionData.id}, attempting fresh login.`);
                    loadedState = null; // Force fresh login if parsing fails
                }
            }

            const ig = IgApiClientMQTT.withFbns(new IgApiClient());
            ig.state.deviceString = process.env.IG_DEVICE_STRING; // Use environment variables for device specifics
            ig.state.deviceId = process.env.IG_DEVICE_ID;
            ig.state.uuid = process.env.IG_UUID;
            ig.state.phoneId = process.env.IG_PHONE_ID;
            ig.state.adid = process.env.IG_ADID;
            ig.state.build = process.env.IG_BUILD;


            ig.id = sessionData.id; // Attach session ID for tracking

             // Set username on the client instance
            ig.state.webUserAgent = `Instagram ${process.env.IG_APP_VERSION} Android (24/7.0; 480dpi; 1080x1920; samsung; SM-G935F; hero2lte; samsungexynos8890; en_US; ${process.env.IG_APP_ID})`;

            // Set state if loaded successfully
            if (loadedState) {
                try {
                    await ig.state.deserialize(loadedState);
                    // Verify state by getting self profile
                    currentUser = await ig.account.currentUser();
                    logger.info(`Instagram session state loaded successfully for user ${currentUser.username} (ID: ${sessionData.id})`);

                } catch (stateError) {
                    logger.warn(`Failed to load Instagram session state for ${sessionData.id}, attempting fresh login: ${stateError}`);
                    loadedState = null; // Force fresh login if state is invalid
                }
            }


            // Attempt login if state wasn't loaded or was invalid
            if (!loadedState) {
                 // Simulate pre-login flow if necessary (library might handle this)
                 // await ig.simulate.preLoginFlow();
                 currentUser = await ig.account.login(username, password);
                 // await ig.simulate.postLoginFlow(); // Simulate post-login flow
                 logger.info(`Instagram login successful for user ${currentUser.username} (ID: ${sessionData.id})`);

                 // Save the newly generated state
                 const serializedState = await ig.state.serialize();
                 delete serializedState.constants; // Remove unnecessary constants
                 await sessionData.update({ instagramSession: JSON.stringify(serializedState) }); // Assuming sessionData has an update method
            }

            // Attach listener to state changes for saving
            ig.state.generateDevice(username); // Generate device specifics based on username
            process.nextTick(async () => {
                 try {
                     const serializedState = await ig.state.serialize();
                     delete serializedState.constants;
                     await sessionData.update({ instagramSession: JSON.stringify(serializedState) });
                 } catch (saveError) {
                     logger.error(`Error saving Instagram state during nextTick for ${sessionData.id}: ${saveError}`);
                 }
             });

            // --- MQTT Connection ---
            // Ensure previous listener is disconnected if reconnecting
             const existingSessionIndex = sessions.findIndex(s => s.id === sessionData.id);
             if (existingSessionIndex !== -1 && sessions[existingSessionIndex].listener) {
                  logger.info(`Disconnecting existing MQTT listener for session ${sessionData.id}`);
                  sessions[existingSessionIndex].listener?.disconnect();
             }


            await ig.fbns.connect();
             logger.info(`Instagram MQTT connected for user ${currentUser?.username || username} (ID: ${sessionData.id})`);


            // --- Store Session ---
            const newSession: Session = { id: sessionData.id, ig, listener: ig.fbns }; // Store MQTT listener

            if (existingSessionIndex === -1) {
                sessions.push(newSession);
            } else {
                sessions[existingSessionIndex] = newSession; // Update existing session
            }

            return ig; // Return the initialized client

        } catch (error: any) {
            logger.error(`initInstaBot error | Session ID: ${sessionData.id} | Attempt: ${attempt + 1} | Error: ${error}`);
             // Specific error handling
             if (error instanceof IgLoginBadPasswordError || error instanceof IgLoginInvalidUserError) {
                 logger.error(`Invalid Instagram credentials for session ${sessionData.id}`);
                 await sessionData.update({ instagramSession: '' }); // Clear invalid session
                 throw new AppError("Invalid Instagram credentials.", 401);
             } else if (error instanceof IgLoginTwoFactorRequiredError) {
                 logger.error(`Instagram Two-Factor Auth required for session ${sessionData.id}`);
                 throw new AppError("Instagram Two-Factor Auth required.", 401);
             } else if (error instanceof IgCheckpointError) {
                  logger.error(`Instagram Checkpoint required for session ${sessionData.id}`);
                  await sessionData.update({ instagramSession: '' }); // Clear session on checkpoint
                  throw new AppError("Instagram Checkpoint required. Please login via app/website.", 401);
             } else if (error.message === 'Not credentials') {
                  throw new AppError("Instagram username or password not provided.", 400);
             }


            attempt++;
            if (attempt >= retries) {
                 logger.error(`Max retries reached for initializing InstaBot session ${sessionData.id}.`);
                 throw new AppError(`Max retries reached. Error: ${error.message || error}`, 500);
            }
            // Wait before retrying
            await new Promise(resolve => setTimeout(resolve, 2000 * attempt)); // Exponential backoff?
        }
    }
    // Should not reach here if successful, but needed for TS path completion
    throw new AppError('Failed to initialize InstaBot after multiple retries.', 500);
};

/**
 * Retrieves an initialized Instagram bot client for a given ID.
 * @param id - The ID of the WhatsApp/Instagram session.
 * @returns The IgApiClientMQTT instance or undefined if not found.
 */
export const getInstaBot = (id: number | string): IgApiClientMQTT | undefined => {
    const sessionIndex = sessions.findIndex(s => s.id === id);
    if (sessionIndex !== -1) {
        return sessions[sessionIndex].ig;
    }
    return undefined;
};

/**
 * Removes and disconnects an Instagram bot session.
 * @param sessionToRemove - The session object containing the ID to remove.
 */
export const removeInstaBot = (sessionToRemove: { id: number | string }): void => {
    try {
        const sessionIndex = sessions.findIndex(s => s.id === sessionToRemove.id);
        if (sessionIndex !== -1) {
            const session = sessions[sessionIndex];
            // Disconnect MQTT listener first
            if (session.listener) {
                session.listener.disconnect();
                 logger.info(`Instagram MQTT listener disconnected for session ${sessionToRemove.id}`);
            }
            // Attempt logout from Instagram API (optional, might invalidate session state)
            // try {
            //     await session.ig.account.logout();
            //     logger.info(`Instagram account logged out for session ${sessionToRemove.id}`);
            // } catch (logoutError) {
            //     logger.error(`Error logging out Instagram account for session ${sessionToRemove.id}: ${logoutError}`);
            // }

            sessions.splice(sessionIndex, 1); // Remove session from the array
            logger.info(`InstaBot session removed for ID: ${sessionToRemove.id}`);

             // Optionally clear the saved session state in the database
             // await sessionData.update({ instagramSession: '' }); // Assuming sessionData is the db record
        } else {
             logger.warn(`Attempted to remove non-existent InstaBot session: ${sessionToRemove.id}`);
        }
    } catch (error) {
        logger.error(`Error removing InstaBot session ${sessionToRemove.id}: ${error}`);
    }
};