<template>
  <div>
    <q-card flat class="q-pa-sm q-pb-md">
      <q-card-section class="q-pa-none">
        <div class="text-subtitle2 q-mb-sm">
          {{ $t('ccFlowBuilder.enviarlocalizacao') }}
        </div>
        <!-- Location data section -->
        <div class="q-mb-md">

          <div class="row q-col-gutter-sm">
            <!-- Latitude field -->
            <div class="col-6 q-mb-sm">
              <q-input
                dense
                outlined
                required
                type="number"
                step="any"
                v-model="$attrs.element.data.latitude"
                :label="$t('ccFlowBuilder.latitude')"
              />
            </div>

            <!-- Longitude field -->
            <div class="col-6 q-mb-sm">
              <q-input
                dense
                outlined
                required
                type="number"
                step="any"
                v-model="$attrs.element.data.longitude"
                :label="$t('ccFlowBuilder.longitude')"
              />
            </div>

            <!-- Name field -->
            <div class="col-12 q-mb-sm">
              <q-input
                dense
                outlined
                required
                v-model="$attrs.element.data.name"
                :label="$t('ccFlowBuilder.nomelocal')"
              />
            </div>

            <!-- Address field -->
            <div class="col-12">
              <q-input
                dense
                outlined
                required
                v-model="$attrs.element.data.address"
                :label="$t('ccFlowBuilder.enderecolocalizacao')"
              />
            </div>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
export default {
  name: 'SendLocationField',
  data () {
    return {}
  },
  mounted () {
    // Initialize location fields if they don't exist
    if (!this.$attrs.element.data.latitude) {
      this.$attrs.element.data.latitude = ''
    }
    if (!this.$attrs.element.data.longitude) {
      this.$attrs.element.data.longitude = ''
    }
    if (!this.$attrs.element.data.name) {
      this.$attrs.element.data.name = ''
    }
    if (!this.$attrs.element.data.address) {
      this.$attrs.element.data.address = ''
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
