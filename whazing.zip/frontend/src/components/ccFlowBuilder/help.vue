<template>
  <q-dialog
    v-model="dialogVisible"
    maximized
    persistent
    class="help-dialog"
  >
    <div class="modal-backdrop" @click.self="dialogVisible = false">
      <div class="modal-content" :class="{ 'dark-mode': $q.dark.isActive }">
        <div class="modal-header">
          <h2 :class="$q.dark.isActive ? 'color-dark3' : ''">Guía de Configuración del Chatbot</h2>
          <q-btn
            icon="close"
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? 'color-dark1' : ''"
            @click="dialogVisible = false"
          />
        </div>

        <div class="modal-body">
          <!-- Menu de navegación lateral -->
          <div class="sidebar" :class="{ 'dark-mode': $q.dark.isActive }">
            <div
              v-for="(tab, index) in tabs"
              :key="index"
              class="tab-button"
              :class="{
                active: currentTab === index,
                'dark-mode': $q.dark.isActive
              }"
              @click="currentTab = index"
            >
              {{ tab.label }}
            </div>
          </div>

          <!-- Contenido de la tab seleccionada -->
          <div class="content-area">
            <div class="scrollable-content">
              <!-- Elementos Básicos -->
              <div v-if="currentTab === 0">
                <h3 :class="$q.dark.isActive ? 'color-dark3' : ''">Elementos Básicos de Configuración</h3>
                <div class="help-section">
                  <div class="item-list">
                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>1. Enviar Mensaje</strong>
                      <ul>
                        <li>Permite insertar el texto que será enviado al cliente</li>
                        <li>Soporta el uso de variables (consulte la sección de variables)</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>2. Enviar Documentos y Archivos</strong>
                      <ul>
                        <li>Funcionalidad para envío de archivos diversos</li>
                        <li>Soporta documentos, videos, audios y otros tipos</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>3. Añadir Retraso</strong>
                      <ul>
                        <li>Configure el intervalo de tiempo entre mensajes</li>
                        <li>Importante para garantizar secuencia correcta</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>4. Añadir Etiqueta</strong>
                      <ul>
                        <li>Permite marcar el contacto con etiqueta específica</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>5. Añadir Webhook (GET)</strong>
                      <ul>
                        <li>Integración con sistemas externos</li>
                        <li>Envío de información capturada en la atención</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Orden de las Interacciones -->
              <div v-if="currentTab === 1">
                <h3 :class="$q.dark.isActive ? 'color-dark3' : ''">Orden de las Interacciones</h3>
                <div class="help-section">
                  <div class="info-box" :class="{ 'dark-mode': $q.dark.isActive }">
                    <h4>Importante:</h4>
                    <ul>
                      <li>Los números indican la secuencia exacta de ejecución</li>
                      <li>Use siempre retraso entre múltiples mensajes</li>
                      <li>El orden de ejecución sigue la numeración configurada</li>
                    </ul>
                  </div>
                </div>
              </div>

              <!-- Condiciones -->
              <div v-if="currentTab === 2">
                <h3 :class="$q.dark.isActive ? 'color-dark3' : ''">Configuración de Condiciones</h3>
                <div class="help-section">
                  <h4>Tipos de Condiciones (por prioridad):</h4>

                  <div class="item-list">
                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>1. Dentro/Fuera del Horario</strong>
                      <ul>
                        <li>Funciona solo en la etapa "¡Bienvenida!"</li>
                        <li>Posición: Inicio de las condiciones</li>
                        <li>Dentro del Horario: Activa en horario comercial</li>
                        <li>Fuera del Horario: Activa fuera del horario comercial</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>2. Respuestas Exactas</strong>
                      <ul>
                        <li>Ejemplo: "1" o "01"</li>
                        <li>Requiere respuesta idéntica a la configurada</li>
                        <li>No acepta variaciones como "quiero 1"</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>3. Contiene Exacto</strong>
                      <ul>
                        <li>Busca palabras específicas en la frase</li>
                        <li>Ejemplo: "quiero comprar" en "Yo quiero comprar unos zapatos"</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>4. Contiene</strong>
                      <ul>
                        <li>Reconoce partes de palabras</li>
                        <li>Ejemplo: "compra" encuentra "comprando"</li>
                      </ul>
                    </div>

                    <div class="help-item" :class="{ 'dark-mode': $q.dark.isActive }">
                      <strong>5. Cualquier Respuesta</strong>
                      <ul>
                        <li>Posición: Siempre por último</li>
                        <li>Captura respuestas no previstas</li>
                      </ul>
                    </div>

                    <div class="warning-box" :class="{ 'dark-mode': $q.dark.isActive }">
                      <h4>Respuestas Inesperadas</h4>
                      <p>Mensaje predeterminado cuando ninguna condición se cumple:</p>
                      <pre>"¡Disculpe! No entendí su respuesta. ¡Intentemos nuevamente! Elija una opción válida."</pre>
                      <p><em>Este mensaje puede ser personalizado en las configuraciones</em></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </q-dialog>
</template>

<script>
export default {
  name: 'HelpDialog',
  data () {
    return {
      dialogVisible: false,
      currentTab: 0,
      tabs: [
        { label: 'Elementos Básicos' },
        { label: 'Orden de las Interacciones' },
        { label: 'Condiciones' }
      ]
    }
  },
  methods: {
    init () {
      this.dialogVisible = true
    }
  }
}
</script>

<style scoped>
.help-dialog {
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background: white;
  border-radius: 8px;
  width: 90%;
  max-width: 1200px;
  height: 90vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  color: #333;
}

.modal-content.dark-mode {
  background: #1d1d1d;
  color: white;
}

.modal-header {
  padding: 16px 24px;
  border-bottom: 1px solid #eee;
  background: inherit;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h2 {
  color: #333;
}

.modal-content.dark-mode .modal-header h2 {
  color: white;
}

.modal-body {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.sidebar {
  width: 200px;
  border-right: 1px solid #eee;
  background: #f8f9fa;
  padding: 16px 0;
}

.sidebar.dark-mode {
  background: #2d2d2d;
  border-right-color: #333;
}

.tab-button {
  padding: 12px 24px;
  cursor: pointer;
  transition: all 0.3s;
  color: #333;
}

.tab-button.dark-mode {
  color: white;
}

.tab-button:hover {
  background: #ecf5ff;
}

.tab-button.dark-mode:hover {
  background: #3d3d3d;
}

.tab-button.active {
  background: var(--q-cor2);
  color: white !important;
}

.tab-button.active.dark-mode {
  background: var(--q-cor1);
}

.content-area {
  flex: 1;
  overflow: hidden;
}

.scrollable-content {
  height: 100%;
  overflow-y: auto;
  padding: 24px;
}

.help-section {
  margin-bottom: 30px;
}

h3 {
  color: #333;
}

.dark-mode h3 {
  color: white;
}

h4 {
  color: #333;
}

.dark-mode h4 {
  color: white;
}

.item-list {
  display: grid;
  gap: 20px;
}

.help-item {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  border-left: 4px solid var(--q-cor1);
}

.help-item.dark-mode {
  background: #2d2d2d;
  border-left-color: var(--q-cor1);
}

.help-item strong {
  color: #333;
}

.help-item.dark-mode strong {
  color: white;
}

.info-box {
  background: #ecf5ff;
  padding: 20px;
  border-radius: 8px;
  border: 1px solid #d9ecff;
  margin: 20px 0;
}

.info-box.dark-mode {
  background: #2d2d2d;
  border-color: #333;
}

.warning-box {
  background: #fff9f2;
  padding: 20px;
  border-radius: 8px;
  border: 1px solid #faecd8;
  margin-top: 30px;
}

.warning-box.dark-mode {
  background: #2d2d2d;
  border-color: #333;
}

.warning-box pre {
  background: #fff;
  padding: 15px;
  border-radius: 4px;
  margin: 10px 0;
  border: 1px solid #faecd8;
  color: #333;
}

.warning-box.dark-mode pre {
  background: #1d1d1d;
  border-color: #333;
  color: white;
}

ul {
  margin: 0;
  padding-left: 20px;
}

li {
  margin: 8px 0;
  color: #333;
}

.dark-mode li {
  color: white;
}

@media (max-width: 768px) {
  .modal-content {
    width: 95%;
    height: 95vh;
  }

  .sidebar {
    width: 150px;
  }

  .tab-button {
    padding: 12px 16px;
  }

  .scrollable-content {
    padding: 16px;
  }

  .help-item {
    padding: 16px;
  }
}
</style>
