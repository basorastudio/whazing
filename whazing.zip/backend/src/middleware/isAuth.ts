/**
 * Middleware para autenticar usuarios regulares usando un token JWT
 * en el header Authorization. También maneja la validación de sesión única si está habilitada.
 */
import { Response, NextFunction } from "express";
import { verify } from "jsonwebtoken";
import User from "../models/User";
import AppError from "../errors/AppError";
import authConfig from "../config/auth";
import { AuthRequest } from "./interfaces/AuthRequest"; // Importa la interfaz

interface TokenPayload {
  id: string | number; // Tipo del ID del usuario
  profile: string;
  tenantId: string | number; // Tipo del tenantId
  loginDate?: string; // Fecha de login incluida en el token (opcional)
  iat: number;
  exp: number;
}

const isAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  const authHeader = req.headers.authorization;

  // Verifica si el header Authorization existe
  if (!authHeader) {
    throw new AppError("Token no proporcionado.", 401); // 401 Unauthorized
  }

  // Divide el header ("Bearer TOKEN_AQUI")
  const [, token] = authHeader.split(" ");

  try {
    // Verifica el token JWT
    const decoded = verify(token, authConfig.secret);
    const { id, profile, tenantId, loginDate } = decoded as TokenPayload;

    // Busca el usuario en la base de datos para validar existencia y posible sesión única
    // Selecciona solo los campos necesarios
    const user = await User.findByPk(id, {
      attributes: ["id", "profile", "tenantId", "lastLogin", "singleLogin"] // Asume que User tiene estas propiedades
    });

    // Si el usuario no se encuentra en la BD (pudo ser eliminado después de emitir el token)
    if (!user) {
      throw new AppError("Usuario no encontrado.", 401); // Considerar 401 ya que el token referencia a un usuario inexistente
    }

    // Verifica la sesión única si está habilitada para este usuario
    // Asume que `authConfig.singleLogin` es un booleano global y `user.singleLogin` es específico del usuario
    if (authConfig.singleLogin && user.singleLogin) {
      // Compara la fecha de login del token con la última fecha de login almacenada en la BD
      // Asegúrate de que 'loginDate' esté en el token y 'lastLogin' en la BD
      if (loginDate && user.lastLogin) {
        const tokenLoginDate = new Date(loginDate);
        const dbLastLoginDate = new Date(user.lastLogin);

        // Si las fechas no coinciden exactamente (o tokenLoginDate es anterior),
        // significa que hubo un login posterior, invalidando esta sesión.
        // Se necesita una comparación precisa, quizás comparar milisegundos.
        // ¡Cuidado con la precisión de las fechas y zonas horarias!
        // Una comparación simple de < podría ser suficiente si lastLogin siempre se actualiza.
        if (tokenLoginDate.getTime() < dbLastLoginDate.getTime()) {
          throw new AppError(
            "Sesión invalidada por nuevo inicio de sesión.", // Mensaje original traducido
            401 // Unauthorized
          );
        }
      } else {
        // Podría lanzar un error si falta alguna fecha necesaria para la validación
        console.warn(
          `Validación de sesión única no pudo completarse para usuario ${id}: falta loginDate en token o lastLogin en BD.`
        );
        // Considerar lanzar un error aquí si esta validación es crítica
        // throw new AppError("Error al validar sesión.", 401);
      }
    }

    // Si todo está bien, adjunta la información del usuario al objeto request
    req.user = {
      id,
      profile,
      tenantId,
      // Puedes añadir más propiedades si son necesarias en controladores posteriores
      email: user.email, // Asumiendo que el modelo User tiene email
      loginDate: loginDate ? new Date(loginDate) : undefined // Opcional, añadirlo si es útil
    };

    // Pasa al siguiente middleware/controlador
    return next();
  } catch (err) {
    // Manejo específico de errores de JWT y otros
    if (err instanceof AppError) {
      // Si ya es un AppError (lanzado desde la validación de sesión única o usuario no encontrado)
      throw err;
    } else if (
      err.name === "JsonWebTokenError" ||
      err.name === "TokenExpiredError"
    ) {
      // Si es un error de verificación de JWT (inválido, expirado)
      throw new AppError("Token inválido.", 401); // 401 Unauthorized
    } else {
      // Otros errores inesperados
      console.error("Error inesperado en middleware isAuth:", err);
      throw new AppError(
        "Error interno del servidor durante la autenticación.",
        500
      );
    }
  }
};

export default isAuth; // Exportación default
