import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'userId' column to the 'Whatsapps' table as a foreign key
    await queryInterface.addColumn(
      'Whatsapps', // Table name
      'userId',    // New column name
      {
        type: DataTypes.INTEGER,
        references: {
          model: 'Users', // References the 'Users' table
          key: 'id',
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL', // If the referenced User is deleted, set userId to NULL
        allowNull: true,      // Allow null because onDelete is SET NULL
        defaultValue: null,   // Default value is null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'userId' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps', // Table name
      'userId'     // Column name to remove
    );
  }
};

export = migration;