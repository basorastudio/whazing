import mustache from 'mustache';
import ContactCustomField from '../models/ContactCustomField'; // Assuming model path
import Queue from '../models/Queue'; // Assuming model path
import User from '../models/User'; // Assuming model path
import { logger } from '../utils/logger'; // Assuming logger path

// Define basic types for Contact and Ticket or import them if available
interface ContactType {
    id: number | string;
    name?: string;
    number?: string;
    email?: string;
    // Add other relevant contact properties
}

interface TicketType {
    id: number | string;
    queueId?: number | string | null;
    userId?: number | string | null;
    protocol?: string | null;
    queue?: { name?: string } | null; // Nested queue info
    user?: { name?: string, email?: string } | null; // Nested user info
    save: () => Promise<TicketType>; // Assuming a save method if protocol is generated
    // Add other relevant ticket properties
}

interface Greetings {
    [lang: string]: {
        morning: string;
        afternoon: string;
        evening: string;
        dawn: string;
    };
}

const ptGreetings = { morning: 'Bom dia', afternoon: 'Boa tarde', evening: 'Boa noite', dawn: 'Boa madrugada' };
const enGreetings = { morning: 'Good morning', afternoon: 'Good afternoon', evening: 'Good night', dawn: 'Good dawn' };
const esGreetings = { morning: 'Buenos días', afternoon: 'Buenas tardes', evening: 'Buenas noches', dawn: 'Buena madrugada' };

const greetings: Greetings = {
    pt: ptGreetings,
    en: enGreetings,
    es: esGreetings
};

const firstName = (contact?: ContactType): string => {
    if (contact?.name) {
        const nameParts = contact.name.split(' ');
        return nameParts[0] || ''; // Return the first part
    }
    return '';
};

export const date = (): string => {
    const now = new Date();
    const day = ('0' + now.getDate()).slice(-2);
    const month = ('0' + (now.getMonth() + 1)).slice(-2); // Month is 0-indexed
    const year = now.getFullYear().toString();
    return `${day}-${month}-${year}`; // Changed format to DD-MM-YYYY
};

export const hour = (): string => {
    const now = new Date();
    const hours = ('0' + now.getHours()).slice(-2);
    const minutes = ('0' + now.getMinutes()).slice(-2);
    const seconds = ('0' + now.getSeconds()).slice(-2);
    return `${hours}:${minutes}:${seconds}`;
};

export const renderMustache = async (
    message: string | null | undefined,
    contact: ContactType,
    ticket?: TicketType | null // Ticket is optional
): Promise<string> => {

    if (!message) {
        return ''; // Return empty string if message is null or undefined
    }

    const now = new Date();
    const currentHour = now.getHours();

    let ptGreeting: string = '';
    let msgGreeting: string = ''; // Variable for the main greeting in the message context (default Portuguese)
    let enGreeting: string = '';
    let esGreeting: string = '';

    // Determine greetings based on time
    if (currentHour >= 5 && currentHour < 12) { // Morning 5 AM to 11:59 AM
        ptGreeting = greetings.pt.morning;
        msgGreeting = greetings.pt.morning;
        enGreeting = greetings.en.morning;
        esGreeting = greetings.es.morning;
    } else if (currentHour >= 12 && currentHour < 18) { // Afternoon 12 PM to 5:59 PM
        ptGreeting = greetings.pt.afternoon;
        msgGreeting = greetings.pt.afternoon;
        enGreeting = greetings.en.afternoon;
        esGreeting = greetings.es.afternoon;
    } else if (currentHour >= 18 && currentHour < 24) { // Evening 6 PM to 11:59 PM
        ptGreeting = greetings.pt.evening;
        msgGreeting = greetings.pt.evening;
        enGreeting = greetings.en.evening;
        esGreeting = greetings.es.evening;
    } else { // Dawn 0 AM to 4:59 AM
        ptGreeting = greetings.pt.dawn;
        msgGreeting = greetings.pt.dawn;
        enGreeting = greetings.en.dawn;
        esGreeting = greetings.es.dawn;
    }

    let queueName: string = '';
    if (ticket?.queueId) {
        // Attempt to get queue name from ticket object first
        queueName = ticket.queue?.name || '';
        // If not directly available, fetch from DB
        if (!queueName) {
            const queue = await Queue.findByPk(ticket.queueId);
            queueName = queue ? queue.name : '';
        }
    }

    let userName: string = '';
    let userEmail: string = '';
    if (ticket?.userId) {
         // Attempt to get user info from ticket object first
         userName = ticket.user?.name || '';
         userEmail = ticket.user?.email || '';
         // If not directly available, fetch from DB
         if (!userName) {
            const user = await User.findByPk(ticket.userId);
            userName = user ? user.name : '';
            userEmail = user ? user.email : '';
        }
    }

    // Generate protocol if needed and not present
    let protocol = ticket?.protocol || null;
    if (message.includes('{{protocol}}') && !protocol && ticket) {
        const year = now.getFullYear().toString();
        const month = ('0' + (now.getMonth() + 1)).slice(-2);
        const day = ('0' + now.getDate()).slice(-2);
        const minutes = ('0' + now.getMinutes()).slice(-2);
        const seconds = ('0' + now.getSeconds()).slice(-2);
        // Simple protocol generation: YYYYMMDDHHMMSS + ticket ID
        protocol = `${year}${month}${day}${String(currentHour)}${minutes}${seconds}${ticket.id}`;
        try {
            ticket.protocol = protocol;
            await ticket.save(); // Save the updated ticket with the protocol
        } catch (saveError) {
             logger.error("Error al guardar el ticket con el protocolo generado:", saveError);
            // Decide how to handle the error, maybe proceed without saving
        }

    }

    // Fetch custom fields for the contact
    const customFieldsResult = await ContactCustomField.findAll({
        where: { contactId: contact.id }
    });

    const customFields: { [key: string]: string } = {};
    customFieldsResult.forEach(cf => {
        if (cf.name) { // Ensure name is not null/undefined
             customFields[cf.name] = cf.value || ''; // Use empty string for null values
        }
    });

    const view = {
        firstName: firstName(contact),
        name: contact.name || '',
        phoneNumber: contact.number || '',
        email: contact.email || '',
        greeting: msgGreeting, // Main greeting for the message
        ms: msgGreeting,       // Alias for ptGreeting? Retained original name 'ms'
        greetingEn: enGreeting,
        greetingEs: esGreeting,
        ticket_id: ticket?.id || '',
        protocol: protocol || '', // Use generated or existing protocol
        hour: hour(),
        date: date(),
        fila: queueName, // Spanish for 'queue'
        queue: queueName, // Keep original name 'queue' as well
        userEmail: userEmail,
        user: userName,
        ...customFields // Spread custom fields into the view object
    };

    try {
        return mustache.render(message, view);
    } catch (renderError) {
        logger.error("Error al renderizar el mensaje con Mustache:", renderError);
        return message; // Return original message on render error
    }
};