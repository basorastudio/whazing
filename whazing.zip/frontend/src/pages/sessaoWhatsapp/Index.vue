<template>
  <div class="full-width">
    <q-card flat class="no-shadow">
      <q-tabs
        v-model="tab"
        dense
        align="justify"
      >
        <q-tab name="Canais" :label="$t('canais.canaisComunicacao')" />
        <q-tab name="Api" :label="$t('api.api')" v-if="userProfile === 'admin'"/>
      </q-tabs>
      <q-separator />

      <q-tab-panels v-model="tab" animated>
        <q-tab-panel name="Canais" class="q-pa-none">
          <canais/>
        </q-tab-panel>

        <q-tab-panel name="Api" class="q-pa-none">
          <api/>
        </q-tab-panel>
      </q-tab-panels>
    </q-card>
  </div>
</template>

<script>
import canais from './IndexChannel.vue'
import api from './api/Index.vue'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  data () {
    return {
      tab: 'Canais',
      splitterModel: 20,
      userProfile: 'user'
    }
  },
  components: {
    canais,
    api
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    }
  },
  mounted () {
    this.loadColors()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>
