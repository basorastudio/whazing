// --- START OF FILE PlanController.ts ---

import type { Request, Response } from "express";
import * as Yup from "yup";

import AppError from "../errors/AppError"; // Assuming path
import FindAllPlanService from "../services/PlanServices/FindAllPlanService"; // Assuming path
import DeletePlanService from "../services/PlanServices/DeletePlanService"; // Assuming path
import CreatePlanService from "../services/PlanServices/CreatePlanService"; // Assuming path
import UpdatePlanService from "../services/PlanServices/UpdatePlanService"; // Assuming path

export const listPublic = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const plans = await FindAllPlanService(true); // Pass true to indicate public listing
    return res.status(200).json(plans);
  } catch (error: any) {
    console.error("Error fetching plans:", error); // Keep original log structure
    throw new AppError("Error fetching plans", 500); // Keep original error message structure
  }
};

export const list = async (req: Request, res: Response): Promise<Response> => {
  const plans = await FindAllPlanService(false); // Pass false for non-public listing
  return res.status(200).json(plans);
};

export const remove = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { id } = req.params;
  const result = await DeletePlanService(id); // Pass id as string or number based on service expectation
  return res.status(200).json(result); // Assuming service returns something or status is enough
};

interface PlanData {
  name: string;
  maxUsers?: number; // Optional based on schema
  maxConnections?: number; // Optional
  value?: number; // Optional
  isPublic?: boolean; // Optional
  group?: boolean; // Optional
  campaign?: boolean; // Optional
  integrations?: boolean; // Optional
  // Add other fields as necessary
}

export const store = async (req: Request, res: Response): Promise<Response> => {
  const planData = req.body as PlanData;

  const schema = Yup.object().shape({
    name: Yup.string().required()
    // Add validation for other fields if necessary
    // maxUsers: Yup.number().optional(),
    // maxConnections: Yup.number().optional(),
    // value: Yup.number().optional(),
    // isPublic: Yup.boolean().optional(),
    // etc.
  });

  try {
    await schema.validate(planData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  const plan = await CreatePlanService(planData);
  return res.status(201).json(plan);
};

export const update = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const planData = req.body as PlanData & { id: string | number }; // Include ID for update

  const schema = Yup.object().shape({
    id: Yup.mixed().required(), // ID is required for update
    name: Yup.string().optional() // Name is optional for update, or required() if needed
    // Add optional validation for other updatable fields
    // maxUsers: Yup.number().optional(),
    // maxConnections: Yup.number().optional(),
    // value: Yup.number().optional(),
    // isPublic: Yup.boolean().optional(),
  });

  try {
    await schema.validate(planData);
  } catch (err: any) {
    throw new AppError(err.message);
  }

  // Extract ID and data separately if service expects it that way
  // const { id, ...dataToUpdate } = planData;
  // const updatedPlan = await UpdatePlanService(id, dataToUpdate);

  // Or if service expects the whole object:
  const updatedPlan = await UpdatePlanService(planData);

  return res.status(200).json(updatedPlan);
};

// --- END OF FILE PlanController.ts ---
