import request from 'src/service/request'

/**
 * Servicio para manejar las notificaciones de recordatorio de tareas
 */

/**
 * Obtiene todas las tareas con recordatorios pendientes
 */
export function ListarTarefasComRecordatorio () {
  return request({
    url: '/tasks/reminders',
    method: 'get'
  })
}

/**
 * Marca un recordatorio como enviado
 */
export function MarcarRecordatorioEnviado (taskId) {
  return request({
    url: `/tasks/${taskId}/reminder-sent`,
    method: 'put'
  })
}

/**
 * Envía una notificación al usuario responsable de la tarea
 */
export function EnviarNotificacionRecordatorio (data) {
  return request({
    url: '/tasks/send-reminder',
    method: 'post',
    data
  })
}