class FormatMask {
  setPhoneFormatMask(phoneToFormat) {
    if (!phoneToFormat || phoneToFormat.length < 12) {
      return
    }

    const number = ('' + phoneToFormat).replace(/\D/g, '')

    if (number.length <= 12) {
      const phoneNumberFormatted = number.match(/^(\d{1})(\d{3})(\d{3})(\d{4})$/)
      return (
        '+' +
        phoneNumberFormatted[1] +
        ' (' +
        phoneNumberFormatted[2] +
        ') ' +
        phoneNumberFormatted[3] +
        '-' +
        phoneNumberFormatted[4]
      )
    } else if (number.length === 13) {
      const phoneNumberFormatted = number.match(/^(\d{1})(\d{3})(\d{3})(\d{4})$/)
      return (
        '+' +
        phoneNumberFormatted[1] +
        ' (' +
        phoneNumberFormatted[2] +
        ') ' +
        phoneNumberFormatted[3] +
        '-' +
        phoneNumberFormatted[4]
      )
    }

    return null
  }

  removeMask(number) {
    const filterNumber = number.replace(/\D/g, '')
    return filterNumber
  }

  maskPhonePattern(phoneNumber) {
    if (phoneNumber.length < 13) {
      return '+1 (809) 999 9999'
    } else {
      return '+1 (809) 9999 9999'
    }
  }
}

export { FormatMask }

const formatSerializedId = (serializedId) => {
  const formatMask = new FormatMask()
  const number = serializedId?.replace('@c.us', '')

  return formatMask.setPhoneFormatMask(number)?.replace('+1', '🇩🇴')
}

export default formatSerializedId
