/**
 * Middleware para verificar si el usuario tiene perfil 'admin'.
 */
import { Response, NextFunction } from "express";
import AppError from "../errors/AppError"; // Asumiendo que AppError es la exportación default
import User from "../models/User";       // Asumiendo que User es la exportación default y tiene findByPk
import { AuthRequest } from "./interfaces/AuthRequest"; // Importa la interfaz definida arriba o desde tu archivo de tipos

const isAdmin = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  // Asume que req.user.id está disponible después de un middleware de autenticación previo (ej. isAuth)
  if (!req.user?.id) {
     // Podrías lanzar un error diferente aquí si el usuario no está autenticado en absoluto
    throw new AppError("Autenticación requerida.", 401);
  }

  // Busca el usuario por su ID para obtener el perfil
  const user = await User.findByPk(req.user.id);

  if (!user) {
      throw new AppError("Usuario no encontrado.", 404); // O manejar como un error de autenticación si prefieres
  }

  const profile = user.profile; // Asume que el modelo User tiene una propiedad 'profile'

  // Verifica si el perfil del usuario NO es 'admin'
  if (profile !== "admin") {
    // Si no es admin, lanza un error de acceso no permitido (Forbidden)
    throw new AppError("Acceso no permitido", 403); // 403 Forbidden
  }

  // Si es admin, pasa al siguiente middleware o controlador
  return next();
};

export default isAdmin; // Exportación default como en el original