import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'messageId' column to the 'TicketNotes' table
    // Link a note to a specific message in the ticket conversation.
    await queryInterface.addColumn(
      'TicketNotes', // Table name
      'messageId',   // New column name
      {
        type: DataTypes.STRING, // Assuming message IDs are strings
        allowNull: true,        // Allow null (note might not be linked to a specific message)
        defaultValue: null,
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'messageId' column from the 'TicketNotes' table
    await queryInterface.removeColumn(
      'TicketNotes', // Table name
      'messageId'    // Column name to remove
    );
  }
};

export = migration;