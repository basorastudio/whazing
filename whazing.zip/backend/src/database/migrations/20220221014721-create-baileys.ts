// --- START OF FILE 20220221014721-create-baileys.ts ---

'use strict';
import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Baileys'; // Table name from original code
        const tableDefinition = {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true, // 'autoIncrem' + 'ent'
                primaryKey: true,
                allowNull: false
            },
            whatsappId: { // Column name from original code
                type: DataTypes.INTEGER,
                primaryKey: true, // Original code had primaryKey: !![]
                 allowNull: false // Added allowNull: false based on primaryKey
                 // Missing references to Whatsapps table if it's a foreign key
            },
            chats: { // Column name from original code
                type: DataTypes.TEXT, // Assuming TEXT, original was TEXT
                allowNull: true // Changed !![] to true
            },
            contacts: { // Column name from original code
                type: DataTypes.TEXT, // Assuming TEXT, original was TEXT
                allowNull: true // Changed !![] to true
            },
            createdAt: {
                type: DataTypes.DATE,
                allowNull: false
            },
            updatedAt: {
                type: DataTypes.DATE,
                allowNull: false
            }
        };
        await queryInterface.createTable(tableName, tableDefinition);
        // Note: The original migration defined `whatsappId` as part of a composite primary key
        // along with `id`. This is unusual. Typically, `id` would be the sole primary key,
        // and `whatsappId` would be a foreign key. If `whatsappId` is indeed part of the PK,
        // the definition above is correct based on the original code.
        // If it should be a foreign key instead, the definition needs adjustment:
        // whatsappId: {
        //   type: DataTypes.INTEGER,
        //   references: { model: 'Whatsapps', key: 'id' },
        //   onUpdate: 'CASCADE', // or appropriate action
        //   onDelete: 'CASCADE', // or appropriate action
        //   allowNull: false
        // },
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        const tableName = 'Baileys';
        await queryInterface.dropTable(tableName);
    }
};

export default migration;

// --- END OF FILE 20220221014721-create-baileys.ts ---