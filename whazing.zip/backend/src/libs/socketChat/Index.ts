import { Socket } from 'socket.io';

// Define structure for user state within a tenant room
interface UserState {
    sockets: string[]; // Array of socket IDs associated with the user
    user: any; // User details (use a specific User interface if available)
}

// Define structure for a tenant's room state
interface TenantRoomState {
    usersOnline: { [userId: string]: UserState };
    idleUsers: { [userId: string]: UserState };
    sockets: Socket[]; // Maybe store actual socket instances? Or just IDs? Original was unclear. Storing instances is less common. Let's stick to what Chat.js implies: mapping users to socket IDs.
    // Let's adjust based on how Chat.js uses it: usersOnline maps userId to UserState.
    // Sockets array seems redundant if tracked within usersOnline.
    // idleUsers also seems redundant if user status is tracked elsewhere.
    // Simplifying based on apparent usage:
    // usersOnline: { [userId: string]: UserState };
    // idleUsers map might not be needed if status is tracked on User object.
}

// Define the main shared state structure
interface SharedState {
    [tenantRoomKey: string]: TenantRoomState | undefined; // Key is like 'tenant_XXX'
}

// Initialize the shared state object
export const shared: SharedState = {};

// Note: The original file had some void assignments after the export.
// These are likely remnants of obfuscation or incomplete code and have been removed.
// The primary purpose seems to be exporting the 'shared' object.