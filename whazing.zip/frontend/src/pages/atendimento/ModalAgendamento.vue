<template>
  <q-dialog
    persistent
    :value="modalAgendamento"
    @hide="fecharModal"
    @show="abrirModal"
  >
    <q-card class="q-pa-md modal-container container-rounded-10" style="max-width: 600px;">
      <q-overlay v-if="loading" class="bg-primary">
        <q-spinner color="white" size="50px" />
      </q-overlay>

      <q-card-section class="row items-center justify-between q-my-sm q-px-none">
        <div class="text-h6 text-center font-family-main col">
          {{ $t('modalAgendamento.titulo') }}
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <q-card-section class="q-pa-sm container-border container-rounded-10">
        <div class="text-h6 font-family-main q-mb-sm">
          {{ $t('modalAgendamento.mensagem.titulo') }}
        </div>
        <div class="row items-center">
          <div class="col-xs-3 col-sm-2 col-md-1">
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-emoticon-happy-outline" />
              <q-tooltip>{{ $t('general.emoji') }}</q-tooltip>
              <q-menu anchor="top right" self="bottom middle" :offset="[5, 40]">
                <VEmojiPicker
                  style="width: 40vw"
                  :showSearch="true"
                  :emojisByRow="20"
                  labelSearch="Localizar..."
                  lang="pt-BR"
                  @select="onInsertSelectEmoji"
                />
              </q-menu>
            </q-btn>
            <q-btn round flat class="q-ml-sm">
              <q-icon class="full-width color-light1" :class="{'full-width color-dark1' : $q.dark.isActive}" size="2em" name="mdi-variable" />
              <q-tooltip>{{ $t('general.variaveis') }}</q-tooltip>
              <q-menu touch-position>
                <q-list dense style="min-width: 100px">
                  <q-item
                    v-for="variavel in variaveis"
                    :key="variavel.label"
                    clickable
                    @click="onInsertSelectVariable(variavel.value)"
                    v-close-popup
                  >
                    <q-item-section>{{ variavel.label }}</q-item-section>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>
          </div>
          <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm q-mt-sm">
            <textarea
              ref="inputEnvioMensagem"
              :disabled="audiogravado"
              style="min-height: 15vh; max-height: 15vh;"
              class="q-pa-sm bg-white full-width"
              :placeholder="$t('general.Enteryourmessage')"
              :value="agendamento.mensagem"
              @input="(v) => agendamento.mensagem = v.target.value"
            />
          </div>
        </div>

        <div class="col-xs-8 col-sm-10 col-md-11 q-pl-sm q-mt-md row items-center">
          <!-- Microphone button -->
          <q-btn
            round
            flat
            :color="isRecordingAudio ? 'negative' : 'primary'"
            @click="handleAudioRecording"
            class="color-light1 q-ml-sm"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
          >
            <q-icon
              :name="isRecordingAudio ? 'stop' : 'mic'"
              size="2em"
            />
            <q-tooltip>
              {{ isRecordingAudio ? $t('general.audio.parar') : $t('general.audio.gravar') }}
            </q-tooltip>
          </q-btn>

          <q-btn
            v-if="agendamento.anexo"
            round
            flat
            color="negative"
            @click="clearAttachment"
            class="q-ml-sm color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
          >
            <q-icon name="delete" size="2em" />
            <q-tooltip>
              {{ $t('general.audio.limpar') }}
            </q-tooltip>
          </q-btn>
          <!-- File upload button - hidden while recording -->
          <q-file
            v-if="!isRecordingAudio"
            dense
            outlined
            v-model="agendamento.anexo"
            :label="$t('general.anexo')"
            filled
            class="col"
          />

          <!-- Recording Timer -->
          <RecordingTimer
            v-if="isRecordingAudio"
            class="q-ml-sm"
          />
        </div>

        <div v-if="agendamento.anexo && audioBlobUrl" class="col-12 q-mt-md">
          <audio
            class="q-mt-md full-width"
            controls
            ref="audioPlayer"
            controlsList="download playbackrate volume">
            <source :src="audioBlobUrl" type="audio/mp3" />
            Seu navegador não suporta o elemento de áudio.
          </audio>
        </div>

        <div class="text-h6 font-family-main q-mb-sm q-mt-sm">
          {{ $t('modalAgendamento.agendamento.titulo') }}
        </div>
        <div class="row q-col-gutter-sm">
          <div class="col-xs-12 col-md-6">
            <q-select :options="schedule.options" v-model="schedule.selected" map-options outlined @input="onSelectSchedule" />
          </div>
          <div class="col-xs-12 col-md-6">
            <q-datetime-picker
              outlined
              stack-label
              :label="$t('modalAgendamento.agendamento.dataHora')"
              mode="datetime"
              v-model="agendamento.dataParaEnviar"
              format24h
              :readonly="schedule.selected.value !== 'custom'"
            />
          </div>
          <div class="full-width q-mt-sm">
            <q-checkbox v-model="agendamento.repetir" :label="$t('modalAgendamento.repeticao.repetir')" />
            <q-select
              v-if="agendamento.repetir"
              :options="periodo.options"
              v-model="agendamento.periodo"
              map-options
              outlined
            />
            <q-input
              v-if="agendamento.repetir"
              outlined
              :label="$t('modalAgendamento.repeticao.numero')"
              type="number"
              v-model="agendamento.repeticao"
            />
          </div>
        </div>
      </q-card-section>

      <q-card-actions align="right" class="q-mt-sm">
        <q-btn :label="$t('general.cancelar')" color="negative" v-close-popup class="q-mr-sm btn-rounded-50" />
        <q-btn
          :loading="loading"
          :disable="loading"
          :label="$t('general.salvar')"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          @click="handleAgendamento"
          icon="eva-save-outline"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { CriarAgendamento } from 'src/service/agendamentos'
import { add, format } from 'date-fns'
import { VEmojiPicker } from 'v-emoji-picker'

import RecordingTimer from './RecordingTimer'
import MicRecorder from 'mic-recorder-to-mp3'

const Mp3Recorder = new MicRecorder({
  bitRate: 128,
  encodeAfterRecord: true
})

export default {
  name: 'ModalAgendamento',
  components: { VEmojiPicker, RecordingTimer },
  props: {
    modalAgendamento: {
      type: Boolean,
      default: false
    },
    ticketFocado: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      isRecordingAudio: false,
      audioBlob: null,
      audiogravado: false,
      audioBlobUrl: null,
      contatos: [],
      variaveis: [
        { label: this.$t('variaveis.nomeCompleto'), value: '{{name}}' },
        { label: this.$t('variaveis.nome'), value: '{{firstName}}' },
        { label: this.$t('variaveis.saudacaoPT'), value: '{{greeting}}' },
        { label: this.$t('variaveis.saudacaoEN'), value: '{{greetingEn}}' },
        { label: this.$t('variaveis.saudacaoES'), value: '{{greetingEs}}' },
        { label: this.$t('variaveis.telefone'), value: '{{phoneNumber}}' },
        { label: this.$t('variaveis.email'), value: '{{email}}' },
        { label: this.$t('variaveis.hora'), value: '{{hour}}' },
        { label: this.$t('variaveis.data'), value: '{{date}}' }
      ],
      periodo: {
        selected: { label: this.$t('modalAgendamento.repeticao.periodo.label'), value: '' },
        options: [
          { label: this.$t('modalAgendamento.repeticao.periodo.mensal'), value: 'mensal' },
          { label: this.$t('modalAgendamento.repeticao.periodo.semanal'), value: 'semanal' },
          { label: this.$t('modalAgendamento.repeticao.periodo.quinzenal'), value: 'quinzena' },
          { label: this.$t('modalAgendamento.repeticao.periodo.bimestral'), value: 'bimestral' }
        ]
      },
      schedule: {
        selected: { label: this.$t('modalAgendamento.agendamento.opcoes.personalizado'), value: 'custom', func: null },
        options: [
          { label: this.$t('modalAgendamento.agendamento.opcoes.personalizado'), value: 'custom', func: null },
          { label: this.$t('modalAgendamento.agendamento.opcoes.trintaMinutos'), value: '30_mins', func: () => add(new Date(), { minutes: 30 }) },
          { label: this.$t('modalAgendamento.agendamento.opcoes.amanha'), value: 'amanha', func: () => add(new Date(), { days: 1 }) },
          { label: this.$t('modalAgendamento.agendamento.opcoes.proximaSemana'), value: 'prox_semana', func: () => add(new Date(), { weeks: 1 }) }
        ]
      },
      agendamento: {
        contato: '',
        whatsapp: '',
        mensagem: '',
        anexo: null,
        dataParaEnviar: '',
        repetir: false,
        repeticao: 1,
        periodo: null
      },
      loading: false
    }
  },
  watch: {
    'agendamento.anexo': function(newVal) {
      if (newVal) {
        this.handleFileAttachment()
      }
    }
  },
  methods: {
    async handleAudioRecording () {
      if (!this.isRecordingAudio) {
        try {
          await navigator.mediaDevices.getUserMedia({ audio: true })
          await Mp3Recorder.start()
          this.isRecordingAudio = true
        } catch (error) {
          this.$q.notify({
            type: 'negative',
            message: this.$t('general.audio.erroGravacao')
          })
          this.isRecordingAudio = false
        }
      } else {
        try {
          const [, blob] = await Mp3Recorder.stop().getMp3()
          this.isRecordingAudio = false

          if (blob.size < 10000) {
            this.$q.notify({
              type: 'warning',
              message: this.$t('general.audio.audioMuitoCurto')
            })
            return
          }

          // Create file object for attachment
          const audioFile = new File([blob], `audio_${Date.now()}.mp3`, {
            type: 'audio/mp3'
          })

          // Set the audio file to agendamento.anexo
          this.agendamento.anexo = audioFile

          if (this.audioBlobUrl) {
            URL.revokeObjectURL(this.audioBlobUrl)
          }
          this.audioBlobUrl = URL.createObjectURL(blob)

          this.audiogravado = true

          this.$q.notify({
            type: 'positive',
            message: this.$t('general.audio.sucessoGravacao')
          })
        } catch (error) {
          this.$q.notify({
            type: 'negative',
            message: this.$t('general.audio.erroGravacao')
          })
        }
      }
    },
    async cancelRecording () {
      if (this.isRecordingAudio) {
        try {
          await Mp3Recorder.stop().getMp3()
          this.isRecordingAudio = false
        } catch (error) {
          console.error('Erro ao cancelar gravação:', error)
        }
      }
    },
    clearAttachment() {
      if (this.audioBlobUrl) {
        URL.revokeObjectURL(this.audioBlobUrl)
        this.audioBlobUrl = null
      }

      this.agendamento.anexo = null

      this.audiogravado = false

      this.$q.notify({
        type: 'positive',
        message: this.$t('general.audio.anexoRemovido')
      })
    },
    handleFileAttachment() {
      if (this.agendamento.anexo && this.agendamento.anexo.type.startsWith('audio/')) {
        if (this.audioBlobUrl) {
          URL.revokeObjectURL(this.audioBlobUrl)
        }
        this.audioBlobUrl = URL.createObjectURL(this.agendamento.anexo)
      } else if (this.audioBlobUrl) {
        URL.revokeObjectURL(this.audioBlobUrl)
        this.audioBlobUrl = null
      }
    },
    onInsertSelectVariable (variable) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      // get cursor's position:
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      // filter:
      if (!variable) {
        return
      }
      // insert:
      self.txtContent = this.agendamento.mensagem
      self.txtContent = tmpStr.substring(0, startPos) + variable + tmpStr.substring(endPos, tmpStr.length)
      this.agendamento.mensagem = self.txtContent
      // move cursor:
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + 1
      }, 10)
    },
    onInsertSelectEmoji (emoji) {
      const self = this
      var tArea = this.$refs.inputEnvioMensagem
      var startPos = tArea.selectionStart,
        endPos = tArea.selectionEnd,
        cursorPos = startPos,
        tmpStr = tArea.value
      if (!emoji.data) {
        return
      }
      self.txtContent = this.agendamento.mensagem
      self.txtContent = tmpStr.substring(0, startPos) + emoji.data + tmpStr.substring(endPos, tmpStr.length)
      this.agendamento.mensagem = self.txtContent
      setTimeout(() => {
        tArea.selectionStart = tArea.selectionEnd = cursorPos + emoji.data.length
      }, 10)
    },
    onSelectSchedule(newValue) {
      this.agendamento.dataParaEnviar = newValue.func ? format(newValue.func(), 'yyyy-MM-dd HH:mm') : null
    },
    fecharModal() {
      this.$emit('update:modalAgendamento', false)
    },
    abrirModal() {
      this.audiogravado = false
      this.agendamento = {
        contato: '',
        whatsapp: '',
        mensagem: '',
        anexo: null,
        dataParaEnviar: '',
        repetir: false,
        repeticao: 1,
        periodo: null
      }
    },
    async handleAgendamento() {
      const { mensagem, dataParaEnviar, periodo, repetir, repeticao, anexo } = this.agendamento

      if (!anexo && !mensagem) {
        this.$q.notify({ type: 'negative', message: this.$t('modalAgendamento.erros.mensagemNecessaria') })
        return
      }

      const contatoId = this.ticketFocado.contactId
      const whatsapp = this.ticketFocado.whatsappId
      const periodoValue = periodo ? periodo.value : null

      if (!dataParaEnviar) {
        this.$q.notify({ type: 'negative', message: this.$t('modalAgendamento.erros.camposObrigatorios') })
        return
      }

      if (repetir && (isNaN(repeticao) || repeticao > 12)) {
        this.$q.notify({ type: 'negative', message: this.$t('modalAgendamento.erros.limiteRepeticao') })
        return
      }

      this.loading = true
      try {
        const formData = new FormData()
        formData.append('repetir', repetir)
        formData.append('repeticao', repeticao)
        formData.append('contatoId', contatoId)
        formData.append('whatsapp', whatsapp)
        formData.append('mensagem', mensagem)
        formData.append('dataParaEnviar', dataParaEnviar)
        formData.append('medias', anexo)

        if (periodoValue) formData.append('periodo', periodoValue)

        if (this.ticketFocado.channel === 'hub_whatsapp') {
          this.$q.dialog({
            title: this.$t('modalAgendamento.avisoWhatsapp.titulo'),
            message: this.$t('modalAgendamento.avisoWhatsapp.mensagem'),
            persistent: true,
            ok: {
              label: this.$t('general.salvar'),
              color: 'primary'
            },
            cancel: {
              label: this.$t('general.cancelar'),
              color: 'negative'
            }
          }).onOk(() => {
            this.criarProcessoAgendamento(formData)
          })
          return
        }

        await this.criarProcessoAgendamento(formData)
      } catch (error) {
      } finally {
        this.loading = false
      }
    },
    criarProcessoAgendamento(formData) {
      return CriarAgendamento(formData)
        .then(response => {
          this.$q.notify({ type: 'positive', message: this.$t('modalAgendamento.sucesso.agendamentoCriado') })
          this.fecharModal()
          return response
        })
        .catch(error => {
          console.error(error)
          this.$q.notify({ type: 'negative', message: this.$t('modalAgendamento.erros.erroAgendamento') })
          throw error
        })
    }
  },
  beforeDestroy() {
    this.cancelRecording()

    if (this.audioBlobUrl) {
      URL.revokeObjectURL(this.audioBlobUrl)
    }
  }
}
</script>
