import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'transcriptionkey' column to the 'Whatsapps' table
    // Stores the API key for the transcription service.
    await queryInterface.addColumn(
      'Whatsapps',          // Table name
      'transcriptionkey',   // New column name
      {
        type: DataTypes.TEXT, // TEXT for potentially long API keys
        // allowNull defaults to true
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'transcriptionkey' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps',          // Table name
      'transcriptionkey'    // Column name to remove
    );
  }
};

export = migration;