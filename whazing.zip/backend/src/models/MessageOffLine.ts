import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import Contact from "./Contact";
import Message from "./Message"; // For quoted message relation
import Ticket from "./Ticket";
import User from "./User";

@Table({ freezeTableName: true })
class MessagesOffLine extends Model<MessagesOffLine> {
  // Class name based on table option

  // Getters preserved
  get mediaName(): string | null {
    return this.getDataValue("mediaName");
  }

  get mediaUrl(): string | null {
    const filename = this.getDataValue("mediaUrl");
    if (filename) {
      const { BACKEND_URL, PROXY_PORT } = process.env;
      return `${BACKEND_URL}:${PROXY_PORT}/public/${filename}`;
    }
    return null;
  }

  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Default(0)
  @Column
  ack: number;

  @Default(false)
  @Column
  read: boolean;

  @Default(false)
  @Column
  fromMe: boolean;

  @Column(DataType.TEXT) // Use TEXT for message body
  body: string;

  // Virtual fields for getters
  @Column(DataType.VIRTUAL)
  mediaName: string | null;

  @Column(DataType.VIRTUAL)
  mediaUrl: string | null;

  @Column
  mediaType: string; // Store filename/path here

  @Default(false)
  @Column
  isDeleted: boolean;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;

  @ForeignKey(() => Message) // Self-referencing FK for quoted message
  @AllowNull(true)
  @Default(null)
  @Column
  quotedMsgId: string | null; // Assuming string UUID

  @BelongsTo(() => Message, "quotedMsgId")
  quotedMsg: Message | null;

  @ForeignKey(() => Ticket)
  @Column
  ticketId: number;

  @BelongsTo(() => Ticket)
  ticket: Ticket;

  @ForeignKey(() => Contact)
  @Column
  contactId: number;

  @BelongsTo(() => Contact, "contactId") // Specify FK if needed
  contact: Contact;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;
}

export default MessagesOffLine;
