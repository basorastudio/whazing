import { io } from 'socket.io-client'

export const socketIO = () => {
  return io(process.env.URL_API, {
    reconnection: true,
    autoConnect: true,
    pingTimeout: 36000,
    reconnectionDelay: 1000,
    reconnectionAttempts: 10,
    pingInterval: 36000,
    transports: ['websocket'],
    auth: (cb) => {
      const tokenItem = localStorage.getItem('token')
      const token = tokenItem ? JSON.parse(tokenItem) : null
      // eslint-disable-next-line standard/no-callback-literal
      cb({ token })
    }
  })
}

const socket = socketIO()

socket.io.on('error', (error) => {
  console.error('error de socket', error)
})

socket.on('disconnect', (reason) => {
  console.info('socket desconectado', reason)

  if (reason === 'io server disconnect') {
    // la desconexión fue iniciada por el servidor, necesitas reconectar manualmente
    socket.connect()
  }
  // en caso contrario el socket intentará reconectar automáticamente
})

export default socket
