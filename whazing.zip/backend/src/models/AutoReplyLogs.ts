import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  AutoIncrement
} from "sequelize-typescript";
import Contact from "./Contact";
import Ticket from "./Ticket";

@Table({ freezeTableName: true })
class AutoReplyLogs extends Model<AutoReplyLogs> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  autoReplyId: string; // Assuming string ID based on original name

  @Column(DataType.TEXT)
  autoReplyName: string; // 'autoReplyName' resolved

  @Column
  stepsReplyId: string; // Assuming string ID

  @Column(DataType.TEXT)
  wordsReply: string; // Resolved

  @Column(DataType.TEXT)
  stepsReplyMessage: string; // Resolved from 'Message' likely meaning the step's message

  @ForeignKey(() => Ticket)
  @Column
  ticketId: number;

  @BelongsTo(() => Ticket)
  ticket: Ticket;

  @ForeignKey(() => Contact)
  @Column
  contactId: number;

  @BelongsTo(() => Contact, "contactId") // Specify FK if needed
  contact: Contact;

  @CreatedAt
  @Column(DataType.DATE(6))
  createdAt: Date;

  @UpdatedAt
  @Column(DataType.DATE(6))
  updatedAt: Date;
}

export default AutoReplyLogs;
