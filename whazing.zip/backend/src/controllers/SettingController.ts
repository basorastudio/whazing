// --- START OF FILE SettingController.ts ---

import type { Request, Response } from 'express';

import { getIO } from '../libs/socket'; // Assuming path
import AppError from '../errors/AppError'; // Assuming path
import UpdateSettingService from '../services/SettingServices/UpdateSettingService'; // Assuming path
import UpdateSettingGeneralService from '../services/SettingGeneralServices/UpdateSettingGeneralService'; // Assuming path for general settings
import ListSettingsService from '../services/SettingServices/ListSettingsService'; // Assuming path
import { RefreshToken as RefreshTokenSetting } from '../helpers/RefreshToken'; // Aliased import for setting token
import { RefreshToken as RefreshTokenCheck } from '../helpers/RefreshToken'; // Aliased import for check token
import CheckSettingsHelper from '../helpers/CheckSettingsHelper'; // Assuming path
import NotificameHubService from '../services/WbotNotificame/NotificameHubService'; // Assuming path

export const index = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { tenantId } = req.user; // Assuming tenantId is on user object
        const settings = await ListSettingsService(tenantId);

        // Find the specific setting for hubToken
        const hubTokenSetting = settings.find(s => s.key === 'hubToken');

        if (hubTokenSetting) {
            // Refresh the token value before sending
            const currentTokenValue = hubTokenSetting.value;
            const refreshedToken = await RefreshTokenSetting(currentTokenValue); // Use the alias
            hubTokenSetting.value = refreshedToken; // Update the value in the settings object
        }

        return res.status(200).json(settings);

    } catch (error: any) {
        console.error("Error processing settings:", error); // Keep original log format
        // Return a generic server error message
        return res.status(500).json({
            error: 'Internal server error', // Keep original error message format
            message: error.message // Include original error message if needed
        });
    }
};


interface UpdateBody {
    key: string;
    value: any; // Value can be string, boolean, number etc.
}

export const update = async (req: Request, res: Response): Promise<Response> => {
     // Permission Check: Only admin can update settings
     if (req.user.profile !== 'admin') {
         throw new AppError('ERR_NO_PERMISSION', 403); // Keep error code
     }

     const { tenantId } = req.user;
     let { value } = req.body as UpdateBody; // Make value mutable
     const { key } = req.body as UpdateBody;

     // Special check for 'CheckMsgIsGroup' and 'NotViewAssignedTickets' keys
     // Using token validation logic similar to PWA controller
     if (key === 'CheckMsgIsGroup' || key === 'NotViewAssignedTickets') {
         const tokenizSetting = 'd1a25cdd43'; // Setting specific token key
         const tokenValidSetting = await RefreshTokenSetting(tokenizSetting); // Use setting alias
         const tokenizCheck = '870a1e69ab'; // Check specific token key
         const tokenValidCheck = await RefreshTokenCheck(tokenizCheck); // Use check alias
         const checkResult = await CheckSettingsHelper(tokenValidCheck);

         if (checkResult !== tokenValidSetting) { // If tokens don't match
             throw new AppError('ERR_NO_PERMISSION', 403); // Keep error code
         }
     }

      // Special handling for 'hubToken'
      if (key === 'hubToken' && String(value)?.trim()) {
         // Verify the token with the external service
         const verificationResult = await NotificameHubService.verificarToken(value); // Assuming static method
         if (!verificationResult.isValid) { // Check if the token is not valid
             throw new AppError('Token inválido', 400); // Traducido, using 400 Bad Request
         }
         // Encrypt or transform the token before saving
         value = RefreshToken_2.criarToken(value); // Assuming criarToken encrypts/transforms
     }


     const setting = await UpdateSettingService({
         key,
         value,
         tenantId
     });

     const io = getIO();
     // Emit the setting update event
     io.emit(`${tenantId}:settings`, { // Use template literal and tenantId
         action: 'update',
         setting: setting
     });


     return res.status(200).json(setting);
 };


export const storePrivateFile = async (req: Request, res: Response): Promise<Response> => {
    const file = req.file; // Get file from multer middleware
    // tenantId might not be needed if this is a global setting, adjust if necessary
    // const { tenantId } = req.user;

    if (!file) {
        throw new AppError('Ningún archivo enviado', 400); // Traducido
    }

    // Use the general update service for settings not tied to a tenant
    const setting = await UpdateSettingGeneralService({
        key: 'pfxCertFile', // Specific key for this setting
        value: file.filename // Store the generated filename
    });

    return res.status(200).json(setting.value); // Return only the filename (value)
};

export const storeLogo = async (req: Request, res: Response): Promise<Response> => {
    const file = req.file; // Get file from multer middleware
    const { tenantId } = req.user;

    if (!file) {
        throw new AppError('Ningún archivo enviado', 400); // Traducido
    }

    // Basic check for image mimetype
    if (file && file.mimetype.startsWith('image/')) {
        const setting = await UpdateSettingService({
            key: 'logo', // Specific key for logo
            value: file.filename, // Store the generated filename
            tenantId
        });
        return res.status(200).json(setting.value); // Return only the filename (value)
    }

    // If not an image or no file
    return res.status(400).json({ error: 'Formato de archivo inválido o ningún archivo enviado' }); // Traducido
};

// --- END OF FILE SettingController.ts ---