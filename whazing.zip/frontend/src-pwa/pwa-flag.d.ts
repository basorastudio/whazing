// ESTE ARCHIVO DE BANDERA DE CARACTERÍSTICA ES AUTOGENERADO,
// LA ELIMINACIÓN O LOS CAMBIOS HARÁN QUE LOS TIPOS RELACIONADOS DEJEN DE FUNCIONAR
import "quasar/dist/types/feature-flag";

declare module "quasar/dist/types/feature-flag" {
  interface QuasarFeatureFlags {
    pwa: true; // Garantiza que la bandera PWA esté habilitada
  }
}
