import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    return Promise.all([
      queryInterface.changeColumn("AutoReply", "words", {
        // Cambia el tipo de la columna 'words' a ARRAY de STRING usando SQL crudo
        type: `${DataTypes.ARRAY(DataTypes.STRING)} USING CAST("words" as text[])`
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Revierte el cambio, volviendo al tipo STRING
    const tableInfo = {
      type: DataTypes.STRING,
      allowNull: false
    };
    return Promise.all([
      queryInterface.changeColumn("AutoReply", "words", tableInfo)
    ]);
  }
};
