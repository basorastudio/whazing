async execute({ name, status = "DISCONNECTED", qrcode = "", isDefault = false, greetingMessage, farewellMessage, companyId, token, provider = "beta" }: Request): Promise<Whatsapp> {
    const company = await ShowCompanyService(companyId);
    
    // Eliminando la verificación del límite de conexiones
    // const count = await Whatsapp.count({
    //   where: {
    //     companyId
    //   }
    // });
    
    // if (count >= connection.value) {
    //   throw new AppError("ERR_NO_PERMISSION_CONNECTIONS_LIMIT");
    // }

    // ...existing code...
}
