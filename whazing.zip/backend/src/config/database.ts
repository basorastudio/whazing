// Asegúrate de que las variables de entorno estén cargadas al inicio de tu aplicación
// import 'dotenv/config'; // Descomenta si este es el punto de entrada o necesitas cargar aquí
import { Options, Dialect } from "sequelize"; // Importa tipos de Sequelize

/**
 * Configuración de la base de datos para Sequelize.
 * Lee las variables de entorno o utiliza valores predeterminados.
 */

// Define los tipos esperados para las opciones de Sequelize
// Nota: SequelizeOptions es un alias común para Options
type SequelizeDatabaseOptions = Options;

const ten = 10; // Base 10 para parseInt

const databaseConfig: SequelizeDatabaseOptions = {
  // Define: Opciones específicas para la definición de modelos
  define: {
    charset: "utf8mb4", // Juego de caracteres
    collate: "utf8mb4_bin" // Colación (case-sensitive)
    // underscored: true, // Podrías añadir esto si usas snake_case para columnas auto-generadas
  },
  // Options: Opciones generales de conexión
  options: {
    // Timeout para las solicitudes a la base de datos en milisegundos
    requestTimeout: parseInt(
      process.env.POSTGRES_REQUEST_TIMEOUT || "30000",
      ten
    ) // 30 segundos por defecto
    // La opción 'encrypt' suele ser más específica de MSSQL. Para Postgres, se usa 'ssl'.
    // Verifica la documentación de Sequelize para tu dialecto específico si necesitas SSL.
    // dialectOptions: {
    //   ssl: process.env.DB_SSL === 'true' ? { require: true, rejectUnauthorized: false } : false,
    // },
    // encrypt: true, // Mantenido del original, pero revisa si es aplicable a tu dialecto
  },
  // Retry: Configuración de reintentos de conexión
  retry: {
    // Expresiones regulares para errores que activan un reintento
    match: [
      /SequelizeConnectionError/,
      /SequelizeConnectionRefusedError/,
      /SequelizeHostNotFoundError/,
      /SequelizeHostNotReachableError/,
      /SequelizeInvalidConnectionError/,
      /SequelizeConnectionTimedOutError/,
      /TimeoutError/, // Añadido común
      /ECONNRESET/, // Añadido común
      /ETIMEDOUT/ // Añadido común
    ],
    max: parseInt(process.env.DB_RETRY_MAX || "5", ten) // Máximo de reintentos (ej: 5)
  },
  // Pool: Configuración del pool de conexiones
  pool: {
    max: parseInt(process.env.POSTGRES_POOL_MAX || "5", ten), // Conexiones máximas
    min: parseInt(process.env.POSTGRES_POOL_MIN || "0", ten), // Conexiones mínimas
    acquire: parseInt(process.env.POSTGRES_POOL_ACQUIRE || "30000", ten), // Tiempo máx. para obtener conexión (ms)
    idle: parseInt(process.env.POSTGRES_POOL_IDLE || "10000", ten) // Tiempo máx. conexión inactiva (ms)
  },
  // Dialect: El tipo de base de datos (ej: 'postgres', 'mysql', 'sqlite', 'mssql')
  dialect: (process.env.DB_DIALECT || "postgres") as Dialect, // Asegura que el valor sea un Dialect válido
  // Timezone: Zona horaria para la base de datos
  timezone: process.env.DB_TIMEZONE || "-03:00", // Ejemplo: UTC-3
  // Host: Dirección del servidor de base de datos
  host: process.env.POSTGRES_HOST || "localhost",
  // Port: Puerto del servidor de base de datos
  port: parseInt(process.env.DB_PORT || "5432", ten), // Puerto estándar de Postgres
  // Database: Nombre de la base de datos
  database: process.env.POSTGRES_DB || "whazing", // Nombre por defecto del original
  // Username: Usuario para la conexión
  username: process.env.POSTGRES_USER || "postgres", // Usuario por defecto de Postgres
  // Password: Contraseña para la conexión
  password: process.env.POSTGRES_PASSWORD || "whazing", // Contraseña por defecto del original (¡insegura!)
  // Logging: Controla si Sequelize muestra las consultas SQL en la consola
  // Puede ser false, true, o una función (ej: console.log)
  logging: process.env.DB_DEBUG === "true" // Muestra logs SQL si DB_DEBUG es 'true'
};

// Exporta la configuración tipada
export default databaseConfig;
