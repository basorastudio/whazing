class FormatMask {
  setPhoneFormatMask(phoneToFormat) {
    if (!phoneToFormat || phoneToFormat.length < 11) {
      return
    }

    const number = ('' + phoneToFormat).replace(/\D/g, '')

    if (number.length === 11) {
      const phoneNumberFormatted = number.match(/^(\d{1})(\d{3})(\d{3})(\d{4})$/)
      return (
        '+' +
        phoneNumberFormatted[1] +
        ' (' +
        phoneNumberFormatted[2] +
        ') ' +
        phoneNumberFormatted[3] +
        '-' +
        phoneNumberFormatted[4]
      )
    }

    return null
  }

  removeMask(number) {
    const filterNumber = number.replace(/\D/g, '')
    return filterNumber
  }

  maskPhonePattern(phoneNumber) {
    return '+1 (999) 999-9999'
  }
}

export { FormatMask }

const formatSerializedId = (serializedId) => {
  const formatMask = new FormatMask()
  const number = serializedId?.replace('@c.us', '')

  return formatMask.setPhoneFormatMask(number)?.replace('+1', '🇩🇴')
}

export default formatSerializedId
