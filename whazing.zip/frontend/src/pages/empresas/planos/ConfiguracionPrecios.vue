<template>
  <q-dialog persistent :value="modalConfiguracionPrecios" @hide="fecharModal" @show="abrirModal">
    <q-card class="container-rounded-10 modal-container q-pa-lg">
      <q-card-section class="row items-center justify-between q-mt-md q-px-none">
        <div class="text-h6 text-center font-family-main col">
          Configuración de Precios Base
        </div>
        <q-btn flat color="negative" v-close-popup icon="eva-close" />
      </q-card-section>

      <div class="container-border container-rounded-10">
        <q-card-section class="row flex-gap-1 q-col-gutter-sm">
          <div class="text-h6 font-family-main">
            Precios Base para Planes Personalizados
          </div>
          <div class="flex-gap-1 full-width row q-col-gutter-sm">
            <div class="col-12 col-md-6">
              <c-input
                rounded
                outlined
                v-model.number="precios.baseUsuario"
                type="number"
                label="Precio por Usuario"
                suffix="RD$"
              />
            </div>
            <div class="col-12 col-md-6">
              <c-input
                rounded
                outlined
                v-model.number="precios.baseConexion"
                type="number"
                label="Precio por Conexión"
                suffix="RD$"
              />
            </div>
            <div class="col-12 col-md-6">
              <c-input
                rounded
                outlined
                v-model.number="precios.grupo"
                type="number"
                label="Precio por Grupos"
                suffix="RD$"
              />
            </div>
            <div class="col-12 col-md-6">
              <c-input
                rounded
                outlined
                v-model.number="precios.campana"
                type="number"
                label="Precio por Campañas"
                suffix="RD$"
              />
            </div>
            <div class="col-12 col-md-6">
              <c-input
                rounded
                outlined
                v-model.number="precios.integracion"
                type="number"
                label="Precio por Integraciones"
                suffix="RD$"
              />
            </div>
            <div class="col-12">
              <q-checkbox
                v-model="habilitarPlanesPersonalizados"
                label="Habilitar planes personalizados en el registro"
              />
            </div>
          </div>
        </q-card-section>
      </div>

      <q-card-actions align="right">
        <q-btn
          label="Cancelar"
          class="q-px-md q-mr-sm btn-rounded-50"
          color="negative"
          v-close-popup
        />
        <q-btn
          label="Guardar"
          class="q-ml-lg q-px-md btn-rounded-50"
          color="primary"
          icon="eva-save-outline"
          @click="guardarConfiguracion"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script>
import { ref } from 'vue'

export default {
  name: 'ConfiguracionPrecios',
  props: {
    modalConfiguracionPrecios: {
      type: Boolean,
      default: false
    }
  },
  setup(props, { emit }) {
    const precios = ref({
      baseUsuario: 50,
      baseConexion: 100,
      grupo: 200,
      campana: 300,
      integracion: 400
    })

    const habilitarPlanesPersonalizados = ref(false)

    const guardarConfiguracion = async () => {
      try {
        // Aquí se implementará la lógica para guardar la configuración
        // Se enviará al backend los nuevos precios y el estado de habilitación
        emit('configuracion-guardada', {
          precios: precios.value,
          habilitarPlanesPersonalizados: habilitarPlanesPersonalizados.value
        })
        emit('hide')
      } catch (error) {
        console.error('Error al guardar la configuración:', error)
      }
    }

    const fecharModal = () => {
      emit('hide')
    }

    const abrirModal = () => {
      // Aquí se puede cargar la configuración actual desde el backend
    }

    return {
      precios,
      habilitarPlanesPersonalizados,
      guardarConfiguracion,
      fecharModal,
      abrirModal
    }
  }
}
</script>