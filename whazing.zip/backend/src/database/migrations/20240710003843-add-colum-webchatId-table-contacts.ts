import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'webchatId' column to the 'Contacts' table
    await queryInterface.addColumn(
      "Contacts", // Table name
      "webchatId", // New column name
      {
        type: DataTypes.STRING,
        allowNull: true, // Allow null values
        defaultValue: null // Default is null (explicitly set from original code)
      }
    );
    // Original code wrapped this in Promise.all([ ... ]), but it's unnecessary for a single async operation.
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'webchatId' column from the 'Contacts' table
    await queryInterface.removeColumn(
      "Contacts", // Table name
      "webchatId" // Column name to remove
    );
    // Original code wrapped this in Promise.all([ ... ]), but it's unnecessary for a single async operation.
  }
};

export = migration;
