import { QueryInterface, Sequelize } from "sequelize";

export = {
  up: async (
    queryInterface: QueryInterface,
    sequelize: Sequelize
  ): Promise<void> => {
    // Añade una restricción única combinada a las columnas 'number' y 'tenantId' en la tabla 'Contacts'
    await queryInterface.addConstraint("Contacts", {
      fields: ["number", "tenantId"], // Campos incluidos en la restricción
      type: "unique", // Tipo de restricción: única
      name: "unique_contact_number_tenant" // Nombre de la restricción
    });
  },

  down: async (
    queryInterface: QueryInterface,
    sequelize: Sequelize
  ): Promise<void> => {
    // Elimina la restricción única 'unique_contact_number_tenant' de la tabla 'Contacts'
    await queryInterface.removeConstraint(
      "Contacts",
      "unique_contact_number_tenant"
    );
  }
};
