import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Propiedades comunes para las nuevas columnas de fecha
    const dateColumnProps = {
      type: DataTypes.DATE,
      defaultValue: null
    };

    return Promise.all([
      // Añade la columna 'lastLogin' (DATE) a 'Users'
      queryInterface.addColumn('Users', 'lastLogin', dateColumnProps),
      // Añade la columna 'lastLogout' (DATE) a 'Users'
      queryInterface.addColumn('Users', 'lastLogout', dateColumnProps),
      // Añade la columna 'isOnline' (BOOLEAN) a 'Users'
      queryInterface.addColumn('Users', 'isOnline', {
        type: DataTypes.BOOLEAN,
        defaultValue: false // Valor predeterminado es false
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina las columnas añadidas
    return Promise.all([
      queryInterface.removeColumn('Users', 'lastLogin'),
      queryInterface.removeColumn('Users', 'lastLogout'),
      queryInterface.removeColumn('Users', 'isOnline')
    ]);
  }
};