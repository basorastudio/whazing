"use strict";

import * as Sentry from "@sentry/node";
import { logger } from "../utils/logger";
import axios from "axios";
import { RefreshToken } from "../helpers/RefreshToken";
import CheckSettingsHelper from "../helpers/CheckSettingsHelper";
import AppError from "../errors/AppError"; // Asumiendo que tienes un archivo para errores personalizados

// Opciones para el trabajo de la cola (ejemplo con Bull)
const jobOptions = {
  attempts: 10, // Número de reintentos
  backoff: { type: "fixed" as "fixed", delay: 60000 * 5 } // Retraso fijo de 5 minutos
};

const queueOptions = {
  removeOnComplete: true, // Elimina el trabajo al completar
  removeOnFail: false, // Mantener si falla para inspección
  jobId: "SendWebhook", // Podría ser dinámico basado en datos si es necesario
  ...jobOptions
};

interface WebhookData {
  url: string;
  n8nApiKey?: string; // Clave API opcional para n8n u otro servicio
  dataToSend: any; // Los datos a enviar en el webhook
  // Añade cualquier otro dato necesario
}

export default {
  key: "SendWebhook", // Clave única para este tipo de trabajo
  options: queueOptions,

  async handle({ data }: { data: WebhookData }): Promise<void> {
    const { url, n8nApiKey, dataToSend } = data;
    const keySettingWebhook = "webhookCheck"; // Clave ejemplo para una configuración
    const keySettingFooter = "footer"; // Clave ejemplo para otra configuración

    try {
      // Ejemplo: Verificar una configuración antes de enviar
      const tokenSettingWebhook = RefreshToken(keySettingWebhook);
      const tokenSettingFooter = RefreshToken(keySettingFooter);
      const settingWebhookValue =
        await CheckSettingsHelper(tokenSettingWebhook);

      let finalDataToSend = dataToSend;

      // Ejemplo: Modificar los datos basados en una configuración
      if (settingWebhookValue === tokenSettingFooter) {
        // Adaptar esta lógica
        const footerContent = RefreshToken("aDifferentFooterKey"); // Obtener el contenido real
        finalDataToSend = [footerContent]; // Sobrescribir o añadir al payload
      }

      // Configuración de la solicitud Axios
      const axiosConfig = {
        method: "POST" as "POST",
        url: url,
        headers: {
          "Content-Type": "application/json",
          // Añadir cabecera API Key si se proporciona
          ...(n8nApiKey && { "X-N8N-API-KEY": n8nApiKey })
        },
        data: finalDataToSend // Usar los datos posiblemente modificados
      };

      // Enviar la solicitud
      await axios(axiosConfig);

      // logger.info(`Webhook enviado con éxito a: ${url}`); // Opcional: Log de éxito
    } catch (err: any) {
      Sentry.captureException(err); // Capturar excepción con Sentry
      logger.error("WebHook -> error", err.message); // Mensaje de error traducido
      // Lanzar el error para que Bull pueda manejar los reintentos o marcar como fallido
      throw err; // Usa 'throw new AppError(err.message);' si prefieres tu clase de error
    }
  }
};
