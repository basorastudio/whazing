import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add a composite unique constraint on 'queueId' and 'userId' in 'UsersQueues' table
    await queryInterface.addConstraint("UsersQueues", {
      fields: ["queueId", "userId"], // Fields for the constraint
      type: "unique",
      name: "unique_queue_user" // Explicit constraint name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the composite unique constraint
    await queryInterface.removeConstraint("UsersQueues", "unique_queue_user");
  }
};

export = migration;
