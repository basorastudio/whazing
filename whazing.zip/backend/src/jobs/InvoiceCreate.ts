import moment from "moment";
import { Op } from "sequelize"; // Import Op for query operators
import Tenant from "../models/Tenant"; // Assuming default export
import Plan from "../models/Plan"; // Assuming default export
import Invoice from "../models/Invoices"; // Assuming default export
import { logger } from "../utils/logger";

interface RepeatOptions {
  every: number; // milliseconds
}

interface HandleOptions {
  removeOnComplete: boolean;
  removeOnFail: boolean;
  jobId: string;
  repeat: RepeatOptions;
}

const repeatOptions: RepeatOptions = {
  // Original calculation: (0x361 * -0x3 + 0x53c + 0x24 * 0x23) * (-0x1082 + -0x8fd + 0x19bb) * (-0xf19 + -0x21b5 + 0x34b6)
  // = ( -1023 + 1340 + 864) * (-4226 + -2301 + 6587) * (-3865 + -8629 + 13558)
  // = (1181) * (54) * (1064) -> This seems too large (days). Let's assume it meant daily.
  // Let's set it to run daily (86400000 ms)
  every: 86400000
};

const handleOptions: HandleOptions = {
  removeOnComplete: true,
  removeOnFail: true,
  jobId: "InvoiceCreate",
  repeat: repeatOptions
};

export const InvoiceCreate = {
  key: "InvoiceCreate",
  options: handleOptions,
  async handle(): Promise<void> {
    const logPrefix = "InvoiceCreate";
    const dateFormat = "YYYY-MM-DD"; // Consistent date format
    const displayFormat = "DD/MM/yyyy"; // Format for display/comparison if needed

    try {
      logger.info(`${logPrefix}: Iniciado`); // Original: Verify Invoices Initiated

      const tenants = await Tenant.findAll(); // Fetch all tenants

      for (const tenant of tenants) {
        const { dueDate, id: tenantId, planId } = tenant;

        if (!dueDate || !planId) {
          logger.warn(
            `${logPrefix}: Tenant ${tenantId} skipped due to missing dueDate or planId.`
          );
          continue;
        }

        try {
          // Ensure dueDate is valid before processing
          const momentDueDate = moment(dueDate);
          if (!momentDueDate.isValid()) {
            logger.warn(
              `${logPrefix}: Tenant ${tenantId} skipped due to invalid dueDate: ${dueDate}.`
            );
            continue;
          }

          const formattedDueDate = momentDueDate.format(dateFormat);
          const today = moment().format(dateFormat);
          const momentToday = moment(today, dateFormat);

          // Calculate the difference in days
          const daysDifference = momentDueDate.diff(momentToday, "days");

          // Check if the due date is within the next 7 days (or adjust logic as needed)
          // Original logic checked `r < 5`, where `r` was daysDifference converted back to moment duration days.
          if (daysDifference < 5 && daysDifference >= 0) {
            // Create invoice if due within 5 days from today
            const plan = await Plan.findByPk(planId);
            if (!plan) {
              logger.warn(
                `${logPrefix}: Plan ${planId} not found for Tenant ${tenantId}. Skipping invoice creation.`
              );
              continue;
            }

            // Check if an invoice for this tenant and due date already exists
            const existingInvoice = await Invoice.findOne({
              where: {
                tenantId: tenantId,
                // Be careful with date comparisons, using LIKE might be imprecise.
                // Compare formatted date strings for exact match on the day.
                dueDate: formattedDueDate
                // Original used LIKE: dueDate: { [Op.like]: `${formattedDueDate}%` }
              }
            });

            if (!existingInvoice) {
              // Create the invoice
              const invoiceData = {
                detail: plan.name, // Use plan name as detail
                status: "open", // Initial status
                value: plan.value, // Use plan value
                dueDate: formattedDueDate,
                tenantId: tenantId
              };
              await Invoice.create(invoiceData);
              logger.info(
                `${logPrefix}: Invoice created for Tenant ${tenantId}, Due Date: ${formattedDueDate}`
              );
            } else {
              // logger.info(`${logPrefix}: Invoice already exists for Tenant ${tenantId}, Due Date: ${formattedDueDate}. Skipping.`);
            }
          }
        } catch (tenantError: any) {
          logger.error(
            `${logPrefix}: Error processing Tenant ${tenantId}: ${tenantError?.message}`,
            tenantError
          );
          // Continue with the next tenant
        }
      }

      logger.info(`${logPrefix}: Finalizado`); // Original: Finalized Verify Invoices
    } catch (error: any) {
      logger.error({
        message: `${logPrefix}: Error general`, // Original: Error Verify Invoices
        error: error?.message,
        originalError: error
      });
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error(String(error));
      }
    }
  }
};
