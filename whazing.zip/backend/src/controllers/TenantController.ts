import { Request, Response } from 'express';
import * as Yup from 'yup';
import { isMatch } from 'date-fns'; // Assuming 'isMatch' is the intended function
import AppError from '../errors/AppError';
import UpdateBusinessHoursService from '../services/TenantServices/UpdateBusinessHoursService';
import ShowBusinessHoursAndMessageService from '../services/TenantServices/ShowBusinessHoursAndMessageService';
import UpdateMessageBusinessHoursService from '../services/TenantServices/UpdateMessageBusinessHoursService';
import ShowdueDateService from '../services/TenantServices/ShowdueDateService';
import ShowPlanService from '../services/TenantServices/ShowPlanService';

// Define una interfaz para los datos de horas de negocio
interface BusinessHour {
    day: number;
    label: string;
    type: string; // 'O' for Open, 'C' for Closed?
    hr1: string;
    hr2: string;
    hr3: string;
    hr4: string;
}

// Define una interfaz para el cuerpo de la solicitud de actualización de horas
interface UpdateBusinessHoursBody extends Array<BusinessHour> {}

// Define una interfaz para el cuerpo de la solicitud de actualización del mensaje
interface UpdateMessageBusinessHoursBody {
    messageBusinessHours: string;
}

// Extiende la interfaz Request para incluir la propiedad user
interface UserRequest extends Request {
    user?: {
        id: string | number;
        tenantId: string | number;
        profile: string;
    };
    // Tipa explícitamente body y params si se usan en otros métodos
    body: UpdateBusinessHoursBody | UpdateMessageBusinessHoursBody | any; // Usa 'any' si el body varía mucho o define un tipo unión
    params: any; // Define mejor si se usan parámetros de ruta
}

// Esquema de validación para las horas de negocio
const businessHoursSchema = Yup.array().of(
    Yup.object().shape({
        day: Yup.number().integer().required(),
        label: Yup.string().required(),
        type: Yup.string().required(),
        // Valida que las horas sean en formato HH:mm o cadena vacía/null
        hr1: Yup.string().required().test(
            'is-hour-valid',
            '${path} no es válido', // '${path} is not valid'
            (value) => !value || isMatch(value || '', 'HH:mm')
        ),
        hr2: Yup.string().required().test(
            'is-hour-valid',
            '${path} no es válido', // '${path} is not valid'
            (value) => !value || isMatch(value || '', 'HH:mm')
        ),
        hr3: Yup.string().required().test(
            'is-hour-valid',
            '${path} no es válido', // '${path} is not valid'
            (value) => !value || isMatch(value || '', 'HH:mm')
        ),
        hr4: Yup.string().required().test(
            'is-hour-valid',
            '${path} no es válido', // '${path} is not valid'
            (value) => !value || isMatch(value || '', 'HH:mm')
        ),
    })
);

export const updateBusinessHours = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId, profile } = req.user!;

    // Verifica si el usuario es administrador
    if (profile !== 'admin') {
        throw new AppError('ERR_NO_PERMISSION', 403); // "ERR_SIN_PERMISO"
    }

    const businessHoursData: UpdateBusinessHoursBody = req.body;

    // Validación con Yup
    try {
        await businessHoursSchema.validate(businessHoursData);
    } catch (err: any) { // Usar any o Yup.ValidationError
        throw new AppError(err.message);
    }

    const data = {
        businessHours: businessHoursData,
        tenantId,
    };

    const updatedTenant = await UpdateBusinessHoursService(data);

    return res.status(200).json(updatedTenant);
};

export const updateMessageBusinessHours = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId, profile } = req.user!;

    // Verifica si el usuario es administrador
    if (profile !== 'admin') {
        throw new AppError('ERR_NO_PERMISSION', 403); // "ERR_SIN_PERMISO"
    }

    const { messageBusinessHours } = req.body as UpdateMessageBusinessHoursBody;

    // Verifica si el mensaje fue proporcionado
    if (!messageBusinessHours) {
        throw new AppError('ERR_NO_MESSAGE_INFORMATION', 400); // "ERR_SIN_INFORMACION_DE_MENSAJE"
    }

    const data = {
        messageBusinessHours,
        tenantId,
    };

    const updatedMessage = await UpdateMessageBusinessHoursService(data);

    return res.status(200).json(updatedMessage);
};

export const showBusinessHoursAndMessage = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId } = req.user!;
    const data = { tenantId };
    const businessHoursAndMessage = await ShowBusinessHoursAndMessageService(data);
    return res.status(200).json(businessHoursAndMessage);
};

export const ShowdueDate = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId } = req.user!;
    const data = { tenantId };
    const dueDate = await ShowdueDateService(data);
    return res.status(200).json(dueDate);
};

export const ShowPlan = async (req: UserRequest, res: Response): Promise<Response> => {
    const { tenantId } = req.user!;
    const data = { tenantId };
    const plan = await ShowPlanService(data);
    return res.status(200).json(plan);
};