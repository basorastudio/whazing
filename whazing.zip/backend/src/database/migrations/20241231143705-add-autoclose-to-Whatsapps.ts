import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add auto-close related columns to 'Whatsapps' table
    await queryInterface.addColumn('Whatsapps', 'autoClose', {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      allowNull: false, // Original had false
    });
    await queryInterface.addColumn('Whatsapps', 'autoCloseTime', {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false, // Original had false
    });
    await queryInterface.addColumn('Whatsapps', 'autoCloseMessage', {
      type: DataTypes.TEXT,
      defaultValue: null,
      allowNull: true, // Original allowed null
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added auto-close columns
    await queryInterface.removeColumn('Whatsapps', 'autoCloseMessage');
    await queryInterface.removeColumn('Whatsapps', 'autoCloseTime');
    await queryInterface.removeColumn('Whatsapps', 'autoClose');
  }
};

export = migration;