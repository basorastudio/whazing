import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'planId' column to the 'Tenants' table as a foreign key
    await queryInterface.addColumn(
      'Tenants', // Table name
      'planId',  // New column name
      {
        type: DataTypes.INTEGER,
        references: {
          model: 'Plans', // References the 'Plans' table
          key: 'id',      // References the 'id' column in 'Plans'
        },
        onUpdate: 'CASCADE',  // If the referenced Plan id changes, update it here
        onDelete: 'SET NULL', // If the referenced Plan is deleted, set planId to NULL
        allowNull: true,      // Allow null because onDelete is SET NULL
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'planId' column from the 'Tenants' table
    await queryInterface.removeColumn(
      'Tenants', // Table name
      'planId'   // Column name to remove
    );
  }
};

export = migration;