export const LICENSE_CONFIG = {
  API_URL: 'http://localhost',
  VERIFY_ENDPOINT: '/verify-license',
  ACTIVATION_ENDPOINT: '/activate',
  BYPASS_VERIFICATION: true
}
