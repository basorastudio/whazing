<template>
  <div class="social-auth-container q-pa-md">
    <div class="row q-col-gutter-md">
      <!-- Estado de conexión -->
      <div class="col-12">
        <q-banner v-if="isLoading" class="bg-grey-3">
          <template v-slot:avatar>
            <q-spinner-dots color="primary" />
          </template>
          Verificando estado de conexión...
        </q-banner>

        <q-banner v-else-if="isConnected" class="bg-positive text-white">
          <template v-slot:avatar>
            <q-icon name="check_circle" color="white" />
          </template>
          ¡Conectado exitosamente a Facebook y sus servicios!
        </q-banner>
      </div>

      <!-- Botón de conexión -->
      <div class="col-12 text-center">
        <q-btn
          size="lg"
          color="primary"
          :loading="isConnecting"
          :disable="isConnected"
          @click="connectSocialMedia"
        >
          <q-icon name="facebook" left />
          {{ isConnected ? 'Conectado' : 'Conectar con Facebook' }}
        </q-btn>

        <p class="text-caption q-mt-sm">
          Conecta tu cuenta de Facebook para administrar automáticamente Facebook, Instagram y Messenger
        </p>
      </div>

      <!-- Tarjetas de estado -->
      <div class="col-12 col-md-4" v-for="service in services" :key="service.name">
        <q-card>
          <q-card-section>
            <div class="row items-center no-wrap">
              <div class="col">
                <div class="text-h6">{{ service.name }}</div>
                <div class="text-subtitle2">
                  {{ service.connected ? 'Conectado' : 'No conectado' }}
                </div>
              </div>
              <div class="col-auto">
                <q-icon
                  :name="service.connected ? 'check_circle' : 'error'"
                  :color="service.connected ? 'positive' : 'grey'"
                  size="2em"
                />
              </div>
            </div>
          </q-card-section>
        </q-card>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from 'vue'
import { initFacebookSDK, loginWithFacebook, saveSocialMediaTokens, getSocialMediaStatus } from '../service/socialAuth'

export default defineComponent({
  name: 'SocialMediaAuth',

  data() {
    return {
      isLoading: true,
      isConnecting: false,
      isConnected: false,
      services: [
        { name: 'Facebook', connected: false },
        { name: 'Instagram', connected: false },
        { name: 'Messenger', connected: false }
      ]
    }
  },

  async created() {
    await initFacebookSDK()
    await this.checkConnectionStatus()
  },

  methods: {
    async checkConnectionStatus() {
      try {
        const { data } = await getSocialMediaStatus()
        this.isConnected = data.isConnected
        this.services = this.services.map(service => ({
          ...service,
          connected: data[service.name.toLowerCase()]
        }))
      } catch (error) {
        console.error('Error al verificar el estado de conexión:', error)
      } finally {
        this.isLoading = false
      }
    },

    async connectSocialMedia() {
      this.isConnecting = true
      try {
        const fbResponse = await loginWithFacebook()
        
        // Guardar tokens y configurar servicios
        await saveSocialMediaTokens({
          accessToken: fbResponse.accessToken,
          userId: fbResponse.userId,
          pages: fbResponse.pages
        })

        await this.checkConnectionStatus()
        this.$q.notify({
          type: 'positive',
          message: '¡Conexión exitosa con Facebook y sus servicios!'
        })
      } catch (error) {
        console.error('Error en la conexión:', error)
        this.$q.notify({
          type: 'negative',
          message: error.message || 'Error al conectar con Facebook'
        })
      } finally {
        this.isConnecting = false
      }
    }
  }
})
</script>

<style scoped>
.social-auth-container {
  max-width: 1200px;
  margin: 0 auto;
}
</style>