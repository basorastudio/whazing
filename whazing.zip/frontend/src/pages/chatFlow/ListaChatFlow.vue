<template>
  <div>
    <div class="row">
      <div class="col">
        <q-table
          square
          flat
          bordered
          class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
          :class="{
    'full-height': $q.screen.lt.sm
  }"
          hide-bottom
          :data="listachatFlow"
          :columns="columns"
          :loading="loading"
          row-key="id"
          :pagination.sync="pagination"
          :rows-per-page-options="[0]"
        >
          <template v-slot:top-left>
            <div>
              <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
                <q-icon name="mdi-robot-outline q-pr-sm" />
                {{ $t('chatbot.flows') }}
              </h2>
              <q-btn
                class="generate-button btn-rounded-50"
                :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="eva-plus-outline"
                :label="$t('chatbot.add')"
              @click="chatFlowSelecionado = {}; modalChatFlow = true"
            />
              <q-btn
                class="generate-button btn-rounded-50"
                :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="mdi-import"
                :label="$t('chatbot.import')"
              @click="modalImportFlow = true"
            />
              <q-btn flat
                     class="generate-button btn-rounded-50"
                     :class="{'generate-button-dark' : $q.dark.isActive}"
                     v-if="whatsappNumber"
                     icon="mdi-whatsapp"
                     :label="$t('chatbot.callSupport')"
                     @click="abrirWhatsApp"
              />
            </div>

          </template>
          <template v-slot:body-cell-isActive="props">
            <q-td class="text-center">
              <q-icon
                size="16px"
                :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                :color="props.value ? 'positive' : 'negative'"
                class=""
              />
              <span class="q-mx-xs text-bold">
              {{ props.value ? $t('chatbot.active') : $t('chatbot.inactive') }}
              </span>
            </q-td>
          </template>
          <template v-slot:body-cell-AcceptTransfer="props">
            <q-td class="text-center">
              <q-icon
                size="16px"
                :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                :color="props.value ? 'positive' : 'negative'"
                class=""
              />
              <span class="q-mx-xs text-bold">
              {{ props.value ? $t('chatbot.active') : $t('chatbot.inactive') }}
              </span>
            </q-td>
          </template>
          <template v-slot:body-cell-AcceptKanban="props">
            <q-td class="text-center">
              <q-icon
                size="16px"
                :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
                :color="props.value ? 'positive' : 'negative'"
                class=""
              />
              <span class="q-mx-xs text-bold">
              {{ props.value ? $t('chatbot.active') : $t('chatbot.inactive') }}
              </span>
            </q-td>
          </template>
          <template v-slot:body-cell-acoes="props">
            <q-td class="text-center">
              <q-btn
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                icon="eva-edit-outline"
                flat
                round
                @click="editFlow(props.row)"
              >
                <q-tooltip>
                  {{ $t('chatbot.edit') }}
                </q-tooltip>
              </q-btn>
              <q-btn
                icon="mdi-sitemap"
                flat
                round
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                @click="abrirFluxo(props.row)"
              >
                <q-tooltip>
                  {{ $t('chatbot.openFlow') }}
                </q-tooltip>
              </q-btn>
              <q-btn
                icon="eva-trash-outline"
                flat
                round
                class="color-light1"
                :class="$q.dark.isActive ? ('color-dark1') : ''"
                @click="deletarFluxo(props.row)"
                v-if="userProfile === 'admin'"
              >
                <q-tooltip>
                  {{ $t('chatbot.delete') }}
                </q-tooltip>
              </q-btn>
            </q-td>
          </template>

        </q-table>
      </div>
    </div>
    <ModalChatFlow
      :modalChatFlow.sync="modalChatFlow"
      :chatFlowEdicao.sync="chatFlowSelecionado"
      @chatFlow:criada="novoFluxoCriado"
      @chatFlow:editado="fluxoEditado"
    />
    <ModalImportFlow
      :modalImportFlow.sync="modalImportFlow"
      @chatFlow:criada="novoFluxoCriado"
    />
    <q-dialog v-model="confirmDelete" persistent>
      <q-card style="min-width: 350px">
        <q-card-section>
          <div class="text-h6">{{ $t('chatbot.confirmDelete') }}</div>
          <div>{{ chatFlowSelecionado.name }}</div>
        </q-card-section>
        <q-card-actions align="right" class="text-primary">
          <q-btn
            :label="$t('general.no')"
            v-close-popup
            class="q-mr-md"
            color="primary"
          />
          <q-btn :label="$t('general.yes')" color="negative" v-close-popup @click="confirmDeleteFoo()" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import { ListarFilas } from 'src/service/filas'
import { ListarChatFlow, DeletarChatFlow } from 'src/service/chatFlow'
import { ListarUsuarios } from 'src/service/user'
import { ListarConfiguracaoPublica } from 'src/service/configuracoesgeneral'
import ModalChatFlow from './ModalChatFlow.vue'
import ModalImportFlow from './ModalImportFlow.vue'

export default {
  name: 'ChatFlowIndex',
  components: { ModalChatFlow, ModalImportFlow },
  data () {
    return {
      userProfile: 'user',
      confirmDelete: false,
      listachatFlow: [],
      modalChatFlow: false,
      modalImportFlow: false,
      whatsappNumber: null,
      chatFlowSelecionado: {},
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        searchParam: null,
        hasMore: true
      },
      loading: false,
      columns: [
        { name: 'name', label: this.$t('chatbot.nome'), field: 'name', align: 'left' },
        { name: 'isActive', label: this.$t('chatbot.status'), field: 'isActive', align: 'center' },
        { name: 'AcceptTransfer', label: this.$t('chatbot.transferAvailability'), field: 'AcceptTransfer', align: 'center' },
        { name: 'AcceptKanban', label: this.$t('chatbot.crmAvailability'), field: 'AcceptKanban', align: 'center' },
        { name: 'celularTeste', label: this.$t('chatbot.testPhone'), field: 'celularTeste', align: 'center' },
        { name: 'acoes', label: this.$t('chatbot.actions'), field: 'acoes', align: 'center' }
      ],
      filas: [],
      usuarios: []
    }
  },
  methods: {
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configurações:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const message = encodeURIComponent(this.$t('chatbot.whatsapp'))
        const url = `https://wa.me/${this.whatsappNumber}?text=${message}`
        window.open(url, '_blank')
      }
    },
    async listarChatFlow () {
      const { data } = await ListarChatFlow()
      this.listachatFlow = data.chatFlow
    },
    async listarFilas () {
      const { data } = await ListarFilas({ isActive: true })
      this.filas = data.filter(q => q.isActive)
    },
    async listarUsuarios () {
      const { data } = await ListarUsuarios(this.params)
      this.usuarios = data.users
    },
    novoFluxoCriado (flow) {
      const lista = [...this.listachatFlow]
      lista.push(flow)
      this.listachatFlow = lista
    },
    fluxoEditado (flow) {
      const lista = [...this.listachatFlow.filter(f => f.id !== flow.id)]
      lista.push(flow)
      this.listachatFlow = lista
    },
    editFlow (flow) {
      this.chatFlowSelecionado = flow
      this.modalChatFlow = true
    },
    async abrirFluxo (flow) {
      await this.$store.commit('SET_FLOW_DATA', {
        usuarios: this.usuarios,
        filas: this.filas,
        flow
      })
      this.$router.push({ name: 'chat-flow-builder' })
    },
    deletarFluxo (flow) {
      this.chatFlowSelecionado = flow
      this.confirmDelete = true
    },
    async confirmDeleteFoo (flow) {
      await DeletarChatFlow(this.chatFlowSelecionado)
      await this.listarChatFlow()
    }
  },
  async mounted () {
    this.userProfile = localStorage.getItem('profile')
    this.fetchConfigurations()
    await this.listarChatFlow()
    await this.listarFilas()
    await this.listarUsuarios()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px
</style>
