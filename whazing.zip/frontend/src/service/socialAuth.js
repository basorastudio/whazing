import request from 'src/service/request'

export function initFacebookSDK() {
  return new Promise((resolve) => {
    window.fbAsyncInit = function() {
      FB.init({
        appId: '1592585827725304',
        cookie: true,
        xfbml: true,
        version: 'v18.0'
      })
      resolve()
    }

    // Load Facebook SDK
    ;(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0]
      if (d.getElementById(id)) return
      js = d.createElement(s)
      js.id = id
      js.src = 'https://connect.facebook.net/es_LA/sdk.js'
      fjs.parentNode.insertBefore(js, fjs)
    }(document, 'script', 'facebook-jssdk'))
  })
}

export function loginWithFacebook() {
  return new Promise((resolve, reject) => {
    FB.login(function(response) {
      if (response.authResponse) {
        const accessToken = response.authResponse.accessToken
        const userId = response.authResponse.userID

        // Get Facebook Pages
        FB.api('/me/accounts', function(response) {
          if (!response.error) {
            const pages = response.data
            resolve({
              accessToken,
              userId,
              pages
            })
          } else {
            reject(response.error)
          }
        })
      } else {
        reject(new Error('Usuario canceló el inicio de sesión o no autorizó la aplicación'))
      }
    }, { scope: 'pages_show_list,pages_messaging,pages_manage_metadata,instagram_basic,instagram_content_publish,pages_read_engagement' })
  })
}

export function saveSocialMediaTokens(tokens) {
  return request({
    url: '/social-auth/save-tokens',
    method: 'post',
    data: tokens
  })
}

export function getSocialMediaStatus() {
  return request({
    url: '/social-auth/status',
    method: 'get'
  })
}