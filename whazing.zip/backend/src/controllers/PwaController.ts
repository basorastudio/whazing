// --- START OF FILE PwaController.ts ---

import type { Request, Response } from "express";
import CheckSettingsGeneral from "../helpers/CheckSettingsGeneral"; // Assuming path
import * as packageJson from "../../package.json"; // Assuming path
import CheckSettingsHelper from "../helpers/CheckSettingsHelper"; // Assuming path
import { RefreshToken } from "../helpers/RefreshToken"; // Assuming path

export const manifest = async (
  req: Request,
  res: Response
): Promise<Response> => {
  let title = await CheckSettingsGeneral("title");
  const tokeniz = "90a6acde49";
  const tokenValid = await RefreshToken(tokeniz);
  const tokenizCor = "ebc1de57e5";
  const tokenValidCor = await RefreshToken(tokenizCor);
  const CheckCor = await CheckSettingsHelper(tokenValidCor);

  // If token is invalid, use default title
  if (CheckCor !== tokenValid) {
    title = "Whazing SaaS - www.whazing.com.br"; // Keep branding
  }

  const cor1 = "#5E56F6"; // Default color
  const color = await CheckSettingsGeneral("cor1"); // Fetch color setting

  const icon128 = {
    src: `${process.env.BACKEND_URL}/public/logos/icon-128x128.png`,
    sizes: "128x128",
    type: "image/png"
  };
  const icon192 = {
    src: `${process.env.BACKEND_URL}/public/logos/icon-192x192.png`,
    sizes: "192x192",
    type: "image/png"
  };
  const icon256 = {
    src: `${process.env.BACKEND_URL}/public/logos/icon-256x256.png`,
    sizes: "256x256",
    type: "image/png"
  };
  const icon384 = {
    src: `${process.env.BACKEND_URL}/public/logos/icon-384x384.png`,
    sizes: "384x384",
    type: "image/png"
  };
  const icon512 = {
    src: `${process.env.BACKEND_URL}/public/logos/icon-512x512.png`,
    sizes: "512x512",
    type: "image/png"
  };

  const manifestData = {
    short_name: title,
    name: title,
    icons: [icon128, icon192, icon256, icon384, icon512],
    start_url: `${process.env.FRONTEND_URL}/`, // Use FRONTEND_URL
    display: "standalone",
    theme_color: isValidHexColor(color) ? color : cor1, // Use fetched or default
    background_color: "#FFFFFF", // Default background
    orientation: "portrait"
    // background_sync: true // Optional: consider if needed
  };

  return res.status(200).json(manifestData);
};

export const title = async (req: Request, res: Response): Promise<Response> => {
  try {
    let appTitle = await CheckSettingsGeneral("title");
    const tokeniz = "90a6acde49";
    const tokenValid = await RefreshToken(tokeniz);
    const tokenizCor = "ebc1de57e5";
    const tokenValidCor = await RefreshToken(tokenizCor);
    const checkCor = await CheckSettingsHelper(tokenValidCor);

    // If token is invalid, use default title
    if (checkCor !== tokenValid) {
      appTitle = "Whazing SaaS - www.whazing.com.br"; // Keep branding
    }
    return res.status(200).json({ title: appTitle });
  } catch (error: any) {
    console.error("Error fetching title:", error); // Keep original log message structure
    return res.status(500).json({ error: "Error fetching title" }); // Keep original error message structure
  }
};

// Helper function to validate hex color
const isValidHexColor = (color: string): boolean => {
  const hexColorRegex = /^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$/;
  return hexColorRegex.test(color);
};

export const versionP = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const tokeniz = "90a6acde49";
    const tokenValid = await RefreshToken(tokeniz);
    const tokenizCor = "ebc1de57e5";
    const tokenValidCor = await RefreshToken(tokenizCor);
    const checkCor = await CheckSettingsHelper(tokenValidCor);

    if (checkCor !== tokenValid) {
      // Return success false if tokens don't match
      return res.status(200).json({ success: false });
    } else {
      // Return success true if tokens match
      return res.status(200).json({ success: true });
    }
  } catch (error) {
    // Return success false in case of any error during token validation/fetching
    return res
      .status(200)
      .json({ success: false, error: "Failed to validate version token" });
  }
};

export const color = async (req: Request, res: Response): Promise<Response> => {
  const defaults = {
    cor1: "#5E56F6",
    cor2: "#5690F0",
    textcor1: "#FFFFFF",
    cor1dark: "#5E56F6", // Assuming same default for dark or specify if different
    cor2dark: "#5690F0", // Assuming same default for dark or specify if different
    textcor1dark: "#FFFFFF" // Assuming same default for dark or specify if different
  };

  try {
    const fetchedCor1 = await CheckSettingsGeneral("cor1");
    const fetchedCor2 = await CheckSettingsGeneral("cor2");
    const fetchedTextCor1 = await CheckSettingsGeneral("textcor1");
    const fetchedCor1Dark = await CheckSettingsGeneral("cor1dark");
    const fetchedCor2Dark = await CheckSettingsGeneral("cor2dark");
    const fetchedTextCor1Dark = await CheckSettingsGeneral("textcor1dark");

    const tokeniz = "90a6acde49";
    const tokenValid = await RefreshToken(tokeniz);
    const tokenizCor = "ebc1de57e5";
    const tokenValidCor = await RefreshToken(tokenizCor);
    const checkCor = await CheckSettingsHelper(tokenValidCor);

    let colors = {
      cor1: isValidHexColor(fetchedCor1) ? fetchedCor1 : defaults.cor1,
      cor2: isValidHexColor(fetchedCor2) ? fetchedCor2 : defaults.cor2,
      textcor1: isValidHexColor(fetchedTextCor1)
        ? fetchedTextCor1
        : defaults.textcor1,
      cor1dark: isValidHexColor(fetchedCor1Dark)
        ? fetchedCor1Dark
        : defaults.cor1dark,
      cor2dark: isValidHexColor(fetchedCor2Dark)
        ? fetchedCor2Dark
        : defaults.cor2dark,
      textcor1dark: isValidHexColor(fetchedTextCor1Dark)
        ? fetchedTextCor1Dark
        : defaults.textcor1dark
    };

    // If token check fails, revert to defaults
    if (checkCor !== tokenValid) {
      colors = { ...defaults };
    }

    return res.status(200).json(colors);
  } catch (error: any) {
    console.error("Error fetching colors:", error); // Keep original log message structure
    return res.status(500).json({ error: "Error fetching colors" }); // Keep original error message structure
  }
};

export const version = async (
  req: Request,
  res: Response
): Promise<Response> => {
  // Access version directly from imported package.json
  return res.status(200).json({ version: packageJson.version });
};

// --- END OF FILE PwaController.ts ---
