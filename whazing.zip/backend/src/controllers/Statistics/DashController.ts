import { Request, Response } from "express";
import DashTicketsAndTimes from "../../services/Statistics/DashTicketsAndTimes";
import DashTicketsChannels from "../../services/Statistics/DashTicketsChannels";
import DashTicketsEvolutionChannels from "../../services/Statistics/DashTicketsEvolutionChannels";
import DashTicketsEvolutionByPeriod from "../../services/Statistics/DashTicketsEvolutionByPeriod";
import DashTicketsPerUsersDetail from "../../services/Statistics/DashTicketsPerUsersDetail";
import DashTicketsQueue from "../../services/Statistics/DashTicketsQueue";
import DashTicketsEvolutionByHour from "../../services/Statistics/DashTicketsEvolutionByHour";
import DashTicketsUser from "../../services/Statistics/DashTicketsUser";
import DashTicketsActiveUsers from "../../services/Statistics/DashTicketsActiveUsers";
import DashTicketsStatus from "../../services/Statistics/DashTicketsStatus";
import { UserProfile } from "../../models/User"; // Asumiendo que UserProfile es un tipo/enum
import AppError from "../../errors/AppError"; // Necesario si manejas errores específicos

// Define una interfaz para los query params comunes si quieres más tipado
interface DateRangeQuery {
  startDate?: string;
  endDate?: string;
}

// Define una interfaz para el objeto req.user si está disponible y tipado
// interface AuthenticatedRequest extends Request {
//   user?: {
//     id: number | string; // o el tipo correcto para userId
//     tenantId: number;
//     profile: UserProfile; // o string si no es un enum/tipo
//   };
// }
// Y luego usa AuthenticatedRequest en lugar de Request

// Tipo para los parámetros de los servicios de dashboard
interface DashParams {
  startDate?: string;
  endDate?: string;
  tenantId: number;
  userId?: number | string; // opcional dependiendo del servicio
  userProfile?: UserProfile | string; // opcional
}

// Nota: Asumo que req.user contiene { id, tenantId, profile } después de la autenticación.
// Ajusta según tu middleware de autenticación.

export const getDashTicketsAndTimes = async (
  req: Request,
  res: Response
): Promise<Response> => {
  // Asegúrate de que req.user y sus propiedades existan.
  // Puedes usar validación o aserciones de tipo no nulo si estás seguro.
  const tenantId = req.user!.tenantId;
  const userId = req.user!.id;
  const userProfile = req.user!.profile;
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: DashParams = {
    startDate,
    endDate,
    tenantId,
    userId,
    userProfile
  };

  const ticketsAndTimes = await DashTicketsAndTimes(params);
  return res.json(ticketsAndTimes);
};

export const getDashTicketsChannels = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  const userId = req.user!.id;
  const userProfile = req.user!.profile;
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: DashParams = {
    startDate,
    endDate,
    tenantId,
    userId,
    userProfile
  };

  const ticketsChannels = await DashTicketsChannels(params);
  return res.json(ticketsChannels);
};

export const getDashTicketsEvolutionChannels = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  const userId = req.user!.id;
  const userProfile = req.user!.profile;
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: DashParams = {
    startDate,
    endDate,
    tenantId,
    userId,
    userProfile
  };

  const evolutionChannels = await DashTicketsEvolutionChannels(params);
  return res.json(evolutionChannels);
};

export const getDashTicketsEvolutionByPeriod = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  const userId = req.user!.id;
  const userProfile = req.user!.profile;
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: DashParams = {
    startDate,
    endDate,
    tenantId,
    userId,
    userProfile
  };

  const evolutionByPeriod = await DashTicketsEvolutionByPeriod(params);
  return res.json(evolutionByPeriod);
};

export const getDashTicketsPerUsersDetail = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  const userId = req.user!.id;
  const userProfile = req.user!.profile;
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: DashParams = {
    startDate,
    endDate,
    tenantId,
    userId,
    userProfile
  };

  const ticketsPerUsers = await DashTicketsPerUsersDetail(params);
  return res.json(ticketsPerUsers);
};

export const getDashTicketsQueue = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  const userId = req.user!.id;
  const userProfile = req.user!.profile;
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: DashParams = {
    startDate,
    endDate,
    tenantId,
    userId,
    userProfile
  };

  const ticketsQueue = await DashTicketsQueue(params);
  return res.json(ticketsQueue);
};

export const getDashTicketsEvolutionByHour = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  const userId = req.user!.id;
  const userProfile = req.user!.profile;
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: DashParams = {
    startDate,
    endDate,
    tenantId,
    userId,
    userProfile
  };

  const evolutionByHour = await DashTicketsEvolutionByHour(params);
  return res.json(evolutionByHour);
};

export const getDashTicketsUser = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  // userId y userProfile no se usan en el servicio original para este endpoint
  const { startDate, endDate } = req.query as DateRangeQuery;

  const params: DashParams = {
    // Solo se necesitan estos para el servicio original
    startDate,
    endDate,
    tenantId
  };

  const ticketsUser = await DashTicketsUser(params);
  return res.json(ticketsUser);
};

export const getDashTicketsActiveUsers = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  // startDate, endDate, userId, userProfile no se usan en el servicio original aquí
  const params: Partial<DashParams> = {
    // Solo se necesita tenantId
    tenantId
  };

  const activeUsers = await DashTicketsActiveUsers(params);
  return res.json(activeUsers);
};

export const getDashTicketsStatus = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const tenantId = req.user!.tenantId;
  // startDate, endDate, userId, userProfile no se usan en el servicio original aquí
  const params: Partial<DashParams> = {
    // Solo se necesita tenantId
    tenantId
  };

  try {
    const ticketsStatus = await DashTicketsStatus(params);
    return res.json(ticketsStatus);
  } catch (error) {
    // Log del error original
    console.error(error);
    // Podrías usar un logger más sofisticado aquí (Winston, Pino, etc.)

    // Devuelve una respuesta de error genérica al cliente
    // La traducción de "Erro ao buscar os dados dos tickets" a "Error al buscar los datos de los tickets"
    return res
      .status(500)
      .json({ error: "Error al buscar los datos de los tickets" });
    // O podrías usar tu clase AppError si el servicio la lanza
    // if (error instanceof AppError) {
    //    return res.status(error.statusCode).json({ error: error.message });
    // }
  }
};
