import { Socket } from 'socket.io';
import * as _ from 'lodash';
import {
    sendToSelf,
    sendToUser,
    sendToAllExcept,
    sortByKeys // Assuming sortByKeys is needed based on context
} from './Utils'; // Assuming Utils is in the same directory
import { shared as SharedIO } from './Index'; // Import shared state
import User from '../../models/User'; // Adjust path as necessary
import { logger } from '../../utils/logger'; // Adjust path as necessary

// Define interfaces
interface SocketAuth {
    user: any; // Replace 'any' with your User interface/type
    // Add other auth properties if they exist
}

interface SocketWithAuth extends Socket {
    handshake: Socket['handshake'] & {
        auth: SocketAuth;
    };
    // Add userId directly to socket for easier lookup?
    userId?: string | number;
    tenantId?: string | number;
}

interface ChatMessage {
    to: string | number; // User ID
    from: string | number; // User ID
    message: any; // Message content
    id: string; // Message ID?
    type: 's' | 'r'; // Sent or Received indicator?
}

interface TypingPayload {
    to: string | number; // User ID being typed to
    from: string | number; // User ID typing
    typing: boolean;
}

interface UserPayload {
    userId: string | number;
    remove?: boolean; // For saveChatWindow
}

// Event handlers map
const events: { [key: string]: (socket: SocketWithAuth) => void } = {};

/**
 * Handles joining the chat server.
 * Stores user and socket information in the shared state.
 */
const JoinChatServer = (socket: SocketWithAuth): void => {
    const { user } = socket.handshake.auth;
    logger.info(`User ${user.username} connected (${socket.id})`);
    const { tenantId } = user;
    const tenantRoom = `tenant_${tenantId}`;

    let room = SharedIO[tenantRoom];

    if (!room) {
        // Initialize room if it doesn't exist
        const newRoomState = { usersOnline: {}, idleUsers: {}, sockets: [] }; // Initialize based on previous Index.ts structure
        SharedIO[tenantRoom] = newRoomState;
        room = newRoomState;
    }

    if (room) {
        // Attach tenantId and userId to socket for easier access
        socket.tenantId = tenantId;
        socket.userId = user.id;

        // Add socket to room's list (if needed, original logic is a bit unclear)
        // room.sockets.push(socket); // This might cause memory issues if sockets aren't cleaned up

        // Update or add user to usersOnline
        let userState = room.usersOnline[user.id];
        if (!userState) {
            userState = { sockets: [], user: user };
            room.usersOnline[user.id] = userState;
        }
        if (!userState.sockets.includes(socket.id)) {
            userState.sockets.push(socket.id);
        }

        // Remove user from idle list if present
        delete room.idleUsers[user.id];

        // Join the Socket.IO room for the tenant
        socket.join(tenantRoom);

        // Send confirmation back to the user
        sendToSelf(socket, 'joinSuccessfully'); // Send simple confirmation

        // Notify others in the room about the new user (optional)
        // sendToAllExcept(io, socket.id, `tenant_${tenantId}`, 'userJoined', { user });

        // Send initial state (online/idle users) to the newly connected user
        UpdateOnlineBubbles(socket); // Update bubbles for this user
    }
};
events.JoinChatServer = JoinChatServer;


/**
 * Updates the list of online and idle users for all users in the tenant room.
 * Triggered when user list changes (connect, disconnect, idle, active).
 * THIS FUNCTION IS CALLED REPEATEDLY AND NEEDS OPTIMIZATION.
 */
const UpdateUsers = (socket: SocketWithAuth): void => {
    const { user } = socket.handshake.auth;
    const tenantRoom = `tenant_${user.tenantId}`;
    const room = SharedIO[tenantRoom];

    if (!room) return;

    // Prepare sorted lists of online and idle users
    // NOTE: Sorting on every update can be CPU intensive for large numbers of users.
    // Consider optimizing if performance issues arise.
    const sortedUserList = sortByKeys(
        _.mapValues(
            _.pickBy(room.usersOnline, (u) => u && u.sockets.length > 0), // Filter out users with no sockets
            (userInfo) => ({
                id: userInfo.user.id, // Include necessary user fields
                name: userInfo.user.name,
                email: userInfo.user.email,
                profile: userInfo.user.profile,
                 // Add other relevant fields for the frontend bubble
            })
        )
    );
    const sortedIdleList = sortByKeys(
        _.mapValues(room.idleUsers, (userInfo) => ({
            id: userInfo.user.id,
            name: userInfo.user.name,
            email: userInfo.user.email,
            profile: userInfo.user.profile,
            // Add other relevant fields
        }))
    );


    const payload = {
        usersOnline: sortedUserList,
        idleUsers: sortedIdleList
    };

    // Send the updated lists to everyone in the tenant's room
    // This includes the user who triggered the update
    sendToAllClientsInRoom(socket.nsp, tenantRoom, ':chat:updateUsers', payload);

};
events.UpdateUsers = UpdateUsers;


/**
 * Sends the current online/idle user lists to the requesting socket.
 */
const UpdateOnlineBubbles = (socket: SocketWithAuth): void => {
    const { user } = socket.handshake.auth;
    const tenantRoom = `tenant_${user.tenantId}`;
    const room = SharedIO[tenantRoom];

    if (!room) return;

    const sortedUserList = sortByKeys(
        _.mapValues(
            _.pickBy(room.usersOnline, (u) => u && u.sockets.length > 0),
             (userInfo) => ({ id: userInfo.user.id, name: userInfo.user.name, email: userInfo.user.email, profile: userInfo.user.profile })
         )
     );
     const sortedIdleList = sortByKeys(
         _.mapValues(room.idleUsers, (userInfo) => ({ id: userInfo.user.id, name: userInfo.user.name, email: userInfo.user.email, profile: userInfo.user.profile }))
     );

    const payload = {
        usersOnline: sortedUserList,
        idleUsers: sortedIdleList
    };
    // Send only to the requesting socket
    sendToSelf(socket, ':chat:updateOnlineUsers', payload);
};
events.UpdateOnlineBubbles = UpdateOnlineBubbles; // Export if needed elsewhere


/**
 * Spawns (sends) currently open chat windows/tickets for the user upon connection.
 */
const SpawnOpenChatWindows = async (socket: SocketWithAuth): Promise<void> => {
    const { user } = socket.handshake.auth;
    try {
        // Fetch user details including open tickets/chats
        // This requires database interaction and likely a specific service/query
        const userWithChats = await User.findByPk(user.id, {
             include: [
                 // Include relations needed to determine 'open chats'
                 // e.g., 'assignedTickets', 'participatingChats' - adjust based on your models
                 // { model: Ticket, where: { status: 'open', userId: user.id } } // Example
             ]
         });

        if (!userWithChats) {
            logger.warn(`User not found in database for spawning chats: ${user.id}`);
            sendToSelf(socket, ':error', { message: 'Error al procesar datos: Usuario no encontrado.' });
            return;
        }

        // Send the relevant chat data to the client
        sendToSelf(socket, ':spawn:open:chats', userWithChats); // Send fetched data

    } catch (error) {
        logger.error('Error fetching open chats for user:', error);
        sendToSelf(socket, ':error', { message: 'Error al buscar datos: Error al procesar requisición.' });
    }
};
events.SpawnOpenChatWindows = SpawnOpenChatWindows;


/**
 * Spawns a specific chat window when requested by the client.
 */
const spawnChatWindow = (socket: SocketWithAuth): void => {
    socket.on(':spawn:chat:window', async (userIdToSpawn: string | number) => {
        try {
             // Fetch details of the requested user
             const userToSpawnDetails = await User.findByPk(userIdToSpawn, {
                 attributes: ['id', 'name', 'email', 'profile'] // Select needed attributes
             });
             sendToSelf(socket, ':spawn:chat:window', userToSpawnDetails);
        } catch (error) {
             logger.error(`Error spawning chat window for user ${userIdToSpawn}:`, error);
             // Optionally send error back to client
             sendToSelf(socket, ':error', { message: `Error spawning chat for user ${userIdToSpawn}` });
        }
    });
};
events.spawnChatWindow = spawnChatWindow;


/**
 * Handles setting a user's status to idle.
 */
const onSetUserIdle = (socket: SocketWithAuth): void => {
    const { user } = socket.handshake.auth;
    const tenantRoom = `tenant_${user.tenantId}`;

    socket.on(`${user.id}:setUserIdle`, () => {
        let room = SharedIO[tenantRoom];

        // Ensure room exists
        if (!room) {
             // Initialize room if needed (should ideally exist if user is connected)
             room = { usersOnline: {}, idleUsers: {}, sockets: [] };
             SharedIO[tenantRoom] = room;
        }

        // Move user from online to idle
        const onlineUser = room.usersOnline[user.id];
        if (onlineUser) {
             // Add to idle list (only if not already there)
             if (!room.idleUsers[user.id]) {
                  room.idleUsers[user.id] = onlineUser;
             }
             // Remove from online list
             delete room.usersOnline[user.id];
             // Update bubbles for everyone in the room
             UpdateUsers(socket); // Trigger update for all
        } else {
             // User might already be disconnected or idle, ensure they are in idle list
             if (!room.idleUsers[user.id]) {
                  // If user data is needed here, fetch it or ensure it's available
                  // For simplicity, assuming user data might be stale if not online
                  room.idleUsers[user.id] = { sockets: [], user: user }; // Add with potentially stale user data
                  UpdateUsers(socket);
             }
        }
    });
};
events.onSetUserIdle = onSetUserIdle;


/**
 * Handles setting a user's status to active.
 */
const onSetUserActive = (socket: SocketWithAuth): void => {
    const { user } = socket.handshake.auth;
    const tenantRoom = `tenant_${user.tenantId}`;

    socket.on(`${user.id}:setUserActive`, () => {
        let room = SharedIO[tenantRoom];

        // Ensure room exists
        if (!room) {
            room = { usersOnline: {}, idleUsers: {}, sockets: [] };
            SharedIO[tenantRoom] = room;
        }

        // Move user from idle to online
        const idleUser = room.idleUsers[user.id];
        if (idleUser) {
            // Add to online list (only if not already there)
            if (!room.usersOnline[user.id]) {
                 room.usersOnline[user.id] = idleUser;
            }
            // Remove from idle list
            delete room.idleUsers[user.id];
            // Update bubbles for everyone
            UpdateUsers(socket);
        } else {
            // User might already be online or disconnected, ensure they are in online list
            if (!room.usersOnline[user.id]) {
                 // If user data is needed, ensure it's available (e.g., from auth)
                 room.usersOnline[user.id] = { sockets: [socket.id], user: user }; // Add with current socket
                 UpdateUsers(socket);
            }
        }
    });
};
events.onSetUserActive = onSetUserActive;


/**
 * Relays chat messages between users within the same tenant.
 */
const onChatMessage = (socket: SocketWithAuth): void => {
    const { user } = socket.handshake.auth;
    const { tenantId } = user;
    const tenantRoom = `tenant_${tenantId}`;

    socket.on(':chat:message', (messageData: ChatMessage) => {
        const room = SharedIO[tenantRoom];
        if (room) {
            const { to, from } = messageData; // Target and sender user IDs

            // Log message details
            // console.log('TO', to);
            // console.log('FROM', from);

            // Determine message type ('s' for sent, 'r' for received) based on sender/receiver
            const originalType = messageData.type; // Store original type if needed

            // Send message to recipient user(s)
            messageData.type = 'r'; // Mark as received for the recipient
            sendToUser(socket.nsp, room.usersOnline, to, ':chat:message', messageData);

            // Send message back to sender user(s) (confirmation or display in own window)
            messageData.type = 's'; // Mark as sent for the sender
            sendToUser(socket.nsp, room.usersOnline, from, ':chat:message', messageData);

            // Restore original type if it was modified and needed elsewhere
            messageData.type = originalType;
        }
    });
};
events.onChatMessage = onChatMessage;


/**
 * Relays typing indicator between users.
 */
const onChatTyping = (socket: SocketWithAuth): void => {
    const { user } = socket.handshake.auth;
    const { tenantId } = user;
    const tenantRoom = `tenant_${tenantId}`;

    socket.on(':chat:typing', (typingData: TypingPayload) => {
        const room = SharedIO[tenantRoom];
        if (room) {
            const { to, from } = typingData; // Target user ID and sender user ID

            const targetUser = room.usersOnline[to.toString()];
            const fromUser = room.usersOnline[from.toString()];

            if (!targetUser || !fromUser) {
                // console.warn('Typing indicator: Target or From user not found online.');
                return; // Don't send if target or sender isn't found online
            }

            typingData.typing = true; // Ensure typing state is true
            // Send typing indicator only to the target user
            sendToUser(socket.nsp, room.usersOnline, to, ':chat:typing', typingData);
        }
    });
};
events.onChatTyping = onChatTyping;


/**
 * Relays stop typing indicator between users.
 */
const onChatStopTyping = (socket: SocketWithAuth): void => {
    const { user } = socket.handshake.auth;
    const { tenantId } = user;
    const tenantRoom = `tenant_${tenantId}`;

    socket.on(':chat:stop:typing', (typingData: TypingPayload) => {
        const room = SharedIO[tenantRoom];
        if (room) {
            const { to } = typingData; // Only need the target user ID

            const targetUser = room.usersOnline[to.toString()];

            if (!targetUser) {
                // console.warn('Stop Typing indicator: Target user not found online.');
                return; // Don't send if target isn't found online
            }

            typingData.typing = false; // Ensure typing state is false
            // Send stop typing indicator only to the target user
            sendToUser(socket.nsp, room.usersOnline, to, ':chat:stop:typing', typingData);
        }
    });
};
events.onChatStopTyping = onChatStopTyping;


/**
 * Handles saving/removing chat window state (likely deprecated or unused).
 * Original logic seems flawed and database interaction is commented out.
 */
const saveChatWindow = (socket: SocketWithAuth): void => {
    socket.on(':save:chat:window', async (payload: UserPayload) => {
        // This function seems intended to update user preferences in the database,
        // but the database logic was missing or commented out in the original.
        // Re-implement database logic here if needed using User.findByPk and user.update()
        // Example:
        // const { userId, remove } = payload;
        // const userToUpdate = await User.findByPk(userId);
        // if (userToUpdate) {
        //     let currentChats = userToUpdate.getDataValue('openChats') || []; // Assuming 'openChats' field exists
        //     if (remove) {
        //         currentChats = currentChats.filter((chatId: number) => chatId !== /* chat id to remove */);
        //     } else {
        //         // Add chat id if not present
        //         if (!currentChats.includes(/* chat id to add */)) {
        //             currentChats.push(/* chat id to add */);
        //         }
        //     }
        //     await userToUpdate.update({ openChats: currentChats });
        // }
        logger.warn(':save:chat:window event received, but database logic is not implemented.');
    });
};
events.saveChatWindow = saveChatWindow;


/**
 * Handles socket disconnection.
 * Removes socket ID from user state, updates status if last socket, and notifies others.
 */
const onDisconnect = (socket: SocketWithAuth): void => {
    socket.on('disconnect', async (reason: string) => {
        const { user } = socket.handshake.auth;
        if (!user || !user.tenantId || !user.id) {
            logger.info(`Socket ${socket.id} disconnected without valid user auth.`);
            return; // Cannot process disconnect without user info
        }

        const { tenantId } = user;
        const tenantRoom = `tenant_${tenantId}`;
        const room = SharedIO[tenantRoom];

        logger.info(`User disconnected (${reason}): ${user.username} (${user.id}) Socket: ${socket.id}`);

        if (room) {
            // Remove socket from user's online list
            const onlineUser = room.usersOnline[user.id];
            if (onlineUser) {
                 onlineUser.sockets = _.without(onlineUser.sockets, socket.id);
                 // If no sockets left, remove user from online list
                 if (onlineUser.sockets.length === 0) {
                      delete room.usersOnline[user.id];
                 }
            }

            // Remove socket from user's idle list (if they disconnected while idle)
            const idleUser = room.idleUsers[user.id];
            if (idleUser) {
                idleUser.sockets = _.without(idleUser.sockets, socket.id);
                 // If no sockets left, remove user from idle list
                 if (idleUser.sockets.length === 0) {
                     delete room.idleUsers[user.id];
                 }
            }

            // Remove socket from the general room list (if used)
            // room.sockets = _.without(room.sockets, socket); // Be careful with storing full socket objects

             // Update user status in database to offline
             try {
                 const userDb = await User.findByPk(user.id);
                 if (userDb) {
                     await userDb.update({
                         status: 'offline',
                         lastOnline: new Date()
                     });
                 }
             } catch (dbError) {
                 logger.error(`Error updating user status on disconnect for user ${user.id}:`, dbError);
             }

            // Notify remaining users in the room
            UpdateUsers(socket); // Trigger update for others
        }

    });
};
events.onDisconnect = onDisconnect;


//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
/**
 * Registers all chat-related event listeners for a given socket connection.
 * @param socket The socket instance to register listeners on.
 */
export function register(socket: SocketWithAuth): void {
    if (!socket.handshake?.auth?.user?.id) {
        logger.warn(`Attempted to register events for socket ${socket.id} without user authentication.`);
        // Optionally disconnect the socket if auth is mandatory
        // socket.disconnect(true);
        return;
    }

    // Register all defined event handlers
    events.onSetUserIdle(socket);
    events.onSetUserActive(socket);
    events.onUpdateUsers(socket); // Client might request explicit update
    events.SpawnOpenChatWindows(socket);
    events.spawnChatWindow(socket);
    events.onChatMessage(socket);
    events.onChatTyping(socket);
    events.onChatStopTyping(socket);
    events.saveChatWindow(socket); // Likely unused/deprecated
    events.onDisconnect(socket);

    // Initial actions upon successful connection registration
    JoinChatServer(socket); // Handle user joining
}

/**
 * Periodic loop to update user lists (can be intensive).
 * Consider replacing with event-driven updates if possible.
 * @param io Socket.IO Server or Namespace instance
 */
export const eventLoop = (io: any): void => {
    // This function seems intended to periodically update all users.
    // This is generally inefficient compared to emitting updates only when changes occur.
    // If kept, use with caution and a reasonable interval.
    // Example (if needed):
    // setInterval(() => {
    //      Object.keys(SharedIO).forEach(tenantRoomKey => {
    //           const room = SharedIO[tenantRoomKey];
    //           if (room) {
    //                // Simulate an update trigger - find one socket in the room to use as context
    //                const firstSocketId = room.usersOnline[Object.keys(room.usersOnline)[0]]?.sockets[0];
    //                const socketInstance = io.sockets.sockets.get(firstSocketId);
    //                if (socketInstance) {
    //                     UpdateUsers(socketInstance as SocketWithAuth);
    //                     UpdateOnlineBubbles(socketInstance as SocketWithAuth); // Maybe redundant if UpdateUsers sends to all
    //                }
    //           }
    //      });
    // }, 5000); // Example: Update every 5 seconds
    logger.warn("Periodic eventLoop is defined but currently inactive. Use event-driven updates for better performance.");
};

// Export the main chat object containing register and eventLoop
export const chat = {
    events,
    eventLoop,
    register
};