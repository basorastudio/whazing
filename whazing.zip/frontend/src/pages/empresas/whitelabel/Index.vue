<template>
  <div class="mass-container container-rounded-10" :class="$q.dark.isActive ? ('text-white bg-grey-10') : 'container-border'">

    <q-banner v-if="!premium" dense inline-actions class="bg-amber-8 text-white q-mb-md">
      <template v-slot:avatar>
        <q-icon name="star" />
      </template>
      {{ $t('general.msgRecursoPremium') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               icon="mdi-whatsapp"
               :label="$t('general.linkobterpremium')"
               @click="abrirWhatsApp3"
        />
      </template>
    </q-banner>

    <q-list class="text-weight-medium"/>
    <q-item-label :class="$q.dark.isActive ? ('text-color-dark') : ''">{{ $t('whitelabel.moduloWhiteLabel') }}</q-item-label>
    <q-separator spaced />

    <div class="row q-px-md">
      <div class="col-12">
        <q-item-label :class="$q.dark.isActive ? ('text-color-dark') : ''">{{ $t('whitelabel.alteracaoLogoTitulo') }}</q-item-label>
        <q-item-section>
          <q-input :disabled="!premium" :readonly="!premium" v-model="title" type="textarea" autogrow dense outlined :label="$t('whitelabel.tituloSite')"
                   input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                   @input="atualizarConfiguracao('title')" />

          <q-item tag="label" v-ripple>
            <q-item-section>
              <q-item-label>{{ $t('whitelabel.selecionarImagem') }}</q-item-label>
            </q-item-section>
            <q-item-section avatar>
              <q-select
                :disabled="!premium"
                :readonly="!premium"
                style="width: 300px"
                outlined
                dense
                v-model="selectedFileType"
                :options="fileOptions"
                emit-value
                option-value="value"
                option-label="label"
                @input="handleFileTypeChange"
              />
            </q-item-section>
          </q-item>

          <q-item tag="label" v-ripple>
            <q-item-section>
              <q-item-label>{{ $t('whitelabel.novoArquivo') }}</q-item-label>
            </q-item-section>
            <q-item-section avatar>
              <input
                :readonly="!premium"
                type="file"
                @change="onFileChangeLogo"
                ref="fileInput"
                class="q-mt-md"
                :accept="fileAcceptType"
                :disabled="!selectedFileType"
              />
            </q-item-section>
          </q-item>
        </q-item-section>
      </div>
    </div>

      <div class="col-12">
        <q-item tag="label" v-ripple>
          <q-item-section>
            <q-item-label :class="$q.dark.isActive ? ('text-color-dark') : ''">{{ $t('whitelabel.whatsappSuporte') }}</q-item-label>
            <q-input :disabled="!premium" :readonly="!premium" v-model="whatsappnumber" type="number" autogrow dense outlined
                     :label="$t('whitelabel.whatsappSuporte')" input-style="min-height: 6vh; max-height: 9vh;" debounce="700"
                     @input="atualizarConfiguracao('whatsappnumber')" />
          </q-item-section>
        </q-item>
      </div>

    <div class="row q-px-md">
      <div class="col-12 q-mb-sm">
        <q-input
          :disabled="!premium"
          :readonly="!premium"
          :label="$t('whitelabel.cor1')"
          filled
          hide-bottom-space
          :style="`background: ${cor1} `"
          v-model="cor1"
          :rules="['anyColor']"
          class="q-my-md"
          :dark="false"
          rounded
          @input="atualizarConfiguracao('cor1')"
        >
          <template v-slot:preappend>
          </template>
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer"
            >
              <q-popup-proxy
                transition-show="scale"
                transition-hide="scale"
              >
                <q-color
                  format-model="hex"
                  rounded
                  default-view="palette"
                  no-header
                  bordered
                  v-model="cor1"
                  @input="atualizarConfiguracao('cor1')"
                />
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          :disabled="!premium"
          :readonly="!premium"
          :label="$t('whitelabel.cor2')"
          filled
          hide-bottom-space
          :style="`background: ${cor2} `"
          v-model="cor2"
          :rules="['anyColor']"
          class="q-my-md"
          :dark="false"
          rounded
          @input="atualizarConfiguracao('cor2')"
        >
          <template v-slot:preappend>
          </template>
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer"
            >
              <q-popup-proxy
                transition-show="scale"
                transition-hide="scale"
              >
                <q-color
                  format-model="hex"
                  rounded
                  default-view="palette"
                  no-header
                  bordered
                  v-model="cor2"
                  @input="atualizarConfiguracao('cor2')"
                />
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          :disabled="!premium"
          :readonly="!premium"
          :label="$t('whitelabel.cor3')"
          filled
          hide-bottom-space
          :style="`background: ${textcor1} `"
          v-model="textcor1"
          :rules="['anyColor']"
          class="q-my-md"
          :dark="false"
          rounded
          @input="atualizarConfiguracao('textcor1')"
        >
          <template v-slot:preappend>
          </template>
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer"
            >
              <q-popup-proxy
                transition-show="scale"
                transition-hide="scale"
              >
                <q-color
                  format-model="hex"
                  rounded
                  default-view="palette"
                  no-header
                  bordered
                  v-model="textcor1"
                  @input="atualizarConfiguracao('textcor1')"
                />
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          :disabled="!premium"
          :readonly="!premium"
          :label="$t('whitelabel.cor1Dark')"
          filled
          hide-bottom-space
          :style="`background: ${cor1dark} `"
          v-model="cor1dark"
          :rules="['anyColor']"
          class="q-my-md"
          :dark="false"
          rounded
          @input="atualizarConfiguracao('cor1dark')"
        >
          <template v-slot:preappend>
          </template>
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer"
            >
              <q-popup-proxy
                transition-show="scale"
                transition-hide="scale"
              >
                <q-color
                  format-model="hex"
                  rounded
                  default-view="palette"
                  no-header
                  bordered
                  v-model="cor1dark"
                  @input="atualizarConfiguracao('cor1dark')"
                />
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          :disabled="!premium"
          :readonly="!premium"
          :label="$t('whitelabel.cor2Dark')"
          filled
          hide-bottom-space
          :style="`background: ${cor2dark} `"
          v-model="cor2dark"
          :rules="['anyColor']"
          class="q-my-md"
          :dark="false"
          rounded
          @input="atualizarConfiguracao('cor2dark')"
        >
          <template v-slot:preappend>
          </template>
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer"
            >
              <q-popup-proxy
                transition-show="scale"
                transition-hide="scale"
              >
                <q-color
                  format-model="hex"
                  rounded
                  default-view="palette"
                  no-header
                  bordered
                  v-model="cor2dark"
                  @input="atualizarConfiguracao('cor2dark')"
                />
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>

      <div class="col-12 q-mb-sm">
        <q-input
          :disabled="!premium"
          :readonly="!premium"
          :label="$t('whitelabel.cor3Dark')"
          filled
          hide-bottom-space
          :style="`background: ${textcor1dark} `"
          v-model="textcor1dark"
          :rules="['anyColor']"
          class="q-my-md"
          :dark="false"
          rounded
          @input="atualizarConfiguracao('textcor1dark')"
        >
          <template v-slot:preappend>
          </template>
          <template v-slot:append>
            <q-icon
              name="colorize"
              class="cursor-pointer"
            >
              <q-popup-proxy
                transition-show="scale"
                transition-hide="scale"
              >
                <q-color
                  format-model="hex"
                  rounded
                  default-view="palette"
                  no-header
                  bordered
                  v-model="textcor1dark"
                  @input="atualizarConfiguracao('textcor1dark')"
                />
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
      </div>
    </div>

  </div>
</template>

<script>
import { ListarConfiguracoesGeneral, AlterarConfiguracaoGeneral, Listarp } from 'src/service/configuracoesgeneral'
import { UploadLogo } from 'src/service/empresas'

export default {
  name: 'ConfiguracoesWhiteLabel',
  data() {
    return {
      fileOptions: [
        { label: this.$t('whitelabel.logoTelaLogin'), value: 'login' },
        { label: this.$t('whitelabel.logoCadastro'), value: 'signup' },
        { label: this.$t('whitelabel.logoTelaAtendimento'), value: 'atendimento' },
        { label: this.$t('whitelabel.favicon16'), value: 'favicon-16x16' },
        { label: this.$t('whitelabel.favicon32'), value: 'favicon-32x32' },
        { label: this.$t('whitelabel.favicon96'), value: 'favicon-96x96' },
        { label: this.$t('whitelabel.icon128'), value: 'icon-128x128' },
        { label: this.$t('whitelabel.icon192'), value: 'icon-192x192' },
        { label: this.$t('whitelabel.icon256'), value: 'icon-256x256' },
        { label: this.$t('whitelabel.icon384'), value: 'icon-384x384' },
        { label: this.$t('whitelabel.icon512'), value: 'icon-512x512' },
        { label: this.$t('whitelabel.faviconIco'), value: 'favicon' }
      ],
      configuracoes: [],
      allowSignup: null,
      apienviarwhatsapp: null,
      apiendpoint: '',
      apitoken: '',
      apiexternalKey: '',
      apimessage: '',
      timeTest: '',
      informative: null,
      paymentGateway: null,
      openColorPicker: false,
      openColorPicker2: false,
      openColorPicker3: false,
      openColorPicker4: false,
      openColorPicker5: false,
      openColorPicker6: false,
      premium: true,
      efiClientId: '',
      efiClientSecret: '',
      efiPixKey: '',
      title: '',
      filename: '',
      habilitasmtp: '',
      selectedFileType: null,
      fileAcceptType: '',
      whatsappnumber: null,
      cor1: '#ffffff',
      cor2: '#ffffff',
      textcor1: '#ffffff',
      cor1dark: '#ffffff',
      cor2dark: '#ffffff',
      textcor1dark: '#ffffff'
    }
  },
  methods: {
    async listarConfiguracoes() {
      const { data } = await ListarConfiguracoesGeneral()
      this.configuracoes = data
      this.configuracoes.forEach(el => {
        const value = el.value
        this.$data[el.key] = value
      })
    },
    async atualizarConfiguracao(key) {
      const params = {
        key,
        value: this.$data[key]
      }
      try {
        await AlterarConfiguracaoGeneral(params)
        this.$q.notify({
          type: 'positive',
          message: this.$t('whitelabel.configuracaoAlterada'),
          progress: true,
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (error) {
        console.error('error - AlterarConfiguracao', error)
        this.$data[key] = this.$data[key] === 'enabled' ? 'disabled' : 'enabled'
        this.$notificarErro(this.$t('whitelabel.erro'), error)
      }
    },
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    async onFileChangeLogo(event) {
      const file = event.target.files[0]
      if (file) {
        try {
          await UploadLogo(file, this.selectedFileType)
          this.filename = file.name
          this.$q.notify({
            type: 'positive',
            message: this.$t('whitelabel.arquivoEnviadoSucesso'),
            progress: true,
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        } catch (error) {
          console.error('Erro ao enviar arquivo', error)
          this.$q.notify({
            type: 'negative',
            message: this.$t('whitelabel.erroEnviarArquivo'),
            progress: true,
            actions: [{
              icon: 'close',
              round: true,
              color: 'white'
            }]
          })
        }
      }
    },
    handleFileTypeChange(value) {
      // Atualiza o tipo de arquivo aceito com base na seleção
      switch (value) {
        case 'login':
        case 'signup':
        case 'atendimento':
        case 'favicon-16x16':
        case 'favicon-96x96':
        case 'icon-128x128':
        case 'icon-192x192':
        case 'icon-256x256':
        case 'icon-384x384':
        case 'icon-512x512':
          this.fileAcceptType = 'image/png'
          break
        case 'favicon':
          this.fileAcceptType = 'image/x-icon'
          break
        default:
          this.fileAcceptType = ''
      }
    }
  },
  async mounted() {
    await this.listarConfiguracoes()
    await this.loadVersionp()
  }
}
</script>

<style scoped>

</style>
