import UpdateTicketService from "../services/UpdateTicketService"; // Assuming service path

// Define Ticket type or import it
interface TicketType {
  id: number | string;
  // other properties
}

const UpdateDeletedUserOpenTicketsStatus = async (
  tickets: TicketType[],
  tenantId: number | string,
  userIdRequest?: number | string | null // ID of user performing the action (optional)
): Promise<void> => {
  if (!tickets || tickets.length === 0) {
    console.log(
      "No hay tickets abiertos para actualizar para el usuario eliminado."
    );
    return;
  }

  console.log(
    `Actualizando ${tickets.length} tickets abiertos a 'pending' para el usuario eliminado en el tenant ${tenantId}`
  );

  // Use Promise.all for concurrent updates
  await Promise.all(
    tickets.map(async ticket => {
      const ticketId = ticket.id;
      const ticketData = {
        status: "pending", // Set status to pending
        userId: null, // Unassign the user
        // queueId: null,  // Optionally unassign the queue as well
        tenantId: tenantId // Pass tenantId for service validation/context
      };

      try {
        await UpdateTicketService({
          ticketData: ticketData,
          ticketId: ticketId,
          userIdRequest: userIdRequest // Pass the requesting user ID if available
        });
        console.log(`Ticket ${ticketId} actualizado a pending.`);
      } catch (error) {
        console.error(`Error al actualizar el ticket ${ticketId}:`, error);
        // Decide how to handle individual ticket update errors (e.g., log and continue)
      }
    })
  );

  console.log(
    `Actualización completada para los tickets del usuario eliminado.`
  );
};

export default UpdateDeletedUserOpenTicketsStatus;
