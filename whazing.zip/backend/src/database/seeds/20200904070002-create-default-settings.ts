'use strict';
import { QueryInterface } from 'sequelize';

export default {
    up: async (queryInterface: QueryInterface) => {
        // Inserta múltiples configuraciones predeterminadas para el tenant 1
        return queryInterface.sequelize.query(`
      INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('userRating', 'enabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('scheduleTimes', '10', '2022-12-16 16:08:45.354', '2022-12-16 16:08:45.354', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('call', 'disabled', '2022-12-16 16:08:45.354', '2022-12-16 16:08:45.354', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('chatbot', 'disabled', '2022-12-16 16:08:45.354', '2022-12-16 16:08:45.354', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('checkMsgIsGroup', 'enabled', '2022-12-16 16:08:45.354', '2022-12-16 16:08:45.354', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('NotViewTicketsQueueUser', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('NotViewTicketsChatBot', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('DirectTicketsToWallets', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('DirectTicketActive', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
          INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('NotViewAssignedTickets', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);

INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('botTicketActive', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('spyticket', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('HideTicketContactsName', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('ContactTab', 'enabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);

INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendGreetingAccepted', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendGreetingClosed', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendQueue', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendRated', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendFarewell', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendTransfer', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('acceptCallWhatsapp', 'enabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('AutoRejectCalls', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('rejectCalls', 'Olá! No momento, as chamadas de voz e vídeo estão desabilitadas para este WhatsApp, por favor envie uma mensagem de texto.', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('ignoreGroupMsg', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendSign', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('userDisableSignature', 'disabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendGreetingMessageOneQueues', 'enabled', '2020-12-12 16:08:45.354', '2020-12-12 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendMsgTransfTicket', 'disabled', '2022-12-16 16:08:45.354', '2022-12-16 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('sendMsgCloseTicket', 'disabled', '2022-12-16 16:08:45.354', '2022-12-16 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('closeTicketImport', 'disabled', '2022-12-16 16:08:45.354', '2022-12-16 16:08:45.354', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('NotViewCloseTickets', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('NotViewTicketsClosed', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('DirectTicketsToOfflineUser', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('GroupTicketsClosed', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('GroupTicketsQueue', 'disabled', '2022-12-16 21:10:02.076', '2022-12-16 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('hubProtocol', '3000', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('hubToken', '', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('hubWebhook', '', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('universalCounter', 'disabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('AuditMode', 'disabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('DirectCloseTicket', 'disabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('ExibirConexao', 'disabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('HideTicketNumber', 'disabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('TicketsLimitPending', '30', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('maxRetries', '3', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('reopenTicket', '30', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('KanbanGlobal', 'enabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('KanbanUserNull', 'enabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('KanbanNoTicket', 'disabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('KanbanLane', 'disabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('TicketsLimitOpen', '30', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('autoPending', 'disabled', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
INSERT INTO public."Settings" ("key", value, "createdAt", "updatedAt", "tenantId") VALUES('autoPendingingTime', '30', '2022-07-01 21:10:02.076', '2022-07-01 21:10:02.076', 1);
    `);
    },

    down: async (queryInterface: QueryInterface) => {
        // Elimina todos los registros de la tabla Settings (¡cuidado en producción!)
        return queryInterface.bulkDelete('Settings', {});
    }
};