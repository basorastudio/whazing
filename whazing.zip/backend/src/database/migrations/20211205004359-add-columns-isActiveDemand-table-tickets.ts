import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'isActiveDemand' column to the 'Tickets' table
    await queryInterface.addColumn(
      'Tickets',        // Table name
      'isActiveDemand', // New column name
      {
        type: DataTypes.BOOLEAN,
        allowNull: false,    // Cannot be null
        defaultValue: false, // Default to false
      }
    );
    // Original code wrapped this in Promise.all, unnecessary here.
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'isActiveDemand' column from the 'Tickets' table
    await queryInterface.removeColumn(
      'Tickets',        // Table name
      'isActiveDemand'  // Column name to remove
    );
     // Original code wrapped this in Promise.all, unnecessary here.
  }
};

export = migration;