// --- START OF FILE InvoicesController.ts ---

import type { Request, Response } from 'express';
import FindAllInvoiceService from '../services/InvoicesServices/FindAllInvoiceService'; // Assuming path
import ListInvoicesServices from '../services/InvoicesServices/ListInvoicesService'; // Assuming path
import ShowInvoiceService from '../services/InvoicesServices/ShowInvoiceService';   // Assuming path

type IndexQuery = {
  searchParam?: string;
  pageNumber?: string;
};

export const index = async (req: Request, res: Response): Promise<Response> => {
  const { searchParam, pageNumber } = req.query as IndexQuery;

  const { invoices, count, hasMore } = await ListInvoicesServices({
    searchParam,
    pageNumber
  });

  return res.json({ invoices, count, hasMore });
};

export const show = async (req: Request, res: Response): Promise<Response> => {
  const { Invoiceid } = req.params; // Parameter name likely case-sensitive

  const invoice = await ShowInvoiceService(Invoiceid); // Pass the ID as string

  return res.status(200).json(invoice);
};

// Assuming 'list' is intended to find all for a specific tenant?
// The original 'list' service name 'FindAllInvoiceService' implies this.
export const list = async (req: Request, res: Response): Promise<Response> => {
  const { tenantId } = req.user; // Assuming tenantId is needed

  const invoices = await FindAllInvoiceService(tenantId); // Pass tenantId

  return res.status(200).json(invoices);
};

// --- END OF FILE InvoicesController.ts ---