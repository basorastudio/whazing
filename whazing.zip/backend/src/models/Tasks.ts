import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AllowNull,
  AutoIncrement
} from "sequelize-typescript";
import Tenant from "./Tenant";
import User from "./User";

@Table
class Task extends Model<Task> {
  // Renamed class to singular
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @AllowNull(true)
  @Default(null)
  @Column(DataType.TEXT)
  name: string | null; // Assuming 'name' is the column

  @AllowNull(true)
  @Default(null)
  @Column(DataType.TEXT)
  description: string | null; // 'description' resolved

  @AllowNull(true)
  @Default(null)
  @Column(DataType.DATE) // Use DATE type
  limitDate: Date | null;

  @AllowNull(true)
  @Default(null)
  @Column
  priority: string | null; // Assuming string

  @AllowNull(true)
  @Default(null)
  @Column
  status: string | null;

  @AllowNull(true)
  @Default(null)
  @Column
  owner: string | null; // Assuming string

  @AllowNull(true)
  @Default(null)
  @Column(DataType.TEXT) // Assuming TEXT for potentially long comments
  comments: string | null;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;
}

export default Task; // Changed export name
