import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'lastOnline' (DATE) a 'Users'
    return Promise.all([
      queryInterface.addColumn('Users', 'lastOnline', {
        type: DataTypes.DATE,
        allowNull: true, // Permite nulos
        defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'lastOnline' de 'Users'
    return Promise.all([
      queryInterface.removeColumn('Users', 'lastOnline')
    ]);
  }
};