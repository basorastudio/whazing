import { Request, Response } from "express";
import * as Yup from "yup";
import AppError from "../errors/AppError";
import ListTicketNotesService from "../services/TicketNoteServices/ListTicketNotesService";
import CreateTicketNoteService from "../services/TicketNoteServices/CreateTicketNoteService";
import UpdateTicketNoteService from "../services/TicketNoteServices/UpdateTicketNoteService";
import DeleteTicketNoteService from "../services/TicketNoteServices/DeleteTicketNoteService";
import FindNotesByTicketId from "../services/TicketNoteServices/FindNotesByTicketId";
import FindNotesByContactId from "../services/TicketNoteServices/FindNotesByContactId";

// Interfaz para los parámetros de consulta de la lista
interface ListTicketNotesQuery {
  searchParam?: string;
  pageNumber?: string;
}

// Interfaz para el cuerpo de la solicitud de creación/actualización
interface TicketNoteBody {
  note?: string;
  ticketId?: string | number; // El ticketId viene en params para store/update/delete
  contactId?: string | number; // El contactId viene en params para findFilteredListContact
  // userId y tenantId se añadirán internamente
}

// Extiende la interfaz Request
interface TicketNoteRequest extends Request {
  user?: {
    id: string | number;
    tenantId: string | number;
    profile: string; // Asumiendo que profile existe
  };
  body: TicketNoteBody;
  query: ListTicketNotesQuery;
  params: {
    id?: string; // ID de la nota para update/delete
    ticketId?: string; // ID del ticket para store y findFilteredList
    contactId?: string; // ID del contacto para findFilteredListContact
  };
}

// Esquema de validación para creación/actualización de nota
const ticketNoteSchema = Yup.object().shape({
  note: Yup.string().required()
});

export const index = async (
  req: TicketNoteRequest,
  res: Response
): Promise<Response> => {
  const { searchParam, pageNumber } = req.query;
  const { tenantId } = req.user!; // Asumiendo que tenantId siempre está en user

  const params = {
    searchParam,
    pageNumber,
    tenantId: Number(tenantId) // El servicio espera un número
  };

  const { ticketNotes, count, hasMore } = await ListTicketNotesService(params);

  return res.status(200).json({ ticketNotes, count, hasMore });
};

export const store = async (
  req: TicketNoteRequest,
  res: Response
): Promise<Response> => {
  const { tenantId, id: userId } = req.user!;
  const { ticketId } = req.params;
  const noteData = req.body;

  if (!ticketId) {
    throw new AppError("ticketId parameter is missing", 400); // "Falta el parámetro ticketId"
  }

  try {
    await ticketNoteSchema.validate(noteData);
  } catch (err: any) {
    throw new AppError(err.message, 400);
  }

  const dataToCreate = {
    ...noteData,
    userId: Number(userId),
    tenantId: Number(tenantId),
    ticketId: Number(ticketId) // Añade ticketId de los parámetros
  };

  const ticketNote = await CreateTicketNoteService(dataToCreate);

  // El original no usaba 201, pero es lo semánticamente correcto para store
  return res.status(201).json(ticketNote);
};

export const update = async (
  req: TicketNoteRequest,
  res: Response
): Promise<Response> => {
  const noteData = req.body;
  const { id: noteId } = req.params; // ID de la nota a actualizar
  const { tenantId } = req.user!; // Necesario para el servicio de actualización

  if (!noteId) {
    throw new AppError("Note ID parameter is missing", 400); // "Falta el parámetro de ID de nota"
  }

  try {
    await ticketNoteSchema.validate(noteData);
  } catch (err: any) {
    throw new AppError(err.message, 400);
  }

  // El servicio UpdateTicketNoteService probablemente necesite noteId y tenantId además de los datos
  // Asumiendo que el servicio espera un objeto con `note`, `noteId`, `tenantId`
  const dataToUpdate = {
    ...noteData,
    noteId: noteId, // Pasa el ID de la nota
    tenantId: Number(tenantId)
  };

  const ticketNote = await UpdateTicketNoteService(dataToUpdate); // Ajusta según la firma real del servicio

  return res.status(200).json(ticketNote);
};

export const remove = async (
  req: TicketNoteRequest,
  res: Response
): Promise<Response> => {
  const { id: noteId } = req.params; // ID de la nota a eliminar
  const { tenantId } = req.user!;

  if (!noteId) {
    throw new AppError("Note ID parameter is missing", 400); // "Falta el parámetro de ID de nota"
  }

  await DeleteTicketNoteService(noteId, Number(tenantId)); // Pasa ID y tenantId

  return res.status(200).json({ message: "Observation removed" }); // "Observación removida"
};

export const findFilteredList = async (
  req: TicketNoteRequest,
  res: Response
): Promise<Response> => {
  const { ticketId } = req.params;
  const { tenantId } = req.user!;

  if (!ticketId) {
    throw new AppError("ticketId parameter is missing", 400); // "Falta el parámetro ticketId"
  }

  try {
    const notes = await FindNotesByTicketId({
      ticketId: Number(ticketId),
      tenantId: Number(tenantId)
    });
    return res.status(200).json(notes);
  } catch (error: any) {
    // Devuelve un error 500 si el servicio falla
    return res.status(500).json({ message: error.message });
  }
};

export const findFilteredListContact = async (
  req: TicketNoteRequest,
  res: Response
): Promise<Response> => {
  const { contactId } = req.params;
  const { tenantId } = req.user!;

  if (!contactId) {
    throw new AppError("contactId parameter is missing", 400); // "Falta el parámetro contactId"
  }

  try {
    const notes = await FindNotesByContactId({
      contactId: Number(contactId),
      tenantId: Number(tenantId)
    });
    return res.status(200).json(notes);
  } catch (error: any) {
    // Devuelve un error 500 si el servicio falla
    return res.status(500).json({ message: error.message });
  }
};
