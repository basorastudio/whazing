import { Request, Response } from 'express';
import * as Yup from 'yup';
import CreateStepsReplyService from '../services/StepsReplyServices/CreateStepsReplyService'; // Ajustar ruta
import AppError from '../errors/AppError';
import UpdateStepsReplyService from '../services/StepsReplyServices/UpdateStepsReplyService'; // Ajustar ruta
import DeleteStepsReplyService from '../services/StepsReplyServices/DeleteStepsReplyService'; // Ajustar ruta

interface StepsReplyBody {
    reply?: string;
    idAutoReply?: number | string; // Asumiendo que es numérico, pero puede venir como string
    initialStep?: boolean | string; // Asumiendo que es booleano, pero puede venir como string
    // Otras propiedades si existen
}

interface UserRequest extends Request {
    user?: {
        id: string | number;
        profile: string;
        // otras propiedades
    };
    body: StepsReplyBody;
    params: {
      stepsReplyId?: string; // ID para update y delete
    }
}

// Esquema de validación para creación/actualización
const stepsReplySchema = Yup.object().shape({
    reply: Yup.string().required(),
    idAutoReply: Yup.number().required(), // Usar number si es el tipo correcto
    userId: Yup.number().required(), // Añadido en el controlador original
    initialStep: Yup.boolean().required() // Usar boolean si es el tipo correcto
});

export const store = async (req: UserRequest, res: Response): Promise<Response> => {
    // Verifica si el usuario es administrador
    if (req.user?.profile !== 'admin') {
        throw new AppError('ERR_NO_PERMISSION', 403); // "ERR_SIN_PERMISO"
    }

    const stepsReplyData = { ...req.body };
    // Añade userId al objeto de datos desde el usuario autenticado
    stepsReplyData.userId = req.user?.id;

    try {
        // Valida los datos combinados
        await stepsReplySchema.validate(stepsReplyData);
    } catch (err: any) {
        throw new AppError(err.message || 'Validation Error', 400); // "Error de Validación"
    }

    // Llama al servicio para crear
    const stepsReply = await CreateStepsReplyService(stepsReplyData);

    // Devuelve la respuesta creada (201)
    return res.status(201).json(stepsReply);
};

export const update = async (req: UserRequest, res: Response): Promise<Response> => {
    // Verifica si el usuario es administrador
    if (req.user?.profile !== 'admin') {
        throw new AppError('ERR_NO_PERMISSION', 403); // "ERR_SIN_PERMISO"
    }

    const stepsReplyData = { ...req.body };
     // Añade userId al objeto de datos desde el usuario autenticado (si la lógica de negocio lo requiere para actualizar)
    stepsReplyData.userId = req.user?.id;

    try {
        // Valida los datos (puede que quieras un esquema diferente para update)
        // Usando el mismo esquema por ahora
        await stepsReplySchema.validate(stepsReplyData);
    } catch (err: any) {
        throw new AppError(err.message || 'Validation Error', 400); // "Error de Validación"
    }

    const { stepsReplyId } = req.params;
    if (!stepsReplyId) {
         throw new AppError('Missing stepsReplyId parameter', 400); // "Falta parámetro stepsReplyId"
    }

    const updateData = {
        stepsReplyData: stepsReplyData,
        stepsReplyId: stepsReplyId
    };

    // Llama al servicio para actualizar
    const stepsReply = await UpdateStepsReplyService(updateData);

    // Devuelve la respuesta actualizada (200)
    return res.status(200).json(stepsReply);
};

export const remove = async (req: UserRequest, res: Response): Promise<Response> => {
    // Verifica si el usuario es administrador
    if (req.user?.profile !== 'admin') {
        throw new AppError('ERR_NO_PERMISSION', 403); // "ERR_SIN_PERMISO"
    }

    const { stepsReplyId } = req.params;
    if (!stepsReplyId) {
         throw new AppError('Missing stepsReplyId parameter', 400); // "Falta parámetro stepsReplyId"
    }

    // Llama al servicio para eliminar
    await DeleteStepsReplyService(stepsReplyId);

    // Devuelve una respuesta de éxito sin contenido (200 o 204)
    // El original devolvía un JSON, lo mantenemos por fidelidad
    return res.status(200).json({ message: 'Steps reply deleted' }); // "Respuesta de pasos eliminada"
};