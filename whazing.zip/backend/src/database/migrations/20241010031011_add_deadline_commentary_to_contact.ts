import { QueryInterface, DataTypes } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add 'deadline' and 'commentary' columns to 'Contacts' table
    await queryInterface.addColumn("Contacts", "deadline", {
      type: DataTypes.DATE,
      allowNull: true,
      defaultValue: null
    });
    await queryInterface.addColumn("Contacts", "commentary", {
      type: DataTypes.STRING, // Consider TEXT if comments can be long
      allowNull: true,
      defaultValue: null
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the added columns
    await queryInterface.removeColumn("Contacts", "commentary");
    await queryInterface.removeColumn("Contacts", "deadline");
  }
};

export = migration;
