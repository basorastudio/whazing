import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'oldStepAutoReplyId' a la tabla 'Tickets'
    return Promise.all([
      queryInterface.addColumn('Tickets', 'oldStepAutoReplyId', {
        type: DataTypes.INTEGER,
        references: {
          model: 'StepsReply', // Referencia a la tabla StepsReply
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL', // Si se elimina el StepsReply, establece el valor a NULL
        allowNull: true,
        defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'oldStepAutoReplyId' de la tabla 'Tickets'
    return queryInterface.removeColumn('Tickets', 'oldStepAutoReplyId');
  }
};