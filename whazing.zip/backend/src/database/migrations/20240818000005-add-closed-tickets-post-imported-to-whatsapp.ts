import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'closedTicketsPostImported' column to the 'Whatsapps' table
    // Likely a flag related to handling tickets closed after import.
    await queryInterface.addColumn(
      'Whatsapps',                   // Table name
      'closedTicketsPostImported',   // New column name
      {
        type: DataTypes.BOOLEAN,
        allowNull: true, // Allow null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'closedTicketsPostImported' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps',                   // Table name
      'closedTicketsPostImported'    // Column name to remove
    );
  }
};

export = migration;