<template>
  <q-page padding>
    <div class="row q-col-gutter-md">
      <div class="col-12">
        <q-card>
          <q-card-section>
            <div class="text-h6">Gestión de Tokens de Administrador</div>
          </q-card-section>

          <q-card-section>
            <div class="row q-col-gutter-md">
              <div class="col-12">
                <q-btn
                  color="primary"
                  label="Generar Nuevo Token"
                  @click="generarNuevoToken"
                  :loading="generandoToken"
                />
              </div>

              <div class="col-12" v-if="tokenActual">
                <q-card flat bordered>
                  <q-card-section>
                    <div class="text-subtitle2">Token Actual</div>
                    <q-input
                      v-model="tokenActual"
                      type="textarea"
                      readonly
                      filled
                      autogrow
                    />
                    <div class="row q-gutter-sm q-mt-sm">
                      <q-btn
                        flat
                        color="primary"
                        icon="content_copy"
                        label="Copiar"
                        @click="copiarToken"
                      />
                      <q-btn
                        flat
                        color="primary"
                        icon="refresh"
                        label="Renovar"
                        @click="renovarToken"
                        :loading="renovandoToken"
                      />
                    </div>
                  </q-card-section>
                </q-card>
              </div>
            </div>
          </q-card-section>
        </q-card>
      </div>
    </div>

    <q-dialog v-model="confirmDialog">
      <q-card>
        <q-card-section>
          <div class="text-h6">Confirmar Acción</div>
        </q-card-section>

        <q-card-section>
          {{ confirmMessage }}
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="Cancelar" color="primary" v-close-popup />
          <q-btn
            flat
            label="Confirmar"
            color="primary"
            @click="confirmarAccion"
            v-close-popup
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script>
import { generarTokenAdmin, renovarTokenAdmin } from 'src/service/adminApi'
import { Notify } from 'quasar'

export default {
  name: 'TokenAdmin',

  data () {
    return {
      tokenActual: null,
      generandoToken: false,
      renovandoToken: false,
      confirmDialog: false,
      confirmMessage: '',
      accionPendiente: null
    }
  },

  methods: {
    async generarNuevoToken () {
      this.confirmMessage = '¿Está seguro que desea generar un nuevo token? El token anterior dejará de funcionar.'
      this.accionPendiente = 'generar'
      this.confirmDialog = true
    },

    async renovarToken () {
      this.confirmMessage = '¿Está seguro que desea renovar el token actual?'
      this.accionPendiente = 'renovar'
      this.confirmDialog = true
    },

    async confirmarAccion () {
      if (this.accionPendiente === 'generar') {
        await this.ejecutarGenerarToken()
      } else if (this.accionPendiente === 'renovar') {
        await this.ejecutarRenovarToken()
      }
      this.accionPendiente = null
    },

    async ejecutarGenerarToken () {
      try {
        this.generandoToken = true
        const response = await generarTokenAdmin()
        this.tokenActual = response.data.token
        Notify.create({
          type: 'positive',
          message: 'Token generado exitosamente'
        })
      } catch (error) {
        console.error('Error al generar token:', error)
        Notify.create({
          type: 'negative',
          message: 'Error al generar el token'
        })
      } finally {
        this.generandoToken = false
      }
    },

    async ejecutarRenovarToken () {
      if (!this.tokenActual) {
        Notify.create({
          type: 'warning',
          message: 'No hay token para renovar'
        })
        return
      }

      try {
        this.renovandoToken = true
        const response = await renovarTokenAdmin({ token: this.tokenActual })
        this.tokenActual = response.data.token
        Notify.create({
          type: 'positive',
          message: 'Token renovado exitosamente'
        })
      } catch (error) {
        console.error('Error al renovar token:', error)
        Notify.create({
          type: 'negative',
          message: 'Error al renovar el token'
        })
      } finally {
        this.renovandoToken = false
      }
    },

    copiarToken () {
      if (this.tokenActual) {
        navigator.clipboard.writeText(this.tokenActual)
        Notify.create({
          type: 'positive',
          message: 'Token copiado al portapapeles'
        })
      }
    }
  }
}
</script>