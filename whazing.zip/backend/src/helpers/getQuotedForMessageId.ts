// Original: getQuotedForMessageId.js
// Deobfuscated, converted to TS, and translated

"use strict";

import Message from "../models/Message"; // Asumiendo exportación predeterminada

// Tipos inferidos
interface MessageInstance {
  // Define las propiedades esperadas del modelo Message
  id: number | string;
  messageId?: string | null;
  ticketId: number;
  // ... otras propiedades
}

const getQuotedForMessageId = async (
  messageId: string,
  tenantId: number | string
): Promise<MessageInstance | null> => {
  const quotedMessage = (await Message.findOne({
    where: {
      messageId: String(messageId), // Asegurar que sea string
      tenantId: +tenantId // Asegurar que sea number
    }
  })) as MessageInstance | null; // Castear tipo

  return quotedMessage;
};

export default getQuotedForMessageId;
