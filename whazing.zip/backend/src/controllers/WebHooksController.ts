import { Request, Response } from "express";
import AppError from "../errors/AppError";
// Assuming 'rabbit' is correctly configured and exported from app
// If it's a global or part of req.app, adjust accordingly.
// import { rabbitMQInstance } from '../libs/rabbit'; // Example if it's a separate module

interface WebhookRequest extends Request {
  app?: {
    // Assuming rabbit is accessed via req.app
    rabbit?: {
      publishInQueue: (queueName: string, data: string) => Promise<void>;
    };
  };
  // Define specific types for body/params/query if known
  body?: any;
  params?: any;
  query?: {
    "hub.challenge"?: string;
    // other query params
  };
}

// Handler for 360 Dialog Webhook
export const ReceivedRequest360 = async (
  req: WebhookRequest,
  res: Response
): Promise<Response> => {
  const queueName = "waba360"; // Nombre de la cola
  const logMessage = "Message adicionado queue"; // "Mensaje añadido a la cola"

  try {
    // Extrae datos relevantes (ejemplo, ajusta según la estructura real)
    const payloadToQueue = {
      token: req.params.token, // Asumiendo que el token viene de los parámetros
      requestData: req.body
    };

    if (!req.app?.rabbit) {
      throw new AppError("RabbitMQ instance not found on app.", 500); // "Instancia de RabbitMQ no encontrada en la app."
    }

    // Publica en la cola RabbitMQ
    await req.app.rabbit.publishInQueue(
      queueName,
      JSON.stringify(payloadToQueue)
    );
  } catch (err: any) {
    // Lanza un error de aplicación si falla la publicación
    throw new AppError(err.message, 500);
  }

  // Responde con éxito
  return res.status(200).json({ message: logMessage });
};

// Handler para verificación de webhook de Messenger (Facebook)
export const CheckServiceMessenger = async (
  req: WebhookRequest,
  res: Response
): Promise<Response> => {
  const challenge = req.query?.["hub.challenge"];
  const verificationMessage = "WEBHOOK_VERIFIED"; // Mensaje de verificación
  const logInfo = "Verificando webhook messenger"; // "Verificando webhook messenger"

  console.log(logInfo); // Log informativo

  // Responde con el challenge si existe (verificación de Facebook)
  if (challenge) {
    return res.status(200).send(challenge);
  } else {
    // Si no hay challenge, podría ser un error o un tipo diferente de solicitud
    return res.status(400).send("No challenge token found"); // "No se encontró token de challenge"
  }
};

// Handler para recepción de mensajes de Messenger
export const ReceivedRequestMessenger = async (
  req: WebhookRequest,
  res: Response
): Promise<Response> => {
  const queueName = "messenger"; // Nombre de la cola específica para Messenger
  const successMessage = "Message adicionado queue"; // "Mensaje añadido a la cola"

  try {
    // Extrae datos relevantes (ejemplo, ajusta según estructura real)
    const payloadToQueue = {
      token: req.params.token, // Asumiendo token en params
      requestData: req.body
    };

    if (!req.app?.rabbit) {
      throw new AppError("RabbitMQ instance not found on app.", 500); // "Instancia de RabbitMQ no encontrada en la app."
    }

    // Publica en la cola RabbitMQ
    await req.app.rabbit.publishInQueue(
      queueName,
      JSON.stringify(payloadToQueue)
    );
  } catch (err: any) {
    // Lanza un error de aplicación si falla la publicación
    throw new AppError(err.message, 500);
  }

  // Responde con éxito
  return res.status(200).json({ message: successMessage });
};
