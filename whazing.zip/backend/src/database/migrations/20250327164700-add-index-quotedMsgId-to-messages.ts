import { QueryInterface } from "sequelize";
import { Migration } from "sequelize";

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Messages";
    // Add index on [ticketId, quotedMsgId]
    await queryInterface.addIndex(tableName, ["ticketId", "quotedMsgId"], {
      name: "idx_messages_ticketid_quotedmsgid" // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = "Messages";
    // Remove the index
    await queryInterface.removeIndex(
      tableName,
      "idx_messages_ticketid_quotedmsgid"
    );
  }
};

export = migration;
