import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Check if the 'transcription' column already exists before adding
    const tableInfo = await queryInterface.describeTable('Whatsapps');
    if (!tableInfo || !tableInfo['transcription']) {
      // Add the 'transcription' column to the 'Whatsapps' table
      // Flag to enable/disable audio message transcription.
      await queryInterface.addColumn(
        'Whatsapps',     // Table name
        'transcription', // New column name
        {
          type: DataTypes.BOOLEAN,
          defaultValue: false, // Default to false
          allowNull: true,     // Allow null
        }
      );
    }
    // If the column exists, do nothing (idempotency)
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'transcription' column from the 'Whatsapps' table
    await queryInterface.removeColumn(
      'Whatsapps',     // Table name
      'transcription'  // Column name to remove
    );
  }
};

export = migration;