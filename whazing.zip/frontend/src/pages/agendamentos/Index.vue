<template>
  <div>
    <q-table
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      title="Agendamentos"
      :data="agendamentos"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="eva-clock-outline q-pr-sm"/>
            {{ $t('schedules.title') }}
          </h2>
          <div class="contact-header full-width">
            <div class="col-xs-6 col-md-3">
            <q-btn
              class="generate-button btn-rounded-50"
              :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="eva-plus-outline"
              :label="$t('schedules.schedule_message')"
              @click="modalAgendamento = true"
            />
            </div>
            <div class="col-xs-6 col-md-3">
              <q-select
                v-model="params.status"
                :options="statusOptions"
                :label="$t('schedules.filter_status')"
                @input="filtrarAgendamentos"
                class="contact-search"
                style="width: 300px"
                filled
                debounce="500"
              />
              <q-select
                v-if="userProfile === 'admin'"
                v-model="params.selectedUser"
                :options="usuarios"
                option-value="id"
                option-label="name"
                :label="$t('schedules.filter_user')"
                @input="filtrarAgendamentos"
                class="contact-search"
                style="width: 300px"
                filled
                debounce="500"
                clearable
              >
              </q-select>
            </div>
            <div class="d-flex justify-content-between">
              {{ $t('schedules.sending_date') }}
            <DatePick dense rounded outlined
                      class="row col"
                      v-model="params.startDate"
                      @input="onDateChange"
            />
            <DatePick dense rounded outlined
                      class="row col"
                      v-model="params.endDate"
                      @input="onDateChange"
            />
            </div>
            <div class="d-flex justify-content-between">
              {{ $t('schedules.scheduled_date') }}
            <DatePick dense rounded outlined
                      class="row col"
                      v-model="params.startDateCreatedAt"
                      @input="onDateChange"
            />
            <DatePick dense rounded outlined
                      class="row col"
                      v-model="params.endDateCreatedAt"
                      @input="onDateChange"
            />
            </div>
          </div>
        </div>
      </template>
      <template v-slot:body-cell-body="props">
        <q-td :props="props" style="white-space: pre-wrap; word-wrap: break-word;">
          {{ props.row.body.length > 100 ? props.row.body.slice(0, 100) + '...' : props.row.body }}
          <q-btn
            v-if="props.row.body.length > 100"
            flat
            dense
            :label="$t('general.see_more')"
            class="text-primary q-ml-sm"
            @click="abrirModalTextoCompleto(props.row.body)"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-status="props">
        <q-td :props="props">
          <div class="status-indicator">
            <q-icon
              v-if="props.row.status === 'PENDENTE'"
              name="hourglass_top"
              class="status-icon yellow"
            />
            <q-icon
              v-else-if="props.row.status === 'ENVIADA'"
              name="check_circle"
              class="status-icon green"
            />
            <q-icon
              v-else-if="props.row.status === 'ERRO'"
              name="error"
              class="status-icon red"
            />
            <span>{{ props.row.status }}</span>
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-mediaUrl="props">
        <q-td :props="props">
          <span v-if="props.row.mediaUrl">
            <a :href="props.row.mediaUrl" target="_blank" style="text-decoration: underline; cursor: pointer;">
              {{ $t('general.open_file') }}
            </a>
          </span>
          <span v-else>
            {{ $t('general.no_file') }}
          </span>
        </q-td>
      </template>

      <template v-slot:body-cell-createdAt="props">
        <q-td :props="props">
          {{ formatDate(props.row.createdAt) }}
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            v-if="props.row.status !== 'ENVIADA'"
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? 'color-dark1' : ''"
            icon="eva-trash-outline"
            @click="deletarMensagem(props.row)"
          />
        </q-td>
      </template>
      <template v-slot:pagination="{ pagination }">
        {{ agendamentos.length }}/{{ pagination.rowsNumber }}
      </template>
    </q-table>

    <q-dialog v-model="modalTextoCompleto">
      <q-card>
        <q-card-section>
          <div class="text-h6">{{ $t('schedules.full_text') }}</div>
        </q-card-section>
        <q-card-section style="white-space: pre-wrap; word-wrap: break-word;">
          <p>{{ textoCompleto }}</p>
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat :label="$t('general.close')" color="primary" @click="modalTextoCompleto = false" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <ModalAgendamento
      :modalAgendamento.sync="modalAgendamento"
    @agendamento:criado="agendamentoCriado"
    />

  </div>
</template>

<script>
import { ListarAgendamentoNovo, DeletarAgendamento } from 'src/service/agendamentos'
import { ListarUsuarios } from 'src/service/user'
import { ListarCores } from 'src/service/configuracoesgeneral'
import ModalAgendamento from './ModalAgendamento'

export default {
  name: 'Agendamentos',
  components: { ModalAgendamento },
  data() {
    return {
      userProfile: 'user',
      contatosCache: {},
      usuarios: [],
      agendamentos: [],
      modalAgendamento: false,
      modalTextoCompleto: false,
      textoCompleto: '',
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        startDate: null,
        endDate: null,
        startDateCreatedAt: null,
        endDateCreatedAt: null,
        status: 'PENDENTE',
        hasMore: true,
        selectedUser: null
      },
      statusOptions: [
        { label: this.$t('schedules.status.pending'), value: 'PENDENTE' },
        { label: this.$t('schedules.status.sent'), value: 'ENVIADA' },
        { label: this.$t('schedules.status.error'), value: 'ERRO' }
      ],
      loading: false,
      columns: [
        { name: 'contactName', label: this.$t('general.contact'), field: 'contactName', align: 'center' },
        { name: 'body', label: this.$t('general.message'), field: 'body', align: 'center' },
        { name: 'status', label: this.$t('general.status'), field: 'status', align: 'center' },
        { name: 'mediaUrl', label: this.$t('general.file'), field: 'mediaUrl', align: 'left' },
        { name: 'scheduleDate', label: this.$t('schedules.columns.sending_date'), field: 'scheduleDate', align: 'left', format: (val) => this.formatDate(val) },
        { name: 'userName', label: this.$t('schedules.columns.user'), field: 'userName', align: 'center' },
        { name: 'createdAt', label: this.$t('schedules.columns.scheduled_date'), field: 'createdAt', align: 'center', format: (val) => this.formatDate(val) },
        { name: 'acoes', label: this.$t('general.actions'), field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const cachedColors = localStorage.getItem('appColors')
      if (cachedColors) {
        try {
          const colors = JSON.parse(cachedColors)
          this.applyColors(colors)
        } catch (error) {
          console.error('Erro ao carregar cores do cache:', error)
        }
      }

      try {
        const response = await ListarCores()
        const colors = response.data

        localStorage.setItem('appColors', JSON.stringify(colors))

        this.applyColors(colors)
      } catch (error) {
        console.error('Erro ao carregar as cores do backend:', error)
        if (!cachedColors) {
          const defaultColors = {
            cor1: '#5690F0',
            cor2: '#5E56F6',
            textcor1: '#ffffff',
            cor1dark: '#5690F0',
            cor2dark: '#5E56F6',
            textcor1dark: '#ffffff'
          }
          this.applyColors(defaultColors)
        }
      }
    },
    applyColors(colors) {
      const root = document.documentElement
      const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = colors

      root.style.setProperty('--q-cor1', cor1)
      root.style.setProperty('--q-cor2', cor2)
      root.style.setProperty('--q-textcor1', textcor1)
      root.style.setProperty('--q-cor1dark', cor1dark)
      root.style.setProperty('--q-cor2dark', cor2dark)
      root.style.setProperty('--q-textcor1dark', textcor1dark)
    },
    deletarMensagem(mensagem) {
      this.$q
        .dialog({
          title: this.$t('schedules.delete_confirm'),
          message: this.$t('schedules.delete_warning'),
          cancel: {
            label: this.$t('general.no'),
            color: 'primary',
            push: true
          },
          ok: {
            label: this.$t('general.yes'),
            color: 'negative',
            push: true
          },
          persistent: true
        })
        .onOk(() => {
          this.loading = true
          DeletarAgendamento(mensagem)
            .then((res) => {
              this.loading = false
              // Remove o agendamento deletado do array agendamentos
              const index = this.agendamentos.findIndex(agendamento => agendamento.id === mensagem.id)
              if (index !== -1) {
                this.agendamentos.splice(index, 1)
              }
              this.pagination.rowsNumber -= 1
              this.$q.notify({
                type: 'positive',
                message: this.$t('schedules.success_delete')
              })
            })
            .catch((error) => {
              this.loading = false
              console.error(error)
              this.$q.notify({
                type: 'negative',
                message: this.$t('schedules.error_delete'),
                detail: error.message
              })
            })
        })
        .onCancel(() => {
        })
    },
    async listarUsuarios() {
      const data = await ListarUsuarios()
      this.usuarios = data.data.users
    },
    async listarAgendamentos() {
      this.loading = true
      try {
        const startDate = this.params.startDate
          ? new Date(this.params.startDate).toISOString()
          : null

        const endDate = this.params.endDate
          ? (() => {
            const date = new Date(this.params.endDate)
            date.setDate(date.getDate() + 1)
            return date.toISOString()
          })()
          : null

        const startDateCreatedAt = this.params.startDateCreatedAt
          ? new Date(this.params.startDateCreatedAt).toISOString()
          : null

        const endDateCreatedAt = this.params.endDateCreatedAt
          ? (() => {
            const date = new Date(this.params.endDateCreatedAt)
            date.setDate(date.getDate() + 1)
            return date.toISOString()
          })()
          : null

        const response = await ListarAgendamentoNovo({
          startDate,
          endDate,
          startDateCreatedAt,
          endDateCreatedAt,
          status: this.params.status,
          selectedUser: this.params.selectedUser,
          pageNumber: this.params.pageNumber
        })

        if (response.data && Array.isArray(response.data.schedules)) {
          this.agendamentos = [
            ...this.agendamentos,
            ...response.data.schedules.map((schedule) => ({
              id: schedule.id,
              body: schedule.body,
              status: schedule.status,
              mediaUrl: schedule.mediaPath ? `${process.env.URL_API}/public/${schedule.mediaPath}/${schedule.mediaName}` : null,
              ticketId: schedule.ticketId,
              scheduleDate: schedule.sendAt,
              userName: schedule.user ? schedule.user.name : this.$t('schedules.unknown_user'),
              contactName: schedule.contact ? schedule.contact.name : this.$t('schedules.unknown_contact'),
              createdAt: schedule.createdAt
            }))
          ]
          this.pagination.rowsNumber = response.data.count || 0
          this.pagination.hasMore = response.data.hasMore
        } else {
          console.error('Resposta da API não está no formato esperado:', response.data)
        }
      } catch (error) {
        console.error('Erro ao listar agendamentos:', error)
      } finally {
        this.loading = false
      }
    },
    abrirModalTextoCompleto(note) {
      this.textoCompleto = note
      this.modalTextoCompleto = true
    },
    formatDate(dateString) {
      const date = new Date(dateString)

      // Configura o formatador de data para o fuso horário desejado (exemplo: 'America/Sao_Paulo')
      const options = {
        timeZone: 'America/Sao_Paulo', // Ajuste para o fuso horário desejado
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false // Usa o formato de 24 horas
      }

      const formatter = new Intl.DateTimeFormat('pt-BR', options)
      return formatter.format(date).replace(',', '')
    },
    async filtrarAgendamentos() {
      this.params.pageNumber = 1
      this.params.hasMore = true
      this.agendamentos = []

      this.params.status = this.params.status && this.params.status.value ? this.params.status.value : null

      await this.listarAgendamentos()
    },
    onDateChange() {
      if (this.params.startDate && this.params.endDate) {
        this.filtrarAgendamentos()
      }
      if (this.params.startDateCreatedAt && this.params.endDateCreatedAt) {
        this.filtrarAgendamentos()
      }
    },
    onScroll({ to, ref, ...all }) {
      if (!this.loading && this.params.hasMore && to >= (this.agendamentos.length - 10)) {
        this.loading = true
        this.params.pageNumber++
        this.listarAgendamentos()
      }
    }
  },
  async mounted() {
    this.loadColors()
    await this.listarAgendamentos()
    await this.listarUsuarios()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.my-sticky-dynamic
  /* height or max-height is important */
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th /* bg color is important for th; just specify one */
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1
  /* this will be the loading indicator */
  thead tr:last-child th
    /* height of all previous header rows */
    top: 63px
  thead tr:first-child th
    top: 0

.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

#tabela-contatos-atendimento
  thead
    th
      height: 55px

.blur-effect
  filter: blur(0px)

.status-indicator
  display: flex
  align-items: center
  gap: 8px

.status-icon
  border-radius: 50%
  padding: 4px
  color: white

.status-icon.yellow
  background-color: #fbc02d

.status-icon.green
  background-color: #4caf50

.status-icon.red
  background-color: #f44336
</style>
