import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'dueDate' column to the 'Tenants' table
    await queryInterface.addColumn(
      'Tenants', // Table name
      'dueDate', // New column name
      {
        type: DataTypes.DATE, // Data type is DATE (stores date and time)
        allowNull: true,     // Allow null values
        // No default value specified in original code
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'dueDate' column from the 'Tenants' table
    await queryInterface.removeColumn(
      'Tenants', // Table name
      'dueDate'  // Column name to remove
    );
  }
};

export = migration;