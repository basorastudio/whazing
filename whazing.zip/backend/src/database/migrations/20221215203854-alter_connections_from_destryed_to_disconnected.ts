// --- START OF FILE 20221215203854-alter_connections_from_destryed_to_disconnected.ts ---

'use strict';
import { QueryInterface, Sequelize, QueryTypes } from 'sequelize'; // Added QueryTypes

interface Migration {
  up: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
  down: (queryInterface: QueryInterface, sequelize: typeof Sequelize) => Promise<void>;
}

const migration: Migration = {
    up: async (queryInterface: QueryInterface): Promise<void> => {
        // Original Query: update "Whatsapps" SET status = 'DISCONNECTED' WHERE status = 'DESTROYED';
        const updateQuery = `UPDATE "Whatsapps" SET status = 'DISCONNECTED' WHERE status = 'DESTROYED'`;
        // Removed 'select gen_random_uuid()' which seemed out of place for an update operation.
        await Promise.all([
             queryInterface.sequelize.query(updateQuery, { type: QueryTypes.UPDATE })
        ]);
    },

    down: async (queryInterface: QueryInterface): Promise<void> => {
        // Original Query: SELECT gen_random_uuid() FROM "Whatsapps" WHERE status = 'DESTROYED'; (This seems incorrect for a down migration)
        // Assuming the goal is to revert the status change:
        const revertQuery = `UPDATE "Whatsapps" SET status = 'DESTROYED' WHERE status = 'DISCONNECTED'`;
        await Promise.all([
            queryInterface.sequelize.query(revertQuery, { type: QueryTypes.UPDATE })
        ]);
        // Note: The original 'down' query `select gen_random_uuid()` made no sense for reverting.
        // The corrected query above attempts to revert the status change made in 'up'.
        // Be cautious with this rollback, as it assumes all 'DISCONNECTED' statuses were previously 'DESTROYED'.
    }
};

export default migration;
// --- END OF FILE 20221215203854-alter_connections_from_destryed_to_disconnected.ts ---