<template>
  <div class="heightChat" v-if="userProfile === 'admin' || userProfile === 'supervisor'" :class="{'fullscreen-mode': isFullScreen}">
    <!-- Header section -->
    <div class="header-section" :class="{ 'hide-header': isFullScreen }">
      <div class="row items-center justify-between q-px-md">
        <!-- Conteúdo que será ocultado em fullscreen -->
        <div class="row items-center fullscreen-hide">
          <h2 :class="{ 'color-dark3': $q.dark.isActive }">
            <q-icon name="mdi-view-dashboard-variant" />
            Panel de Atenciones
          </h2>
        </div>
        <div class="row items-center q-gutter-x-md">
          <!-- Botão de filtros que será ocultado em fullscreen -->
          <q-btn
            icon="mdi-view-module"
            label="Tipo de visualización"
            class="generate-button btn-rounded-50 fullscreen-hide"
            :class="{'generate-button-dark': $q.dark.isActive}"
            @click="visualizarFiltros = true"
          />
          <!-- Botão de fullscreen sempre visível -->
          <q-btn
            flat
            round
            :icon="isFullScreen ? 'mdi-fullscreen-exit' : 'mdi-fullscreen'"
            @click="toggleFullScreen"
            class="fullscreen-button color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
          >
            <q-tooltip>{{ isFullScreen ? 'Salir de pantalla completa' : 'Pantalla completa' }}</q-tooltip>
          </q-btn>
        </div>
      </div>
    </div>

    <q-dialog
      position="left"
      v-model="visualizarFiltros">
      <q-card style="width: 300px">
        <q-card-section>
          <q-separator />
          <div class="text-h6 q-mt-md">Tipo de visualización</div>
          <q-option-group :options="optionsVisao"
            label="Visión"
            type="radio"
            v-model="visao" />
        </q-card-section>
        <q-separator />
        <q-card-actions align="center">
          <q-btn outline
            label="Cerrar"
                 class="full-width color-light1"
                 :class="{'full-width color-dark1' : $q.dark.isActive}"
            v-close-popup
            @click="consultarTickets" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <div
      class="scroll">
      <template v-for="(items, key) in sets">
        <div
          :key="key"
          class="row q-px-md q-pb-md q-pt-xs q-col-gutter-md q-mb-sm">
          <div :class="contentClass"
            v-for="(item, index) in items"
            :key="index">
            <q-card class="container-border container-rounded-50"
              flat>
              <q-item v-if="visao === 'U' || visao === 'US'"
                class="font-family-main text-bold"
                :class="{
                  'bg-negative text-white': definirNomeUsuario(item[0]) === 'Pendiente'
                }">
                <!-- <q-item-section avatar>
                  <q-avatar>
                    <img src="https://cdn.quasar.dev/img/boy-avatar.png">
                  </q-avatar>
                </q-item-section> -->
                <q-item-section>
                  <q-item-label class="font-family-main text-bold text-h6">{{ definirNomeUsuario(item[0]) }}</q-item-label>
                  <q-item-label caption class="font-family-main"
                    :class="{
                      'text-white': definirNomeUsuario(item[0]) === 'Pendiente'
                    }">
                    Atenciones: {{ item.length }}
                  </q-item-label>
                </q-item-section>
              </q-item>

              <q-item v-if="visao === 'F' || visao === 'FS'"
                class="font-family-main text-bold"
                :class="{
                  'bg-negative text-white': definirNomeFila(item[0]) === 'Sin Cola'
                }">
                <q-item-section avatar>
                  <q-avatar>
                    <img src="https://cdn.quasar.dev/img/boy-avatar.png">
                  </q-avatar>
                </q-item-section>
                <q-item-section>
                  <q-item-label>{{ definirNomeFila(item[0]) }}</q-item-label>
                  <q-item-label caption
                    :class="{
                      'text-white': definirNomeFila(item[0]) === 'Sin Cola'
                    }">
                    Abiertos: {{ counterStatus(item).open }} | Pendientes: {{ counterStatus(item).pending }} | Total: {{
                        item.length
                    }}
                  </q-item-label>
                </q-item-section>
                <q-btn @click="listarFilas"
                  v-if="definirNomeFila(item[0]).toLowerCase() === 'sem fila'"
                  flat
                  color="primary"
                  class="bg-padrao btn-rounded">
                  <q-icon name="mdi-transfer" />
                  <q-tooltip content-class="bg-primary text-bold">
                    Transferir Atenciones Sin Cola
                  </q-tooltip>
                </q-btn>
              </q-item>
              <q-separator />
              <q-card-section :style="{ height: '320px' }"
                class="bg-grey-3 scroll"

                v-if="visao === 'U' || visao === 'F'">
                <ItemTicket v-for="(ticket, i) in item"
                  :key="i"
                  :ticket="ticket"
                  :filas="filas" />
              </q-card-section>
            </q-card>
          </div>
          <q-resize-observer @resize="onResize"></q-resize-observer>
        </div>
      </template>
    </div>

    <q-dialog v-model="modalTransferirTicket"
              @hide="modalTransferirTicket = false"
              persistent>
      <q-card class="q-pa-md"
              style="width: 500px">
        <q-card-section>
          <div class="text-h6">Transferir todas las atenciones sin cola</div>
          <div class="text-h8">Seleccione el destino (atenciones sin cola):</div>
        </q-card-section>
        <q-card-section>
          <q-select square
                    outlined
                    v-model="filaSelecionada"
                    :options="filas"
                    emit-value
                    map-options
                    option-value="id"
                    option-label="queue"
                    label="Cola de destino" />
        </q-card-section>
        <q-card-section>
          <q-select square
                    outlined
                    v-model="usuarioSelecionado"
                    :options="usuarios.filter(filterUsers)"
                    emit-value
                    map-options
                    option-value="id"
                    option-label="name"
                    label="Usuario destino" />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn
            label="Salir"
            color="negative"
            v-close-popup
            class="q-mr-lg" />
          <q-btn
            label="Guardar"
            color="primary"
            @click="confirmarTransferenciaTicket" />
        </q-card-actions>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
const usuario = JSON.parse(localStorage.getItem('usuario'))
import { socketIO } from 'src/utils/socket'
const socket = socketIO()

import ItemTicket from './ItemTicket'
import { ConsultarTicketsQueuesService } from 'src/service/estatisticas.js'
import { ListarFilas } from 'src/service/filas'
import { ListarUsuarios } from 'src/service/user'
import { AtualizarTicket } from 'src/service/tickets'
import { ListarWhatsapps } from 'src/service/sessoesWhatsapp'
import { ListarCores } from 'src/service/configuracoesgeneral'
const UserQueues = localStorage.getItem('queues')
import { groupBy } from 'lodash'
const profile = localStorage.getItem('profile')
export default {
  name: 'painel-de-controle',
  components: { ItemTicket },
  data () {
    return {
      userProfile: 'admin',
      profile,
      visualizarFiltros: false,
      slide: 0,
      height: 400,
      optionsVisao: [
        { label: 'Por Usuario', value: 'U' },
        { label: 'Por Usuario (Sintético)', value: 'US' },
        { label: 'Por Colas', value: 'F' },
        { label: 'Por Colas (Sintético)', value: 'FS' }
      ],
      visao: 'U',
      pesquisaTickets: {
        queuesIds: []
      },
      tickets: [],
      listaWhats: [],
      filas: [],
      usuarios: [],
      modalTransferirTicket: false,
      usuarioSelecionado: null,
      filaSelecionada: null,
      usuarios2: [],
      usuarios3: [],
      modalTransferirTicket2: false,
      usuarioSelecionado2: null,
      usuarioSelecionado3: null,
      sizes: { lg: 3, md: 3, sm: 2, xs: 1 },
      isFullScreen: false,
      refreshInterval: null
    }
  },
  computed: {
    contentClass () {
      let contentClass = 'col'
      const keysLenSize = Object.keys(this.cTicketsUser[0]).length
      for (const size of ['xl', 'lg', 'md', 'sm', 'xs']) {
        if (this.sizes[size]) {
          const sizeExpect = this.sizes[size] > keysLenSize ? keysLenSize : this.sizes[size]
          contentClass += ' col-' + size + '-' + (12 / sizeExpect)
        }
      }
      return contentClass
    },
    sets () {
      const sets = []
      // const items = this.itemsPerSet
      const limit = Math.ceil(this.cTicketsUser.length / this.itemsPerSet)
      for (let index = 0; index < limit; index++) {
        const start = index * this.itemsPerSet
        const end = start + this.itemsPerSet
        sets.push(this.cTicketsUser.slice(start, end))
      }
      return sets[0]
    },
    itemsPerSet () {
      let cond = false
      for (const size of ['xl', 'lg', 'md', 'sm', 'xs']) {
        cond = cond || this.$q.screen[size]
        if (cond && this.sizes[size]) {
          return this.sizes[size]
        }
      }
      return 1
    },
    cUserQueues () {
      try {
        const filasUsuario = JSON.parse(UserQueues).map(q => {
          if (q.isActive) {
            return q.id
          }
        })
        return this.filas.filter(f => filasUsuario.includes(f.id)) || []
      } catch (error) {
        return []
      }
    },
    cTicketsUser () {
      const field = this.visao === 'U' || this.visao === 'US' ? 'userId' : 'queueId'
      return [groupBy(this.tickets, field)]
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        const response = await ListarCores()

        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Error al cargar los colores:', error)
      }
    },
    toggleFullScreen () {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen()
        this.isFullScreen = true
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen()
          this.isFullScreen = false
        }
      }
    },
    async listaWhatsapp() {
      const { data } = await ListarWhatsapps()
      this.listaWhats = data.filter(f => f.isActive)
    },
    async listarFilas () {
      try {
        const { data } = await ListarFilas()
        this.filas = data
        this.modalTransferirTicket = true
        this.listarUsuarios()
      } catch (error) {
        console.error(error)
        this.$notificarErro('Problema al cargar colas', error)
      }
    },
    filterUsers (element, index, array) {
      const fila = this.filaSelecionada
      if (fila == null) return true
      const queues_valid = element.queues.filter(function (element, index, array) {
        return (element.id == fila)
      })
      return (queues_valid.length > 0)
    },
    async confirmarTransferenciaTicket() {
      if (!this.filaSelecionada) {
        this.$notificarErro('Seleccione la cola destino para las atenciones pendientes!')
        return
      }

      try {
        const ticketsWithoutQueue = this.tickets.filter(ticket => ticket.queueId === null)

        if (ticketsWithoutQueue.length === 0) {
          this.$notificarErro('No hay atenciones pendientes para transferir!')
          return
        }

        await Promise.all(
          ticketsWithoutQueue.map(ticket =>
            this.atualizarTicketPorFila(
              ticket.id,
              this.usuarioSelecionado,
              this.filaSelecionada,
              ticket.status
            )
          )
        )

        this.$q.notify({
          type: 'positive',
          message: '¡Atenciones transferidas con éxito!'
        })

        this.modalTransferirTicket = false
        await this.consultarTickets()
      } catch (error) {
        console.error(error)
        this.$notificarErro('Problema al realizar transferencia', error)
      }
    },
    async listarUsuarios () {
      try {
        const { data } = await ListarUsuarios()
        this.usuarios = data.users
        this.modalTransferirTicket = true
      } catch (error) {
        console.error(error)
        this.$notificarErro('Problema al cargar usuarios', error)
      }
    },
    async atualizarTicketPorFila (id, user, fila, status) {
      await AtualizarTicket(id, {
        userId: user,
        queueId: fila,
        status: status,
        isTransference: 1
      })
    },
    deleteTicket (ticketId) {
      const newTickets = [...this.tickets]
      const ticketsFilter = newTickets.filter(t => t.id !== ticketId)
      this.tickets = [...ticketsFilter]
    },
    updateTicket (ticket) {
      const newTickets = [...this.tickets]
      const idx = newTickets.findIndex(t => ticket.id)
      if (idx) {
        newTickets[idx] = ticket
        this.tickets = [...newTickets]
      }
    },
    createTicket (ticket) {
      const newTickets = [...this.tickets]
      newTickets.unshift(ticket)
      this.tickets = [...newTickets]
    },
    verifyIsActionSocket(data) {
      if (!data.id) return false

      // mostrar todos
      if (this.pesquisaTickets.showAll) return true

      // não existir filas cadastradas
      if (!this.filas.length) return true

      // Allow tickets without queue
      if (!data.queueId) return true

      // verificar se a fila do ticket está filtrada
      const isQueue = this.pesquisaTickets.queuesIds.indexOf(q => data.queueId === q)

      let isValid = false
      if (isQueue !== -1) {
        isValid = true
      }
      return isValid
    },
    conectSocketQueues (tenantId, queueId) {
      // socket.on(`${tenantId}:${queueId}:ticket:queue`, data => {
      //   if (!this.verifyIsActionSocket(data.ticket)) return

      //   if (data.action === 'update') {
      //     this.updateTicket(data.ticket)
      //   }
      //   if (data.action === 'create') {
      //     this.createTicket(data.ticket)
      //   }
      //   if (data.action === 'delete') {
      //     this.deleteTicket(data.ticketId)
      //   }
      // })
    },
    socketTickets() {
      socket.on(`${usuario.tenantId}:ticketList`, async (data) => {
        if (data.type === 'ticket:update') {
          // Handle closed tickets
          if (data.payload.status === 'closed') {
            this.tickets = this.tickets.filter(t => t.id !== data.payload.id)
            return
          }

          // Update existing ticket or add new one
          const ticketIndex = this.tickets.findIndex(t => t.id === data.payload.id)
          if (ticketIndex !== -1) {
            // Update existing ticket
            this.tickets.splice(ticketIndex, 1, data.payload)
          } else {
            // Add new ticket
            this.tickets.unshift(data.payload)
          }

          // Sort tickets to maintain consistent order
          this.sortTickets()
        }
      })
    },
    connectSocket () {
      this.socketTickets()
      this.cUserQueues.forEach(el => {
        this.conectSocketQueues(usuario.tenantId, el.id)
      })
    },
    definirNomeUsuario (item) {
      this.verifyIsActionSocket(item)
      return item?.user?.name || 'Pendiente'
    },
    definirNomeFila (f) {
      const fila = this.filas.find(fila => fila.id === f.queueId)
      return fila?.queue || 'Sin Cola'
    },
    updateCounters() {
      // Update total counts
      const totalTickets = this.tickets.length
      const pendingTickets = this.tickets.filter(t => !t.userId).length
      const queueCounts = {}

      // Count by queue
      this.tickets.forEach(ticket => {
        const queueId = ticket.queueId || 'pending'
        queueCounts[queueId] = (queueCounts[queueId] || 0) + 1
      })

      // Update the data properties
      this.$set(this, 'ticketCounts', {
        total: totalTickets,
        pending: pendingTickets,
        byQueue: queueCounts
      })
    },
    getTicketPosition(ticket) {
      if (!ticket.queueId) {
        return this.tickets
          .filter(t => !t.queueId)
          .findIndex(t => t.id === ticket.id) + 1
      }

      return this.tickets
        .filter(t => t.queueId === ticket.queueId)
        .findIndex(t => t.id === ticket.id) + 1
    },
    sortTickets() {
      this.tickets.sort((a, b) => {
        // First by queue
        const queueIdA = a.queueId || ''
        const queueIdB = b.queueId || ''

        if (queueIdA !== queueIdB) {
          return queueIdA.localeCompare(queueIdB)
        }

        // Then by status
        if (a.status !== b.status) {
          return a.status.localeCompare(b.status)
        }

        // Finally by creation date
        return new Date(b.createdAt) - new Date(a.createdAt)
      })
    },
    counterStatus (tickets) {
      const status = {
        open: 0,
        pending: 0,
        closed: 0
      }
      const group = groupBy(tickets, 'status')
      status.open = group.open?.length || 0
      status.pending = group.pending?.length || 0
      status.closed = group.closed?.length || 0
      return status
    },
    async consultarTickets() {
      try {
        const { data } = await ConsultarTicketsQueuesService(this.pesquisaTickets)
        this.tickets = data
        this.sortTickets()
        this.updateCounters()
        this.connectSocket()
      } catch (error) {
        console.error(error)
        this.$notificarErro('Error al consultar atenciones', error)
      }
    },
    onResize ({ height }) {
      this.height = height
    },
    setupAutoRefresh() {
      if (this.refreshInterval) {
        clearInterval(this.refreshInterval)
      }
      this.refreshInterval = setInterval(() => {
        this.consultarTickets()
      }, 180000) // 180000ms = 180s
    }
  },

  async mounted () {
    this.loadColors()
    await ListarFilas().then(res => {
      this.filas = res.data
    })
    await this.consultarTickets()
    this.listaWhatsapp()
    this.userProfile = localStorage.getItem('profile')
    this.setupAutoRefresh()
  },
  destroyed () {
    socket.disconnect()
  },
  beforeDestroy() {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval)
    }
    socket.disconnect()
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

  // Estilos para modo fullscreen
  &.fullscreen-mode
    .header-section
      padding: 8px
      position: fixed
      right: 0
      top: 0
      z-index: 2000
      background: transparent

    .fullscreen-hide
      display: none
</style>
