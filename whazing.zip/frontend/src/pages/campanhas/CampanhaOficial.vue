<template>
  <div v-if="!canAccessPage">
    <q-banner dense inline-actions class="bg-red text-white">
      <template v-slot:avatar>
        <q-icon name="warning" />
      </template>
      {{ $t('campanhas.acessoNegado') }}
      <template v-slot:action>
        <q-btn flat
               class="generate-button btn-rounded-50"
               :class="{'generate-button-dark' : $q.dark.isActive}"
               v-if="whatsappNumber"
               icon="mdi-whatsapp"
               :label="$t('campanhas.chamarSuporte')"
               @click="abrirWhatsApp"
        />
      </template>
    </q-banner>
  </div>
  <div v-else-if="userProfile === 'admin' || userProfile === 'supervisor'">
    <q-table
      flat
      bordered
      square
      hide-bottom
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      :data="campanhasComCalculos"
      :columns="columns"
      :loading="loading"
      row-key="id"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
    >
      <template v-slot:top-left>
        <div>
          <h2  :class="$q.dark.isActive ? ('color-dark3') : ''">
            {{ $t('campanhas.titulo') }}
          </h2>
          <div>
            <q-btn
              class="color-light1"
              :class="$q.dark.isActive ? ('color-dark1') : ''"
              icon="refresh"
              outline
              @click="listarCampanhas"
            >
              <q-tooltip>
                {{ $t('campanhas.atualizarListagem') }}
              </q-tooltip>
            </q-btn>
            <!-- Add this button next to your existing "Adicionar" button -->
            <q-btn
              class="generate-button btn-rounded-50 q-ml-md"
              :class="{'generate-button-dark' : $q.dark.isActive}"
              icon="mdi-message-text-outline"
              :label="$t('campanhasoficial.campanhaPorTemplate')"
              @click="openTemplateCampaignModal"
            />
          </div>
        </div>

      </template>
      <template v-slot:body-cell-color="props">
        <q-td class="text-center">
          <div
            class="q-pa-sm rounded-borders"
            :style="`background: ${props.row.color}`"
          >
            {{ props.row.color }}
          </div>
        </q-td>
      </template>
      <template v-slot:body-cell-isActive="props">
        <q-td class="text-center">
          <q-icon
            size="24px"
            :name="props.value ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'"
            :color="props.value ? 'positive' : 'negative'"
          />
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            flat
            round
            icon="mdi-account-details-outline"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="contatosCampanha(props.row)"
          >
            <q-tooltip>
              {{ $t('campanhas.listacontatos') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            v-if="['pending', 'canceled'].includes(props.row.status)"
            icon="mdi-calendar-clock"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="iniciarCampanha(props.row)"
          >
            <q-tooltip>
              {{ $t('campanhas.programarenvio') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            v-if="['scheduled', 'processing'].includes(props.row.status)"
            icon="mdi-close-box-multiple"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="cancelarCampanha(props.row)"
          >
            <q-tooltip>
              {{ $t('campanhas.cancelarcampanha') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            icon="eva-edit-outline"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="editarCampanha(props.row)"
          >
            <q-tooltip>
              {{ $t('campanhas.editarCampanha') }}
            </q-tooltip>
          </q-btn>
          <q-btn
            flat
            round
            icon="eva-trash-outline"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            @click="deletarCampanha(props.row)"
          >
            <q-tooltip>
              {{ $t('campanhas.excluirCampanha') }}
            </q-tooltip>
          </q-btn>
        </q-td>
      </template>
    </q-table>

    <!-- Modal campanha de template -->
    <q-dialog v-model="templateCampaignModal" persistent>
      <q-card style="width: 700px; max-width: 90vw;">
        <q-card-section>
          <div class="text-h6">{{ $t('campanhasoficial.criarCampanhaTemplate') }}</div>
        </q-card-section>

        <q-stepper
          v-model="templateCampaignStep"
          vertical
          color="primary"
          animated
        >
          <!-- Step 1: Selecionar WhatsApp -->
          <q-step
            :name="1"
            :title="$t('campanhas.enviarPor')"
            icon="mdi-whatsapp"
            :done="templateCampaignStep > 1"
          >
            <div class="q-pa-md">
              <div v-if="cSessions.length > 0" class="q-mt-md">
                <q-radio
                  v-for="session in cSessions"
                  :key="session.id"
                  v-model="selectedWhatsApp"
                  :val="session.id"
                  :label="session.name"
                />
              </div>
            </div>

            <q-stepper-navigation>
              <q-btn
                :label="$t('general.proximo')"
                color="primary"
                :disable="!selectedWhatsApp"
                @click="templateCampaignStep = 2; loadTemplateCategories()"
                class="btn-rounded-50"
              />
              <q-btn
                flat
                :label="$t('general.cancelar')"
                color="negative"
                v-close-popup
                class="q-ml-sm btn-rounded-50"
              />
            </q-stepper-navigation>
          </q-step>

          <!-- Step 2: Selecionar categoria de template -->
          <q-step
            :name="2"
            :title="$t('campanhasoficial.selecionarCategoriaTemplate')"
            icon="mdi-tag-outline"
            :done="templateCampaignStep > 2"
          >
            <div class="q-pa-md">
              <div v-if="loadingTemplateCategories" class="text-center">
                <q-spinner color="primary" size="2em" />
                <div class="q-mt-sm">{{ $t('inputtemplate.carregandocategorias') }}</div>
              </div>
              <div v-else-if="templateCategories.length === 0" class="text-center">
                <q-icon name="mdi-alert-circle-outline" color="warning" size="2em" />
                <div class="q-mt-sm">{{ $t('inputtemplate.nenhumtemplatedisponivel') }}</div>
              </div>
              <div v-else>
                <q-list separator>
                  <q-item
                    v-for="category in templateCategories"
                    :key="category"
                    clickable
                    v-ripple
                    @click="selectTemplateCategory(category)"
                  >
                    <q-item-section avatar>
                      <q-icon name="mdi-tag" color="primary" />
                    </q-item-section>
                    <q-item-section>
                      <q-item-label>{{ category }}</q-item-label>
                    </q-item-section>
                    <q-item-section side>
                      <q-icon name="chevron_right" color="grey" />
                    </q-item-section>
                  </q-item>
                </q-list>
              </div>
            </div>

            <q-stepper-navigation>
              <q-btn
                :label="$t('general.proximo')"
                color="primary"
                :disable="!selectedCategory"
                @click="templateCampaignStep = 3; loadTemplates()"
                class="btn-rounded-50"
              />
              <q-btn flat :label="$t('general.voltar')" color="primary" @click="templateCampaignStep = 1" class="q-ml-sm btn-rounded-50" />
              <q-btn flat :label="$t('general.cancelar')" color="negative" v-close-popup class="q-ml-sm btn-rounded-50" />
            </q-stepper-navigation>
          </q-step>

          <!-- Step 3: Selecionar template -->
          <q-step
            :name="3"
            :title="$t('campanhasoficial.selecionarTemplate')"
            icon="mdi-text-box-outline"
            :done="templateCampaignStep > 3"
          >
            <div class="q-pa-md">
              <div v-if="loadingTemplates" class="text-center">
                <q-spinner color="primary" size="2em" />
                <div class="q-mt-sm">{{ $t('inputtemplate.carregandotemplates') }}</div>
              </div>
              <div v-else-if="templateList.length === 0" class="text-center">
                <q-icon name="mdi-alert-circle-outline" color="warning" size="2em" />
                <div class="q-mt-sm">{{ $t('campanhas.nenhumTemplateNaCategoria') }}</div>
              </div>
              <div v-else>
                <q-input
                  outlined
                  v-model="templateSearch"
                  :label="$t('inputtemplate.buscartemplate')"
                  dense
                  class="q-mb-md"
                >
                  <template v-slot:append>
                    <q-icon name="search" />
                  </template>
                </q-input>

                <q-list separator>
                  <q-item
                    v-for="template in filteredTemplates"
                    :key="template.id"
                    clickable
                    v-ripple
                    @click="selectTemplate(template)"
                  >
                    <q-item-section>
                      <q-item-label class="text-weight-bold">{{ template.name }}</q-item-label>
                      <q-item-label caption>{{ getTemplatePreview(template) }}</q-item-label>
                    </q-item-section>
                    <q-item-section side>
                      <q-icon name="chevron_right" color="grey" />
                    </q-item-section>
                  </q-item>
                </q-list>
              </div>
            </div>

            <q-stepper-navigation>
              <q-btn
                :label="$t('general.proximo')"
                color="primary"
                :disable="!selectedTemplate"
                @click="templateCampaignStep = 4; extractTemplateParameters()"
                class="btn-rounded-50"
              />
              <q-btn flat :label="$t('general.voltar')" color="primary" @click="templateCampaignStep = 2" class="q-ml-sm btn-rounded-50" />
              <q-btn flat :label="$t('general.cancelar')" color="negative" v-close-popup class="q-ml-sm btn-rounded-50" />
            </q-stepper-navigation>
          </q-step>

          <!-- Step 4: Configurar template -->
          <q-step
            :name="4"
            :title="$t('campanhasoficial.configurarTemplate')"
            icon="mdi-format-list-bulleted"
            :done="templateCampaignStep > 4"
          >
            <div class="q-pa-md">
              <div class="text-subtitle1 q-mb-md">{{ selectedTemplate?.name }}</div>
              <div class="text-body1 q-mb-md">{{ getTemplatePreview(selectedTemplate) }}</div>

              <div v-if="templateParameters.length > 0">
                <div v-for="(param, index) in templateParameters" :key="index" class="q-mb-md">
                  <div class="text-body2 q-my-md">
                    {{ $t('campanhasoficial.variaveis') }}
                  </div>
                  <q-input
                    outlined
                    v-model="templateParamValues[index]"
                    :label="`${$t('inputtemplate.parametro')} ${index + 1}`"
                    :hint="getParameterHint(param, index)"
                  />
                </div>
              </div>

              <div v-else class="text-body2 q-my-md">
                {{ $t('inputtemplate.templatenaopossuiparametros') }}
              </div>

              <div v-if="selectedTemplate?.components?.find(c => c.type === 'HEADER' && c.format === 'IMAGE')" class="q-mt-lg">
                <q-file
                  v-model="templateHeaderImage"
                  :label="$t('inputtemplate.imagemcabecalho')"
                  outlined
                  accept=".jpg, .jpeg, .png"
                >
                  <template v-slot:prepend>
                    <q-icon name="image" />
                  </template>
                </q-file>
              </div>
            </div>

            <q-stepper-navigation>
              <q-btn
                :label="$t('general.proximo')"
                color="primary"
                @click="templateCampaignStep = 5"
                class="btn-rounded-50"
              />
              <q-btn flat :label="$t('general.voltar')" color="primary" @click="templateCampaignStep = 3" class="q-ml-sm btn-rounded-50" />
              <q-btn flat :label="$t('general.cancelar')" color="negative" v-close-popup class="q-ml-sm btn-rounded-50" />
            </q-stepper-navigation>
          </q-step>

          <!-- Step 5: Programar envio -->
          <q-step
            :name="5"
            :title="$t('campanhasoficial.programarEnvio')"
            icon="mdi-calendar-clock"
          >
            <div class="q-pa-md">
              <div class="row q-col-gutter-md">
                <div class="col-12">
                  <!-- Adicionando campo nome da campanha -->
                  <q-input
                    class="required q-mb-md"
                    outlined
                    dense
                    rounded
                    v-model="campanha.name"
                    :label="$t('campanhas.nomeCampanha')"
                    :error-message="$t('campanhas.erroobrigatorio')"
                  />

                  <!-- Componente para data e hora -->
                  <q-datetime-picker
                    rounded
                    dense
                    hide-bottom-space
                    outlined
                    stack-label
                    bottom-slots
                    :label="$t('campanhas.dataHoraInicio')"
                    mode="datetime"
                    color="primary"
                    format24h
                    v-model="scheduledDateTime"
                    :error-message="$t('campanhas.errordataHoraInicio')"
                  />

                  <q-input
                    v-model.number="messageDelay"
                    type="number"
                    :label="$t('campanhas.delay')"
                    :suffix="$t('campanhas.segundos')"
                    outlined
                    dense
                    rounded
                    min="1"
                  />
                </div>

                <div class="col-12 q-mt-md">
                  <q-card flat bordered class="bg-grey-2 q-pa-md">
                    <div class="text-subtitle1 q-mb-sm">{{ $t('campanhasoficial.resumoCampanha') }}</div>
                    <div class="q-ml-md">
                      <div><strong>{{ $t('campanhas.nomeCampanha') }}:</strong> {{ campanha.name }}</div>
                      <div><strong>{{ $t('campanhas.enviarPor') }}:</strong> {{ getWhatsAppName() }}</div>
                      <div><strong>{{ $t('campanhas.template') }}:</strong> {{ selectedTemplate?.name }}</div>
                      <div><strong>{{ $t('campanhas.dataHoraInicio') }}:</strong> {{ scheduledDateTime }} </div>
                      <div><strong>{{ $t('campanhas.delay') }}:</strong> {{ messageDelay }} {{ $t('campanhas.segundos') }}</div>
                    </div>
                  </q-card>
                </div>
              </div>
            </div>

            <q-stepper-navigation>
              <q-btn
                :label="$t('campanhas.criarCampanha')"
                color="primary"
                @click="createTemplateCampaign"
                :loading="creatingCampaign"
                :disable="!isFormValid"
                class="btn-rounded-50"
              />
              <q-btn flat :label="$t('general.voltar')" color="primary" @click="templateCampaignStep = 4" class="q-ml-sm btn-rounded-50" />
              <q-btn flat :label="$t('general.cancelar')" color="negative" v-close-popup class="q-ml-sm btn-rounded-50" />
            </q-stepper-navigation>
          </q-step>

        </q-stepper>
      </q-card>
    </q-dialog>

    <q-dialog v-model="editCampaignModal" persistent>
      <q-card style="width: 500px; max-width: 90vw;">
        <q-card-section>
          <div class="text-h6">{{ $t('campanhas.editarCampanha') }}</div>
        </q-card-section>

        <q-banner class="bg-amber-8 text-white q-mt-sm" dense rounded>
          <q-icon name="warning" size="md" class="q-mr-sm" />
          <div class="text-subtitle1 text-bold">{{ $t('campanhasoficial.avisoImportante') }}</div>
          <div class="text-body2">
            {{ $t('campanhasoficial.apenasDataEditavel') }}
          </div>
        </q-banner>

        <q-card-section v-if="campaignToEdit">
          <q-form @submit="saveCampaignEdit">

            <q-datetime-picker
              rounded
              dense
              hide-bottom-space
              outlined
              stack-label
              bottom-slots
              :label="$t('campanhas.dataHoraInicio')"
              mode="datetime"
              color="primary"
              format24h
              v-model="campaignToEdit.start"
              :error-message="$t('campanhas.errordataHoraInicio')"
            />
          </q-form>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat :label="$t('general.cancelar')" color="negative" v-close-popup />
          <q-btn
            flat
            :label="$t('general.salvar')"
            color="positive"
            @click="saveCampaignEdit"
            :loading="savingEdit"
            :disable="!campaignToEdit || !campaignToEdit.start"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>

</div>
</template>

<script>
import {
  AlterarCampanhaOficial,
  CancelarCampanha,
  CriarCampanhaOficial,
  DeletarCampanha,
  IniciarCampanha,
  ListarCampanhas
} from 'src/service/campanhas'
import { MostrarPlano } from 'src/service/empresas'
import { format, parseISO, startOfDay } from 'date-fns'
import { ListarConfiguracaoPublica } from 'src/service/configuracoesgeneral'
import { mapGetters } from 'vuex'

import { ListarCategoriasTemplates, ListarTemplates } from 'src/service/hub'

export default {
  name: 'CampanhasOficial',
  data () {
    return {
      userProfile: 'user',
      canAccessPage: false,
      campanhaEdicao: {},
      whatsappNumber: null,
      campanhas: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      loading: false,
      columns: [
        { name: 'id', label: '#', field: 'id', align: 'left' },
        { name: 'name', label: this.$t('campanhas.campanha'), field: 'name', align: 'left' },
        { name: 'start', label: this.$t('campanhas.inicio'), field: 'start', align: 'center', format: (v) => format(parseISO(v), 'dd/MM/yyyy HH:mm') },
        {
          name: 'status',
          label: this.$t('general.status'),
          field: 'status',
          align: 'center',
          format: (v) => v ? this.status[v] : ''
        },
        { name: 'contactsCount', label: this.$t('campanhas.qtdcontatos'), field: 'contactsCount', align: 'center' },
        { name: 'pendentesEnvio', label: this.$t('campanhas.aenviar'), field: 'pendentesEnvio', align: 'center' },
        { name: 'pendentesEntrega', label: this.$t('campanhas.aentregar'), field: 'pendentesEntrega', align: 'center' },
        { name: 'recebidas', label: this.$t('campanhas.recebidas'), field: 'recebidas', align: 'center' },
        { name: 'lidas', label: this.$t('campanhas.lidas'), field: 'lidas', align: 'center' },
        { name: 'acoes', label: this.$t('general.actions'), field: 'acoes', align: 'center' }
      ],
      status: {
        pending: this.$t('campanhas.statusPendente'),
        scheduled: this.$t('campanhas.statusProgramada'),
        processing: this.$t('campanhas.statusProcessando'),
        canceled: this.$t('campanhas.statusCancelada'),
        finished: this.$t('campanhas.statusFinalizada')
      },
      campanha: {
        name: null,
        start: null
      },
      templateCampaignModal: false,
      templateCampaignStep: 1,
      selectedWhatsApp: null,
      selectedCategory: null,
      selectedTemplate: null,
      templateCategories: [],
      templateList: [],
      loadingTemplateCategories: false,
      loadingTemplates: false,
      templateSearch: '',
      templateParameters: [],
      templateParamValues: [],
      templateHeaderImage: null,
      messageDelay: 120,
      scheduledDateTime: null,
      creatingCampaign: false,
      editCampaignModal: false,
      campaignToEdit: null,
      savingEdit: false
    }
  },
  computed: {
    ...mapGetters(['whatsapps']),
    cSessions() {
      return this.whatsapps.filter(w => w.type === 'hub_whatsapp')
    },
    campanhasComCalculos() {
      return this.campanhas.map(campanha => ({
        ...campanha,
        pendentesEnvio: Math.max(
          0,
          campanha.contactsCount -
          (campanha.pendentesEntrega || 0) -
          (campanha.recebidas || 0) -
          (campanha.lidas || 0)
        )
      }))
    },
    filteredTemplates() {
      if (!this.templateSearch || !this.templateList) return this.templateList || []

      const search = this.templateSearch.toLowerCase()
      return this.templateList.filter(template =>
        template.name.toLowerCase().includes(search) ||
        this.getTemplatePreview(template).toLowerCase().includes(search)
      )
    },
    isFormValid() {
      if (!this.selectedWhatsApp || !this.selectedTemplate) {
        return false
      }

      if (!this.scheduledDateTime) {
        return false
      }

      if (!this.messageDelay || this.messageDelay < 20) {
        return false
      }

      if (!this.campanha.name) {
        return false
      }

      return true
    },
    dateOptions() {
      const today = new Date()
      return date => date >= today
    }
  },
  methods: {
    async fetchConfigurations() {
      try {
        const response = await ListarConfiguracaoPublica()
        const configurations = response.data
        this.whatsappNumber = configurations.whatsappnumber || null
      } catch (error) {
        console.error('Erro ao buscar configurações:', error)
      }
    },
    abrirWhatsApp() {
      if (this.whatsappNumber) {
        const message = encodeURIComponent(this.$t('campanhas.whatsapp'))
        const url = `https://wa.me/${this.whatsappNumber}?text=${message}`
        window.open(url, '_blank')
      }
    },
    async listarPlano() {
      try {
        const { data } = await MostrarPlano()
        this.canAccessPage = data.campaign !== false
      } catch (error) {
        console.error('Erro ao carregar o plano:', error)
      }
    },
    async listarCampanhas () {
      const { data } = await ListarCampanhas(true)
      this.campanhas = data
    },
    isValidDate (v) {
      return startOfDay(new Date(parseISO(v))).getTime() >= startOfDay(new Date()).getTime()
    },
    deletarCampanha (campanha) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('campanhas.confirmarDelecaoCampanha', { name: campanha.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarCampanha(campanha)
          .then(res => {
            let newCampanhas = [...this.campanhas]
            newCampanhas = newCampanhas.filter(f => f.id !== campanha.id)
            this.campanhas = [...newCampanhas]
            this.$notificarSucesso(this.$t('campanhas.campanhaExcluida', { name: campanha.name }))
          })
        this.loading = false
      })
    },
    contatosCampanha (campanha) {
      this.$router.push({
        name: 'contatos-campanha',
        params: {
          campanhaId: campanha.id,
          campanha
        }
      })
    },
    cancelarCampanha (campanha) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('campanhas.confirmarCancelamentoCampanha', { name: campanha.name }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        CancelarCampanha(campanha.id)
          .then(res => {
            this.$notificarSucesso(this.$t('campanhas.campanhaCancelada'))
            this.listarCampanhas()
          }).catch(err => {
            this.$notificarErro(this.$t('campanhas.erroCancelarCampanha'), err)
          })
      })
    },
    iniciarCampanha (campanha) {
      if (!this.isValidDate(campanha.start)) {
        this.$notificarErro(this.$t('campanhas.erroDataInvalida'))
      }

      if (campanha.contactsCount == 0) {
        this.$notificarErro(this.$t('campanhas.erroSemContatos'))
      }

      if (campanha.status !== 'pending' && campanha.status !== 'canceled') {
        this.$notificarErro(this.$t('general.erroStatusProgramacao'))
      }

      IniciarCampanha(campanha.id).then(res => {
        this.$notificarSucesso(this.$t('campanhas.campanhainiciada'))
        this.listarCampanhas()
      }).catch(err => {
        this.$notificarErro(this.$t('campanhas.campanhanaoiniciada'), err)
      })
    },
    openTemplateCampaignModal() {
      this.resetTemplateCampaignForm()
      this.templateCampaignModal = true
    },

    // Reset form data
    resetTemplateCampaignForm() {
      this.templateCampaignStep = 1
      this.selectedWhatsApp = null
      this.selectedCategory = null
      this.selectedTemplate = null
      this.templateCategories = []
      this.templateList = []
      this.templateSearch = ''
      this.templateParameters = []
      this.templateParamValues = []
      this.templateHeaderImage = null
      this.messageDelay = 120
      this.campanha.name = ''

      // Set default date and time (now + 1 hour)
      const now = new Date()
      now.setHours(now.getHours() + 1)
      this.scheduledDateTime = null
    },

    // Load template categories from API
    async loadTemplateCategories() {
      if (!this.selectedWhatsApp) return

      this.loadingTemplateCategories = true
      this.templateCategories = []

      try {
        const response = await ListarCategoriasTemplates(this.selectedWhatsApp)
        if (response.data && response.data.categories) {
          this.templateCategories = response.data.categories
        } else {
          this.$q.notify({
            message: this.$t('inputtemplate.naofoipossivelcarregartemplates'),
            type: 'warning'
          })
        }
      } catch (error) {
        console.error('Erro ao carregar categorias:', error)
        this.$q.notify({
          message: this.$t('inputtemplate.errocarregarcategorias'),
          type: 'negative'
        })
      } finally {
        this.loadingTemplateCategories = false
      }
    },
    selectTemplate(template) {
      this.selectedTemplate = template
      this.templateListModal = false
      this.templateEditModal = true

      // Extrair os parâmetros
      this.extractTemplateParameters()
    },
    // Select a template category
    selectTemplateCategory(category) {
      this.selectedCategory = category
    },
    extractTemplateParameters() {
      this.templateParameters = []
      this.templateParamValues = []

      if (!this.selectedTemplate || !this.selectedTemplate.components) return

      const components = Array.isArray(this.selectedTemplate.components)
        ? this.selectedTemplate.components
        : JSON.parse(this.selectedTemplate.components)

      // Se o formato for posicional ({{1}}, {{2}}, etc.)
      if (this.selectedTemplate.parameter_format === 'POSITIONAL') {
        // Encontrar todos os parâmetros do tipo {{N}}
        const bodyComponent = components.find(c => c.type === 'BODY')
        if (!bodyComponent || !bodyComponent.text) return

        const paramMatches = bodyComponent.text.match(/{{(\d+)}}/g) || []
        const params = paramMatches.map(match => {
          // Extrair o número do parâmetro
          const paramNumber = match.replace('{{', '').replace('}}', '')
          return {
            type: 'text',
            position: parseInt(paramNumber),
            example: this.getParameterExample(bodyComponent, paramNumber)
          }
        })

        // Ordenar parâmetros por posição e remover duplicados
        const uniqueParams = [...new Map(params.map(p => [p.position, p])).values()]
        uniqueParams.sort((a, b) => a.position - b.position)

        this.templateParameters = uniqueParams
        this.templateParamValues = new Array(uniqueParams.length).fill('')
      } else {
        // Procurar parâmetros em todos os componentes
        components.forEach(component => {
          if (component.parameters) {
            component.parameters.forEach(param => {
              this.templateParameters.push(param)
              this.templateParamValues.push('')
            })
          }
        })
      }
    },
    async loadTemplates() {
      if (!this.selectedWhatsApp || !this.selectedCategory) return

      this.loadingTemplates = true
      this.templateList = []
      this.templateSearch = ''

      try {
        const response = await ListarTemplates(this.selectedWhatsApp, this.selectedCategory)
        if (response.data && response.data.templates) {
          this.templateList = response.data.templates
        } else {
          this.$q.notify({
            message: this.$t('inputtemplate.errocarregartemplates'),
            type: 'warning'
          })
        }
      } catch (error) {
        console.error('Erro ao carregar templates:', error)
        this.$q.notify({
          message: this.$t('inputtemplate.errocarregartemplates'),
          type: 'negative'
        })
      } finally {
        this.loadingTemplates = false
      }
    },
    getTemplatePreview(template) {
      if (!template || !template.components) return ''

      const bodyComponent = Array.isArray(template.components)
        ? template.components.find(c => c.type === 'BODY')
        : null

      if (!bodyComponent) return ''

      return bodyComponent.text || ''
    },
    getWhatsAppName() {
      if (!this.selectedWhatsApp) return ''
      const whatsapp = this.cSessions.find(w => w.id === this.selectedWhatsApp)
      return whatsapp ? whatsapp.name : ''
    },
    getParameterHint(param, index) {
      if (param.example) {
        return `${this.$t('inputtemplate.exemplo')}: ${param.example}`
      }

      return `${this.$t('inputtemplate.parametro')} ${index + 1}`
    },
    getParameterExample(component, paramPosition) {
      if (!component || !component.example || !component.example.body_text) {
        return ''
      }

      try {
        // Tenta acessar o exemplo para esse parâmetro
        const examples = component.example.body_text
        if (examples && examples.length > 0 && examples[0].length >= paramPosition) {
          return examples[0][paramPosition - 1]
        }
      } catch (error) {
        console.error('Erro ao obter exemplo de parâmetro:', error)
      }

      return ''
    },
    getFormattedTemplateBody() {
      if (!this.selectedTemplate || !this.selectedTemplate.components) return ''

      const components = Array.isArray(this.selectedTemplate.components)
        ? this.selectedTemplate.components
        : JSON.parse(this.selectedTemplate.components)

      // Find the body component
      const bodyComponent = components.find(c => c.type === 'BODY')
      if (!bodyComponent || !bodyComponent.text) return ''

      let formattedText = bodyComponent.text

      // Replace parameters based on format type
      if (this.selectedTemplate.parameter_format === 'POSITIONAL') {
        // Replace {{1}}, {{2}}, etc. with the provided values
        this.templateParameters.forEach((param, index) => {
          const paramValue = this.templateParamValues[index] || ''
          const paramMarker = `{{${param.position}}}`
          formattedText = formattedText.replace(new RegExp(paramMarker, 'g'), paramValue)
        })
      } else {
        // For named parameters, replace {{parameter_name}} with values
        this.templateParameters.forEach((param, index) => {
          const paramValue = this.templateParamValues[index] || ''
          const paramMarker = `{{${param.parameter_name}}}`
          formattedText = formattedText.replace(new RegExp(paramMarker, 'g'), paramValue)
        })
      }

      return formattedText
    },
    async createTemplateCampaign() {
      if (!this.selectedTemplate) return

      this.sendingTemplate = true

      try {
        // Preparar os dados do template conforme formato necessário
        const templateData = {
          name: this.selectedTemplate.name,
          language: { code: this.selectedTemplate.language || 'pt_BR' },
          components: []
        }

        const components = Array.isArray(this.selectedTemplate.components)
          ? this.selectedTemplate.components
          : JSON.parse(this.selectedTemplate.components)

        // Processar componentes do template
        components.forEach(component => {
          const templateComponent = {
            type: component.type.toLowerCase(),
            parameters: []
          }

          // Para botões, adicionar sub_type e index se existirem
          if (component.type === 'BUTTONS' && component.buttons) {
            component.buttons.forEach((button, index) => {
              templateComponent.sub_type = button.type.toLowerCase()
              templateComponent.index = index.toString()
            })
          }

          // Adicionar parâmetros conforme formato
          if (this.selectedTemplate.parameter_format === 'POSITIONAL') {
            // Formato posicional (parâmetros são números)
            if (component.type === 'BODY') {
              this.templateParameters.forEach((param, index) => {
                if (this.templateParamValues[index]) {
                  templateComponent.parameters.push({
                    type: 'text',
                    text: this.templateParamValues[index]
                  })
                }
              })
            }
          } else {
            // Formato nomeado (parâmetros têm nomes)
            if (component.parameters) {
              component.parameters.forEach((param, index) => {
                if (this.templateParamValues[index]) {
                  templateComponent.parameters.push({
                    type: param.type,
                    parameter_name: param.parameter_name,
                    text: this.templateParamValues[index]
                  })
                }
              })
            }
          }

          // Se for cabeçalho com imagem, adicionar a imagem
          if (component.type === 'HEADER' && component.format === 'IMAGE' && this.templateHeaderImage) {
            templateComponent.parameters.push({
              type: 'image',
              image: {
                link: '' // Link will be set by the backend after upload
              }
            })
          }

          // Adicionar componente à lista se tiver parâmetros ou for um componente sem parâmetros (ex: texto simples)
          if (templateComponent.parameters.length > 0 || component.type === 'BODY') {
            templateData.components.push(templateComponent)
          }
        })

        const body = this.getFormattedTemplateBody()

        const formData = new FormData()

        formData.append('body', body)
        formData.append('dataJson', JSON.stringify(templateData))
        formData.append('campaignName', this.campanha.name)
        formData.append('delay', this.messageDelay)
        formData.append('whatsappId', this.selectedWhatsApp)
        formData.append('scheduledDateTime', this.scheduledDateTime)

        // Add file if exists
        if (this.templateHeaderImage) {
          formData.append('templateHeaderImage', this.templateHeaderImage)
        }

        await CriarCampanhaOficial(formData)

        // Fechar os modais e limpar os dados
        this.templateCampaignModal = false
        this.selectedTemplate = null
        this.templateParameters = []
        this.templateParamValues = []
        this.templateHeaderImage = null
        this.campanha.name = ''
        this.selectedWhatsApp = null
        this.scheduledDateTime = null

        this.$q.notify({
          type: 'positive',
          progress: true,
          position: 'top',
          message: this.$t('campanhas.campanhaCriada'),
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })
      } catch (error) {
        console.error(error)
        this.$notificarErro(this.$t('campanhas.erroCriarCampanha'), error)
      } finally {
        this.sendingTemplate = false
        this.listarCampanhas()
      }
    },
    editarCampanha(row) {
      // Initialize with default values to ensure nothing is null
      this.campaignToEdit = {
        id: row?.id || null,
        // Use a default date if start is not available
        start: null
      }

      // Only try to process the start date if it exists
      if (row && row.start) {
        try {
          // For datetime-local input, we need format YYYY-MM-DDThh:mm
          this.campaignToEdit.start = row.start.substring(0, 16)
        } catch (e) {
          console.error('Error formatting date:', e)
          this.campaignToEdit.start = new Date().toISOString().substring(0, 16)
        }
      } else {
        // Default to current date/time if no start date is provided
        this.campaignToEdit.start = new Date().toISOString().substring(0, 16)
      }

      // Open the modal after campaignToEdit is fully initialized
      this.$nextTick(() => {
        this.editCampaignModal = true
      })
    },
    async saveCampaignEdit() {
      if (!this.campaignToEdit || !this.campaignToEdit.start) {
        this.$q.notify({
          message: this.$t('general.preenchaCamposObrigatorios'),
          color: 'negative'
        })
        return
      }

      try {
        this.savingEdit = true
        const payload = {
          start: this.campaignToEdit.start
        }

        await AlterarCampanhaOficial(payload, this.campaignToEdit.id)

        this.$q.notify({
          type: 'info',
          progress: true,
          position: 'top',
          textColor: 'black',
          message: this.$t('campanhas.campanhaEditada'),
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })

        this.editCampaignModal = false
        this.listarCampanhas()
      } catch (error) {
        console.error(error)
        this.$notificarErro(this.$t('campanhas.erroCriarCampanha'), error)
      } finally {
        this.savingEdit = false
      }
    }
  },
  mounted () {
    this.fetchConfigurations()
    this.listarPlano()
    this.listarCampanhas()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px
</style>
