/**
 * Middleware para verificar si el usuario tiene perfil 'supervisor' o 'admin'.
 */
import { Response, NextFunction } from "express";
import AppError from "../errors/AppError";
import User from "../models/User";
import { AuthRequest } from "./interfaces/AuthRequest"; // Importa la interfaz

const isSupervisor = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  // Asume que req.user.id está disponible
  if (!req.user?.id) {
    throw new AppError("Autenticación requerida.", 401);
  }

  // Busca el usuario por su ID
  const user = await User.findByPk(req.user.id);

  if (!user) {
    throw new AppError("Usuario no encontrado.", 404);
  }

  const profile = user.profile; // Asume propiedad 'profile'

  // Verifica si el perfil NO es 'supervisor' Y TAMPOCO es 'admin'
  if (profile !== "supervisor" && profile !== "admin") {
    // Si no es ninguno de los dos, lanza error (Forbidden)
    throw new AppError("Acceso no permitido", 403); // 403 Forbidden
  }

  // Si es supervisor o admin, permite continuar
  return next();
};

export default isSupervisor; // Exportación default
