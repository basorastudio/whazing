<template>
  <div>
    <!-- Este componente no tiene interfaz visible, solo maneja las notificaciones -->
  </div>
</template>

<script>
import { ListarTarefasComRecordatorio, MarcarRecordatorioEnviado, EnviarNotificacionRecordatorio } from 'src/service/taskReminders'

export default {
  name: 'TaskReminderNotification',
  data () {
    return {
      checkInterval: null,
      intervalTime: 60000 // Verificar cada minuto
    }
  },
  methods: {
    async checkReminders () {
      try {
        // Obtener tareas con recordatorios pendientes
        const { data } = await ListarTarefasComRecordatorio()
        
        if (data && data.length > 0) {
          // Procesar cada tarea con recordatorio
          data.forEach(async task => {
            // Mostrar notificación al usuario
            this.showNotification(task)
            
            // Enviar notificación al backend (para posible envío por correo, etc.)
            await EnviarNotificacionRecordatorio({
              taskId: task.id,
              userId: task.userId,
              message: `Recordatorio: La tarea "${task.name}" tiene fecha límite próxima.`
            })
            
            // Marcar recordatorio como enviado
            await MarcarRecordatorioEnviado(task.id)
          })
        }
      } catch (error) {
        console.error('Error al verificar recordatorios:', error)
      }
    },
    
    showNotification (task) {
      // Mostrar notificación en la interfaz de usuario
      this.$q.notify({
        type: 'warning',
        message: `Recordatorio: La tarea "${task.name}" tiene fecha límite próxima.`,
        icon: 'alarm',
        position: 'top-right',
        timeout: 10000,
        actions: [
          { icon: 'visibility', color: 'white', handler: () => this.viewTask(task) },
          { icon: 'close', color: 'white' }
        ]
      })
    },
    
    viewTask (task) {
      // Aquí se podría implementar la navegación a la vista de detalles de la tarea
      // Por ejemplo: this.$router.push(`/tarefas/${task.id}`)
      // O emitir un evento para que otro componente maneje la visualización
      this.$root.$emit('view-task', task)
    },
    
    startCheckingReminders () {
      // Verificar inmediatamente al iniciar
      this.checkReminders()
      
      // Configurar verificación periódica
      this.checkInterval = setInterval(() => {
        this.checkReminders()
      }, this.intervalTime)
    },
    
    stopCheckingReminders () {
      if (this.checkInterval) {
        clearInterval(this.checkInterval)
        this.checkInterval = null
      }
    }
  },
  mounted () {
    // Iniciar verificación de recordatorios cuando el componente se monta
    this.startCheckingReminders()
  },
  beforeDestroy () {
    // Detener verificación cuando el componente se destruye
    this.stopCheckingReminders()
  }
}
</script>