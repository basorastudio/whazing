import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'typebotStatus' column to the 'Tickets' table
    await queryInterface.addColumn(
      'Tickets',         // Table name
      'typebotStatus',   // New column name
      {
        type: DataTypes.BOOLEAN,
        defaultValue: false, // Default value is false
        allowNull: false,   // Does not allow null
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'typebotStatus' column from the 'Tickets' table
    await queryInterface.removeColumn(
      'Tickets',         // Table name
      'typebotStatus'    // Column name to remove
    );
  }
};

export = migration;