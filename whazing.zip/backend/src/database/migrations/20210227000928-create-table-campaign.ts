import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Crea la tabla 'Campaigns'
    return Promise.all([
      // Usar Promise.all aunque solo sea una operación
      queryInterface.createTable("Campaigns", {
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true,
          allowNull: false
        },
        name: {
          // Nombre de la campaña
          type: DataTypes.STRING,
          allowNull: false
        },
        start: {
          // Fecha de inicio de la campaña
          type: DataTypes.DATE,
          allowNull: false
        },
        status: {
          // Estado de la campaña (ej: 'pending', 'running', 'finished')
          type: DataTypes.STRING,
          allowNull: false,
          defaultValue: "pending" // Valor predeterminado 'pending'
        },
        sessionId: {
          // ID de la sesión/conexión de WhatsApp usada
          type: DataTypes.INTEGER,
          references: { model: "Whatsapps", key: "id" },
          onUpdate: "CASCADE",
          onDelete: "SET NULL"
        },
        message1: {
          // Mensaje 1 de la campaña
          type: DataTypes.TEXT,
          allowNull: false
        },
        message2: {
          // Mensaje 2 de la campaña
          type: DataTypes.TEXT,
          allowNull: false
        },
        message3: {
          // Mensaje 3 de la campaña
          type: DataTypes.TEXT,
          allowNull: false
        },
        mediaUrl: {
          // URL de un medio adjunto (opcional)
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        mediaType: {
          // Tipo del medio adjunto (opcional)
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        userId: {
          type: DataTypes.INTEGER,
          references: { model: "Users", key: "id" },
          onUpdate: "CASCADE",
          onDelete: "SET NULL"
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: { model: "Tenants", key: "id" },
          onUpdate: "CASCADE",
          onDelete: "CASCADE",
          allowNull: false,
          defaultValue: 1
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        }
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la tabla 'Campaigns'
    return Promise.all([
      // Usar Promise.all aunque solo sea una operación
      queryInterface.dropTable("Campaigns")
    ]);
  }
};
