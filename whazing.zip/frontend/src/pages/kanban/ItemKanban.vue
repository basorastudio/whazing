<template>
  <div>
    <q-list
      separator
      class="q-mr-sm q-ml-none q-my-sm q-pa-xs"
      :class="$q.dark.isActive ? 'bg-grey-5' : 'bg-grey-6'"
      style="border-radius: 5px"
    >
      <!-- <wait-dialog :d-wait="dialogWait" /> -->
      <q-item
        id="item-ticket-houve"
        class="ticketBorder q-px-none"
        style="height: auto; max-width: 100%; cursor: move;"
        :style="`
    background: ${$q.dark.isActive ? '#000000' : '#ebebeb'};
    ${titleColor ? `border-left: 3px solid ${titleColor} !important;` : ''}
  `"
      >
        <q-item-section avatar class="q-px-xs">
          <q-avatar size="45px" class="relative-position">
            <img
              :src="Value(contato, 'profilePicUrl')"
              onerror="this.style.display='none'"
              v-show="!!Value(contato, 'profilePicUrl')"
            />
            <q-icon size="45px" name="mdi-account-circle" color="grey-8" />
          </q-avatar>
        </q-item-section>
        <q-item-section id="ListItemsTicket">
          <q-item-label class="text-bold h5" lines="1">
            <span :class="$q.dark.isActive ? 'text-white' : ''">{{
                contato.name
              }}</span>
          </q-item-label>
          <q-item-label class="text-bold h6" lines="1" v-if="contato.number && (userProfile === 'admin' || userProfile === 'supervisor' || !HideNumber)">
            <a :class="$q.dark.isActive ? ('text-white') : ''" :href="getPhoneNumberLink(contato.number)">
              {{ formatId(contato.number) }}
            </a>
          </q-item-label>
          <q-item-label v-if="contato.deadline">
            <div class="row text-caption q-pt-xs">
              <q-icon size="sm" color="red-5" class="q-mr-xs" name="timer" />
              <span>{{ formatarDataTZ(contato.deadline) }}</span>
            </div>
          </q-item-label>
          <q-item-label v-if="contato.commentary">
            <div class="row text-caption q-pt-xs q-pl-none">
              <div class="col-xs-1">
                <q-icon color="primary" size="sm" name="mdi-text" />
              </div>
              <div class="col-sm-9 q-ml-sm ellipsis">
                {{ contato.commentary }}
              </div>
            </div>
          </q-item-label>
        </q-item-section>
        <q-item-section side>
          <q-icon
            @click="openCard(contato)"
            name="edit"
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            style="cursor: pointer"
          >
            <q-tooltip>Editar</q-tooltip>
          </q-icon>
          <q-icon
            @click="handleSaveTicket(contato, 'whatsapp')"
            name="mdi-whatsapp"
            color="green-10"
            class="text-bold q-mt-sm"
            style="cursor: pointer"
            v-if="contato.number"
          >
            <q-tooltip>{{ $t('crm.Service') }}</q-tooltip>
          </q-icon>
          <q-icon
            @click="handleSaveTicket(contato, 'hub_facebook')"
            name="mdi-instagram"
            color="purple"
            class="text-bold q-mt-sm"
            style="cursor: pointer"
            v-if="contato.instagramPK"
          >
            <q-tooltip>{{ $t('crm.Service') }}</q-tooltip>
          </q-icon>
          <q-icon
            @click="handleSaveTicket(contato, 'hub_webchat')"
            name="mdi-web"
            color="cyan"
            class="text-bold q-mt-sm"
            style="cursor: pointer"
            v-if="contato.webchatId"
          >
            <q-tooltip>{{ $t('crm.Service') }}</q-tooltip>
          </q-icon>
          <q-icon
            @click="handleSaveTicket(contato, 'hub_facebook')"
            name="mdi-facebook-messenger"
            color="blue"
            class="text-bold q-mt-sm"
            style="cursor: pointer"
            v-if="contato.messengerId"
          >
            <q-tooltip>{{ $t('crm.Service') }}</q-tooltip>
          </q-icon>
          <q-badge color="cyan">{{`$ ${formatKanbanPrice(contato.kanbanPrice)}`}}</q-badge>
        </q-item-section>
      </q-item>
      <!-- <q-separator spaced color="grey-2" /> -->
      <!-- <q-separator /> -->
    </q-list>
    <q-dialog v-model="modelCard">
      <CardModal :data-card="openCardData" @hide="updateContato"></CardModal>
    </q-dialog>

    <q-dialog v-model="modalSelecionarCanal" persistent>
      <q-card class="q-pa-md" style="width: 500px">
        <q-card-section>
          <div class="text-h6">{{ $t('newticket.title') }}</div>
        </q-card-section>

        <q-card-section>
          <q-select
            square
            outlined
            v-model="canalSelecionado"
            :options="canaisUsuario"
            emit-value
            map-options
            option-value="id"
            option-label="name"
            :label="$t('newticket.canal')"
          />
        </q-card-section>

        <q-card-section>
          <q-select
            square
            outlined
            v-model="filaSelecionada"
            :options="cUserQueues"
            emit-value
            map-options
            option-value="id"
            option-label="queue"
            :label="$t('newticket.fila')"
          />
        </q-card-section>

        <q-card-section v-if="erro" class="text-negative text-caption q-mt-sm">
          {{ erro }}
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat
                 :label="$t('general.cancelar')"
                 color="negative"
                 v-close-popup
                 @click="fecharModalCanal" />
          <q-btn flat
                 :label="$t('general.salvar')"
                 color="primary"
                 @click="criarTicket" />
        </q-card-actions>
      </q-card>
    </q-dialog>

  </div>
</template>

<script>
const UserQueues = JSON.parse(localStorage.getItem('queues'))
import { format, parseISO, formatDistance, parseJSON } from 'date-fns'
import pt from 'date-fns/locale/pt-BR'
import { outlinedAccountCircle } from '@quasar/extras/material-icons-outlined'
import CardModal from './CardModal.vue'
import { CriarTicketNew } from 'src/service/tickets'
import { ListarCanalUsuario } from 'src/service/user'
import formatSerializedId from 'src/utils/phoneFormatter'

export default {
  name: 'ItemKanban',
  components: { CardModal },
  data: () => ({
    openCardData: { contactId: null, deadline: null, commentary: null, kanbanPrice: null },
    modelCard: false,
    modalTransferirTicket: false,
    usuarioSelecionado: null,
    filaSelecionada: null,
    filas: [],
    usuariosTransferencia: [],
    canaisUsuario: [],
    modalSelecionarCanal: false,
    canalSelecionado: null,
    HideNumber: null,
    userProfile: 'user',
    tipoCanal: '',
    contatoAtual: null,
    erro: null,
    usuarios: [],
    dialogWait: false,
    outlinedAccountCircle,
    recalcularHora: 1,
    statusAbreviado: {
      open: 'A',
      pending: 'P',
      closed: 'R'
    },
    status: {
      open: 'Aberto',
      pending: 'Pendente',
      closed: 'Resolvido'
    },
    color: {
      open: 'primary',
      pending: 'negative',
      closed: 'positive'
    },
    borderColor: {
      open: 'primary',
      pending: 'negative',
      closed: 'positive'
    },
    ticketStatusText: {
      open: 'Ticket aberto',
      pending: 'Ticket pendente',
      closed: 'Ticket encerrado'
    }
  }),
  props: {
    statusTicket: {
      type: String,
      default: () => null
    },
    titleColor: {
      type: String,
      default: () => ''
    },
    contato: {
      type: Object,
      default: () => {
      }
    },
    buscaTicket: {
      type: Boolean,
      default: false
    },
    filas: {
      type: Array,
      default: () => []
    }
  },
  methods: {
    getPhoneNumberLink(number) {
      if (!number) {
        return null
      }
      if ((number.startsWith('55')) && (number.charAt(4) > 5)) {
        return `tel:${number.slice(0, 4)}9${number.slice(-8)}`
      } else {
        return `tel:${number}`
      }
    },
    async listarConfiguracoes() {
      const configuracoes = JSON.parse(localStorage.getItem('configuracoes'))
      const HideNumberConfig = configuracoes?.find(c => c.key === 'HideNumber')
      if (HideNumberConfig) {
        this.HideNumber = HideNumberConfig.value === 'enabled'
      }
    },
    formatKanbanPrice(price) {
      // Se price for nulo, indefinido ou não um número, retornar '0.00'
      return !isNaN(price) ? Number(price).toFixed(2) : '0.00'
    },
    formatId(id) {
      const formattedId = formatSerializedId(id)
      return formattedId
    },
    formatarDataTZ(utcDate) {
      // const localDate = new Date(utcDate).toLocaleString('pt-BR', {
      //   // localeMatcher: 'best fit',
      //   // timeZoneName: 'short',
      // })
      return format(parseISO(utcDate), 'dd-MM-yyyy')
      // return localDate
    },
    updateContato(data) {
      this.modelCard = false // Fecha o modal
      this.$emit('update-contato', { contato: data }) // Emite o evento com os dados atualizados
    },
    openCard(contato) {
      const dd = contato.deadline
      const dados = {
        contactId: contato.id,
        deadline: dd
          ? format(parseISO(dd), 'yyyy-MM-dd')
          : format(new Date(), 'yyyy-MM-dd'),
        commentary: contato.commentary,
        kanbanPrice: contato.kanbanPrice
      }
      this.openCardData = dados
      this.modelCard = true
    },
    Value(obj, prop) {
      try {
        return obj[prop]
      } catch (error) {
        return ''
      }
    },

    dataInWords(timestamp, updated) {
      if (!updated) return ''
      let data = parseJSON(updated)
      if (timestamp) {
        data = new Date(Number(timestamp))
      }
      return formatDistance(data, new Date(), { locale: pt })
    },
    async handleSaveTicket(contact, channel) {
      if (!contact.id) return

      const activeTicket = contact.tickets?.find(ticket =>
        ticket.status === 'open' || ticket.status === 'pending'
      )

      if (activeTicket) {
        this.$router.push(`/atendimento/${activeTicket.id}`)
        return
      }

      try {
        this.contatoAtual = contact
        this.tipoCanal = channel

        // Buscar canais disponíveis para o usuário, enviando o tipo para filtragem no backend
        const { data } = await ListarCanalUsuario(channel)
        this.canaisUsuario = data

        if (this.canaisUsuario.length === 0) {
          this.$q.notify({
            message: this.$t('newticket.noChannelsAvailable'),
            type: 'negative',
            position: 'top'
          })
          return
        }

        this.canalSelecionado = this.canaisUsuario.length > 0 ? this.canaisUsuario[0].id : null

        this.filaSelecionada = this.cUserQueues.length > 0 ? this.cUserQueues[0].id : null

        this.modalSelecionarCanal = true
      } catch (error) {
        this.$notificarErro(this.$t('newticket.loadChannels'), error)
      }
    },
    async criarTicket() {
      if (!this.canalSelecionado || !this.filaSelecionada) {
        this.erro = this.$t('newticket.errorselecionar')
        return
      }

      this.erro = null
      this.loading = true

      try {
        const { data: ticket } = await CriarTicketNew({
          contactId: this.contatoAtual.id,
          isActiveDemand: true,
          channel: this.tipoCanal,
          channelId: this.canalSelecionado,
          queueId: this.filaSelecionada,
          status: 'open'
        })

        this.ticketFocado = ticket
        this.modalSelecionarCanal = false

        await this.$store.commit('SET_HAS_MORE', true)
        await this.$store.dispatch('AbrirChatMensagens', ticket)

        this.$q.notify({
          message: this.$t('contacts.newticket.ServiceStarted', { name: ticket.contact.name, ticketid: ticket.id }),
          type: 'positive',
          position: 'top',
          progress: true,
          actions: [{
            icon: 'close',
            round: true,
            color: 'white'
          }]
        })

        this.$router.push({ name: 'chat', params: { ticketId: ticket.id } })
      } catch (error) {
        this.loading = false
        console.log('error', error)
        const errorMessage = error?.data?.message || this.$t('general.Anunknownerrorhasoccurred')

        if (error.status === 409 && errorMessage === this.$t('general.Aticketalreadyexists')) {
          console.log('Erro 409:', error)
          const ticketAtual = error.data?.ticket
          this.abrirAtendimentoExistente(this.contatoAtual, ticketAtual)
        } else {
          if (error.status === 409) {
            console.log(error)
            this.$q.dialog({
              title: this.$t('general.Attention'),
              message: `${errorMessage}`,
              ok: {
                label: this.$t('general.close'),
                color: 'primary',
                push: true
              },
              persistent: true
            })
            this.$q.notify({
              message: errorMessage,
              type: 'negative',
              position: 'top',
              progress: true,
              actions: [{
                icon: 'close',
                round: true,
                color: 'white'
              }]
            })
          }
        }
      } finally {
        this.loading = false
        this.fecharModalCanal()
      }
    },
    fecharModalCanal() {
      this.modalSelecionarCanal = false
      this.canalSelecionado = null
      this.filaSelecionada = null
      this.contatoAtual = null
      this.tipoCanal = ''
      this.erro = null
    },
    abrirChatContato (ticket) {
      // caso esteja em um tamanho mobile, fechar a drawer dos contatos
      if (this.$q.screen.lt.md && ticket.status !== 'pending') {
        this.$root.$emit('infor-cabecalo-chat:acao-menu')
      }
      if (!(ticket.status !== 'pending' && (ticket.id !== this.$store.getters.ticketFocado.id || this.$route.name !== 'chat'))) return
      this.$store.commit('SET_HAS_MORE', true)
      this.$store.dispatch('AbrirChatMensagens', ticket)
    },
    abrirAtendimentoExistente (contato, ticket) {
      this.$q.dialog({
        title: this.$t('general.Attention'),
        message: this.$t('crm.newticket.ongoingservice', { name: contato.name, ticketid: ticket.id }),
        cancel: {
          label: this.$t('general.no'),
          color: 'primary',
          push: true
        },
        ok: {
          label: this.$t('general.yes'),
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(async () => {
        try {
          this.abrirChatContato(ticket)
        } catch (error) {
          this.$notificarErro(
            this.$t('crm.newticket.tokenerror'),
            error
          )
        }
      })
    }
  },
  mounted () {
    this.listarConfiguracoes()
    this.userProfile = localStorage.getItem('profile')
  },
  computed: {
    cUserQueues () {
      return UserQueues
    }
  },
  created() {
    setInterval(() => {
      this.recalcularHora++
    }, 50000)
  }
}
</script>

<style lang="sass">
.position-status
  position: absolute !important

  left:-65px

  top:-10px

img:after
  content: ""
  vertical-align: middle
  display: inline-block
  border-radius: 50%
  font-size: 48px
  position: absolute
  top: 0
  left: 0
  width: inherit
  height: inherit
  z-index: 10
  color: transparent

.ticket-active-item
  // border: 2px solid rgb(21, 120, 173)
  // border-left: 3px solid $light //rgb(21, 120, 173)
  border-radius: 0
  position: relative
  height: 100%
  background: $blue-1
//$active-item-ticket
// background-color: #e6ebf5

#ListItemsTicket
  .q-item__label + .q-item__label
    margin-top: 1.5px

#item-ticket-houve:hover
  background: $grey-5
  //$active-item-ticket
  transition: all .4s

.primary
  border-left: 2px solid $primary

.negative
  border-left: 2px solid $negative

.positive
  border-left: 2px solid $positive

.ticketNotAnswered
  border-left: 2px solid $amber !important

.ticketBorder
  border-left: 2px solid $grey-9

.ticketBorderGrey
  border-left: 2px solid $grey-4
</style>
