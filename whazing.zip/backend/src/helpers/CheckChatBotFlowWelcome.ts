// Original: CheckChatBotFlowWelcome.js
// Deobfuscated, converted to TS, and translated

'use strict';

import Contact from '../models/Contact';
import Setting from '../models/Setting';
import ChatFlow from '../models/ChatFlow';
import KeywordChatFlow from '../models/KeywordChatFlow';
import Kanban from '../models/Kanban'; // Importar Kanban
import CreateLogTicketService from '../services/TicketServices/CreateLogTicketService';
import IsContactTest from '../services/WbotServices/IsContactTest'; // Importar servicio correcto
import ShowWhatsAppService from '../services/WhatsappService/ShowWhatsAppService'; // Importar servicio correcto
import { RefreshToken } from './RefreshToken'; // Asumiendo exportación nombrada
import CheckSettingsHelper from './CheckSettingsHelper'; // Asumiendo exportación predeterminada
import { logger } from '../utils/logger'; // Asumiendo exportación nombrada

// Tipos inferidos o asumidos para los modelos y servicios
interface Ticket {
  id: number | string;
  tenantId: number;
  contactId: number;
  whatsappId: number | string;
  isGroup: boolean;
  channel: string;
  chatFlowId?: number | null;
  stepChatFlow?: string | null; // Asumiendo string por el uso de 'to'
  lastInteractionBot?: Date | null;
  update: (data: Partial<Ticket>) => Promise<Ticket>;
}

interface ContactInstance {
  id: number;
  number: string;
  kanbanId?: number | null; // Añadir kanbanId
  disableBot?: boolean; // Añadir disableBot
}

interface ChatFlowInstance {
  id: number;
  celularTeste?: string | null;
  flow: {
    nodeList: Array<{ type: string; to: string }>; // Estructura inferida
  };
}

interface SettingInstance {
    key: string;
    value: string;
    tenantId: number;
}

interface WhatsappInstance {
    id: number;
    chatFlowId?: number | null;
}

interface KanbanInstance {
    id: number;
    chatFlowId?: number | null;
}

interface KeywordChatFlowInstance {
  id: number;
  keyword: string;
  chatFlowId: number;
}

// Función para escapar caracteres de RegExp
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& significa la cadena entera coincidente
}

const CheckChatBotFlowWelcome = async (ticket: Ticket, msgBody?: string): Promise<void> => {
  // Si el ticket ya tiene un bot asignado, no hacer nada
  if (ticket.chatBot) return;

  let keywordChatFlow: KeywordChatFlowInstance | undefined;

  // Buscar por palabra clave si msgBody está presente
  if (msgBody) {
    logger.debug(`Mensaje recibida en el nuevo ticket: ${ticket.id} ${msgBody}`);
    const keywords = await KeywordChatFlow.findAll({
      where: {
        tenantId: ticket.tenantId,
        isActive: true // Asumiendo que se buscan palabras clave activas
      }
    });

    keywordChatFlow = keywords.find(k => {
      // Crear RegExp para buscar la palabra clave como palabra completa, insensible a mayúsculas/minúsculas
      const keywordRegex = new RegExp(`\\b${escapeRegExp(k.keyword)}\\b`, 'i');
      return keywordRegex.test(msgBody);
    });
  }

  // Obtener la configuración de chatFlowId por defecto
  const settingChatFlowId = await Setting.findOne({
    where: {
      key: 'chatFlowId',
      tenantId: ticket.tenantId
    }
  });

  // Obtener la instancia de WhatsApp asociada al ticket
   const whatsapp = await ShowWhatsAppService({
       id: ticket.whatsappId,
       tenantId: ticket.tenantId
   }); // Pasar tenantId también


  // Obtener el contacto asociado al ticket
  const contact = await Contact.findByPk(ticket.contactId) as ContactInstance | null; // Castear tipo

  // Obtener el Kanban asociado al contacto si existe
  const kanban = contact?.kanbanId ? await Kanban.findByPk(contact.kanbanId) as KanbanInstance | null : null;

  // Obtener tokens y configuraciones
  const tokenChatFlow = RefreshToken('c77d08e4b8'); // Token para chatFlowId directo
  const tokenTypeBot = RefreshToken('ebc1de57e5'); // Token para typebot general
  const settingTypeBot = await CheckSettingsHelper(tokenTypeBot); // Verificar configuración general de typebot

  let chatFlowId: number | string | null | undefined;

  // Determinar el chatFlowId a usar
  if (settingTypeBot !== tokenChatFlow) {
      // Si la configuración general de typebot NO es la directa para chatFlowId,
      // prioriza el chatFlowId del WhatsApp o el encontrado en la configuración.
      chatFlowId = whatsapp?.chatFlowId || settingChatFlowId?.value;
  } else {
      // Si la configuración general de typebot ES la directa para chatFlowId,
      // prioriza el Kanban, luego la palabra clave, luego WhatsApp, luego la configuración.
      chatFlowId = kanban?.chatFlowId || keywordChatFlow?.chatFlowId || whatsapp?.chatFlowId || settingChatFlowId?.value;
  }


  // Si no se encontró ningún chatFlowId, no hacer nada
  if (!chatFlowId) return;

  // Buscar el ChatFlow activo y no eliminado
  const chatFlow = await ChatFlow.findOne({
    where: {
      id: +chatFlowId, // Convertir a número
      tenantId: ticket.tenantId,
      isActive: true,
      isDeleted: false // Asumiendo que hay un campo isDeleted
    }
  }) as ChatFlowInstance | null; // Castear tipo

  // Si no se encontró el ChatFlow, no hacer nada
  if (!chatFlow) return;

  const { celularTeste } = chatFlow;
  const contactNumber = contact?.number;

  // Si el contacto tiene el bot deshabilitado, no hacer nada
  if (contact?.disableBot) return;

  // Verificar si el contacto es un número de prueba
  const isTestContact = await IsContactTest(contactNumber, celularTeste, ticket.channel);
  if (isTestContact) return;


  // Encontrar el nodo inicial del flujo
  const startNode = chatFlow.flow.nodeList.find(node => node.type === 'start');
  if (!startNode) return; // No hacer nada si no hay nodo inicial

  // Actualizar el ticket con la información del ChatFlow
  await ticket.update({
    chatFlowId: parseInt(String(chatFlow.id), 10), // Asegurar que sea número
    stepChatFlow: startNode.to, // Asignar el siguiente paso desde el nodo 'start'
    lastInteractionBot: new Date()
  });

  // Crear un registro en el log del ticket
  await CreateLogTicketService({
    ticketId: ticket.id,
    type: 'chatFlowId' // Indicar que el ticket entró en un flujo
  });
};

export default CheckChatBotFlowWelcome;