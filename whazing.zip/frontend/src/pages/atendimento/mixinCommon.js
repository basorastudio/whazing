import { format, parseISO, parseJSON } from 'date-fns'
import pt from 'date-fns/locale/pt-BR'
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters(['mensagensTicket', 'ticketFocado', 'hasMore'])
  },
  data () {
    return {
      loading: false
    }
  },
  methods: {
    scrollToBottom () {
      setTimeout(() => {
        this.$root.$emit('scrollToBottomMessageChat')
      }, 200)
    },
    dataInWords (date) {
      return format(parseJSON(date), 'HH:mm', { locale: pt })
    },
    formatMediaName(filePath) {
      if (!filePath) return ''

      // Get just the filename part after the last '/'
      const fileName = filePath.split('/').pop() || ''

      const lastUnderscoreIndex = fileName.lastIndexOf('_')
      const extension = fileName.slice(fileName.lastIndexOf('.'))

      if (lastUnderscoreIndex === -1) return fileName

      const baseNameParts = fileName.slice(0, lastUnderscoreIndex).split('_')
      return `${baseNameParts.join('_')}${extension}`
    },
    formatarMensagemWhatsapp (body) {
      if (!body) return
      let formatado = body
      function isAlphanumeric (c) {
        const x = c.charCodeAt()
        return (x >= 65 && x <= 90) || (x >= 97 && x <= 122) || (x >= 48 && x <= 57)
      }
      function whatsappStyles (texto, wildcard, opTag, clTag) {
        const indices = []
        for (let i = 0; i < texto.length; i++) {
          if (texto[i] === wildcard) {
            if (indices.length % 2) {
              if (texto[i - 1] !== ' ' && (typeof texto[i + 1] === 'undefined' || !isAlphanumeric(texto[i + 1]))) {
                indices.push(i)
              }
            } else {
              if (typeof texto[i + 1] !== 'undefined' && texto[i + 1] !== ' ' && (typeof texto[i - 1] === 'undefined' || !isAlphanumeric(texto[i - 1]))) {
                indices.push(i)
              }
            }
          } else if (texto[i].charCodeAt() === 10 && indices.length % 2) {
            indices.pop()
          }
        }
        if (indices.length % 2) indices.pop()
        let offset = 0
        indices.forEach((v, i) => {
          const tag = i % 2 ? clTag : opTag
          formatado = formatado.slice(0, v + offset) + tag + formatado.slice(v + offset + 1)
          offset += tag.length - 1
        })
        return formatado
      }
      formatado = whatsappStyles(formatado, '_', '<i>', '</i>')
      formatado = whatsappStyles(formatado, '*', '<b>', '</b>')
      formatado = whatsappStyles(formatado, '~', '<s>', '</s>')
      formatado = formatado.replace(/\n/g, '<br>')
      return formatado
    },
    downloadMedia(url) {
      fetch(url)
        .then(response => {
          const contentType = response.headers.get('Content-Type')

          const isDownloadable = contentType && (
            contentType.startsWith('image/') ||
            contentType.startsWith('video/') ||
            contentType.startsWith('audio/') ||
            contentType === 'application/pdf'
          )

          if (!isDownloadable) {
            window.open(url, '_blank')
            return
          }

          const disposition = response.headers.get('Content-Disposition')
          let filename = ''

          if (disposition && disposition.includes('filename=')) {
            filename = disposition.split('filename=')[1].replace(/['"]/g, '')
          } else {
            filename = url.split('/').pop().split('?')[0]
          }

          if (!filename.includes('.')) {
            let ext = ''
            if (contentType === 'application/pdf') {
              ext = 'pdf'
            } else {
              ext = contentType.split('/')[1]
            }
            filename = `${filename}.${ext}`
          }

          return response.blob().then(blob => ({ blob, filename }))
        })
        .then(data => {
          if (!data) return

          const { blob, filename } = data
          const blobUrl = window.URL.createObjectURL(blob)
          const link = document.createElement('a')
          link.href = blobUrl
          link.download = filename
          document.body.appendChild(link)
          link.click()
          document.body.removeChild(link)
          window.URL.revokeObjectURL(blobUrl)
        })
        .catch(error => {
          console.error('Erro ao baixar mídia:', error)
          this.$q.notify({
            color: 'negative',
            message: this.$t('mixinCommon.ErrorDownload'),
            icon: 'report_problem'
          })
        })
    },
    formatarNota(body) {
      if (!body) return
      const notaFormatada = `
      <b>Nota interna:</b><br/>
      ${body.split('\n').join('<br/>')}
  `
      return notaFormatada
    },
    formatarBotaoWhatsapp (body) {
      if (!body) return
      let formatado = body

      function isAlphanumeric (c) {
        const x = c.charCodeAt()
        return (x >= 65 && x <= 90) || (x >= 97 && x <= 122) || (x >= 48 && x <= 57)
      }

      const whatsappStyles = (texto, wildcard, opTag, clTag) => {
        const indices = []
        try {
          for (let i = 0; i < texto.length; i++) {
            if (texto[i] === wildcard) {
              if (indices.length % 2) {
                if (texto[i - 1] !== ' ' && (typeof texto[i + 1] === 'undefined' || !isAlphanumeric(texto[i + 1]))) {
                  indices.push(i)
                }
              } else {
                if (typeof texto[i + 1] !== 'undefined' && texto[i + 1] !== ' ' && (typeof texto[i - 1] === 'undefined' || !isAlphanumeric(texto[i - 1]))) {
                  indices.push(i)
                }
              }
            } else if (texto[i].charCodeAt() === 10 && indices.length % 2) {
              indices.pop()
            }
          }
          if (indices.length % 2) indices.pop()
          let offset = 0
          indices.forEach((v, i) => {
            const tag = i % 2 ? clTag : opTag
            formatado = formatado.slice(0, v + offset) + tag + formatado.slice(v + offset + 1)
            offset += tag.length - 1
          })
        } catch (error) {
          console.error('Erro ao aplicar estilos do WhatsApp:', error)
        }
        return formatado
      }

      try {
        // Quebra o body em linhas
        const linhas = body.trim().split('\n')
        const tituloDescricao = linhas.shift() + '\n' // Primeira linha é o título
        const botoes = linhas.filter(btn => btn.trim() !== '').map(btn => {
          return `<button style="display: inline-block; margin: 5px; padding: 10px; background-color: #0084ff; color: white; border: none; border-radius: 5px;" title="Esse botão só é clicável no celular">➡️ ${btn.trim()}</button>`
        })
        formatado = [tituloDescricao, ...botoes].join('\n')
        formatado = whatsappStyles(formatado, '_', '<i>', '</i>')
        formatado = whatsappStyles(formatado, '*', '<b>', '</b>')
        formatado = whatsappStyles(formatado, '~', '<s>', '</s>')
        formatado = formatado.replace(/\n/g, '<br>')
        return formatado
      } catch (error) {
        console.error('Erro ao formatar botão do WhatsApp:', error)
        return body
      }
    },
    formatarInteractiveWhatsapp(mensagem) {
      if (!mensagem) return ''

      try {
        const msgObj = typeof mensagem === 'string' ? JSON.parse(mensagem) : mensagem

        // Verificar se é o novo formato (contém message.listMessage)
        if (msgObj.message?.listMessage) {
          const listMsg = msgObj.message.listMessage
          let formatado = '<div class="whatsapp-interactive list">'

          if (listMsg.title) {
            formatado += `<div class="list-header"><b>${this.formatarMensagemWhatsapp(listMsg.title)}</b></div>`
          }

          if (listMsg.description) {
            formatado += `<div class="list-body">${this.formatarMensagemWhatsapp(listMsg.description)}</div>`
          }

          if (listMsg.sections && listMsg.sections.length > 0) {
            formatado += '<div class="list-sections">'
            listMsg.sections.forEach(section => {
              formatado += '<div class="list-section">'

              if (section.title) {
                formatado += `<div class="section-title"><b>${section.title}</b></div>`
              }

              if (section.rows && section.rows.length > 0) {
                formatado += '<ul class="section-items">'
                section.rows.forEach(row => {
                  formatado += '<li class="section-item">'
                  formatado += `<div class="item-title">${row.title}</div>`
                  if (row.description) {
                    formatado += `<div class="item-description">${row.description}</div>`
                  }
                  formatado += '</li>'
                })
                formatado += '</ul>'
              }

              formatado += '</div>' // Fecha section
            })
            formatado += '</div>' // Fecha sections
          }

          if (listMsg.buttonText) {
            formatado += `<div class="list-button"><button style="display: inline-block; margin: 5px; padding: 10px; background-color: #0084ff; color: white; border: none; border-radius: 5px;" title="Esse botão só é clicável no celular">➡️ ${listMsg.buttonText}</button></div>`
          }

          formatado += '</div>' // Fecha container
          return formatado
        }

        // Continua com o formato original
        switch (msgObj.type) {
          case 'location_request_message': {
            let formatado = '<div class="whatsapp-interactive location-request">'

            if (msgObj.body?.text) {
              formatado += `<div class="location-body">${this.formatarMensagemWhatsapp(msgObj.body.text)}</div>`
            }

            if (msgObj.action?.name === 'send_location') {
              formatado += '<div class="location-button"><button style="display: inline-block; margin: 5px; padding: 10px; background-color: #0084ff; color: white; border: none; border-radius: 5px;" title="Esse botão só é clicável no celular">📍 Compartilhar localização</button></div>'
            }

            formatado += '</div>' // Fecha container
            return formatado
          }

          case 'list': {
            let formatado = '<div class="whatsapp-interactive list">'

            if (msgObj.header?.text) {
              formatado += `<div class="list-header"><b>${this.formatarMensagemWhatsapp(msgObj.header.text)}</b></div>`
            }

            if (msgObj.body?.text) {
              formatado += `<div class="list-body">${this.formatarMensagemWhatsapp(msgObj.body.text)}</div>`
            }

            if (msgObj.action?.sections && msgObj.action.sections.length > 0) {
              formatado += '<div class="list-sections">'
              msgObj.action.sections.forEach(section => {
                formatado += '<div class="list-section">'

                if (section.title) {
                  formatado += `<div class="section-title"><b>${section.title}</b></div>`
                }

                if (section.rows && section.rows.length > 0) {
                  formatado += '<ul class="section-items">'
                  section.rows.forEach(row => {
                    formatado += '<li class="section-item">'
                    formatado += `<div class="item-title">${row.title}</div>`
                    if (row.description) {
                      formatado += `<div class="item-description">${row.description}</div>`
                    }
                    formatado += '</li>'
                  })
                  formatado += '</ul>'
                }

                formatado += '</div>' // Fecha section
              })
              formatado += '</div>' // Fecha sections
            }

            if (msgObj.action?.button) {
              formatado += `<div class="list-button"><button style="display: inline-block; margin: 5px; padding: 10px; background-color: #0084ff; color: white; border: none; border-radius: 5px;" title="Esse botão só é clicável no celular">➡️ ${msgObj.action.button}</button></div>`
            }

            formatado += '</div>' // Fecha container
            return formatado
          }

          case 'cta_url': {
            let formatado = '<div class="whatsapp-interactive cta-url">'

            if (msgObj.header?.text) {
              formatado += `<div class="cta-header"><b>${this.formatarMensagemWhatsapp(msgObj.header.text)}</b></div>`
            }

            if (msgObj.body?.text) {
              formatado += `<div class="cta-body">${this.formatarMensagemWhatsapp(msgObj.body.text)}</div>`
            }

            if (msgObj.footer?.text) {
              formatado += `<div class="cta-footer"><small>${this.formatarMensagemWhatsapp(msgObj.footer.text)}</small></div>`
            }

            if (msgObj.action?.parameters) {
              const { display_text, url } = msgObj.action.parameters
              formatado += `<div class="cta-button"><a href="${url}" target="_blank" style="display: inline-block; margin: 5px; padding: 10px; background-color: #0084ff; color: white; text-decoration: none; border-radius: 5px;">${display_text}</a></div>`
            }

            formatado += '</div>'
            return formatado
          }

          case 'button': {
            let formatado = '<div class="whatsapp-interactive button">'

            if (msgObj.body?.text) {
              formatado += `<div class="button-body">${this.formatarMensagemWhatsapp(msgObj.body.text)}</div>`
            }

            if (msgObj.action?.buttons && msgObj.action.buttons.length > 0) {
              formatado += '<div class="button-container">'
              msgObj.action.buttons.forEach(button => {
                if (button.type === 'reply' && button.reply) {
                  formatado += `<button style="display: inline-block; margin: 5px; padding: 10px; background-color: #0084ff; color: white; border: none; border-radius: 5px;" title="Esse botão só é clicável no celular">➡️ ${button.reply.title}</button>`
                }
              })
              formatado += '</div>'
            }

            formatado += '</div>' // Fecha container
            return formatado
          }

          default:
            return '<div class="unknown-interactive">Mensagem interativa não suportada</div>'
        }
      } catch (error) {
        console.error('Erro ao formatar mensagem interativa do WhatsApp:', error)
        return String(mensagem)
      }
    },
    formatarinteractiveMessage(messageData) {
      let message

      try {
        if (typeof messageData === 'string') {
          message = JSON.parse(messageData)
        } else {
          message = JSON.parse(JSON.stringify(messageData))
        }
      } catch (e) {
        console.error('Error parsing message data:', e)
        return this.$t('mensagemchat.midia.indisponivel.interativa')
      }

      if (!message || !message.message || !message.message.interactiveMessage) {
        return this.$t('mensagemchat.midia.indisponivel.interativa')
      }

      try {
        // Get the interactive message
        const interactiveMsg = message.message.interactiveMessage

        // Check if it's a payment message (nativeFlowMessage)
        if (interactiveMsg.nativeFlowMessage && interactiveMsg.nativeFlowMessage.buttons) {
          const paymentButton = interactiveMsg.nativeFlowMessage.buttons.find(btn => btn.name === 'payment_info')

          if (paymentButton && paymentButton.buttonParamsJson) {
            // Parse the payment info
            const paymentInfo = JSON.parse(paymentButton.buttonParamsJson)

            // Format currency value (assuming it's in cents)
            const formatCurrency = (amount) => {
              if (!amount || typeof amount.value === 'undefined' || typeof amount.offset === 'undefined') {
                return 'N/A'
              }

              const value = amount.value / amount.offset
              return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: paymentInfo.currency || 'BRL' }).format(value)
            }

            // Build a nice formatted payment message
            let formatado = `
          <div class="whatsapp-payment">
            <div class="payment-header">
              <h3>💰 Solicitação de Pagamento</h3>
            </div>
            <div class="payment-details">
        `

            // Add order details if available
            if (paymentInfo.order) {
              if (paymentInfo.order.items && paymentInfo.order.items.length > 0) {
                formatado += '<div class="payment-items">'

                paymentInfo.order.items.forEach(item => {
                  if (item.name) {
                    const itemAmount = formatCurrency(item.amount)
                    const quantity = item.quantity || 1
                    formatado += `
                  <div class="payment-item">
                    <span>${item.name} ${quantity > 1 ? `(${quantity}x)` : ''}</span>
                    <span>${itemAmount}</span>
                  </div>
                `
                  }
                })

                formatado += '</div>'
              }

              // Add subtotal if available
              if (paymentInfo.order.subtotal) {
                formatado += `
              <div class="payment-subtotal">
                <span>Subtotal:</span>
                <span>${formatCurrency(paymentInfo.order.subtotal)}</span>
              </div>
            `
              }
            }

            // Add total amount
            if (paymentInfo.total_amount) {
              formatado += `
            <div class="payment-total">
              <span><strong>Total:</strong></span>
              <span><strong>${formatCurrency(paymentInfo.total_amount)}</strong></span>
            </div>
          `
            }

            // Add payment method info
            if (paymentInfo.payment_settings && paymentInfo.payment_settings.length > 0) {
              const pixSettings = paymentInfo.payment_settings.find(ps => ps.type === 'pix_static_code')

              if (pixSettings && pixSettings.pix_static_code) {
                const pixInfo = pixSettings.pix_static_code
                formatado += `
              <div class="payment-method">
                <div class="pix-info">
                  <p><strong>Pagamento via PIX</strong></p>
                  ${pixInfo.merchant_name ? `<p>Beneficiário: ${pixInfo.merchant_name}</p>` : ''}
                  ${pixInfo.key ? `<p>Chave: ${pixInfo.key} (${pixInfo.key_type || 'PIX'})</p>` : ''}
                </div>
              </div>
            `
              }
            }

            // Reference ID
            if (paymentInfo.reference_id) {
              formatado += `
            <div class="payment-reference">
              <small>Referência: ${paymentInfo.reference_id}</small>
            </div>
          `
            }

            // Note about the payment
            formatado += `
              <div class="payment-note">
                <small><i>Este pagamento só pode ser realizado no WhatsApp</i></small>
              </div>
            </div>
          </div>
        `

            return formatado
          }
        }

        // If it's not a payment or couldn't be parsed, return i18n variable
        return this.$t('mensagemchat.midia.indisponivel.interativa')
      } catch (error) {
        console.error('Erro ao formatar mensagem interativa do WhatsApp:', error)
        // Return i18n variable on any error
        return this.$t('mensagemchat.midia.indisponivel.interativa')
      }
    },
    formatarEventMessage(messageData) {
      let message

      try {
        if (typeof messageData === 'string') {
          message = JSON.parse(messageData)
        } else {
          message = JSON.parse(JSON.stringify(messageData))
        }
      } catch (e) {
        console.error('Error parsing message data:', e)
        return this.$t('mensagemchat.midia.indisponivel.eventMessage')
      }

      if (!message || !message.message || !message.message.eventMessage) {
        return this.$t('mensagemchat.midia.indisponivel.eventMessage')
      }

      try {
        // Get the event message
        const eventMsg = message.message.eventMessage

        // Check if event has been canceled
        const isCanceled = eventMsg.isCanceled === true

        // Format the date from Unix timestamp (seconds)
        const formatEventDate = (timestamp) => {
          if (!timestamp) return 'Data não especificada'

          // Convert Unix timestamp to Date object (multiply by 1000 to convert seconds to milliseconds)
          const date = new Date(parseInt(timestamp) * 1000)

          try {
            // Format date in Portuguese Brazil locale
            return new Intl.DateTimeFormat('pt-BR', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
              timeZone: 'America/Sao_Paulo' // Use appropriate timezone
            }).format(date)
          } catch (e) {
            console.error('Error formatting date:', e)
            // Fallback format
            return date.toLocaleString('pt-BR')
          }
        }

        // Build a formatted event message
        let formatado = `
      <div class="whatsapp-event ${isCanceled ? 'event-canceled' : ''}">
        <div class="event-header">
          <h3>📅 ${isCanceled ? 'Evento Cancelado' : 'Convite para Evento'}</h3>
        </div>
        <div class="event-details">
    `

        // Add event name
        if (eventMsg.name) {
          formatado += `
        <div class="event-name">
          <strong>${eventMsg.name}</strong>
        </div>
      `
        }

        // Add event description if available
        if (eventMsg.description) {
          formatado += `
        <div class="event-description">
          <p>${eventMsg.description}</p>
        </div>
      `
        }

        // Add event date/time
        if (eventMsg.startTime) {
          formatado += `
        <div class="event-time">
          <div><span>🕒 Data e hora:</span></div>
          <div>${formatEventDate(eventMsg.startTime)}</div>
        </div>
      `
        }

        // Add information about extra guests
        if (typeof eventMsg.extraGuestsAllowed !== 'undefined') {
          formatado += `
        <div class="event-guests-info">
          <small>${eventMsg.extraGuestsAllowed
            ? 'Convidados adicionais são permitidos'
            : 'Convidados adicionais não são permitidos'}</small>
        </div>
      `
        }

        // Note about the event
        formatado += `
          <div class="event-note">
            <small><i>Este evento só pode ser visualizado completamente no WhatsApp</i></small>
          </div>
        </div>
      </div>
    `
        return formatado
      } catch (error) {
        console.error('Erro ao formatar mensagem de evento do WhatsApp:', error)
        // Return i18n variable on any error
        return this.$t('mensagemchat.midia.indisponivel.eventMessage')
      }
    },
    formatarproductMessage(messageData) {
      let message

      try {
        if (typeof messageData === 'string') {
          message = JSON.parse(messageData)
        } else {
          message = JSON.parse(JSON.stringify(messageData))
        }
      } catch (e) {
        return this.$t('mensagemchat.midia.indisponivel.produto')
      }

      if (!message || !message.message || !message.message.productMessage || !message.message.productMessage.product) {
        return this.$t('mensagemchat.midia.indisponivel.produto')
      }

      try {
        const product = message.message.productMessage.product

        const formatCurrency = (amount, currencyCode) => {
          if (!amount) return 'N/A'

          try {
            const value = parseInt(amount) / 1000
            return new Intl.NumberFormat('pt-BR', {
              style: 'currency',
              currency: currencyCode || 'BRL'
            }).format(value)
          } catch (err) {
            console.error('Error formatting currency:', err)
            return `${currencyCode || 'BRL'} ${amount / 1000}`
          }
        }

        const businessName = message.verifiedBizName ||
          (message.message.productMessage.businessOwnerJid
            ? message.message.productMessage.businessOwnerJid.split('@')[0]
            : 'Loja')

        let formatado = `
      <div class="whatsapp-product">
        <div class="product-header">
          <h3>🛍️ Produto</h3>
          ${businessName ? `<div class="product-business">${businessName}</div>` : ''}
        </div>
        <div class="product-content">
    `

        formatado += '<div class="product-details">'

        if (product.title) {
          formatado += `
        <div class="product-title">
          <strong>${product.title}</strong>
        </div>
      `
        }

        if (product.priceAmount1000 && product.currencyCode) {
          formatado += `
        <div class="product-price">
          ${formatCurrency(product.priceAmount1000, product.currencyCode)}
        </div>
      `
        }

        if (product.productId) {
          formatado += `
        <div class="product-id">
          <small>ID: ${product.productId}</small>
        </div>
      `
        }

        formatado += `
          </div>
        </div>
        <div class="product-footer">
          <small><i>Este produto só pode ser comprado através do WhatsApp</i></small>
        </div>
      </div>
    `

        return formatado
      } catch (error) {
        console.error('Erro ao formatar mensagem de produto do WhatsApp:', error)
        return this.$t('mensagemchat.midia.indisponivel.produto')
      }
    },
    formatarpollCreationMessage(messageData) {
      let message

      try {
        if (typeof messageData === 'string') {
          message = JSON.parse(messageData)
        } else {
          message = JSON.parse(JSON.stringify(messageData))
        }
      } catch (e) {
        console.error('Error parsing message data:', e)
        message = messageData
      }

      if (!message || !message.message || !message.message.pollCreationMessageV3) {
        return ''
      }

      try {
        const poll = message.message.pollCreationMessageV3

        const formatado = `
      <div style="border: 1px solid #ddd; padding: 10px; margin: 10px 0; border-radius: 8px;">
        <div style="font-weight: bold; margin-bottom: 10px;">${poll.name}</div>
        <div>
          ${poll.options.map(option => `<div style="margin: 5px 0;">◯ ${option.optionName}</div>`).join('')}
        </div>
      </div>
    `

        return formatado
      } catch (error) {
        console.error('Erro ao formatar enquete do WhatsApp:', error)
        return `<div>Erro ao carregar a enquete: ${error.message}</div>`
      }
    },
    formatarData (data, formato = 'dd/MM/yyyy') {
      return format(parseISO(data), formato, { locale: pt })
    },
    formatarComentario(dataJson) {
      try {
        const data = typeof dataJson === 'string' ? JSON.parse(dataJson) : dataJson

        const plataforma = data.channel || 'desconhecida'

        const infoComentario = {
          nomeUsuario: 'Usuário',
          textoComentario: '',
          linkPublicacao: '',
          plataforma: plataforma
        }

        const nomeUsuario = data.message?.visitor?.name || 'Usuário'
        const textoComentario = data.message?.contents?.[0]?.text || data.body || ''

        infoComentario.nomeUsuario = nomeUsuario
        infoComentario.textoComentario = textoComentario

        if (plataforma === 'instagram') {
          infoComentario.linkPublicacao = data.message?.contents?.[0]?.media?.link || ''
        } else if (plataforma === 'facebook') {
          infoComentario.linkPublicacao = data.message?.contents?.[0]?.post?.link || ''
        }

        return infoComentario
      } catch (error) {
        console.error('Erro ao formatar comentário:', error)
        return {
          nomeUsuario: 'Usuário',
          textoComentario: '',
          linkPublicacao: '',
          plataforma: 'desconhecida'
        }
      }
    },
    formatarTemplateWhatsapp(messageData) {
      let template

      try {
        if (typeof messageData === 'string') {
          template = JSON.parse(messageData)
        } else {
          template = JSON.parse(JSON.stringify(messageData))
        }
      } catch (e) {
        console.error('Error parsing template data:', e)
        template = messageData
      }

      if (!template || !template.name || !template.components || !Array.isArray(template.components)) {
        console.error('Template inválido ou mal formatado:', template)
        return '<div class="whatsapp-template-error">Template inválido ou mal formatado</div>'
      }

      try {
        // Build the template HTML
        let formatado = `
      <div class="whatsapp-template">
        <div class="template-header">
          <span class="template-badge">${template.language?.code || 'pt_BR'}</span>
          <span class="template-name">${template.name}</span>
        </div>
        <div class="template-content">
    `

        // Process each component
        template.components.forEach(component => {
          switch (component.type) {
            case 'header':
              formatado += this.formatarTemplateHeader(component)
              break
            case 'body':
              formatado += this.formatarTemplateBody(component)
              break
            case 'button':
              formatado += this.formatarTemplateButton(component)
              break
            default:
              formatado += `<div class="template-unknown-component">Tipo de componente desconhecido: ${component.type}</div>`
          }
        })

        formatado += `
        </div>
      </div>
    `

        return formatado
      } catch (error) {
        console.error('Erro ao formatar template do WhatsApp:', error)
        return `<div class="whatsapp-template-error">Erro ao processar template: ${error.message}</div>`
      }
    },
    formatarTemplateHeader(component) {
      if (!component.parameters || !Array.isArray(component.parameters)) {
        return '<div class="template-component header">Cabeçalho sem parâmetros</div>'
      }

      let headerHtml = '<div class="template-component header">'

      component.parameters.forEach(param => {
        if (param.type === 'image' && param.image?.link) {
          headerHtml += `
        <div class="header-document">
          <div class="document-icon">📷</div>
          <div class="document-info">Imagem</div>
        </div>
      `
        } else if (param.type === 'text' && param.text) {
          headerHtml += `
        <div class="header-text">
          ${this.formatarMensagemWhatsapp(param.text)}
        </div>
      `
        } else if (param.type === 'document' && param.document?.link) {
          headerHtml += `
        <div class="header-document">
          <div class="document-icon">📄</div>
          <div class="document-info">Documento</div>
        </div>
      `
        } else if (param.type === 'video' && param.video?.link) {
          headerHtml += `
        <div class="header-video">
          <div class="video-icon">🎬</div>
          <div class="video-info">Vídeo</div>
        </div>
      `
        }
      })

      headerHtml += '</div>'
      return headerHtml
    },
    formatarTemplateBody(component) {
      let bodyHtml = '<div class="template-component body">'

      if (!component.parameters || !Array.isArray(component.parameters) || component.parameters.length === 0) {
        bodyHtml += '<div class="body-text">Corpo do template sem parâmetros</div>'
      } else {
        bodyHtml += '<div class="body-parameters">'
        component.parameters.forEach((param, index) => {
          if (param.type === 'text') {
            const paramName = param.parameter_name ? param.parameter_name : `Parâmetro ${index + 1}`
            const paramText = param.text || ''
            bodyHtml += `
          <div class="body-parameter">
            <span class="parameter-name">${paramName}:</span>
            <span class="parameter-value">${this.formatarMensagemWhatsapp(paramText)}</span>
          </div>
        `
          }
        })
        bodyHtml += '</div>'
      }

      bodyHtml += '</div>'
      return bodyHtml
    },
    formatarTemplateButton(component) {
      const buttonIndex = component.index || '0'
      const buttonType = component.sub_type || 'padrão'

      let buttonHtml = `
    <div class="template-component button">
      <button
        class="whatsapp-button ${buttonType}"
        data-index="${buttonIndex}"
        title="Esse botão só é clicável no WhatsApp">
        ➡️ ${buttonType === 'url' ? 'Abrir link' : 'Botão interativo'}
      </button>
  `

      if (component.parameters && Array.isArray(component.parameters) && component.parameters.length > 0) {
        buttonHtml += '<div class="button-parameters">'
        component.parameters.forEach(param => {
          if (param.type === 'text' && param.text) {
            buttonHtml += `
          <div class="button-parameter">
            <span class="parameter-value">${this.formatarMensagemWhatsapp(param.text)}</span>
          </div>
        `
          }
        })
        buttonHtml += '</div>'
      }

      buttonHtml += '</div>'
      return buttonHtml
    }
  }
}
