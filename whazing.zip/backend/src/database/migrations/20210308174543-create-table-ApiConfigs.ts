import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Validación simple para verificar si es una URL
    const urlValidation = { isUrl: true };

    // Crea la tabla 'ApiConfigs' para configuraciones de API
    return Promise.all([
      // Usar Promise.all aunque solo sea una operación
      queryInterface.createTable("ApiConfigs", {
        id: {
          allowNull: false,
          primaryKey: true,
          type: DataTypes.UUID,
          // Establece el valor predeterminado usando la función gen_random_uuid() de PostgreSQL
          defaultValue: Sequelize.literal("gen_random_uuid()")
        },
        sessionId: {
          // ID de la sesión de WhatsApp asociada
          type: DataTypes.INTEGER,
          references: { model: "Whatsapps", key: "id" },
          onUpdate: "CASCADE",
          onDelete: "SET NULL"
        },
        name: {
          // Nombre de la configuración de API
          type: DataTypes.STRING,
          allowNull: false,
          defaultValue: ""
        },
        isActive: {
          // Indica si la configuración está activa
          type: DataTypes.BOOLEAN,
          allowNull: false,
          defaultValue: true
        },
        token: {
          // Token de autenticación para la API
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
        },
        userId: {
          type: DataTypes.INTEGER,
          references: { model: "Users", key: "id" },
          onUpdate: "CASCADE",
          onDelete: "SET NULL"
        },
        tenantId: {
          type: DataTypes.INTEGER,
          references: { model: "Tenants", key: "id" },
          onUpdate: "CASCADE",
          onDelete: "CASCADE",
          allowNull: false,
          defaultValue: 1
        },
        urlServiceStatus: {
          // URL para el webhook de estado del servicio
          type: DataTypes.TEXT,
          allowNull: true,
          defaultValue: null,
          validate: urlValidation // Aplica la validación de URL
        },
        urlMessageStatus: {
          // URL para el webhook de estado de mensajes
          type: DataTypes.TEXT,
          allowNull: true,
          defaultValue: null,
          validate: urlValidation // Aplica la validación de URL
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false
        }
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la tabla 'ApiConfigs'
    return Promise.all([
      // Usar Promise.all aunque solo sea una operación
      queryInterface.dropTable("ApiConfigs")
    ]);
  }
};
