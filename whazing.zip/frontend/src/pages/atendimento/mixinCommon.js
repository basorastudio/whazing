import { format, parseISO, parseJSON } from 'date-fns'
import es from 'date-fns/locale/es'
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters(['mensagensTicket', 'ticketFocado', 'hasMore'])
  },
  data () {
    return {
      loading: false
    }
  },
  methods: {
    scrollToBottom () {
      setTimeout(() => {
        this.$root.$emit('scrollToBottomMessageChat')
      }, 200)
    },
    dataInWords (date) {
      return format(parseJSON(date), 'HH:mm', { locale: es })
    },
    formatMediaName(filePath) {
      if (!filePath) return ''

      // Obtener solo el nombre del archivo después del último '/'
      const fileName = filePath.split('/').pop() || ''

      const lastUnderscoreIndex = fileName.lastIndexOf('_')
      const extension = fileName.slice(fileName.lastIndexOf('.'))

      if (lastUnderscoreIndex === -1) return fileName

      const baseNameParts = fileName.slice(0, lastUnderscoreIndex).split('_')
      return `${baseNameParts.join('_')}${extension}`
    },
    formatarMensagemWhatsapp (body) {
      if (!body) return
      let formatado = body
      function isAlphanumeric (c) {
        const x = c.charCodeAt()
        return (x >= 65 && x <= 90) || (x >= 97 && x <= 122) || (x >= 48 && x <= 57)
      }
      function whatsappStyles (texto, wildcard, opTag, clTag) {
        const indices = []
        for (let i = 0; i < texto.length; i++) {
          if (texto[i] === wildcard) {
            if (indices.length % 2) {
              if (texto[i - 1] !== ' ' && (typeof texto[i + 1] === 'undefined' || !isAlphanumeric(texto[i + 1]))) {
                indices.push(i)
              }
            } else {
              if (typeof texto[i + 1] !== 'undefined' && texto[i + 1] !== ' ' && (typeof texto[i - 1] === 'undefined' || !isAlphanumeric(texto[i - 1]))) {
                indices.push(i)
              }
            }
          } else if (texto[i].charCodeAt() === 10 && indices.length % 2) {
            indices.pop()
          }
        }
        if (indices.length % 2) indices.pop()
        let offset = 0
        indices.forEach((v, i) => {
          const tag = i % 2 ? clTag : opTag
          formatado = formatado.slice(0, v + offset) + tag + formatado.slice(v + offset + 1)
          offset += tag.length - 1
        })
        return formatado
      }
      formatado = whatsappStyles(formatado, '_', '<i>', '</i>')
      formatado = whatsappStyles(formatado, '*', '<b>', '</b>')
      formatado = whatsappStyles(formatado, '~', '<s>', '</s>')
      formatado = formatado.replace(/\n/g, '<br>')
      return formatado
    },
    downloadMedia(url) {
      fetch(url)
        .then(response => {
          const contentType = response.headers.get('Content-Type')

          const isDownloadable = contentType && (
            contentType.startsWith('image/') ||
            contentType.startsWith('video/') ||
            contentType.startsWith('audio/') ||
            contentType === 'application/pdf'
          )

          if (!isDownloadable) {
            window.open(url, '_blank')
            return
          }

          const disposition = response.headers.get('Content-Disposition')
          let filename = ''

          if (disposition && disposition includes('filename=')) {
            filename = disposition.split('filename=')[1].replace(/['"]/g, '')
          } else {
            filename = url.split('/').pop().split('?')[0]
          }

          if (!filename.includes('.')) {
            let ext = ''
            if (contentType === 'application/pdf') {
              ext = 'pdf'
            } else {
              ext = contentType.split('/')[1]
            }
            filename = `${filename}.${ext}`
          }

          return response.blob().then(blob => ({ blob, filename }))
        })
        .then(data => {
          if (!data) return

          const { blob, filename } = data
          const blobUrl = window.URL.createObjectURL(blob)
          const link = document.createElement('a')
          link.href = blobUrl
          link.download = filename
          document.body.appendChild(link)
          link.click()
          document.body.removeChild(link)
          window.URL.revokeObjectURL(blobUrl)
        })
        .catch(error => {
          console.error('Error al descargar media:', error)
          this.$q.notify({
            color: 'negative',
            message: 'Error al descargar media. Por favor, inténtelo de nuevo.',
            icon: 'report_problem'
          })
        })
    },
    formatarNota(body) {
      if (!body) return
      const notaFormatada = `
      <b>Nota interna:</b><br/>
      ${body.split('\n').join('<br/>')}
  `
      return notaFormatada
    },
    formatarBotaoWhatsapp (body) {
      if (!body) return
      let formatado = body

      function isAlphanumeric (c) {
        const x = c.charCodeAt()
        return (x >= 65 && x <= 90) || (x >= 97 && x <= 122) || (x >= 48 && x <= 57)
      }

      const whatsappStyles = (texto, wildcard, opTag, clTag) => {
        const indices = []
        try {
          for (let i = 0; i < texto.length; i++) {
            if (texto[i] === wildcard) {
              if (indices.length % 2) {
                if (texto[i - 1] !== ' ' && (typeof texto[i + 1] === 'undefined' || !isAlphanumeric(texto[i + 1]))) {
                  indices.push(i)
                }
              } else {
                if (typeof texto[i + 1] !== 'undefined' && texto[i + 1] !== ' ' && (typeof texto[i - 1] === 'undefined' || !isAlphanumeric(texto[i - 1]))) {
                  indices.push(i)
                }
              }
            } else if (texto[i].charCodeAt() === 10 && indices.length % 2) {
              indices.pop()
            }
          }
          if (indices.length % 2) indices pop()
          let offset = 0
          indices.forEach((v, i) => {
            const tag = i % 2 ? clTag : opTag
            formatado = formatado.slice(0, v + offset) + tag + formatado.slice(v + offset + 1)
            offset += tag.length - 1
          })
        } catch (error) {
          console.error('Error al aplicar estilos de WhatsApp:', error)
        }
        return formatado
      }

      try {
        // Divide el body en líneas
        const linhas = body.trim().split('\n')
        const tituloDescricao = linhas.shift() + '\n' // Primera línea es el título
        const botoes = linhas.filter(btn => btn.trim() !== '').map(btn => {
          return `<button style="display: inline-block; margin: 5px; padding: 10px; background-color: #0084ff; color: white; border: none; border-radius: 5px;" title="Este botón solo es pulsable en el móvil">➡️ ${btn.trim()}</button>`
        })
        formatado = [tituloDescricao, ...botoes].join('\n')
        formatado = whatsappStyles(formatado, '_', '<i>', '</i>')
        formatado = whatsappStyles(formatado, '*', '<b>', '</b>')
        formatado = whatsappStyles(formatado, '~', '<s>', '</s>')
        formatado = formatado.replace(/\n/g, '<br>')
        return formatado
      } catch (error) {
        console.error('Error al formatear botón de WhatsApp:', error)
        return body
      }
    },
    formatarData (data, formato = 'dd/MM/yyyy') {
      return format(parseISO(data), formato, { locale: es })
    }
  }
}
