import {
  Table,
  Column,
  Model,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  CreatedAt,
  UpdatedAt,
  DataType,
  Default,
  AutoIncrement
} from "sequelize-typescript";
import Tenant from "./Tenant";
import User from "./User";

@Table
class Group extends Model<Group> {
  @PrimaryKey
  @AutoIncrement
  @Column
  id: number;

  @Column
  group: string; // Assuming 'group' is the name column

  @Default(true)
  @Column
  isActive: boolean;

  @CreatedAt
  createdAt: Date;

  @UpdatedAt
  updatedAt: Date;

  @ForeignKey(() => User)
  @Column
  userId: number;

  @BelongsTo(() => User)
  user: User;

  @ForeignKey(() => Tenant)
  @Column
  tenantId: number;

  @BelongsTo(() => Tenant)
  tenant: Tenant;
}

export default Group;
