// Original: CheckChatBotWelcome.js
// Deobfuscated, converted to TS, and translated

'use strict';

import Contact from '../models/Contact'; // Asumiendo exportación predeterminada
import ShowStepAutoReplyMessageService from '../services/AutoReplyServices/ShowStepAutoReplyMessageService'; // Asumiendo exportación predeterminada
import CreateLogTicketService from '../services/TicketServices/CreateLogTicketService'; // Asumiendo exportación predeterminada

// Interfaz para el objeto 'ticket' (asumiendo propiedades basadas en el uso)
interface Ticket {
  id: number | string;
  userId?: number | null;
  contactId: number;
  isGroup: boolean;
  channel: string;
  tenantId: number;
  chatBot?: number | null; // Asumiendo que puede ser número o null
  autoReplyId?: number | null; // Asumiendo que puede ser número o null
  stepAutoReplyId?: number | null; // Asumiendo que puede ser número o null
  update: (data: Partial<Ticket>) => Promise<Ticket>; // Asumiendo que update devuelve una Promise
}

// Tipo para el objeto de respuesta de ShowStepAutoReplyMessageService
interface AutoReplyStep {
  id: number;
  autoReply: {
    id: number;
    celularTeste?: string | null; // Puede ser string o null
  };
}

const AutoReplyWelcome = async (ticket: Ticket): Promise<void> => {
  // Si ya tiene un bot asignado o un usuario, no hacer nada
  if (ticket.userId || ticket.chatBot) return;

  const stepAutoReply: AutoReplyStep | null = await ShowStepAutoReplyMessageService(
    0, // initialStep
    0, // msg?.chatbot || 0
    0, // msg?.contact?.number
    true, // firstInteraction
    ticket.tenantId
  );

  // Si no hay un paso de respuesta automática configurado, no hacer nada
  if (!stepAutoReply) return;

  const contact = await Contact.findByPk(ticket.contactId);
  const { celularTeste } = stepAutoReply.autoReply; // Obtener celularTeste
  const contactNumber = contact?.number;

  // Verifica si es un número de prueba o si el contacto no existe
  if (
    (celularTeste && contactNumber?.indexOf(celularTeste.substr(3)) !== -1) || !contactNumber
    ) {
      // Si es un canal de telegrama y no es un número de prueba, retornar
      if (ticket.channel === "telegram" && !celularTeste) {
        return;
      }
      // Si no es un número de prueba, retornar (para otros canales que no sean telegram)
      if (!celularTeste) {
        return;
      }
  }


  // Actualiza el ticket con los IDs de la respuesta automática
  await ticket.update({
    autoReplyId: Number(stepAutoReply.autoReply.id),
    stepAutoReplyId: Number(stepAutoReply.id)
  });

  // Crea un registro en el log del ticket
  await CreateLogTicketService({
    ticketId: ticket.id,
    type: 'chatBot'
  });
};

export default AutoReplyWelcome;