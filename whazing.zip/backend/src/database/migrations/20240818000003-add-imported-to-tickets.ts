import { QueryInterface, DataTypes } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    // Add the 'imported' column to the 'Tickets' table
    // Likely indicates the timestamp when the ticket was imported.
    await queryInterface.addColumn(
      'Tickets',   // Table name
      'imported',  // New column name
      {
        type: DataTypes.DATE, // Stores date and time
        allowNull: true,      // Allow null (ticket might not be imported)
      }
    );
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    // Remove the 'imported' column from the 'Tickets' table
    await queryInterface.removeColumn(
      'Tickets',   // Table name
      'imported'   // Column name to remove
    );
  }
};

export = migration;