import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<any> => {
    // Añade la columna 'wabaMediaId' (TEXT) a 'Messages'
    return Promise.all([
      queryInterface.addColumn("Messages", "wabaMediaId", {
        type: DataTypes.TEXT,
        allowNull: true, // Permite nulos
        defaultValue: null
      })
    ]);
  },

  down: (queryInterface: QueryInterface): Promise<any> => {
    // Elimina la columna 'wabaMediaId' de 'Messages'
    return Promise.all([
      queryInterface.removeColumn("Messages", "wabaMediaId")
    ]);
  }
};
