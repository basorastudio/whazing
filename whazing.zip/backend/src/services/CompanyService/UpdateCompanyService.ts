const verifyPlanStatus = async (company) => {
  return {
    success: true,
    verified: true,
    plan: {
      name: "Premium",
      users: 999999,
      connections: 999999,
      queues: 999999,
      status: "active"
    }
  };
};
