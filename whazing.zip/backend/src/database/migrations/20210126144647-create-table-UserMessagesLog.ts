import { QueryInterface, DataTypes, Sequelize } from "sequelize";

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla 'UserMessagesLog' para registrar logs de mensajes por usuario
    return queryInterface.createTable("UserMessagesLog", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
      },
      messageId: {
        type: DataTypes.STRING, // ID del mensaje (probablemente de WhatsApp)
        allowNull: true,
        defaultValue: null
      },
      userId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Users", // Referencia a la tabla Users
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "SET NULL" // Si el usuario se elimina, userId se establece en NULL
      },
      ticketId: {
        type: DataTypes.INTEGER,
        references: {
          model: "Tickets", // Referencia a la tabla Tickets
          key: "id"
        },
        onUpdate: "CASCADE",
        onDelete: "RESTRICT", // No permite eliminar el ticket si tiene logs asociados
        allowNull: true // Permite nulos (¿quizás para mensajes fuera de tickets?)
      },
      createdAt: {
        type: DataTypes.DATE(6), // Fecha con precisión de microsegundos
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE(6), // Fecha con precisión de microsegundos
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la tabla 'UserMessagesLog'
    return queryInterface.dropTable("UserMessagesLog");
  }
};
