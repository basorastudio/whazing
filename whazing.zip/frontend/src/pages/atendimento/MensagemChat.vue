<template>
  <div class="q-pa-md">
    <transition-group appear
      enter-active-class="animated fadeIn"
      leave-active-class="animated fadeOut">
      <!-- Agrupar mensajes por ticketId -->
      <template v-for="(group, ticketId) in groupedMessages">
        <div v-bind:key="`ticket-${ticketId}`">
          <!-- Mostrar el título del ticket -->
          <div class="ticket-title q-mb-md q-mt-md">
            Ticket {{ ticketId }}
          </div>
          <template v-for="(mensaje, index) in group">
            <hr
              v-if="index === 0 || formatarData(mensaje.createdAt) !== formatarData(group[index - 1]?.createdAt)"
              :key="'hr-' + index"
              class="hr-text q-mt-lg q-mb-md"
              :data-content="formatarData(mensaje.createdAt)"
            />
        <template v-if="mensajes.length && index === mensajes.length - 1">
          <div :key="`ref-${mensaje.createdAt}`"
            ref="lastMessageRef"
            id="lastMessageRef"
            style="float: 'left', background: 'black', clear: 'both'" />
        </template>
        <div :key="`chat-message-${mensaje.id}`"
          :id="`chat-message-${mensaje.id}`" />
        <q-chat-message :key="mensaje.id"
          :stamp="dataInWords(mensaje.createdAt)"
          :sent="mensaje.fromMe"
          class="text-weight-medium"
          :bg-color="mensaje.mediaType === 'note'
          ? 'yellow'
          : (mensaje.fromMe
          ? ($q.dark.isActive ? 'green-2' : 'green-1')
          : ($q.dark.isActive ? 'blue-2' : 'blue-1'))"
                        :class="{ pulseIdentications: identificarMensaje == `chat-message-${mensaje.id}` }">
          <!-- :bg-color="mensaje.fromMe ? 'grey-2' : 'secondary' " -->
          <div style="min-width: 100px; max-width: 350px;"
            :style="mensaje.isDeleted ? 'color: rgba(0, 0, 0, 0.36) !important;' : ''">
            <q-checkbox v-if="ativarMultiEncaminhamento"
              :key="`cheked-chat-message-${mensaje.id}`"
              :class="{
                  'absolute-top-right checkbox-encaminhar-right': !mensaje.fromMe,
                  'absolute-top-left checkbox-encaminhar-left': mensaje.fromMe
                }"
              :ref="`box-chat-message-${mensaje.id}`"
              @click.native="verificarEncaminharMensaje(mensaje)"
              :value="false" />

            <q-icon class="q-ma-xs"
              name="mdi-calendar"
              size="18px"
              :class="{
                  'text-primary': mensaje.scheduleDate && mensaje.status === 'pending',
                  'text-positive': !['pending', 'canceled'].includes(mensaje.status)
                }"
              v-if="mensaje.scheduleDate">
              <q-tooltip content-class="bg-secondary text-grey-8">
                <div class="row col">
                  Mensaje programado
                </div>
                <div class="row col"
                  v-if="mensaje.isDeleted">
                  <q-chip color="red-3"
                    icon="mdi-trash-can-outline">
                    Envío cancelado: {{ formatarData(mensaje.updatedAt, 'dd/MM/yyyy') }}
                  </q-chip>
                </div>
                <div class="row col">
                  <q-chip color="blue-1"
                    icon="mdi-calendar-import">
                    Enviado en: {{ formatarData(mensaje.createdAt, 'dd/MM/yyyy HH:mm') }}
                  </q-chip>
                </div>
                <div class="row col">
                  <q-chip color="blue-1"
                    icon="mdi-calendar-start">
                    Programado en: {{ formatarData(mensaje.scheduleDate, 'dd/MM/yyyy HH:mm') }}
                  </q-chip>
                </div>
              </q-tooltip>
            </q-icon>
            <div v-if="mensaje.sendType && mensaje.sendType.startsWith('user:')" class="bot-message">
              <q-icon name="mdi-account" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">{{ mensaje.sendType.replace('user: ', '') }}</span>
            </div>
            <div v-if="mensaje.sendType === 'Campaign'" class="bot-message">
              <q-icon name="mdi-bullhorn" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">Campaña</span>
            </div>
            <div v-if="mensaje.sendType === 'bot'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">BOT</span>
            </div>
            <div v-if="mensaje.sendType === 'typebot'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">TypeBot</span>
            </div>
            <div v-if="mensaje.sendType === 'openai'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">ChatGPT</span>
            </div>
            <div v-if="mensaje.sendType === 'groq'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">Groq</span>
            </div>
            <div v-if="mensaje.sendType === 'deepseek'" class="bot-message">
              <q-icon name="mdi-robot" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
              <span class="bot-label">DeepSeek</span>
            </div>
            <div v-if="mensaje.sendType === 'API'" class="bot-message">
              <q-icon name="mdi-api" size="18px" class="q-mr-xs color-light1" :class="$q.dark.isActive ? ('color-dark1') : ''" />
            </div>
              <div v-if="mensaje.isForwarded" class="forwarded-message">
                <i class="fa fa-share"></i>
                Mensaje reenviado
              </div>
            <div v-if="mensaje.isDeleted"
              class="text-italic">
              Mensaje eliminado en {{ formatarData(mensaje.updatedAt, 'dd/MM/yyyy') }}.
            </div>
            <div v-if="isGroupLabel(mensaje)"
              class="q-mb-sm"
              style="display: flex; color: rgb(59 23 251); fontWeight: 500;">
              {{ isGroupLabel(mensaje) }}
            </div>
            <div v-if="mensaje.quotedMsg" :class="{ textContentItem: !mensaje.isDeleted, textContentItemDeleted: mensaje.isDeleted }" @click="focarMensaje(mensaje.quotedMsg)">
              <MensagemRespondida
                style="max-width: 240px; max-height: 150px"
                class="row justify-center"
                :mensaje="mensaje.quotedMsg"
              />
            </div>
            <q-btn v-if="!mensaje.isDeleted && isShowOptions && mensaje.mediaType !== 'note'" class="absolute-top-right" dense flat ripple round icon="mdi-chevron-down">
              <q-menu square auto-close anchor="bottom left" self="top left">
                <q-list style="min-width: 100px">
                  <q-item :disable=" !['whatsapp', 'telegram'].includes(ticketFocado.channel) "
                    clickable
                    @click=" citarMensaje(mensaje) ">
                    <q-item-section>Responder</q-item-section>
                    <q-tooltip v-if=" !['whatsapp', 'telegram'].includes(ticketFocado.channel) ">
                      Disponible solo para WhatsApp y Telegram
                    </q-tooltip>
                  </q-item>
                  <q-item clickable :disable=" !['whatsapp'].includes(ticketFocado.channel) "
                    @click=" encaminharMensaje(mensaje) ">
                    <q-item-section>Reenviar</q-item-section>
                    <q-tooltip v-if=" !['whatsapp', 'telegram'].includes(ticketFocado.channel) ">
                      Disponible solo para WhatsApp
                    </q-tooltip>
                  </q-item>
                  <q-item clickable :disable=" !['whatsapp'].includes(ticketFocado.channel) "
                    @click=" marcarMensajesParaEncaminhar(mensaje) ">
                    <q-item-section>Marcar (reenviar varios)</q-item-section>
                    <q-tooltip v-if=" !['whatsapp'].includes(ticketFocado.channel) ">
                      Disponible solo para WhatsApp
                    </q-tooltip>
                  </q-item>

                  <q-item :disable=" !['whatsapp'].includes(ticketFocado.channel) " clickable @click="mensajeReacao = mensaje; modalEmojiOpen = true" v-if="ticketFocado.channel === 'whatsapp'">
                  <q-item-section>Reaccionar</q-item-section>
                  </q-item>

                  <q-item
                    @click=" AbrirmodaleditarMensaje(mensaje) "
                    clickable
                    v-if=" mensaje.fromMe  && mensaje.mediaType === 'chat'"
                    :disable=" !['whatsapp'].includes(ticketFocado.channel) "
                  >
                    <q-item-section>
                      <q-item-label>Editar Mensaje</q-item-label>
                    </q-item-section>
                    <q-tooltip v-if=" !['whatsapp'].includes(ticketFocado.channel) ">
                      Disponible solo para WhatsApp
                    </q-tooltip>
                  </q-item>
                  <q-separator />
                  <q-item @click=" deletarMensaje(mensaje) "
                    clickable
                    v-if=" mensaje.fromMe "
                          :disable=" !['whatsapp'].includes(ticketFocado.channel) ">
                    <q-item-section>
                      <q-item-label>Eliminar</q-item-label>
                    </q-item-section>
                    <q-tooltip v-if=" !['whatsapp'].includes(ticketFocado.channel) ">
                      Disponible solo para WhatsApp
                    </q-tooltip>
                  </q-item>
                </q-list>
              </q-menu>
            </q-btn>
            <q-icon v-if="mensaje.fromMe && mensaje.mediaType !== 'note'"
              class="absolute-bottom-right q-pr-xs q-pb-xs"
              :name=" ackIcons[mensaje.ack] "
              size="1.2em"
              :color=" mensaje.ack >= 3 ? 'blue-12' : '' " />
            <template v-if=" mensaje.mediaType === 'audio' ">
              <div style="width: 330px; heigth: 300px">
                <audio class="q-mt-md full-width"
                  controls
                  ref="audioMessage"
                  controlsList="download playbackrate volume">
                  <source :src=" mensaje.mediaUrl "
                    type="audio/mp3" />
                </audio>
              </div>
            </template>
            <template v-if=" mensaje.mediaType === 'contactMessage' ">
                <div style="min-width: 250px;">
                <ContatoCard
                :mensaje="mensaje"
                @openContactModal="openContactModal"
                />
                <ContatoModal
                :value="modalContato"
                :contact="currentContact"
                @close="closeModal"
                @saveContact="saveContact"
                />
                </div>
            </template>
            <template v-if="mensaje.mediaType === 'locationMessage'">
              <q-img
                @click="openGoogleMaps(mensaje.body)"
                src="../../assets/localizacao.png"
                spinner-color="primary"
                height="200px"
                width="200px"
                class="q-mt-md"
                style="cursor: pointer"
              />
            </template>
            <template v-if="mensaje.mediaType === 'liveLocationMessage'">
              <q-img
                @click="openGoogleMaps(mensaje.body)"
                src="../../assets/localizacao.png"
                spinner-color="primary"
                height="250px"
                width="250px"
                class="q-mt-md"
                style="cursor: pointer"
              />
            <div style="color: red;">*Aún no es posible mostrar la ubicación en tiempo real en este dispositivo. Abra WhatsApp en su celular para ver correctamente.</div>
            </template>
            <template v-if="mensaje.mediaType === 'comment'">
              <div class="q-pa-md">
                <template v-if="mensaje.dataJson">
                  <a :href="mensaje.dataJson"
                     target="_blank"
                     rel="noopener noreferrer"
                     class="external-link">
                    Nuevo Comentario - Enlace Publicación
                  </a>
                </template>
                <template v-else>
                  <span class="text-grey">Enlace de la publicación no disponible</span>
                </template>
              </div>
              <div v-html="formatarMensajeWhatsapp(mensaje.body)">
              </div>
            </template>
            <template v-if="mensaje.mediaType === 'interactiveMessage'">
              <div v-html=" formatarMensajeWhatsapp(mensaje.body) ">
              </div>
              <div style="color: red;">*Mensaje interactivo verificar en su celular.</div>
            </template>
            <template v-if="mensaje.mediaType === 'pollCreationMessageV2'">
              <div v-html=" formatarMensajeWhatsapp(mensaje.body) ">
              </div>
              <div style="color: red;">*Encuesta verificar en su celular.</div>
            </template>
            <template v-if="mensaje.mediaType === 'pollCreationMessageV3'">
              <div v-html=" formatarMensajeWhatsapp(mensaje.body) ">
              </div>
            <div style="color: red;">*Encuesta verificar en su celular.</div>
            </template>
            <template v-if="mensaje.mediaType === 'note'">
              <div v-html="formatarNota(mensaje.body)"></div>
            </template>
            <template v-if="mensaje.mediaType === 'productMessage'">
            <div style="color: red;">*No es posible mostrar este mensaje en este dispositivo. Abra WhatsApp en su celular para ver el mensaje.</div>
            </template>
            <template v-if="mensaje.mediaType === 'image'">
              <div style="width: 100%; max-width: 200px; overflow: hidden;">
                <img @click="urlMedia = mensaje.mediaUrl; abrirModalImagen = true"
                     :src="mensaje.mediaUrl"
                     style="width: 100%; height: auto; object-fit: contain; cursor: pointer; display: block;"
                     class="q-mt-md" />
              </div>
              <q-btn type="a"
                     :color=" $q.dark.isActive ? '' : 'grey-3' "
                     no-wrap
                     no-caps
                     stack
                     dense
                     class="q-mt-sm text-center text-black btn-rounded  text-grey-9 ellipsis"
                     download
                     @click="downloadMedia(mensaje.mediaUrl)"
              >
                <q-tooltip v-if=" mensaje.mediaUrl "
                           content-class="text-bold">
                  Descargar: {{ formatMediaName(mensaje.mediaName) }}
                </q-tooltip>
                <div class="row items-center q-ma-xs ">
                  <div class="ellipsis col-grow q-pr-sm"
                       style="max-width: 290px">
                    {{ formatMediaName(mensaje.mediaName) }}
                  </div>
                  <q-icon name="mdi-download" />
                </div>
              </q-btn>
              <VueEasyLightbox
                               :visible="abrirModalImagen"
                               :imgs="urlMedia"
                               class="bg-transparent easy-lightbox-wrapper"
                               :index="mensaje.ticketId || 1"
                               @hide="abrirModalImagen = false" />
            </template>
            <template v-if="mensaje.mediaType === 'video'">
              <div style="width: 100%; max-width: 330px; overflow: hidden;">
                <video :src="mensaje.mediaUrl"
                       controls
                       ref="videoElement"
                       style="width: 100%; height: auto; object-fit: contain; border-radius: 8px; max-height: 400px;">
                </video>
              </div>
              <q-btn type="a"
                     :color=" $q.dark.isActive ? '' : 'grey-3' "
                     no-wrap
                     no-caps
                     stack
                     dense
                     class="q-mt-sm text-center text-black btn-rounded  text-grey-9 ellipsis"
                     download
                     @click="downloadMedia(mensaje.mediaUrl)"
              >
                <q-tooltip v-if=" mensaje.mediaUrl "
                           content-class="text-bold">
                  Descargar: {{ formatMediaName(mensaje.mediaName) }}
                </q-tooltip>
                <div class="row items-center q-ma-xs ">
                  <div class="ellipsis col-grow q-pr-sm"
                       style="max-width: 290px">
                    {{ formatMediaName(mensaje.mediaName) }}
                  </div>
                  <q-icon name="mdi-download" />
                </div>
              </q-btn>
            </template>
            <template v-if="mensaje.mediaType === 'protocolMessage'">
              <div class="forwarded-message" v-html="formatarBotaoWhatsapp(mensaje.body)"></div>
            </template>
            <template v-if="mensaje.mediaType === 'buttonsMessage'">
              <div style="margin-top:20px" v-html="formatarBotaoWhatsapp(mensaje.body)"></div>
            </template>
            <template v-if="mensaje.mediaType === 'listMessage'">
              <div style="margin-top:20px" v-html="formatarBotaoWhatsapp(mensaje.body)"></div>
            </template>
            <template v-if=" !['audio', 'vcard', 'image', 'video'].includes(mensaje.mediaType) && mensaje.mediaUrl ">
              <div class="text-center full-width hide-scrollbar no-scroll">
                <iframe v-if=" isPDF(mensaje.mediaUrl) "
                  frameBorder="0"
                  scrolling="no"
                  style="
                    width: 330px;
                    height: 150px;
                    overflow-y: hidden;
                    -ms-overflow-y: hidden;
                  "
                  class="no-scroll hide-scrollbar"
                  :src=" mensaje.mediaUrl "
                  id="frame-pdf">
                  Haga la descarga del PDF
                  <!-- alt : <a href="mensaje.mediaUrl"></a> -->
                </iframe>
                <q-btn type="a"
                  :color=" $q.dark.isActive ? '' : 'grey-3' "
                  no-wrap
                  no-caps
                  stack
                  dense
                  class="q-mt-sm text-center text-black btn-rounded  text-grey-9 ellipsis"
                  download
                  :target=" isPDF(mensaje.mediaUrl) ? '_blank' : '' "
                  :href=" mensaje.mediaUrl ">
                  <q-tooltip v-if=" mensaje.mediaUrl "
                    content-class="text-bold">
                    Descargar: {{ formatMediaName(mensaje.mediaName) }}
                  </q-tooltip>
                  <div class="row items-center q-ma-xs ">
                    <div class="ellipsis col-grow q-pr-sm"
                      style="max-width: 290px">
                      {{ formatMediaName(mensaje.mediaName) }}
                    </div>
                    <q-icon name="mdi-download" />
                  </div>
                </q-btn>
              </div>
            </template>
            <div v-linkified
              v-if=" !['reactionMessage', 'note', 'protocolMessage', 'listMessage', 'buttonsMessage', 'productMessage', 'contactMessage', 'locationMessage', 'liveLocationMessage', 'interactiveMessage', 'pollCreationMessageV3', 'comment'].includes(mensaje.mediaType) "
                 :class="{'q-mt-sm': !['chat','extendedMessageText', 'conversation'].includes(mensaje.mediaType)}"
              class="q-message-container row items-end no-wrap">
              <div v-if="'canRead' in mensaje && !mensaje.canRead">
                <i>Sin permiso para leer este mensaje</i>
              </div>
              <div v-if="mensaje.body && !mensaje.edited" v-html="formatarMensajeWhatsapp(mensaje.body)">
              </div>
            </div>
            <div v-if="mensaje.body && mensaje.edited">
              <div v-html="formatarMensajeWhatsapp(mensaje.body)"></div>
              <small class="text-grey">(editado) {{ mensaje.edited }}</small>
            </div>
            <div v-if="mensaje.mediaType === 'reactionMessage'" class="reaction-container q-mt-xs">
              {{ mensaje.body }}
            </div>
          </div>
        </q-chat-message>
      </template>
    </transition-group>
<q-dialog v-model="modalEmojiOpen">
  <q-card>
    <q-card-section class="row q-gutter-sm">
      <!-- Muestra los 6 emojis principales -->
      <q-btn v-for="emoji in principaisEmojis" :key="emoji" flat @click="selectEmoji(emoji, mensajeReacao)">
        {{ emoji }}
      </q-btn>

      <!-- Botón circular con el ícono "+" -->
      <q-btn
        flat
        round
        icon="add"
        size="sm"
        class="q-ml-sm"
        @click="expandirEmojis = !expandirEmojis"
      />

      <!-- Muestra el resto de los emojis si expandirEmojis es verdadero -->
      <div v-if="expandirEmojis">
        <VEmojiPicker
          style="width: 40vw"
          :showSearch="true"
          :emojisByRow="calculateEmojisByRow()"
          labelSearch="Buscar..."
          lang="es"
          @select="onInsertSelectEmoji"
        />
      </div>
    </q-card-section>
  </q-card>
</q-dialog>
  <q-dialog v-model="showModaledit">
  <q-card class="q-pa-lg modal-container container-rounded-10">
    <q-card-section>
      <div class="text-h6">Editar Mensaje</div>
    </q-card-section>
    <q-card-section>
      <q-input filled v-model="mensajeAtual.body" label="Mensaje" />
    </q-card-section>
    <q-card-actions align="right">
      <q-btn label="Cancelar" color="negative" v-close-popup />
      <q-btn label="Guardar" color="primary" @click="salvarMensaje" />
    </q-card-actions>
  </q-card>
</q-dialog>
  </div>
</template>

<script>
import mixinCommon from './mixinCommon'
import axios from 'axios'
import VueEasyLightbox from 'vue-easy-lightbox'
import MensagemRespondida from './MensagemRespondida'
import ContatoCard from './ContatoCard.vue'
import ContatoModal from './ContatoModal.vue'
import { VEmojiPicker } from 'v-emoji-picker'
const downloadImageCors = axios.create({
  baseURL: process.env.URL_API,
  timeout: 20000,
  headers: {
    responseType: 'blob'
  }
})
import { DeletarMensagem, EditarMensagem, ReagirMensagem } from 'src/service/tickets'
import { Base64 } from 'js-base64'
export default {
  name: 'MensagemChat',
  mixins: [mixinCommon],
  props: {
    mensaje: {
      type: Object,
      required: true
    },
    mensajes: {
      type: Array,
      default: () => []
    },
    mensajesParaEncaminhar: {
      type: Array,
      default: () => []
    },
    size: {
      type: [String, Number],
      default: '5'
    },
    isLineDate: {
      type: Boolean,
      default: true
    },
    isShowOptions: {
      type: Boolean,
      default: true
    },
    ativarMultiEncaminhamento: {
      type: Boolean,
      default: false
    },
    replyingMessage: {
      type: Object,
      default: () => { }
    }
  },
  data () {
    return {
      modalEmojiOpen: false,
      mensajeReacao: null,
      expandirEmojis: false,
      principaisEmojis: ['👍', '❤️', '😂', '😮', '😢', '👏'],
      mensajeAtual: { body: '' },
      showModaledit: false,
      modalContato: false,
      currentContact: {},
      abrirModalImagen: false,
      urlMedia: '',
      identificarMensaje: null,
      ackIcons: { // Si ACK == 3 o 4 entonces color verde
        0: 'mdi-clock-outline',
        1: 'mdi-check',
        2: 'mdi-check-all',
        3: 'mdi-check-all',
        4: 'mdi-check-all'
      }
    }
  },
  components: {
    VueEasyLightbox,
    MensagemRespondida,
    ContatoCard,
    ContatoModal,
    VEmojiPicker
  },
  computed: {
    groupedMessages() {
      const groups = {}
      this.mensajes.forEach((mensaje) => {
        const ticketId = mensaje.ticketId
        if (!groups[ticketId]) {
          groups[ticketId] = []
        }
        groups[ticketId].push(mensaje)
      })

      return groups
    }
  },
  methods: {
    onInsertSelectEmoji(emoji) {
      if (this.mensajeReacao) {
        const reactionData = {
          messageId: this.mensajeReacao.messageId,
          ticketId: this.mensajeReacao.ticketId,
          reaction: emoji.data
        }
        this.selectEmoji(reactionData.reaction, this.mensajeReacao)
      } else {
        console.error('Ningún mensaje fue seleccionado para reacción.')
      }
      this.modalEmojiOpen = false
    },
    async selectEmoji(emoji, mensaje) {
      if (mensaje) {
        const reactionData = {
          messageId: mensaje.messageId,
          ticketId: mensaje.ticketId,
          reaction: emoji
        }
        await ReagirMensagem(reactionData)
        this.mensaje = null
      } else {
        console.error('Ningún mensaje fue seleccionado para reacción.')
      }
      this.modalEmojiOpen = false
    },
    calculateEmojisByRow() {
      const screenWidth = window.innerWidth
      if (screenWidth < 600) {
        return 5
      } else if (screenWidth >= 600 && screenWidth < 1200) {
        return 10
      } else {
        return 20
      }
    },
    async salvarMensaje () {
      try {
        const updatedMessage = await EditarMensagem({
          id: this.mensajeAtual.id,
          messageId: this.mensajeAtual.messageId,
          body: this.mensajeAtual.body
        })
        // console.log('Mensaje editado con éxito')
        this.showModaledit = false
        this.atualizarMensaje(updatedMessage)
      } catch (error) {
        console.error('Error al editar el mensaje', error.message)
        this.$notificarErro('No fue posible editar el mensaje')
      }
    },
    atualizarMensaje (updatedMessage) {
      const index = this.mensajes.findIndex(mensaje => mensaje.id === updatedMessage.id)
      if (index !== -1) {
        this.mensajes.splice(index, 1, updatedMessage)
      }
    },
    AbrirmodaleditarMensaje (mensaje) {
      this.mensajeAtual = mensaje
      this.showModaledit = true
    },
    openContactModal (contact) {
      this.currentContact = contact
      this.modalContato = true
    },
    closeModal () {
      this.modalContato = false
    },
    saveContact (contact) {
      // console.log('Contacto guardado:', contact)
      // Aquí puedes agregar la lógica para guardar el contacto
    },
    getMapThumbnail(body) {
      const [thumbnail] = body.split('|')
      return thumbnail
    },
    openGoogleMaps(body) {
      const [, mapLink] = body.split('|')
      window.open(mapLink, '_blank')
    },
    verificarEncaminharMensaje (mensaje) {
      const mensajes = [...this.mensajesParaEncaminhar]
      const msgIdx = mensajes.findIndex(m => m.id === mensaje.id)
      if (msgIdx !== -1) {
        mensajes.splice(msgIdx, 1)
      } else {
        if (this.mensajesParaEncaminhar.length > 9) {
          this.$notificarErro('Permitido un máximo de 10 mensajes.')
          return
        }
        mensajes.push(mensaje)
      }
      this.$refs[`box-chat-message-${mensaje.id}`][0].value = !this.$refs[`box-chat-message-${mensaje.id}`][0].value
      this.$emit('update:mensajesParaEncaminhar', mensajes)
    },
    marcarMensajesParaEncaminhar (mensaje) {
      this.$emit('update:mensajesParaEncaminhar', [])
      this.$emit('update:ativarMultiEncaminhamento', !this.ativarMultiEncaminhamento)
      // this.verificarEncaminharMensaje(mensaje)
    },
    isPDF (url) {
      if (!url) return false
      const split = url.split('.')
      const ext = split[split.length - 1]
      return ext === 'pdf'
    },
    isGroupLabel (mensaje) {
      try {
        return this.ticketFocado.isGroup ? mensaje.contact.name : ''
      } catch (error) {
        return ''
      }
    },
    // cUrlMediaCors () {
    //   return this.urlMedia
    // },
    returnCardContato (str) {
      // return btoa(str)
      return Base64.encode(str)
    },
    isDesactivatDelete (msg) {
      // if (msg) {
      //   return (differenceInMinutes(new Date(), new Date(+msg.timestamp)) > 5)
      // }
      return false
    },
    async buscarImageCors (imageUrl) {
      this.loading = true
      try {
        const { data, headers } = await downloadImageCors.get(imageUrl, {
          responseType: 'blob'
        })
        const url = window.URL.createObjectURL(
          new Blob([data], { type: headers['content-type'] })
        )
        this.urlMedia = url
        this.abrirModalImagen = true
      } catch (error) {
        this.$notificarErro('¡Ocurrió un error!', error)
      }
      this.loading = false
    },
    citarMensaje (mensaje) {
      this.$emit('update:replyingMessage', mensaje)
      this.$root.$emit('mensaje-chat:focar-input-mensaje', mensaje)
    },
    encaminharMensaje (mensaje) {
      this.$emit('mensaje-chat:encaminhar-mensaje', mensaje)
    },
    deletarMensaje (mensaje) {
      if (this.isDesactivatDelete(mensaje)) {
        this.$notificarErro('No fue posible eliminar el mensaje con más de 5 minutos de envío.')
      }
      // const diffHoursDate = differenceInHours(
      //   new Date(),
      //   parseJSON(mensaje.createdAt)
      // )
      // if (diffHoursDate > 2) {
      //   // throw new AppError("No delete message afeter 2h sended");
      // }
      const data = { ...mensaje }
      this.$q.dialog({
        title: '¡Atención!! ¿Realmente desea eliminar el mensaje?',
        message: 'Los mensajes antiguos no serán eliminados en el cliente.',
        cancel: {
          label: 'No',
          color: 'primary',
          push: true
        },
        ok: {
          label: 'Sí',
          color: 'negative',
          push: true
        },
        persistent: true
      }).onOk(() => {
        this.loading = true
        DeletarMensagem(data)
          .then(res => {
            this.loading = false
            mensaje.isDeleted = true
          })
          .catch(error => {
            this.loading = false
            console.error(error)
            this.$notificarErro('No fue posible eliminar el mensaje', error)
          })
      }).onCancel(() => {
      })
    },
    focarMensaje (mensaje) {
      const id = `chat-message-${mensaje.id}`
      this.identificarMensaje = id
      this.$nextTick(() => {
        const elem = document.getElementById(id)
        elem.scrollIntoView()
      })
      setTimeout(() => {
        this.identificarMensaje = null
      }, 5000)
    }
  },
  mounted () {
    this.scrollToBottom()
    window.addEventListener('resize', this.onResize)
    // this.$refs.audioMessage.forEach(element => {
    //   element.playbackRate = 2
    // })
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.onResize)
  },
  destroyed() {}
}
</script>

<style lang="scss">
.frame-pdf {
  overflow: hidden;
}

.bot-message {
  display: flex;
  align-items: center;
  font-size: 12px;
  color: #666;
  margin-bottom: 4px;

  .bot-label {
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
}

.ticket-title {
  font-size: 1.5rem;
  font-weight: bold;
  color: #333;
  border-bottom: 2px solid #ccc;
  padding-bottom: 0.5rem;
  margin-bottom: 1rem;
}

.quoted-container {
  display: flex;
  align-items: center; /* Alinea en el centro verticalmente */
  justify-content: flex-start; /* Alinea correctamente */
  max-width: 240px;
  max-height: 150px;
  padding: 8px; /* Reduce el espacio en blanco */
  background-color: rgba(0, 0, 0, 0.05); /* Para visualizar */
  border-radius: 8px;
}

.reaction-container {
  font-size: 0.75rem;
  color: #606060;
  margin-top: 8px;
  padding: 2px 4px;
  border-radius: 4px;
  background-color: #f0f0f0;
  display: inline-block;
}

.checkbox-encaminhar-right {
  right: -35px;
  z-index: 99999;
}

.forwarded-message {
  font-style: italic;
  color: #4a4a4a;
  font-size: 12px;
  margin-bottom: 5px;
  display: flex;
  align-items: center;
}

.icon-forward {
  margin-right: 5px;
  font-size: 14px;
  color: #4a4a4a;
}

.checkbox-encaminhar-left {
  left: -35px;
  z-index: 99999;
}

.emoji-picker {
  width: 100%;
}

.q-message-container.row.items-end.no-wrap {
  padding: 0 30px 0 0 !important;
}

.comment-message {
  padding: 8px;
}

.new-comment {
  font-weight: bold;
  margin-bottom: 4px;
}

.comment-body {
  color: #666;
}

@media (min-width: 600px) {
  .emoji-picker {
    width: 50vw;
  }
}

</style>
