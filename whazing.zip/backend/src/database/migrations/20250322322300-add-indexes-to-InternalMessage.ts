import { QueryInterface } from 'sequelize';
import { Migration } from 'sequelize';

const migration: Migration = {
  up: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'InternalMessages'; // Pluralized table name
    // Add index on [senderId, receiverId]
    await queryInterface.addIndex(tableName, ['senderId', 'receiverId'], {
      name: 'idx_internal_message_sender_receiver', // Explicit index name
    });
    // Add index on [groupId]
    await queryInterface.addIndex(tableName, ['groupId'], {
      name: 'idx_internal_message_group', // Explicit index name
    });
     // Add index on [tenantId]
    await queryInterface.addIndex(tableName, ['tenantId'], {
       name: 'idx_internal_message_tenant', // Explicit index name
    });
  },

  down: async (queryInterface: QueryInterface): Promise<void> => {
    const tableName = 'InternalMessages';
    // Remove indexes in reverse order
    await queryInterface.removeIndex(tableName, 'idx_internal_message_tenant');
    await queryInterface.removeIndex(tableName, 'idx_internal_message_group');
    await queryInterface.removeIndex(tableName, 'idx_internal_message_sender_receiver');
  }
};

export = migration;