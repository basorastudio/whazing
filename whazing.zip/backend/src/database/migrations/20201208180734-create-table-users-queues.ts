import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Crea la tabla de unión 'UsersQueues' para la relación muchos a muchos entre Users y Queues
    return queryInterface.createTable('UsersQueues', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      queueId: {
        type: DataTypes.INTEGER,
        references: {
          model: 'Queues', // Referencia a la tabla Queues
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Si se elimina una Queue, se elimina la asociación
        allowNull: false
      },
      userId: {
        type: DataTypes.INTEGER,
        references: {
          model: 'Users', // Referencia a la tabla Users
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE', // Si se elimina un User, se elimina la asociación
        allowNull: false
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: false
      }
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    return queryInterface.dropTable('UsersQueues');
  }
};