import { QueryInterface, DataTypes, Sequelize } from 'sequelize';

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'tokenTelegram' a la tabla 'Whatsapps'
    return queryInterface.addColumn('Whatsapps', 'tokenTelegram', {
      type: DataTypes.STRING,
      allowNull: true, // Permite nulos
      defaultValue: null
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'tokenTelegram' de la tabla 'Whatsapps'
    return queryInterface.removeColumn('Whatsapps', 'tokenTelegram');
  }
};