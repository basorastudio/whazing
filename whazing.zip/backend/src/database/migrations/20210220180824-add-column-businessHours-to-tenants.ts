import { QueryInterface, DataTypes, Sequelize } from "sequelize";
import { BusinessHours } from "../../utils/defaultConstants"; // Asume que la ruta y exportación son correctas

export = {
  up: (queryInterface: QueryInterface): Promise<void> => {
    // Añade la columna 'businessHours' (JSONB) a la tabla 'Tenants'
    return queryInterface.addColumn("Tenants", "businessHours", {
      type: DataTypes.JSONB,
      allowNull: true, // Permite nulos
      defaultValue: BusinessHours // Usa el valor predeterminado importado
    });
  },

  down: (queryInterface: QueryInterface): Promise<void> => {
    // Elimina la columna 'businessHours' de la tabla 'Tenants'
    return queryInterface.removeColumn("Tenants", "businessHours");
  }
};
