import { Socket } from "socket.io"; // Import Socket type
import * as _ from "lodash"; // Import lodash

// Define interfaces for data structures if known, otherwise use 'any' initially
interface UserState {
  sockets: string[];
  user: any; // Replace 'any' with a specific User interface if available
}

interface TenantRoomState {
  usersOnline: { [userId: string]: UserState };
  idleUsers: { [userId: string]: UserState };
  sockets: Socket[]; // Array of Socket instances
}

interface SharedIoState {
  [tenantRoomKey: string]: TenantRoomState;
}

interface SocketData {
  // Define structure of data object passed in emit/on events if known
  [key: string]: any;
}

/**
 * Sorts an object by its keys alphabetically.
 * @param obj The object to sort.
 * @returns A new object with keys sorted.
 */
export const sortByKeys = <T extends object>(obj: T): T => {
  const keys = Object.keys(obj);
  const sortedKeys = _.sortBy(keys);
  // Use _.fromPairs correctly with map to create the sorted object
  return _.fromPairs(_.map(sortedKeys, key => [key, obj[key as keyof T]])) as T;
};

/**
 * Sends an event to the specific socket instance.
 * @param socket The client socket instance.
 * @param event The event name.
 * @param data Optional data to send.
 */
export const sendToSelf = (
  socket: Socket,
  event: string,
  data: SocketData = {}
): void => {
  socket.emit(event, data);
};

/**
 * Sends an event to all sockets associated with a specific user ID, except the sender socket.
 * (Internal helper potentially, considering the name prefix)
 * @param io The Socket.IO server instance or namespace.
 * @param userId The target user ID.
 * @param socketId The sender's socket ID to exclude.
 * @param event The event name.
 * @param data Optional data to send.
 */
export const _sendToSelf = (
  io: any, // Type for io instance (e.g., Namespace or Server from socket.io)
  userId: string | number,
  socketId: string,
  event: string,
  data: SocketData
): void => {
  // This function seems intended to send to other sockets of the *same user*.
  // The original logic iterates through all sockets, which is inefficient.
  // A better approach requires knowing how user sockets are tracked (e.g., in a room or map).
  // Assuming a structure like Index.js maintains state:
  // Find the user's other sockets and emit directly to them.
  // This implementation remains closer to the original flawed iteration for now.
  _.each(io.sockets.sockets, (socketInstance: Socket) => {
    if (socketInstance.id !== socketId) {
      // Check if it's not the sender
      // Check if this socket belongs to the target user (requires user info on socket)
      if ((socketInstance as any).userId === userId) {
        // Assuming userId is attached to socket
        socketInstance.emit(event, data);
      }
    }
  });
  // NOTE: The original logic iterating ALL sockets is very inefficient.
  // A better implementation would directly target the user's sockets if tracked.
};

/**
 * Sends an event to all connected clients in the current namespace.
 * @param io The Socket.IO server instance or namespace.
 * @param event The event name.
 * @param data Optional data to send.
 */
export const sendToAllConnectedClients = (
  io: any,
  event: string,
  data: SocketData
): void => {
  io.emit(event, data);
};

/**
 * Sends an event to all clients joined to a specific room.
 * @param io The Socket.IO server instance or namespace.
 * @param room The room name/ID.
 * @param event The event name.
 * @param data Optional data to send.
 */
export const sendToAllClientsInRoom = (
  io: any,
  room: string,
  event: string,
  data: SocketData
): void => {
  io.in(room).emit(event, data);
};

/**
 * Sends an event specifically to sockets associated with a target user ID.
 * @param io The Socket.IO server instance or namespace.
 * @param userSocketsMap A map where keys are user IDs and values are objects containing socket IDs.
 * @param targetUserId The ID of the user to send the message to.
 * @param event The event name.
 * @param data Optional data to send.
 * @returns boolean indicating if any socket was found for the user.
 */
export const sendToUser = (
  io: any, // Use proper Server or Namespace type from socket.io
  userSocketsMap: { [userId: string]: UserState | undefined }, // Map from userId to user state
  targetUserId: string | number,
  event: string,
  data: SocketData
): boolean => {
  const targetUserState = userSocketsMap[targetUserId.toString()];

  if (
    !targetUserState ||
    !targetUserState.sockets ||
    targetUserState.sockets.length === 0
  ) {
    // console.warn(`No sockets found for user ${targetUserId}`);
    return false; // No sockets found for this user
  }

  let messageSent = false;
  targetUserState.sockets.forEach(socketId => {
    const targetSocket = io.sockets.sockets.get(socketId); // Get socket instance by ID
    if (targetSocket) {
      targetSocket.emit(event, data);
      messageSent = true;
      // console.log(`Sent event '${event}' to socket ${socketId} for user ${targetUserId}`);
    } else {
      // console.warn(`Socket ${socketId} for user ${targetUserId} not found in main io instance.`);
      // Optionally: Clean up stale socket IDs from userSocketsMap here
    }
  });

  return messageSent;
};

/**
 * Sends an event to all connected clients except for the specified socket ID.
 * @param io The Socket.IO server instance or namespace.
 * @param senderSocketId The ID of the socket to exclude.
 * @param event The event name.
 * @param data Optional data to send.
 */
export const sendToAllExcept = (
  io: any,
  senderSocketId: string,
  event: string,
  data: SocketData
): void => {
  // Iterate over all connected sockets in the namespace
  io.sockets.sockets.forEach((socket: Socket) => {
    if (socket.id !== senderSocketId) {
      socket.emit(event, data);
    }
  });
  // Alternative using built-in broadcast:
  // const senderSocket = io.sockets.sockets.get(senderSocketId);
  // if (senderSocket) {
  //     senderSocket.broadcast.emit(event, data);
  // } else {
  //     // Fallback if sender socket not found (shouldn't normally happen)
  //     io.emit(event, data);
  // }
};

/**
 * Disconnects all clients currently connected to the namespace.
 * @param io The Socket.IO server instance or namespace.
 */
export const disconnectAllClients = (io: any): void => {
  Object.keys(io.sockets.sockets).forEach(socketId => {
    const socket = io.sockets.sockets.get(socketId);
    if (socket) {
      socket.disconnect(true); // true: close underlying connection
    }
  });
};
